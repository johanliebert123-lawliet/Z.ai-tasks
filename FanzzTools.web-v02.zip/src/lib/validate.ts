/** Validasi input ketat untuk API routes. */

export function isEmail(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(v.trim()) &&
    v.length <= 120
  );
}

export function isUsername(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^[a-zA-Z0-9_.\s]{3,24}$/.test(v.trim()) &&
    v.trim().length >= 3
  );
}

/**
 * V2 Modern-UpdSec: minimum password dinaikkan 6 → 8 karakter.
 * (vault hash di client bisa di-brute-force offline bila password pendek;
 *  8+ karakter menaikkan biaya serangan secara signifikan.)
 */
export function isPassword(v: unknown): v is string {
  return typeof v === "string" && v.length >= 8 && v.length <= 72;
}

/** IPv4 private / reserved / loopback / CGNAT / link-local — untuk SSRF guard. */
const PRIVATE_IPV4 = [
  /^0\./, // 0.0.0.0/8
  /^10\./, // 10.0.0.0/8
  /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./, // 100.64.0.0/10 (CGNAT)
  /^127\./, // loopback
  /^169\.254\./, // link-local
  /^172\.(1[6-9]|2\d|3[01])\./, // 172.16.0.0/12
  /^192\.168\./, // private
  /^192\.0\.0\./, // IETF protocol assignments
  /^192\.0\.2\./, // TEST-NET-1
  /^198\.18\./, // benchmark
  /^198\.51\.100\./, // TEST-NET-2
  /^203\.0\.113\./, // TEST-NET-3
  /^(22[4-9]|23\d)\./, // multicast + reserved
];

const PRIVATE_IPV6 = [
  /^::1$/, // loopback
  /^[fF][cCdD]/, // fc00::/7 unique-local
  /^[fF][eE]80:/, // link-local
  /^::$/, // unspecified
];

/** Cek apakah sebuah hostname/IP adalah target terlarang (SSRF). */
export function isPrivateHost(host: string): boolean {
  const h = host.trim().toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost")) return true;
  // literal IPv6 tanpa kurung siku
  if (h.includes(":")) {
    return PRIVATE_IPV6.some((re) => re.test(h));
  }
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(h)) {
    return PRIVATE_IPV4.some((re) => re.test(h));
  }
  // desimal/oktal/heksa bentuk aneh dari IP (mis. 2130706433 = 127.0.0.1)
  if (/^\d{8,10}$/.test(h)) {
    const n = Number(h);
    const ip = `${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}`;
    return PRIVATE_IPV4.some((re) => re.test(ip));
  }
  if (/^0x[0-9a-f]+$/i.test(h)) {
    const n = parseInt(h, 16);
    if (Number.isFinite(n)) {
      const ip = `${(n >>> 24) & 255}.${(n >>> 16) & 255}.${(n >>> 8) & 255}.${n & 255}`;
      return PRIVATE_IPV4.some((re) => re.test(ip));
    }
  }
  return false;
}

/** URL http(s) aman (blokir SSRF ke localhost/internal — lengkap V2 UpdSec). */
export function isHttpUrl(v: unknown): v is string {
  if (typeof v !== "string") return false;
  try {
    const u = new URL(v.trim());
    if (u.protocol !== "http:" && u.protocol !== "https:") return false;
    if (u.username || u.password) return false; // URL dengan kredensial embed = indikasi serangan
    return !isPrivateHost(u.hostname);
  } catch {
    return false;
  }
}

export function clampStr(v: unknown, max: number, fallback = ""): string {
  if (typeof v !== "string") return fallback;
  return v.slice(0, max);
}

/**
 * V2 Modern-UpdSec: bcrypt rounds bisa naik (10 → 12) lewat env,
 * jadi hash lama $10$ tetap dikenali saat compare.
 */
export function isBcryptHash(v: unknown): v is string {
  return (
    typeof v === "string" &&
    /^\$2[aby]\$(10|11|12|13)\$[./A-Za-z0-9]{53}$/.test(v)
  );
}
