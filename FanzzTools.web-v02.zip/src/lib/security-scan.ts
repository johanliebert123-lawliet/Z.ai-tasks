/**
 * FanzzSecurity — mesin analisis file STATIS di sisi klien (client-side).
 *
 * JUJUR soal kemampuan: ini analisis heuristik statis (hash + magic-byte +
 * kecocokan ekstensi + struktur arsip). BUKAN engine antivirus. Untuk verdict
 * "MALICIOUS" asli dibutuhkan reputation/malware engine (mis. VirusTotal) —
 * bila belum dikonfigurasi, hasil ditampilkan sebagai HEURISTIC_ONLY /
 * SUSPICIOUS, tidak pernah dipalsukan menjadi "SAFE" atau "virus detected".
 *
 * Tidak ada file yang DIJALANKAN — semua hanya dibaca sebagai byte.
 */

export interface FileScanResult {
  name: string;
  size: number;
  ext: string;
  mimeDetected: string;
  mimeLabel: string;
  sha256: string;
  status: "CLEAN_HEURISTIC" | "SUSPICIOUS" | "HEURISTIC_ONLY" | "UNSCANNABLE";
  statusLabel: string;
  signals: Array<{ label: string; detail: string; level: "info" | "warn" | "danger" }>;
  riskScore: number; // 0-100 — skor sinyal yang TERSEDIA, bukan probabilitas infeksi
  recommendation: "KEEP" | "REVIEW" | "QUARANTINE" | "REMOVE_RECOMMENDED";
  durationMs: number;
}

/** Tabel magic-byte umum — deteksi MIME nyata dari isi, bukan ekstensi. */
const MAGIC_TABLE: Array<{ sig: number[]; offset?: number; mime: string; label: string; category: string }> = [
  { sig: [0xff, 0xd8, 0xff], mime: "image/jpeg", label: "JPEG image", category: "image" },
  { sig: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], mime: "image/png", label: "PNG image", category: "image" },
  { sig: [0x47, 0x49, 0x46, 0x38], mime: "image/gif", label: "GIF image", category: "image" },
  { sig: [0x52, 0x49, 0x46, 0x46], mime: "image/webp", label: "WebP/RIFF", category: "image" },
  { sig: [0x42, 0x4d], mime: "image/bmp", label: "BMP image", category: "image" },
  { sig: [0x25, 0x50, 0x44, 0x46], mime: "application/pdf", label: "PDF document", category: "document" },
  { sig: [0x50, 0x4b, 0x03, 0x04], mime: "application/zip", label: "ZIP archive", category: "archive" },
  { sig: [0x50, 0x4b, 0x05, 0x06], mime: "application/zip", label: "ZIP archive (empty)", category: "archive" },
  { sig: [0x52, 0x61, 0x72, 0x21, 0x1a, 0x07], mime: "application/x-rar", label: "RAR archive", category: "archive" },
  { sig: [0x37, 0x7a, 0xbc, 0xaf, 0x27, 0x1c], mime: "application/x-7z", label: "7-Zip archive", category: "archive" },
  { sig: [0x1f, 0x8b], mime: "application/gzip", label: "GZIP archive", category: "archive" },
  { sig: [0xd0, 0xcf, 0x11, 0xe0], mime: "application/vnd.ms-office", label: "MS Office (legacy)", category: "document" },
  { sig: [0x50, 0x4b, 0x03, 0x04, 0x14, 0x00, 0x06, 0x00], mime: "application/vnd.ms-office", label: "MS Office (OOXML)", category: "document" },
  { sig: [0x49, 0x44, 0x33], mime: "audio/mpeg", label: "MP3 audio (ID3)", category: "audio" },
  { sig: [0xff, 0xfb], mime: "audio/mpeg", label: "MP3 audio", category: "audio" },
  { sig: [0x66, 0x74, 0x79, 0x70], offset: 4, mime: "video/mp4", label: "MP4/ISO-BMFF media", category: "video" },
  { sig: [0x1a, 0x45, 0xdf, 0xa3], mime: "video/webm", label: "WebM/Matroska video", category: "video" },
  { sig: [0x00, 0x00, 0x01, 0x00], mime: "image/x-icon", label: "ICO icon", category: "image" },
  { sig: [0x7f, 0x45, 0x4c, 0x46], mime: "application/x-elf", label: "ELF executable (Linux)", category: "executable" },
  { sig: [0x4d, 0x5a], mime: "application/x-msdownload", label: "Windows executable (MZ)", category: "executable" },
  { sig: [0xca, 0xfe, 0xba, 0xbe], mime: "application/x-java-archive", label: "Java class/JAR", category: "executable" },
  { sig: [0x64, 0x65, 0x78, 0x0a], offset: 0, mime: "application/vnd.android.dex", label: "Android DEX bytecode", category: "executable" },
  { sig: [0x7f, 0x45, 0x4c, 0x46], mime: "application/x-elf", label: "ELF executable", category: "executable" },
];

const APK_ZIP_HINTS = ["AndroidManifest.xml", "classes.dex", "META-INF/"];

function extOf(name: string): string {
  const m = name.match(/\.([a-z0-9]+)$/i);
  return m ? m[1].toLowerCase() : "";
}

/** Peta ekstensi → tipe yang DIHARAPKAN (untuk cek kecocokan). */
const EXT_EXPECT: Record<string, { mimes: string[]; label: string }> = {
  jpg: { mimes: ["image/jpeg"], label: "JPEG" },
  jpeg: { mimes: ["image/jpeg"], label: "JPEG" },
  png: { mimes: ["image/png"], label: "PNG" },
  webp: { mimes: ["image/webp"], label: "WebP" },
  gif: { mimes: ["image/gif"], label: "GIF" },
  bmp: { mimes: ["image/bmp"], label: "BMP" },
  svg: { mimes: ["image/svg+xml"], label: "SVG (teks)" },
  heic: { mimes: ["image/heic"], label: "HEIC" },
  mp3: { mimes: ["audio/mpeg"], label: "MP3" },
  wav: { mimes: ["audio/wav", "audio/x-wav"], label: "WAV" },
  ogg: { mimes: ["audio/ogg", "application/ogg"], label: "OGG" },
  m4a: { mimes: ["video/mp4"], label: "M4A (MP4 container)" },
  flac: { mimes: ["audio/flac"], label: "FLAC" },
  mp4: { mimes: ["video/mp4"], label: "MP4" },
  mov: { mimes: ["video/quicktime"], label: "MOV (QuickTime)" },
  webm: { mimes: ["video/webm"], label: "WebM" },
  mkv: { mimes: ["video/webm", "video/x-matroska"], label: "MKV" },
  avi: { mimes: ["video/avi", "video/x-msvideo"], label: "AVI" },
  zip: { mimes: ["application/zip"], label: "ZIP" },
  rar: { mimes: ["application/x-rar"], label: "RAR" },
  "7z": { mimes: ["application/x-7z"], label: "7z" },
  gz: { mimes: ["application/gzip"], label: "GZIP" },
  tar: { mimes: ["application/x-tar"], label: "TAR" },
  pdf: { mimes: ["application/pdf"], label: "PDF" },
  doc: { mimes: ["application/vnd.ms-office", "application/msword"], label: "DOC" },
  xls: { mimes: ["application/vnd.ms-office", "application/vnd.ms-excel"], label: "XLS" },
  ppt: { mimes: ["application/vnd.ms-office", "application/vnd.ms-powerpoint"], label: "PPT" },
  docx: { mimes: ["application/zip", "application/vnd.ms-office"], label: "DOCX (zip)" },
  xlsx: { mimes: ["application/zip", "application/vnd.ms-office"], label: "XLSX (zip)" },
  pptx: { mimes: ["application/zip", "application/vnd.ms-office"], label: "PPTX (zip)" },
  txt: { mimes: ["text/plain"], label: "Teks" },
  md: { mimes: ["text/plain"], label: "Markdown" },
  json: { mimes: ["text/plain"], label: "JSON" },
  js: { mimes: ["text/plain"], label: "JavaScript" },
  ts: { mimes: ["text/plain"], label: "TypeScript" },
  html: { mimes: ["text/plain"], label: "HTML" },
  css: { mimes: ["text/plain"], label: "CSS" },
  apk: { mimes: ["application/zip"], label: "APK (zip)" },
  jar: { mimes: ["application/zip"], label: "JAR (zip)" },
  exe: { mimes: ["application/x-msdownload"], label: "EXE" },
  dll: { mimes: ["application/x-msdownload"], label: "DLL" },
  so: { mimes: ["application/x-elf"], label: "ELF shared object" },
  ipa: { mimes: ["application/zip"], label: "IPA (zip)" },
};

async function sha256Hex(buf: ArrayBuffer): Promise<string> {
  const d = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function sha1Hex(buf: ArrayBuffer): Promise<string> {
  const d = await crypto.subtle.digest("SHA-1", buf);
  return Array.from(new Uint8Array(d)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function md5Like(buf: ArrayBuffer): Promise<string> {
  // MD5 tidak tersedia di crypto.subtle — gunakan SHA-1 sebagai sidik jari
  // sekunder (diberi label jelas, bukan dipalsukan sebagai MD5).
  return sha1Hex(buf);
}

function detectMime(head: Uint8Array): { mime: string; label: string } | null {
  for (const t of MAGIC_TABLE) {
    const off = t.offset || 0;
    if (off + t.sig.length > head.length) continue;
    let ok = true;
    for (let i = 0; i < t.sig.length; i++) {
      if (head[off + i] !== t.sig[i]) { ok = false; break; }
    }
    if (ok) return { mime: t.mime, label: t.label };
  }
  // cek teks (UTF-8/ASCII printable)
  let printable = 0;
  const n = Math.min(head.length, 512);
  for (let i = 0; i < n; i++) {
    const c = head[i];
    if (c === 9 || c === 10 || c === 13 || (c >= 32 && c < 127)) printable++;
  }
  if (n > 0 && printable / n > 0.95) return { mime: "text/plain", label: "Teks" };
  return null;
}

/** Ekstensi yang umum dipakai sosial-engineering / payload. */
const RISKY_EXT = new Set(["exe", "scr", "bat", "cmd", "com", "pif", "vbs", "vbe", "js", "jse", "wsf", "wsh", "ps1", "hta", "jar", "lnk", "apk", "dll", "msi"]);
const DOUBLE_EXT = /\.(zip|rar|7z|pdf|doc|docx|jpg|jpeg|png|txt)\.(exe|scr|bat|cmd|js|vbs|ps1|jar|apk)$/i;

export interface ScanOptions {
  /** inspeksi isi arsip zip (daftar entry + deteksi zip-bomb ratio) */
  inspectZip?: boolean;
}

/** Pindai SATU file — semuanya lokal di browser, file tidak pernah dikirim. */
export async function scanFile(file: File, opts: ScanOptions = {}): Promise<FileScanResult> {
  const t0 = performance.now();
  const ext = extOf(file.name);
  const size = file.size;
  const signals: FileScanResult["signals"] = [];
  let risk = 0;

  const head = new Uint8Array(await file.slice(0, 4096).arrayBuffer());
  const detected = detectMime(head);
  const sha256 = await sha256Hex(await file.arrayBuffer());

  const mimeDetected = detected?.mime || "application/octet-stream";
  const mimeLabel = detected?.label || "Data biner tidak dikenal";

  // ==== sinyal 1: ekstensi vs isi ====
  const expect = EXT_EXPECT[ext];
  if (expect) {
    const match = expect.mimes.includes(mimeDetected) || (mimeDetected === "text/plain" && ["txt", "md", "json", "js", "ts", "html", "css", "svg"].includes(ext));
    if (match) {
      signals.push({ label: "Kecocokan tipe", detail: `Ekstensi .${ext} sesuai isi terdeteksi (${mimeLabel})`, level: "info" });
    } else {
      risk += 45;
      signals.push({ label: "Ekstensi TIDAK cocok dengan isi", detail: `File berlabel .${ext} (seharusnya ${expect.label}) tetapi isi terdeteksi sebagai ${mimeLabel} — tanda penyamaran tipe file`, level: "warn" });
    }
  }

  // ==== sinyal 2: ekstensi berisiko ====
  if (RISKY_EXT.has(ext)) {
    risk += 20;
    signals.push({ label: "Ekstensi eksekusi/berisiko", detail: `Ekstensi .${ext} dapat mengeksekusi kode di perangkat — pastikan sumbernya terpercaya sebelum dibuka`, level: "warn" });
  }
  if (DOUBLE_EXT.test(file.name)) {
    risk += 35;
    signals.push({ label: "Ekstensi ganda mencurigakan", detail: `Pola "nama.seemingly-safe.ext" klasik penyamaran (mis. foto.jpg.exe) — sangat umum pada malware dropper`, level: "danger" });
  }

  // ==== sinyal 3: executable yang menyamar ====
  if (detected?.mime === "application/x-msdownload" && !["exe", "dll", "msi", "com"].includes(ext)) {
    risk += 55;
    signals.push({ label: "Executable Windows tersembunyi", detail: "Isi file adalah executable MZ tetapi ekstensi bukan EXE — kemungkinan besar payload yang menyamar", level: "danger" });
  }
  if (detected?.mime === "application/vnd.android.dex" && ext !== "apk" && ext !== "dex") {
    risk += 40;
    signals.push({ label: "Bytecode Android DEX tersembunyi", detail: "Isi berisi DEX di luar paket APK biasa", level: "warn" });
  }

  // ==== sinyal 4: file sangat kecil berbahaya ====
  if (size < 512 && RISKY_EXT.has(ext)) {
    risk += 15;
    signals.push({ label: "File eksekusi sangat kecil", detail: `Eksekusi sekecil ${size} B sering berupa loader/stager`, level: "warn" });
  }

  // ==== inspeksi arsip (zip/apk/jar) ====
  if ((opts.inspectZip !== false) && (mimeDetected === "application/zip" || ["zip", "apk", "jar", "ipa", "docx", "xlsx", "pptx"].includes(ext))) {
    try {
      const { unzipSync, strFromU8 } = await import("fflate");
      const buf = new Uint8Array(await file.arrayBuffer());
      // batas aman dekompresi: 200MB total unpack
      const files = unzipSync(buf, {
        filter: (f) => {
          if ((f.originalSize || 0) > 60 * 1024 * 1024) {
            signals.push({ label: "Entry arsip sangat besar", detail: `"${f.name}" ter-unpack ${(f.originalSize! / 1048576).toFixed(1)} MB — hati-hati decompression bomb`, level: "warn" });
            risk += 15;
            return false;
          }
          return true;
        },
      });
      const names = Object.keys(files);
      if (names.length > 3000) {
        risk += 20;
        signals.push({ label: "Entry arsip berjumlah besar", detail: `${names.length} entri — pola archive bomb / fuzzing`, level: "warn" });
      }
      // path traversal (zip-slip) di nama entry
      const slip = names.some((nm) => nm.includes("..") || nm.startsWith("/") || /^[a-z]:/i.test(nm));
      if (slip) {
        risk += 50;
        signals.push({ label: "Path traversal dalam arsip", detail: "Ada nama entry berisi '../' atau path absolut — pola zip-slip yang menulis di luar folder tujuan saat diekstrak", level: "danger" });
      }
      // APK structure
      if (ext === "apk" || APK_ZIP_HINTS.every((h) => names.some((nm) => nm.startsWith(h)))) {
        const hasManifest = names.includes("AndroidManifest.xml");
        const dexCount = names.filter((nm) => /^classes\d*\.dex$/.test(nm)).length;
        const hasSig = names.some((nm) => nm.startsWith("META-INF/") && /\.(RSA|DSA|EC|SF)$/i.test(nm));
        signals.push({ label: "Struktur Android (APK)", detail: `Manifest: ${hasManifest ? "ada" : "TIDAK ADA"}, DEX: ${dexCount}, tanda tangan v1: ${hasSig ? "ada" : "tidak ada"}`, level: "info" });
        if (!hasManifest) {
          risk += 30;
          signals.push({ label: "APK tanpa AndroidManifest", detail: "Paket Android tidak valid / dibuat tidak wajar", level: "warn" });
        }
        // ELF native libs
        const nativeLibs = names.filter((nm) => nm.startsWith("lib/") && nm.endsWith(".so"));
        if (nativeLibs.length) {
          signals.push({ label: "Library native", detail: `${nativeLibs.length} .so (${[...new Set(nativeLibs.map((l) => l.split("/")[1]))].join(", ")})`, level: "info" });
        }
      }
      // teks berbahaya di entry kecil (indikator skrip dropper) — hanya utk archive non-office
      if (["zip", "rar", "7z", "gz"].includes(ext)) {
        let scriptHits = 0;
        for (const nm of names) {
          if (/\.(vbs|ps1|bat|cmd|js|hta|scr)$/i.test(nm)) scriptHits++;
        }
        if (scriptHits > 0) {
          risk += 25 * Math.min(2, scriptHits);
          signals.push({ label: "Skrip di dalam arsip", detail: `${scriptHits} file skrip (.vbs/.ps1/.bat/.js/.hta) — pola dropper umum`, level: "warn" });
        }
      }
    } catch (e) {
      signals.push({ label: "Arsip tidak bisa dibaca", detail: "Struktur arsip rusak atau format tidak didukung penuh", level: "info" });
    }
  }

  // ==== status akhir (JUJUR — tanpa klaim virus) ====
  const riskScore = Math.min(100, risk);
  let status: FileScanResult["status"];
  let statusLabel: string;
  if (signals.some((s) => s.level === "danger") || riskScore >= 60) {
    status = "SUSPICIOUS";
    statusLabel = "Mencurigakan (heuristik)";
  } else if (riskScore >= 25) {
    status = "SUSPICIOUS";
    statusLabel = "Terdapat indikator untuk ditinjau (heuristik)";
  } else {
    status = "HEURISTIC_ONLY";
    statusLabel = "Tidak ada indikator mencurigakan — analisis heuristik lokal (bukan verdict engine antivirus)";
  }
  const recommendation: FileScanResult["recommendation"] =
    riskScore >= 60 ? "REMOVE_RECOMMENDED" : riskScore >= 25 ? "REVIEW" : "KEEP";

  signals.push({
    label: "Batas analisis",
    detail: "Hasil ini dari analisis statis lokal (hash + struktur). Verdict malware pasti memerlukan reputation engine (belum terkonfigurasi). Tidak ada file yang dikirim keluar.",
    level: "info",
  });

  return {
    name: file.name.slice(0, 120),
    size,
    ext,
    mimeDetected,
    mimeLabel,
    sha256,
    status,
    statusLabel,
    signals,
    riskScore,
    recommendation,
    durationMs: Math.round(performance.now() - t0),
  };
}

/** Hitung semua sidik jari file (SHA-256 + SHA-1) untuk tool Hash/IOC. */
export async function fileFingerprints(buf: ArrayBuffer): Promise<{ sha256: string; sha1: string }> {
  return { sha256: await sha256Hex(buf), sha1: await sha1Hex(buf) };
}
