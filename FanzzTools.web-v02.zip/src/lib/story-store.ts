import type { SessionPayload } from "@/lib/session";
import { ensureProfile, publicProfile, getProfile } from "@/lib/social-store";
import { loadJson, saveJsonDebounced, onDbHydrated } from "@/lib/persist";

/**
 * FanzzStory — fitur status/story ala WhatsApp (V2 Modern-UpdSec).
 *
 * Aturan sesuai permintaan pemilik:
 *  - Status bertahan 22 JAM sejak diunggah, lalu otomatis hilang.
 *  - Maksimal 5 status AKTIF per user.
 *  - Bisa berupa TEKS (latar gradasi), VIDEO + caption, atau
 *    FOTO + musik latar (PERBARUAN #4: durasi tampil TETAP 14 detik —
 *    musik otomatis dipotong 14 detik; musik opsional).
 *  - Terkirim GLOBAL — otomatis terlihat semua user FanzzTools.
 *  - Bisa di-LIKE dan di-KOMENTARI user lain.
 *  - Pemilik status bisa melihat SIAPA SAJA yang menonton.
 *  - Ada daftar mengikuti/pengikut (dari social-store).
 *
 * PERSISTENSI (PERBAIKAN #3): story kini bertahan cold-start lewat
 * data/story.json — tidak lagi hilang saat server idle/restart.
 */

export interface StoryComment {
  uid: string;
  username: string;
  text: string;
  ts: number;
}

export interface FanzzStory {
  id: string;
  uid: string;
  username: string;
  avatarColor: string;
  avatar?: string | null;
  type: "text" | "video" | "photo";
  /** teks status (mode teks) atau caption di bawah video/foto */
  text: string;
  /** index preset gradasi latar (mode teks) */
  bg: number;
  /** data URL: video (mode video) atau foto (mode foto) */
  data?: string;
  /** PERBARUAN #4: musik latar (mode foto, opsional) — dipotong 14 dtk saat diputar.
   *  PERMINTAAN #3: boleh data URL (upload user, sudah dipotong 14 dtk di klien)
   *  ATAU path proxy library musik situs (/api/stream/proxy?...) — lagu dari sc situs. */
  music?: string;
  /** PERMINTAAN #3: videoId lagu library — dipakai klien menyegarkan URL kedaluwarsa */
  musicVideo?: string;
  createdAt: number;
  expiresAt: number;
  likes: string[];
  viewers: string[];
  comments: StoryComment[];
}

const g = globalThis as unknown as {
  __fanzzStories?: Map<string, FanzzStory>;
  __fanzzStorySweep?: ReturnType<typeof setInterval> | null;
};

if (!g.__fanzzStories) {
  g.__fanzzStories = new Map();
  /* ===== PERBAIKAN #3: pulihkan story tersimpan (yang belum kedaluwarsa) ===== */
  const restoreStories = () => {
    const S2 = g.__fanzzStories;
    if (!S2) return;
    const saved = loadJson<{ stories?: FanzzStory[] }>("story");
    if (saved?.stories) {
      const now = Date.now();
      for (const st of saved.stories) {
        if (st?.id && st.expiresAt > now) S2.set(st.id, st);
      }
    }
  };
  restoreStories();
  /* FanzSec-Update: pulihkan dari DATABASE saat instance baru mulai. */
  onDbHydrated((keys) => {
    const st = g.__fanzzStories;
    if (st && keys.includes("story") && st.size === 0) restoreStories();
  });
}
if (!g.__fanzzStorySweep) {
  // sapu status kedaluwarsa tiap 2 menit (22 jam lewat = hilang otomatis)
  g.__fanzzStorySweep = setInterval(() => {
    const now = Date.now();
    for (const [id, s] of g.__fanzzStories!) {
      if (now > s.expiresAt) g.__fanzzStories!.delete(id);
    }
  }, 2 * 60 * 1000);
  (g.__fanzzStorySweep as unknown as { unref?: () => void }).unref?.();
}

const S = g.__fanzzStories;

export const STORY_TTL_MS = 22 * 60 * 60 * 1000; // 22 jam
export const STORY_MAX_PER_USER = 5;
export const STORY_MAX_TEXT = 700;
export const STORY_MAX_VIDEO_BYTES = 12 * 1024 * 1024; // 12 MB (data URL)
/** PERBARUAN #4: foto + musik — durasi tampil FOTO ditetapkan 14 detik (musik dipotong 14 dtk). */
export const STORY_PHOTO_MS = 14 * 1000;
export const STORY_MAX_PHOTO_BYTES = 10 * 1024 * 1024; // 10 MB (data URL foto)
export const STORY_MAX_MUSIC_BYTES = 8 * 1024 * 1024; // 8 MB (data URL musik)
export const STORY_MAX_TOTAL = 2000;

/* ===== PERBAIKAN #3: simpan snapshot story (debounce) — cap 20 MB ===== */
function persistStories() {
  saveJsonDebounced("story", () => {
    let stories = [...S.values()].sort((a, b) => b.createdAt - a.createdAt);
    let json = JSON.stringify({ stories });
    while (json.length > 20 * 1024 * 1024 && stories.length > 200) {
      stories = stories.slice(0, Math.floor(stories.length * 0.8));
      json = JSON.stringify({ stories });
    }
    return json;
  });
}

function sweepExpired() {
  const now = Date.now();
  for (const [id, s] of S) {
    if (now > s.expiresAt) S.delete(id);
  }
}

export interface CreateStoryInput {
  type: "text" | "video" | "photo";
  text: string;
  bg: number;
  data?: string;
  /** musik latar (mode foto) — data URL atau path proxy library musik */
  music?: string;
  /** videoId lagu library (opsional, untuk penyegaran URL) */
  musicVideo?: string;
}

export function createStory(
  session: SessionPayload,
  input: CreateStoryInput
): { ok: true; story: FanzzStory } | { ok: false; error: string } {
  const p = ensureProfile(session);
  sweepExpired();

  const mine = [...S.values()].filter((s) => s.uid === session.uid && Date.now() <= s.expiresAt);
  if (mine.length >= STORY_MAX_PER_USER) {
    return { ok: false, error: `Maksimal ${STORY_MAX_PER_USER} status aktif. Hapus salah satu dulu, atau tunggu status lama habis masa 22 jamnya.` };
  }

  const text = (input.text || "").slice(0, STORY_MAX_TEXT);
  if (input.type === "text" && !text.trim()) {
    return { ok: false, error: "Status teks tidak boleh kosong." };
  }
  if (input.type === "video") {
    if (!input.data || !/^data:video\/(mp4|webm|quicktime);base64,/.test(input.data.slice(0, 40))) {
      return { ok: false, error: "Video tidak valid (MP4/WebM saja)." };
    }
    if (input.data.length > STORY_MAX_VIDEO_BYTES) {
      return { ok: false, error: "Video terlalu besar — maksimal ±8 MB setelah dikompres." };
    }
  }
  if (input.type === "photo") {
    // PERBARUAN #4: foto + musik opsional; durasi tampil tetap 14 detik
    if (!input.data || !/^data:image\/(png|jpe?g|webp);base64,/.test(input.data.slice(0, 40))) {
      return { ok: false, error: "Foto tidak valid (PNG/JPG/WebP saja)." };
    }
    if (input.data.length > STORY_MAX_PHOTO_BYTES) {
      return { ok: false, error: "Foto terlalu besar — maksimal ±7 MB. Kompress dulu ya." };
    }
    if (input.music) {
      const m = input.music;
      /* PERMINTAAN #3: dua bentuk musik yang diterima —
       *  (a) data URL audio (upload user — idealnya sudah dipotong 14 dtk di klien)
       *  (b) path proxy library musik situs: /api/stream/proxy?url=... (lagu dari sc situs) */
      const dataUrlOk = /^data:audio\/(mpeg|mp3|mp4|aac|ogg|wav|webm);base64,/.test(m.slice(0, 40));
      const proxyOk = m.startsWith("/api/stream/proxy?url=") && m.length <= 2000 && !/["'\s]/.test(m);
      if (!dataUrlOk && !proxyOk) {
        return { ok: false, error: "Musik tidak valid (MP3/AAC/OGG/WAV atau lagu dari library musik FanzzTools)." };
      }
      if (dataUrlOk && m.length > STORY_MAX_MUSIC_BYTES) {
        return { ok: false, error: "File musik terlalu besar — maksimal ±6 MB." };
      }
    }
  }

  // jaga total memori
  if (S.size > STORY_MAX_TOTAL) {
    const oldest = [...S.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
    if (oldest) S.delete(oldest.id);
  }

  const story: FanzzStory = {
    id: `st${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    uid: session.uid,
    username: p.username,
    avatarColor: p.avatarColor,
    avatar: p.avatar || null,
    type: input.type,
    text,
    bg: Math.max(0, Math.min(9, Number(input.bg) || 0)),
    data: input.type === "video" || input.type === "photo" ? input.data : undefined,
    music: input.type === "photo" ? input.music : undefined,
    musicVideo: input.type === "photo" && /^[a-zA-Z0-9_-]{11}$/.test(input.musicVideo || "") ? input.musicVideo : undefined,
    createdAt: Date.now(),
    expiresAt: Date.now() + STORY_TTL_MS,
    likes: [],
    viewers: [],
    comments: [],
  };
  S.set(story.id, story);
  persistStories();
  return { ok: true, story };
}

/** Story publik — data video/foto/musik HANYA disertakan saat ditonton (hemat bandwidth). */
function publicStory(s: FanzzStory, viewerUid: string, includeData = false) {
  return {
    id: s.id,
    uid: s.uid,
    username: s.username,
    avatarColor: s.avatarColor,
    avatar: s.avatar,
    type: s.type,
    text: s.text,
    bg: s.bg,
    hasVideo: s.type === "video",
    hasPhoto: s.type === "photo",
    /** durasi tampil foto+musik — 14 detik tetap (PERBARUAN #4) */
    photoDuration: s.type === "photo" ? STORY_PHOTO_MS : undefined,
    hasMusic: s.type === "photo" && !!s.music,
    createdAt: s.createdAt,
    expiresAt: s.expiresAt,
    likes: s.likes.length,
    likedByMe: s.likes.includes(viewerUid),
    viewers: s.uid === viewerUid ? s.viewers.length : undefined,
    viewersList: s.uid === viewerUid
      ? s.viewers.slice(0, 100).map((uid) => {
          const p = publicProfileOf(uid);
          return p ? { uid, username: p.username, avatar: p.avatar, avatarColor: p.avatarColor } : { uid, username: "user", avatar: null, avatarColor: "" };
        })
      : undefined,
    comments: s.comments.slice(-50),
    canDelete: s.uid === viewerUid,
    /** data media hanya untuk pemutaran tunggal (video/foto + musik) */
    data: includeData && (s.type === "video" || s.type === "photo") ? s.data : undefined,
    music: includeData && s.type === "photo" ? s.music : undefined,
    musicVideo: includeData && s.type === "photo" ? s.musicVideo : undefined,
  };
}

function publicProfileOf(uid: string) {
  const p = getProfile(uid);
  return p ? publicProfile(p) : null;
}

export interface StoryGroup {
  uid: string;
  username: string;
  avatar: string | null;
  avatarColor: string;
  fanzzId?: string;
  isMe: boolean;
  stories: ReturnType<typeof publicStory>[];
}

/** Daftar semua story aktif — dikelompokkan per user (milikku paling atas). */
export function listStories(viewerUid: string): StoryGroup[] {
  sweepExpired();
  const groups = new Map<string, FanzzStory[]>();
  for (const s of S.values()) {
    if (Date.now() > s.expiresAt) continue;
    const arr = groups.get(s.uid) || [];
    arr.push(s);
    groups.set(s.uid, arr);
  }
  const out: StoryGroup[] = [];
  for (const [uid, stories] of groups) {
    stories.sort((a, b) => a.createdAt - b.createdAt);
    const first = stories[0];
    const prof = publicProfileOf(uid);
    out.push({
      uid,
      username: first.username,
      avatar: first.avatar || prof?.avatar || null,
      avatarColor: first.avatarColor,
      fanzzId: prof?.fanzzId,
      isMe: uid === viewerUid,
      stories: stories.map((s) => publicStory(s, viewerUid)),
    });
  }
  // story-ku paling atas, sisanya urut terbaru
  out.sort((a, b) => {
    if (a.isMe !== b.isMe) return a.isMe ? -1 : 1;
    const la = a.stories[a.stories.length - 1]?.createdAt || 0;
    const lb = b.stories[b.stories.length - 1]?.createdAt || 0;
    return lb - la;
  });
  return out;
}

export function getStory(id: string): FanzzStory | undefined {
  const s = S.get(id);
  if (!s || Date.now() > s.expiresAt) return undefined;
  return s;
}

/** Satu story lengkap (dengan data video) untuk ditonton. */
export function storyView(id: string, viewerUid: string) {
  const s = getStory(id);
  if (!s) return null;
  return publicStory(s, viewerUid, true);
}

export function viewStory(viewerUid: string, id: string): boolean {
  const s = getStory(id);
  if (!s) return false;
  if (s.uid !== viewerUid && !s.viewers.includes(viewerUid)) {
    s.viewers.push(viewerUid);
    persistStories();
  }
  return true;
}

export function likeStory(viewerUid: string, id: string): { liked: boolean } | null {
  const s = getStory(id);
  if (!s) return null;
  const idx = s.likes.indexOf(viewerUid);
  if (idx >= 0) {
    s.likes.splice(idx, 1);
    persistStories();
    return { liked: false };
  }
  s.likes.push(viewerUid);
  persistStories();
  return { liked: true };
}

export function commentStory(
  session: SessionPayload,
  id: string,
  text: string
): StoryComment | null {
  const s = getStory(id);
  if (!s) return null;
  const clean = text.replace(/\s+/g, " ").trim().slice(0, 240);
  if (!clean) return null;
  const c: StoryComment = {
    uid: session.uid,
    username: session.username,
    text: clean,
    ts: Date.now(),
  };
  s.comments.push(c);
  if (s.comments.length > 200) s.comments.splice(0, s.comments.length - 200);
  persistStories();
  return c;
}

export function deleteStory(uid: string, id: string): boolean {
  const s = getStory(id);
  if (!s || s.uid !== uid) return false;
  S.delete(id);
  persistStories();
  return true;
}

/** Status milik user sendiri (untuk halaman kelola). */
export function myStories(uid: string): FanzzStory[] {
  sweepExpired();
  return [...S.values()]
    .filter((s) => s.uid === uid && Date.now() <= s.expiresAt)
    .sort((a, b) => a.createdAt - b.createdAt);
}
