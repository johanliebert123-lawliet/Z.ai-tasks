"use client";

/**
 * Renderer markdown ringan & aman untuk bubble chat AI.
 * Tanpa dangerouslySetInnerHTML — semua jadi elemen React.
 * Support: heading, bold, italic, strike, inline code, code block
 * (+ tombol copy), list, blockquote, link, hr, tabel sederhana.
 */

import { useState } from "react";
import { Check, Copy } from "lucide-react";

/* ---------- inline parsing ---------- */

interface InlineSeg {
  t: "text" | "bold" | "italic" | "strike" | "code" | "link";
  v: string;
  href?: string;
}

function parseInline(src: string): InlineSeg[] {
  const segs: InlineSeg[] = [];
  // urutan prioritas: code → bold → italic → strike → link
  const re =
    /(`[^`\n]+`)|(\*\*[^*\n][\s\S]*?\*\*)|(__[^_\n]+__)|(\*[^*\n]+\*)|(~~[^~\n]+~~)|(\[[^\]\n]+\]\([^)\s]+\))/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) {
    if (m.index > last) segs.push({ t: "text", v: src.slice(last, m.index) });
    const tok = m[0];
    if (tok.startsWith("`")) {
      segs.push({ t: "code", v: tok.slice(1, -1) });
    } else if (tok.startsWith("**")) {
      segs.push({ t: "bold", v: tok.slice(2, -2) });
    } else if (tok.startsWith("__")) {
      segs.push({ t: "bold", v: tok.slice(2, -2) });
    } else if (tok.startsWith("~~")) {
      segs.push({ t: "strike", v: tok.slice(2, -2) });
    } else if (tok.startsWith("*")) {
      segs.push({ t: "italic", v: tok.slice(1, -1) });
    } else if (tok.startsWith("[")) {
      const mm = tok.match(/^\[([^\]]+)\]\(([^)\s]+)\)$/);
      if (mm) segs.push({ t: "link", v: mm[1], href: mm[2] });
      else segs.push({ t: "text", v: tok });
    }
    last = m.index + tok.length;
  }
  if (last < src.length) segs.push({ t: "text", v: src.slice(last) });
  return segs;
}

function Inline({ segs }: { segs: InlineSeg[] }) {
  return (
    <>
      {segs.map((s, i) => {
        switch (s.t) {
          case "bold":
            return <b key={i} className="font-extrabold">{s.v}</b>;
          case "italic":
            return <i key={i}>{s.v}</i>;
          case "strike":
            return <s key={i} className="opacity-60">{s.v}</s>;
          case "code":
            return (
              <code key={i} className="rounded-md bg-black/20 px-1.5 py-0.5 font-mono text-[0.85em] text-red-300">
                {s.v}
              </code>
            );
          case "link":
            return (
              <a
                key={i}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer nofollow"
                className="font-semibold text-cyan-400 underline decoration-cyan-400/40 underline-offset-2 hover:decoration-cyan-400"
              >
                {s.v}
              </a>
            );
          default:
            return <span key={i}>{s.v}</span>;
        }
      })}
    </>
  );
}

/* ---------- code block dengan tombol copy ---------- */

function CodeBlock({ code, lang }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      /* ignore */
    }
  };
  return (
    <div className="relative my-2 overflow-hidden rounded-xl border border-white/10 bg-black/40">
      <div className="flex items-center justify-between border-b border-white/10 px-3 py-1.5">
        <span className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">
          {lang || "code"}
        </span>
        <button
          onClick={copy}
          className="flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground transition-colors hover:bg-white/10 hover:text-foreground"
        >
          {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
          {copied ? "Tersalin!" : "Salin"}
        </button>
      </div>
      <pre className="overflow-x-auto p-3 text-[11.5px] leading-relaxed">
        <code className="font-mono text-emerald-200">{code}</code>
      </pre>
    </div>
  );
}

/* ---------- block parser ---------- */

type Block =
  | { t: "p"; segs: InlineSeg[] }
  | { t: "h"; level: number; segs: InlineSeg[] }
  | { t: "code"; code: string; lang?: string }
  | { t: "ul" | "ol"; items: InlineSeg[][] }
  | { t: "quote"; segs: InlineSeg[] }
  | { t: "hr" }
  | { t: "table"; head: InlineSeg[][]; rows: InlineSeg[][][] };

function parseBlocks(md: string): Block[] {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  const blocks: Block[] = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    // kosong
    if (!line.trim()) {
      i++;
      continue;
    }

    // code fence
    if (line.trim().startsWith("```")) {
      const lang = line.trim().slice(3).trim() || undefined;
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].trim().startsWith("```")) {
        buf.push(lines[i]);
        i++;
      }
      i++; // skip closing fence
      blocks.push({ t: "code", code: buf.join("\n"), lang });
      continue;
    }

    // heading
    const hm = line.match(/^(#{1,6})\s+(.*)$/);
    if (hm) {
      blocks.push({ t: "h", level: hm[1].length, segs: parseInline(hm[2]) });
      i++;
      continue;
    }

    // hr
    if (/^(\*{3,}|-{3,}|_{3,})\s*$/.test(line.trim())) {
      blocks.push({ t: "hr" });
      i++;
      continue;
    }

    // blockquote
    if (line.trim().startsWith(">")) {
      const buf: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith(">")) {
        buf.push(lines[i].replace(/^\s*>\s?/, ""));
        i++;
      }
      blocks.push({ t: "quote", segs: parseInline(buf.join(" ")) });
      continue;
    }

    // table
    if (
      i + 1 < lines.length &&
      line.includes("|") &&
      /^\s*\|?[\s:|-]+\|[\s:|-]*$/.test(lines[i + 1])
    ) {
      const splitRow = (r: string) =>
        r.replace(/^\s*\|/, "").replace(/\|\s*$/, "").split("|").map((c) => c.trim());
      const head = splitRow(line).map(parseInline);
      i += 2;
      const rows: InlineSeg[][][] = [];
      while (i < lines.length && lines[i].includes("|") && lines[i].trim()) {
        rows.push(splitRow(lines[i]).map(parseInline));
        i++;
      }
      blocks.push({ t: "table", head, rows });
      continue;
    }

    // list
    const isUl = (l: string) => /^\s*[-*+]\s+/.test(l);
    const isOl = (l: string) => /^\s*\d+[.)]\s+/.test(l);
    if (isUl(line) || isOl(line)) {
      const ordered = isOl(line);
      const items: InlineSeg[][] = [];
      while (i < lines.length && (ordered ? isOl(lines[i]) : isUl(lines[i]))) {
        const c = lines[i].replace(/^\s*(?:[-*+]|\d+[.)])\s+/, "");
        items.push(parseInline(c));
        i++;
      }
      blocks.push({ t: ordered ? "ol" : "ul", items });
      continue;
    }

    // paragraf
    const buf: string[] = [];
    while (
      i < lines.length &&
      lines[i].trim() &&
      !lines[i].trim().startsWith("```") &&
      !/^(#{1,6})\s+/.test(lines[i]) &&
      !isUl(lines[i]) &&
      !isOl(lines[i]) &&
      !lines[i].trim().startsWith(">") &&
      !/^(\*{3,}|-{3,}|_{3,})\s*$/.test(lines[i].trim())
    ) {
      buf.push(lines[i]);
      i++;
    }
    blocks.push({ t: "p", segs: parseInline(buf.join("\n")) });
  }
  return blocks;
}

/* ---------- komponen utama ---------- */

export default function Markdown({ text }: { text: string }) {
  const blocks = parseBlocks(text);
  return (
    <div className="md-body">
      {blocks.map((b, i) => {
        switch (b.t) {
          case "h": {
            const sizes = ["text-base", "text-[15px]", "text-sm", "text-sm", "text-xs", "text-xs"];
            return (
              <p key={i} className={`mt-2 mb-1 font-extrabold first:mt-0 ${sizes[Math.min(b.level - 1, 5)]}`}>
                <Inline segs={b.segs} />
              </p>
            );
          }
          case "code":
            return <CodeBlock key={i} code={b.code} lang={b.lang} />;
          case "hr":
            return <hr key={i} className="my-2.5 border-white/10" />;
          case "quote":
            return (
              <blockquote key={i} className="my-2 border-l-2 border-red-400/60 pl-3 text-[13px] italic opacity-90">
                <Inline segs={b.segs} />
              </blockquote>
            );
          case "ul":
            return (
              <ul key={i} className="my-1.5 space-y-1 pl-1">
                {b.items.map((it, j) => (
                  <li key={j} className="flex gap-2">
                    <span className="mt-[3px] h-1.5 w-1.5 shrink-0 rounded-full bg-red-400/80" />
                    <span className="min-w-0 flex-1"><Inline segs={it} /></span>
                  </li>
                ))}
              </ul>
            );
          case "ol":
            return (
              <ol key={i} className="my-1.5 space-y-1 pl-1">
                {b.items.map((it, j) => (
                  <li key={j} className="flex gap-2">
                    <span className="min-w-4 shrink-0 text-[11px] font-extrabold text-red-400">{j + 1}.</span>
                    <span className="min-w-0 flex-1"><Inline segs={it} /></span>
                  </li>
                ))}
              </ol>
            );
          case "table":
            return (
              <div key={i} className="my-2 overflow-x-auto rounded-xl border border-white/10">
                <table className="w-full text-left text-[11.5px]">
                  <thead className="bg-white/5">
                    <tr>
                      {b.head.map((c, j) => (
                        <th key={j} className="px-2.5 py-1.5 font-extrabold"><Inline segs={c} /></th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {b.rows.map((r, j) => (
                      <tr key={j} className="border-t border-white/5">
                        {r.map((c, k) => (
                          <td key={k} className="px-2.5 py-1.5"><Inline segs={c} /></td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );
          default:
            return (
              <p key={i} className="whitespace-pre-wrap break-words">
                <Inline segs={b.segs} />
              </p>
            );
        }
      })}
    </div>
  );
}
