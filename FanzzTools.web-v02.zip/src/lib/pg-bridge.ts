import { Pool } from "pg";

/**
 * FanzSec-Update — PG-BRIDGE (Neon PostgreSQL / PostgreSQL biasa).
 *
 * Lapisan persistensi DATABASE yang OPSIONAL tapi direkomendasikan untuk
 * production: ketika DATABASE_URL di-set, snapshot JSON seluruh store
 * (social, story, pm, auth) ikut ditulis ke tabel `app_kv` sehingga data
 * TIDAK hilang saat instance serverless cold-start / redeploy (akar masalah
 * "foto profil & story hilang setelah refresh").
 *
 * Perilaku (jujur, TANPA fallback diam-diam):
 *  - DATABASE_URL TIDAK di-set → mode "file" seperti biasa (dev lokal).
 *  - DATABASE_URL di-set + DB sehat → mode "database": load boot + write-through.
 *  - DATABASE_URL di-set + DB GAGAL:
 *      • tulis: kegagalan dicatat (lastError) & dibocorkan lewat pgStatus()
 *        untuk /api/pm/health — TIDAK dianggap sukses diam-diam
 *      • baca boot: store tetap jalan dari memori/file warm, status
 *        databaseReady=false terlihat jelas di health
 *      • route sensitif PM memakai fail-closed (503 DATABASE_UNAVAILABLE)
 *
 * Tabel dibuat idempotent (CREATE TABLE IF NOT EXISTS) — aman dijalankan
 * berulang. Menggunakan pg Pool dengan connection kecil (max 3) karena
 * berjalan di serverless.
 */

const g = globalThis as {
  __fanzzPgPool?: Pool;
  __fanzzPgState?: {
    configured: boolean;
    ready: boolean;
    lastError: string | null;
    lastWriteOk: number;
    lastReadOk: number;
    initTried: boolean;
  };
};

function state() {
  if (!g.__fanzzPgState) {
    g.__fanzzPgState = {
      configured: !!process.env.DATABASE_URL,
      ready: false,
      lastError: null,
      lastWriteOk: 0,
      lastReadOk: 0,
      initTried: false,
    };
  }
  return g.__fanzzPgState;
}

function pool(): Pool | null {
  if (!process.env.DATABASE_URL) return null;
  if (!g.__fanzzPgPool) {
    g.__fanzzPgPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      // serverless: pool kecil + idle timeout agresif
      max: 3,
      idleTimeoutMillis: 10_000,
      connectionTimeoutMillis: 8_000,
      // Neon butuh SSL bila tanpa sslmode di connection string
      ssl: /sslmode=disable/i.test(process.env.DATABASE_URL)
        ? false
        : { rejectUnauthorized: false },
    });
    g.__fanzzPgPool.on("error", () => {
      /* error koneksi idle di-handle per-query */
    });
  }
  return g.__fanzzPgPool;
}

export function pgConfigured(): boolean {
  return state().configured;
}

/** Status untuk health endpoint — TANPA membocorkan DATABASE_URL/secret. */
export function pgStatus(): {
  configured: boolean;
  ready: boolean;
  lastError: string | null;
  lastWriteOk: number;
  lastReadOk: number;
} {
  const s = state();
  return {
    configured: s.configured,
    ready: s.ready,
    lastError: s.lastError,
    lastWriteOk: s.lastWriteOk,
    lastReadOk: s.lastReadOk,
  };
}

/** Buat tabel (idempotent) + tes koneksi. Dipanggil sekali per instance. */
async function ensureTable(): Promise<boolean> {
  const s = state();
  if (!s.configured) return false;
  if (s.initTried) return s.ready;
  s.initTried = true;
  const p = pool();
  if (!p) return false;
  try {
    await p.query(
      `CREATE TABLE IF NOT EXISTS app_kv (
         key TEXT PRIMARY KEY,
         value TEXT NOT NULL,
         updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
       )`
    );
    // index tidak dibutuhkan (PK), tapi pastikan tabel benar-benar bisa ditulis
    await p.query(
      `INSERT INTO app_kv (key, value, updated_at)
       VALUES ('__health', $1, now())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
      [new Date().toISOString()]
    );
    s.ready = true;
    s.lastError = null;
    s.lastReadOk = Date.now();
    s.lastWriteOk = Date.now();
    return true;
  } catch (e) {
    // kegagalan dicatat & dibocorkan lewat pgStatus() — TIDAK diam-diam
    s.ready = false;
    s.lastError = (e instanceof Error && e.message ? e.message : String(e?.constructor?.name || "Koneksi database gagal")).slice(0, 160);
    return false;
  }
}

/** Simpan snapshot JSON satu kunci (write-through, fire-and-forget tapi
 *  kegagalannya tercatat untuk health). */
export async function pgSaveJson(name: string, payload: string): Promise<boolean> {
  const s = state();
  if (!s.configured) return false;
  const p = pool();
  if (!p) return false;
  try {
    await ensureTable();
    await p.query(
      `INSERT INTO app_kv (key, value, updated_at)
       VALUES ($1, $2, now())
       ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
      [name, payload]
    );
    s.lastWriteOk = Date.now();
    s.ready = true;
    return true;
  } catch (e) {
    s.lastError = (e instanceof Error && e.message ? e.message : String(e?.constructor?.name || "Tulis database gagal")).slice(0, 160);
    return false;
  }
}

/** Baca snapshot JSON satu kunci (null bila tidak ada / DB tidak siap). */
export async function pgLoadJson(name: string): Promise<string | null> {
  const s = state();
  if (!s.configured) return null;
  const p = pool();
  if (!p) return null;
  try {
    await ensureTable();
    const r = await p.query<{ value: string }>(
      `SELECT value FROM app_kv WHERE key = $1 LIMIT 1`,
      [name]
    );
    s.lastReadOk = Date.now();
    s.ready = true;
    return r.rows?.[0]?.value ?? null;
  } catch (e) {
    s.lastError = (e instanceof Error && e.message ? e.message : String(e?.constructor?.name || "Baca database gagal")).slice(0, 160);
    return null;
  }
}

/** Cek koneksi sungguhan (SELECT 1 dengan timeout) — dipakai health endpoint.
 *  Inilah yang membuat /api/pm/health melakukan connectivity check NYATA,
 *  bukan sekadar membaca flag. */
export async function pgPing(timeoutMs = 5000): Promise<boolean> {
  const s = state();
  if (!s.configured) return false;
  const p = pool();
  if (!p) return false;
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    await Promise.race([
      (async () => {
        await ensureTable();
        await p.query("SELECT 1");
      })(),
      new Promise((_, rej) => {
        timer = setTimeout(() => rej(new Error("ping timeout")), timeoutMs);
      }),
    ]);
    if (timer) clearTimeout(timer);
    s.ready = true;
    s.lastError = null;
    s.lastReadOk = Date.now();
    return true;
  } catch (e) {
    if (timer) clearTimeout(timer);
    s.ready = false;
    s.lastError = (e instanceof Error && e.message ? e.message : String(e?.constructor?.name || "ping gagal")).slice(0, 160);
    return false;
  }
}

/** Tutup pool (dipakai test / shutdown). */
export async function pgClose() {
  if (g.__fanzzPgPool) {
    await g.__fanzzPgPool.end().catch(() => {});
    g.__fanzzPgPool = undefined;
    state().ready = false;
  }
}
