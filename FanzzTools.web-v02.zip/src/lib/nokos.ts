/**
 * Gacha Nokos — permintaan #6.
 * Diadaptasi dari SC_GACHA_NOKOS (bot Telegram) ke versi web:
 * - Gacha nomor virtual dengan rarity (Common/Rare/Epic/Legendary)
 * - Deteksi negara dari prefix nomor (data prefix asli)
 * - Deteksi jenis WhatsApp (Business / App biasa) — penentu deterministik
 *   dari nomor (mirip perilaku SC aslinya yang menandai tiap nomor)
 * - Kode OTP 6 digit dengan masa berlaku 5 menit
 * - Limit harian + statistik
 *
 * Semua state disimpan di localStorage per perangkat.
 */

export interface NokosNumber {
  /** nomor penuh format internasional tanpa + (mis. 5842612345678) */
  number: string;
  /** format tampilan +58 426-123-4567 */
  display: string;
  country: string;
  flag: string;
  /** kode negara iso 2 huruf */
  iso: string;
  /** jenis WhatsApp yang ditandai untuk nomor ini */
  waType: "business" | "regular";
  rarity: "Common" | "Rare" | "Epic" | "Legendary";
  gachaAt: number;
}

export interface NokosOtp {
  number: string;
  otp: string;
  /** kedaluwarsa (epoch ms) — 5 menit */
  expiresAt: number;
  createdAt: number;
}

/* ============ Data prefix negara (dipakai deteksi asli) ============ */

interface PrefixDef {
  prefix: string;
  country: string;
  flag: string;
  iso: string;
  /** panjang total nomor umum */
  len: number;
  /** V2-new (#15): awalan nomor NASIONAL yang valid untuk ponsel — nomor
   *  gacha kini mengikuti rencana penomoran tiap negara supaya formatnya
   *  diterima WhatsApp (tidak lagi "nomor tidak sesuai dengan negara ini"). */
  mobile?: string[];
}

export const COUNTRY_PREFIXES: PrefixDef[] = [
  { prefix: "62", country: "Indonesia", flag: "🇮🇩", iso: "ID", len: 13, mobile: ["8"] }, // 62 + 8xx + 8 digit = 13 (V2.11 #26: dulu 12 — kurang 1 digit)
  { prefix: "58", country: "Venezuela", flag: "🇻🇪", iso: "VE", len: 11, mobile: ["412", "414", "424", "426"] },
  { prefix: "1", country: "Amerika Serikat / Kanada", flag: "🇺🇸", iso: "US", len: 11, mobile: ["2", "3", "4", "5", "6", "7", "8", "9"] },
  { prefix: "44", country: "Inggris Raya", flag: "🇬🇧", iso: "GB", len: 12, mobile: ["74", "75", "77", "78", "79"] },
  { prefix: "49", country: "Jerman", flag: "🇩🇪", iso: "DE", len: 12, mobile: ["151", "152", "157", "159", "160", "162", "170", "175"] },
  { prefix: "33", country: "Prancis", flag: "🇫🇷", iso: "FR", len: 11, mobile: ["6", "7"] },
  { prefix: "34", country: "Spanyol", flag: "🇪🇸", iso: "ES", len: 11, mobile: ["6", "7"] },
  { prefix: "39", country: "Italia", flag: "🇮🇹", iso: "IT", len: 12, mobile: ["3"] },
  { prefix: "55", country: "Brasil", flag: "🇧🇷", iso: "BR", len: 13, mobile: ["11", "21", "31", "41", "51", "61", "71", "85"] },
  { prefix: "52", country: "Meksiko", flag: "🇲🇽", iso: "MX", len: 13, mobile: ["1"] },
  { prefix: "63", country: "Filipina", flag: "🇵🇭", iso: "PH", len: 13, mobile: ["9"] }, // 63 + 9xx + 9 digit = 13
  { prefix: "60", country: "Malaysia", flag: "🇲🇾", iso: "MY", len: 11, mobile: ["1"] },
  { prefix: "65", country: "Singapura", flag: "🇸🇬", iso: "SG", len: 10, mobile: ["8", "9"] },
  { prefix: "66", country: "Thailand", flag: "🇹🇭", iso: "TH", len: 11, mobile: ["8", "9"] },
  { prefix: "84", country: "Vietnam", flag: "🇻🇳", iso: "VN", len: 12, mobile: ["3", "5", "7", "8", "9"] }, // 84 + 9 digit = 12 (V2.11: dulu 11)
  { prefix: "91", country: "India", flag: "🇮🇳", iso: "IN", len: 12, mobile: ["6", "7", "8", "9"] },
  { prefix: "92", country: "Pakistan", flag: "🇵🇰", iso: "PK", len: 12, mobile: ["3"] },
  { prefix: "880", country: "Bangladesh", flag: "🇧🇩", iso: "BD", len: 13, mobile: ["1"] },
  { prefix: "234", country: "Nigeria", flag: "🇳🇬", iso: "NG", len: 13, mobile: ["7", "8", "9"] },
  { prefix: "254", country: "Kenya", flag: "🇰🇪", iso: "KE", len: 12, mobile: ["7", "1"] },
  { prefix: "27", country: "Afrika Selatan", flag: "🇿🇦", iso: "ZA", len: 11, mobile: ["6", "7", "8"] },
  { prefix: "7", country: "Rusia / Kazakhstan", flag: "🇷🇺", iso: "RU", len: 11, mobile: ["9"] },
  { prefix: "90", country: "Turki", flag: "🇹🇷", iso: "TR", len: 12, mobile: ["5"] },
  { prefix: "98", country: "Iran", flag: "🇮🇷", iso: "IR", len: 12, mobile: ["9"] },
  { prefix: "20", country: "Mesir", flag: "🇪🇬", iso: "EG", len: 12, mobile: ["1"] },
  { prefix: "212", country: "Maroko", flag: "🇲🇦", iso: "MA", len: 12, mobile: ["6", "7"] },
  { prefix: "971", country: "Uni Emirat Arab", flag: "🇦🇪", iso: "AE", len: 11, mobile: ["5"] },
  { prefix: "966", country: "Arab Saudi", flag: "🇸🇦", iso: "SA", len: 11, mobile: ["5"] },
  { prefix: "82", country: "Korea Selatan", flag: "🇰🇷", iso: "KR", len: 11, mobile: ["1"] },
  { prefix: "81", country: "Jepang", flag: "🇯🇵", iso: "JP", len: 11, mobile: ["7", "8", "9"] },
  { prefix: "86", country: "Tiongkok", flag: "🇨🇳", iso: "CN", len: 13, mobile: ["1"] },
  { prefix: "48", country: "Polandia", flag: "🇵🇱", iso: "PL", len: 11, mobile: ["5", "6", "7", "8"] },
  { prefix: "380", country: "Ukraina", flag: "🇺🇦", iso: "UA", len: 12, mobile: ["3", "5", "6", "7", "9"] },
  { prefix: "372", country: "Estonia", flag: "🇪🇪", iso: "EE", len: 10, mobile: ["5"] },
  { prefix: "371", country: "Latvia", flag: "🇱🇻", iso: "LV", len: 10, mobile: ["2"] },
  { prefix: "370", country: "Lituania", flag: "🇱🇹", iso: "LT", len: 10, mobile: ["6"] },
  { prefix: "40", country: "Rumania", flag: "🇷🇴", iso: "RO", len: 11, mobile: ["7"] },
  { prefix: "36", country: "Hungaria", flag: "🇭🇺", iso: "HU", len: 11, mobile: ["20", "30", "70"] },
  { prefix: "31", country: "Belanda", flag: "🇳🇱", iso: "NL", len: 11, mobile: ["6"] },
  { prefix: "46", country: "Swedia", flag: "🇸🇪", iso: "SE", len: 11, mobile: ["7"] },
  { prefix: "47", country: "Norwegia", flag: "🇳🇴", iso: "NO", len: 10, mobile: ["4", "9"] },
  { prefix: "45", country: "Denmark", flag: "🇩🇰", iso: "DK", len: 10, mobile: ["2", "3", "4", "5", "6", "7", "8", "9"] },
];

/* ============ Rarity ============ */

export function rollRarity(): "Common" | "Rare" | "Epic" | "Legendary" {
  const roll = Math.random();
  if (roll > 0.98) return "Legendary";
  if (roll > 0.9) return "Epic";
  if (roll > 0.7) return "Rare";
  return "Common";
}

export const RARITY_STYLE: Record<
  "Common" | "Rare" | "Epic" | "Legendary",
  { ring: string; text: string; glow: string; label: string }
> = {
  Common: {
    ring: "ring-slate-400/40",
    text: "text-slate-300",
    glow: "",
    label: "Umum",
  },
  Rare: {
    ring: "ring-cyan-400/50",
    text: "text-cyan-300",
    glow: "shadow-cyan-500/20",
    label: "Langka",
  },
  Epic: {
    ring: "ring-cyan-400/60",
    text: "text-cyan-300",
    glow: "shadow-cyan-500/30",
    label: "Epik",
  },
  Legendary: {
    ring: "ring-amber-400/70",
    text: "text-amber-300",
    glow: "shadow-amber-500/40",
    label: "Legendaris",
  },
};

/* ============ Generasi & deteksi ============ */

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Deteksi negara dari nomor (prefix terpanjang menang). */
export function detectCountry(number: string): PrefixDef | null {
  const sorted = [...COUNTRY_PREFIXES].sort((a, b) => b.prefix.length - a.prefix.length);
  for (const def of sorted) {
    if (number.startsWith(def.prefix)) return def;
  }
  return null;
}

/**
 * Deteksi jenis WhatsApp untuk sebuah nomor — deterministik dari hash nomor,
 * persis gaya SC aslinya yang "menandai" tiap nomor keluaran gacha.
 */
export function detectWaType(number: string): "business" | "regular" {
  let h = 0;
  for (let i = 0; i < number.length; i++) h = (h * 31 + number.charCodeAt(i)) >>> 0;
  return h % 3 === 0 ? "business" : "regular";
}

/** Format tampilan rapi: +62 812-3456-7890 */
export function formatDisplay(number: string): string {
  const def = detectCountry(number);
  const pfx = def?.prefix ?? number.slice(0, 2);
  const rest = number.slice(pfx.length);
  const groups: string[] = [];
  let i = 0;
  while (i < rest.length) {
    groups.push(rest.slice(i, i + 4));
    i += 4;
  }
  return `+${pfx} ${groups.join("-")}`.trim();
}

/** V2-new (#15): format E.164 polos untuk ditempel ke WhatsApp —
 *  tanpa +, tanpa spasi, tanpa tanda hubung (mis. 6281234567890). */
export function e164Plain(displayOrNumber: string): string {
  return displayOrNumber.replace(/[^0-9]/g, "");
}

/** Gacha satu nomor baru — V2-new (#15):
 *  - opsional pilih negara (iso) — kalau tidak, acak
 *  - bagian nasional dimulai dengan awalan ponsel VALID negara itu
 *    (rencana penomoran nasional) sehingga formatnya diterima WhatsApp. */
export function gachaNumber(iso?: string): NokosNumber {
  const pool = iso ? COUNTRY_PREFIXES.filter((d) => d.iso === iso) : COUNTRY_PREFIXES;
  const def = pick(pool.length ? pool : COUNTRY_PREFIXES);

  // awalan nasional valid (mis. ID "8", UK "74…", DE "151…")
  const nationalStart = def.mobile?.length ? pick(def.mobile) : "";
  const remain = Math.max(
    5,
    def.len - def.prefix.length - nationalStart.length
  );
  let suffix = "";
  // digit pertama sisa tidak boleh 0 (aturan umum numbering plan)
  suffix += String(Math.floor(Math.random() * 9) + 1);
  for (let i = 1; i < remain; i++) suffix += Math.floor(Math.random() * 10);
  const number = def.prefix + nationalStart + suffix;
  return {
    number,
    display: formatDisplay(number),
    country: def.country,
    flag: def.flag,
    iso: def.iso,
    waType: detectWaType(number),
    rarity: rollRarity(),
    gachaAt: Date.now(),
  };
}

/** Buat OTP untuk sebuah nomor (6 digit, berlaku 5 menit). */
export function generateOtp(number: string): NokosOtp {
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  return {
    number,
    otp,
    expiresAt: Date.now() + 5 * 60 * 1000,
    createdAt: Date.now(),
  };
}

export function formatOtp(otp: string): string {
  return otp.replace(/(\d{3})(\d{3})/, "$1-$2");
}

/* ============ State per perangkat (localStorage) ============ */

const KEY_NUMBERS = "fanzz_nokos_numbers";
const KEY_OTPS = "fanzz_nokos_otps";
const KEY_STATS = "fanzz_nokos_stats";

export const DAILY_LIMIT = 20;

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson(key: string, v: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(v));
  } catch {
    /* penuh */
  }
}

export function loadNumbers(): NokosNumber[] {
  return readJson<NokosNumber[]>(KEY_NUMBERS, []);
}

export function saveNumbers(list: NokosNumber[]) {
  writeJson(KEY_NUMBERS, list.slice(0, 50));
}

export function loadOtps(): NokosOtp[] {
  const now = Date.now();
  return readJson<NokosOtp[]>(KEY_OTPS, []).filter((o) => o.expiresAt > now);
}

export function saveOtps(list: NokosOtp[]) {
  writeJson(KEY_OTPS, list.slice(0, 60));
}

export interface NokosStats {
  day: string;
  usedToday: number;
  totalGacha: number;
}

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

export function loadStats(): NokosStats {
  const s = readJson<NokosStats>(KEY_STATS, { day: todayKey(), usedToday: 0, totalGacha: 0 });
  if (s.day !== todayKey()) {
    const reset: NokosStats = { day: todayKey(), usedToday: 0, totalGacha: s.totalGacha };
    writeJson(KEY_STATS, reset);
    return reset;
  }
  return s;
}

export function bumpStats(): NokosStats {
  const s = loadStats();
  const next: NokosStats = { day: s.day, usedToday: s.usedToday + 1, totalGacha: s.totalGacha + 1 };
  writeJson(KEY_STATS, next);
  return next;
}
