import type { SessionPayload } from "@/lib/session";
import { loadJson, saveJsonDebounced, onDbHydrated } from "@/lib/persist";

/**
 * Social store — profil publik + chat realtime antar user FanzzTools.
 * In-memory (globalThis, tahan hot-reload) + PERSISTENSI FILE JSON
 * (PERBAIKAN #3 — "foto profil & story hilang saat balik dari web"):
 * cold-start serverless / restart VPS kini memulihkan profil, avatar,
 * chat, grup, dan story dari data/social.json. Pesan di-polling lewat
 * /api/social/messages — jalan di semua environment tanpa DB eksternal.
 *
 * Privasi: email TIDAK pernah dibagikan. Yang tampil: username, negara,
 * favorit lagu, riwayat nonton (judul + poster saja).
 */

export interface SocialSong {
  title: string;
  artist: string;
  thumb?: string;
}

export interface SocialWatch {
  title: string;
  poster?: string | null;
  type?: string;
}

export interface SocialProfile {
  uid: string;
  /** ID publik pendek untuk dicari/ditunjukkan (LT-XXXXXX) — V0.01 permintaan #15 */
  fanzzId?: string;
  username: string;
  country?: string;
  countryCode?: string;
  city?: string;
  bio?: string;
  /** V2 UpdSec: foto profil (data URL kecil, di-upload user, tampil di chat/story) */
  avatar?: string;
  avatarColor: string;
  favSongs: SocialSong[];
  watched: SocialWatch[];
  followers: string[];
  following: string[];
  lastSeen: number;
  createdAt: number;
}

export type ChatMsgType = "text" | "image" | "vn";

export interface ChatMessage {
  id: number;
  from: string;
  to: string;
  type: ChatMsgType;
  text?: string;
  /** data URL (gambar terkompresi / VN base64) */
  data?: string;
  /** durasi VN detik */
  dur?: number;
  ts: number;
  seen: boolean;
}

interface Conv {
  messages: ChatMessage[];
  updated: number;
}

/* ================= GRUP ================= */

export interface SocialGroup {
  gid: string;
  name: string;
  desc?: string;
  owner: string;
  admins: string[];
  members: string[];
  avatarColor: string;
  createdAt: number;
  lastActive: number;
}

const g = globalThis as unknown as {
  __fanzzSocial?: {
    profiles: Map<string, SocialProfile>;
    convs: Map<string, Conv>;
    seq: number;
    groups: Map<string, SocialGroup>;
    groupConvs: Map<string, Conv>;
    gseq: number;
  };
};

if (!g.__fanzzSocial) {
  g.__fanzzSocial = {
    profiles: new Map(),
    convs: new Map(),
    seq: 1,
    groups: new Map(),
    groupConvs: new Map(),
    gseq: 1,
  };
  /* ===== PULIHKAN dari data/social.json (PERBAIKAN #3) ===== */
  const restoreSocial = () => {
    const S2 = g.__fanzzSocial;
    if (!S2) return;
    const saved = loadJson<{
      profiles?: SocialProfile[];
      convs?: Array<{ key: string; messages: ChatMessage[]; updated: number }>;
      groups?: SocialGroup[];
      groupConvs?: Array<{ key: string; messages: GroupMsg[]; updated: number }>;
      seq?: number;
      gseq?: number;
    }>("social");
    if (saved) {
      try {
        for (const p of saved.profiles || []) {
          if (p?.uid) S2.profiles.set(p.uid, p);
        }
        for (const c of saved.convs || []) {
          if (c?.key && Array.isArray(c.messages)) S2.convs.set(c.key, { messages: c.messages, updated: c.updated || Date.now() });
        }
        for (const gr of saved.groups || []) {
          if (gr?.gid) S2.groups.set(gr.gid, gr);
        }
        for (const c of saved.groupConvs || []) {
          if (c?.key && Array.isArray(c.messages)) S2.groupConvs.set(c.key, { messages: c.messages as unknown as ChatMessage[], updated: c.updated || Date.now() });
        }
        if (Number.isFinite(saved.seq) && (saved.seq || 0) > 0) S2.seq = saved.seq!;
        if (Number.isFinite(saved.gseq) && (saved.gseq || 0) > 0) S2.gseq = saved.gseq!;
      } catch {
        /* file rusak → mulai kosong */
      }
    }
  };
  restoreSocial();
  /* FanzSec-Update: instance serverless baru (file /tmp kosong) → snapshot
   * dipulihkan dari DATABASE (Neon) setelah hydration selesai. */
  onDbHydrated((keys) => {
    const st = g.__fanzzSocial;
    if (st && keys.includes("social") && st.profiles.size === 0) restoreSocial();
  });
}
const S = g.__fanzzSocial;

/* ===== SIMPAN ke data/social.json — debounce 2,5 dtk (PERBAIKAN #3) =====
 * Pesan lama: hanya 150 terakhir per percakapan yang dipertahankan;
 * pesan ber-media (data URL) lebih dari 3 hari dilepas datanya (hemat ruang).
 * Total snapshot dipatok < 15 MB dengan pemangkasan bertahap. */
function persistSocial() {
  saveJsonDebounced("social", () => {
    const cutoff = Date.now() - 3 * 864e5;
    const trim = (msgs: ChatMessage[]) =>
      msgs.slice(-150).map((m) => (m.data && m.ts < cutoff ? { ...m, data: undefined } : m));
    let convs = [...S.convs.entries()].map(([key, c]) => ({ key, messages: trim(c.messages), updated: c.updated }));
    let groupConvs = [...S.groupConvs.entries()].map(([key, c]) => ({ key, messages: trim(c.messages) as unknown as GroupMsg[], updated: c.updated }));
    let json = JSON.stringify(serialize(convs, groupConvs));
    while (json.length > 15 * 1024 * 1024 && (convs.length > 400 || groupConvs.length > 200)) {
      if (convs.length > 400) convs = convs.slice(-400);
      else groupConvs = groupConvs.slice(-200);
      json = JSON.stringify(serialize(convs, groupConvs));
    }
    return json;
    function serialize(cc: typeof convs, gc: typeof groupConvs) {
      return {
        profiles: [...S.profiles.values()],
        convs: cc,
        groups: [...S.groups.values()],
        groupConvs: gc,
        seq: S.seq,
        gseq: S.gseq,
      };
    }
  });
}

const MAX_MSGS_PER_CONV = 400;
const MAX_TOTAL_PROFILES = 2000;
const MAX_GROUPS = 200;
const MAX_GROUP_MEMBERS = 200;

const COLORS = [
  "from-red-500 to-red-700",
  "from-cyan-500 to-teal-600",
  "from-amber-500 to-orange-600",
  "from-emerald-500 to-green-600",
  "from-rose-500 to-red-600",
  "from-blue-600 to-blue-600",
  "from-cyan-500 to-red-700",
  "from-lime-500 to-green-600",
];

function colorFor(uid: string): string {
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) >>> 0;
  return COLORS[h % COLORS.length];
}

/** ID publik pendek — deterministik dari uid, format LT-XXXXXX. */
function makeFanzzId(uid: string): string {
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 33 + uid.charCodeAt(i)) >>> 0;
  return `LT-${h.toString(36).toUpperCase().padStart(6, "0").slice(-6)}`;
}

/** Pastikan profil ada (dibikin otomatis waktu login/register). */
export function ensureProfile(session: SessionPayload): SocialProfile {
  let p = S.profiles.get(session.uid);
  if (!p) {
    p = {
      uid: session.uid,
      fanzzId: makeFanzzId(session.uid),
      username: session.username,
      avatarColor: colorFor(session.uid),
      favSongs: [],
      watched: [],
      followers: [],
      following: [],
      lastSeen: Date.now(),
      createdAt: Date.now(),
    };
    // buang profil lama nganggur kalau kebanyakan
    if (S.profiles.size > MAX_TOTAL_PROFILES) {
      const oldest = [...S.profiles.values()].sort((a, b) => a.lastSeen - b.lastSeen)[0];
      if (oldest) S.profiles.delete(oldest.uid);
    }
    S.profiles.set(session.uid, p);
    persistSocial();
  } else {
    // sinkron username terbaru + heartbeat + pastikan fanzzId terisi
    const berubah = p.username !== session.username || !p.fanzzId;
    p.username = session.username;
    if (!p.fanzzId) p.fanzzId = makeFanzzId(session.uid);
    p.lastSeen = Date.now();
    if (berubah) persistSocial();
  }
  return p;
}

export function updateProfile(
  session: SessionPayload,
  patch: Partial<Omit<Pick<SocialProfile, "country" | "countryCode" | "city" | "bio">, never>> & {
    avatar?: string | null;
    favSong?: SocialSong;
    watched?: SocialWatch;
  }
): SocialProfile & { avatarRejected?: string } {
  const p = ensureProfile(session);
  if (patch.country !== undefined) p.country = patch.country.slice(0, 60) || undefined;
  if (patch.countryCode !== undefined) p.countryCode = (patch.countryCode.slice(0, 2) || "").toUpperCase() || undefined;
  if (patch.city !== undefined) p.city = patch.city.slice(0, 60) || undefined;
  if (patch.bio !== undefined) p.bio = patch.bio.slice(0, 160) || undefined;
  // V2 UpdSec + FanzSec-Update: avatar — data URL gambar, maks 300KB.
  // PERBAIKAN BUG "foto profil hilang saat buka Profile": dulu avatar yang
  // melebihi batas DITOLAK DIAM-DIAM (UI lokal tetap menampilkannya karena
  // fallback dataUrl, server tidak pernah menyimpan → foto hilang setelah
  // refresh/navigasi). Sekarang penolakan dilaporkan eksplisit lewat
  // avatarRejected supaya API/UI gagal dengan jujur.
  if (patch.avatar !== undefined) {
    if (patch.avatar === null || patch.avatar === "") {
      p.avatar = undefined;
    } else if (
      typeof patch.avatar === "string" &&
      /^data:image\/(png|jpeg|jpg|webp|gif);base64,/.test(patch.avatar.slice(0, 40)) &&
      patch.avatar.length <= 300 * 1024
    ) {
      p.avatar = patch.avatar;
    } else if (typeof patch.avatar === "string" && patch.avatar.length > 0) {
      (p as SocialProfile & { avatarRejected?: string }).avatarRejected =
        patch.avatar.length > 300 * 1024
          ? `Foto terlalu besar setelah kompresi (${Math.round(patch.avatar.length / 1024)} KB — maks 300 KB). Coba foto dengan resolusi lebih kecil.`
          : "Format foto tidak valid (harus PNG/JPEG/WebP data URL).";
    }
  }
  if (patch.favSong?.title) {
    p.favSongs = [
      { title: patch.favSong.title.slice(0, 80), artist: (patch.favSong.artist || "").slice(0, 60), thumb: patch.favSong.thumb?.slice(0, 300) },
      ...p.favSongs.filter((s) => s.title !== patch.favSong?.title),
    ].slice(0, 5);
  }
  if (patch.watched?.title) {
    p.watched = [
      { title: patch.watched.title.slice(0, 100), poster: patch.watched.poster?.slice(0, 300) || null, type: patch.watched.type },
      ...p.watched.filter((w) => w.title !== patch.watched?.title),
    ].slice(0, 5);
  }
  persistSocial(); // PERBAIKAN #3 — profil (termasuk avatar) langsung bertahan
  return p;
}

/** Profil publik (aman — tanpa data sensitif). */
export function publicProfile(p: SocialProfile) {
  return {
    uid: p.uid,
    fanzzId: p.fanzzId || makeFanzzId(p.uid),
    username: p.username,
    country: p.country || null,
    countryCode: p.countryCode || null,
    city: p.city || null,
    bio: p.bio || null,
    avatar: p.avatar || null,
    avatarColor: p.avatarColor,
    favSongs: p.favSongs.slice(0, 3),
    watched: p.watched.slice(0, 3),
    followers: p.followers.length,
    followersList: p.followers.slice(0, 50),
    following: p.following.length,
    online: Date.now() - p.lastSeen < 90 * 1000,
    lastSeen: p.lastSeen,
    createdAt: p.createdAt,
  };
}

/** Cari user (username, negara, atau ID FanzzTools/uid) — V0.01: search by ID. */
export function searchProfiles(q: string, excludeUid: string, limit = 30) {
  const query = q.trim().toLowerCase().replace(/^@/, "");
  const all = [...S.profiles.values()].filter((p) => p.uid !== excludeUid);
  if (!query) {
    // paling baru aktif dulu
    return all.sort((a, b) => b.lastSeen - a.lastSeen).slice(0, limit).map(publicProfile);
  }
  return all
    .filter(
      (p) =>
        p.username.toLowerCase().includes(query) ||
        (p.country || "").toLowerCase().includes(query) ||
        (p.fanzzId || "").toLowerCase().includes(query) ||
        p.uid.toLowerCase().startsWith(query)
    )
    .sort((a, b) => b.lastSeen - a.lastSeen)
    .slice(0, limit)
    .map(publicProfile);
}

export function getProfile(uid: string): SocialProfile | undefined {
  return S.profiles.get(uid);
}

/** Follow / unfollow. Balikin status follow baru. */
export function toggleFollow(meUid: string, targetUid: string): boolean {
  if (meUid === targetUid) return false;
  const me = S.profiles.get(meUid);
  const target = S.profiles.get(targetUid);
  if (!me || !target) return false;

  const idx = me.following.indexOf(targetUid);
  if (idx >= 0) {
    me.following.splice(idx, 1);
    target.followers = target.followers.filter((f) => f !== meUid);
    persistSocial();
    return false;
  }
  me.following.push(targetUid);
  if (!target.followers.includes(meUid)) target.followers.push(meUid);
  persistSocial();
  return true;
}

function convKey(a: string, b: string): string {
  return [a, b].sort().join("::");
}

function getConv(a: string, b: string): Conv {
  const k = convKey(a, b);
  let c = S.convs.get(k);
  if (!c) {
    c = { messages: [], updated: Date.now() };
    S.convs.set(k, c);
  }
  return c;
}

export function sendMessage(
  from: string,
  to: string,
  msg: { type: ChatMsgType; text?: string; data?: string; dur?: number }
): ChatMessage | null {
  if (from === to) return null;
  const target = S.profiles.get(to);
  if (!target) return null;

  const conv = getConv(from, to);
  const m: ChatMessage = {
    id: S.seq++,
    from,
    to,
    type: msg.type,
    text: msg.text?.slice(0, 4000),
    data: msg.data,
    dur: msg.dur,
    ts: Date.now(),
    seen: false,
  };
  conv.messages.push(m);
  if (conv.messages.length > MAX_MSGS_PER_CONV) {
    conv.messages.splice(0, conv.messages.length - MAX_MSGS_PER_CONV);
  }
  conv.updated = m.ts;
  persistSocial();
  return m;
}

/** Ambil pesan (incremental via afterId), sekaligus tandai sudah dibaca. */
export function getMessages(me: string, peer: string, afterId?: number): ChatMessage[] {
  const conv = getConv(me, peer);
  const after = Number(afterId) || 0;
  const fresh = conv.messages.filter((m) => m.id > after);
  // tandai pesan dari peer sebagai dibaca
  for (const m of conv.messages) {
    if (m.to === me && !m.seen) m.seen = true;
  }
  return fresh;
}

export interface ConvSummary {
  peer: ReturnType<typeof publicProfile> | null;
  last: { text: string; type: ChatMsgType; ts: number; from: string } | null;
  unread: number;
}

/** Daftar percakapan user. */
export function listConversations(me: string): ConvSummary[] {
  const out: ConvSummary[] = [];
  for (const [k, conv] of S.convs) {
    if (!k.includes(me)) continue;
    const peerUid = k.split("::").find((u) => u !== me) || "";
    const peer = S.profiles.get(peerUid);
    if (!peer || !conv.messages.length) continue;
    const last = conv.messages[conv.messages.length - 1];
    out.push({
      peer: publicProfile(peer),
      last: {
        text: last.type === "text" ? String(last.text || "") : last.type === "vn" ? "🎙️ Pesan suara" : "📷 Foto",
        type: last.type,
        ts: last.ts,
        from: last.from,
      },
      unread: conv.messages.filter((m) => m.to === me && !m.seen).length,
    });
  }
  return out.sort((a, b) => (b.last?.ts || 0) - (a.last?.ts || 0));
}

/** Total unread semua percakapan (badge nav). */
export function totalUnread(me: string): number {
  let n = 0;
  for (const conv of S.convs.values()) {
    n += conv.messages.filter((m) => m.to === me && !m.seen).length;
  }
  return n;
}

/* ================= GRUP: operasi ================= */

export function publicGroup(gr: SocialGroup) {
  return {
    gid: gr.gid,
    name: gr.name,
    desc: gr.desc || null,
    owner: gr.owner,
    admins: gr.admins,
    members: gr.members.length,
    avatarColor: gr.avatarColor,
    createdAt: gr.createdAt,
    lastActive: gr.lastActive,
  };
}

export function listGroups(me: string) {
  const all = [...S.groups.values()].sort((a, b) => b.lastActive - a.lastActive);
  const mine: SocialGroup[] = [];
  const pub: SocialGroup[] = [];
  for (const gr of all) {
    if (gr.members.includes(me)) mine.push(gr);
    else pub.push(gr);
  }
  return { mine: mine.map(publicGroup), discover: pub.slice(0, 30).map(publicGroup) };
}

export function getGroup(gid: string): SocialGroup | undefined {
  return S.groups.get(gid);
}

export function createGroup(me: string, name: string, desc?: string): SocialGroup | null {
  const clean = name.replace(/\s+/g, " ").trim().slice(0, 40);
  if (clean.length < 3) return null;
  // buang grup nganggur kalau kebanyakan
  if (S.groups.size > MAX_GROUPS) {
    const oldest = [...S.groups.values()].sort((a, b) => a.lastActive - b.lastActive)[0];
    if (oldest) {
      S.groups.delete(oldest.gid);
      S.groupConvs.delete(oldest.gid);
    }
  }
  const gr: SocialGroup = {
    gid: `g${S.gseq++}${Date.now().toString(36).slice(-4)}`,
    name: clean,
    desc: desc?.slice(0, 120) || undefined,
    owner: me,
    admins: [me],
    members: [me],
    avatarColor: colorFor(clean),
    createdAt: Date.now(),
    lastActive: Date.now(),
  };
  S.groups.set(gr.gid, gr);
  persistSocial();
  return gr;
}

export function joinGroup(me: string, gid: string): { ok: boolean; error?: string } {
  const gr = S.groups.get(gid);
  if (!gr) return { ok: false, error: "Grup gak ketemu" };
  if (gr.members.includes(me)) return { ok: false, error: "Udah jadi anggota grup ini" };
  if (gr.members.length >= MAX_GROUP_MEMBERS) return { ok: false, error: "Grup penuh (200 anggota)" };
  gr.members.push(me);
  gr.lastActive = Date.now();
  persistSocial();
  return { ok: true };
}

/**
 * Admin/owner MENAMBAH anggota langsung ke grup — V0.01 (permintaan #15).
 * Target boleh fanzzId (LT-XXXXXX), username, atau uid.
 */
export function addMember(me: string, gid: string, targetQuery: string): { ok: boolean; error?: string } {
  const gr = S.groups.get(gid);
  if (!gr) return { ok: false, error: "Grup tidak ditemukan" };
  if (gr.owner !== me && !gr.admins.includes(me)) {
    return { ok: false, error: "Hanya admin/owner grup yang bisa menambahkan anggota" };
  }
  const q = targetQuery.trim().toLowerCase().replace(/^@/, "");
  if (!q) return { ok: false, error: "Masukkan ID (LT-XXXXXX) atau username anggota" };

  const target =
    [...S.profiles.values()].find(
      (p) =>
        (p.fanzzId || "").toLowerCase() === q ||
        p.username.toLowerCase() === q ||
        p.uid.toLowerCase() === q
    ) || null;
  if (!target) return { ok: false, error: "Pengguna tidak ditemukan (coba cari ID atau username yang tepat)" };
  if (gr.members.includes(target.uid)) return { ok: false, error: `${target.username} sudah menjadi anggota grup ini` };
  if (gr.members.length >= MAX_GROUP_MEMBERS) return { ok: false, error: "Grup penuh (200 anggota)" };

  gr.members.push(target.uid);
  gr.lastActive = Date.now();

  // pesan sistem di chat grup supaya anggota lain tahu
  const conv = S.groupConvs.get(gid) || { messages: [], updated: Date.now() };
  S.groupConvs.set(gid, conv);
  conv.messages.push({
    id: S.gseq++,
    gid,
    from: me,
    fromName: "Sistem",
    type: "text",
    text: `${target.username} ditambahkan ke grup oleh admin.`,
    ts: Date.now(),
    seen: false,
  } as GroupMsg);
  conv.updated = Date.now();
  persistSocial();
  return { ok: true, added: target.username };
}

export function leaveGroup(me: string, gid: string): { ok: boolean; error?: string } {
  const gr = S.groups.get(gid);
  if (!gr) return { ok: false, error: "Grup gak ketemu" };
  if (!gr.members.includes(me)) return { ok: false, error: "Kamu bukan anggota grup ini" };
  if (gr.owner === me && gr.members.length > 1) {
    return { ok: false, error: "Owner gak bisa keluar — transfer dulu atau hapus grup (anggota tinggal kamu sendiri)" };
  }
  gr.members = gr.members.filter((m) => m !== me);
  gr.admins = gr.admins.filter((m) => m !== me);
  gr.lastActive = Date.now();
  if (gr.members.length === 0) {
    S.groups.delete(gr.gid);
    S.groupConvs.delete(gr.gid);
  }
  persistSocial();
  return { ok: true };
}

/** Promote / demote admin — hanya owner & admin yang bisa. */
export function setAdmin(me: string, gid: string, target: string, make: boolean): { ok: boolean; error?: string } {
  const gr = S.groups.get(gid);
  if (!gr) return { ok: false, error: "Grup gak ketemu" };
  if (gr.owner !== me && !gr.admins.includes(me)) {
    return { ok: false, error: "Cuma admin grup yang bisa ngatur admin" };
  }
  if (gr.owner === target) return { ok: false, error: "Owner gak bisa diubah" };
  if (!gr.members.includes(target)) return { ok: false, error: "Target bukan anggota grup" };
  if (make && !gr.admins.includes(target)) gr.admins.push(target);
  if (!make) gr.admins = gr.admins.filter((a) => a !== target);
  gr.lastActive = Date.now();
  persistSocial();
  return { ok: true };
}

export function kickMember(me: string, gid: string, target: string): { ok: boolean; error?: string } {
  const gr = S.groups.get(gid);
  if (!gr) return { ok: false, error: "Grup gak ketemu" };
  if (gr.owner !== me && !gr.admins.includes(me)) {
    return { ok: false, error: "Cuma admin yang bisa kick anggota" };
  }
  if (gr.owner === target) return { ok: false, error: "Owner gak bisa di-kick" };
  if (!gr.members.includes(target)) return { ok: false, error: "Target bukan anggota grup" };
  gr.members = gr.members.filter((m) => m !== target);
  gr.admins = gr.admins.filter((a) => a !== target);
  gr.lastActive = Date.now();
  persistSocial();
  return { ok: true };
}

export interface GroupMsg extends Omit<ChatMessage, "to"> {
  gid: string;
  fromName?: string;
}

export function sendGroupMessage(
  me: string,
  gid: string,
  msg: { type: ChatMsgType; text?: string; data?: string; dur?: number }
): GroupMsg | null {
  const gr = S.groups.get(gid);
  if (!gr || !gr.members.includes(me)) return null;
  const meProfile = S.profiles.get(me);
  const conv = S.groupConvs.get(gid) || { messages: [], updated: Date.now() };
  S.groupConvs.set(gid, conv);
  const m: GroupMsg = {
    id: S.seq++,
    gid,
    from: me,
    fromName: meProfile?.username || "user",
    type: msg.type,
    text: msg.text?.slice(0, 4000),
    data: msg.data,
    dur: msg.dur,
    ts: Date.now(),
    seen: true,
  };
  conv.messages.push(m);
  if (conv.messages.length > MAX_MSGS_PER_CONV) {
    conv.messages.splice(0, conv.messages.length - MAX_MSGS_PER_CONV);
  }
  conv.updated = m.ts;
  gr.lastActive = m.ts;
  persistSocial();
  return m;
}

export function getGroupMessages(gid: string, afterId?: number): GroupMsg[] {
  const conv = S.groupConvs.get(gid);
  if (!conv) return [];
  const after = Number(afterId) || 0;
  return conv.messages.filter((m) => m.id > after) as GroupMsg[];
}

/** Anggota grup lengkap dengan profil publik. */
export function groupMembers(gid: string) {
  const gr = S.groups.get(gid);
  if (!gr) return null;
  return gr.members
    .map((uid) => {
      const p = S.profiles.get(uid);
      if (!p) return null;
      return {
        ...publicProfile(p),
        isOwner: gr.owner === uid,
        isAdmin: gr.admins.includes(uid),
      };
    })
    .filter(Boolean);
}

/* ================= Daftar followers / following (profil publik) ================= */

export function listFollowers(uid: string) {
  const p = S.profiles.get(uid);
  if (!p) return [];
  return p.followers
    .map((f) => S.profiles.get(f))
    .filter(Boolean)
    .slice(0, 50)
    .map((f) => publicProfile(f as SocialProfile));
}

export function listFollowing(uid: string) {
  const p = S.profiles.get(uid);
  if (!p) return [];
  return p.following
    .map((f) => S.profiles.get(f))
    .filter(Boolean)
    .slice(0, 50)
    .map((f) => publicProfile(f as SocialProfile));
}
