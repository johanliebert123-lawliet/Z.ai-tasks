"use client";

import { create } from "zustand";

export type ViewId =
  | "home"
  | "film"
  | "anime"
  | "ai"
  | "music"
  | "downloader"
  | "email"
  | "am"
  | "osint"
  | "apk"
  | "chat"
  | "news"
  | "wiki"
  | "books"
  | "profile"
  | "nekopoi"
  | "manhwa"
  | "komik"
  | "donghua"
  | "aiimage"
  | "reactwa"
  | "capcut"
  | "dracin"
  | "gacha"
  | "history"
  | "lyrics"
  | "profanity"
  | "usercheck"
  | "studio"
  | "hdimage"
  | "qr"
  | "kalkulator"
  | "iqtest"
  /* V2 Modern-UpdSec — tools baru */
  | "alltools"
  | "sourcecode"
  | "secscan"
  | "minecraft"
  | "ibadah"
  | "quran"
  | "debat"
  | "story"
  /* V2.12 Security-Updt — Parent Monitor / Family Cyber Safety */
  | "pm"
  /* V2.13 zuperupdt — tools baru: cuaca, wifi, roda nama, ascii */
  | "cuaca"
  | "wifi"
  | "roda"
  | "ascii"
  /* FanzSec-Update — FanzzSecurity & FanzSec.Ai */
  | "security"
  | "fanzsec";

export interface AppUser {
  uid: string;
  username: string;
  email: string;
}

export interface BatteryInfo {
  level: number;
  charging: boolean;
  supported: boolean;
}

export interface DeviceInfo {
  os: string;
  osName: string;
  browser: string;
  modelCode: string;
  modelName: string;
  screen: string;
  cores?: number;
  memory?: number;
  network?: string;
  language: string;
  timezone: string;
}

export interface GeoInfo {
  mode: "gps" | "estimasi" | "loading";
  lat: number;
  lon: number;
  accuracy?: number;
  kecamatan?: string;
  kelurahan?: string;
  kota?: string;
  kabupaten?: string;
  provinsi?: string;
  negara?: string;
  countryCode?: string;
  postcode?: string;
  display?: string;
  ip?: string;
}

export interface PlayingSong {
  videoId: string;
  title: string;
  artist: string;
  thumbnail: string;
  mp3: string;
}

export interface WatchHistoryItem {
  id: number;
  type: "movie" | "tv";
  title: string;
  poster: string | null;
  at: number;
  season?: number;
  episode?: number;
}

interface AppState {
  phase: "boot" | "auth" | "app";
  user: AppUser | null;
  view: ViewId;
  filmDeepLink: { id: number; type: "movie" | "tv" } | null;

  // music player
  currentSong: PlayingSong | null;
  isPlaying: boolean;
  audioEl: HTMLAudioElement | null;

  // device & lokasi (V2.3)
  battery: BatteryInfo | null;
  device: DeviceInfo | null;
  geo: GeoInfo | null;
  geoAsked: boolean;

  // chat sosial (V2 Modern)
  chatPeer: { uid: string; name: string } | null;
  chatUnread: number;

  // tugas AI latar belakang (V2-new #21) — tetap berjalan walau pindah menu
  aiTasks: AiTask[];

  setPhase: (p: AppState["phase"]) => void;
  setUser: (u: AppUser | null) => void;
  setView: (v: ViewId) => void;
  openFilm: (id: number, type: "movie" | "tv") => void;
  clearFilmLink: () => void;
  playSong: (s: PlayingSong) => void;
  setPlaying: (p: boolean) => void;
  setAudioEl: (el: HTMLAudioElement | null) => void;
  stopSong: () => void;
  setBattery: (b: BatteryInfo) => void;
  setDevice: (d: DeviceInfo) => void;
  setGeo: (g: GeoInfo | null) => void;
  markGeoAsked: () => void;
  openChatWith: (peer: { uid: string; name: string } | null) => void;
  setChatUnread: (n: number) => void;
  setAiTasks: (t: AiTask[]) => void;
  updateAiTask: (id: string, patch: Partial<AiTask>) => void;
}

/** Tugas AI latar belakang — fetch dipegang di luar komponen (zustand),
 *  jadi terus berjalan saat pengguna pindah-pindah menu. */
export interface AiTask {
  id: string;
  prompt: string;
  model: string;
  mode: string;
  status: "running" | "done" | "error";
  startedAt: number;
  finishedAt?: number;
  answer?: string;
  error?: string;
  sessionId?: string;
}

export const useApp = create<AppState>((set, get) => ({
  phase: "boot",
  user: null,
  view: "home",
  filmDeepLink: null,
  currentSong: null,
  isPlaying: false,
  audioEl: null,
  battery: null,
  device: null,
  geo: null,
  geoAsked: false,
  chatPeer: null,
  chatUnread: 0,
  aiTasks: [],

  setPhase: (p) => set({ phase: p }),
  setUser: (u) => set({ user: u }),
  setView: (v) => set({ view: v }),
  openFilm: (id, type) => set({ view: "film", filmDeepLink: { id, type } }),
  clearFilmLink: () => set({ filmDeepLink: null }),

  playSong: (s) => {
    const { audioEl, currentSong } = get();
    if (audioEl) {
      // lagu sama TAPI sumber audio berbeda (hasil re-resolve fresh) → ganti src
      if (currentSong?.videoId === s.videoId && currentSong?.mp3 === s.mp3) {
        if (audioEl.paused) {
          audioEl.play().catch(() => {});
          set({ isPlaying: true });
        } else {
          audioEl.pause();
          set({ isPlaying: false });
        }
        return;
      }
      audioEl.src = s.mp3;
      audioEl.play().catch(() => set({ isPlaying: false }));
    }
    set({ currentSong: s, isPlaying: true });
  },
  setPlaying: (p) => set({ isPlaying: p }),
  setAudioEl: (el) => set({ audioEl: el }),
  setBattery: (b) => set({ battery: b }),
  setDevice: (d) => set({ device: d }),
  setGeo: (g) => set({ geo: g }),
  markGeoAsked: () => set({ geoAsked: true }),
  openChatWith: (peer) => set({ chatPeer: peer, view: "chat" }),
  setChatUnread: (n) => set({ chatUnread: n }),
  setAiTasks: (t) => set({ aiTasks: t }),
  updateAiTask: (id, patch) =>
    set((state) => ({ aiTasks: state.aiTasks.map((task) => (task.id === id ? { ...task, ...patch } : task)) })),
  stopSong: () => {
    const { audioEl } = get();
    if (audioEl) {
      audioEl.pause();
      audioEl.removeAttribute("src");
    }
    set({ currentSong: null, isPlaying: false });
  },
}));

/* ===== Helper localStorage minimal (hanya data ringan user) ===== */

const LS_HISTORY = "fanzz_history_v2";
const LS_FAVSONG = "fanzz_fav_songs_v2";
const LS_SETTINGS = "fanzz_settings_v2";
const LS_VAULT = "fanzz_vault_v2";

export function getWatchHistory(): WatchHistoryItem[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(LS_HISTORY) || "[]").slice(0, 50);
  } catch {
    return [];
  }
}

export function addWatchHistory(item: Omit<WatchHistoryItem, "at">) {
  if (typeof window === "undefined") return;
  try {
    const list = getWatchHistory().filter(
      (h) => !(h.id === item.id && h.type === item.type)
    );
    list.unshift({ ...item, at: Date.now() });
    localStorage.setItem(LS_HISTORY, JSON.stringify(list.slice(0, 50)));
  } catch {
    /* penuh? abaikan */
  }
}

export function getFavSongs(): PlayingSong[] {
  if (typeof window === "undefined") return [];
  try {
    return JSON.parse(localStorage.getItem(LS_FAVSONG) || "[]").slice(0, 100);
  } catch {
    return [];
  }
}

export function toggleFavSong(song: PlayingSong): boolean {
  if (typeof window === "undefined") return false;
  try {
    const list = getFavSongs();
    const idx = list.findIndex((s) => s.videoId === song.videoId);
    if (idx >= 0) {
      list.splice(idx, 1);
      localStorage.setItem(LS_FAVSONG, JSON.stringify(list));
      return false;
    }
    list.unshift(song);
    localStorage.setItem(LS_FAVSONG, JSON.stringify(list.slice(0, 100)));
    return true;
  } catch {
    return false;
  }
}

export interface AppSettings {
  defaultModel: string;
  defaultSub: "id" | "en" | "off";
  defaultServer: string;
  /** tema: gelap futuristik (default) / terang / charcoal-blood (V0.01) */
  theme?: "dark" | "light" | "blood";
}

export function getSettings(): AppSettings {
  if (typeof window === "undefined")
    return { defaultModel: "gpt-4.1-nano", defaultSub: "id", defaultServer: "vidlink" };
  try {
    return {
      defaultModel: "gpt-4.1-nano",
      defaultSub: "id",
      defaultServer: "vidlink",
      ...(JSON.parse(localStorage.getItem(LS_SETTINGS) || "{}") as Partial<AppSettings>),
    };
  } catch {
    return { defaultModel: "gpt-4.1-nano", defaultSub: "id", defaultServer: "vidlink" };
  }
}

export function saveSettings(s: Partial<AppSettings>) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_SETTINGS, JSON.stringify({ ...getSettings(), ...s }));
  } catch {
    /* ignore */
  }
}

export interface VaultRecord {
  email: string;
  username: string;
  hash: string;
}

/** Vault akun — restore login kalau server cold-start. Ini SATU-SATUNYA data akun di client. */
export function saveVault(v: VaultRecord) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_VAULT, JSON.stringify(v));
  } catch {
    /* ignore */
  }
}

export function getVault(): VaultRecord | null {
  if (typeof window === "undefined") return null;
  try {
    const v = JSON.parse(localStorage.getItem(LS_VAULT) || "null");
    if (v && typeof v.email === "string" && typeof v.hash === "string") return v;
    return null;
  } catch {
    return null;
  }
}

export function clearVault() {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(LS_VAULT);
  } catch {
    /* ignore */
  }
}
