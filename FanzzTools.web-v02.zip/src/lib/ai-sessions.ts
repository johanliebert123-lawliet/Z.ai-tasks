/**
 * Riwayat & ingatan AI (V2-new #21).
 *
 * - ChatSession: satu percakapan penuh (pesan, model, mode) — tersimpan di
 *   localStorage, bisa dibuka kembali & dilanjutkan kapan saja.
 * - AI Memory: catatan "hal yang harus AI ingat" per pengguna — disuntikkan
 *   sebagai konteks setiap kali chat, sehingga AI benar-benar punya ingatan
 *   lintas sesi.
 * - Semua murni client-side (tanpa server) supaya tetap jalan tanpa DB.
 */

export interface AiMsg {
  role: "user" | "assistant";
  content: string;
  model?: string;
  image?: string;
  fileName?: string;
  searched?: boolean;
  at?: number;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: AiMsg[];
  model: string;
  mode: string;
  createdAt: number;
  updatedAt: number;
}

const LS_SESSIONS = "fanzz_ai_sessions_v1";
const LS_MEMORY = "fanzz_ai_memory_v1";
const MAX_SESSIONS = 40;

/* ============ Sesi ============ */

export function loadSessions(): ChatSession[] {
  if (typeof window === "undefined") return [];
  try {
    const list = JSON.parse(localStorage.getItem(LS_SESSIONS) || "[]") as ChatSession[];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

function saveSessions(list: ChatSession[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_SESSIONS, JSON.stringify(list.slice(0, MAX_SESSIONS)));
  } catch {
    /* penuh — abaikan */
  }
}

export function newSession(model: string, mode: string): ChatSession {
  const s: ChatSession = {
    id: `s_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    title: "Percakapan baru",
    messages: [],
    model,
    mode,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  const list = [s, ...loadSessions()];
  saveSessions(list);
  return s;
}

/** Simpan/update satu sesi (upsert). Judul otomatis dari pesan pertama. */
export function upsertSession(session: ChatSession) {
  if (typeof window === "undefined") return;
  const list = loadSessions();
  const idx = list.findIndex((s) => s.id === session.id);
  const updated: ChatSession = {
    ...session,
    updatedAt: Date.now(),
    title:
      session.messages.find((m) => m.role === "user")?.content.slice(0, 42) ||
      session.title,
  };
  if (idx >= 0) list[idx] = updated;
  else list.unshift(updated);
  saveSessions(list);
}

export function deleteSession(id: string) {
  saveSessions(loadSessions().filter((s) => s.id !== id));
}

export function clearSessions() {
  if (typeof window === "undefined") return;
  try {
    localStorage.removeItem(LS_SESSIONS);
  } catch {
    /* ignore */
  }
}

/* ============ Ingatan jangka panjang ============ */

export function loadMemory(): string {
  if (typeof window === "undefined") return "";
  try {
    return String(localStorage.getItem(LS_MEMORY) || "");
  } catch {
    return "";
  }
}

export function saveMemory(text: string) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(LS_MEMORY, text.slice(0, 2000));
  } catch {
    /* ignore */
  }
}

/** Konteks sistem yang disuntikkan ke setiap permintaan chat. */
export function memoryContext(): string {
  const mem = loadMemory().trim();
  if (!mem) return "";
  return `[Ingatan jangka panjang pengguna — pakai sebagai konteks pribadi, jangan diulang mentah-mentah kecuali ditanya]\n${mem}`;
}
