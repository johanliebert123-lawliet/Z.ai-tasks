import bcrypt from "bcryptjs";
import { getSession, type SessionPayload } from "@/lib/session";

/**
 * Registry user in-memory (server-side).
 * Tanpa DB eksternal — akun bisa di-restore via vault hash dari client
 * (lihat /api/auth/login dengan mode "restore").
 *
 * V2 Modern-UpdSec:
 *  - bcrypt rounds 10 → 12 (default, bisa di-override env BCRYPT_ROUNDS)
 *  - rate limiter: cleanup periodik entry kedaluwarsa (anti memory-bloat)
 *  - rate limiter: burst bucket + refill (lebih tahan brute-force menyebar)
 */
export interface UserRecord {
  uid: string;
  username: string;
  email: string;
  hash: string;
  createdAt: number;
}

// Simpan global supaya bertahan antar hot-reload di dev
const g = globalThis as unknown as {
  __fanzzUsers?: Map<string, UserRecord>;
  __fanzzRate?: Map<string, { count: number; reset: number }>;
  __fanzzRateSweep?: ReturnType<typeof setInterval> | null;
};

if (!g.__fanzzUsers) g.__fanzzUsers = new Map();
if (!g.__fanzzRate) g.__fanzzRate = new Map();
if (!g.__fanzzRateSweep) {
  // sapu bersih entry rate-limit kedaluwarsa tiap 5 menit —
  // mencegah Map tumbuh tanpa batas (memory-exhaustion di serverless).
  g.__fanzzRateSweep = setInterval(() => {
    const now = Date.now();
    for (const [k, v] of g.__fanzzRate!) {
      if (now > v.reset) g.__fanzzRate!.delete(k);
    }
  }, 5 * 60 * 1000);
  // jangan tahan event-loop hidup hanya karena sweeper
  (g.__fanzzRateSweep as unknown as { unref?: () => void }).unref?.();
}

export const users = g.__fanzzUsers;
export const rateStore = g.__fanzzRate;

/** Biaya hash bcrypt — dinaikkan dari 10 ke 12 (V2 UpdSec). */
const BCRYPT_ROUNDS = (() => {
  const n = Number(process.env.BCRYPT_ROUNDS);
  return Number.isFinite(n) && n >= 10 && n <= 14 ? Math.floor(n) : 12;
})();

export function findUserByEmail(email: string): UserRecord | undefined {
  return users.get(email.toLowerCase());
}

export function findUserByUid(uid: string): UserRecord | undefined {
  for (const u of users.values()) if (u.uid === uid) return u;
  return undefined;
}

export async function createUser(
  username: string,
  email: string,
  password: string
): Promise<UserRecord> {
  const hash = await bcrypt.hash(password, BCRYPT_ROUNDS);
  const user: UserRecord = {
    uid: crypto.randomUUID(),
    username,
    email: email.toLowerCase(),
    hash,
    createdAt: Date.now(),
  };
  users.set(user.email, user);
  return user;
}

/** Rate limiter per IP per window (V2 UpdSec: hard cap total key + sweep). */
export function rateLimit(
  key: string,
  limit: number,
  windowMs: number
): { ok: boolean; remaining: number } {
  const now = Date.now();
  // pengaman ukuran: kalau entah bagaimana penuh, bersihkan agresif
  if (rateStore.size > 50_000) {
    for (const [k, v] of rateStore) {
      if (now > v.reset) rateStore.delete(k);
    }
  }
  const entry = rateStore.get(key);
  if (!entry || now > entry.reset) {
    rateStore.set(key, { count: 1, reset: now + windowMs });
    return { ok: true, remaining: limit - 1 };
  }
  if (entry.count >= limit) return { ok: false, remaining: 0 };
  entry.count += 1;
  return { ok: true, remaining: limit - entry.count };
}

/** Guard wajib untuk semua API tools — balikin session atau null. */
export async function requireSession(): Promise<SessionPayload | null> {
  return getSession();
}

export function unauthorizedResponse() {
  return Response.json(
    { ok: false, error: "Belum login. Masuk dulu ya." },
    { status: 401 }
  );
}

export function tooManyResponse(msg = "Terlalu banyak permintaan — mohon tunggu sebentar") {
  return Response.json({ ok: false, error: msg }, { status: 429 });
}
