/**
 * CapCut account generator + klaim Pro trial 7 hari.
 * Port dari capcut-generator-main (lib/capcut.js) — versi server-side minimal:
 * sendVerificationCode → registerVerifyLogin → getUserInfo → getTrial7d.
 */

import crypto from "node:crypto";

const API_BASE = "https://www.capcut.com";
const FEED_API = "https://feed-api-sg.capcut.com";
const COMMERCE_API = "https://commerce-api-sg.capcut.com";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
const AID = "348188";
const VERIFY_FP = "verify_m7euzwhw_PNtb4tlY_I0az_4me0_9Hrt_sEBZgW5GGPdn";

 
export function encryptToTargetHex(input: string): string {
  let hexResult = "";
  for (const char of String(input)) {
    const encryptedCharCode = char.charCodeAt(0) ^ 0x05;
    hexResult += encryptedCharCode.toString(16).padStart(2, "0");
  }
  return hexResult;
}

export function generateSecurePassword(): string {
  const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%&*";
  let pass = "Cc9!";
  for (let i = 0; i < 10; i++) {
    pass += chars[crypto.randomBytes(1)[0] % chars.length];
  }
  return pass;
}

export function generateRandomBirthday(): string {
  const start = new Date(1992, 0, 1).getTime();
  const end = new Date(2003, 11, 31).getTime();
  const d = new Date(start + Math.random() * (end - start));
  return d.toISOString().split("T")[0];
}

function baseHeaders(cookie?: string): Record<string, string> {
  return {
    "User-Agent": UA,
    Accept: "application/json, text/plain, */*",
    "Accept-Language": "en-US;q=0.9,id;q=0.8",
    ...(cookie ? { Cookie: cookie } : {}),
  };
}

/** Kirim kode verifikasi OTP ke email (bikin akun baru). */
export async function sendVerificationCode(email: string, password: string): Promise<void> {
  const url = new URL(`${API_BASE}/passport/web/email/send_code/`);
  url.searchParams.append("aid", AID);
  url.searchParams.append("account_sdk_source", "web");
  url.searchParams.append("language", "en");
  url.searchParams.append("verifyFp", VERIFY_FP);
  url.searchParams.append("check_region", "1");

  const form = new URLSearchParams();
  form.append("mix_mode", "1");
  form.append("email", encryptToTargetHex(email));
  form.append("password", encryptToTargetHex(password));
  form.append("type", "34");
  form.append("fixed_mix_mode", "1");

  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { ...baseHeaders(), "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    signal: AbortSignal.timeout(30000),
  });
  const json = (await res.json().catch(() => null)) as { message?: string } | null;
  if (json?.message !== "success") {
    throw new Error(String(json?.message || "Gagal kirim kode verifikasi"));
  }
}

/** Verifikasi OTP + daftar + login — hasilnya cookie sesi. */
export async function registerVerifyLogin(
  email: string,
  password: string,
  code: string
): Promise<{ userId: string; cookie: string }> {
  const url = new URL(`${API_BASE}/passport/web/email/register_verify_login/`);
  url.searchParams.append("aid", AID);
  url.searchParams.append("account_sdk_source", "web");
  url.searchParams.append("language", "en");
  url.searchParams.append("verifyFp", VERIFY_FP);
  url.searchParams.append("check_region", "1");

  const form = new URLSearchParams();
  form.append("mix_mode", "1");
  form.append("email", encryptToTargetHex(email));
  form.append("code", encryptToTargetHex(code));
  form.append("password", encryptToTargetHex(password));
  form.append("type", "34");
  form.append("birthday", generateRandomBirthday());
  form.append("force_user_region", "ID");
  form.append("biz_param", "%7B%7D");
  form.append("check_region", "1");
  form.append("fixed_mix_mode", "1");

  const res = await fetch(url.toString(), {
    method: "POST",
    headers: { ...baseHeaders(), "Content-Type": "application/x-www-form-urlencoded" },
    body: form.toString(),
    signal: AbortSignal.timeout(30000),
  });
  const json = (await res.json().catch(() => null)) as
    | { message?: string; data?: { user_id?: string; user_id_str?: string } }
    | null;
  if (json?.message !== "success" || !json.data) {
    throw new Error(String(json?.message || "Gagal verifikasi & daftar akun"));
  }

  const setCookies = res.headers.getSetCookie?.() || [];
  const cookie = setCookies.map((c) => c.split(";")[0]).join("; ");
  const userId = String(json.data.user_id_str || json.data.user_id || "");
  if (!cookie) throw new Error("Sesi gak kebentuk — coba lagi");

  return { userId, cookie };
}

/** Info akun (nama, region, dsb). */
export async function getUserInfo(cookie: string): Promise<Record<string, unknown> | null> {
  try {
    const res = await fetch(`${API_BASE}/passport/web/account/info/?aid=${AID}`, {
      headers: baseHeaders(cookie),
      signal: AbortSignal.timeout(20000),
    });
    const json = (await res.json()) as { message?: string; data?: Record<string, unknown> };
    return json?.data || null;
  } catch {
    return null;
  }
}

function commerceHeaders(url: string, cookie: string): Record<string, string> {
  const ts = Math.floor(Date.now() / 1000);
  const raw = `9e2c|${url.slice(-7)}|7|12.4.0|${ts}||11ac`;
  const sign = crypto.createHash("md5").update(raw).digest("hex").toLowerCase();
  return {
    "Content-Type": "application/json",
    Accept: "application/json, text/plain, */*",
    "User-Agent": UA,
    Referer: `${API_BASE}/commerce/subscription`,
    Origin: API_BASE,
    appid: AID,
    loc: "sg",
    lan: "en",
    pf: "7",
    appvr: "12.4.0",
    "sign-ver": "1",
    "app-sdk-version": "48.0.0",
    sign,
    "device-time": String(ts),
    Cookie: cookie,
  };
}

function feedHeaders(path: string, cookie: string): Record<string, string> {
  const ts = Math.floor(Date.now() / 1000);
  const raw = `9e2c|${path.slice(-7)}|0||${ts}||11ac`;
  const sign = crypto.createHash("md5").update(raw).digest("hex");
  return {
    "Content-Type": "application/json",
    Cookie: cookie,
    sign,
    "sign-ver": "1",
    "device-time": String(ts),
    pf: "0",
    loc: "SG",
    "app-sdk-version": "100.0.0",
    "User-Agent": UA,
  };
}

/** Klaim Pro trial 7 hari (fission token + aktivasi langsung). */
export async function claimTrial7d(cookie: string): Promise<{
  success: boolean;
  steps: Array<{ action: string; success: boolean; info?: string }>;
}> {
  const steps: Array<{ action: string; success: boolean; info?: string }> = [];

  // 1. validasi aktivitas fission
  let token: string | null = null;
  try {
    const path = "/lv/v1/pc/share/is_activity_valid";
    const res = await fetch(`${FEED_API}${path}`, {
      method: "POST",
      headers: feedHeaders(path, cookie),
      body: "{}",
      signal: AbortSignal.timeout(20000),
    });
    const d = await res.json();
    steps.push({ action: "cek aktivitas trial", success: d.ret === "0" });
  } catch (e) {
    steps.push({ action: "cek aktivitas trial", success: false, info: e instanceof Error ? e.message : "gagal" });
  }

  // 2. generate token fission
  try {
    const path = "/lv/v1/pc/share/token_gen";
    const res = await fetch(`${FEED_API}${path}`, {
      method: "POST",
      headers: feedHeaders(path, cookie),
      body: "{}",
      signal: AbortSignal.timeout(20000),
    });
    const d = await res.json();
    token = d?.data?.token || null;
    steps.push({ action: "generate token undangan", success: Boolean(token) });
  } catch (e) {
    steps.push({ action: "generate token undangan", success: false, info: e instanceof Error ? e.message : "gagal" });
  }

  // 3. kunjungi link fission (klaim lewat web)
  if (token) {
    try {
      const res = await fetch(`${API_BASE}/capcut_pc_web/fission_receive?code=${encodeURIComponent(token)}&lng=en`, {
        headers: baseHeaders(cookie),
        redirect: "follow",
        signal: AbortSignal.timeout(20000),
      });
      steps.push({ action: "klaim lewat web", success: res.ok, info: `HTTP ${res.status}` });
    } catch (e) {
      steps.push({ action: "klaim lewat web", success: false, info: e instanceof Error ? e.message : "gagal" });
    }
  }

  // 4. trigger aktivasi VIP langsung
  try {
    const path = "/commerce/v1/vip/outside/start_activation";
    const res = await fetch(`${COMMERCE_API}${path}`, {
      method: "POST",
      headers: commerceHeaders(path, cookie),
      body: JSON.stringify({ aid: Number(AID), scene: "vip" }),
      signal: AbortSignal.timeout(20000),
    });
    const d = await res.json();
    steps.push({
      action: "aktivasi Pro",
      success: d.ret === "0",
      info: d.ret === "0" ? "aktif 7 hari" : String(d?.msg || d.ret || "gagal"),
    });
  } catch (e) {
    steps.push({ action: "aktivasi Pro", success: false, info: e instanceof Error ? e.message : "gagal" });
  }

  return { success: steps.some((s) => s.success && s.action === "aktivasi Pro"), steps };
}
