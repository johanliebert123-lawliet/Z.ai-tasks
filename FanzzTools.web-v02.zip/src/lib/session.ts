import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

/**
 * V2 Modern-UpdSec (#KEAMANAN-1 — celah paling kritis):
 *
 * SEBELUM: kalau env APP_SECRET tidak di-set, sistem diam-diam fallback ke
 * secret hardcoded di source code. Siapa pun yang pernah melihat repo/zip
 * bisa memalsukan token sesi siapa saja → bypass auth total.
 *
 * SEKARANG:
 *  - Dev tanpa APP_SECRET → secret dev ephemeral acak per-proses
 *    (sesi tetap nyaman dipakai lokal, TIDAK pernah dipakai di production).
 *  - Production tanpa APP_SECRET → BUILD/RUNTIME GAGAL cepat (throw).
 *    Lebih baik deploy merah daripada diam-diam memakai secret yang bocor.
 *  - Secret minimal 32 karakter — menolak secret lemah.
 */

function resolveSecret(): string {
  const env = process.env.APP_SECRET;

  if (env && env.trim()) {
    const s = env.trim();
    if (s.length < 32) {
      throw new Error(
        "[FanzzTools] APP_SECRET terlalu pendek — minimal 32 karakter. Generate dengan: openssl rand -hex 32"
      );
    }
    return s;
  }

  if (process.env.NODE_ENV === "production") {
    throw new Error(
      "[FanzzTools] APP_SECRET WAJIB di-set di production! " +
        "Generate: openssl rand -hex 32 — lalu tambahkan ke Environment Variables " +
        "(Vercel → Project → Settings → Environment Variables → APP_SECRET). " +
        "Deploy sengaja dihentikan demi keamanan sesi semua user."
    );
  }

  // dev only: secret acak per-proses (cukup untuk `next dev` lokal)
  return `dev-only-${globalThis.crypto.randomUUID()}-${globalThis.crypto.randomUUID()}`;
}

const SECRET = resolveSecret();
const key = new TextEncoder().encode(SECRET);

export const SESSION_COOKIE = "fanzz_session";
const SESSION_DAYS = 30;

export interface SessionPayload {
  uid: string;
  username: string;
  email: string;
  iat?: number;
  exp?: number;
}

export async function signSession(payload: Omit<SessionPayload, "iat" | "exp">) {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setIssuedAt()
    .setIssuer("fanzztools.v2")
    .setAudience("fanzztools.app")
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(key);
}

export async function verifySession(
  token: string
): Promise<SessionPayload | null> {
  try {
    const { payload } = await jwtVerify(token, key, {
      issuer: "fanzztools.v2",
      audience: "fanzztools.app",
      algorithms: ["HS256"],
      clockTolerance: 5,
    });
    if (
      typeof payload.uid === "string" &&
      typeof payload.username === "string" &&
      typeof payload.email === "string" &&
      payload.uid.length <= 64 &&
      payload.username.length <= 32 &&
      payload.email.length <= 120
    ) {
      return {
        uid: payload.uid,
        username: payload.username,
        email: payload.email,
      };
    }
    return null;
  } catch {
    return null;
  }
}

/** Ambil session user dari cookie (untuk API routes). */
export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token || token.length > 2048) return null;
  return verifySession(token);
}

export function sessionCookieOptions(maxAgeSeconds: number) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: maxAgeSeconds,
  };
}

export const SESSION_MAX_AGE = SESSION_DAYS * 24 * 60 * 60;
