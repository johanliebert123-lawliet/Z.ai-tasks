"use client";

/**
 * Riwayat per-tools — PERBAIKAN V0.01 (permintaan #7).
 * Setiap tools punya daftar riwayatnya sendiri, disimpan di localStorage,
 * maksimal 30 entri per tools supaya gak membengkak.
 */

export type HistoryTool =
  | "film"
  | "anime"
  | "manhwa"
  | "komik"
  | "donghua"
  | "dracin"
  | "nekopoi"
  | "books"
  | "music"
  | "downloader"
  | "lyrics"
  | "nokos"
  | "studio"
  | "hdimage"
  | "qr"
  | "kalkulator"
  | "iqtest"
  | "osint"
  /* V2.12 Security-Updt */
  | "quran"
  | "ibadah"
  | "debat"
  | "story"
  | "pm"
  /* V2.13 zuperupdt */
  | "cuaca"
  | "wifi"
  | "roda"
  | "ascii"
  /* FanzSec-Update */
  | "security"
  | "fanzsec";

export interface HistoryEntry {
  id: string;
  title: string;
  subtitle?: string;
  poster?: string | null;
  url?: string;
  /** data bebas per-tools (mis. episode, chapter, penyanyi) */
  extra?: Record<string, unknown>;
  at: number;
}

const KEY = "fanzz_history_v1";
const MAX_PER_TOOL = 30;

const TOOL_LABELS: Record<HistoryTool, string> = {
  film: "Film",
  anime: "Anime",
  manhwa: "Manhwa",
  komik: "Komik (ComicVerse)",
  donghua: "Donghua",
  dracin: "Dracin (Drama Asia)",
  nekopoi: "Nekopoi 21+",
  books: "Buku",
  music: "Musik",
  downloader: "Downloader",
  lyrics: "Lirik Lagu",
  nokos: "Gacha Nokos",
  studio: "Studio Gambar",
  hdimage: "Image HD",
  qr: "QR Studio",
  kalkulator: "Kalkulator",
  iqtest: "Tes IQ",
  osint: "OSINT",
  /* V2.12 Security-Updt */
  quran: "Qur'an Digital",
  ibadah: "Ruang Ibadah",
  debat: "Debat Filosofis AI",
  story: "FanzzStory",
  pm: "Parent Monitor",
  /* V2.13 zuperupdt */
  cuaca: "Cuaca Live",
  wifi: "Check WiFi Sekitar",
  roda: "Roda Nama",
  ascii: "ASCII Art",
  security: "FanzzSecurity",
  fanzsec: "FanzSec.Ai",
};

export const HISTORY_TOOLS: Array<{ id: HistoryTool; label: string }> = (
  Object.keys(TOOL_LABELS) as HistoryTool[]
).map((id) => ({ id, label: TOOL_LABELS[id] }));

type Store = Partial<Record<HistoryTool, HistoryEntry[]>>;

function read(): Store {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const d = JSON.parse(raw);
    return d && typeof d === "object" ? (d as Store) : {};
  } catch {
    return {};
  }
}

function write(s: Store) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* penuh — biarkan */
  }
}

/** Tambah entri riwayat untuk sebuah tools (dedupe by id, terbaru duluan). */
export function pushHistory(tool: HistoryTool, entry: Omit<HistoryEntry, "at">) {
  if (typeof window === "undefined") return;
  const s = read();
  const list = (s[tool] || []).filter((e) => e.id !== entry.id);
  list.unshift({ ...entry, at: Date.now() });
  s[tool] = list.slice(0, MAX_PER_TOOL);
  write(s);
}

/** Ambil riwayat satu tools (terbaru duluan). */
export function getHistory(tool: HistoryTool): HistoryEntry[] {
  if (typeof window === "undefined") return [];
  return read()[tool] || [];
}

/** Hapus satu entri. */
export function removeHistory(tool: HistoryTool, id: string) {
  const s = read();
  s[tool] = (s[tool] || []).filter((e) => e.id !== id);
  write(s);
}

/** Kosongkan riwayat satu tools. */
export function clearHistory(tool: HistoryTool) {
  const s = read();
  delete s[tool];
  write(s);
}

/** Kosongkan semua riwayat semua tools. */
export function clearAllHistory() {
  try {
    localStorage.removeItem(KEY);
  } catch {
    /* ignore */
  }
}

export function fmtHistoryTime(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "baru saja";
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  if (s < 7 * 86400) return `${Math.floor(s / 86400)} hari lalu`;
  return new Date(ts).toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
}
