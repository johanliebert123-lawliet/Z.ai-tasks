/**
 * APK Builder — generate APK dari HTML/ZIP secara client-side.
 *
 * Arsitektur:
 * 1. Template resmi (template.apk) berisi classes.dex WebView wrapper.
 * 2. String "app_name" (UTF-8 pool di resources.arsc) + package name
 *    (UTF-16 pool di AndroidManifest.xml) di-patch in-place dengan
 *    placeholder ber-panjang tetap.
 * 3. Icon mipmap-* diganti PNG hasil resize canvas.
 * 4. assets/index.html (atau isi ZIP user) dimasukkan.
 * 5. Di-repack jadi APK + JAR signing v1 (MANIFEST.MF, CERT.SF, CERT.RSA
 *    PKCS#7 via node-forge) — kompatibel targetSdk 29.
 */

import * as fflate from "fflate";
import forge from "node-forge";

export interface ApkIcons {
  mdpi: Uint8Array;
  hdpi: Uint8Array;
  xhdpi: Uint8Array;
  xxhdpi: Uint8Array;
  xxxhdpi: Uint8Array;
}

export interface BuildApkOptions {
  /** File HTML utama ATAU isi zip user */
  files: Array<{ path: string; data: Uint8Array }>;
  /** Nama tampilan aplikasi (launcher label) */
  appName: string;
  /** Icon per density (PNG bytes) */
  icons: ApkIcons;
  /** Template APK bytes (material signing kini server-side) */
  template: Uint8Array;
  /** @deprecated FanzSec-Update: signing dilakukan server-side (/api/apk/sign) */
  certPem?: string;
  /** @deprecated FanzSec-Update: signing dilakukan server-side (/api/apk/sign) */
  keyPem?: string;
  /** Progress callback */
  onProgress?: (msg: string) => void;
}

/* ============ 1. Patch String Pool ============ */

/** Patch string pool UTF-8: ganti placeholder dengan replacement yang
 *  byte-length-nya dipatok sama dengan placeholder (padding spasi). */
function patchUtf8Pool(buf: Uint8Array, placeholder: string, replacement: string): boolean {
  const bytes = new TextEncoder();
  const phBytes = bytes.encode(placeholder);
  const phLen = phBytes.length;
  if (phLen >= 128) throw new Error("placeholder terlalu panjang");

  // cari semua kemunculan
  let found = false;
  outer: for (let i = 0; i < buf.length - phLen - 2; i++) {
    for (let j = 0; j < phLen; j++) {
      if (buf[i + j] !== phBytes[j]) continue outer;
    }
    // cek varint lengths sebelum string: [l16][byteLen]
    if (buf[i - 1] !== phLen || buf[i - 2] !== phLen) continue;

    // susun replacement: truncate ke phLen bytes lalu pad spasi
    let rep = "";
    let bl = 0;
    for (const ch of replacement) {
      const cl = bytes.encode(ch).length;
      if (bl + cl > phLen) break;
      rep += ch;
      bl += cl;
    }
    while (bl < phLen) {
      rep += " ";
      bl += 1;
    }
    const repBytes = bytes.encode(rep);
    const u16len = [...rep].length; // jumlah unit UTF-16
    if (u16len >= 128 || repBytes.length !== phLen) continue;

    buf[i - 2] = u16len;
    buf[i - 1] = phLen; // byte length tetap
    buf.set(repBytes, i);
    found = true;
    break;
  }
  return found;
}

/** Patch string pool UTF-16: char-length dipatok sama (padding 'x'). */
function patchUtf16Pool(buf: Uint8Array, placeholder: string, replacement: string): boolean {
  const enc = new TextEncoder();
  const phUnits = [...placeholder].length;
  const phBytes = new Uint16Array(phUnits);
  {
    const tmp = enc.encode(placeholder);
    const dv = new DataView(tmp.buffer, tmp.byteOffset, tmp.byteLength);
    // encode placeholder ke UTF-16LE manual (pasti ASCII di praktik kita)
    for (let i = 0; i < phUnits; i++) phBytes[i] = placeholder.charCodeAt(i);
    void dv;
  }
  if (phUnits >= 0x8000) throw new Error("placeholder terlalu panjang");

  // normalisasi replacement ke unit UTF-16 maks phUnits
  const units: number[] = [];
  for (const ch of replacement) {
    const cp = ch.codePointAt(0)!;
    if (cp > 0xffff) {
      // surrogate pair
      const h = Math.floor((cp - 0x10000) / 0x400) + 0xd800;
      const l = ((cp - 0x10000) % 0x400) + 0xdc00;
      units.push(h, l);
    } else units.push(cp);
    if (units.length >= phUnits) break;
  }
  while (units.length < phUnits) units.push("x".charCodeAt(0));
  const u16len = units.length;

  // cari: u16 length (2 byte LE, atau 4 byte kalau >= 0x8000) + bytes UTF-16LE + null
  let found = false;
  outer: for (let i = 2; i < buf.length - phUnits * 2 - 2; i++) {
    // cek length prefix (1 unit)
    const len = buf[i] | (buf[i + 1] << 8);
    if (len !== phUnits || len & 0x8000) continue;
    for (let j = 0; j < phUnits; j++) {
      const v = buf[i + 2 + j * 2] | (buf[i + 3 + j * 2] << 8);
      if (v !== phBytes[j]) continue outer;
    }
    // tulis replacement
    for (let j = 0; j < phUnits; j++) {
      buf[i + 2 + j * 2] = units[j] & 0xff;
      buf[i + 3 + j * 2] = (units[j] >> 8) & 0xff;
    }
    found = true;
    break;
  }
  void u16len;
  return found;
}

/* ============ 2. JAR Signing (v1) ============ */

/* ============ 1b. PERBAIKAN CRASH V0.01 (#16): rebuild string pool manifest ============ */

/**
 * AKAR MASALAH "APK kepental sendiri":
 * Template dex berisi kelas com.fanzz.webapp.MainActivity, sedangkan manifest
 * di-patch package-nya jadi com.fanzz.webapp.<nama-app>. Activity ".MainActivity"
 * (relatif) lalu dicari di package BARU → kelas tidak ketemu → aplikasi
 * langsung force-close saat dibuka.
 *
 * Solusi: bangun ulang string pool manifest supaya activity memakai nama
 * ABSOLUT (com.fanzz.webapp.MainActivity) — panjang string bebas karena pool
 * ditulis ulang penuh (offset & size dihitung ulang; urutan string tetap
 * sehingga indeks yang direferensikan elemen XML tidak berubah).
 */
export function rebuildManifestPool(
  man: Uint8Array,
  replacements: Record<string, string>
): Uint8Array | null {
  try {
    const dv = new DataView(man.buffer, man.byteOffset, man.byteLength);
    // header file: magic(4) + filesize(4)
    // pool chunk mulai di offset 8
    if (dv.getUint16(8, true) !== 0x0001) return null; // bukan string pool
    const strCount = dv.getUint32(16, true);
    const flags = dv.getUint32(24, true);
    const stringsStart = dv.getUint32(28, true);
    if (flags & 0x100) return null; // UTF-8 pool — template kita UTF-16
    if (strCount === 0 || strCount > 4096) return null;

    // baca semua string UTF-16 (offset relatif ke stringsStart, dari awal chunk)
    const poolBase = 8;
    const offsets: number[] = [];
    for (let i = 0; i < strCount; i++) offsets.push(dv.getUint32(poolBase + 28 + i * 4, true));

    const strings: string[] = offsets.map((off) => {
      const p = poolBase + stringsStart + off;
      let len = dv.getUint16(p, true);
      let q = p + 2;
      if (len & 0x8000) {
        const hi = dv.getUint16(q, true);
        q += 2;
        len = ((len & 0x7fff) << 16) | hi;
      }
      let s = "";
      for (let k = 0; k < len; k++) {
        s += String.fromCharCode(dv.getUint16(q + k * 2, true));
      }
      return s;
    });

    // terapkan penggantian (indeks tetap)
    let changed = 0;
    for (let i = 0; i < strings.length; i++) {
      const rep = replacements[strings[i]];
      if (rep !== undefined && rep !== strings[i]) {
        strings[i] = rep;
        changed++;
      }
    }
    if (!changed) return man;

    // bangun data string baru: [u16 len][utf16le][null]
    const enc = new TextEncoder();
    const chunks: Uint8Array[] = [];
    const newOffsets: number[] = [];
    let cursor = 0;
    for (const s of strings) {
      newOffsets.push(cursor);
      const units: number[] = [];
      for (const ch of s) units.push(ch.charCodeAt(0));
      const buf = new Uint8Array(2 + units.length * 2 + 2);
      const bdv = new DataView(buf.buffer);
      if (units.length >= 0x8000) {
        bdv.setUint16(0, 0x8000 | ((units.length >> 16) & 0x7fff), true);
        bdv.setUint16(2, units.length & 0xffff, true);
        for (let k = 0; k < units.length; k++) bdv.setUint16(4 + k * 2, units[k], true);
      } else {
        bdv.setUint16(0, units.length, true);
        for (let k = 0; k < units.length; k++) bdv.setUint16(2 + k * 2, units[k], true);
      }
      chunks.push(buf);
      cursor += buf.length;
    }
    // pad data string ke kelipatan 4
    const padLen = (4 - (cursor % 4)) % 4;
    if (padLen) chunks.push(new Uint8Array(padLen));
    cursor += padLen;

    // header pool baru
    const headerSize = 28;
    const offsetsBytes = strCount * 4;
    const newStringsStart = headerSize + offsetsBytes;
    const poolSize = newStringsStart + cursor;
    const rest = man.subarray(poolBase + /* poolSize lama */ dv.getUint32(12, true));

    const total = 8 + poolSize + rest.length;
    const out = new Uint8Array(total);
    const odv = new DataView(out.buffer);
    // file header: magic + ukuran baru
    odv.setUint32(0, dv.getUint32(0, true), true);
    odv.setUint32(4, total, true);
    // pool chunk header
    let o = 8;
    odv.setUint16(o, 0x0001, true); // type
    odv.setUint16(o + 2, headerSize, true);
    odv.setUint32(o + 4, poolSize, true);
    odv.setUint32(o + 8, strCount, true); // stringCount
    odv.setUint32(o + 12, 0, true); // styleCount
    odv.setUint32(o + 16, 0, true); // flags (UTF-16, tidak sorted)
    odv.setUint32(o + 20, newStringsStart, true);
    odv.setUint32(o + 24, 0, true); // stylesStart
    o += headerSize;
    for (let i = 0; i < strCount; i++) {
      odv.setUint32(o + i * 4, newOffsets[i], true);
    }
    o += offsetsBytes;
    for (const c of chunks) {
      out.set(c, o);
      o += c.length;
    }
    out.set(rest, 8 + poolSize);
    return out;
  } catch {
    return null;
  }
}

/** Kelas activity asli di dalam dex template. */
export const TEMPLATE_ACTIVITY = "com.fanzz.webapp.MainActivity";

/** HTML pembungkus untuk mode APK dari LINK (permintaan #16) — redirect ke URL. */
export function buildUrlWrapperHtml(url: string, appName: string): string {
  const safe = url.replace(/"/g, "%22");
  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${appName.replace(/[<>&]/g, "")}</title>
<meta http-equiv="refresh" content="0; url=${safe}">
<style>
  html,body{margin:0;height:100%;background:#0e1116;color:#e6e9ef;font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;text-align:center}
  .s{max-width:420px;padding:24px}
  .r{width:46px;height:46px;border-radius:50%;border:3px solid #ffffff22;border-top-color:#7c5cff;animation:spin 0.9s linear infinite;margin:0 auto 16px}
  @keyframes spin{to{transform:rotate(360deg)}}
  b{color:#9db1ff}
</style>
</head>
<body>
<div class="s">
<div class="r"></div>
<p>Memuat <b>${appName.replace(/[<>&]/g, "")}</b>…</p>
<p style="font-size:12px;opacity:.6">Aplikasi ini membuka tautan yang Anda pilih.</p>
</div>
<script>try{location.replace(${JSON.stringify(url)});}catch(e){}</script>
</body>
</html>
`;
}

const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

export function b64encode(bytes: Uint8Array): string {
  let out = "";
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
    const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
    out += B64[b0 >> 2];
    out += B64[((b0 & 3) << 4) | (b1 >> 4)];
    out += i + 1 < bytes.length ? B64[((b1 & 15) << 2) | (b2 >> 6)] : "=";
    out += i + 2 < bytes.length ? B64[b2 & 63] : "=";
  }
  return out;
}

export async function sha256(bytes: Uint8Array): Promise<Uint8Array> {
  const d = await crypto.subtle.digest("SHA-256", bytes as unknown as ArrayBuffer);
  return new Uint8Array(d);
}

/** Bungkus satu header logical line ke physical lines ≤ 72 byte.
 *  Kelanjutan baris diawali satu spasi (spec JAR manifest). */
const sharedDecoder = new TextDecoder();
export function wrapLine(line: string): string {
  const bytes = new TextEncoder().encode(line);
  if (bytes.length <= 72) return line + "\r\n";
  let out = "";
  let start = 0;
  let first = true;
  while (start < bytes.length) {
    let end = Math.min(start + (first ? 72 : 71), bytes.length);
    // jangan potong di tengah karakter UTF-8
    while (end > start && end < bytes.length && (bytes[end] & 0xc0) === 0x80) end--;
    const chunk = sharedDecoder.decode(bytes.slice(start, end));
    out += (first ? "" : " ") + chunk + "\r\n";
    first = false;
    start = end;
  }
  return out;
}

interface JarSignResult {
  manifestMf: Uint8Array;
  certSf: Uint8Array;
  certRsa: Uint8Array;
}

/** Hitung MANIFEST.MF + CERT.SF (hanya digest — bukan rahasia).
 *  FanzSec-Update: bagian ini aman di klien. CERT.RSA dibuat di server. */
export async function jarSignApkDigests(
  entries: Array<{ name: string; data: Uint8Array }>
): Promise<Pick<JarSignResult, "manifestMf" | "certSf">> {
  // 1) MANIFEST.MF
  let mf = wrapLine("Manifest-Version: 1.0") + wrapLine("Created-By: 1.0 (Android)");
  const sections: Array<{ name: string; section: string }> = [];
  for (const e of entries) {
    const digest = b64encode(await sha256(e.data));
    const section =
      wrapLine(`Name: ${e.name}`) + wrapLine(`SHA-256-Digest: ${digest}`) + "\r\n";
    sections.push({ name: e.name, section });
    mf += "\r\n" + section;
  }
  const mfBytes = new TextEncoder().encode(mf);

  // 2) CERT.SF
  let sf =
    wrapLine("Signature-Version: 1.0") +
    wrapLine("Created-By: 1.0 (Android)") +
    wrapLine(`SHA-256-Digest-Manifest: ${b64encode(await sha256(mfBytes))}`);
  for (const sec of sections) {
    const sectionDigest = b64encode(await sha256(new TextEncoder().encode(sec.section)));
    sf += "\r\n" + wrapLine(`Name: ${sec.name}`) + wrapLine(`SHA-256-Digest: ${sectionDigest}`);
  }
  const sfBytes = new TextEncoder().encode(sf);
  return { manifestMf: mfBytes, certSf: sfBytes };
}

/** Buat CERT.RSA (PKCS#7 detached) — HANYA dipanggil server-side.
 *  Private key tidak pernah menyentuh browser. */
export function jarSignCertRsa(sfBytes: Uint8Array, certPem: string, keyPem: string): Uint8Array {
  const cert = forge.pki.certificateFromPem(certPem);
  const key = forge.pki.privateKeyFromPem(keyPem);
  const p7 = forge.pkcs7.createSignedData();
  p7.content = forge.util.createBuffer(sfBytes as unknown as string);
  p7.addCertificate(cert);
  p7.addSigner({
    key,
    certificate: cert,
    digestAlgorithm: forge.pki.oids.sha256,
    authenticatedAttributes: [],
  });
  p7.sign({ detached: true });
  const der = forge.asn1.toDer(p7.toAsn1()).getBytes();
  const rsaBytes = new Uint8Array(der.length);
  for (let i = 0; i < der.length; i++) rsaBytes[i] = der.charCodeAt(i);
  return rsaBytes;
}

/* ============ 3. Sanitize package name ============ */

export function buildPackageName(appName: string): string {
  let clean = appName
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "")
    .slice(0, 22);
  if (!clean || /^[0-9]/.test(clean)) clean = "app" + clean;
  let pkg = "com.fanzz.webapp." + clean;
  // pad dengan 'x' ke total 48 char (panjang placeholder di manifest)
  while (pkg.length < 48) pkg += "x";
  return pkg.slice(0, 48);
}

/** V2.12 Security-Updt: package name khusus companion Parent Monitor —
 *  prefix berbeda dari webapp biasa agar tidak bentrok dengan APK user. */
export function buildPmPackageName(appName: string): string {
  let clean = appName
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "")
    .slice(0, 24);
  if (!clean || /^[0-9]/.test(clean)) clean = "familysafety" + clean;
  let pkg = "com.fanzz.familysafety." + clean;
  while (pkg.length < 48) pkg += "x";
  return pkg.slice(0, 48);
}

/* ============ 3b. ZIP writer ter-align (gaya zipalign) ============ */

/**
 * FIX CRASH: resources.arsc yang STORED harus mulai di offset kelipatan 4.
 * Writer ini menyisipkan extra-field padding persis seperti zipalign, jadi
 * APK-nya gak crash di Android 11+ (sebelumnya pakai fflate.zipSync yang
 * tidak menjamin alignment → app langsung force close saat dibuka).
 */

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? (0xedb88320 ^ (c >>> 1)) >>> 0 : (c >>> 1) >>> 0;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = (CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)) >>> 0;
  return (c ^ 0xffffffff) >>> 0;
}

export interface ZipEntrySpec {
  name: string;
  data: Uint8Array;
  /** 0 = STORE (tanpa kompresi), >0 = DEFLATE level */
  level: number;
  /** align kan data ke 4 byte (wajib untuk entry STORED) */
  align4?: boolean;
}

function u16(v: number): Uint8Array {
  return new Uint8Array([v & 0xff, (v >>> 8) & 0xff]);
}
function u32(v: number): Uint8Array {
  return new Uint8Array([v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff]);
}

export function buildAlignedZip(entries: ZipEntrySpec[]): Uint8Array {
  const enc = new TextEncoder();
  const parts: Uint8Array[] = [];
  const central: Uint8Array[] = [];
  let offset = 0;

  // timestamp DOS tetap (build time)
  const now = new Date();
  const dosTime =
    ((now.getHours() & 0x1f) << 11) |
    ((now.getMinutes() & 0x3f) << 5) |
    ((now.getSeconds() / 2) & 0x1f);
  const dosDate =
    (((now.getFullYear() - 1980) & 0x7f) << 9) |
    (((now.getMonth() + 1) & 0xf) << 5) |
    (now.getDate() & 0x1f);

  const push = (chunk: Uint8Array) => {
    parts.push(chunk);
    offset += chunk.length;
  };

  for (const e of entries) {
    const nameBytes = enc.encode(e.name);
    const stored = e.level === 0;
    const data = stored
      ? e.data
      : fflate.deflateSync(e.data, { level: (Math.max(1, Math.min(9, e.level)) as 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9) });
    const crc = crc32(e.data);
    const method = stored ? 0 : 8;

    // hitung padding alignment: data start = offset + 30 + nameLen + extraLen
    let extraBytes: Uint8Array | null = null;
    if (stored && e.align4 !== false) {
      const dataStart = offset + 30 + nameBytes.length;
      const rem = (4 - (dataStart % 4)) % 4;
      if (rem > 0) {
        // extra field butuh minimal 4 byte (id 2 + size 2) → geser total 4+rem
        const total = rem + 4;
        extraBytes = new Uint8Array(total);
        extraBytes[0] = 0x86; // id 0x1986 (placeholder alignment)
        extraBytes[1] = 0x19;
        extraBytes[2] = (total - 4) & 0xff;
        extraBytes[3] = ((total - 4) >> 8) & 0xff;
      }
    }

    // ---- local file header ----
    const header: Uint8Array[] = [
      u32(0x04034b50),
      u16(20), // version needed
      u16(0), // flags (nama ASCII)
      u16(method),
      u16(dosTime),
      u16(dosDate),
      u32(crc),
      u32(data.length),
      u32(e.data.length),
      u16(nameBytes.length),
      u16(extraBytes ? extraBytes.length : 0),
      nameBytes,
      ...(extraBytes ? [extraBytes] : []),
    ];
    const lfhLen = 30 + nameBytes.length + (extraBytes ? extraBytes.length : 0);

    // catat offset entry ini (sebelum push)
    const entryOffset = offset;
    for (const h of header) push(h);
    push(data);

    // ---- central directory record ----
    central.push(
      concat([
        u32(0x02014b50),
        u16(20), // version made by
        u16(20), // version needed
        u16(0), // flags
        u16(method),
        u16(dosTime),
        u16(dosDate),
        u32(crc),
        u32(data.length),
        u32(e.data.length),
        u16(nameBytes.length),
        u16(0), // extra len (cd)
        u16(0), // comment len
        u16(0), // disk start
        u16(0), // internal attrs
        u32(0), // external attrs
        u32(entryOffset),
        nameBytes,
      ])
    );
    void lfhLen;
  }

  const cdOffset = offset;
  let cdSize = 0;
  for (const c of central) cdSize += c.length;
  for (const c of central) push(c);

  // ---- EOCD ----
  push(
    concat([
      u32(0x06054b50),
      u16(0),
      u16(0),
      u16(entries.length),
      u16(entries.length),
      u32(cdSize),
      u32(cdOffset),
      u16(0),
    ])
  );

  return concat(parts);
}

function concat(chunks: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const c of chunks) total += c.length;
  const out = new Uint8Array(total);
  let p = 0;
  for (const c of chunks) {
    out.set(c, p);
    p += c.length;
  }
  return out;
}

/* ============ 4. Builder utama ============ */

const PLACEHOLDER_NAME = "M".repeat(40);
const PLACEHOLDER_PKG = "com.fanzz.webapp." + "x".repeat(32); // 48 char

export async function buildApk(opts: BuildApkOptions): Promise<Uint8Array> {
  const { onProgress } = opts;
  const say = (m: string) => onProgress?.(m);

  say("Membuka template…");
  const entries = fflate.unzipSync(opts.template);

  // patch resources.arsc (app_name)
  const arsc = entries["resources.arsc"];
  if (!arsc) throw new Error("Template rusak: resources.arsc tidak ada");
  say("Menyetel nama aplikasi…");
  if (!patchUtf8Pool(arsc, PLACEHOLDER_NAME, opts.appName)) {
    throw new Error("Gagal menyetel nama aplikasi (patch arsc gagal)");
  }

  // patch AndroidManifest.xml (package + activity absolut)
  // PERBAIKAN V0.01 (#16): manifest dibangun ulang supaya activity menunjuk ke
  // kelas ASLI di dex (com.fanzz.webapp.MainActivity). Dulu ".MainActivity"
  // relatif ke package hasil patch → kelas tidak ditemukan → APK force-close.
  const man = entries["AndroidManifest.xml"];
  if (!man) throw new Error("Template rusak: AndroidManifest.xml tidak ada");
  const pkg = buildPackageName(opts.appName);
  say("Menyiapkan package & activity…");
  const manFixed = rebuildManifestPool(man, {
    [PLACEHOLDER_PKG]: pkg,
    ".MainActivity": TEMPLATE_ACTIVITY,
  });
  let finalMan: Uint8Array;
  if (manFixed) {
    finalMan = manFixed;
  } else {
    // cadangan: cara lama (patch panjang tetap)
    const manOld = new Uint8Array(man);
    if (!patchUtf16Pool(manOld, PLACEHOLDER_PKG, pkg)) {
      throw new Error("Gagal menyetel package name");
    }
    finalMan = manOld;
  }

  // susun daftar file final — resources.arsc duluan (offset awal = 44, kelipatan 4)
  const files: Array<{ name: string; data: Uint8Array }> = [];

  // resources.arsc STORED (uncompressed) + 4-byte aligned
  files.push({ name: "resources.arsc", data: arsc });

  files.push({ name: "AndroidManifest.xml", data: finalMan });

  // classes.dex dari template
  const dex = entries["classes.dex"];
  if (!dex) throw new Error("Template rusak: classes.dex tidak ada");
  files.push({ name: "classes.dex", data: dex });

  // icons
  say("Memasang icon…");
  const iconMap: Record<keyof ApkIcons, string> = {
    mdpi: "res/mipmap-mdpi-v4/ic_launcher.png",
    hdpi: "res/mipmap-hdpi-v4/ic_launcher.png",
    xhdpi: "res/mipmap-xhdpi-v4/ic_launcher.png",
    xxhdpi: "res/mipmap-xxhdpi-v4/ic_launcher.png",
    xxxhdpi: "res/mipmap-xxxhdpi-v4/ic_launcher.png",
  };
  (Object.keys(iconMap) as Array<keyof ApkIcons>).forEach((k) => {
    files.push({ name: iconMap[k], data: opts.icons[k] });
  });

  // assets user
  say("Memasukkan file web…");
  for (const f of opts.files) {
    const safe = f.path.replace(/^\/+/, "").replace(/\.\.(\/|$)/g, "");
    if (!safe) continue;
    files.push({ name: "assets/" + safe, data: f.data });
  }

  // FanzSec-Update: private key TIDAK lagi dikirim ke browser.
  // MANIFEST.MF + CERT.SF hanyalah daftar digest (publik, bukan rahasia) dan
  // tetap dihitung di klien. CERT.RSA (tanda tangan PKCS#7 yang butuh private
  // key) dibuat SERVER-SIDE lewat /api/apk/sign — key lama di public/ dianggap
  // TERKOMPROMI dan sudah dihapus.
  say("Menyiapkan berkas digest tanda tangan…");
  const sig = await jarSignApkDigests(files);

  // gabungkan jadi zip final — pakai writer ter-align 4 byte (anti crash Android 11+)
  say("Mengemas APK (belum bertanda)…");
  const finalEntries: Array<{ name: string; data: Uint8Array; level: number }> = [
    { name: "META-INF/MANIFEST.MF", data: sig.manifestMf, level: 6 },
    { name: "META-INF/CERT.SF", data: sig.certSf, level: 6 },
    ...files.map((f) => ({
      name: f.name,
      data: f.data,
      level: f.name === "resources.arsc" ? 0 : 6,
    })),
  ];

  const out = buildAlignedZip(finalEntries);
  say("APK siap! 🎉");
  return out;
}

/* ============ 5. Helper baca zip user ============ */

/** Terima file HTML atau ZIP dari user; balikan daftar path+data. */
export async function readUserFiles(file: File): Promise<Array<{ path: string; data: Uint8Array }>> {
  const name = file.name.toLowerCase();
  const buf = new Uint8Array(await file.arrayBuffer());

  if (name.endsWith(".zip")) {
    const unzipped = fflate.unzipSync(buf);
    const out: Array<{ path: string; data: Uint8Array }> = [];
    let hasIndex = false;
    for (const [path, data] of Object.entries(unzipped)) {
      if (path.endsWith("/")) continue;
      const safe = path.replace(/^\/+/, "");
      if (!safe || safe.startsWith("__MACOSX") || safe.includes("/.git/")) continue;
      if (safe === "index.html" || safe.endsWith("/index.html")) hasIndex = true;
      out.push({ path: safe, data });
    }
    if (!out.length) throw new Error("ZIP kosong atau tidak terbaca");
    if (!hasIndex) {
      // cari html pertama sebagai index
      const firstHtml = out.find((f) => f.path.toLowerCase().endsWith(".html") || f.path.toLowerCase().endsWith(".htm"));
      if (firstHtml) {
        out.push({
          path: "index.html",
          data: firstHtml.data,
        });
      } else {
        throw new Error("ZIP tidak punya file .html sama sekali");
      }
    }
    return out;
  }

  // file tunggal html
  const base = file.name.replace(/\.(html?|zip)$/i, "") || "index";
  return [{ path: "index.html", data: buf }];
}

/** Resize icon ke 5 density via canvas — support SEMUA format gambar yang bisa
 * dibaca browser (jpg, png, webp, gif, bmp, avif, heic, …) dengan fallback
 * decode via <img> untuk format yang tidak didukung createImageBitmap. */
export async function resizeIcons(
  imageFile: File
): Promise<ApkIcons> {
  // metode 1: createImageBitmap (cepat, mayoritas format)
  let bitmap: ImageBitmap | HTMLImageElement | null = null;
  try {
    bitmap = await createImageBitmap(imageFile);
  } catch {
    // metode 2: decode via <img> object URL (cover format langka)
    bitmap = await new Promise<HTMLImageElement | null>((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => resolve(null);
      img.src = URL.createObjectURL(imageFile);
    }).then((img) => {
      if (img?.src.startsWith("blob:")) URL.revokeObjectURL(img.src);
      return img;
    });
  }
  if (!bitmap || !(bitmap.width > 0) || !(bitmap.height > 0)) {
    throw new Error("Icon gak kebaca — coba format lain (jpg/png/webp)");
  }

  const bw = bitmap.width;
  const bh = bitmap.height;
  const sizes: Record<keyof ApkIcons, number> = {
    mdpi: 48,
    hdpi: 72,
    xhdpi: 96,
    xxhdpi: 144,
    xxxhdpi: 192,
  };
  const result = {} as ApkIcons;
  for (const [dpi, size] of Object.entries(sizes) as Array<[keyof ApkIcons, number]>) {
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d")!;
    // square-crop tengah
    const side = Math.min(bw, bh);
    ctx.drawImage(
      bitmap,
      (bw - side) / 2,
      (bh - side) / 2,
      side,
      side,
      0,
      0,
      size,
      size
    );
    const blob = await new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("toBlob gagal"))), "image/png");
    });
    result[dpi] = new Uint8Array(await blob.arrayBuffer());
  }
  if (typeof (bitmap as ImageBitmap).close === "function") {
    (bitmap as ImageBitmap).close();
  }
  return result;
}
