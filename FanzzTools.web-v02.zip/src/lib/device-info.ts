"use client";

/**
 * Info perangkat + baterai + lokasi (real-time).
 * - Device: OS, model (UA / userAgentData) + nama marketing via /api/device/lookup
 * - Battery: navigator.getBattery dengan event listener real-time
 * - Location: Geolocation API (izin) → reverse geocode via /api/geo/reverse;
 *   kalau ditolak → estimasi via ipwho.is (berbasis IP)
 */

export interface BatteryState {
  level: number; // 0-1
  charging: boolean;
  supported: boolean;
}

export interface DeviceState {
  os: string; // "Android 14"
  osName: string; // "Android"
  browser: string; // "Chrome 131"
  modelCode: string; // "V2414" / "SM-A155F" / "iPhone"
  modelName: string; // "Vivo Y18i" (marketing, dari DB) atau fallback
  screen: string; // "1080×2400"
  cores?: number;
  memory?: number; // GB (deviceMemory)
  network?: string;
  language: string;
  timezone: string;
}

export interface GeoState {
  mode: "gps" | "estimasi" | "loading";
  lat: number;
  lon: number;
  accuracy?: number;
  kecamatan?: string;
  kelurahan?: string;
  kota?: string;
  kabupaten?: string;
  provinsi?: string;
  negara?: string;
  countryCode?: string;
  postcode?: string;
  display?: string;
  ip?: string;
}

/* ---------------- Baterai ---------------- */

export async function watchBattery(
  onUpdate: (b: BatteryState) => void
): Promise<() => void> {
  interface BatteryManager extends EventTarget {
    level: number;
    charging: boolean;
    addEventListener(type: string, l: () => void): void;
  }
  const nav = navigator as Navigator & { getBattery?: () => Promise<BatteryManager> };
  if (!nav.getBattery) {
    onUpdate({ level: -1, charging: false, supported: false });
    return () => {};
  }
  try {
    const bat = await nav.getBattery();
    const emit = () =>
      onUpdate({ level: bat.level, charging: bat.charging, supported: true });
    emit();
    const handlers = ["levelchange", "chargingchange", "chargingtimechange", "dischargingtimechange"];
    handlers.forEach((h) => bat.addEventListener(h, emit));
    return () => handlers.forEach((h) => bat.removeEventListener(h, emit));
  } catch {
    onUpdate({ level: -1, charging: false, supported: false });
    return () => {};
  }
}

/* ---------------- Perangkat ---------------- */

function parseUA(): { os: string; osName: string; browser: string; modelCode: string } {
  const ua = navigator.userAgent;

  // model Android: segmen sebelum "; Build/"
  let modelCode = "";
  const m = ua.match(/Android[^;]*;\s*([^;)]+?)\s*(?:Build\/|\))/i);
  if (m && !/^\s*$/.test(m[1])) {
    let cand = m[1].trim();
    // buang prefix "K)" (masked UA: "Android 10; K")
    if (cand === "K" || /^(?:[A-Z]{1,2})$/.test(cand)) cand = "";
    // UA desktop-mode / K: kosong
    modelCode = cand;
  }

  // OS
  let os = "Tidak dikenal";
  let osName = "Web";
  const andVer = ua.match(/Android\s+([\d.]+)/i);
  const iosVer = ua.match(/(?:iPhone\s+OS|CPU\s+iPhone\s+OS)\s+([\d_]+)/i);
  if (andVer) {
    os = `Android ${andVer[1]}`;
    osName = "Android";
    if (!modelCode) modelCode = "";
  } else if (iosVer) {
    os = `iOS ${iosVer[1].replace(/_/g, ".")}`;
    osName = "iOS";
    modelCode = ua.match(/iPhone\d+,\d+/)?.[0] || "iPhone";
  } else if (/Windows/i.test(ua)) {
    os = "Windows";
    osName = "Windows";
  } else if (/Mac OS X/i.test(ua)) {
    os = "macOS";
    osName = "macOS";
  } else if (/Linux/i.test(ua)) {
    os = "Linux";
    osName = "Linux";
  }

  // browser
  let browser = "Browser";
  const yandex = ua.match(/YaBrowser\/([\d.]+)/i);
  const chrome = ua.match(/Chrome\/([\d.]+)/i);
  const samsung = ua.match(/SamsungBrowser\/([\d.]+)/i);
  const firefox = ua.match(/Firefox\/([\d.]+)/i);
  const safari = ua.match(/Version\/([\d.]+).*Safari/i);
  const edge = ua.match(/Edg(?:e|A|iOS)?\/([\d.]+)/i);
  const opera = ua.match(/OPR\/([\d.]+)/i);
  if (opera) browser = `Opera ${opera[1].split(".")[0]}`;
  else if (samsung) browser = `Samsung Internet ${samsung[1].split(".")[0]}`;
  else if (yandex) browser = `Yandex ${yandex[1].split(".")[0]}`;
  else if (edge) browser = `Edge ${edge[1].split(".")[0]}`;
  else if (firefox) browser = `Firefox ${firefox[1].split(".")[0]}`;
  else if (chrome) browser = `Chrome ${chrome[1].split(".")[0]}`;
  else if (safari) browser = `Safari ${safari[1].split(".")[0]}`;

  return { os, osName, browser, modelCode };
}

export async function getDeviceInfo(): Promise<DeviceState> {
  const { os, osName, browser, modelCode } = parseUA();
  let model = modelCode;
  let osFinal = os;

  // high-entropy UA-CH (Chrome Android): model + versi OS asli
  interface UACH {
    model?: string;
    platformVersion?: string;
    platform?: string;
  }
  const uad = (navigator as Navigator & {
    userAgentData?: {
      getHighEntropyValues?: (h: string[]) => Promise<UACH>;
    };
  }).userAgentData;
  if (uad?.getHighEntropyValues) {
    try {
      const h = await uad.getHighEntropyValues(["model", "platformVersion"]);
      if (h.model) model = h.model;
      if (h.platformVersion && osName === "Android") {
        osFinal = `Android ${h.platformVersion.split(".")[0]}`;
      }
    } catch {
      /* fallback UA */
    }
  }

  // cari nama marketing
  let modelName = "";
  if (model) {
    const code = model.trim();
    if (/^(?:iPhone|iPad)/i.test(code)) {
      modelName = code; // iPhone sudah deskriptif
    } else if (/^[a-z]{2,}[\d]+[a-z]*$/i.test(code) || /^[A-Z]{2,}[a-z0-9-]*\d/i.test(code) || /^RMX|^CPH|^V2|^SM-|^23\d{6}/i.test(code)) {
      try {
        const res = await fetch(`/api/device/lookup?model=${encodeURIComponent(code)}`);
        const d = await res.json();
        if (d?.ok && d.name) modelName = d.name;
      } catch {
        /* biarkan kosong */
      }
    }
  }

  const conn = (navigator as Navigator & {
    connection?: { effectiveType?: string };
  }).connection;

  return {
    os: osFinal,
    osName,
    browser,
    modelCode: model,
    modelName: modelName || (model ? `${osName} (${model})` : osName),
    screen: `${window.screen.width}×${window.screen.height}`,
    cores: navigator.hardwareConcurrency || undefined,
    memory: (navigator as Navigator & { deviceMemory?: number }).deviceMemory,
    network: conn?.effectiveType,
    language: navigator.language,
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "",
  };
}

/* ---------------- Lokasi ---------------- */

export async function getLocationGps(): Promise<GeoState | null> {
  return new Promise((resolve) => {
    if (!navigator.geolocation) {
      resolve(null);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const geo: GeoState = {
          mode: "gps",
          lat: pos.coords.latitude,
          lon: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };
        try {
          const res = await fetch(
            `/api/geo/reverse?lat=${geo.lat}&lon=${geo.lon}`
          );
          const d = await res.json();
          if (d?.ok) {
            geo.kecamatan = d.address.kecamatan;
            geo.kelurahan = d.address.kelurahan;
            geo.kota = d.address.kota;
            geo.kabupaten = d.address.kabupaten;
            geo.provinsi = d.address.provinsi;
            geo.negara = d.address.negara;
            geo.countryCode = d.address.countryCode;
            geo.postcode = d.address.postcode;
            geo.display = d.address.display;
          }
        } catch {
          /* tetap tampil koordinat */
        }
        resolve(geo);
      },
      () => resolve(null),
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 60000 }
    );
  });
}

/** Fallback: estimasi via IP (tanpa izin). */
export async function getLocationByIp(): Promise<GeoState | null> {
  try {
    const res = await fetch("https://ipwho.is/");
    const d = await res.json();
    if (d?.success === false || !d?.latitude) return null;
    return {
      mode: "estimasi",
      lat: d.latitude,
      lon: d.longitude,
      kota: d.city,
      provinsi: d.region,
      negara: d.country,
      countryCode: d.country_code,
      postcode: d.postal,
      ip: d.ip,
      display: [d.city, d.region, d.country].filter(Boolean).join(", "),
    };
  } catch {
    return null;
  }
}
