/**
 * FanzzSecurity — Image Metadata (EXIF) Analyzer.
 *
 * Parser EXIF JPEG murni client-side (tanpa library besar). Membaca:
 *  - EXIF IFD0/ExifIFD/GPS IFD: kamera, software, tanggal, GPS
 *  - dimensi dari marker SOF
 * Hasil JUJUR: bila EXIF sudah dihapus (umum pada foto WhatsApp) →
 * "Metadata tidak tersedia" — TIDAK menebak lokasi/tanggal.
 */

export interface ExifGps {
  lat: number;
  lon: number;
  label: string;
}

export interface ImageMetaResult {
  format: string;
  width: number;
  height: number;
  hasExif: boolean;
  fields: Array<{ key: string; value: string; group: string }>;
  gps?: ExifGps;
  notes: string[];
}

const TAGS: Record<number, string> = {
  0x010f: "Kamera (Make)",
  0x0110: "Model kamera",
  0x0112: "Orientasi",
  0x0131: "Software",
  0x0132: "Tanggal diubah",
  0x013b: "Pembuat (Artist)",
  0x8298: "Hak cipta",
  0x829a: "Exposure time",
  0x829d: "F-number",
  0x8827: "ISO",
  0x9003: "Tanggal ambil (original)",
  0x9004: "Tanggal digitize",
  0x920a: "Focal length",
  0xa432: "Lens info",
  0xa433: "Lens make",
  0xa434: "Lens model",
  0xa430: "Owner name",
  0x927c: "Maker note (ada)",
  0x4746: "Rating",
  0x013e: "White point",
  0xa002: "Panjang pixel Exif",
  0xa003: "Lebar pixel Exif",
};

const ORIENTATION: Record<number, string> = {
  1: "Normal",
  3: "Diputar 180",
  6: "Diputar 90 CW",
  8: "Diputar 90 CCW",
};

function readUint16(v: DataView, off: number, le: boolean) { return v.getUint16(off, le); }
function readUint32(v: DataView, off: number, le: boolean) { return v.getUint32(off, le); }

function dmsToDecimal(d: number, m: number, s: number, ref: string): number {
  let dec = d + m / 60 + s / 3600;
  if (ref === "S" || ref === "W") dec = -dec;
  return dec;
}

/** Parse EXIF dari JPEG. Return null bila tidak ada APP1/Exif. */
export function analyzeJpegExif(buf: ArrayBuffer): ImageMetaResult | null {
  const v = new DataView(buf);
  const notes: string[] = [];
  const fields: ImageMetaResult["fields"] = [];

  if (v.byteLength < 4 || v.getUint16(0) !== 0xffd8) return null;

  // cari marker & SOF & APP1-Exif
  let off = 2;
  let width = 0, height = 0;
  let exifStart = -1;
  while (off < v.byteLength - 4) {
    if (v.getUint8(off) !== 0xff) { off++; continue; }
    const marker = v.getUint8(off + 1);
    if (marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7)) { off += 2; continue; }
    if (marker === 0xda) break; // start of scan
    const len = v.getUint16(off + 2);
    if (marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc) {
      height = v.getUint16(off + 5);
      width = v.getUint16(off + 7);
    }
    if (marker === 0xe1) {
      // cek "Exif\0\0"
      const tag = String.fromCharCode(v.getUint8(off + 4), v.getUint8(off + 5), v.getUint8(off + 6), v.getUint8(off + 7));
      if (tag === "Exif") exifStart = off + 10;
    }
    off += 2 + len;
  }

  if (exifStart < 0) {
    return {
      format: "JPEG",
      width, height,
      hasExif: false,
      fields: [],
      notes: ["Segmen EXIF tidak ditemukan — metadata kemungkinan sudah dihapus (umum pada foto yang dikirim lewat WhatsApp/compressor)."],
    };
  }

  const tiff = exifStart;
  const bo = v.getUint16(tiff);
  const le = bo === 0x4949;
  if (bo !== 0x4949 && bo !== 0x4d4d) {
    return { format: "JPEG", width, height, hasExif: false, fields: [], notes: ["Header TIFF EXIF tidak valid."] };
  }

  const ifd0Off = tiff + readUint32(v, tiff + 4, le);
  let exifIfdOff = 0;
  let gpsIfdOff = 0;

  function readIfd(off: number, group: string) {
    if (off <= 0 || off + 2 > v.byteLength) return;
    const n = readUint16(v, off, le);
    if (n > 512) return; // sanity
    for (let i = 0; i < n; i++) {
      const e = off + 2 + i * 12;
      if (e + 12 > v.byteLength) break;
      const tag = readUint16(v, e, le);
      const type = readUint16(v, e + 2, le);
      const count = readUint32(v, e + 4, le);
      let valOff = e + 8;
      const sizes: Record<number, number> = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };
      const unit = sizes[type] || 1;
      const total = unit * count;
      if (total > 4) valOff = tiff + readUint32(v, e + 8, le);

      if (tag === 0x8769) { exifIfdOff = tiff + readUint32(v, e + 8, le); continue; }
      if (tag === 0x8825) { gpsIfdOff = tiff + readUint32(v, e + 8, le); continue; }

      const name = TAGS[tag];
      if (!name) continue;
      let value = "";
      try {
        if (type === 2) {
          // ASCII
          let s = "";
          for (let k = 0; k < Math.min(count, 64); k++) s += String.fromCharCode(v.getUint8(valOff + k));
          value = s.replace(/\0+$/, "").trim();
        } else if (type === 3) {
          value = String(readUint16(v, valOff, le));
        } else if (type === 4) {
          value = String(readUint32(v, valOff, le));
        } else if (type === 5) {
          const num = readUint32(v, valOff, le);
          const den = readUint32(v, valOff + 4, le);
          value = den ? (num / den).toFixed(3) : `${num}/${den}`;
        } else if (type === 10) {
          const num = v.getInt32(valOff, le);
          const den = v.getInt32(valOff + 4, le);
          value = den ? (num / den).toFixed(3) : `${num}/${den}`;
        } else {
          value = `(tipe ${type}, ${count} nilai)`;
        }
      } catch { continue; }

      if (!value) continue;
      if (tag === 0x0112) value = ORIENTATION[Number(value)] || value;
      fields.push({ key: name, value: value.slice(0, 80), group });
    }
  }

  readIfd(ifd0Off, "Umum (IFD0)");
  if (exifIfdOff) readIfd(exifIfdOff, "Kamera (ExifIFD)");

  // GPS
  let gps: ExifGps | undefined;
  if (gpsIfdOff) {
    try {
      const n = readUint16(v, gpsIfdOff, le);
      const gpsVals: Record<number, number[]> = {};
      let gpsRef = "";
      for (let i = 0; i < n; i++) {
        const e = gpsIfdOff + 2 + i * 12;
        if (e + 12 > v.byteLength) break;
        const tag = readUint16(v, e, le);
        const type = readUint16(v, e + 2, le);
        const count = readUint32(v, e + 4, le);
        let valOff = e + 8;
        if (type === 5 && count > 1) valOff = tiff + readUint32(v, e + 8, le);
        if (tag >= 1 && tag <= 4) {
          const arr: number[] = [];
          for (let k = 0; k < count; k++) {
            if (type === 5) {
              arr.push(readUint32(v, valOff + k * 8, le) / (readUint32(v, valOff + k * 8 + 4, le) || 1));
            } else if (type === 3) {
              arr.push(readUint16(v, valOff + k * 2, le));
            }
          }
          gpsVals[tag] = arr;
        }
        if (tag === 1 || tag === 2) {
          try { gpsRef += String.fromCharCode(v.getUint8(e + 8)).trim(); } catch { /* ignore */ }
        }
      }
      const lat = gpsVals[2], lon = gpsVals[4];
      if (lat?.length >= 3 && lon?.length >= 3) {
        const latDec = dmsToDecimal(lat[0], lat[1], lat[2], gpsRef.includes("S") ? "S" : "N");
        const lonDec = dmsToDecimal(lon[0], lon[1], lon[2], gpsRef.includes("W") ? "W" : "E");
        gps = {
          lat: latDec,
          lon: lonDec,
          label: `${latDec.toFixed(6)}, ${lonDec.toFixed(6)} (dari tag GPS EXIF yang tertanam — akurasi sesuai perangkat saat foto)`,
        };
        fields.push({ key: "Koordinat GPS", value: gps.label, group: "GPS" });
      }
    } catch { /* GPS rusak */ }
  }

  if (!gps) {
    notes.push("Tidak ada tag GPS EXIF pada gambar ini — lokasi tidak bisa ditentukan dan TIDAK ditebak.");
  }
  notes.push("Semua field di bawah dibaca langsung dari byte metadata yang tertanam; field yang tidak ada tidak ditampilkan.");

  return { format: "JPEG", width, height, hasExif: fields.length > 0, fields, gps, notes };
}

/** Analisis PNG dasar (dimensi + chunk text). */
export function analyzePng(buf: ArrayBuffer): ImageMetaResult {
  const v = new DataView(buf);
  const notes: string[] = [];
  const fields: ImageMetaResult["fields"] = [];
  const sig = [0x89, 0x50, 0x4e, 0x47];
  let isPng = true;
  for (let i = 0; i < 4; i++) if (v.getUint8(i) !== sig[i]) { isPng = false; break; }
  if (!isPng) return { format: "?", width: 0, height: 0, hasExif: false, fields, notes: ["Bukan PNG valid."] };

  const width = v.getUint32(16);
  const height = v.getUint32(20);
  // walk chunks untuk tEXt/iTXt/zTXt
  let off = 8;
  const dec = new TextDecoder();
  while (off + 8 < v.byteLength) {
    const len = v.getUint32(off);
    const type = String.fromCharCode(v.getUint8(off + 4), v.getUint8(off + 5), v.getUint8(off + 6), v.getUint8(off + 7));
    if (type === "tEXt" && len < 1024) {
      const bytes = new Uint8Array(buf, off + 8, Math.min(len, 256));
      const s = dec.decode(bytes);
      const eq = s.indexOf("\0");
      if (eq > 0) fields.push({ key: s.slice(0, eq), value: s.slice(eq + 1).slice(0, 80), group: "PNG text" });
    }
    if (type === "IEND") break;
    off += 12 + len;
    if (len < 0 || off > v.byteLength) break;
  }
  notes.push("PNG menyimpan metadata dalam chunk tEXt/eXIf — bila tidak ada di bawah, metadata sudah bersih.");
  return { format: "PNG", width, height, hasExif: fields.length > 0, fields, notes };
}
