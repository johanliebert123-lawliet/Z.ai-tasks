/**
 * AM Active — reverse-engineered dari source "am-reverse-main" (zenno/ansari).
 *
 * Alur: Firebase Identity Toolkit milik app Android Alight Motion:
 *  1. Kirim magic link  → getOobConfirmationCode (requestType 6 = email link signin)
 *  2. User paste link   → emailLinkSignin (oobCode) + getAccountInfo
 *  3. Premium           → verifyPurchase (cloud function) dengan orderId neo-*
 *
 * Bekerja untuk email apa pun (Gmail/Yahoo/Outlook/dll) karena
 * magic link dikirim Firebase ke alamat email itu sendiri.
 */

/** API key Firebase dari app Android Alight Motion. */
const AM_KEY = "AIzaSyDtG1AU22ErnQD60AzBAcaknySiz9_CEq0";
const IDT = "https://www.googleapis.com/identitytoolkit/v3/relyingparty";
const SECURE_TOKEN = "https://securetoken.googleapis.com/v1/token";
const VFY = "https://us-central1-alight-creative.cloudfunctions.net/verifyPurchase";

export interface AmUser {
  localId?: string;
  email?: string;
  emailVerified?: boolean;
  displayName?: string | null;
  photoUrl?: string | null;
  createdAt?: string;
  lastLoginAt?: string;
}

export interface AmLinkResult {
  ok: boolean;
  error?: string;
}

export interface AmAuthResult {
  ok: boolean;
  email?: string;
  idToken?: string;
  refreshToken?: string;
  uid?: string;
  isNewUser?: boolean;
  user?: AmUser | null;
  error?: string;
}

export interface AmProResult {
  ok: boolean;
  order?: string;
  data?: unknown;
  error?: string;
}

/** IP acak buat header spoof (teknik dari source asli). */
function dip(): string {
  const r = (min: number, max: number) =>
    Math.floor(Math.random() * (max - min + 1)) + min;
  return `${r(1, 255)}.${r(0, 255)}.${r(0, 255)}.${r(1, 255)}`;
}

/** Header dasar menyerupai app Android Alight Motion. */
function h1(): Record<string, string> {
  return {
    "content-type": "application/json",
    "x-android-package": "com.alightcreative.motion",
    "x-android-cert": "ECA6BF91B8715A6F810ED0BBFC65B6CD578F52A8",
    "user-agent":
      "dalvik/2.1.0 (linux; u; android 15; 23127pn0cc build/bp1a.250505.005)",
    "x-forwarded-for": dip(),
    "x-real-ip": dip(),
    "client-ip": dip(),
    "x-client-ip": dip(),
    "x-originating-ip": dip(),
    "x-cluster-client-ip": dip(),
  };
}

function h2(idToken: string): Record<string, string> {
  return {
    "content-type": "application/json; charset=utf-8",
    "user-agent": "okhttp/3.12.1",
    "accept-encoding": "gzip",
    authorization: "Bearer " + idToken,
    "firebase-instance-id-token":
      "cSDnCyp3T-uwp07z3tL86T:APA91bFkmvvsHw5nnqa1SBFci-99DRsKClLiETdRrVcJjS5yBx1v_FbCb1d8WhBuea_zmwnYBktyTIzcRhN4b6uNOUur9wPc0gKXmJDoZic0LhNq5V2s0xI",
    "x-forwarded-for": dip(),
    "x-real-ip": dip(),
    "client-ip": dip(),
    "x-client-ip": dip(),
    "x-originating-ip": dip(),
    "x-cluster-client-ip": dip(),
  };
}

function errText(e: unknown): string {
  const err = e as { response?: { data?: unknown }; message?: string };
  const d = err?.response?.data;
  if (d) {
    return typeof d === "object" ? JSON.stringify(d) : String(d);
  }
  return err?.message || String(e);
}

/** Kirim magic link ke email (requestType 6 = email link sign-in). */
export async function amSendLink(email: string): Promise<AmLinkResult> {
  try {
    const res = await fetch(`${IDT}/getOobConfirmationCode?key=${AM_KEY}`, {
      method: "POST",
      headers: h1(),
      body: JSON.stringify({
        requestType: 6,
        email: email,
        androidInstallApp: true,
        canHandleCodeInApp: true,
        continueUrl: "https://alightcreative.com?ui_sid=0366624874&ui_sd=0",
        iosBundleId: "com.alightcreative.motion",
        androidPackageName: "com.alightcreative.motion",
        androidMinimumVersion: "585",
        clientType: "CLIENT_TYPE_ANDROID",
      }),
      signal: AbortSignal.timeout(30000),
    });
    const text = await res.text();
    let data: Record<string, unknown> | null = null;
    try {
      data = JSON.parse(text);
    } catch {
      /* html / error */
    }
    if (!res.ok) {
      return { ok: false, error: friendlyFirebaseError(text) };
    }
    if (data && (data.email || data.emailExists !== undefined)) {
      return { ok: true };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, error: errText(e) };
  }
}

/** Ekstrak oobCode dari magic link yang di-paste user. */
export function extractOobCode(raw: string): string | null {
  if (!raw) return null;
  let s = String(raw).replace(/&amp;/g, "&");
  try {
    s = decodeURIComponent(s);
  } catch {
    /* biarkan */
  }
  try {
    const u = new URL(s);
    let c = u.searchParams.get("oobCode");
    if (!c) {
      const n =
        u.searchParams.get("link") ||
        u.searchParams.get("q") ||
        u.searchParams.get("url");
      if (n) {
        try {
          c = new URL(n).searchParams.get("oobCode");
        } catch {
          /* bukan URL */
        }
      }
    }
    if (c) return c.replace(/[^a-zA-Z0-9_-]/g, "");
  } catch {
    /* bukan URL */
  }
  const m = s.match(/oobCode=([a-zA-Z0-9_-]+)/i);
  if (m) return m[1];
  const t = raw.trim();
  if (/^[a-zA-Z0-9_-]{10,}$/.test(t) && !t.includes("://")) return t;
  return null;
}

/** Tukar magic link jadi sesi (idToken/refreshToken) + data user. */
export async function amAuth(email: string, magicLink: string): Promise<AmAuthResult> {
  const code = extractOobCode(magicLink);
  if (!code) {
    return { ok: false, error: "Format magic link tidak dikenali. Pastikan seluruh URL dari email di-paste lengkap." };
  }
  try {
    const res = await fetch(`${IDT}/emailLinkSignin?key=${AM_KEY}`, {
      method: "POST",
      headers: h1(),
      body: JSON.stringify({
        email: email,
        oobCode: code,
        clientType: "CLIENT_TYPE_ANDROID",
      }),
      signal: AbortSignal.timeout(30000),
    });
    const text = await res.text();
    if (!res.ok) {
      return { ok: false, error: friendlyFirebaseError(text) };
    }
    let a: {
      idToken?: string;
      refreshToken?: string;
      localId?: string;
      isNewUser?: boolean;
    } | null = null;
    try {
      a = JSON.parse(text);
    } catch {
      return { ok: false, error: "Respon server tidak valid" };
    }
    if (!a?.idToken) return { ok: false, error: "Login gagal: token tidak diterima" };

    let user: AmUser | null = null;
    try {
      const b = await fetch(`${IDT}/getAccountInfo?key=${AM_KEY}`, {
        method: "POST",
        headers: h1(),
        body: JSON.stringify({ idToken: a.idToken }),
        signal: AbortSignal.timeout(15000),
      });
      if (b.ok) {
        const d = (await b.json()) as { users?: AmUser[] };
        user = d?.users?.[0] || null;
      }
    } catch {
      /* best-effort */
    }

    return {
      ok: true,
      email,
      idToken: a.idToken,
      refreshToken: a.refreshToken,
      uid: a.localId,
      isNewUser: !!a.isNewUser,
      user,
    };
  } catch (e) {
    return { ok: false, error: errText(e) };
  }
}

/** Aktifkan premium via verifyPurchase. */
export async function amActivate(idToken: string): Promise<AmProResult> {
  const order = "neo-" + Array.from({ length: 6 }, () =>
    Math.floor(Math.random() * 256).toString(16).padStart(2, "0")
  ).join("");
  try {
    const res = await fetch(VFY, {
      method: "POST",
      headers: h2(idToken),
      body: JSON.stringify({
        data: {
          productId: "am.full.sub.annual.19q4",
          token:
            "mmgaobamlahbbeccfplmbkbb.AO-J1OzqG0or_GJJIx-ms8GrTm-jaglCRfhQSRPUZKpl2YspYS-oN7_94uv8RC5vQbvd_Ios2pPDStZ2n7F0hLE3FiOU7HS3R6Fquulv5xLXFECSv4ctElw",
          skuType: "subs",
          orderId: order,
        },
      }),
      signal: AbortSignal.timeout(30000),
    });
    const text = await res.text();
    let data: unknown = null;
    try {
      data = JSON.parse(text);
    } catch {
      /* text */
    }
    if (!res.ok) return { ok: false, error: friendlyFirebaseError(text) };
    return { ok: true, order, data };
  } catch (e) {
    return { ok: false, error: errText(e) };
  }
}

/** Error Firebase → pesan bahasa Indonesia yang ramah. */
export function friendlyFirebaseError(errStr: string): string {
  if (!errStr || typeof errStr !== "string") return "Terjadi kesalahan autentikasi.";
  if (errStr.includes("INVALID_OOB_CODE"))
    return "Magic link tidak valid atau sudah pernah dipakai.";
  if (errStr.includes("EXPIRED_OOB_CODE"))
    return "Magic link sudah kedaluwarsa. Kirim ulang link baru ya.";
  if (errStr.includes("INVALID_EMAIL")) return "Format email tidak valid.";
  if (errStr.includes("EMAIL_NOT_FOUND"))
    return "Email tidak ditemukan. Kirim magic link dulu sebelum verifikasi.";
  if (errStr.includes("USER_DISABLED")) return "Akun dinonaktifkan.";
  if (errStr.includes("TOO_MANY_ATTEMPTS_TRY_LATER"))
    return "Terlalu banyak percobaan. Coba lagi nanti ya.";
  if (errStr.includes("API_KEY_INVALID") || errStr.includes("API key not valid"))
    return "API key tidak valid.";
  if (errStr.includes("OPERATION_NOT_ALLOWED"))
    return "Metode login email-link sedang tidak diizinkan server.";
  if (errStr.includes("NETWORK"))
    return "Koneksi ke server Alight Motion gagal. Cek internet atau coba lagi.";
  // coba ambil pesan dari JSON error google
  try {
    const j = JSON.parse(errStr);
    const msg = j?.error?.message || j?.message;
    if (msg) return friendlyFirebaseError(String(msg));
  } catch {
    /* bukan json */
  }
  return errStr.length > 300 ? errStr.slice(0, 300) + "…" : errStr;
}
