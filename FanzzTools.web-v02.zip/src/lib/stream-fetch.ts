/**
 * PERBAIKAN SISTEMIK (permintaan #3 "lagu terpotong" + #8):
 *
 * Akar masalah: route proxy memakai `signal: AbortSignal.timeout(N)` pada
 * fetch streaming. Sinyal itu TIDAK hanya membatasi waktu konek — ia MEMUTUS
 * BODY yang sedang mengalir setelah N milidetik. Akibatnya:
 *   - /api/quran/audio   (25 dtk)  → audio full-surah terpotong di detik 25
 *   - /api/stream/proxy  (30 dtk)  → lagu MP3 terpotong di detik 30
 *   - /api/download/file (120 dtk) → file besar gagal di menit ke-2
 *
 * Solusi: "connect timeout" sejati — timer hanya berjalan SAMPAI HEADER
 * respons sumber diterima. Setelah itu timer dibatalkan (disconnect) dan
 * body dibiarkan mengalir sampai selesai. Pola ini standar untuk proxy
 * streaming (sama seperti yang dipakai reverse-proxy pada umumnya).
 *
 * Fungsi helper di file ini DIPAKAI BERSAMA oleh:
 *   src/app/api/quran/audio/route.ts
 *   src/app/api/stream/proxy/route.ts
 *   src/app/api/download/file/route.ts
 */

export interface FetchStreamOptions extends RequestInit {
  /** Batas waktu MENUNGGU header respons sumber (default 20 dtk). */
  connectTimeoutMs?: number;
}

/**
 * Fetch yang hanya membatasi waktu SAMPAI header respons diterima.
 * Setelah header tiba, abort dimatikan — body streaming tidak akan
 * pernah diputus oleh timer. Abaikan jika pemanggil memberi signal sendiri.
 */
export async function fetchStream(
  url: string,
  opts: FetchStreamOptions = {}
): Promise<Response> {
  const { connectTimeoutMs = 20000, signal: outerSignal, ...rest } = opts;

  // pemanggil membawa signal sendiri (mis. AbortSignal dari klien) →
  // hormati signal itu saja, tanpa menambah timer apa pun.
  if (outerSignal) {
    return fetch(url, { ...rest, signal: outerSignal });
  }

  const ac = new AbortController();
  let timer: ReturnType<typeof setTimeout> | null = setTimeout(() => {
    timer = null;
    ac.abort();
  }, connectTimeoutMs);

  let upstream: Response;
  try {
    upstream = await fetch(url, { ...rest, signal: ac.signal });
  } finally {
    // header sudah diterima (atau error final) → matikan timer SEBELUM
    // mengembalikan Response agar body-nya bisa mengalir selama apa pun.
    if (timer) {
      clearTimeout(timer);
      timer = null;
    }
  }
  return upstream;
}

/**
 * Idem fetchStream, tapi mengembalikan null bila sumber gagal / menjawab
 * HTML-JSON (challenge / halaman error) alih-alih media — dipakai rantai
 * kandidat audio Qur'an.
 */
export async function fetchStreamOrNull(
  url: string,
  opts: FetchStreamOptions & { range?: string } = {}
): Promise<Response | null> {
  try {
    const { range, ...rest } = opts;
    const upstream = await fetchStream(url, {
      ...rest,
      headers: {
        ...(rest.headers as Record<string, string> | undefined),
        ...(range ? { Range: range } : {}),
      },
    });
    const ct = (upstream.headers.get("content-type") || "").toLowerCase();
    if (!upstream.ok && upstream.status !== 206) return null;
    // tolak halaman HTML (challenge / error) dan JSON — bukan media
    if (ct.includes("text/html") || ct.includes("application/json")) return null;
    if (!upstream.body) return null;
    return upstream;
  } catch {
    return null;
  }
}

/** Bangun Response streaming same-origin dari respons upstream (header aman). */
export function restream(upstream: Response, extra?: Record<string, string>): Response {
  const h = new Headers();
  const ct = upstream.headers.get("content-type") || "";
  h.set("Content-Type", ct.split(";")[0] || "application/octet-stream");
  const cl = upstream.headers.get("content-length");
  if (cl) h.set("Content-Length", cl);
  const cr = upstream.headers.get("content-range");
  if (cr) h.set("Content-Range", cr);
  h.set("Accept-Ranges", "bytes");
  for (const [k, v] of Object.entries(extra || {})) h.set(k, v);
  return new Response(upstream.body, {
    status: upstream.status === 206 ? 206 : 200,
    headers: h,
  });
}
