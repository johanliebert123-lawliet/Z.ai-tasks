import fs from "fs";
import path from "path";
import os from "os";
import { pgSaveJson, pgLoadJson, pgConfigured } from "@/lib/pg-bridge";

/**
 * Persistensi ringan berbasis file JSON + BRIDGE DATABASE (FanzSec-Update).
 *
 * Sejarah akar masalah (PERBAIKAN #3): social-store & story-store 100%
 * in-memory; cold-start serverless menghapus SEMUA foto profil, story,
 * chat, dan data PM. File JSON ke /tmp hanya bertahan selama instance warm.
 *
 * FanzSec-Update: bila DATABASE_URL di-set (mis. Neon PostgreSQL), snapshot
 * juga di-write-through ke tabel app_kv (lihat lib/pg-bridge.ts) dan
 * di-hydrate kembali saat instance baru mulai — data bertahan lintas
 * redeploy/cold-start. Bila DATABASE_URL tidak di-set: perilaku lama
 * (file lokal) — cocok untuk development.
 *
 * File JSON tetap ditulis (atomik, tmp+rename, debounce) sebagai cache
 * instance lokal.
 */

const g = globalThis as unknown as {
  __fanzzDataDir?: string | null;
  __fanzzPersistTimers?: Map<string, ReturnType<typeof setTimeout>>;
  __fanzzDbHydrate?: {
    done: Set<string>;
    listeners: Array<(keys: string[]) => void>;
    started: boolean;
  };
};

function resolveDataDir(): string | null {
  if (g.__fanzzDataDir !== undefined) return g.__fanzzDataDir;
  const candidates = [
    process.env.FANZZ_DATA_DIR || "",
    path.join(process.cwd(), "data"),
    path.join(os.tmpdir(), "fanzz-data"),
  ].filter(Boolean);
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      fs.accessSync(dir, fs.constants.W_OK);
      g.__fanzzDataDir = dir;
      return dir;
    } catch {
      /* coba kandidat berikutnya */
    }
  }
  g.__fanzzDataDir = null;
  return null;
}

if (!g.__fanzzPersistTimers) g.__fanzzPersistTimers = new Map();
if (!g.__fanzzDbHydrate) g.__fanzzDbHydrate = { done: new Set(), listeners: [], started: false };

/* ================= HYDRATION DATABASE (async, sekali per instance) ================= */

/** Daftar kunci yang file-nya TIDAK ada saat boot (kandidat hydrate dari DB). */
const missingFileKeys: string[] = [];

/**
 * Muat JSON dari file data (null bila tidak ada / rusak).
 * PERBAIKAN V2.12: tangani file lama yang ter-stringify GANDA.
 */
export function loadJson<T>(name: string): T | null {
  const dir = resolveDataDir();
  if (!dir) {
    missingFileKeys.push(name);
    return null;
  }
  try {
    const raw = fs.readFileSync(path.join(dir, `${name}.json`), "utf8");
    let parsed: unknown = JSON.parse(raw);
    if (typeof parsed === "string") {
      try { parsed = JSON.parse(parsed); } catch { /* biarkan string */ }
    }
    return parsed as T;
  } catch {
    missingFileKeys.push(name);
    return null;
  }
}

/** Berlangganan notifikasi hydrate DB — callback dipanggil SEKALI dengan
 *  daftar kunci yang berhasil dimuat dari database. Store memakai ini untuk
 *  memulihkan state saat instance baru mulai (file /tmp kosong). */
export function onDbHydrated(cb: (keys: string[]) => void) {
  if (!pgConfigured()) return; // tanpa DATABASE_URL → tidak ada event DB
  const h = g.__fanzzDbHydrate!;
  h.listeners.push(cb);
  startDbHydration();
}

function startDbHydration() {
  const h = g.__fanzzDbHydrate!;
  if (h.started || !pgConfigured()) return;
  h.started = true;
  (async () => {
    // kunci yang ingin di-hydrate = kunci yang file lokalnya tidak ada
    const wanted = [...new Set(missingFileKeys)].filter((k) => !h.done.has(k));
    const loaded: string[] = [];
    for (const key of wanted) {
      try {
        const raw = await pgLoadJson(key);
        if (raw) {
          // tulis ke file lokal (cache instance) lalu tandai siap di-load
          const dir = resolveDataDir();
          if (dir) {
            const file = path.join(dir, `${key}.json`);
            const tmp = `${file}.tmp`;
            fs.writeFileSync(tmp, raw);
            fs.renameSync(tmp, file);
          }
          h.done.add(key);
          loaded.push(key);
        }
      } catch {
        /* per kunci gagal → lanjut kunci berikutnya */
      }
    }
    if (loaded.length) {
      for (const cb of h.listeners) {
        try { cb(loaded); } catch { /* listener error tidak boleh mematikan */ }
      }
    }
  })();
}

/** Simpan JSON atomik + debounce 2,5 detik per kunci (anti spam I/O).
 *  FanzSec-Update: write-through ke database bila DATABASE_URL di-set. */
export function saveJsonDebounced(name: string, data: () => unknown, delayMs = 2500) {
  const timers = g.__fanzzPersistTimers!;
  const prev = timers.get(name);
  if (prev) clearTimeout(prev);
  timers.set(
    name,
    setTimeout(() => {
      timers.delete(name);
      const dir = resolveDataDir();
      let payload = "";
      try {
        const val = data();
        payload = typeof val === "string" ? val : JSON.stringify(val);
        if (dir) {
          const file = path.join(dir, `${name}.json`);
          const tmp = `${file}.tmp`;
          fs.writeFileSync(tmp, payload);
          fs.renameSync(tmp, file);
        }
      } catch {
        /* disk penuh / read-only — lanjut ke DB */
      }
      // write-through database (fire-and-forget, kegagalan tercatat di pgStatus)
      if (pgConfigured() && payload) {
        void pgSaveJson(name, payload);
      }
    }, delayMs)
  );
}

/** Simpan langsung (tanpa debounce) — momen kritis (enroll/dll).
 *  FanzSec-Update: juga write-through ke database. */
export function saveJsonNow(name: string, data: () => unknown) {
  const dir = resolveDataDir();
  let payload = "";
  try {
    const val = data();
    payload = typeof val === "string" ? val : JSON.stringify(val);
    if (dir) {
      const file = path.join(dir, `${name}.json`);
      const tmp = `${file}.tmp`;
      fs.writeFileSync(tmp, payload);
      fs.renameSync(tmp, file);
    }
  } catch {
    /* ignore */
  }
  if (pgConfigured() && payload) {
    void pgSaveJson(name, payload);
  }
}

/** Direktori data aktif (untuk info di UI/dokumentasi). */
export function dataDirInfo(): { dir: string | null; persistent: boolean } {
  const dir = resolveDataDir();
  return { dir, persistent: !!dir && !dir.startsWith(os.tmpdir()) };
}
