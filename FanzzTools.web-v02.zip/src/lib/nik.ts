import { gunzipSync } from "fflate";
import { WILAYAH_DB_B64 } from "@/lib/wilayah-db";

/** Parse DB wilayah sekali per proses server. */
function parseDb(): {
  prov: Record<string, string>;
  kab: Record<string, string>;
  kec: Record<string, string>;
} {
  const raw = new TextDecoder().decode(
    gunzipSync(new Uint8Array(Buffer.from(WILAYAH_DB_B64, "base64")))
  );
  const [p, k, d] = raw.split("|");
  const toMap = (s: string) => {
    const m: Record<string, string> = {};
    for (const kv of s.split(";")) {
      const i = kv.indexOf("=");
      if (i > 0) m[kv.slice(0, i)] = kv.slice(i + 1);
    }
    return m;
  };
  // format: P32=Jawa Barat;33=... → strip prefix P/K/D
  return {
    prov: toMap(p.slice(1)),
    kab: toMap(k.slice(1)),
    kec: toMap(d.slice(1)),
  };
}

let cached: ReturnType<typeof parseDb> | null = null;
export function wilayahDb() {
  if (!cached) cached = parseDb();
  return cached;
}

const ZODIAC: Array<[number, number, string]> = [
  [1, 20, "Aquarius ♒"], [2, 19, "Pisces ♓"], [3, 21, "Aries ♈"],
  [4, 20, "Taurus ♉"], [5, 21, "Gemini ♊"], [6, 21, "Cancer ♋"],
  [7, 23, "Leo ♌"], [8, 23, "Virgo ♍"], [9, 23, "Libra ♎"],
  [10, 23, "Scorpio ♏"], [11, 22, "Sagittarius ♐"], [12, 22, "Capricorn ♑"],
];

function zodiac(month: number, day: number): string {
  // batas: kalau day < boundary → zodiak sebelumnya
  const idx = month - 1;
  const [, boundary, name] = ZODIAC[idx];
  if (day < boundary) {
    const prev = ZODIAC[(idx + 11) % 12];
    return prev[2];
  }
  return name;
}

export interface NikResult {
  valid: boolean;
  errors: string[];
  nik: string;
  wilayah: {
    provinsi: string;
    kabupatenKota: string;
    kecamatan: string;
    kodePos?: string;
  };
  pribadi: {
    jenisKelamin: "Laki-laki" | "Perempuan";
    tanggalLahir: string; // 14 Februari 2005
    umur: string;
    zodiak: string;
    ulangTahunBerikutnya: string;
  };
  nomorUrut: string;
  unikTahunLahir: string;
}

const BULAN = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember",
];

/** Decode NIK 16 digit → data wilayah + data lahir (murni membaca struktur angka). */
export function decodeNik(nikRaw: string): NikResult {
  const errors: string[] = [];
  const nik = nikRaw.replace(/\D/g, "");
  const valid = /^[0-9]{16}$/.test(nik);

  if (!valid) {
    return {
      valid: false,
      errors: [
        nik.length !== 16
          ? `NIK harus 16 digit, yang kamu masukin ${nik.length} digit.`
          : "NIK hanya boleh berisi angka.",
      ],
      nik,
      wilayah: { provinsi: "", kabupatenKota: "", kecamatan: "" },
      pribadi: {
        jenisKelamin: "Laki-laki",
        tanggalLahir: "",
        umur: "",
        zodiak: "",
        ulangTahunBerikutnya: "",
      },
      nomorUrut: "",
      unikTahunLahir: "",
    };
  }

  const { prov, kab, kec } = wilayahDb();
  const kodeProv = nik.slice(0, 2);
  const kodeKab = `${nik.slice(0, 2)}.${nik.slice(2, 4)}`;
  const kodeKec = `${nik.slice(0, 2)}.${nik.slice(2, 4)}.${nik.slice(4, 6)}`;

  const provinsi = prov[kodeProv];
  const kabupatenKota = kab[kodeKab];
  const kecamatan = kec[kodeKec];

  if (!provinsi) errors.push(`Kode provinsi "${kodeProv}" tidak dikenal.`);
  if (provinsi && !kabupatenKota)
    errors.push(`Kode kabupaten/kota "${kodeKab}" tidak dikenal.`);
  if (provinsi && kabupatenKota && !kecamatan)
    errors.push(`Kode kecamatan "${kodeKec}" tidak dikenal (NIK mungkin tidak valid).`);

  // tanggal lahir: digit 7-12 (DDMMYY)
  let dd = parseInt(nik.slice(6, 8), 10);
  const mm = parseInt(nik.slice(8, 10), 10);
  const yy = parseInt(nik.slice(10, 12), 10);
  let jenisKelamin: "Laki-laki" | "Perempuan" = "Laki-laki";
  if (dd > 40) {
    jenisKelamin = "Perempuan";
    dd -= 40;
  }
  const now = new Date();
  const nowYY = now.getFullYear() % 100;
  const tahun = yy <= nowYY ? 2000 + yy : 1900 + yy;

  let tanggalLahir = "";
  let umur = "";
  let zod = "";
  let nextBirthday = "";
  const tglValid =
    dd >= 1 && dd <= 31 && mm >= 1 && mm <= 12 && !isNaN(tahun) && tahun >= 1900 && tahun <= now.getFullYear();
  if (tglValid) {
    // validasi tanggal kalender beneran
    const testDate = new Date(tahun, mm - 1, dd);
    if (testDate.getDate() === dd && testDate.getMonth() === mm - 1) {
      tanggalLahir = `${dd} ${BULAN[mm - 1]} ${tahun}`;
      zod = zodiac(mm, dd);
      let years = now.getFullYear() - tahun;
      const hadBirthday =
        now.getMonth() + 1 > mm || (now.getMonth() + 1 === mm && now.getDate() >= dd);
      if (!hadBirthday) years--;
      umur = `${years} tahun`;

      const next = new Date(now.getFullYear(), mm - 1, dd);
      if (next < now) next.setFullYear(now.getFullYear() + 1);
      const selisih = Math.ceil((next.getTime() - now.getTime()) / 86400000);
      nextBirthday = `${dd} ${BULAN[mm - 1]} — ${selisih} hari lagi`;
    } else {
      errors.push(`Tanggal lahir ${dd}/${mm}/${tahun} tidak valid dalam kalender.`);
    }
  } else {
    errors.push("Angka tanggal lahir (digit 7-12) tidak masuk akal.");
  }

  const nomorUrut = nik.slice(12, 16);
  const unik = `${provinsi || "?"}|${tahun}|${nik.slice(0, 12)}`;

  return {
    valid: errors.length === 0,
    errors,
    nik,
    wilayah: {
      provinsi: provinsi || "Tidak dikenal",
      kabupatenKota: kabupatenKota || "Tidak dikenal",
      kecamatan: kecamatan || "Tidak dikenal",
    },
    pribadi: {
      jenisKelamin,
      tanggalLahir,
      umur,
      zodiak: zod,
      ulangTahunBerikutnya: nextBirthday,
    },
    nomorUrut,
    unikTahunLahir: unik,
  };
}
