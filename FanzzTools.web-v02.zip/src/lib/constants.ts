/** Konstanta bersama: embed server film, user agent, dsb. */

/**
 * zuperupdt #16 — KUNCI PEMELIHARAAN DONGHUA (3 lapis):
 *  L1 server : /api/donghua selalu menjawab maintenance (kecuali env
 *              FANZZ_DONGHUA_ENABLED=1)
 *  L2 klien  : DonghuaView membaca konstanta ini langsung (ter-bundle) —
 *              layar "sedang dalam pemeliharaan" tampil SEBELUM fetch
 *  L3 lokal  : flag localStorage "fanzz_donghua_maintenance" — bertahan
 *              walau bundle lama masih ter-cache di browser pengguna
 * Sistem/scrapper donghua TIDAK dihapus. Untuk mengaktifkan kembali:
 * ubah ke false (atau set env FANZZ_DONGHUA_ENABLED=1 di server). */
export const DONGHUA_MAINTENANCE: boolean = true;

export const UA_MOBILE =
  "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36";

export const UA_DESKTOP =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

export const TMDB_KEY =
  process.env.TMDB_API_KEY || "9e7096a7575623aa30c66e9cc987e411";
export const TMDB_BASE = "https://api.themoviedb.org/3";
export const TMDB_IMG = "https://image.tmdb.org/t/p";

export const MOVIEZONE_BASE = "https://moviezone.web.id/api/movies";

/** Sandbox iframe ketat — memblokir popup, redirect, dan modal iklan. */
export const PLAYER_SANDBOX =
  "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

/** Server yang butuh sandbox dilepas (compat) agar bisa jalan. */
export const SANDBOX_SENSITIVE = [
  "2embed",
  "superembed",
  "vidsrc",
  "vidlink",
  "multiembed",
  "vsembed",
  "vidsrc.cc",
  "lk21-fast",
  "lk21-ultra",
];

export interface EmbedServer {
  id: string;
  name: string;
  /** Bangun URL embed dari tmdb id */
  build: (tmdbId: number, season?: number, episode?: number) => string;
  /** true = butuh mode kompatibel (sandbox dilepas) */
  compat?: boolean;
  /** dukungan subtitle via param URL */
  subParam?: boolean;
  /** "file" = sub via param sub_file (VTT FanzzTools), "cc" = lewat menu CC player */
  subMode?: "file" | "cc";
  note?: string;
}

/** Daftar embed provider — diaudit ulang 13 Sep 2026 (server mati dikeluarkan). */
export const EMBED_SERVERS: EmbedServer[] = [
  {
    id: "vidlink",
    name: "VidLink",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidlink.pro/tv/${id}/${s}/${e}`
        : `https://vidlink.pro/movie/${id}`,
    subParam: true,
    subMode: "file",
    note: "Sub bisa diatur dari sini (ID/EN)",
  },
  {
    id: "vidsrc-to",
    name: "VidSrc To",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.to/embed/tv/${id}/${s}/${e}`
        : `https://vidsrc.to/embed/movie/${id}`,
    compat: true,
    subMode: "cc",
    note: "Subtitle multi bahasa via CC",
  },
  {
    id: "vidfast",
    name: "VidFast",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidfast.vc/tv/${id}/${s}/${e}`
        : `https://vidfast.vc/movie/${id}`,
    subMode: "cc",
    note: "Player modern & cepat",
  },
  {
    id: "videasy",
    name: "Videasy",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://player.videasy.net/tv/${id}/${s}/${e}`
        : `https://player.videasy.net/movie/${id}`,
    subMode: "cc",
    note: "Stabil, sub via menu player",
  },
  {
    id: "smashy",
    name: "SmashyStream",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://smashystream.xyz/tv/${id}?season=${s}&episode=${e}`
        : `https://smashystream.xyz/movie/${id}`,
    subMode: "cc",
    note: "Multi kualitas",
  },
  {
    id: "vidjoy",
    name: "VidJoy",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidjoy.pro/embed/tv/${id}/${s}/${e}`
        : `https://vidjoy.pro/embed/movie/${id}`,
    subMode: "cc",
    note: "Server alternatif",
  },
  {
    id: "vidzee",
    name: "Vidzee",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidzee.wtf/tv/${id}/${s}/${e}`
        : `https://vidzee.wtf/movie/${id}`,
    subMode: "cc",
    note: "Alternatif baru",
  },
  {
    id: "vidsrc-wiki",
    name: "VidSrc Wiki",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.wiki/embed/tv/${id}/${s}/${e}/`
        : `https://vidsrc.wiki/embed/movie/${id}/`,
    subMode: "cc",
    note: "Stabil, sub via menu player",
  },
  {
    id: "vidsrc-sbs",
    name: "VidSrc SBS",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.sbs/embed/tv/${id}/${s}/${e}/`
        : `https://vidsrc.sbs/embed/movie/${id}/`,
    subMode: "cc",
    note: "Multi bahasa subtitle (CC)",
  },
  {
    id: "2embed",
    name: "2Embed",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://www.2embed.cc/embedtv/${id}/s/${s}/e/${e}`
        : `https://www.2embed.cc/embed/${id}`,
    compat: true,
    subMode: "cc",
    note: "Subtitle multi bahasa",
  },
  {
    id: "vidsrc-cc",
    name: "VidSrc CC v2",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.cc/v2/embed/tv/${id}/${s}/${e}`
        : `https://vidsrc.cc/v2/embed/movie/${id}`,
    subMode: "cc",
    note: "Sub Indonesia sering tersedia di CC",
  },
  {
    id: "vidora",
    name: "Vidora",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidora.su/tv/${id}/${s}/${e}`
        : `https://vidora.su/movie/${id}`,
    subMode: "cc",
    note: "Server cepat + CC",
  },
  {
    id: "autoembed",
    name: "AutoEmbed",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://autoembed.pro/embed/tv/${id}/${s}/${e}`
        : `https://autoembed.pro/embed/movie/${id}`,
    subMode: "cc",
    note: "Alternatif stabil",
  },
  {
    id: "111movies",
    name: "111Movies",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://111movies.com/tv/${id}/${s}/${e}`
        : `https://111movies.com/movie/${id}`,
    subMode: "cc",
    note: "Backup ekstra",
  },
];

/**
 * LK21 Stream Premium — DITAMBAHKAN V0.01 (permintaan #2 & #8b).
 * Keluarga server dari SC lk21-stream-premium (RSTREAM) — pemutaran sub
 * Indonesia multi-server. Ditempatkan SESUDAH MovieZone (tetap sumber utama).
 */
export const LK21_SERVERS: EmbedServer[] = [
  {
    id: "lk21-vip",
    name: "LK21 Premium VIP",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidlink.pro/tv/${id}/${s}/${e}`
        : `https://vidlink.pro/movie/${id}`,
    subParam: true,
    subMode: "file",
    note: "LK21 Stream Premium — sub bisa diatur dari sini",
  },
  {
    id: "lk21-fast",
    name: "LK21 Premium Fast",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.cc/v2/embed/tv/${id}/${s}/${e}`
        : `https://vidsrc.cc/v2/embed/movie/${id}`,
    compat: true,
    subMode: "cc",
    note: "LK21 Stream Premium — sub multi bahasa via CC",
  },
  {
    id: "lk21-hd",
    name: "LK21 Premium HD",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://embed.su/embed/tv/${id}/${s}/${e}`
        : `https://embed.su/embed/movie/${id}`,
    subMode: "cc",
    note: "LK21 Stream Premium — kualitas HD",
  },
  {
    id: "lk21-pro",
    name: "LK21 Premium Pro",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://vidsrc.pro/embed/tv/${id}/${s}/${e}`
        : `https://vidsrc.pro/embed/movie/${id}`,
    subMode: "cc",
    note: "LK21 Stream Premium — server pro",
  },
  {
    id: "lk21-ultra",
    name: "LK21 Premium Ultra",
    build: (id, s, e) =>
      s != null && e != null
        ? `https://multiembed.mov/directstream.php?video_id=${id}&tmdb=1&s=${s}&e=${e}`
        : `https://multiembed.mov/directstream.php?video_id=${id}&tmdb=1`,
    compat: true,
    subMode: "cc",
    note: "LK21 Stream Premium — ultra multi kualitas",
  },
];

export const AM_API_BASE = process.env.AM_API_BASE || "https://am.yappi.my.id";
