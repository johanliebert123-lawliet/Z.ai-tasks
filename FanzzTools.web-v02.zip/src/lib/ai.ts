import { UA_MOBILE, UA_DESKTOP } from "@/lib/constants";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

export interface AiModel {
  id: string;
  label: string;
  provider: "overchat" | "yenus" | "azbry";
  badge: string;
  desc: string;
}

export const AI_MODELS: AiModel[] = [
  {
    id: "gpt-4.1-nano",
    label: "GPT-4.1 Nano",
    provider: "overchat",
    badge: "OpenAI",
    desc: "Cepat & ringan buat tugas harian",
  },
  {
    id: "gpt-4o",
    label: "GPT-4o",
    provider: "azbry",
    badge: "OpenAI",
    desc: "Model serba bisa",
  },
  {
    id: "claude-haiku-4-5-20251001",
    label: "Claude Haiku 4.5",
    provider: "overchat",
    badge: "Anthropic",
    desc: "Jawaban rapi & puitis",
  },
  {
    id: "gemini-2.5-flash",
    label: "Gemini 2.5 Flash",
    provider: "yenus",
    badge: "Google",
    desc: "Nalar kuat, multimodal",
  },
  {
    id: "alibaba/qwen3-next-80b-a3b-instruct",
    label: "Qwen3 Next 80B",
    provider: "overchat",
    badge: "Alibaba",
    desc: "A3B hemat, cocok analisis",
  },
];

export const DEFAULT_MODEL = "gpt-4.1-nano";

function deviceId() {
  return crypto.randomUUID();
}

/** Overchat: GPT-4.1 Nano, Claude Haiku 4.5, Qwen3 (SSE). */
async function callOverchat(
  modelId: string,
  messages: ChatMessage[]
): Promise<string> {
  const uuid = deviceId();
  const persona =
    modelId === "claude-haiku-4-5-20251001"
      ? "claude-haiku-4-5-landing"
      : modelId === "alibaba/qwen3-next-80b-a3b-instruct"
        ? "qwen-3-landing"
        : "gpt-4o-landing";

  const res = await fetch("https://api.overchat.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "sec-ch-ua-platform": '"Android"',
      "x-device-uuid": uuid,
      "sec-ch-ua-mobile": "?1",
      "x-device-language": "id-ID",
      "x-device-platform": "web",
      "x-device-version": "1.0.44",
      "user-agent": UA_MOBILE,
      accept: "*/*",
      "content-type": "application/json",
      origin: "https://overchat.ai",
      referer: "https://overchat.ai/",
    },
    body: JSON.stringify({
      chatId: uuid,
      model: modelId,
      messages: messages.map((m) => ({
        id: crypto.randomUUID(),
        role: m.role,
        content: m.content,
      })),
      personaId: persona,
      frequency_penalty: 0,
      max_tokens: 4000,
      presence_penalty: 0,
      stream: true,
      temperature: 0.6,
      top_p: 0.95,
    }),
    signal: AbortSignal.timeout(60000),
  });

  if (!res.ok || !res.body) {
    const t = await res.text().catch(() => "");
    throw new Error(`overchat ${res.status}: ${t.slice(0, 140)}`);
  }

  // Parse SSE
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let answer = "";
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";
    for (const raw of lines) {
      const line = raw.trim();
      if (!line.startsWith("data:")) continue;
      const data = line.slice(5).trim();
      if (!data || data === "[DONE]") continue;
      try {
        const json = JSON.parse(data);
        const c = json.choices?.[0]?.delta?.content;
        if (typeof c === "string") answer += c;
      } catch {
        /* abaikan chunk rusak */
      }
    }
  }
  if (!answer.trim()) throw new Error("overchat: jawaban kosong");
  return answer.trim();
}

/** YenusAI: Gemini 2.5 Flash. */
async function callYenus(messages: ChatMessage[]): Promise<string> {
  const res = await fetch(
    "https://yenus.created.app/integrations/google-gemini-1-5-flash",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-createxyz-project-id": "31b1368e-b142-4030-bef4-1a10d86e4873",
      },
      body: JSON.stringify({
        messages: messages.slice(-12).map((m) => ({
          role: m.role,
          content: m.content.slice(0, 12000),
        })),
        stream: false,
      }),
      signal: AbortSignal.timeout(60000),
    }
  );
  if (!res.ok) throw new Error(`yenus ${res.status}`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error("yenus: jawaban kosong");
  return String(text).trim();
}

/** azbry: GPT-4o (context dibungkus jadi satu prompt). */
async function callAzbry(messages: ChatMessage[]): Promise<string> {
  const convo = messages
    .slice(-8)
    .map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)
    .join("\n\n");
  const q = `Kamu AI asisten FanzzTools. Jawab dalam bahasa yang sama dengan user, santai tapi jelas. Riwayat chat:\n\n${convo}\n\nAssistant:`;
  const res = await fetch(
    `https://api.azbry.com/api/ai/gpt4o?q=${encodeURIComponent(q.slice(0, 3000))}`,
    {
      headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
      signal: AbortSignal.timeout(60000),
    }
  );
  if (!res.ok) throw new Error(`azbry ${res.status}`);
  const data = await res.json();
  const text = data?.result?.answer;
  if (!text) throw new Error("azbry: jawaban kosong");
  return String(text).trim();
}

/** Chat utama dengan cascade fallback antar provider. */
export async function aiChat(
  modelId: string,
  messages: ChatMessage[]
): Promise<{ text: string; model: string }> {
  const model = AI_MODELS.find((m) => m.id === modelId) || AI_MODELS[0];
  const order: Array<() => Promise<string>> = [];

  if (model.provider === "overchat")
    order.push(
      () => callOverchat(model.id, messages),
      () => callYenus(messages),
      () => callAzbry(messages)
    );
  else if (model.provider === "yenus")
    order.push(
      () => callYenus(messages),
      () => callOverchat("gpt-4.1-nano", messages),
      () => callAzbry(messages)
    );
  else
    order.push(
      () => callAzbry(messages),
      () => callOverchat("gpt-4.1-nano", messages),
      () => callYenus(messages)
    );

  let lastErr: unknown = null;
  for (const fn of order) {
    try {
      const text = await fn();
      return { text, model: model.label };
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr instanceof Error
    ? lastErr
    : new Error("Semua model AI sedang sibuk, coba lagi ya");
}

/** Vision: deskripsi gambar via aiconvert.online lalu dianalisis model chat. */
export async function describeImage(
  imageBase64: string,
  mimeType: string
): Promise<string> {
  const submit = await fetch(
    "https://aiconvert.online/api/submit-prompt-job",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "User-Agent": UA_DESKTOP,
        Referer: "https://aiconvert.online/prompt-generator",
      },
      body: JSON.stringify({
        imageData: imageBase64,
        mimeType,
        language: "id",
        promptType: "detailed",
      }),
      signal: AbortSignal.timeout(30000),
    }
  );
  const sub = await submit.json().catch(() => null);
  const taskId = sub?.taskId;
  if (!taskId) throw new Error("Gagal mengirim gambar ke analyzer");

  for (let i = 0; i < 15; i++) {
    await new Promise((r) => setTimeout(r, 2500));
    const poll = await fetch(
      `https://aiconvert.online/api/check-status-kv?taskId=${taskId}`,
      {
        headers: {
          "User-Agent": UA_DESKTOP,
          Referer: "https://aiconvert.online/prompt-generator",
        },
        signal: AbortSignal.timeout(10000),
      }
    );
    const st = await poll.json().catch(() => null);
    if (st?.status === "SUCCESS" && st?.result?.generatedPrompt)
      return String(st.result.generatedPrompt);
    if (st?.status === "FAILED") break;
  }
  throw new Error("Waktu analisis gambar habis, coba lagi");
}

export interface SearchHit {
  title: string;
  url: string;
  snippet: string;
}

/** Decode link redirect Bing (bing.com/ck/a?...&u=a1<base64url>). */
function decodeBingUrl(href: string): string | null {
  if (!href) return null;
  if (href.startsWith("http") && !href.includes("bing.com/ck/")) return href;
  try {
    const u = new URL(href, "https://www.bing.com");
    const up = u.searchParams.get("u");
    if (!up) return href.startsWith("http") ? href : null;
    // u=a1XXXX — strip prefix base64url lalu decode
    const cleaned = up.startsWith("a1") ? up.slice(2) : up;
    const b64 = cleaned.replace(/-/g, "+").replace(/_/g, "/");
    const buf = Buffer.from(b64, "base64");
    const dec = buf.toString("utf-8");
    return dec.startsWith("http") ? dec : href.startsWith("http") ? href : null;
  } catch {
    return href.startsWith("http") ? href : null;
  }
}

function stripTags(s: string): string {
  return s
    .replace(/<[^>]+>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const STOPWORDS = new Set([
  "apa", "yang", "ini", "itu", "hari", "dan", "dengan", "untuk", "dari", "adalah",
  "bagaimana", "kenapa", "mengapa", "kapan", "berapa", "siapa", "tolong", "dong",
  "gak", "nggak", "bisa", "bikin", "kasih", "boleh", "kak", "min", "ada", "tentang",
  "carikan", "carikan", "tolongin", "cewek", "cowok", "saya", "kamu", "aku", "gue",
  "gw", "we", "the", "what", "when", "where", "how", "who", "why", "about", "latest",
]);

const ADULT_DOMAINS = [
  "xhamster", "pornhub", "xnxx", "iporntv", "redtube", "youporn", "porntrex",
  "spankbang", "xxx", "sex", "bokep", "desi", "iporn", "xvideos", "chudai",
];

/** Filter hasil yang gak nyambung sama query (anti hasil racun / spam). */
function isRelevant(query: string, hit: { title: string; url: string; snippet: string }): boolean {
  const domain = hit.url.toLowerCase();
  if (ADULT_DOMAINS.some((d) => domain.includes(d))) return false;

  const tokens = query
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((t) => t.length >= 4 && !STOPWORDS.has(t));
  if (!tokens.length) return true; // query terlalu generik — terima apa adanya

  const hay = `${hit.title} ${hit.snippet}`.toLowerCase();
  return tokens.some((t) => hay.includes(t));
}

/** Web search cascade: Google News RSS → Bing HTML (terfilter) → Wikipedia. */
export async function webSearch(query: string): Promise<SearchHit[]> {
  const q = query.trim().slice(0, 150);
  if (!q) return [];

  // 1) Google News RSS — paling andal buat berita/kejadian terbaru
  try {
    const res = await fetch(
      `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=id&gl=ID&ceid=ID:id`,
      { signal: AbortSignal.timeout(12000), headers: { "User-Agent": UA_DESKTOP } }
    );
    const xml = await res.text();
    const hits: SearchHit[] = [];
    const items = xml.split("<item>").slice(1);
    for (const it of items) {
      const t = it.match(/<title>([\s\S]*?)<\/title>/);
      const l = it.match(/<link>([\s\S]*?)<\/link>/);
      const d = it.match(/<description>([\s\S]*?)<\/description>/);
      const p = it.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
      if (t && l) {
        const title = t[1].replace(/<!\[CDATA\[|\]\]>/g, "").trim();
        const url = l[1].trim();
        let snippet = d
          ? d[1].replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, "").trim().slice(0, 200)
          : "";
        if (p) snippet = `(${p[1].trim()}) ${snippet}`;
        const hit = { title, url, snippet };
        if (title && url && isRelevant(q, hit)) hits.push(hit);
      }
      if (hits.length >= 8) break;
    }
    if (hits.length) return hits;
  } catch {
    /* lanjut fallback */
  }

  // 2) Bing HTML — hasilnya difilter relevansi (IP datacenter kadang dapat racun)
  try {
    const res = await fetch(
      `https://www.bing.com/search?q=${encodeURIComponent(q)}&setlang=id&count=10`,
      {
        headers: {
          "User-Agent": UA_DESKTOP,
          "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
          Accept: "text/html,application/xhtml+xml",
        },
        signal: AbortSignal.timeout(12000),
      }
    );
    const html = await res.text();
    const hits: SearchHit[] = [];
    const blockRe = /<li class="b_algo"[\s\S]*?<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>\s*<\/h2>([\s\S]*?)<\/li>/g;
    let m: RegExpExecArray | null;
    while ((m = blockRe.exec(html))) {
      const url = decodeBingUrl(m[1].replace(/&amp;/g, "&"));
      if (!url || !/^https?:\/\//.test(url)) continue;
      const title = stripTags(m[2]);
      const body = m[3] || "";
      const sm =
        body.match(/<p[^>]*>([\s\S]*?)<\/p>/) ||
        body.match(/class="b_caption[^"]*"[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/);
      const snippet = sm ? stripTags(sm[1]).slice(0, 240) : "";
      if (!title) continue;
      const hit = { title, url, snippet };
      if (isRelevant(q, hit)) hits.push(hit);
      if (hits.length >= 8) break;
    }
    if (hits.length) return hits;
  } catch {
    /* lanjut fallback */
  }

  // 3) Wikipedia (ID + EN) — buat pertanyaan ensiklopedia
  try {
    for (const lang of ["id", "en"]) {
      const res = await fetch(
        `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srlimit=6&format=json&srsearch=${encodeURIComponent(q)}`,
        {
          headers: { "User-Agent": UA_DESKTOP },
          signal: AbortSignal.timeout(10000),
        }
      );
      const d = await res.json();
      const hits: SearchHit[] = (d?.query?.search || []).map(
        (s: { title: string; snippet: string }) => ({
          title: s.title,
          url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(s.title.replace(/ /g, "_"))}`,
          snippet: stripTags(s.snippet).slice(0, 200),
        })
      );
      if (hits.length) return hits;
    }
  } catch {
    /* kosong */
  }

  return [];
}

/** Deteksi apakah pertanyaan user butuh data terbaru (auto web search). */
export function needsFreshData(text: string): boolean {
  const t = text.toLowerCase();
  const patterns = [
    "terbaru", "terkini", "hari ini", "kemarin", "sekarang", "baru ini", "terkini",
    "berita", "news", "latest", "update", "updated", "skrg", "sekarang lagi",
    "jadwal", "rilis", "release", "harga", "kurs", "cuaca", "skor", "hasil",
    "siapa juara", "top chart", "trending", "viral", "2024", "2025", "2026",
    "berapa sekarang", "kapan rilis", "peringkat", "kabar", "hangat", "mutakhir",
    "isu", "peristiwa", "kejadian", "artis", "bola", "politik", "cuacanya",
    "hari apa", "jam berapa", "sudah", "belum", "nonton apa",
  ];
  return patterns.some((p) => t.includes(p));
}
