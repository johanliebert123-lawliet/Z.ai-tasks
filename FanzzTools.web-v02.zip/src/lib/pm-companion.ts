/**
 * Parent Monitor — Companion app (untuk HP anak) — V2.12 Security-Updt.
 *
 * Menghasilkan HTML mandiri (satu file, tanpa dependensi eksternal) yang
 * di-bundle APK Builder ke assets/index.html. Companion ini TRANSPARAN:
 *  - Menampilkan selalu fitur monitoring apa saja yang aktif.
 *  - Pairing butuh konfirmasi eksplisit pengguna perangkat (tidak diam-diam).
 *  - Anak bisa memutus koneksi sendiri kapan saja (Disconnect).
 *  - TIDAK ADA fitur spyware: tanpa keylogger, tanpa intersep OTP/chat,
 *    tanpa rekam layar/kamera/mic diam-diam, tanpa scraping galeri,
 *    tanpa shell jarak jauh, tanpa mode tersembunyi.
 *  - Statistik pemakaian aplikasi hanya bisa dilaporkan companion NATIVE
 *    (UsageStatsManager Android) — sumber Kotlin ada di android-companion/.
 *    Companion WebView ini melaporkan status perangkat (baterai/jaringan),
 *    lokasi opsional (dengan izin), dan media yang DIPILIH pengguna.
 */

export interface PmCompanionOptions {
  /** nama aplikasi (label launcher) */
  appName: string;
  /** URL absolut server FanzzTools (origin pembuat APK) */
  serverUrl: string;
  /** nama panggilan anak (info transparan di layar sambutan) */
  childNickname?: string;
  /** fitur monitoring yang diaktifkan orang tua */
  features: { usage: boolean; status: boolean; location: boolean; media: boolean };
  /** versi companion */
  version: string;
}

/** Nama aplikasi sistem yang DILARANG dipakai (anti-impersonasi). */
const FORBIDDEN_APP_NAMES = [
  "android system", "system ui", "google play services", "play services",
  "google", "settings", "pengaturan", "sistem", "system", "phone", "telepon",
  "sms", "messenger service", "whatsapp", "chrome", "google chrome",
];

export function isForbiddenAppName(name: string): boolean {
  const n = (name || "").trim().toLowerCase();
  return FORBIDDEN_APP_NAMES.includes(n);
}

/** Padankan warna aksen senada FanzzTools (indigo/biru keluarga). */
export function buildPmCompanionHtml(opts: PmCompanionOptions): string {
  const cfg = JSON.stringify({
    appName: opts.appName,
    serverUrl: opts.serverUrl.replace(/\/+$/, ""),
    childNickname: opts.childNickname || "",
    features: opts.features,
    version: opts.version,
  }).replace(/</g, "\\u003c");

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Family Safety</title>
<style>
  :root{--bg:#0b1020;--card:#141a30;--line:#232b4d;--tx:#e8ecf8;--mut:#8b93b5;--acc:#6366f1;--ok:#10b981;--warn:#f59e0b;--err:#ef4444}
  *{box-sizing:border-box;margin:0;padding:0}
  html,body{height:100%}
  body{background:var(--bg);color:var(--tx);font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
    display:flex;flex-direction:column;align-items:center;padding:20px 16px 40px;line-height:1.55}
  .wrap{width:100%;max-width:430px}
  .logo{display:flex;align-items:center;gap:12px;margin-bottom:22px}
  .logo .ic{flex:0 0 auto;width:52px;height:52px;border-radius:16px;background:linear-gradient(135deg,#6366f1,#3b82f6);
    display:flex;align-items:center;justify-content:center}
  .logo h1{font-size:19px;font-weight:800}
  .logo p{font-size:11.5px;color:var(--mut)}
  .card{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:20px;margin-bottom:14px}
  .card h2{font-size:15px;font-weight:800;margin-bottom:8px}
  .card p{font-size:12.5px;color:var(--mut)}
  .card p b{color:var(--tx)}
  .feat{display:flex;align-items:center;justify-content:space-between;padding:11px 0;border-bottom:1px solid var(--line);font-size:13px}
  .feat:last-child{border-bottom:0}
  .feat .dot{width:9px;height:9px;border-radius:50%;background:var(--err);display:inline-block;margin-right:8px}
  .feat.on .dot{background:var(--ok)}
  .feat small{display:block;color:var(--mut);font-size:10.5px}
  input,button{font-family:inherit}
  input{width:100%;padding:13px 14px;border-radius:14px;border:1px solid var(--line);background:#0e1428;color:var(--tx);
    font-size:15px;text-align:center;letter-spacing:1px;text-transform:uppercase;outline:none}
  input:focus{border-color:var(--acc)}
  button{width:100%;padding:15px;border:0;border-radius:16px;font-size:14px;font-weight:800;cursor:pointer;
    transition:transform .1s}
  button:active{transform:scale(.98)}
  .btn-p{background:linear-gradient(135deg,#6366f1,#3b82f6);color:#fff}
  .btn-o{background:#1c2444;color:var(--tx);border:1px solid var(--line)}
  .btn-d{background:rgba(239,68,68,.12);color:#fca5a5;border:1px solid rgba(239,68,68,.3)}
  .btn-s{background:rgba(16,185,129,.12);color:#6ee7b7;border:1px solid rgba(16,185,129,.3)}
  .row{display:flex;gap:10px}
  .row button{flex:1}
  .pill{display:inline-block;padding:3px 10px;border-radius:999px;font-size:10px;font-weight:800;margin:2px 4px 2px 0}
  .pill.ok{background:rgba(16,185,129,.15);color:#6ee7b7}
  .pill.err{background:rgba(239,68,68,.15);color:#fca5a5}
  .pill.warn{background:rgba(245,158,11,.15);color:#fcd34d}
  .kv{display:flex;justify-content:space-between;font-size:12.5px;padding:7px 0;border-bottom:1px solid var(--line)}
  .kv:last-child{border-bottom:0}
  .kv span:first-child{color:var(--mut)}
  .note{font-size:10.5px;color:var(--mut);text-align:center;margin:10px 0 0}
  .errbox{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);border-radius:12px;
    padding:10px 14px;font-size:12px;color:#fca5a5;margin-bottom:12px;display:none}
  .spin{width:22px;height:22px;border:3px solid #ffffff22;border-top-color:var(--acc);border-radius:50%;
    animation:sp 1s linear infinite;margin:14px auto}
  @keyframes sp{to{transform:rotate(360deg)}}
  video,#qrbox{width:100%;max-width:340px;border-radius:16px;background:#000;margin:10px auto;display:block}
  .hidden{display:none!important}
  .foot{margin-top:18px;font-size:10px;color:var(--mut);text-align:center}
</style>
</head>
<body>
<div class="wrap">

  <div class="logo">
    <div class="ic">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2"
        stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <path d="m9 12 2 2 4-4"/></svg>
    </div>
    <div>
      <h1 id="appTitle">Family Safety</h1>
      <p>Companion transparan untuk keluarga</p>
    </div>
  </div>

  <div id="errbox" class="errbox"></div>

  <!-- ============ LAYAR: SAMBUTAN (belum terhubung) ============ -->
  <div id="scr-welcome">
    <div class="card">
      <h2>Aplikasi keamanan keluarga</h2>
      <p id="welcomeChild">Aplikasi ini menghubungkan perangkat ini dengan akun orang tua/wali keluarga kamu
      supaya mereka bisa membantu menjaga keamanan digital kamu.</p>
      <div style="margin-top:12px">
        <span class="pill ok">TRANSPARAN</span><span class="pill ok">BISA DIPUTUS KAPAN SAAT</span>
        <span class="pill ok">TANPA KEYLOGGER</span><span class="pill ok">TANPA BACA CHAT</span>
      </div>
    </div>

    <div class="card">
      <h2>Yang dilaporkan aplikasi ini</h2>
      <div id="featList"></div>
      <p style="margin-top:10px">Tidak ada yang disembunyi: daftar di atas SELALU tampil, dan kamu bisa
      memutus koneksi lewat tombol <b>Putuskan Koneksi</b>.</p>
    </div>

    <button class="btn-p" onclick="show('connect')">Mulai Hubungkan</button>
    <button class="btn-o" style="margin-top:10px" onclick="show('about')">Privasi &amp; Izin</button>
  </div>

  <!-- ============ LAYAR: HUBUNGKAN (kode / QR) ============ -->
  <div id="scr-connect" class="hidden">
    <div class="card">
      <h2>Hubungkan ke keluarga</h2>
      <p>Minta orang tua membuka <b>FanzzTools V2 &gt; Parent Monitor</b>, lalu tekan
      <b>QR / Kode Pairing</b> pada perangkat yang sudah didaftarkan. Kode berlaku
      <b>10 menit</b> dan hanya bisa dipakai <b>sekali</b>.</p>
    </div>

    <div class="card">
      <h2>Masukkan kode pairing</h2>
      <input id="codeInput" placeholder="PM-XXXX-XXXX" autocomplete="off" autocapitalize="characters"
        maxlength="14" style="margin-bottom:10px" onkeydown="if(event.key==='Enter')pairingCode()">
      <button class="btn-p" onclick="pairingCode()">Hubungkan dengan Kode</button>
      <p class="note">atau pindai QR dari dashboard orang tua</p>
    </div>

    <div class="card">
      <h2>Pindai QR <span id="qrState" class="pill warn">opsional</span></h2>
      <video id="qrbox" class="hidden" muted playsinline></video>
      <button id="qrBtn" class="btn-o" onclick="scanQr()">Coba Pindai QR</button>
      <p class="note" id="qrNote">Kalau kamera tidak tersedia di aplikasi ini, pakai kode manual di atas —
      hasilnya sama saja.</p>
    </div>

    <button class="btn-o" onclick="show('welcome')">Kembali</button>
  </div>

  <!-- ============ LAYAR: KONFIRMASI PAIRING ============ -->
  <div id="scr-confirm" class="hidden">
    <div class="card">
      <h2>Konfirmasi koneksi</h2>
      <div class="kv"><span>Keluarga</span><b id="cfHouse">—</b></div>
      <div class="kv"><span>Profil anak</span><b id="cfChild">—</b></div>
      <div class="kv"><span>Perangkat</span><b id="cfDev">—</b></div>
    </div>
    <div class="card">
      <h2>Fitur yang akan aktif</h2>
      <div id="cfFeats"></div>
      <p style="margin-top:10px">Dengan menekan <b>Saya Setuju</b>, kamu mengizinkan pelaporan data di atas
      ke dashboard orang tua. Kamu tetap bisa memutus koneksi nanti.</p>
    </div>
    <button class="btn-p" id="cfBtn" onclick="confirmPair()">Saya Setuju &amp; Hubungkan</button>
    <button class="btn-d" style="margin-top:10px" onclick="rejectPair()">Batalkan (kode jadi tidak berlaku)</button>
  </div>

  <!-- ============ LAYAR: STATUS (terhubung) ============ -->
  <div id="scr-status" class="hidden">
    <div class="card">
      <h2>Status Keamanan Keluarga</h2>
      <span id="stPill" class="pill warn">MEMERIKSA…</span>
      <div style="margin-top:8px" id="stKv">
        <div class="kv"><span>Keluarga</span><b id="stHouse">—</b></div>
        <div class="kv"><span>Anak</span><b id="stChild">—</b></div>
        <div class="kv"><span>Perangkat</span><b id="stDev">—</b></div>
        <div class="kv"><span>Baterai</span><b id="stBat">—</b></div>
        <div class="kv"><span>Jaringan</span><b id="stNet">—</b></div>
        <div class="kv"><span>Sinkron terakhir</span><b id="stSync">—</b></div>
      </div>
    </div>

    <div class="card">
      <h2>Monitoring aktif</h2>
      <div id="stFeats"></div>
    </div>

    <div class="row" style="margin-bottom:10px">
      <button class="btn-s" onclick="syncNow()">Sinkron Sekarang</button>
      <button class="btn-o" onclick="show('about')">Privasi</button>
    </div>

    <button id="locBtn" class="btn-o hidden" style="margin-bottom:10px" onclick="shareLocation()">
      Kirim Lokasi Sekarang (opsional)
    </button>
    <button id="medBtn" class="btn-o hidden" style="margin-bottom:10px" onclick="sharePhoto()">
      Bagikan Foto ke Orang Tua (pilih sendiri)
    </button>
    <input id="photoInput" type="file" accept="image/*" class="hidden" onchange="photoPicked(event)">

    <button class="btn-d" onclick="disconnect()">Putuskan Koneksi</button>
    <p class="note">Putuskan kapan pun kamu mau — orang tua akan melihat status perangkat menjadi offline.</p>
  </div>

  <!-- ============ LAYAR: PRIVASI & TENTANG ============ -->
  <div id="scr-about" class="hidden">
    <div class="card">
      <h2>Privasi &amp; Izin</h2>
      <p><b>Yang dikirim:</b></p>
      <p style="margin:6px 0 12px">- Status perangkat (baterai, jenis jaringan, waktu sinkron)<br>
      - Lokasi GPS <b>hanya</b> jika fitur aktif DAN kamu menekan tombol kirim lokasi<br>
      - Foto <b>hanya</b> yang kamu pilih sendiri lewat tombol bagikan</p>
      <p><b>Yang TIDAK pernah dilakukan aplikasi ini:</b></p>
      <p style="margin:6px 0 12px">- Membaca isi chat / pesan apa pun<br>
      - Mencatat ketikan (keylogger) atau OTP<br>
      - Merekam layar / kamera / mikrofon diam-diam<br>
      - Mengambil seluruh isi galeri tanpa kamu pilih<br>
      - Menyembunyikan diri atau mode siluman<br>
      - Menjalankan perintah jarak jauh</p>
      <p><b>Izin Android:</b> aplikasi hanya meminta izin saat kamu sendiri menekan tombolnya
      (lokasi/kamera). Tidak ada bypass izin sistem.</p>
    </div>
    <div class="card">
      <h2>Tentang</h2>
      <div class="kv"><span>Aplikasi</span><b id="abName">Family Safety</b></div>
      <div class="kv"><span>Versi</span><b id="abVer">—</b></div>
      <div class="kv"><span>Server</span><b id="abSrv">—</b></div>
      <div class="kv"><span>Kebijakan retensi</span><b>lokasi 30 hr • media 30/90 hr</b></div>
      <p style="margin-top:8px">Alasan kepatuhan: membantu orang tua memenuhi kewajiban pengawasan
      sesuai UU ITE &amp; UU PDP — perlindungan anak dari konten/aktor berbahaya.</p>
    </div>
    <button class="btn-o" onclick="backFromAbout()">Kembali</button>
  </div>

  <p class="foot" id="footTxt">FanzzTools V2 • Family Cyber Safety • transparan &amp; bisa diputus anak kapan saja</p>
</div>

<script>
"use strict";
var CFG = ${cfg};
var LS = "fanzzPmCompanion";
var state = { paired: null, hbTimer: 0, lastSync: 0, healthOk: false };
var FEAT_LABEL = {
  usage: ["Statistik pemakaian aplikasi", "ringkasan agregat (native only)"],
  status: ["Status perangkat", "baterai, jaringan, waktu sinkron"],
  location: ["Lokasi", "koordinat GPS saat kamu kirim"],
  media: ["Media", "foto yang kamu pilih sendiri"]
};

function $(id) { return document.getElementById(id); }
function show(scr) {
  var ids = ["welcome", "connect", "confirm", "status", "about"];
  for (var i = 0; i < ids.length; i++) $("scr-" + ids[i]).className = ids[i] === scr ? "" : "hidden";
  window.scrollTo(0, 0);
  if (scr === "status") refreshStatus();
}
function err(msg) {
  var b = $("errbox");
  if (!msg) { b.style.display = "none"; return; }
  b.textContent = msg; b.style.display = "block";
}
function featRows(target, feats) {
  var el = $(target), html = "";
  ["usage", "status", "location", "media"].forEach(function (k) {
    var on = !!(feats && feats[k]);
    html += '<div class="feat' + (on ? " on" : "") + '"><div><span class="dot"></span>' +
      FEAT_LABEL[k][0] + "<small>" + FEAT_LABEL[k][1] + "</small></div><span>" +
      (on ? "AKTIF" : "NONAKTIF") + "</span></div>";
  });
  el.innerHTML = html;
}
function fmtTime(ts) {
  if (!ts) return "belum pernah";
  var s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return s + " detik lalu";
  if (s < 3600) return Math.floor(s / 60) + " menit lalu";
  return Math.floor(s / 3600) + " jam lalu";
}
function save() {
  try { localStorage.setItem(LS, JSON.stringify(state.paired)); } catch (e) {}
}
function load() {
  try { state.paired = JSON.parse(localStorage.getItem(LS) || "null"); } catch (e) { state.paired = null; }
  return state.paired;
}
function api(path, opts) {
  var headers = { "Content-Type": "application/json" };
  if (state.paired && state.paired.token) headers["Authorization"] = "Bearer " + state.paired.token;
  return fetch(CFG.serverUrl + path, Object.assign({ headers: headers }, opts || {}))
    .then(function (r) { return r.json().catch(function () { return { ok: false, error: "Respons server tidak valid" }; }); });
}
function deviceInfo() {
  var ua = navigator.userAgent || "";
  var model = "Perangkat Android";
  var m = ua.match(/Android[^;]*;\\s*([^;)]+)/);
  if (m && m[1] && !/Build/i.test(m[1])) model = m[1].trim();
  var av = (ua.match(/Android\\s+([\\d.]+)/) || [])[1] || "";
  return { model: model, androidVersion: av, appVersion: CFG.version };
}
function battery() {
  if (!navigator.getBattery) return Promise.resolve(null);
  return navigator.getBattery().then(function (b) {
    return { level: Math.round(b.level * 100), charging: b.charging };
  }).catch(function () { return null; });
}
function netType() {
  var c = navigator.connection || {};
  return c.effectiveType || c.type || "tidak diketahui";
}

/* ---------- health check ---------- */
function checkHealth() {
  api("/api/pm/health").then(function (d) {
    state.healthOk = !!d.ok;
    if (!d.ok) err("Server tidak terjangkau. Periksa koneksi internet lalu coba lagi.");
  }).catch(function () {
    state.healthOk = false;
    err("Server tidak terjangkau. Periksa koneksi internet lalu coba lagi.");
  });
}

/* ---------- pairing (2-FASE, zuperupdt #7) ----------
 * FASE 1: scan/input kode → server membuat perangkat PENDING (tanpa token)
 *         dan mengirim consentTicket. Layar persetujuan terbuka → tandai
 *         "shown" supaya orang tua melihat status CONSENT_REQUIRED.
 * FASE 2: anak menekan "Saya Setuju" → consent:true → token diterbitkan.
 *         Anak menekan "Batalkan" → consent:false → kode mati (REJECTED). */
function pairReq(body) {
  var di = deviceInfo();
  // TANPA confirm — consent dikirim HANYA saat anak menekan tombol setuju
  body.model = di.model;
  body.androidVersion = di.androidVersion;
  body.appVersion = di.appVersion;
  err("");
  api("/api/pm/device/enroll", { method: "POST", body: JSON.stringify(body) })
    .then(function (d) {
      if (!d.ok) {
        // galat terstruktur: pesan manusia + kode mesin
        err((d.message || d.error || "Pairing gagal.") + (d.error ? " [" + d.error + "]" : ""));
        return;
      }
      if (d.status === "connected" && d.token) {
        finishPair(d); // defensive — fase 1 normalnya tanpa token
        return;
      }
      state.pending = d; // { deviceId, consentTicket, householdName, ... }
      $("cfHouse").textContent = d.householdName || "-";
      $("cfChild").textContent = d.childNickname || "-";
      $("cfDev").textContent = d.deviceLabel || "-";
      featRows("cfFeats", d.features);
      show("confirm");
      // tandai layar persetujuan terbuka (status → CONSENT_REQUIRED di dashboard)
      api("/api/pm/device/enroll", {
        method: "POST",
        body: JSON.stringify({ deviceId: d.deviceId, consentTicket: d.consentTicket, action: "shown" })
      }).catch(function () {});
    })
    .catch(function () { err("Koneksi gagal — periksa internet."); });
}
function pairingCode() {
  var code = ($("codeInput").value || "").trim();
  // zuperupdt #7: input manual juga menerima TEKS QR penuh (FANZZ-PM1|...) —
  // hasil salin-tempel pemindai QR luar diparse LANGSUNG, tidak "huruf acak".
  if (code.indexOf("FANZZ-PM1|") === 0) {
    pairReq({ qrPayload: code });
    return;
  }
  code = code.toUpperCase();
  if (!/^PM-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code)) {
    err("Format kode: PM-XXXX-XXXX — atau tempel teks QR FANZZ-PM1|… (minta lagi ke orang tua bila ragu)."); return;
  }
  pairReq({ code: code });
}
function confirmPair() {
  var d = state.pending;
  if (!d || !d.deviceId || !d.consentTicket) { show("connect"); return; }
  $("cfBtn").disabled = true;
  err("");
  api("/api/pm/device/enroll", {
    method: "POST",
    body: JSON.stringify({ deviceId: d.deviceId, consentTicket: d.consentTicket, consent: true })
  })
    .then(function (r) {
      $("cfBtn").disabled = false;
      if (!r.ok) {
        err((r.message || "Persetujuan gagal — ulangi pemindaian QR.") + (r.error ? " [" + r.error + "]" : ""));
        show("connect");
        return;
      }
      if (r.status !== "connected" || !r.token) {
        err("Server tidak menerbitkan token — ulangi pemindaian QR.");
        show("connect");
        return;
      }
      finishPair(r);
    })
    .catch(function () { $("cfBtn").disabled = false; err("Koneksi gagal — periksa internet."); });
}
/** Simpan hasil pairing final (hanya setelah consent diterima server). */
function finishPair(d) {
  state.pending = null;
  state.paired = {
    deviceId: d.deviceId, token: d.token, householdName: d.householdName,
    childNickname: d.childNickname, deviceLabel: d.deviceLabel, features: d.features
  };
  save();
  show("status");
  syncNow();
}
/** Anak menekan "Batalkan" → beri tahu server (REJECTED), kembali ke awal. */
function rejectPair() {
  var d = state.pending;
  state.pending = null;
  if (d && d.deviceId && d.consentTicket) {
    api("/api/pm/device/enroll", {
      method: "POST",
      body: JSON.stringify({ deviceId: d.deviceId, consentTicket: d.consentTicket, consent: false })
    }).catch(function () {});
  }
  show("connect");
}
function scanQr() {
  if (!("BarcodeDetector" in window)) {
    $("qrNote").innerHTML = "Perangkat ini tidak mendukung pemindai QR bawaan — <b>pakai kode manual di atas</b> (hasilnya sama).";
    $("qrBtn").disabled = true;
    return;
  }
  $("qrBtn").disabled = true;
  $("qrState").textContent = "memindai…";
  navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } })
    .then(function (stream) {
      var v = $("qrbox");
      v.srcObject = stream; v.className = ""; v.play();
      var det = new window.BarcodeDetector({ formats: ["qr_code"] });
      var tick = function () {
        det.detect(v).then(function (codes) {
          if (codes && codes.length) {
            stream.getTracks().forEach(function (t) { t.stop(); });
            v.className = "hidden";
            var raw = String(codes[0].rawValue || "");
            // QR FanzzTools berformat: FANZZ-PM1|id|code|exp|sig
            if (raw.indexOf("FANZZ-PM1|") !== 0) {
              err("QR bukan QR pairing FanzzTools Parent Monitor."); show("connect"); return;
            }
            pairReq({ qrPayload: raw });
          } else { requestAnimationFrame(tick); }
        }).catch(function () { requestAnimationFrame(tick); });
      };
      requestAnimationFrame(tick);
    })
    .catch(function () {
      $("qrBtn").disabled = false;
      $("qrState").textContent = "opsional";
      $("qrNote").innerHTML = "Kamera tidak diizinkan — <b>masukkan kode manual</b> PM-XXXX-XXXX di atas (hasilnya sama).";
    });
}

/* ---------- status & heartbeat ---------- */
function refreshStatus() {
  var p = load();
  if (!p) { show("welcome"); return; }
  $("stHouse").textContent = p.householdName || "-";
  $("stChild").textContent = p.childNickname || "-";
  $("stDev").textContent = p.deviceLabel || "-";
  $("stSync").textContent = fmtTime(state.lastSync);
  $("stBat").textContent = "…";
  $("stNet").textContent = netType();
  battery().then(function (b) {
    $("stBat").textContent = b ? (b.level + "%" + (b.charging ? " (mengisi)" : "")) : "tidak tersedia";
  });
  featRows("stFeats", p.features);
  $("locBtn").className = p.features && p.features.location ? "btn-o" : "btn-o hidden";
  $("medBtn").className = p.features && p.features.media ? "btn-o" : "btn-o hidden";
  $("stPill").className = "pill warn";
  $("stPill").textContent = "SINKRONISASI…";
}
function syncNow() {
  var p = load();
  if (!p) { show("welcome"); return; }
  var di = deviceInfo();
  battery().then(function (b) {
    var body = {
      battery: b ? b.level : undefined,
      charging: b ? b.charging : undefined,
      network: netType(),
      model: di.model, androidVersion: di.androidVersion, appVersion: di.appVersion,
      permissions: {
        location: p.features && p.features.location ? "granted-web" : "off",
        media: p.features && p.features.media ? "granted-web" : "off",
        usage: "native-only", notifications: "n/a"
      }
    };
    return api("/api/pm/device/heartbeat", { method: "POST", body: JSON.stringify(body) });
  }).then(function (d) {
    if (!d.ok) {
      if (/dicabut|tidak valid/i.test(d.error || "")) { logout("Perangkat sudah diputus dari sisi server."); }
      else { $("stPill").className = "pill err"; $("stPill").textContent = "OFFLINE"; }
      return;
    }
    state.lastSync = Date.now();
    $("stSync").textContent = fmtTime(state.lastSync);
    $("stPill").className = "pill ok";
    $("stPill").textContent = "TERHUBUNG";
    if (d.features) {
      state.paired.features = d.features; save();
      featRows("stFeats", d.features);
    }
    if (d.paused) { $("stPill").className = "pill warn"; $("stPill").textContent = "DIJEDA ORANG TUA"; }
  }).catch(function () {
    $("stPill").className = "pill err"; $("stPill").textContent = "OFFLINE";
  });
}
function shareLocation() {
  var p = load();
  if (!p) return;
  if (!navigator.geolocation) { err("Perangkat ini tidak mendukung GPS."); return; }
  $("locBtn").disabled = true;
  navigator.geolocation.getCurrentPosition(function (pos) {
    api("/api/pm/device/location", {
      method: "POST",
      body: JSON.stringify({ lat: pos.coords.latitude, lon: pos.coords.longitude, accuracy: Math.round(pos.coords.accuracy || 0) })
    }).then(function (d) {
      $("locBtn").disabled = false;
      if (d.ok) err(""); else err(d.error || "Gagal mengirim lokasi.");
    });
  }, function (e) {
    $("locBtn").disabled = false;
    err("Izin lokasi ditolak — orang tua tetap bisa melihat data lain. (" + (e.message || "") + ")");
  }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 });
}
function sharePhoto() { $("photoInput").click(); }
function photoPicked(ev) {
  var f = ev.target.files && ev.target.files[0];
  ev.target.value = "";
  if (!f) return;
  // buat thumbnail kecil (maks 320px, JPEG) — yang dikirim hanya thumbnail + metadata
  var img = new Image();
  var url = URL.createObjectURL(f);
  img.onload = function () {
    var s = Math.min(1, 320 / Math.max(img.width, img.height));
    var c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(img.width * s));
    c.height = Math.max(1, Math.round(img.height * s));
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    URL.revokeObjectURL(url);
    var thumb = c.toDataURL("image/jpeg", 0.6);
    api("/api/pm/device/media", {
      method: "POST",
      body: JSON.stringify({ items: [{ kind: "photo", size: f.size, thumb: thumb }] })
    }).then(function (d) {
      if (d.ok) err(""); else err(d.error || "Gagal mengirim media.");
    });
  };
  img.onerror = function () { URL.revokeObjectURL(url); err("File bukan gambar yang valid."); };
  img.src = url;
}
function disconnect() {
  if (!confirm("Putuskan koneksi monitoring ke orang tua?")) return;
  api("/api/pm/device/disconnect", { method: "POST", body: "{}" }).then(function () {
    logout("Koneksi diputus. Orang tua melihat perangkat ini offline.");
  }).catch(function () { logout("Koneksi diputus (offline)."); });
}
function logout(msg) {
  try { localStorage.removeItem(LS); } catch (e) {}
  state.paired = null;
  if (state.hbTimer) { clearInterval(state.hbTimer); state.hbTimer = 0; }
  show("welcome");
  err(msg || "");
}
function backFromAbout() { show(load() ? "status" : "welcome"); }

/* ---------- init ---------- */
(function init() {
  $("appTitle").textContent = CFG.appName || "Family Safety";
  $("abName").textContent = CFG.appName || "Family Safety";
  $("abVer").textContent = "v" + CFG.version + " (companion web)";
  $("abSrv").textContent = CFG.serverUrl;
  $("footTxt").textContent = CFG.appName + " • FanzzTools V2 Family Cyber Safety • transparan & bisa diputus kapan saja";
  if (CFG.childNickname) {
    $("welcomeChild").innerHTML = "Aplikasi ini menghubungkan perangkat ini dengan akun orang tua/wali " +
      "untuk profil <b>" + CFG.childNickname.replace(/[<>&]/g, "") + "</b>. Mereka bisa membantu " +
      "menjaga keamanan digital kamu.";
  }
  featRows("featList", CFG.features);
  checkHealth();
  var p = load();
  if (p && p.token) {
    show("status");
    syncNow();
    // heartbeat ringan tiap 60 dtk selama aplikasi TERBUKA (bukan pelacak diam-diam)
    if (state.hbTimer) clearInterval(state.hbTimer);
    state.hbTimer = setInterval(syncNow, 60000);
  } else {
    show("welcome");
  }
})();
</script>
</body>
</html>
`;
}
