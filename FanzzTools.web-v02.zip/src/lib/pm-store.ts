import crypto from "crypto";
import type { SessionPayload } from "@/lib/session";
import { loadJson, saveJsonDebounced, onDbHydrated } from "@/lib/persist";

/**
 * Parent Monitor / Family Cyber Safety — store server-side (V2.12).
 *
 * PRINSIP DESAIN (sesuai spesifikasi pemilik):
 *  - TRANSPAREN: companion di perangkat anak SELALU menampilkan fitur apa
 *    saja yang aktif; anak bisa memutus koneksi sendiri (Disconnect).
 *  - QR enrollment: satu-kali-pakai, kedaluwarsa 10 menit, bertanda-tangan
 *    HMAC, TIDAK berisi rahasia permanen apa pun.
 *  - Token perangkat: acak tinggi-entropi, disimpan sebagai HASH, bisa
 *    dicabut/dirotasi kapan saja. Bukan global token.
 *  - Isolasi household total: parent A tidak bisa membaca data parent B.
 *  - TANPA fitur spyware: tidak ada keylogger, intersep OTP, rekam diam-diam,
 *    akses galeri tersembunyi, shell jarak jauh, stealth mode, dsb.
 *  - Monitoring penggunaan aplikasi = statistik agregat yang DIKIRIM perangkat
 *    anak sendiri melalui companion (UsageStatsManager di sisi Android
 *    native; companion WebView melaporkan apa yang platform izinkan).
 *
 * Penyimpanan: in-memory + file JSON (data/pm.json) — konsisten dengan
 * arsitektur FanzzTools V2 tanpa DB eksternal.
 */

/* ================= TIPE DATA ================= */

export interface PmAttestation {
  confirmedAt: number;
  /** tahun lahir orang tua (opsional — TIDAK dipakai untuk auth/otorisasi) */
  parentBirthYear?: number;
}

export interface PmHousehold {
  id: string;
  parentUid: string;
  parentUsername: string;
  name: string;
  attestation?: PmAttestation;
  createdAt: number;
}

export interface PmChild {
  id: string;
  householdId: string;
  nickname: string;
  birthYear?: number;
  avatar?: string;
  notes?: string;
  createdAt: number;
  disabled: boolean;
}

export type DeviceStatus = "waiting" | "pending_consent" | "connected" | "paused" | "revoked" | "rejected";

export interface PmFeatures {
  usage: boolean;
  status: boolean;
  location: boolean;
  media: boolean;
}

export interface PmDevice {
  id: string;
  householdId: string;
  childId: string;
  label: string;
  model?: string;
  androidVersion?: string;
  appVersion?: string;
  battery?: number;
  charging?: boolean;
  network?: string;
  lastSeen?: number;
  lastSync?: number;
  status: DeviceStatus;
  features: PmFeatures;
  permissions?: Record<string, string>;
  createdAt: number;
  revokedAt?: number;
}

export interface DeviceTokenRow {
  id: string;
  deviceId: string;
  tokenHash: string;
  createdAt: number;
  lastUsedAt?: number;
  expiresAt: number;
  revokedAt?: number;
  rotatedAt?: number;
}

/* ================= ENROLLMENT — MESIN STATUS (zuperupdt #7) =================
 *
 * DULU (cacat): consumeEnrollment membuat perangkat LANGSUNG "connected"
 * + mengeluarkan token pada saat SCAN — layar "Saya Setuju" di companion
 * murni kosmetik. Jika anak menekan Batal, perangkat tetap terhubung di
 * dashboard orang tua (koneksi hantu) & kode terkunci "sudah dipakai"
 * (inilah "kode pairing macet" yang dilaporkan).
 *
 * SEKARANG — mesin status eksplisit, consent WAJIB sebelum koneksi:
 *   CREATED          QR/kode dibuat orang tua (menunggu pemindaian)
 *   PENDING          perangkat telah scan/input kode — dibuat baris perangkat
 *                    status "pending_consent", TANPA token; menunggu anak
 *   CONSENT_REQUIRED companion membuka layar persetujuan (menandai status ini
 *                    supaya orang tua melihat "menunggu persetujuan anak")
 *   CONNECTED        anak menekan "Saya Setuju" → token diterbitkan
 *   REJECTED         anak menolak / membatalkan → kode mati, perangkat rejected
 *   EXPIRED          lewat TTL 10 menit sebelum connected
 *   REVOKED          dibatalkan orang tua / perangkat diputus
 */
export type EnrollStatus =
  | "created"
  | "pending"
  | "consent_required"
  | "connected"
  | "revoked"
  | "expired"
  | "rejected";

/** Nama status lama → baru (file data lama tetap terbaca). */
const LEGACY_ENROLL: Record<string, EnrollStatus> = {
  waiting: "created",
  scanned: "pending",
  confirming: "consent_required",
  cancelled: "revoked",
  failed: "rejected",
};

const ENROLL_STATUSES = ["created", "pending", "consent_required", "connected", "revoked", "expired", "rejected"];

export function normalizeEnrollStatus(s: string): EnrollStatus {
  return LEGACY_ENROLL[s] || (ENROLL_STATUSES.includes(s) ? (s as EnrollStatus) : "created");
}

/** Galat terstruktur — kode mesin + pesan manusia (zuperupdt #7:
 *  "pembedaan galat terstruktur" supaya companion bisa menampilkan
 *  pesan tepat: QR rusak ≠ kedaluwarsa ≠ sudah dipakai ≠ dibatalkan). */
export interface PmError {
  code:
    | "INVALID_QR"
    | "QR_SIGNATURE_INVALID"
    | "PAIRING_NOT_FOUND"
    | "PAIRING_EXPIRED"
    | "PAIRING_USED"
    | "PAIRING_CANCELLED"
    | "PAIRING_REJECTED"
    | "HOUSEHOLD_GONE"
    | "CONSENT_REQUIRED"
    | "CONSENT_NOT_SHOWN"
    | "DEVICE_NOT_PENDING"
    | "CONSENT_INVALID"
    | "CONSENT_EXPIRED"
    | "RATE_LIMITED"
    | "BAD_REQUEST";
  message: string;
}
export type PmResult<T> = { ok: true; data: T } | { ok: false; error: PmError };
const err = (code: PmError["code"], message: string): { ok: false; error: PmError } => ({ ok: false, error: { code, message } });

export interface EnrollmentRow {
  id: string;
  householdId: string;
  childId: string;
  deviceLabel: string;
  /** kode pendek untuk input manual (PM-XXXX-XXXX) */
  code: string;
  nonce: string;
  createdAt: number;
  expiresAt: number;
  status: EnrollStatus;
  usedAt?: number;
  deviceId?: string;
  /** tiket persetujuan anak — diterbitkan saat PENDING, sekali pakai,
   *  umur sama dengan sisa TTL enrollment (default 10 menit). */
  consentTicket?: string;
  consentIssuedAt?: number;
  consentAt?: number;
  /** V2.12: fitur yang dipilih orang tua saat membuat QR — dipakai saat
   *  perangkat dibuat pada saat pairing. Default: usage+status aktif,
   *  location+media mati. */
  features?: PmFeatures;
}

export interface UsageRow {
  key: string; // deviceId|date|package
  householdId: string;
  childId: string;
  deviceId: string;
  date: string; // YYYY-MM-DD
  pkg: string;
  app: string;
  usageMs: number;
  launches: number;
  updatedAt: number;
}

export interface LocationRow {
  id: string;
  householdId: string;
  deviceId: string;
  lat: number;
  lon: number;
  accuracy?: number;
  ts: number;
}

export interface MediaRow {
  id: string;
  householdId: string;
  deviceId: string;
  kind: "photo" | "video";
  size?: number;
  thumb?: string; // data URL kecil (≤60KB)
  ts: number;
}

export interface PmAlert {
  id: string;
  householdId: string;
  childId?: string;
  deviceId?: string;
  type: string;
  msg: string;
  ts: number;
}

export interface AuditRow {
  id: string;
  householdId: string;
  actor: string;
  action: string;
  detail?: string;
  ts: number;
}

interface PmState {
  households: Map<string, PmHousehold>;
  children: Map<string, PmChild>;
  devices: Map<string, PmDevice>;
  tokens: Map<string, DeviceTokenRow>; // key: tokenHash
  enrollments: Map<string, EnrollmentRow>;
  usage: Map<string, UsageRow>;
  locations: LocationRow[];
  media: Map<string, MediaRow>;
  alerts: PmAlert[];
  audit: AuditRow[];
}

/* ================= STATE + PERSIST ================= */

const g = globalThis as unknown as { __fanzzPm?: PmState; __fanzzPmSweep?: ReturnType<typeof setInterval> | null };

if (!g.__fanzzPm) {
  g.__fanzzPm = {
    households: new Map(),
    children: new Map(),
    devices: new Map(),
    tokens: new Map(),
    enrollments: new Map(),
    usage: new Map(),
    locations: [],
    media: new Map(),
    alerts: [],
    audit: [],
  };
  const restorePm = () => {
    const P = g.__fanzzPm;
    if (!P) return;
    const saved = loadJson<{
      households?: PmHousehold[];
      children?: PmChild[];
      devices?: PmDevice[];
      tokens?: DeviceTokenRow[];
      enrollments?: EnrollmentRow[];
      usage?: UsageRow[];
      locations?: LocationRow[];
      media?: MediaRow[];
      alerts?: PmAlert[];
      audit?: AuditRow[];
    }>("pm");
    if (saved) {
      try {
        const now = Date.now();
        for (const h of saved.households || []) if (h?.id) P.households.set(h.id, h);
        for (const c of saved.children || []) if (c?.id) P.children.set(c.id, c);
        for (const d of saved.devices || []) if (d?.id) P.devices.set(d.id, d);
        for (const t of saved.tokens || []) if (t?.tokenHash) P.tokens.set(t.tokenHash, t);
        for (const e of saved.enrollments || []) {
          // enrollment belum terpakai & belum kedaluwarsa saja yang dipulihkan
          // (zuperupdt #7: status baru created/pending/consent_required; file
          //  lama memakai nama lama → dinormalisasi dulu)
          const st = e ? normalizeEnrollStatus(String(e.status)) : "connected";
          if (e?.id && (st === "created" || st === "pending" || st === "consent_required") && e.expiresAt > now) {
            e.status = st;
            P.enrollments.set(e.id, e);
          }
        }
        for (const u of saved.usage || []) if (u?.key) P.usage.set(u.key, u);
        P.locations = (saved.locations || []).filter((l) => l && l.ts > now - 30 * 864e5).slice(-2000);
        for (const m of saved.media || []) if (m?.id) P.media.set(m.id, m);
        P.alerts = (saved.alerts || []).slice(-200);
        P.audit = (saved.audit || []).slice(-500);
      } catch {
        /* file rusak → mulai kosong */
      }
    }
  };
  restorePm();
  /* FanzSec-Update: instance serverless baru → snapshot PM dipulihkan dari
   * DATABASE (Neon) supaya enrollment/device tidak hilang saat cold-start. */
  onDbHydrated((keys) => {
    const st = g.__fanzzPm;
    if (st && keys.includes("pm") && st.households.size === 0) restorePm();
  });
}

const PM = g.__fanzzPm;

function persistPm() {
  saveJsonDebounced("pm", () => {
    let usage = [...PM.usage.values()];
    let media = [...PM.media.values()];
    let json = JSON.stringify({ ...serializeCore(), usage, media });
    while (json.length > 20 * 1024 * 1024 && (usage.length > 2000 || media.length > 500)) {
      if (media.length > 500) media = media.slice(-500);
      else if (usage.length > 2000) usage = usage.slice(-2000);
      json = JSON.stringify({ ...serializeCore(), usage, media });
    }
    return json;
    function serializeCore() {
      const now = Date.now();
      return {
        households: [...PM.households.values()],
        children: [...PM.children.values()],
        devices: [...PM.devices.values()],
        tokens: [...PM.tokens.values()],
        enrollments: [...PM.enrollments.values()].filter((e) => {
          const st = normalizeEnrollStatus(e.status);
          return (st === "created" || st === "pending" || st === "consent_required") && e.expiresAt > now;
        }),
        locations: PM.locations.slice(-1000),
        alerts: PM.alerts.slice(-200),
        audit: PM.audit.slice(-500),
      };
    }
  });
}

/* ================= KONSTANTA ================= */

export const PM_ENROLL_TTL_MS = 10 * 60 * 1000; // QR kedaluwarsa 10 menit
export const PM_CHILD_MAX_AGE = 35; // permintaan pemilik: batas usia anak 35 tahun
export const PM_ADULT_AGE = 18;
export const RETENTION = { usageDays: 90, locationDays: 30, mediaMetaDays: 90, thumbDays: 30 };

/* ================= SIG / TOKEN / KUNCI ================= */

function pmSecret(): string {
  const env = process.env.APP_SECRET;
  if (env && env.trim().length >= 32) return `${env.trim()}#fanzz-pm-v1`;
  if (process.env.NODE_ENV === "production") {
    // session.ts sudah melempar duluan di production tanpa APP_SECRET;
    // jalur ini hanya pengaman konsistensi.
    throw new Error("[FanzzTools] APP_SECRET wajib di-set untuk Parent Monitor.");
  }
  return `dev-pm-${process.pid}-${(globalThis as { __fanzzPmDevKey?: string }).__fanzzPmDevKey || ""}`;
}
if (process.env.NODE_ENV !== "production") {
  (globalThis as { __fanzzPmDevKey?: string }).__fanzzPmDevKey = crypto.randomUUID();
}

function hmacSig(parts: string): string {
  return crypto.createHmac("sha256", pmSecret()).update(`FANZZ-PM1|${parts}`).digest("base64url");
}

function sha256(s: string): string {
  return crypto.createHash("sha256").update(s).digest("hex");
}

function randomToken(): string {
  return crypto.randomBytes(32).toString("base64url");
}

/** Kode pendek yang mudah diketik (tanpa karakter ambigu). */
function shortCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const pick = (n: number) =>
    Array.from({ length: n }, () => alphabet[crypto.randomInt(alphabet.length)]).join("");
  return `PM-${pick(4)}-${pick(4)}`;
}

const rid = (prefix: string) =>
  `${prefix}${Date.now().toString(36)}${crypto.randomBytes(4).toString("hex")}`;

/* ================= AUDIT & ALERT ================= */

function audit(householdId: string, actor: string, action: string, detail?: string) {
  PM.audit.push({ id: rid("a"), householdId, actor, action, detail: detail?.slice(0, 200), ts: Date.now() });
  if (PM.audit.length > 600) PM.audit.splice(0, PM.audit.length - 600);
  persistPm();
}

function alertOf(householdId: string, type: string, msg: string, childId?: string, deviceId?: string) {
  // satu alert per jenis per perangkat per jam (anti spam)
  const dupWindow = Date.now() - 60 * 60 * 1000;
  if (PM.alerts.some((a) => a.type === type && a.deviceId === deviceId && a.ts > dupWindow)) return;
  PM.alerts.push({ id: rid("al"), householdId, childId, deviceId, type, msg: msg.slice(0, 200), ts: Date.now() });
  if (PM.alerts.length > 300) PM.alerts.splice(0, PM.alerts.length - 300);
  persistPm();
}

/* ================= HOUSEHOLD ================= */

export function getHousehold(session: SessionPayload): PmHousehold {
  let h = [...PM.households.values()].find((x) => x.parentUid === session.uid);
  if (!h) {
    h = {
      id: rid("hh"),
      parentUid: session.uid,
      parentUsername: session.username,
      name: `Keluarga ${session.username}`,
      createdAt: Date.now(),
    };
    PM.households.set(h.id, h);
    audit(h.id, session.uid, "HOUSEHOLD_CREATED", h.name);
  } else if (h.parentUsername !== session.username) {
    h.parentUsername = session.username;
  }
  return h;
}

export function setAttestation(session: SessionPayload, parentBirthYear?: number): PmHousehold {
  const h = getHousehold(session);
  h.attestation = { confirmedAt: Date.now(), parentBirthYear };
  audit(h.id, session.uid, "ATTESTATION_CONFIRMED", "pernyataan wali resmi");
  persistPm();
  return h;
}

export function isAttested(h: PmHousehold): boolean {
  return !!h.attestation?.confirmedAt;
}

/* ================= CHILDREN ================= */

export function listChildren(householdId: string): PmChild[] {
  return [...PM.children.values()]
    .filter((c) => c.householdId === householdId)
    .sort((a, b) => a.createdAt - b.createdAt);
}

export interface ChildInput {
  nickname: string;
  birthYear?: number;
  avatar?: string;
  notes?: string;
}

export function childAge(c: PmChild): number | null {
  if (!c.birthYear) return null;
  const age = new Date().getFullYear() - c.birthYear;
  return age >= 0 && age <= 120 ? age : null;
}

export function createChild(session: SessionPayload, input: ChildInput):
  { ok: true; child: PmChild; warning?: string } | { ok: false; error: string } {
  const h = getHousehold(session);
  if (!isAttested(h)) return { ok: false, error: "Konfirmasi pernyataan wali resmi dulu (langkah onboarding)." };
  const nickname = (input.nickname || "").replace(/\s+/g, " ").trim().slice(0, 30);
  if (nickname.length < 2) return { ok: false, error: "Nama panggilan minimal 2 karakter." };

  let warning: string | undefined;
  if (input.birthYear) {
    const year = Math.floor(Number(input.birthYear));
    const now = new Date().getFullYear();
    if (!Number.isFinite(year) || year < 1900 || year > now) {
      return { ok: false, error: "Tahun lahir tidak valid." };
    }
    const age = now - year;
    if (age > PM_CHILD_MAX_AGE) {
      return { ok: false, error: `Batas usia profil anak adalah ${PM_CHILD_MAX_AGE} tahun (permintaan keamanan agar tool ini tidak disalahgunakan untuk memantau orang dewasa).` };
    }
    if (age >= PM_ADULT_AGE) {
      warning = `Usia ${age} tahun — anak sudah dewasa; pantau HANYA dengan persetujuan tertulisnya. Perlindungan UU PDP tetap berlaku.`;
    }
  }

  const child: PmChild = {
    id: rid("ch"),
    householdId: h.id,
    nickname,
    birthYear: input.birthYear ? Math.floor(Number(input.birthYear)) : undefined,
    avatar: input.avatar && /^data:image\/(png|jpe?g|webp);base64,/.test(input.avatar.slice(0, 40)) && input.avatar.length <= 100 * 1024 ? input.avatar : undefined,
    notes: input.notes?.slice(0, 200),
    createdAt: Date.now(),
    disabled: false,
  };
  PM.children.set(child.id, child);
  audit(h.id, session.uid, "CHILD_CREATED", nickname);
  persistPm();
  return { ok: true, child, warning };
}

export function updateChild(session: SessionPayload, childId: string, patch: Partial<ChildInput> & { disabled?: boolean }):
  { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const c = PM.children.get(childId);
  if (!c || c.householdId !== h.id) return { ok: false, error: "Profil anak tidak ditemukan." };
  if (patch.nickname !== undefined) {
    const nickname = patch.nickname.replace(/\s+/g, " ").trim().slice(0, 30);
    if (nickname.length < 2) return { ok: false, error: "Nama panggilan minimal 2 karakter." };
    c.nickname = nickname;
  }
  if (patch.birthYear !== undefined) {
    if (patch.birthYear === null || Number(patch.birthYear) === 0) c.birthYear = undefined;
    else {
      const year = Math.floor(Number(patch.birthYear));
      const now = new Date().getFullYear();
      if (!Number.isFinite(year) || year < 1900 || year > now) return { ok: false, error: "Tahun lahir tidak valid." };
      if (now - year > PM_CHILD_MAX_AGE) return { ok: false, error: `Batas usia profil anak adalah ${PM_CHILD_MAX_AGE} tahun.` };
      c.birthYear = year;
    }
  }
  if (patch.avatar !== undefined) {
    c.avatar = patch.avatar && /^data:image\/(png|jpe?g|webp);base64,/.test(patch.avatar.slice(0, 40)) && patch.avatar.length <= 100 * 1024 ? patch.avatar : undefined;
  }
  if (patch.notes !== undefined) c.notes = patch.notes?.slice(0, 200);
  if (patch.disabled !== undefined) c.disabled = !!patch.disabled;
  audit(h.id, session.uid, "CHILD_UPDATED", c.nickname);
  persistPm();
  return { ok: true };
}

export function deleteChild(session: SessionPayload, childId: string): { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const c = PM.children.get(childId);
  if (!c || c.householdId !== h.id) return { ok: false, error: "Profil anak tidak ditemukan." };
  // cabut semua perangkat anak ini
  for (const d of PM.devices.values()) {
    if (d.childId === childId) revokeDevice(session, d.id);
  }
  PM.children.delete(childId);
  audit(h.id, session.uid, "CHILD_DELETED", c.nickname);
  persistPm();
  return { ok: true };
}

/* ================= DEVICES ================= */

export function listDevices(householdId: string): PmDevice[] {
  return [...PM.devices.values()]
    .filter((d) => d.householdId === householdId)
    .sort((a, b) => b.createdAt - a.createdAt);
}

export function createDevice(session: SessionPayload, childId: string, label: string, features: Partial<PmFeatures>):
  { ok: true; device: PmDevice } | { ok: false; error: string } {
  const h = getHousehold(session);
  const c = PM.children.get(childId);
  if (!c || c.householdId !== h.id) return { ok: false, error: "Profil anak tidak ditemukan." };
  const cleanLabel = (label || "").replace(/\s+/g, " ").trim().slice(0, 40) || `Perangkat ${c.nickname}`;
  const device: PmDevice = {
    id: rid("dv"),
    householdId: h.id,
    childId,
    label: cleanLabel,
    status: "waiting",
    features: {
      usage: features.usage !== false,
      status: features.status !== false,
      location: features.location === true,
      media: features.media === true,
    },
    createdAt: Date.now(),
  };
  PM.devices.set(device.id, device);
  audit(h.id, session.uid, "DEVICE_CREATED", `${cleanLabel} → ${c.nickname}`);
  persistPm();
  return { ok: true, device };
}

export function patchDevice(session: SessionPayload, deviceId: string, patch: { label?: string; status?: DeviceStatus; features?: Partial<PmFeatures> }):
  { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return { ok: false, error: "Perangkat tidak ditemukan." };
  if (patch.label !== undefined) d.label = patch.label.replace(/\s+/g, " ").trim().slice(0, 40) || d.label;
  if (patch.features) {
    if (patch.features.usage !== undefined) d.features.usage = !!patch.features.usage;
    if (patch.features.status !== undefined) d.features.status = !!patch.features.status;
    if (patch.features.location !== undefined) {
      if (d.features.location && !patch.features.location) audit(h.id, session.uid, "LOCATION_DISABLED", d.label);
      if (!d.features.location && patch.features.location) audit(h.id, session.uid, "LOCATION_ENABLED", d.label);
      d.features.location = !!patch.features.location;
    }
    if (patch.features.media !== undefined) {
      if (d.features.media && !patch.features.media) audit(h.id, session.uid, "MEDIA_ACCESS_REVOKED", d.label);
      if (!d.features.media && patch.features.media) audit(h.id, session.uid, "MEDIA_ACCESS_ENABLED", d.label);
      d.features.media = !!patch.features.media;
    }
  }
  if (patch.status) {
    if (patch.status === "paused" && d.status === "connected") {
      d.status = "paused";
      audit(h.id, session.uid, "DEVICE_DISABLED", d.label);
    } else if (patch.status === "connected" && d.status === "paused") {
      d.status = "connected";
      audit(h.id, session.uid, "DEVICE_ENABLED", d.label);
    }
  }
  persistPm();
  return { ok: true };
}

export function revokeDevice(session: SessionPayload, deviceId: string): { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return { ok: false, error: "Perangkat tidak ditemukan." };
  d.status = "revoked";
  d.revokedAt = Date.now();
  for (const t of PM.tokens.values()) {
    if (t.deviceId === deviceId && !t.revokedAt) t.revokedAt = Date.now();
  }
  audit(h.id, session.uid, "DEVICE_REVOKED", d.label);
  alertOf(h.id, "device_revoked", `Perangkat "${d.label}" dicabut — kredensialnya langsung tidak valid.`, d.childId, d.id);
  persistPm();
  return { ok: true };
}

export function deleteDevice(session: SessionPayload, deviceId: string): { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return { ok: false, error: "Perangkat tidak ditemukan." };
  PM.devices.delete(deviceId);
  for (const [hash, t] of PM.tokens) if (t.deviceId === deviceId) PM.tokens.delete(hash);
  PM.locations = PM.locations.filter((l) => l.deviceId !== deviceId);
  for (const [id, m] of PM.media) if (m.deviceId === deviceId) PM.media.delete(id);
  for (const [key, u] of PM.usage) if (u.deviceId === deviceId) PM.usage.delete(key);
  audit(h.id, session.uid, "DEVICE_DELETED", d.label);
  persistPm();
  return { ok: true };
}

/* ================= ENROLLMENT (QR) ================= */

export interface EnrollmentFull {
  row: EnrollmentRow;
  /** payload QR bertanda-tangan (aman dibagikan — tanpa rahasia permanen) */
  qrPayload: string;
  code: string;
  expiresAt: number;
}

export function generateEnrollment(session: SessionPayload, childId: string, deviceLabel: string, features?: Partial<PmFeatures>):
  { ok: true; enrollment: EnrollmentFull } | { ok: false; error: string } {
  const h = getHousehold(session);
  if (!isAttested(h)) return { ok: false, error: "Konfirmasi pernyataan wali resmi dulu." };
  const c = PM.children.get(childId);
  if (!c || c.householdId !== h.id) return { ok: false, error: "Profil anak tidak ditemukan." };

  const row: EnrollmentRow = {
    id: rid("en"),
    householdId: h.id,
    childId,
    deviceLabel: (deviceLabel || "").replace(/\s+/g, " ").trim().slice(0, 40) || `Perangkat ${c.nickname}`,
    code: shortCode(),
    nonce: crypto.randomBytes(16).toString("hex"),
    createdAt: Date.now(),
    expiresAt: Date.now() + PM_ENROLL_TTL_MS,
    status: "created", // zuperupdt #7: mesin status baru (dulu "waiting")
    // V2.12: fitur pilihan orang tua ikut dengan QR (default aman bila tak diisi)
    features: {
      usage: features?.usage !== false,
      status: features?.status !== false,
      location: features?.location === true,
      media: features?.media === true,
    },
  };
  PM.enrollments.set(row.id, row);
  audit(h.id, session.uid, "QR_GENERATED", `${row.code} → ${c.nickname} / ${row.deviceLabel}`);
  persistPm();
  return { ok: true, enrollment: { row, qrPayload: buildQrPayload(row), code: row.code, expiresAt: row.expiresAt } };
}

function buildQrPayload(row: EnrollmentRow): string {
  const sig = hmacSig(`${row.id}|${row.code}|${row.expiresAt}`);
  return `FANZZ-PM1|${row.id}|${row.code}|${row.expiresAt}|${sig}`;
}

export function cancelEnrollment(session: SessionPayload, enrollmentId: string): { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const row = PM.enrollments.get(enrollmentId);
  if (!row || row.householdId !== h.id) return { ok: false, error: "Kode enrollment tidak ditemukan." };
  const st = normalizeEnrollStatus(row.status);
  if (st === "created" || st === "pending" || st === "consent_required") {
    row.status = "revoked";
    // perangkat pending ikut dicabut supaya tidak menggantung
    if (row.deviceId) {
      const d = PM.devices.get(row.deviceId);
      if (d && d.status === "pending_consent") d.status = "revoked";
    }
    audit(h.id, session.uid, "QR_CANCELLED", row.code);
    persistPm();
  }
  return { ok: true };
}

export function getEnrollmentStatus(session: SessionPayload, enrollmentId: string):
  { ok: true; status: EnrollStatus; expiresAt: number; deviceId?: string } | { ok: false; error: string } {
  const h = getHousehold(session);
  const row = PM.enrollments.get(enrollmentId);
  if (!row || row.householdId !== h.id) return { ok: false, error: "Kode enrollment tidak ditemukan." };
  const st = normalizeEnrollStatus(row.status);
  if ((st === "created" || st === "pending" || st === "consent_required") && Date.now() > row.expiresAt) {
    row.status = "expired";
    // perangkat yang belum disetujui ikut ditandai kedaluwarsa (bukan connected)
    if (row.deviceId) {
      const d = PM.devices.get(row.deviceId);
      if (d && d.status === "pending_consent") d.status = "revoked";
    }
    audit(h.id, session.uid, "QR_EXPIRED", row.code);
    persistPm();
    return { ok: true, status: "expired", expiresAt: row.expiresAt, deviceId: row.deviceId };
  }
  return { ok: true, status: st, expiresAt: row.expiresAt, deviceId: row.deviceId };
}

export interface EnrollDeviceInfo {
  model?: string;
  androidVersion?: string;
  appVersion?: string;
}

/** Hasil FASE 1 (scan) — TANPA token; consent anak dulu. */
export interface EnrollPreview {
  deviceId: string;
  consentTicket: string;
  householdName: string;
  childNickname: string;
  deviceLabel: string;
  features: PmFeatures;
  consentRequired: true;
}

/**
 * FASE 1 (zuperupdt #7): perangkat anak memindai QR / memasukkan kode.
 * - Validasi QR bertanda-tangan FANZZ-PM1|id|code|exp|sig (protokol kustom
 *   diparse LANGSUNG di sini — bukan lewat parser luar).
 * - Membuat baris perangkat status "pending_consent" (BUKAN connected).
 * - Menerbitkan consentTicket sekali-pakai (hash disimpan).
 * - TIDAK menerbitkan token perangkat — token hanya setelah anak setuju.
 * Idempotent: pemindaian ulang kode yang sama sebelum consent mengembalikan
 * tiket yang sudah ada (mencegah "kode macet" bila aplikasi tertutup).
 */
export function beginEnrollment(input: { qrPayload?: string; code?: string }, dev: EnrollDeviceInfo): PmResult<EnrollPreview> {
  const now = Date.now();

  let row: EnrollmentRow | undefined;
  if (input.qrPayload) {
    const parts = input.qrPayload.trim().split("|");
    if (parts.length !== 5 || parts[0] !== "FANZZ-PM1") {
      return err("INVALID_QR", "QR bukan QR pairing FanzzTools Parent Monitor (format FANZZ-PM1 tidak dikenal).");
    }
    const [, id, code, expStr, sig] = parts;
    if (hmacSig(`${id}|${code}|${expStr}`) !== sig) {
      return err("QR_SIGNATURE_INVALID", "Tanda tangan QR tidak valid — QR mungkin rusak/terpotong. Minta QR baru ke orang tua.");
    }
    if (Number(expStr) < now) return err("PAIRING_EXPIRED", "QR kedaluwarsa — minta kode baru ke orang tua.");
    row = PM.enrollments.get(id);
    if (row && row.code !== code) row = undefined;
  } else if (input.code) {
    const clean = input.code.replace(/\s+/g, "").toUpperCase();
    row = [...PM.enrollments.values()].find((r) => r.code === clean);
  }

  if (!row) return err("PAIRING_NOT_FOUND", "Kode enrollment tidak ditemukan. Periksa kembali atau minta kode baru ke orang tua.");
  const st = normalizeEnrollStatus(row.status);

  if (st === "connected") return err("PAIRING_USED", "Kode sudah dipakai (satu kali pakai). Minta kode baru ke orang tua.");
  if (st === "revoked") return err("PAIRING_CANCELLED", "Kode sudah dibatalkan orang tua. Minta kode baru.");
  if (st === "rejected") return err("PAIRING_REJECTED", "Koneksi sudah ditolak dari perangkat anak. Minta kode baru ke orang tua.");
  if (st === "expired" || now > row.expiresAt) {
    row.status = "expired";
    persistPm();
    return err("PAIRING_EXPIRED", "Kode kedaluwarsa — minta kode baru ke orang tua.");
  }

  const h = PM.households.get(row.householdId);
  const c = PM.children.get(row.childId);
  if (!h || !c || c.disabled) {
    row.status = "rejected";
    persistPm();
    return err("HOUSEHOLD_GONE", "Keluarga/profil anak tidak tersedia lagi di server.");
  }

  // idempotent: perangkat pending untuk enrollment ini sudah ada → ganti
  // tiket lama dengan tiket BARU (tiket lama mungkin sudah hilang di klien
  // karena app tertutup — ini pencegah "kode pairing macet")
  if (st === "pending" || st === "consent_required") {
    if (row.deviceId) {
      const d = PM.devices.get(row.deviceId);
      if (d && d.status === "pending_consent") {
        // perbarui info perangkat (mis. app version baru)
        if (dev.model) d.model = dev.model.slice(0, 60);
        if (dev.androidVersion) d.androidVersion = dev.androidVersion.slice(0, 20);
        if (dev.appVersion) d.appVersion = dev.appVersion.slice(0, 20);
        const ticketBaru = randomToken();
        row.consentTicket = sha256(ticketBaru);
        row.consentIssuedAt = now;
        persistPm();
        return {
          ok: true,
          data: {
            deviceId: d.id,
            consentTicket: ticketBaru,
            householdName: h.name,
            childNickname: c.nickname,
            deviceLabel: d.label,
            features: d.features,
            consentRequired: true,
          },
        };
      }
    }
  }

  // buat perangkat status PENDING_CONSENT — tanpa token (zuperupdt #7)
  const device: PmDevice = {
    id: rid("dv"),
    householdId: h.id,
    childId: c.id,
    label: row.deviceLabel,
    model: dev.model?.slice(0, 60),
    androidVersion: dev.androidVersion?.slice(0, 20),
    appVersion: dev.appVersion?.slice(0, 20),
    status: "pending_consent",
    features: row.features || { usage: true, status: true, location: false, media: false },
    createdAt: now,
    lastSeen: now,
  };
  PM.devices.set(device.id, device);

  const consentTicket = randomToken();
  row.status = "pending";
  row.deviceId = device.id;
  row.consentTicket = sha256(consentTicket); // disimpan sebagai HASH
  row.consentIssuedAt = now;

  audit(h.id, `device:${device.id}`, "DEVICE_SCAN_PENDING", `${device.label} memindai kode — menunggu persetujuan anak`);
  persistPm();
  return {
    ok: true,
    data: {
      deviceId: device.id,
      consentTicket,
      householdName: h.name,
      childNickname: c.nickname,
      deviceLabel: device.label,
      features: device.features,
      consentRequired: true,
    },
  };
}

/** FASE 1b: companion membuka layar persetujuan → status CONSENT_REQUIRED
 *  (orang tua melihat "menunggu persetujuan anak" secara live). */
export function markConsentShown(deviceId: string, consentTicket: string): PmResult<{ status: EnrollStatus }> {
  const row = [...PM.enrollments.values()].find((r) => r.deviceId === deviceId);
  if (!row) return err("PAIRING_NOT_FOUND", "Enrollment tidak ditemukan.");
  if (!row.consentTicket || row.consentTicket !== sha256(consentTicket)) {
    return err("CONSENT_INVALID", "Tiket persetujuan tidak valid.");
  }
  const st = normalizeEnrollStatus(row.status);
  if (st !== "pending" && st !== "consent_required") {
    return err("DEVICE_NOT_PENDING", "Enrollment ini sudah tidak menunggu persetujuan.");
  }
  row.status = "consent_required";
  persistPm();
  return { ok: true, data: { status: "consent_required" } };
}

/** FASE 2: anak menekan "Saya Setuju" (accept=true) atau menolak (false).
 *  accept=true  → status CONNECTED + token perangkat diterbitkan (satu kali lihat)
 *  accept=false → status REJECTED, kode mati, perangkat rejected. */
export function completeEnrollment(deviceId: string, consentTicket: string, accept: boolean):
  PmResult<{ token?: string; deviceId: string; householdName: string; childNickname: string; features: PmFeatures; deviceLabel: string; status: EnrollStatus }> {
  const now = Date.now();
  const row = [...PM.enrollments.values()].find((r) => r.deviceId === deviceId);
  if (!row) return err("PAIRING_NOT_FOUND", "Enrollment tidak ditemukan.");
  if (!row.consentTicket || row.consentTicket !== sha256(consentTicket)) {
    return err("CONSENT_INVALID", "Tiket persetujuan tidak valid — ulangi pemindaian QR.");
  }
  const st = normalizeEnrollStatus(row.status);
  if (st !== "pending" && st !== "consent_required") {
    return err("DEVICE_NOT_PENDING", `Enrollment sudah berakhir dengan status ${st.toUpperCase()} — tidak bisa diubah.`);
  }
  if (now > row.expiresAt) {
    row.status = "expired";
    const d = PM.devices.get(deviceId);
    if (d && d.status === "pending_consent") d.status = "revoked";
    persistPm();
    return err("CONSENT_EXPIRED", "Batas waktu persetujuan (10 menit) terlampaui — minta kode baru ke orang tua.");
  }

  /* Cyber-Update #10a (guard server): persetujuan HANYA diterima bila layar
   * disclosure benar-benar sudah terbuka di perangkat anak (fase 1b "shown"
   * menandai status consent_required). Tanpa ini, klien nakal bisa melompat
   * langsung ke consent=true tanpa pernah menampilkan penjelasan ke anak. */
  if (accept && st !== "consent_required") {
    return err("CONSENT_NOT_SHOWN", "Layar penjelasan persetujuan belum terbuka di perangkat anak — enrollment ditolak.");
  }

  const h = PM.households.get(row.householdId);
  const c = PM.children.get(row.childId);
  const device = PM.devices.get(deviceId);
  if (!h || !c || c.disabled || !device) {
    row.status = "rejected";
    persistPm();
    return err("HOUSEHOLD_GONE", "Keluarga/profil anak tidak tersedia lagi di server.");
  }

  if (!accept) {
    row.status = "rejected";
    row.consentAt = now;
    device.status = "rejected";
    // tiket hangus
    row.consentTicket = undefined;
    audit(h.id, deviceId, "DEVICE_CONSENT_REJECTED", `${device.label} MENOLAK koneksi monitoring`);
    alertOf(h.id, "device_rejected", `Perangkat "${device.label}" (${c.nickname}) MENOLAK terhubung. Kode tidak lagi berlaku.`, c.id, deviceId);
    persistPm();
    return { ok: true, data: { deviceId, householdName: h.name, childNickname: c.nickname, features: device.features, deviceLabel: device.label, status: "rejected" } };
  }

  // anak menyetujui → CONNECTED + token (diterbitkan hanya di sini!)
  const token = randomToken();
  PM.tokens.set(sha256(token), {
    id: rid("tk"),
    deviceId: device.id,
    tokenHash: sha256(token),
    createdAt: now,
    expiresAt: now + 365 * 864e5,
  });

  device.status = "connected";
  device.lastSeen = now;
  row.status = "connected";
  row.usedAt = now;
  row.consentAt = now;
  row.consentTicket = undefined; // tiket hangus setelah dipakai

  audit(h.id, deviceId, "DEVICE_ENROLLED", `${device.label} → ${c.nickname} (consent anak tercatat)`);
  alertOf(h.id, "device_enrolled", `Perangkat "${device.label}" (${c.nickname}) berhasil terhubung setelah disetujui anak.`, c.id, deviceId);
  persistPm();
  return {
    ok: true,
    data: {
      token,
      deviceId: device.id,
      householdName: h.name,
      childNickname: c.nickname,
      features: device.features,
      deviceLabel: device.label,
      status: "connected",
    },
  };
}

/**
 * Konsumsi enrollment LAMA (kompatibilitas) — kini mendelegasikan ke alur
 * 2-fase: scan saja (tanpa consent) TIDAK lagi menghubungkan perangkat.
 * Fungsi ini dipertahankan agar route luar yang masih memanggilnya tidak
 * patah, tetapi TIDAK pernah mengeluarkan token tanpa consent.
 */
export function consumeEnrollment(input: { qrPayload?: string; code?: string }, dev: EnrollDeviceInfo):
  | { ok: true; deviceId: string; childNickname: string; householdName: string; features: PmFeatures; token: string; deviceLabel: string }
  | { ok: false; error: PmError } {
  const r = beginEnrollment(input, dev);
  if (!r.ok) return r;
  return err("CONSENT_REQUIRED", "Koneksi memerlukan persetujuan anak di perangkat (fase 2). Gunakan alur beginEnrollment → completeEnrollment.");
}

/* ================= DEVICE AUTH ================= */

export interface DeviceAuth {
  device: PmDevice;
  household: PmHousehold;
}

/** Autentikasi perangkat via header Authorization: Bearer <token>. */
export function authDevice(token: string | null): DeviceAuth | null {
  if (!token || token.length < 20 || token.length > 200) return null;
  const hash = sha256(token);
  const row = PM.tokens.get(hash);
  if (!row) return null;
  if (row.revokedAt) return null;
  if (Date.now() > row.expiresAt) return null;
  const device = PM.devices.get(row.deviceId);
  // zuperupdt #7: hanya perangkat AKTIF yang boleh pakai token
  // (pending_consent/rejected/revoked = tidak pernah punya token valid,
  // tapi cek ganda ini tetap dipasang)
  if (!device || device.status !== "connected" && device.status !== "paused") return null;
  const household = PM.households.get(device.householdId);
  if (!household) return null;
  row.lastUsedAt = Date.now();
  return { device, household };
}

/** Rotasi token — token lama langsung mati, token baru satu kali lihat. */
export function rotateDeviceToken(deviceId: string): string | null {
  const device = PM.devices.get(deviceId);
  if (!device) return null;
  for (const [hash, t] of PM.tokens) {
    if (t.deviceId === deviceId && !t.revokedAt) {
      t.revokedAt = Date.now();
      t.rotatedAt = Date.now();
    }
  }
  const token = randomToken();
  PM.tokens.set(sha256(token), {
    id: rid("tk"),
    deviceId,
    tokenHash: sha256(token),
    createdAt: Date.now(),
    expiresAt: Date.now() + 365 * 864e5,
  });
  audit(device.householdId, `device:${deviceId}`, "TOKEN_ROTATED", device.label);
  persistPm();
  return token;
}

/* ================= HEARTBEAT / STATUS ================= */

export interface HeartbeatInput {
  battery?: number;
  charging?: boolean;
  network?: string;
  model?: string;
  androidVersion?: string;
  appVersion?: string;
  permissions?: Record<string, string>;
}

export function deviceHeartbeat(auth: DeviceAuth, input: HeartbeatInput): { ok: true; paused: boolean; features: PmFeatures } {
  const { device, household } = auth;
  if (typeof input.battery === "number" && input.battery >= 0 && input.battery <= 100) {
    device.battery = Math.round(input.battery);
    device.charging = !!input.charging;
    if (device.battery <= 20 && !device.charging) {
      alertOf(household.id, "low_battery", `Baterai "${device.label}" rendah (${device.battery}%).`, device.childId, device.id);
    }
  }
  if (input.network) device.network = input.network.slice(0, 30);
  if (input.model) device.model = input.model.slice(0, 60);
  if (input.androidVersion) device.androidVersion = input.androidVersion.slice(0, 20);
  if (input.appVersion) device.appVersion = input.appVersion.slice(0, 20);
  if (input.permissions) {
    const prev = device.permissions || {};
    for (const [k, v] of Object.entries(input.permissions).slice(0, 12)) {
      if (prev[k] === "granted" && v && v !== "granted") {
        alertOf(household.id, "permission_revoked", `Izin "${k}" di "${device.label}" berubah menjadi ${v}.`, device.childId, device.id);
        audit(household.id, `device:${device.id}`, "PERMISSION_REVOKED", `${k} → ${v}`);
      }
    }
    device.permissions = input.permissions;
  }
  device.lastSeen = Date.now();
  persistPm();
  return { ok: true, paused: device.status === "paused", features: device.features };
}

/** Perangkat anak memutus koneksi sendiri (transparansi hak anak). */
export function deviceDisconnect(auth: DeviceAuth): { ok: true } {
  const { device, household } = auth;
  device.status = "revoked";
  device.revokedAt = Date.now();
  for (const t of PM.tokens.values()) {
    if (t.deviceId === device.id && !t.revokedAt) t.revokedAt = Date.now();
  }
  audit(household.id, `device:${device.id}`, "DEVICE_DISCONNECTED_BY_CHILD", device.label);
  alertOf(household.id, "device_disabled", `Perangkat "${device.label}" memutus koneksi monitoring dari sisi perangkat.`, device.childId, device.id);
  persistPm();
  return { ok: true };
}

/* ================= USAGE ================= */

export interface UsageInput {
  date?: string; // YYYY-MM-DD (default hari ini)
  entries: Array<{ pkg: string; app?: string; usageMs?: number; launches?: number }>;
}

function validDate(s: string | undefined): string {
  if (s && /^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
  return new Date().toISOString().slice(0, 10);
}

export function ingestUsage(auth: DeviceAuth, input: UsageInput): { ok: true; count: number } {
  const { device, household } = auth;
  if (!device.features.usage) return { ok: true, count: 0 };
  const date = validDate(input.date);
  let count = 0;
  for (const e of (input.entries || []).slice(0, 60)) {
    const pkg = String(e.pkg || "").slice(0, 120);
    if (!/^[a-zA-Z0-9._]+$/.test(pkg)) continue;
    const key = `${device.id}|${date}|${pkg}`;
    const usageMs = Math.max(0, Math.min(24 * 3600 * 1000, Math.floor(Number(e.usageMs) || 0)));
    const launches = Math.max(0, Math.min(5000, Math.floor(Number(e.launches) || 0)));
    const existing = PM.usage.get(key);
    if (existing) {
      // IDEMPOTENT: perangkat mengirim total kumulatif — simpan nilai maksimum
      existing.usageMs = Math.max(existing.usageMs, usageMs);
      existing.launches = Math.max(existing.launches, launches);
      existing.updatedAt = Date.now();
    } else {
      PM.usage.set(key, {
        key,
        householdId: household.id,
        childId: device.childId,
        deviceId: device.id,
        date,
        pkg,
        app: (e.app || pkg).slice(0, 80),
        usageMs,
        launches,
        updatedAt: Date.now(),
      });
      count++;
    }
  }
  device.lastSync = Date.now();
  device.lastSeen = Date.now();
  if (PM.usage.size > 20000) {
    // buang terlama
    const sorted = [...PM.usage.values()].sort((a, b) => a.updatedAt - b.updatedAt);
    for (const u of sorted.slice(0, PM.usage.size - 20000)) PM.usage.delete(u.key);
  }
  persistPm();
  return { ok: true, count };
}

export function usageReport(session: SessionPayload, childId: string, days: 1 | 7 | 30): Array<{ date: string; pkg: string; app: string; usageMs: number; launches: number; deviceId: string }> {
  const h = getHousehold(session);
  const c = PM.children.get(childId);
  if (!c || c.householdId !== h.id) return [];
  const since = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
  return [...PM.usage.values()]
    .filter((u) => u.childId === childId && u.householdId === h.id && u.date >= since)
    .sort((a, b) => b.usageMs - a.usageMs)
    .slice(0, 500);
}

/* ================= LOCATION ================= */

export function ingestLocation(auth: DeviceAuth, lat: number, lon: number, accuracy?: number): { ok: true } | { ok: false; error: string } {
  const { device, household } = auth;
  if (!device.features.location) return { ok: false, error: "Fitur lokasi tidak diaktifkan untuk perangkat ini." };
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return { ok: false, error: "Koordinat tidak valid." };
  }
  PM.locations.push({
    id: rid("lo"),
    householdId: household.id,
    deviceId: device.id,
    lat: Math.round(lat * 1e6) / 1e6,
    lon: Math.round(lon * 1e6) / 1e6,
    accuracy: Number.isFinite(accuracy) ? Math.min(5000, Math.max(0, Math.round(accuracy))) : undefined,
    ts: Date.now(),
  });
  if (PM.locations.length > 3000) PM.locations.splice(0, PM.locations.length - 3000);
  device.lastSeen = Date.now();
  persistPm();
  return { ok: true };
}

export function listLocations(session: SessionPayload, deviceId: string): LocationRow[] {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return [];
  return PM.locations.filter((l) => l.deviceId === deviceId).slice(-100).reverse();
}

/* ================= MEDIA ================= */

export function ingestMedia(auth: DeviceAuth, items: Array<{ kind: "photo" | "video"; size?: number; thumb?: string }>): { ok: true; count: number } {
  const { device, household } = auth;
  if (!device.features.media) return { ok: true, count: 0 };
  let count = 0;
  for (const it of (items || []).slice(0, 30)) {
    const thumbOk = it.thumb && /^data:image\/(png|jpe?g|webp);base64,/.test(it.thumb.slice(0, 40)) && it.thumb.length <= 80 * 1024;
    const m: MediaRow = {
      id: rid("md"),
      householdId: household.id,
      deviceId: device.id,
      kind: it.kind === "video" ? "video" : "photo",
      size: Number.isFinite(it.size) ? Math.min(2 * 1024 * 1024 * 1024, Math.floor(Number(it.size))) : undefined,
      thumb: thumbOk ? it.thumb : undefined,
      ts: Date.now(),
    };
    PM.media.set(m.id, m);
    count++;
  }
  if (PM.media.size > 1000) {
    const sorted = [...PM.media.values()].sort((a, b) => a.ts - b.ts);
    for (const m of sorted.slice(0, PM.media.size - 1000)) PM.media.delete(m.id);
  }
  device.lastSeen = Date.now();
  persistPm();
  return { ok: true, count };
}

export function listMedia(session: SessionPayload, deviceId: string): MediaRow[] {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return [];
  return [...PM.media.values()].filter((m) => m.deviceId === deviceId).sort((a, b) => b.ts - a.ts).slice(0, 200);
}

export function deleteMedia(session: SessionPayload, mediaId: string): { ok: true } | { ok: false; error: string } {
  const h = getHousehold(session);
  const m = PM.media.get(mediaId);
  if (!m || m.householdId !== h.id) return { ok: false, error: "Media tidak ditemukan." };
  PM.media.delete(mediaId);
  audit(h.id, session.uid, "MEDIA_DELETED", m.kind);
  persistPm();
  return { ok: true };
}

export function deleteAllMedia(session: SessionPayload, deviceId: string): { ok: true; count: number } {
  const h = getHousehold(session);
  const d = PM.devices.get(deviceId);
  if (!d || d.householdId !== h.id) return { ok: true, count: 0 };
  let n = 0;
  for (const [id, m] of PM.media) {
    if (m.deviceId === deviceId) {
      PM.media.delete(id);
      n++;
    }
  }
  audit(h.id, session.uid, "MEDIA_DELETED_ALL", `${n} item (${d.label})`);
  persistPm();
  return { ok: true, count: n };
}

/* ================= READ MODEL (DASHBOARD) ================= */

/** Cyber-Update #10c: jendela "online" = 35 menit — interval heartbeat
 *  companion minimal 15 menit (batas WorkManager) + margin retry backoff.
 *  Dulu 10 menit: LEBIH PENDEK dari interval sync, sehingga perangkat yang
 *  sehat pun bolak-balik tampak offline di dashboard orang tua. */
const ONLINE_WINDOW_MS = 35 * 60 * 1000;

export function overview(session: SessionPayload) {
  const h = getHousehold(session);
  const children = listChildren(h.id).map((c) => {
    const devices = listDevices(h.id).filter((d) => d.childId === c.id);
    return {
      ...c,
      age: childAge(c),
      devices: devices.map(publicDevice),
      deviceCount: devices.length,
      connectedCount: devices.filter((d) => d.status === "connected" && Date.now() - (d.lastSeen || 0) < ONLINE_WINDOW_MS).length,
    };
  });
  const now = Date.now();
  const alerts = PM.alerts
    .filter((a) => a.householdId === h.id)
    .sort((a, b) => b.ts - a.ts)
    .slice(0, 50);
  // alert transien: perangkat terhubung tapi >35 menit tidak heartbeat
  for (const d of PM.devices.values()) {
    if (d.householdId === h.id && d.status === "connected" && d.lastSeen && now - d.lastSeen > ONLINE_WINDOW_MS) {
      alerts.unshift({
        id: `off-${d.id}`,
        householdId: h.id,
        childId: d.childId,
        deviceId: d.id,
        type: "device_offline",
        msg: `Perangkat "${d.label}" tidak mengirim heartbeat >35 menit (offline atau jaringan mati).`,
        ts: d.lastSeen,
      });
    }
  }
  return {
    household: { id: h.id, name: h.name, attested: isAttested(h), attestation: h.attestation || null, createdAt: h.createdAt },
    children,
    devices: listDevices(h.id).map(publicDevice),
    alerts: alerts.slice(0, 60),
    audit: PM.audit.filter((a) => a.householdId === h.id).sort((a, b) => b.ts - a.ts).slice(0, 80),
    retention: RETENTION,
    limits: { childMaxAge: PM_CHILD_MAX_AGE, adultAge: PM_ADULT_AGE, enrollTtlMin: 10 },
    serverTime: now,
  };
}

function publicDevice(d: PmDevice) {
  const online = d.status === "connected" && Date.now() - (d.lastSeen || 0) < ONLINE_WINDOW_MS;
  return {
    id: d.id,
    childId: d.childId,
    label: d.label,
    model: d.model || null,
    androidVersion: d.androidVersion || null,
    appVersion: d.appVersion || null,
    battery: d.battery ?? null,
    charging: d.charging ?? null,
    network: d.network || null,
    lastSeen: d.lastSeen || null,
    lastSync: d.lastSync || null,
    status: d.status,
    online,
    features: d.features,
    permissions: d.permissions || null,
    createdAt: d.createdAt,
  };
}

/* ================= PRIVACY CENTER ================= */

export function privacySummary(session: SessionPayload) {
  const h = getHousehold(session);
  const devices = listDevices(h.id);
  return {
    household: { id: h.id, name: h.name, attested: isAttested(h) },
    enabledFeatures: devices.map((d) => ({ deviceId: d.id, label: d.label, features: d.features })),
    counts: {
      usageEntries: [...PM.usage.values()].filter((u) => u.householdId === h.id).length,
      locations: PM.locations.filter((l) => l.householdId === h.id).length,
      media: [...PM.media.values()].filter((m) => m.householdId === h.id).length,
      alerts: PM.alerts.filter((a) => a.householdId === h.id).length,
    },
    retention: RETENTION,
    note: "Semua data monitoring milik household ini saja. Orang tua bisa menghapus kapan pun.",
  };
}

export function purgeData(session: SessionPayload, what: "usage" | "location" | "media" | "alerts" | "all"):
  { ok: true; deleted: Record<string, number> } {
  const h = getHousehold(session);
  const deleted: Record<string, number> = {};
  if (what === "usage" || what === "all") {
    let n = 0;
    for (const [key, u] of PM.usage) {
      if (u.householdId === h.id) {
        PM.usage.delete(key);
        n++;
      }
    }
    deleted.usage = n;
  }
  if (what === "location" || what === "all") {
    const before = PM.locations.length;
    PM.locations = PM.locations.filter((l) => l.householdId !== h.id);
    deleted.location = before - PM.locations.length;
  }
  if (what === "media" || what === "all") {
    let n = 0;
    for (const [id, m] of PM.media) {
      if (m.householdId === h.id) {
        PM.media.delete(id);
        n++;
      }
    }
    deleted.media = n;
  }
  if (what === "alerts" || what === "all") {
    const before = PM.alerts.length;
    PM.alerts = PM.alerts.filter((a) => a.householdId !== h.id);
    deleted.alerts = before - PM.alerts.length;
  }
  audit(h.id, session.uid, "DATA_DELETED", what);
  persistPm();
  return { ok: true, deleted };
}

/* ================= RETENTION SWEEPER ================= */

if (!g.__fanzzPmSweep) {
  g.__fanzzPmSweep = setInterval(() => {
    try {
      const now = Date.now();
      // usage 90 hari
      const usageCut = new Date(now - RETENTION.usageDays * 864e5).toISOString().slice(0, 10);
      for (const [key, u] of PM.usage) if (u.date < usageCut) PM.usage.delete(key);
      // lokasi 30 hari
      PM.locations = PM.locations.filter((l) => l.ts > now - RETENTION.locationDays * 864e5);
      // thumb 30 hari; metadata media 90 hari
      for (const [id, m] of PM.media) {
        if (m.ts < now - RETENTION.thumbDays * 864e5) m.thumb = undefined;
        if (m.ts < now - RETENTION.mediaMetaDays * 864e5) PM.media.delete(id);
      }
      // audit 180 hari
      PM.audit = PM.audit.filter((a) => a.ts > now - 180 * 864e5);
      persistPm();
    } catch {
      /* ignore */
    }
  }, 30 * 60 * 1000);
  (g.__fanzzPmSweep as unknown as { unref?: () => void }).unref?.();
}
