/**
 * Deteksi kata sensitif/kasar multi-bahasa — permintaan #17, diperkuat V2-new (#8).
 * Bahasa: Indonesia, Inggris (US/UK), Jerman, Jepang, Sunda, Jawa + Hate Speech.
 * Tingkat keparahan: 3 (sangat kasar) → 2 (kasar) → 1 (agak kasar/campuran slang).
 * Pencocokan V2-new:
 *  - kata utuh + alias
 *  - normalisasi LEET (4nj1ng, k0nt0l, b*tch → ketemu)
 *  - pengulangan huruf dipecah (anjiiiiing, fuckkk → ketemu)
 *  - pemisah - _ . dibuang (a-n-j-i-n-g → ketemu)
 *  - kamus hate speech/ideologi kebencian (nazi, hitler, KKK, slur rasial)
 */

export type LangCode = "id" | "en" | "de" | "ja" | "su" | "jv" | "xx";

export const LANGS: Array<{ code: LangCode; label: string }> = [
  { code: "id", label: "Bahasa Indonesia" },
  { code: "en", label: "English (US/UK)" },
  { code: "de", label: "Deutsch (Jerman)" },
  { code: "ja", label: "日本語 (Jepang)" },
  { code: "su", label: "Basa Sunda" },
  { code: "jv", label: "Basa Jawa" },
  { code: "xx", label: "Hate Speech (semua bahasa)" },
];

export interface ProfanityEntry {
  word: string;
  level: 1 | 2 | 3;
  note?: string;
  /** alias/singkatan yang ikut terdeteksi */
  alias?: string[];
}

export interface ProfanityHit {
  word: string;
  level: 1 | 2 | 3;
  lang: LangCode;
  note?: string;
  index: number;
}

/* ============ Kamus per bahasa ============ */

const ID_WORDS: ProfanityEntry[] = [
  { word: "anjing", level: 3, alias: ["anj", "anjj", "anjeng", "ajg", "anjg", "anjir", "anjrit", "asu"] },
  { word: "bangsat", level: 3, alias: ["bangst", "bngst", "bgst", "bangke"] },
  { word: "bajingan", level: 3, alias: ["bjngn", "bajing"] },
  { word: "babi", level: 3, alias: ["bb" ] },
  { word: "kontol", level: 3, alias: ["kntl", "cntl", "kontl"] },
  { word: "memek", level: 3, alias: ["mmk", "emek", "puki", "pussy"] },
  { word: "ngentot", level: 3, alias: ["ngntt", "entot", "ngentod", "nentot"] },
  { word: "ngewe", level: 3, alias: ["ngw", "ewek"] },
  { word: "pepek", level: 3, alias: ["ppk", "pekpek", "vagina"] },
  { word: "titit", level: 3, alias: ["tt", "penis", "kemaluan"] },
  { word: "jembut", level: 3, alias: ["jmbt", "jembud"] },
  { word: "pantek", level: 3, alias: ["pntk"] },
  { word: "goblok", level: 2, alias: ["goblog", "gblg", "goblo"] },
  { word: "gila", level: 1, note: "tergantung konteks" },
  { word: "tolol", level: 2, alias: ["tll"] },
  { word: "idiot", level: 2, alias: ["idiot"] },
  { word: "sialan", level: 2 },
  { word: "bego", level: 2, alias: ["bgo"] },
  { word: "bodoh", level: 2, alias: ["bodo", "bdh"] },
  { word: "setan", level: 1 },
  { word: "keparat", level: 2 },
  { word: "brengsek", level: 2, alias: ["brngsk"] },
  { word: "kampret", level: 2, alias: ["kmprt"] },
  { word: "tai", level: 3, alias: ["tahi", "taek", "taik"] },
  { word: "taek", level: 2 },
  { word: "celeng", level: 2 },
  { word: "monyet", level: 2, note: "sebagai hinaan" },
  { word: "kunyuk", level: 2 },
  { word: "bedebah", level: 3, alias: ["bedeba"] },
  { word: "benci", level: 1 },
  { word: "lahap", level: 1 },
  { word: "paido", level: 3 },
  { word: "bencong", level: 3, alias: ["bncng", "waria (hinaan)"] },
  { word: "banci", level: 3, alias: ["bnc"] },
  { word: "kampungan", level: 1 },
  { word: "norak", level: 1 },
];

const EN_WORDS: ProfanityEntry[] = [
  { word: "fuck", level: 3, alias: ["fck", "fuk", "f*ck", "fvck", "fcuk", "fucking", "fucker"] },
  { word: "shit", level: 2, alias: ["sht", "sh*t", "shitty", "bullshit", "bs"] },
  { word: "bitch", level: 3, alias: ["btch", "b*tch", "bitches"] },
  { word: "asshole", level: 3, alias: ["a**hole", "ahole", "arsehole"] },
  { word: "bastard", level: 3, alias: ["bstrd"] },
  { word: "dick", level: 3, alias: ["d*ck", "dickhead"] },
  { word: "pussy", level: 3, alias: ["p*ssy"] },
  { word: "cunt", level: 3, alias: ["c*nt"] },
  { word: "whore", level: 3, alias: ["slut", "sl*t", "hoe"] },
  { word: "motherfucker", level: 3, alias: ["mf", "mofo", "mfer"] },
  { word: "wanker", level: 3, note: "UK" },
  { word: "bollocks", level: 2, note: "UK" },
  { word: "bugger", level: 2, note: "UK" },
  { word: "twat", level: 3, note: "UK" },
  { word: "prick", level: 2 },
  { word: "crap", level: 1, alias: ["cr*p"] },
  { word: "damn", level: 1, alias: ["damnit", "goddamn", "gdam"] },
  { word: "hell", level: 1 },
  { word: "jerk", level: 1 },
  { word: "stupid", level: 1 },
  { word: "idiot", level: 2 },
  { word: "moron", level: 2 },
  { word: "retard", level: 3, alias: ["tard"] },
  { word: "douche", level: 2, alias: ["douchebag"] },
  { word: "scumbag", level: 2 },
  { word: "piss", level: 2, alias: ["p*ss", "pissed"] },
];

const DE_WORDS: ProfanityEntry[] = [
  { word: "scheiße", level: 3, alias: ["scheisse", "scheiß", "shceize", "scheize"] },
  { word: "arschloch", level: 3, alias: ["arsch"] },
  { word: "fick", level: 3, alias: ["ficken", "verfickt"] },
  { word: "hurensohn", level: 3, alias: ["hure"] },
  { word: "wichser", level: 3 },
  { word: "miststück", level: 3 },
  { word: "verdammt", level: 2 },
  { word: "idiot", level: 2, alias: ["idiotin"] },
  { word: "blöd", level: 2, alias: ["bloed", "blödmann"] },
  { word: "dumm", level: 2, alias: ["dummkopf"] },
  { word: "arschgesicht", level: 3 },
  { word: "schwein", level: 2, alias: ["schweinehund"] },
  { word: "kacke", level: 2, alias: ["kack"] },
  { word: "mist", level: 1 },
];

const JA_WORDS: ProfanityEntry[] = [
  { word: "馬鹿", level: 2, alias: ["baka", "バカ"] },
  { word: "阿呆", level: 2, alias: ["aho", "アホ"] },
  { word: "くそ", level: 2, alias: ["kuso", "クソ"] },
  { word: "畜生", level: 3, alias: ["chikushou"] },
  { word: "野郎", level: 2, alias: ["yarou"] },
  { word: "ふざけるな", level: 2, alias: ["fuzakeruna"] },
  { word: "死ね", level: 3, alias: ["shine"] },
  { word: "クソ野郎", level: 3, alias: ["kuso yarou"] },
  { word: "デブ", level: 2, alias: ["debu"] },
  { word: "ブス", level: 3, alias: ["busu"] },
];

const SU_WORDS: ProfanityEntry[] = [
  { word: "anjing", level: 3, note: "serapan, umum dipakai juga di Sunda" },
  { word: "asw", level: 3 },
  { word: "bolot", level: 2, note: "bodoh (Sunda)" },
  { word: "kireuh", level: 2 },
  { word: "nyolot", level: 1 },
  { word: "leungeun-panjang", level: 3, alias: ["maling"] },
  { word: "cicing", level: 1, note: "diam (agak kasar)" },
  { word: "bodo amat", level: 2 },
  { word: "geuring", level: 1 },
  { word: "brong", level: 2 },
  { word: "kolot", level: 1 },
  { word: "tukang nyolong", level: 3 },
];

const JV_WORDS: ProfanityEntry[] = [
  { word: "goblok", level: 3, alias: ["goblog"], note: "Jawa/Indonesia" },
  { word: "edan", level: 2, note: "gila (Jawa)" },
  { word: "gendheng", level: 2, alias: ["gendeng"] },
  { word: "kenthir", level: 2 },
  { word: "kenthong", level: 2 },
  { word: "dhasar", level: 1, note: "asal (hinaan ringan)" },
  { word: "cethil", level: 2 },
  { word: "kere", level: 2 },
  { word: "kalong", level: 2 },
  { word: "bedhes", level: 3 },
  { word: "jancok", level: 3, alias: ["jancuk", "dancok", "cok", "cuk", "jancox"] },
  { word: "kontol", level: 3, alias: ["kntl"] },
  { word: "peler", level: 3 },
  { word: "cukimai", level: 3, alias: ["cuki"] },
  { word: "matamu", level: 2 },
  { word: "asu", level: 3, note: "anjing (Jawa)" },
  { word: "kirik", level: 2, note: "anjak kecil (hinaan)" },
  { word: "bangsat", level: 3 },
];

/* ============ Kamus hate speech / ideologi kebencian (V2-new #8) ============ */

const HATE_WORDS: ProfanityEntry[] = [
  { word: "nazi", level: 3, note: "ideologi kebencian", alias: ["nazis", "neo-nazi", "neonazi"] },
  { word: "hitler", level: 3, note: "tokoh genosida", alias: ["hitlernya", "heil hitler"] },
  { word: "swastika", level: 3, note: "simbol hate speech (konteks barat)", alias: ["swastica"] },
  { word: "kkk", level: 3, note: "organisasi kebencian (Ku Klux Klan)", alias: ["ku klux klan"] },
  { word: "white power", level: 3, note: "slogan supremasi" },
  { word: "white supremacy", level: 3, note: "ideologi supremasi" },
  { word: "genocide", level: 3, note: "genosida", alias: ["genosida"] },
  { word: "holocaust denial", level: 3, note: "negasi genosida" },
  { word: "nigger", level: 3, note: "slur rasial sangat berat", alias: ["nigga", "n*gger", "n1gga"] },
  { word: "faggot", level: 3, note: "slur terhadap LGBT", alias: ["f*ggot", "f4ggot"] },
  { word: "retard", level: 3, note: "hinaan disabilitas", alias: ["tard", "retarded"] },
  { word: "chink", level: 3, note: "slur rasial (Asia)", alias: ["ch1nk"] },
  { word: "spic", level: 3, note: "slur rasial (Latin)", alias: ["sp1c"] },
  { word: "gook", level: 3, note: "slur rasial (Asia)", alias: ["g0ok"] },
  { word: "kike", level: 3, note: "slur antisemit", alias: ["k1ke"] },
  { word: "coon", level: 3, note: "slur rasial" },
  { word: "jihad", level: 2, note: "tergantung konteks — sering dipakai sebagai ujaran kebencian" },
  { word: "infidel", level: 2, note: "hinaan lintas agama" },
  { word: "kafir", level: 2, note: "tergantung konteks — sebagai hinaan = ujaran kebencian" },
  { word: "pengkhianat bangsa", level: 2, note: "retorika kebencian" },
  { word: "bisu", level: 1, note: "hinaan disabilitas bila dipakai mengejek" },
];

const DICTS: Record<LangCode, ProfanityEntry[]> = {
  id: ID_WORDS,
  en: EN_WORDS,
  de: DE_WORDS,
  ja: JA_WORDS,
  su: SU_WORDS,
  jv: JV_WORDS,
  xx: HATE_WORDS,
};

/* ============ Normalisasi LEET & pengulangan (V2-new #8) ============ */

/** Peta karakter leet → huruf asli. */
const LEET_MAP: Record<string, string> = {
  "0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
  "@": "a", $: "s", "!": "i", "€": "e", "+": "t", "8": "b", "9": "g",
};

/** Karakter sensor yang dipakai menyamarkan (b*tch, f*ck). Hanya simbol —
 *  huruf x TIDAK dibuang agar tidak salah tangkap kata sah. */
const MASK_CHARS = new Set(["*", "×", "#", "%"]);

/**
 * Bangun teks ternormalisasi + peta indeks → indeks asli.
 *  - leet: 4nj1ng → anjing
 *  - pengulangan huruf berurutan dipecah: anjiiing → anjing
 *  - pemisah - _ . dibuang: a-n-j-i-n-g → anjing
 *  - huruf sensor (*) di antara huruf dibuang: b*tch → btch (alias b*tch + btch?)
 */
function normalizeWithMap(text: string): { norm: string; map: number[] } {
  const norm: string[] = [];
  const map: number[] = [];
  let prevChar = "";
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const low = ch.toLowerCase();
    // pemisah antar huruf: buang
    if (low === "-" || low === "_" || low === ".") continue;
    // leet
    let mapped = LEET_MAP[low] ?? low;
    // huruf sensor di tengah kata: buang (b*tch → btch, dicocok via normalisasi alias)
    if (MASK_CHARS.has(low)) {
      mapped = "";
    }
    if (!mapped) continue;
    // pengulangan huruf identik berurutan: simpan satu
    if (mapped === prevChar && /[\p{L}\p{N}]/u.test(mapped)) continue;
    norm.push(mapped);
    map.push(i);
    prevChar = mapped;
  }
  return { norm: norm.join(""), map };
}

/* ============ Detektor ============ */

function escapeRe(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** Bangun pola regex per bahasa (kata utuh, case-insensitive). */
const PATTERNS: Record<LangCode, Array<{ re: RegExp; entry: ProfanityEntry }>> = (() => {
  const out = {} as Record<LangCode, Array<{ re: RegExp; entry: ProfanityEntry }>>;
  for (const lang of Object.keys(DICTS) as LangCode[]) {
    const list: Array<{ re: RegExp; entry: ProfanityEntry }> = [];
    for (const entry of DICTS[lang]) {
      const variants = [entry.word, ...(entry.alias || [])].filter(
        (w) => w && !w.includes(" ")
      );
      if (!variants.length) continue;
      // pisah berdasarkan panjang biara kata pendek gak salah tangkap
      const pattern = variants.map(escapeRe).sort((a, b) => b.length - a.length).join("|");
      list.push({
        re: new RegExp(`(?<![\\p{L}\\p{N}])(${pattern})(?![\\p{L}\\p{N}])`, "giu"),
        entry,
      });
    }
    out[lang] = list;
  }
  return out;
})();

export interface DetectResult {
  hits: ProfanityHit[];
  total: number;
  levelMax: 0 | 1 | 2 | 3;
  perLang: Record<LangCode, number>;
  cleaned: string;
}

/** Deteksi semua kata sensitif pada sebuah teks (V2-new: + normalisasi leet/pengulangan). */
export function detectProfanity(text: string, langs?: LangCode[]): DetectResult {
  const useLangs = langs && langs.length ? langs : (Object.keys(DICTS) as LangCode[]);
  const hits: ProfanityHit[] = [];

  /** pencocokan pada satu "haystack" dengan pelaporan indeks. */
  const scan = (hay: string, indexMap: number[] | null, sourceText: string) => {
    for (const lang of useLangs) {
      for (const { re, entry } of PATTERNS[lang]) {
        const rx = new RegExp(re.source, re.flags);
        let m: RegExpExecArray | null;
        while ((m = rx.exec(hay)) !== null) {
          const found = m[1];
          const idx = m.index;
          // perkiraan panjang asli: bila indexMap ada, ambil rentang aslinya
          let origIdx = idx;
          let origWord = found;
          if (indexMap) {
            const start = indexMap[idx] ?? 0;
            const endNorm = Math.min(idx + found.length - 1, indexMap.length - 1);
            const end = (indexMap[endNorm] ?? start) + 1;
            origWord = sourceText.slice(start, end) || found;
            origIdx = start;
          }
          const key = `${origIdx}:${origWord.toLowerCase()}`;
          if (!hits.some((h) => `${h.index}:${h.word.toLowerCase()}` === key)) {
            hits.push({ word: origWord, level: entry.level, lang, note: entry.note, index: origIdx });
          }
          if (m.index === rx.lastIndex) rx.lastIndex++;
        }
      }
    }
  };

  // 1) teks asli (menghindari salah indeks untuk kata polos)
  scan(text, null, text);

  // 2) teks ternormalisasi (leet + pengulangan + pemisah) — menangkap
  //    4nj1ng, k0nt0l, anjiiing, a-n-j-i-n-g, b*tch
  const { norm, map } = normalizeWithMap(text);
  if (norm.length >= 3) scan(norm, map, text);

  hits.sort((a, b) => a.index - b.index);

  // sensor teks hasil (berbasis rentang asli, urut mundur supaya indeks aman)
  let cleaned = text;
  const ranges = [...hits].sort((a, b) => b.index - a.index);
  for (const h of ranges) {
    const start = h.index;
    const end = start + h.word.length;
    // pastikan benar-benar cocok (kata asli bisa berbeda tipis) — bila tidak,
    // cari versi case-insensitive di sekitarnya
    const slice = cleaned.slice(start, end);
    if (slice.toLowerCase() === h.word.toLowerCase()) {
      cleaned = cleaned.slice(0, start) + h.word[0] + "*".repeat(Math.max(1, h.word.length - 1)) + cleaned.slice(end);
    } else {
      const rx = new RegExp(`(?<![\\p{L}\\p{N}])${escapeRe(h.word)}(?![\\p{L}\\p{N}])`, "giu");
      cleaned = cleaned.replace(rx, h.word[0] + "*".repeat(Math.max(1, h.word.length - 1)));
    }
  }

  const perLang = {} as Record<LangCode, number>;
  for (const h of hits) perLang[h.lang] = (perLang[h.lang] || 0) + 1;

  const levelMax = hits.reduce((mx, h) => Math.max(mx, h.level), 0) as 0 | 1 | 2 | 3;

  return { hits, total: hits.length, levelMax, perLang, cleaned };
}

export function levelLabel(level: 0 | 1 | 2 | 3): string {
  switch (level) {
    case 0:
      return "Bersih";
    case 1:
      return "Agak kasar";
    case 2:
      return "Kasar";
    case 3:
      return "Sangat kasar";
  }
}

export function levelColor(level: 0 | 1 | 2 | 3): string {
  switch (level) {
    case 0:
      return "text-emerald-400";
    case 1:
      return "text-amber-300";
    case 2:
      return "text-orange-400";
    case 3:
      return "text-red-400";
  }
}
