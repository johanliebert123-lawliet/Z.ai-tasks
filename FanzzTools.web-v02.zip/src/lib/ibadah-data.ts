/** Data ibadah statis (V2 Modern-UpdSec) — bacaan sholat, daftar kota, agama. */

export interface Kota {
  nama: string;
  lat: number;
  lon: number;
}

/** Kota-kota utama Indonesia (+ Makkah/Madinah) untuk jadwal sholat & kiblat. */
export const KOTA_LIST: Kota[] = [
  { nama: "Jakarta", lat: -6.2088, lon: 106.8456 },
  { nama: "Bandung", lat: -6.9175, lon: 107.6191 },
  { nama: "Surabaya", lat: -7.2575, lon: 112.7521 },
  { nama: "Medan", lat: 3.5952, lon: 98.6722 },
  { nama: "Semarang", lat: -6.9667, lon: 110.4167 },
  { nama: "Yogyakarta", lat: -7.7956, lon: 110.3695 },
  { nama: "Solo", lat: -7.5755, lon: 110.8243 },
  { nama: "Malang", lat: -7.9666, lon: 112.6326 },
  { nama: "Makassar", lat: -5.1477, lon: 119.4327 },
  { nama: "Palembang", lat: -2.9761, lon: 104.7754 },
  { nama: "Denpasar", lat: -8.6705, lon: 115.2126 },
  { nama: "Balikpapan", lat: -1.2379, lon: 116.8529 },
  { nama: "Samarinda", lat: -0.5017, lon: 117.1536 },
  { nama: "Banjarmasin", lat: -3.3194, lon: 114.5908 },
  { nama: "Pontianak", lat: -0.0263, lon: 109.3425 },
  { nama: "Padang", lat: -0.9471, lon: 100.4172 },
  { nama: "Pekanbaru", lat: 0.5071, lon: 101.4478 },
  { nama: "Batam", lat: 1.0456, lon: 104.0305 },
  { nama: "Banda Aceh", lat: 5.5483, lon: 95.3238 },
  { nama: "Bengkulu", lat: -3.8004, lon: 102.2655 },
  { nama: "Jambi", lat: -1.6101, lon: 103.6131 },
  { nama: "Bogor", lat: -6.595, lon: 106.8166 },
  { nama: "Tangerang", lat: -6.1783, lon: 106.63 },
  { nama: "Bekasi", lat: -6.2383, lon: 106.9756 },
  { nama: "Depok", lat: -6.4025, lon: 106.7942 },
  { nama: "Cirebon", lat: -6.732, lon: 108.5523 },
  { nama: "Surakarta", lat: -7.5755, lon: 110.8243 },
  { nama: "Kediri", lat: -7.848, lon: 112.017 },
  { nama: "Cilegon", lat: -6.0175, lon: 105.9963 },
  { nama: "Sukabumi", lat: -6.9275, lon: 106.9277 },
  { nama: "Manado", lat: 1.4748, lon: 124.8421 },
  { nama: "Kendari", lat: -3.9985, lon: 122.513 },
  { nama: "Gorontalo", lat: 0.6999, lon: 122.4467 },
  { nama: "Palu", lat: -0.8917, lon: 119.8707 },
  { nama: "Ambon", lat: -3.6954, lon: 128.1814 },
  { nama: "Ternate", lat: 0.7908, lon: 127.381 },
  { nama: "Kupang", lat: -10.1772, lon: 123.607 },
  { nama: "Mataram", lat: -8.5833, lon: 116.1167 },
  { nama: "Jayapura", lat: -2.5916, lon: 140.669 },
  { nama: "Sorong", lat: -0.8787, lon: 131.2544 },
  { nama: "Makkah", lat: 21.4225, lon: 39.8262 },
  { nama: "Madinah", lat: 24.4686, lon: 39.6142 },
];

/** Sholat wajib — jumlah rakaat. */
export const SHOLAT_WAJIB = [
  { nama: "Subuh", rakaat: "2 rakaat", waktu: "Terbit fajar s.d. sebelum terbit matahari" },
  { nama: "Zuhur", rakaat: "4 rakaat", waktu: "Matahari condong ke barat hingga bayangan benda sama panjang" },
  { nama: "Ashar", rakaat: "4 rakaat", waktu: "Bayangan benda lebih panjang dari bendanya hingga matahari menguning" },
  { nama: "Maghrib", rakaat: "3 rakaat", waktu: "Matahari terbenam hingga hilangnya cahaya merah di langit" },
  { nama: "Isya", rakaat: "4 rakaat", waktu: "Hilangnya cahaya merah hingga sebelum fajar" },
];

/** Sholat sunnah — nama, rakaat, dan keutamaan singkat. */
export const SHOLAT_SUNNAH = [
  { nama: "Rawatib Subuh", rakaat: "2 rakaat", keutamaan: "Lebih baik dari dunia dan seisinya" },
  { nama: "Rawatib Zuhur", rakaat: "2/4 rakaat", keutamaan: "Penjaga dari bahaya di siang hari" },
  { nama: "Rawatib Ashar", rakaat: "2/4 rakaat", keutamaan: "Diampuni dosa-dosa kecil" },
  { nama: "Rawatib Maghrib", rakaat: "2 rakaat", keutamaan: "Dinaikkan derajatnya" },
  { nama: "Rawatib Isya", rakaat: "2 rakaat", keutamaan: "Rumah di surga" },
  { nama: "Dhuha", rakaat: "2–12 rakaat", keutamaan: "Cukup sebagai sedekah 360 persendian" },
  { nama: "Tahajud", rakaat: "2–(bebas)", keutamaan: "Waktu mustajab doa di sepertiga malam" },
  { nama: "Witir", rakaat: "3 rakaat", keutamaan: "Penutup sholat malam, dianjurkan sebelum tidur" },
  { nama: "Tarawih (Ramadan)", rakaat: "8/20 rakaat", keutamaan: "Pahala dilipatgandakan di bulan Ramadan" },
  { nama: "Idul Fitri & Adha", rakaat: "2 rakaat", keutamaan: "Sholat sunnah muakkadah berjamaah" },
  { nama: "Gerhana", rakaat: "2 rakaat", keutamaan: "Mengingat kebesaran Allah saat gerhana" },
  { nama: "Istikharah", rakaat: "2 rakaat", keutamaan: "Memohon petunjuk saat memilih keputusan" },
  { nama: "Taubat", rakaat: "2 rakaat", keutamaan: "Menyertai istighfar setelah berdosa" },
  { nama: "Hajat", rakaat: "2–12 rakaat", keutamaan: "Memohon hajat/diijabahnya doa" },
];

/** Surah pendek yang dianjurkan dibaca dalam sholat. */
export const SURAH_SARAN = [
  { nama: "Al-Fatihah", arab: "الفاتحة", ket: "WAJIB di setiap rakaat (rukun sholat)" },
  { nama: "Al-Ikhlas", arab: "الإخلاص", ket: "Pahala sepertiga Al-Qur'an — favorit Rasulullah" },
  { nama: "Al-Falaq", arab: "الفلق", ket: "Perlindungan dari kejahatan makhluk" },
  { nama: "An-Nas", arab: "الناس", ket: "Perlindungan dari bisikan setan" },
  { nama: "Al-Kautsar", arab: "الكوثر", ket: "Ringan, sering dipakai setelah Al-Fatihah" },
  { nama: "Al-Asr", arab: "العصر", ket: "Penegas waktu, pendek & mudah" },
  { nama: "An-Nasr", arab: "النصر", ket: "Kemenangan dari pertolongan Allah" },
  { nama: "Al-Kafirun", arab: "الكافرون", ket: "Sunnah dibaca di rakaat pertama Witir/sunnah" },
  { nama: "Al-Ma'un", arab: "الماعون", ket: "Pengingat pentingnya membantu sesama" },
  { nama: "Quraisy", arab: "قريش", ket: "Mengingat rezeki yang dijamin Allah" },
  { nama: "Al-Fil", arab: "الفيل", ket: "Kisah pasukan gajah, kekuasaan Allah" },
  { nama: "At-Takatsur", arab: "التكاثر", ket: "Peringatan lomba menumpuk harta" },
];

export interface Bacaan {
  judul: string;
  arab: string;
  latin: string;
  arti: string;
}

/** Bacaan sholat urut — Arab, Latin, terjemahan. */
export const BACAAN_SHOLAT: Bacaan[] = [
  {
    judul: "1. Niat & Takbiratul Ihram",
    arab: "اللهُ أَكْبَرُ",
    latin: "Allāhu Akbar",
    arti: "Allah Maha Besar (mengangkat tangan sejajar telinga sambil berniat dalam hati).",
  },
  {
    judul: "2. Doa Iftitah",
    arab: "اللهُ أَكْبَرُ كَبِيرًا وَالْحَمْدُ لِلَّهِ كَثِيرًا وَسُبْحَانَ اللهِ بُكْرَةً وَأَصِيلًا، إِنِّى وَجَّهْتُ وَجْهِيَ لِلَّذِي فَطَرَ السَّمَاوَاتِ وَالأَرْضَ حَنِيفًا مُسْلِمًا وَمَا أَنَا مِنَ الْمُشْرِكِينَ، إِنَّ صَلاَتِي وَنُسُكِي وَمَحْيَايَ وَمَمَاتِي لِلَّهِ رَبِّ الْعَالَمِينَ، لاَ شَرِيكَ لَهُ وَبِذَلِكَ أُمِرْتُ وَأَنَا مِنَ الْمُسْلِمِينَ",
    latin: "Allāhu akbar kabīran walhamdu lillāhi kaṡīran wa subhānallāhi bukratan wa aṣīlā. Innī wajjahtu wajhiya lillażī faṭaras-samāwāti wal-arḍa ḥanīfam muslimaw wa mā ana minal-musyrikīn. Inna ṣalātī wa nusukī wa maḥyāya wa mamātī lillāhi rabbil-'ālamīn. Lā syarīka lahū wa biżālika umirtu wa ana minal-muslimīn.",
    arti: "Allah Maha Besar dengan segala kebesaran, segala puji bagi Allah dengan segala pujian, dan Maha Suci Allah pagi dan petang. Sungguh aku hadapkan wajahku kepada Allah yang menciptakan langit dan bumi dengan lurus dan berserah diri, dan aku bukan termasuk orang musyrik. Sesungguhnya sholatku, ibadahku, hidupku, dan matiku hanyalah untuk Allah Tuhan semesta alam. Tiada sekutu bagi-Nya, dan demikianlah aku diperintahkan, dan aku termasuk orang muslim.",
  },
  {
    judul: "3. Surah Al-Fatihah (rukn sholat)",
    arab: "بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيْمِ ۝ اَلْحَمْدُ لِلّٰهِ رَبِّ الْعٰلَمِيْنَ ۝ الرَّحْمٰنِ الرَّحِيْمِ ۝ مٰلِكِ يَوْمِ الدِّيْنِ ۝ اِيَّاكَ نَعْبُدُ وَاِيَّاكَ نَسْتَعِيْنُ ۝ اِهْدِنَا الصِّرَاطَ الْمُسْتَقِيْمَ ۝ صِرَاطَ الَّذِيْنَ اَنْعَمْتَ عَلَيْهِمْ ۙ غَيْرِ الْمَغْضُوْبِ عَلَيْهِمْ وَلَا الضَّاۤلِّيْنَ",
    latin: "Bismillāhir-raḥmānir-raḥīm. Al-ḥamdu lillāhi rabbil-'ālamīn. Ar-raḥmānir-raḥīm. Māliki yaumid-dīn. Iyyāka na'budu wa iyyāka nasta'īn. Ihdinaṣ-ṣirāṭal-mustaqīm. Ṣirāṭallażīna an'amta 'alaihim gairil-magḍūbi 'alaihim wa laḍ-ḍāllīn.",
    arti: "Dengan nama Allah Yang Maha Pengasih, Maha Penyayang. Segala puji bagi Allah, Tuhan semesta alam. Yang Maha Pengasih, Maha Penyayang. Pemilik hari pembalasan. Hanya kepada-Mu kami menyembah dan hanya kepada-Mu kami memohon pertolongan. Tunjukilah kami jalan yang lurus, (yaitu) jalan orang-orang yang telah Engkau beri nikmat, bukan (jalan) mereka yang dimurkai dan bukan (pula jalan) orang-orang yang sesat. (Aamiin)",
  },
  {
    judul: "4. Ruku' (takbir + membungkuk)",
    arab: "سُبْحَانَ رَبِّيَ الْعَظِيْمِ وَبِحَمْدِهِ",
    latin: "Subhāna rabbiyal-'aẓīmi wa biḥamdih (3×)",
    arti: "Maha Suci Tuhanku Yang Maha Agung dan segala puji bagi-Nya (dibaca 3×).",
  },
  {
    judul: "5. I'tidal (bangkit dari ruku')",
    arab: "سَمِعَ اللهُ لِمَنْ حَمِدَهُ ۝ رَبَّنَا لَكَ الْحَمْدُ مِلْأَ السَّمٰوٰتِ وَمِلْأَ الْاَرْضِ وَمِلْأَ مَا شِئْتَ مِنْ شَيْءٍ بَعْدُ",
    latin: "Sami'allāhu liman ḥamidah. Rabbanā lakal-ḥamdu mil'as-samāwāti wa mil'al-arḍi wa mil'a mā syi'ta min syai'in ba'd.",
    arti: "Allah mendengar orang yang memuji-Nya. Tuhan kami, bagi-Mu segala puji sepenuh langit dan bumi dan sepenuh apa yang Engkau kehendaki setelah itu.",
  },
  {
    judul: "6. Sujud",
    arab: "سُبْحَانَ رَبِّيَ الْاَعْلٰى وَبِحَمْدِهِ",
    latin: "Subhāna rabbiyal-a'lā wa biḥamdih (3×)",
    arti: "Maha Suci Tuhanku Yang Maha Tinggi dan segala puji bagi-Nya (dibaca 3×).",
  },
  {
    judul: "7. Duduk di antara dua sujud",
    arab: "رَبِّ اغْفِرْلِيْ وَارْحَمْنِيْ وَاجْبُرْنِيْ وَارْفَعْنِيْ وَارْزُقْنِيْ وَاهْدِنِيْ وَعَافِنِيْ وَعْفُ عَنِّيْ",
    latin: "Rabbigfir lī warḥamnī wajburnī warfa'nī warzuqnī wahdinī wa 'āfinī wa'fu 'annī.",
    arti: "Tuhanku, ampunilah aku, sayangilah aku, cukupkanlah aku, angkatlah derajatku, berilah aku rezeki, berilah aku petunjuk, sehatkanlah aku, dan maafkanlah aku.",
  },
  {
    judul: "8. Tasyahud Awal (duduk setelah 2 rakaat)",
    arab: "اَلتَّحِيَّاتُ الْمُبٰرَكٰتُ الصَّلَوٰتُ الطَّيِّبٰتُ لِلّٰهِ ۝ اَلسَّلٰمُ عَلَيْكَ اَيُّهَا النَّبِيُّ وَرَحْمَةُ اللهِ وَبَرَكٰتُهٗ ۝ اَلسَّلٰمُ عَلَيْنَا وَعَلٰى عِبَادِ اللهِ الصَّالِحِيْنَ ۝ اَشْهَدُ اَنْ لَّاۤ اِلٰهَ اِلَّا اللهُ ۙ وَاَشْهَدُ اَنَّ مُحَمَّدًا رَسُوْلُ اللهِ ۝ اَللّٰهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ",
    latin: "At-taḥiyyātul-mubārakātuṣ-ṣalawātuṭ-ṭayyibātu lillāh. Assalāmu 'alaika ayyuhan-nabiyyu wa raḥmatullāhi wa barakātuh. Assalāmu 'alainā wa 'alā 'ibādillāhiṣ-ṣāliḥīn. Asyhadu allā ilāha illallāh, wa asyhadu anna Muhammadar-rasūlullāh. Allāhumma ṣalli 'alā sayyidinā Muhammad.",
    arti: "Segala penghormatan, keberkahan, sholat, dan kebaikan hanya milik Allah. Salam atasmu wahai Nabi, beserta rahmat Allah dan berkat-Nya. Salam atas kami dan hamba-hamba Allah yang shalih. Aku bersaksi tiada Tuhan selain Allah, dan aku bersaksi Muhammad adalah utusan Allah. Ya Allah, limpahkanlah rahmat atas junjungan kami Muhammad.",
  },
  {
    judul: "9. Tasyahud Akhir + Sholawat Ibrahimiyah",
    arab: "اَللّٰهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَّعَلٰى اٰلِ سَيِّدِنَا مُحَمَّدٍ ۙ كَمَا صَلَّيْتَ عَلٰى سَيِّدِنَا اِبْرٰهِيْمَ وَعَلٰى اٰلِ سَيِّدِنَا اِبْرٰهِيْمَ وَبٰرِكْ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَّعَلٰى اٰلِ سَيِّدِنَا مُحَمَّدٍ كَمَا بٰرَكْتَ عَلٰى سَيِّدِنَا اِبْرٰهِيْمَ وَعَلٰى اٰلِ سَيِّدِنَا اِبْرٰهِيْمَ فِى الْعٰلَمِيْنَ ۖ اِنَّكَ حَمِيْدٌ مَجِيْدٌ",
    latin: "Allāhumma ṣalli 'alā sayyidinā Muhammad wa 'alā āli sayyidinā Muhammad, kamā ṣallaita 'alā sayyidinā Ibrāhīma wa 'alā āli sayyidinā Ibrāhīm, wa bārik 'alā sayyidinā Muhammad wa 'alā āli sayyidinā Muhammad, kamā bārakta 'alā sayyidinā Ibrāhīma wa 'alā āli sayyidinā Ibrāhīm fil-'ālamīn. Innaka Ḥamīdum Majīd.",
    arti: "Ya Allah, limpahkanlah rahmat atas junjungan kami Muhammad dan keluarga Muhammad, sebagaimana Engkau merahmati Ibrahim dan keluarga Ibrahim. Dan berkatilah Muhammad dan keluarga Muhammad, sebagaimana Engkau memberkati Ibrahim dan keluarga Ibrahim di seluruh alam. Sungguh Engkaulah Yang Maha Terpuji, Maha Mulia.",
  },
  {
    judul: "10. Salam (menutup sholat)",
    arab: "اَلسَّلٰمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكٰتُهٗ",
    latin: "Assalāmu 'alaikum wa raḥmatullāhi wa barakātuh (menoleh ke kanan, lalu ke kiri)",
    arti: "Semoga keselamatan, rahmat Allah, dan berkat-Nya atas kalian semua.",
  },
];

/* ================= ibadah agama lain ================= */

export interface AgamaInfo {
  id: string;
  nama: string;
  ikon: string;
  aliran?: string[];
  kitabSuci: string;
  rumahIbadah: string;
  hariSuci: string;
  doaHarian: Array<{ judul: string; isi: string }>;
  pengajian: string;
}

export const AGAMA_LIST: AgamaInfo[] = [
  {
    id: "kristen-protestan",
    nama: "Kristen Protestan",
    ikon: "✝️",
    aliran: ["Lutheran", "Calvinis/Reformed", "Pentakosta", "Baptis", "Metodis", "Adventis", "Anglikan", "Karismatik", "Injili"],
    kitabSuci: "Alkitab (Perjanjian Lama & Baru)",
    rumahIbadah: "Gereja",
    hariSuci: "Minggu (hari Tuhan) — ibadah raya & perjamuan kudus",
    doaHarian: [
      {
        judul: "Doa Pagi (Menyerahkan Hari)",
        isi: "Bapa di surga, terima kasih atas malam yang telah Engkau berikan dan hari baru ini. Pandanglah aku dan keluargaku dengan kasih-Mu. Pimpinlah setiap langkah, pekerjaan, dan perkataanku hari ini agar berkenan kepada-Mu. Berikan aku hati yang damai, tangan yang rajin, dan pikiran yang terang. Dalam nama Tuhan Yesus Kristus, Amin.",
      },
      {
        judul: "Doa Bapa Kami (Doa yang diajarkan Yesus)",
        isi: "Bapa kami yang di surga, dikuduskanlah nama-Mu, datanglah kerajaan-Mu, jadilah kehendak-Mu di bumi seperti di surga. Berikanlah kami pada hari ini makanan kami yang secukupnya, dan ampunilah kesalahan kami seperti kami juga mengampuni orang yang bersalah kepada kami. Dan janganlah membawa kami ke dalam pencobaan, tetapi lepaskanlah kami dari yang jahat. Sebab Engkaulah yang empunya kerajaan dan kuasa dan kemuliaan sampai selama-lamanya. Amin.",
      },
      {
        judul: "Doa Syukur & Berkat Makan",
        isi: "Tuhan Allah, Bapa yang baik, kami bersyukur untuk berkat makanan ini. Berkatilah hidangan ini bagi tubuh kami, dan jadikan hidup kami berkat bagi sesama. Dalam nama Yesus Kristus, Amin.",
      },
    ],
    pengajian: "Pemahaman Alkitab (Bible Study), ibadah minggu, persekutuan doa, komsel (kelompok sel), sekolah minggu anak, paduan suara, retret & kebaktian kebangunan rohani (KKR).",
  },
  {
    id: "katolik",
    nama: "Katolik",
    ikon: "atholic",
    aliran: ["Ritus Latin (Roma)", "Ritus Timur: Byzantine", "Maronit", "Siro-Malabar", "Armenia", "Koptik"],
    kitabSuci: "Alkitab (73 kitab: 46 PL + 27 PB)",
    rumahIbadah: "Gereja Katolik (Katedral/Paroki)",
    hariSuci: "Minggu (Misa); hari raya: Natal, Paskah, Kenaikan, Pentakosta, Maria Diangkat",
    doaHarian: [
      {
        judul: "Tanda Salib & Doa Pagiku",
        isi: "Dalam nama Bapa dan Putra dan Roh Kudus. Amin. — Tuhan, pada awal hari ini aku berserah kepada-Mu. Lindungilah aku dari segala bahaya dan bantulah aku melakukan kehendak-Mu dengan setia. Santa Maria, Bunda Allah, doakanlah kami. Amin.",
      },
      {
        judul: "Salam Maria (doa rosario)",
        isi: "Salam Maria, penuh rahmat, Tuhan bersertamu. Terpujilah engkau di antara wanita, dan terpujilah buah tubuhmu, Yesus. Santa Maria, Bunda Allah, doakanlah kami ini, para pendosa, sekarang dan waktu kami mati. Amin.",
      },
      {
        judul: "Doa Tobat (Act of Contrition)",
        isi: "Tuhanku, Yesus Kristus, aku menyesal atas semua dosaku, sebab dengan dosa aku menyakiti hati-Mu yang mahabaik. Dengan pertolongan rahmat-Mu, aku berjanji tidak akan berbuat dosa lagi, menjauhkan diri dari jalan menuju dosa, dan mengasihi-Mu sepenuh hatiku. Amin.",
      },
    ],
    pengajian: "Misa harian/mingguan, Doa Rosario, Adorasi Sakramen Mahakudus, Jalan Salib (Pra-Paskah), Kitab Suci sharing (Lectio Divina), katekese, KKR, ibadat pagi & petang (Liturgia Horarum).",
  },
  {
    id: "ortodoks",
    nama: "Kristen Ortodoks",
    ikon: "Orthodox",
    aliran: ["Yunani (Constantinople)", "Rusia", "Antiokhia", "Serbia", "Rumania", "Georgia", "Koptik (Alexandria)", "Armenia Apostolik", "Syriac", "Etiopia Tewahedo"],
    kitabSuci: "Alkitab (Septuaginta untuk PL) + Tradisi Para Rasli (Holy Tradition)",
    rumahIbadah: "Gereja Ortodoks (dengan ikonostasis)",
    hariSuci: "Minggu (Liturgi Kudus); Paskah Ortodoks (paling penting), Natal, Theophany, Dormition",
    doaHarian: [
      {
        judul: "Doa Yesus (Hesychasm — diulang dalam hati)",
        isi: "Tuhan Yesus Kristus, Putra Allah, kasihanilah aku, seorang pendosa. (Diulang perlahan dengan napas, dibimbing bundar doa/comboschini).",
      },
      {
        judul: "Doa Pagi Ortodoks",
        isi: "Dalam nama Bapa dan Putra dan Roh Kudus. Amin. — Ya Allah, bersihkanlah aku aku seorang pendosa, dan kasihanilah aku. Ya Tuhan, Engkau telah menciptakan aku, terangkatkan hatiku untuk menghadapi hari ini. Sucikanlah aku agar layak memuji nama-Mu yang kudus. Amin.",
      },
      {
        judul: "Doa Tritunggal",
        isi: "Tritunggal Mahakudus, kasihanilah kami. Ya Tuhan, bersihkanlah dosa kami. Ya Guru, ampunilah kesalahan kami. Ya Yang Mahakudus, jengkelah dan sembuhkanlah kelemahan kami, demi nama-Mu sendiri.",
      },
    ],
    pengajian: "Liturgi Ilahi St. Yohanes Krisostomus, Vespers & Matins, puasa ortodoks (Great Lent), teologia ikon, studi Para Bapa Gereja (Patristics), komunitas monastik.",
  },
  {
    id: "hindu",
    nama: "Hindu",
    ikon: "Om",
    aliran: ["Saiva Siddhanta", "Vaishnavisme", "Shaktisme", "Smartisme", "Bali Aga (Hindu Bali)"],
    kitabSuci: "Weda (Rgveda, Samaveda, Yajurveda, Atharvaveda), Upanishad, Bhagawadgita, Purana",
    rumahIbadah: "Pura ( kahyangan) / Mandir",
    hariSuci: "Purnama & Tilem; Galungan, Kuningan, Nyepi, Saraswati (khusus Bali)",
    doaHarian: [
      {
        judul: "Mantram Om (Pranawa)",
        isi: "Om — bunyi pertama alam semesta; lambang Ida Sang Hyang Widhi Wasa. Dibaca di awal dan akhir setiap sembahyang untuk memusatkan pikiran.",
      },
      {
        judul: "Gayatri Mantram",
        isi: "Om Bhur Bhwah Swah, Tat Savitur Varenyam, Bhargo Devasya Dhimahi, Dhiyo Yo Nah Pracodayat. — Kami memusatkan pikiran pada cahaya mulia Savitri (matahari spiritual); semoga ia menerangi budhi kita menuju jalan kebenaran.",
      },
      {
        judul: "Tri Sandya (sembahyang 3 waktu: pagi, siang, petang)",
        isi: "Om Deva Suvigraha... — umat Hindu bersembahyang tiga kali sehari menghadap matahari terbit, tengah hari, dan matahari terbenam dengan mantram Tri Sandya, disertai bunga, air suci (tirtha), dan dupa (incense).",
      },
    ],
    pengajian: "Dharma Wacana (ceramah agama), pembacaan Weda & Bhagawadgita, perayaan Purnama, upacara Pujawali, yoga & meditasi, kelas aksara Bali & kidung.",
  },
  {
    id: "buddha",
    nama: "Buddha",
    ikon: "DharmaWheel",
    aliran: ["Theravada", "Mahayana", "Vajrayana (Tibet)", "Zen", "Pure Land", "Nichiren", "Trung (Indonesia)"],
    kitabSuci: "Tripitaka (Vinaya, Sutta, Abhidhamma); sutra Mahayana",
    rumahIbadah: "Vihara / Cetiya / Pura (Buddhis)",
    hariSuci: "Hari Uposatha (Purnama & Tilem); Waisak, Asadha, Kathina",
    doaHarian: [
      {
        judul: "Vandana (Penghormatan kepada Buddha)",
        isi: "Namo Tassa Bhagavato Arahato Samma Sambuddhassa (3×) — Hormat kepada Yang Berbahagia, Yang Suci, Yang Maha Sempurna Terbangun.",
      },
      {
        judul: "Tisarana (Berlindung pada Tiga Mustika)",
        isi: "Buddham saranam gacchami — Aku berlindung kepada Buddha. Dhammam saranam gacchami — Aku berlindung kepada Dhamma. Sangham saranam gacchami — Aku berlindung kepada Sangha.",
      },
      {
        judul: "Karaniya Metta Sutta (cinta kasih universal)",
        isi: "Sabbe satta sukhi hontu — Semoga semua makhluk berbahagia. Metta bhavana: memancarkan cinta kasih kepada diri sendiri, keluarga, teman, semua makhluk, bahkan yang bersikap buruk — tanpa batas dan tanpa membeda-bedakan.",
      },
    ],
    pengajian: "Puja bakti mingguan, meditasi vipassana & anapanasati, kelas Dhamma, kathina (persembahan jubah), retret meditasi, pembacaan paritta.",
  },
  {
    id: "konghucu",
    nama: "Konghucu",
    ikon: "Taiji",
    aliran: ["Mazhab tradisional (Kerabat)", "Konfusianisme keagamaan (Kau Kau/孔教)"],
    kitabSuci: "Kitab Sishu Wujing (4 Kitab & 5 Klasik: Lun Yu, Mengzi, Daxue, Zhongyong; Shi, Shu, Li, Yi, Chun Qiu)",
    rumahIbadah: "Litang (Kelenteng) / Ru Miao",
    hariSuci: "Tahun Baru Imlek, Chap Goh Meh, Qingming (sembahyang kubur), Peh Cun (Pancu), Zhongyuan, Winter Solstice (Dongzhi)",
    doaHarian: [
      {
        judul: "Sembahyang Tian (Shang Di / Tuhan Yang Maha Esa)",
        isi: "Waktu sembahyang pagi: memberi hormat kepada Tian (Langit/Tuhan), leluhur, dan para suci, dengan sikap Cheng (tulus) dan Jing (hormat yang dalam). Bakti kepada orang tua (Xiao) adalah pangkal kebajikan.",
      },
      {
        judul: "Penghayatan Wuchang (Lima Kebajikan Tetap)",
        isi: "Ren (Kemanusiaan/ kasih), Yi (Keadilan), Li (Kesopanan/ tata krama), Zhi (Kebijaksanaan), Xin (Kebenaran/ dapat dipercaya) — dihayati setiap hari sebagai pedoman hidup bermasyarakat.",
      },
      {
        judul: "Doa Leluhur (Jing Zu)",
        isi: "Memberi hormat kepada roh leluhur di rumah atau makam, membakar hio, dengan ungkapan syukur dan permohonan berkah serta keselamatan keluarga — wujud bakti anak kepada orang tua dan nenek moyang.",
      },
    ],
    pengajian: "Kajian Lun Yu (Sabda Suci), kelas bahasa & aksara Mandarin keagamaan, upacara Imlek & Qingming, pemujaan leluhur, pendidikan moral Lingkungan Keluarga.",
  },
  {
    id: "lainnya",
    nama: "Agama & Kepercayaan Lainnya",
    ikon: "Globe",
    aliran: ["Sikhisme", "Jainisme", "Taoisme", "Shinto", "Yahudi", "Bahai", "Kebatinan/Kepercayaan Nusantara (Penghayat)", "Aluk To Dolo", "Kaharingan", "Marapu", "Parmalim", "Sunda Wiwitan"],
    kitabSuci: "Bervariasi per kepercayaan (Guru Granth Sahib, Tao Te Ching, Torah, Kitab Aqdas, dll.)",
    rumahIbadah: "Gurdwara (Sikh), Sinagoge (Yahudi), Jinja (Shinto), Balai Penghayat Kepercayaan, dll.",
    hariSuci: "Beragam mengikuti kalender masing-masing kepercayaan",
    doaHarian: [
      {
        judul: "Prinsip Menghormati Keberagaman",
        isi: "FanzzTools menghormati seluruh agama dan kepercayaan yang diakui maupun tradisi spiritual semua orang. Bagian ini memberi ruang belajar yang netral dan penuh hormat — gunakan fitur Tanya AI untuk mempelajari ajaran, sejarah, dan praktik kepercayaan tertentu secara lebih dalam.",
      },
      {
        judul: "Sikap Toleransi",
        isi: "Semua agama mengajarkan kebaikan: jujur, kasih pada sesama, dan pengendalian diri. Dalam bertanya dan berdiskusi tentang agama lain, gunakan bahasa yang sopan, hindari hinaan, dan dengarkan dengan empati.",
      },
    ],
    pengajian: "Gunakan tombol Tanya AI untuk mendalami ajaran, kitab suci, dan praktik ibadah kepercayaan tertentu.",
  },
];

/** Hitung arah kiblat (bearing) dari koordinat user ke Ka'bah — derajat dari utara sejati. */
export function arahKiblat(lat: number, lon: number): number {
  const kaabaLat = 21.4224779;
  const kaabaLon = 39.8261887;
  const φ1 = (lat * Math.PI) / 180;
  const φ2 = (kaabaLat * Math.PI) / 180;
  const Δλ = ((kaabaLon - lon) * Math.PI) / 180;
  const y = Math.sin(Δλ);
  const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(Δλ);
  const bearing = (Math.atan2(y, x) * 180) / Math.PI;
  return (bearing + 360) % 360;
}
