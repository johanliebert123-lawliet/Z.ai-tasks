import { UA_DESKTOP } from "@/lib/constants";

/**
 * Mirror resolver (V2-new) — ubah halaman embed mirror (vidhide/streampoi/
 * playmogo/filedon/dst.) menjadi URL video LANGSUNG (m3u8/mp4).
 *
 * Teknik:
 *  1. Fetch halaman embed dengan UA desktop + Referer asal.
 *  2. Unpack JavaScript packer p,a,c,k,e,d (dua varian: klasik & vidhide).
 *  3. Cari URL .m3u8 / .mp4 / file:"..." pada HTML asli ATAU hasil unpack.
 *  4. Fallback cURL subprocess (fingerprint TLS berbeda sering lolos Cloudflare).
 *
 * Hasil: { url, type: "hls" | "mp4", source } | null.
 */

export interface ResolvedStream {
  url: string;
  type: "hls" | "mp4";
  source: string;
}

/** Unpacker varian vidhide/streamwish: while(c--)if(k[c])p=p.replace(...) */
function unpackVidhide(html: string): string | null {
  const re =
    /eval\(function\(p,a,c,k,e,d\)\{while\(c--\)if\(k\[c\]\)p=p\.replace\(new RegExp\('\\\\b'\+c\.toString\(a\)\+'\\\\b','g'\),k\[c\]\);return p\}\(\s*'([\s\S]*?)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'([\s\S]*?)'\.split\('\|'\)\s*\)\)/;
  const m = html.match(re);
  if (!m) return null;
  let p: string;
  try {
    p = m[1].replace(/\\'/g, "'").replace(/\\\\/g, "\\");
  } catch {
    return null;
  }
  const a = parseInt(m[2], 10);
  const c = parseInt(m[3], 10);
  const kk = m[4].split("|");
  for (let i = c - 1; i >= 0; i--) {
    if (!kk[i]) continue;
    try {
      p = p.replace(new RegExp("\\b" + i.toString(a) + "\\b", "g"), kk[i]);
    } catch {
      return null;
    }
  }
  return p;
}

/** Unpacker varian klasik (nekoWrap / jwplayer lama): e=function... return p */
function unpackClassic(html: string): string | null {
  const re = /eval\(function\(p,a,c,k,e,d\)\{[\s\S]*?\}\(([\s\S]*?)\)\)/;
  const m = html.match(re);
  if (!m) return null;
  let args: unknown[];
  try {
    args = JSON.parse("[" + m[1].replace(/'/g, '"') + "]");
  } catch {
    return null;
  }
  if (!Array.isArray(args) || args.length < 4) return null;
  const [p, a, c, k] = args as [string, number, number, string];
  const kk = String(k).split("|");
  const e = (cc: number): string =>
    cc < a ? "" : e(Math.floor(cc / a)) + (cc % a > 35 ? String.fromCharCode((cc % a) + 29) : (cc % a).toString(36));
  const dict: Record<string, string> = {};
  for (let i = 0; i < c; i++) dict[e(i)] = kk[i] || "";
  return String(p).replace(/\b\w+\b/g, (w) => (dict[w] !== undefined ? dict[w] : w));
}

/** zuperupdt #10 — varian packer "modern": p=a(c) satu-liner
 *  (dipakai sejumlah host mirror baru, mis. pola `}('...',62,123,'x|y|z'.split('|'))`
 *  dengan while/for balik). Dicoba kalau dua varian utama gagal. */
function unpackModern(html: string): string | null {
  const re = /\}\('([^']+)'\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*'([^']*)'\.split\('\|'\)/;
  const m = html.match(re);
  if (!m) return null;
  let p: string;
  try {
    p = m[1].replace(/\\'/g, "'").replace(/\\\\/g, "\\");
  } catch {
    return null;
  }
  const a = parseInt(m[2], 10);
  const c = parseInt(m[3], 10);
  const kk = m[4].split("|");
  const e = (cc: number): string =>
    cc < a ? "" : e(Math.floor(cc / a)) + (cc % a > 35 ? String.fromCharCode((cc % a) + 29) : (cc % a).toString(36));
  const dict: Record<string, string> = {};
  for (let i = 0; i < c; i++) dict[e(i)] = kk[i] || "";
  return p.replace(/\b\w+\b/g, (w) => (dict[w] !== undefined ? dict[w] : w));
}

function pickUrls(hay: string): { m3u8: string[]; mp4: string[] } {
  const m3u8 = [...new Set(hay.match(/https?:\/\/[^\s"'\\<>]+\.m3u8[^\s"'\\<>]*/g) || [])];
  const mp4 = [...new Set(hay.match(/https?:\/\/[^\s"'\\<>]+\.mp4[^\s"'\\<>]*/g) || [])];
  // juga file:"https://..." (jwplayer setup)
  const files = [...new Set(hay.match(/file\s*:\s*["'](https?:\/\/[^"']+)["']/g) || [])].map((f) =>
    f.replace(/file\s*:\s*["']/, "").replace(/["']$/, "")
  );
  // zuperupdt #10: varian tambahan — sources:[{file:"..."}] jwplayer/plyr,
  // <source src="..."> HTML5, dan URL dengan query (?url=...m3u8)
  const srcTags = [...new Set(hay.match(/<source[^>]+src=["']([^"']+)["']/gi) || [])].map((f) =>
    (/src=["']([^"']+)["']/i.exec(f)?.[1] || "")
  );
  const queryMedia = [...new Set(hay.match(/https?:\/\/[^\s"'&\\<>]+\.(?:m3u8|mp4)\?[^\s"'\\<>]*/g) || [])];
  for (const f of [...files, ...srcTags, ...queryMedia]) {
    if (/\.m3u8/i.test(f) && !m3u8.includes(f)) m3u8.push(f);
    if (/\.mp4/i.test(f) && !mp4.includes(f)) mp4.push(f);
  }
  // buang yang jelas-jelas bukan media (iklan/pixel/logo)
  const bad = /(\.png|\.jpg|\.jpeg|\.gif|\.webp|logo|banner|advert|\.ts\b)/i;
  return {
    m3u8: m3u8.filter((u) => !bad.test(u)),
    mp4: mp4.filter((u) => !bad.test(u)),
  };
}

/** Fetch teks dengan fallback cURL subprocess. */
async function rawGet(url: string, referer: string | null, timeoutMs = 15000): Promise<string | null> {
  const headers: Record<string, string> = {
    "User-Agent": UA_DESKTOP,
    Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,id-ID;q=0.8",
  };
  if (referer) headers.Referer = referer;
  // 1) Node fetch
  try {
    const res = await fetch(url, { headers, redirect: "follow", signal: AbortSignal.timeout(timeoutMs) });
    if (res.ok) {
      const t = await res.text();
      if (!/Just a moment|Attention Required/i.test(t.slice(0, 3000))) return t;
    }
  } catch {
    /* lanjut cURL */
  }
  // 2) cURL subprocess
  const { execFile } = await import("child_process");
  return new Promise((resolve) => {
    const args = [
      "-s",
      "-L",
      "--compressed",
      "--max-time",
      String(Math.ceil(timeoutMs / 1000)),
      "-A",
      UA_DESKTOP,
      ...Object.entries(headers)
        .filter(([k]) => !/^user-agent$/i.test(k))
        .flatMap(([k, v]) => ["-H", `${k}: ${v}`]),
      url,
    ];
    execFile("curl", args, { timeout: timeoutMs + 5000, maxBuffer: 12 * 1024 * 1024 }, (err, stdout) => {
      if (err || typeof stdout !== "string") return resolve(null);
      if (/Just a moment|Attention Required/i.test(stdout.slice(0, 3000))) return resolve(null);
      resolve(stdout);
    });
  });
}

/**
 * Resolve satu halaman embed mirror → stream langsung.
 * @param embedUrl URL halaman embed (bukan URL video)
 * @param referer  Referer asal (halaman nonton sumber)
 */
export async function resolveMirror(embedUrl: string, referer: string | null): Promise<ResolvedStream | null> {
  if (!/^https?:\/\//i.test(embedUrl)) return null;
  const html = await rawGet(embedUrl, referer);
  if (!html) return null;

  // coba tiga varian unpacker (zuperupdt #10: + varian modern)
  let unpacked = "";
  try {
    unpacked = unpackVidhide(html) || unpackClassic(html) || unpackModern(html) || "";
  } catch {
    unpacked = "";
  }
  const hays = unpacked ? [unpacked, html] : [html];
  for (const hay of hays) {
    const { m3u8, mp4 } = pickUrls(hay);
    if (m3u8.length) return { url: m3u8[0], type: "hls", source: new URL(embedUrl).hostname };
    if (mp4.length) return { url: mp4[0], type: "mp4", source: new URL(embedUrl).hostname };
  }
  return null;
}

/** Bangun URL pemutaran lewat proxy streaming (dengan Referer asal). */
export function proxyStreamUrl(url: string, referer: string | null): string {
  const p = new URLSearchParams({ url });
  if (referer) p.set("referer", referer);
  return `/api/stream/proxy?${p.toString()}`;
}
