import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FanzzTools.V2 — All-in-One Tools",
  description:
    "FanzzTools — website all-in-one tools: nonton film, AI chat multi-model, musik, downloader, email sementara, FanzzSecurity, FanzSec.Ai, dan aktivasi premium. Modern, tajam, smooth.",
  applicationName: "FanzzTools.V2",
  manifest: "/manifest.json",
  icons: {
    icon: "/icon.svg",
  },
  openGraph: {
    title: "FanzzTools.V2 — All-in-One Tools",
    description:
      "Film, AI, musik, downloader, FanzzSecurity & FanzSec.Ai dalam satu tempat.",
    type: "website",
    siteName: "FanzzTools",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#131318" },
    { media: "(prefers-color-scheme: light)", color: "#f4f4f6" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

/* Migrasi data lokal lama ( branding lama FanzzTools = LyzsTools) → kunci baru.
 * Dijalankan SEKALI saat boot: salin nilai kunci lama ke kunci baru bila kunci
 * baru belum ada. Tidak destruktif — data lama TETAP tersimpan, tidak dihapus.
 * Alias lama tidak pernah ditampilkan di UI. */
const storageMigrate = `(function(){try{
var pairs=[
 ["fanzz_theme","lyzs_theme"],
 ["fanzz_vault_v2","lyzs_vault_v2"],
 ["fanzz_settings_v2","lyzs_settings_v2"],
 ["fanzz_history_v1","lyzs_history_v1"],
 ["fanzz_history_v2","lyzs_history_v2"],
 ["fanzz_ai_sessions_v1","lyzs_ai_sessions_v1"],
 ["fanzz_ai_memory_v1","lyzs_ai_memory_v1"],
 ["fanzz_song_cache_v","lyzs_song_cache_v"],
 ["fanzz_fav_songs_v2","lyzs_fav_songs_v2"],
 ["fanzz_geo_asked","lyzs_geo_asked"],
 ["fanzz_ai_preask","lyzs_ai_preask"],
 ["fanzz_ai_mode","lyzs_ai_mode"],
 ["fanzz_display_name","lyzs_display_name"],
 ["fanzz_donghua_maintenance","lyzs_donghua_maintenance"]
];
for(var i=0;i<pairs.length;i++){
 var nk=pairs[i][0],ok=pairs[i][1];
 var nv=localStorage.getItem(nk),ov=localStorage.getItem(ok);
 if(nv===null&&ov!==null){localStorage.setItem(nk,ov);}
}
}catch(e){}})();`;

const themeInit = `(function(){try{${storageMigrate}var t=localStorage.getItem("fanzz_theme")||localStorage.getItem("lyzs_theme");if(t==="light")document.documentElement.classList.add("light");}catch(e){}})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="dark">
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
