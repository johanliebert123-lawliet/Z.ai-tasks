"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useApp } from "@/lib/app-store";
import LoadingScreen from "@/components/LoadingScreen";
import AuthGate from "@/components/AuthGate";
import AppShell from "@/components/AppShell";
import LocationPermission from "@/components/LocationPermission";

export default function Page() {
  const { phase, setPhase, setUser } = useApp();
  const [booting, setBooting] = useState(true);

  // setelah loading screen: cek session cookie server
  useEffect(() => {
    if (phase !== "boot") return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/auth/session");
        const d = await res.json().catch(() => null);
        if (cancelled) return;
        if (res.ok && d?.ok && d.user) {
          setUser(d.user);
          setPhase("app");
        }
      } catch {
        /* anggap belum login */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [phase, setPhase, setUser]);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <AnimatePresence mode="wait">
        {booting || phase === "boot" ? (
          <LoadingScreen
            key="loading"
            onDone={() => {
              setBooting(false);
              // kalau session belum kecek (masih boot), tunggu bentar
              setTimeout(() => {
                if (useApp.getState().phase === "boot") setPhase("auth");
              }, 300);
            }}
          />
        ) : phase === "auth" ? (
          <AuthGate
            key="auth"
            onLogin={(u) => {
              setUser(u);
              setPhase("app");
            }}
          />
        ) : (
          <motion.div key="app" initial={{ opacity: 0, scale: 0.99 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.35 }}>
            <AppShell />
            <LocationPermission />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
