import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { TMDB_KEY, TMDB_BASE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Nonton Dracin V2.11 (perbaikan #6 & #34).
 *
 * MASALAH LAMA: sumber tunggal dracinema.com — situs tersebut memblokir SEMUA
 * IP datacenter (Cloudflare 403, termasuk dari Vercel), sehingga daftar gagal
 * dimuat & video tidak pernah bisa diputar ("poster doang ada").
 *
 * SEKARANG: TMDB sebagai katalog drama Asia (Drama China/Korea, lengkap,
 * poster + sinopsis Indonesia) + PEMUTARAN lewat 20+ server embed milik
 * FanzzTools sendiri (/api/movies/servers?type=tv) — jalur yang sama dengan
 * Nonton Film yang sudah terbukti stabil. dracinema.care dipertahankan
 * sebagai catatan legacy, tidak lagi digunakan karena pemblokiran permanen.
 */

interface DramaCard {
  id: string; // "tmdb-<id>"
  tmdbId: number;
  title: string;
  cover: string;
  year?: string;
  genres?: string[];
  episodesCount?: number;
  url: string; // tmdbId — dipakai view untuk buka detail
  origin?: string;
}

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000;

function cacheGet(key: string): unknown | null {
  const hit = CACHE.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.data;
  return null;
}
function cacheSet(key: string, data: unknown) {
  CACHE.set(key, { at: Date.now(), data });
  if (CACHE.size > 60) {
    const first = CACHE.keys().next().value;
    if (first) CACHE.delete(first);
  }
}

async function tmdb(path: string): Promise<Record<string, unknown> | null> {
  try {
    const sep = path.includes("?") ? "&" : "?";
    const res = await fetch(`${TMDB_BASE}${path}${sep}api_key=${TMDB_KEY}`, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return null;
    return (await res.json()) as Record<string, unknown>;
  } catch {
    return null;
  }
}

/** Genre yang TIDAK termasuk dracin live-action (animasi/anak/realita dll).
 *  Difilter di sisi route karena tanpa_genre TMDB tidak stabil
 *  bila digabung with_origin_country. */
const EXCLUDE_GENRES = new Set([16, 99, 10762, 10763, 10764, 10767]);

function isLiveActionDrama(item: TmdbItem): boolean {
  return !(item.genre_ids || []).some((g) => EXCLUDE_GENRES.has(g));
}

/** Region → asal negara (pipe = OR di TMDB; koma berarti AND!). */
const REGIONS: Record<string, { label: string; countries: string }> = {
  cn: { label: "Drama China", countries: "CN|TW|HK" },
  kr: { label: "Drama Korea", countries: "KR" },
  all: { label: "Semua Asia", countries: "CN|TW|HK|KR|JP|SG|TH|PH" },
};

/** Genre TMDB (serial TV) yang relevan untuk drama. */
const GENRES: Array<{ slug: string; name: string; id: number }> = [
  { slug: "romance", name: "Romansa", id: 1074 },
  { slug: "drama", name: "Drama", id: 18 },
  { slug: "action", name: "Aksi & Petualangan", id: 10759 },
  { slug: "scifi", name: "Fantasi & Sci-Fi", id: 10765 },
  { slug: "mystery", name: "Misteri", id: 9648 },
  { slug: "crime", name: "Kejahatan", id: 80 },
  { slug: "family", name: "Keluarga", id: 10751 },
  { slug: "war", name: "Perang & Politik", id: 10768 },
];

interface TmdbItem {
  id: number;
  name?: string;
  original_name?: string;
  first_air_date?: string;
  poster_path?: string | null;
  genre_ids?: number[];
  vote_average?: number;
  origin_country?: string[];
  overview?: string;
}

function toCard(item: TmdbItem): DramaCard {
  const year = item.first_air_date ? item.first_air_date.slice(0, 4) : undefined;
  return {
    id: `tmdb-${item.id}`,
    tmdbId: item.id,
    title: item.name || item.original_name || "Tanpa judul",
    cover: item.poster_path ? `https://image.tmdb.org/t/p/w342${item.poster_path}` : "",
    year,
    genres: (item.genre_ids || []).map((gid) => GENRES.find((g) => g.id === gid)?.name).filter(Boolean) as string[],
    url: String(item.id),
    origin: item.origin_country?.join(", "),
  };
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`dracin:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — tunggu sebentar" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;
  const refresh = sp.get("refresh") !== null;

  /* ---------- 1) Beranda / genre (TMDB discover) ---------- */
  if (sp.get("home") !== null || sp.get("genre") !== null || sp.get("region") !== null) {
    const region = REGIONS[sp.get("region") || "cn"] ? sp.get("region") || "cn" : "cn";
    const genreSlug = sp.get("genre") || "";
    const page = Math.min(Math.max(Number(sp.get("page")) || 1, 1), 20);
    const key = `discover:${region}:${genreSlug}:${page}`;
    const cached = refresh ? null : cacheGet(key);
    if (cached) return Response.json({ ok: true, ...(cached as object), cached: true });

    const genre = GENRES.find((g) => g.slug === genreSlug);
    // basis: genre Drama (18) — pastikan hasilnya dracin live-action;
    // bila user memilih genre lain, genre itu yang dipakai.
    const genreId = genre ? genre.id : 18;
    const base = `/discover/tv?language=en-US&sort_by=popularity.desc&page=${page}&include_null_first_air_dates=false&with_origin_country=${REGIONS[region].countries}&with_genres=${genreId}&vote_count.gte=5`;

    // ambil 1 halaman; bila hasil live-action tipis, lanjut halaman 2 lalu gabung
    const d1 = await tmdb(base);
    let items = ((d1?.results as TmdbItem[]) || []).filter(isLiveActionDrama);
    if (items.length < 12 && page === 1) {
      const d2 = await tmdb(`/discover/tv?language=en-US&sort_by=popularity.desc&page=2&include_null_first_air_dates=false&with_origin_country=${REGIONS[region].countries}&with_genres=${genreId}&vote_count.gte=5`);
      items = items.concat((((d2?.results as TmdbItem[]) || [])).filter(isLiveActionDrama));
    }
    const dramas = items.filter((x) => x.poster_path).slice(0, 24).map(toCard);
    const payload = {
      region,
      regionLabel: REGIONS[region].label,
      dramas,
      total: dramas.length,
      page,
    };
    cacheSet(key, payload);
    return Response.json({ ok: true, ...payload, genres: GENRES.map(({ name, slug }) => ({ name, slug })) });
  }

  /* ---------- 2) Pencarian ---------- */
  const q = sp.get("q");
  if (q) {
    const query = q.slice(0, 90).trim();
    const key = `search:${query}`;
    const cached = refresh ? null : cacheGet(key);
    if (cached) return Response.json({ ok: true, ...(cached as object), cached: true });

    const d = await tmdb(`/search/tv?language=en-US&include_adult=false&query=${encodeURIComponent(query)}`);
    const items = (d?.results as TmdbItem[] | undefined) || [];
    const dramas = items
      .filter((x) => x.poster_path)
      .filter((x) => !x.origin_country?.length || x.origin_country.some((c) => ["CN", "TW", "KR", "JP", "HK", "SG", "TH", "PH"].includes(c)))
      .slice(0, 24)
      .map(toCard);
    const payload = { dramas, total: dramas.length };
    cacheSet(key, payload);
    return Response.json({ ok: true, ...payload });
  }

  /* ---------- 3) Detail + daftar season/episode ---------- */
  const detailId = sp.get("detail");
  if (detailId && /^\d+$/.test(detailId)) {
    const seasonRaw = Number(sp.get("season"));
    const season = Number.isInteger(seasonRaw) && seasonRaw > 0 ? seasonRaw : undefined;
    const key = `detail:${detailId}:${season || 0}`;
    const cached = refresh ? null : cacheGet(key);
    if (cached) return Response.json({ ok: true, ...(cached as object), cached: true });

    const d = await tmdb(`/tv/${detailId}?language=en-US`);
    if (!d || !d.id) {
      return Response.json({ ok: false, error: "Drama tidak ditemukan di katalog." }, { status: 404 });
    }
    const seasonsAll = (d.seasons as Array<Record<string, unknown>>) || [];
    const seasons = seasonsAll
      .filter((s) => Number(s.season_number) >= 1 && Number(s.episode_count) > 0)
      .map((s) => ({
        number: Number(s.season_number),
        name: String(s.name || `Season ${s.season_number}`),
        episodeCount: Number(s.episode_count),
      }));

    // daftar episode untuk season terpilih (default: season 1)
    const chosen = season || seasons[0]?.number || 1;
    let episodes: Array<{ number: number; title: string; url: string }> = [];
    if (seasons.length) {
      const eps = await tmdb(`/tv/${detailId}/season/${chosen}?language=en-US`);
      const list = (eps?.episodes as Array<Record<string, unknown>>) || [];
      episodes = list.map((e) => ({
        number: Number(e.episode_number),
        title: String(e.name || `Episode ${e.episode_number}`),
        url: `${detailId}/s${chosen}e${e.episode_number}`,
      }));
    }

    // rekomendasi
    const rec = await tmdb(`/tv/${detailId}/recommendations?language=en-US&page=1`);
    const recItems = (rec?.results as TmdbItem[] | undefined) || [];
    const recommendations = recItems.filter((x) => x.poster_path && isLiveActionDrama(x)).slice(0, 12).map(toCard);

    const payload = {
      detail: {
        id: `tmdb-${d.id}`,
        tmdbId: Number(d.id),
        title: String(d.name || d.original_name || "Tanpa judul"),
        cover: d.poster_path ? `https://image.tmdb.org/t/p/w500${d.poster_path}` : "",
        synopsis: String(d.overview || "Sinopsis belum tersedia untuk judul ini."),
        genres: ((d.genres as Array<{ name: string }>) || []).map((g) => ({
          name: g.name,
          slug: String(g.name).toLowerCase().replace(/\s+/g, "-"),
        })),
        seasons,
        currentSeason: chosen,
        episodes,
        episodesCount: seasons.reduce((a, s) => a + s.episodeCount, 0),
        year: d.first_air_date ? String(d.first_air_date).slice(0, 4) : undefined,
        rating: d.vote_average ? Number(d.vote_average).toFixed(1) : undefined,
        origin: ((d.origin_country as string[]) || []).join(", "),
        recommendations,
      },
    };
    cacheSet(key, payload);
    return Response.json({ ok: true, ...payload });
  }

  return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
}
