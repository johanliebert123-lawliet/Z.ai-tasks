import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/**
 * AI Image Generator — deepai.org text2img.
 * Port persis dari scraper deepAiImageGen (tryit-key + cookie flow).
 */

const BASE_URL = "https://deepai.org";
const API_BASE = "https://api.deepai.org";
const MODEL_ID = "text2img";
const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

 
/** Hash md5-varian deepai — port 1:1 dari scraper, TERVERIFIKASI identik
 *  dengan fungsi asli (test scripts/test-hash.ts — semua input match). */
function myhashfunction(input: string): string {
  const a: number[] = [];
  for (let b = 0; 64 > b; ) {
    a[b] = 0 | (4294967296 * Math.sin(++b % Math.PI));
  }

  let d = 1732584193;
  let e = 4023233417;
  const g: number[] = [d, e, ~d, ~e];
  const h: number[] = [];
  const msg = unescape(encodeURI(input)) + "\u0080";
  let k = msg.length;

  let c = (--k / 4 + 2) | 15;
  for (h[--c] = 8 * k; ~k; ) {
    h[k >> 2] = (h[k >> 2] ?? 0) | (msg.charCodeAt(k) << (8 * k--));
  }

  for (let b = 0; b < c; b += 16) {
    let kk: number[] = g;
    d = kk[1] | 0;
    e = kk[2];
    for (let l = 0; l < 64; ) {
      const roundIdx = l >> 4;
      const f = kk[3];
      const round = [(d & e) | (~d & f), (f & d) | (~f & e), d ^ e ^ f, e ^ (d | ~f)][roundIdx] as number;
      const msgIdx = [l, 5 * l + 1, 3 * l + 5, 7 * l][roundIdx] & 15;
      const newF = kk[0] + round + a[l] + ~~(h[b | msgIdx] ?? 0);
      const shift = [7, 12, 17, 22, 5, 9, 14, 20, 4, 11, 16, 23, 6, 10, 15, 21][4 * roundIdx + (l % 4)] as number;
      l++;
      const newEl = d + ((newF << shift) | (newF >>> -shift));
      const dOld = d;
      kk = [kk[3], newEl, dOld, e];
      d = kk[1] | 0;
      e = kk[2];
    }
    for (let l2 = 4; l2; ) {
      g[--l2] += kk[l2];
    }
  }

  let result = "";
  for (let l = 0; 32 > l; ) {
    result += ((g[l >> 3] >> (4 * (1 ^ l++))) & 15).toString(16);
  }
  return result.split("").reverse().join("");
}

function generateTryItKey(): string {
  const myrandomstr = Math.round(Math.random() * 100000000000) + "";
  const hash1 = myhashfunction(
    USER_AGENT +
      myhashfunction(
        USER_AGENT + myhashfunction(USER_AGENT + myrandomstr + "hackers_become_a_little_stinkier_every_time_they_hack")
      )
  );
  return "tryit-" + myrandomstr + "-" + hash1;
}

async function getCookies(): Promise<string> {
  const res = await fetch(`${BASE_URL}/machine-learning-model/text2img`, {
    headers: {
      "User-Agent": USER_AGENT,
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    },
    signal: AbortSignal.timeout(20000),
  });
  const setCookie = res.headers.getSetCookie?.() || [];
  return setCookie.map((c) => c.split(";")[0]).join("; ");
}

/** Fallback: pollinations.ai — tanpa API key, selalu jalan dari server. */
async function viaPollinations(prompt: string): Promise<{ imageUrl: string } | null> {
  try {
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt.slice(0, 300))}?width=768&height=768&nologo=true&seed=${Math.floor(Math.random() * 999999)}`;
    const res = await fetch(url, {
      headers: { "User-Agent": USER_AGENT, Accept: "image/*" },
      redirect: "follow",
      signal: AbortSignal.timeout(120000),
    });
    if (!res.ok) return null;
    const mime = res.headers.get("content-type") || "";
    if (!mime.startsWith("image/")) return null;
    return { imageUrl: url };
  } catch {
    return null;
  }
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`aiimg:${ip}`, 8, 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Bentar lagi — maksimal 8 gambar per menit ya" },
      { status: 429 }
    );
  }

  const body = (await req.json().catch(() => null)) as { prompt?: string } | null;
  const prompt = (body?.prompt || "").trim().slice(0, 500);
  if (prompt.length < 3) {
    return Response.json({ ok: false, error: "Deskripsi gambarnya minimal 3 karakter" }, { status: 400 });
  }

  /* --- Sumber 1: deepai.org (deepAiImageGen port — tryit-key + device cookie) --- */
  try {
    const cookie = await getCookies();
    const apiKey = generateTryItKey();

    const form = new URLSearchParams();
    form.append("text", prompt);
    form.append("generation_source", "img");

    const res = await fetch(`${API_BASE}/api/${MODEL_ID}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": USER_AGENT,
        Accept: "application/json, text/javascript, */*; q=0.01",
        "Accept-Language": "en-US,en;q=0.9",
        "api-key": apiKey,
        Cookie: cookie,
        Origin: BASE_URL,
        Referer: `${BASE_URL}/machine-learning-model/${MODEL_ID}`,
        "Sec-Fetch-Dest": "empty",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Site": "same-site",
      },
      body: form.toString(),
      signal: AbortSignal.timeout(45000),
    });

    const d = (await res.json().catch(() => null)) as Record<string, unknown> | null;

    if (res.ok && d?.output_url) {
      return Response.json({
        ok: true,
        imageUrl: String(d.output_url),
        shareUrl: d.share_url ? String(d.share_url) : null,
        source: "deepai",
      });
    }
  } catch {
    /* lanjut fallback */
  }

  /* --- Sumber 2 (fallback): pollinations.ai — stabil & tanpa key --- */
  const r = await viaPollinations(prompt);
  if (r) {
    return Response.json({ ok: true, imageUrl: r.imageUrl, shareUrl: null, source: "pollinations" });
  }

  return Response.json(
    { ok: false, error: "Generator lagi penuh — tunggu bentar terus coba lagi ya" },
    { status: 502 }
  );
}
