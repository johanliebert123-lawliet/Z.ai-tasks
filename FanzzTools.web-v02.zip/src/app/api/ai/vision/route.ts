import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { aiChat, describeImage } from "@/lib/ai";
import { SITE_CONTEXT } from "@/lib/site-context";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`vision:${ip}`, 10, 5 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Kebanyakan analisis gambar, tunggu sebentar" },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const image = body.image; // data URL: data:image/jpeg;base64,....
  const question =
    typeof body.question === "string" && body.question.trim()
      ? body.question.trim().slice(0, 1000)
      : "Jelaskan gambar ini sedetail mungkin dalam bahasa Indonesia: apa isinya, objek utamanya, suasana/warnanya, dan hal menarik lainnya.";

  const m = typeof image === "string" ? image.match(/^data:(image\/(jpeg|png|webp|gif));base64,([A-Za-z0-9+/=]+)$/) : null;
  if (!m) {
    return Response.json(
      { ok: false, error: "Gambar tidak valid (harus JPEG/PNG/WebP/GIF, maks ~4MB)" },
      { status: 400 }
    );
  }

  const [, , mime, b64] = m;
  if (b64.length > 6_000_000) {
    return Response.json({ ok: false, error: "Gambar kegedean (maks ~4MB)" }, { status: 400 });
  }

  try {
    // 1) Deskripsi visual gambar
    const description = await describeImage(b64, `image/${mime}`);

    // 2) Analisis lanjutan oleh model chat
    const prompt = `${SITE_CONTEXT}

Kamu sedang diberi hasil analisis visual sebuah gambar yang di-upload user. Tugasmu: jawab pertanyaan user tentang gambarnya dengan santai dan informatif dalam bahasa Indonesia. Sertakan detail penting dari deskripsi di bawah.

DESKRIPSI VISUAL GAMBAR:
${description.slice(0, 4000)}

PERTANYAAN USER:
${question}`;

    const { text, model } = await aiChat("gpt-4.1-nano", [
      { role: "user", content: prompt },
    ]);

    return Response.json({ ok: true, text, model, description });
  } catch (e) {
    return Response.json(
      {
        ok: false,
        error:
          e instanceof Error
            ? e.message
            : "Gagal menganalisis gambar, coba lagi ya",
      },
      { status: 502 }
    );
  }
}
