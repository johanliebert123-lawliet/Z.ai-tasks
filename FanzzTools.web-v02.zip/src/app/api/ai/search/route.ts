import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { webSearch } from "@/lib/ai";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`aisearch:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan pencarian" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 120);
  if (q.length < 2) {
    return Response.json({ ok: false, error: "Query terlalu pendek" }, { status: 400 });
  }

  const hits = await webSearch(q);
  if (!hits.length) {
    return Response.json(
      { ok: false, error: "Tidak ada hasil — coba kata kunci lain" },
      { status: 404 }
    );
  }
  return Response.json({ ok: true, query: q, results: hits });
}
