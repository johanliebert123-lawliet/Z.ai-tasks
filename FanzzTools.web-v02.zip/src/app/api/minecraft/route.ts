import { NextRequest } from "next/server";
import * as cheerio from "cheerio";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Minecraft Downloader (V2 Modern-UpdSec) — port legal dari scraper CLI
 * mcpelife.com (main.js milik pemilik) ke API route Next.js.
 *
 * Fitur (sama dengan CLI):
 *  ?search=kata&page=1        — cari konten (mods/maps/shader/apk/…)
 *  ?category=/mods/&page=1    — telusuri kategori
 *  ?trending=1                — populer & trending
 *  ?versions=1                — arsip versi Minecraft PE (lama → terbaru)
 *  ?servers=1                 — server Bedrock multiplayer
 *  ?guides=1                  — panduan instalasi
 *  ?detail=<url>              — detail konten + link unduhan langsung
 *
 * Unduhan file dilewatkan lewat /api/download/file (proxy, butuh sesi).
 */

const BASE_URL = "https://mcpelife.com";

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000;

async function get(path: string): Promise<{ html: string; url: string } | null> {
  const hit = CACHE.get(path);
  if (hit && Date.now() - hit.at < TTL) return hit.data as { html: string; url: string };
  try {
    const res = await fetch(BASE_URL + path, {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      signal: AbortSignal.timeout(25000),
    });
    if (!res.ok) return null;
    const html = await res.text();
    const data = { html, url: BASE_URL + path };
    CACHE.set(path, { at: Date.now(), data });
    return data;
  } catch {
    return null;
  }
}

async function load(path: string): Promise<{ $: cheerio.CheerioAPI; url: string } | null> {
  const raw = await get(path);
  if (!raw?.html) return null;
  return { $: cheerio.load(raw.html), url: raw.url };
}

function clean(t: string | undefined | null) {
  return (t || "").replace(/\s+/g, " ").trim();
}

const SKIP_URL = /\/(download\/?$|about-us\/?$|contacts\/?$|privacy-policy\/?$|dmca\/?$|author\/?$)/i;

function scrapeList($: cheerio.CheerioAPI) {
  const items: Array<Record<string, string>> = [];
  $("article, .post, .entry").each((_, el) => {
    const title = clean($(el).find("h2, h3").first().text());
    let link = $(el).find("a").first().attr("href") || "";
    const img =
      $(el).find("img").first().attr("src") ||
      $(el).find("img").first().attr("data-src") ||
      `${BASE_URL}/favicon.ico`;
    const dateText = clean($(el).find("time, .date, .post-date").first().text()) || "Recently Updated";
    const desc =
      clean($(el).find("p").first().text()).slice(0, 180) ||
      "Download dan jelajahi konten Minecraft di MCPELife.";
    if (title && link && !items.some((i) => i.url === link)) {
      if (!link.startsWith("http")) link = `${BASE_URL}${link}`;
      if (!SKIP_URL.test(link)) {
        items.push({ title, url: link, thumbnail: img, date: dateText, description: desc });
      }
    }
    if (items.length >= 30) return false;
  });
  return items;
}

/* ---------- detail + unduhan langsung ---------- */

async function resolveDirect(downloadPageUrl: string) {
  try {
    const res = await fetch(downloadPageUrl, {
      headers: { "User-Agent": UA_DESKTOP, Accept: "text/html,*/*;q=0.8" },
      signal: AbortSignal.timeout(20000),
    });
    const html = await res.text();
    const $ = cheerio.load(html);
    let directUrl = "";
    $("a").each((_, el) => {
      const href = $(el).attr("href") || "";
      if (href.includes("dl.mcpelife.com") || /\.(apk|mcpack|mcworld|mcaddon|zip|ipa)(\?.*)?$/i.test(href)) {
        directUrl = href;
        return false;
      }
    });
    const pageText = $("body").text();
    const fileName =
      clean($(".file-name, .download-file-name, h1").first().text()) ||
      (directUrl ? directUrl.split("?")[0].split("/").pop() : "Minecraft File");
    const sizeMatch = pageText.match(/([\d.]+)\s*(MB|KB|GB)/i);
    const archMatch = pageText.match(/(arm64-v8a|armeabi-v7a|x86_64|x86)/i);
    return {
      download_page: downloadPageUrl,
      direct_url: directUrl || downloadPageUrl,
      file_name: fileName || "Minecraft File",
      file_size: sizeMatch ? `${sizeMatch[1]} ${sizeMatch[2].toUpperCase()}` : "Ukuran tidak diketahui",
      architecture: archMatch ? archMatch[1] : "Semua Arsitektur",
    };
  } catch {
    return {
      download_page: downloadPageUrl,
      direct_url: downloadPageUrl,
      file_name: "Tautan Unduhan",
      file_size: "—",
      architecture: "Universal",
    };
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`mcpe:${ip}`, 20, 60 * 1000).ok) {
    return tooManyResponse("Terlalu banyak permintaan — tunggu sebentar");
  }

  const sp = req.nextUrl.searchParams;

  try {
    /* ---- pencarian ---- */
    const q = (sp.get("search") || "").trim();
    if (q) {
      const page = Math.max(1, Math.min(50, Number(sp.get("page")) || 1));
      const path = page > 1 ? `/page/${page}/?s=${encodeURIComponent(q.slice(0, 80))}` : `/?s=${encodeURIComponent(q.slice(0, 80))}`;
      const doc = await load(path);
      if (!doc) return Response.json({ ok: false, error: "Gagal menghubungi MCPELife — coba lagi" }, { status: 502 });
      const results = scrapeList(doc.$);
      return Response.json({ ok: true, query: q, page, total: results.length, results });
    }

    /* ---- kategori ---- */
    const cat = (sp.get("category") || "").trim();
    if (cat) {
      const page = Math.max(1, Math.min(50, Number(sp.get("page")) || 1));
      let path = cat.startsWith("/") ? cat : `/${cat}`;
      if (page > 1) path = `${path.replace(/\/+$/, "")}/page/${page}/`;
      const doc = await load(path);
      if (!doc) return Response.json({ ok: false, error: "Kategori tidak ditemukan" }, { status: 404 });
      return Response.json({ ok: true, category: path, page, total: scrapeList(doc.$).length, results: scrapeList(doc.$) });
    }

    /* ---- trending ---- */
    if (sp.get("trending")) {
      const doc = await load("/");
      if (!doc) return Response.json({ ok: false, error: "Gagal memuat trending" }, { status: 502 });
      // semua hasil beranda = konten populer MCPELife (urut sudah dari sumber)
      const items = scrapeList(doc.$);
      return Response.json({ ok: true, total: items.length, results: items.slice(0, 24) });
    }

    /* ---- arsip versi ---- */
    if (sp.get("versions")) {
      const doc = await load("/download/");
      if (!doc) return Response.json({ ok: false, error: "Gagal memuat arsip versi" }, { status: 502 });
      const versions: Array<{ version_name: string; url: string }> = [];
      doc.$('a[href*="/download/minecraft-pe-"]').each((_, el) => {
        const title = clean(doc.$(el).text());
        let link = doc.$(el).attr("href") || "";
        if (title && link && !versions.some((v) => v.url === link)) {
          if (!link.startsWith("http")) link = `${BASE_URL}${link}`;
          versions.push({ version_name: title, url: link });
        }
      });
      return Response.json({ ok: true, total: versions.length, versions });
    }

    /* ---- server bedrock ---- */
    if (sp.get("servers")) {
      const doc = await load("/servers/");
      if (!doc) return Response.json({ ok: false, error: "Gagal memuat daftar server" }, { status: 502 });
      const servers: Array<Record<string, unknown>> = [];
      doc.$("code").each((_, el) => {
        const address = clean(doc.$(el).text());
        const card = doc.$(el).parents().filter((__, p) => doc.$(p).find("h2").length > 0).first();
        const title = clean(card.find("h2").text()) || "Minecraft Bedrock Server";
        const desc = clean(card.find("p").text()).slice(0, 200) || "Server multiplayer Bedrock edition.";
        const players = clean(card.find("strong").first().text()) || "Active";
        if (address && !servers.some((s) => s.address === address)) {
          servers.push({ title, status: "Online", address, port: 19132, players_online: players, description: desc });
        }
      });
      return Response.json({ ok: true, total: servers.length, servers });
    }

    /* ---- panduan ---- */
    if (sp.get("guides")) {
      const guides = [
        { title: "Cara Pasang Mod & Addon", url: `${BASE_URL}/how-to-install-mod-addon-in-minecraft-pe/` },
        { title: "Cara Pasang Maps", url: `${BASE_URL}/how-to-install-a-map-in-minecraft-pe/` },
        { title: "Cara Pasang Textures", url: `${BASE_URL}/how-to-install-textures-in-minecraft-pe/` },
        { title: "Cara Pasang Skins", url: `${BASE_URL}/how-to-install-skins-for-minecraft-pe/` },
      ];
      const results = await Promise.all(
        guides.map(async (g0) => {
          try {
            const res = await fetch(g0.url, {
              headers: { "User-Agent": UA_DESKTOP },
              signal: AbortSignal.timeout(15000),
            });
            const html = await res.text();
            const $ = cheerio.load(html);
            const steps: string[] = [];
            $("ul li").each((_, el) => {
              const t = clean($(el).text());
              if (t.length > 20 && !/downloads|reply|coming soon/i.test(t)) steps.push(t.slice(0, 300));
            });
            return {
              title: clean($("h1").first().text()) || g0.title,
              url: g0.url,
              summary: clean($("p").first().text()).slice(0, 250) || "Panduan Minecraft Bedrock di Android.",
              steps: steps.slice(0, 12),
            };
          } catch {
            return { title: g0.title, url: g0.url, summary: "Panduan instalasi.", steps: ["Unduh file lalu buka langsung dengan Minecraft Bedrock."] };
          }
        })
      );
      return Response.json({ ok: true, total: results.length, guides: results });
    }

    /* ---- detail konten + link unduhan ---- */
    const detail = (sp.get("detail") || "").trim();
    if (detail) {
      let url = detail;
      if (!url.startsWith("http")) url = url.startsWith("/") ? `${BASE_URL}${url}` : `${BASE_URL}/${url}`;
      if (!url.includes("mcpelife.com")) {
        return Response.json({ ok: false, error: "Hanya halaman MCPELife yang didukung" }, { status: 400 });
      }
      const res = await fetch(url, {
        headers: { "User-Agent": UA_DESKTOP, Accept: "text/html,*/*;q=0.8" },
        signal: AbortSignal.timeout(25000),
      });
      if (!res.ok) return Response.json({ ok: false, error: "Halaman tidak ditemukan" }, { status: 404 });
      const html = await res.text();
      const $ = cheerio.load(html);
      const pageText = $("body").text();

      const title = clean($("h1").first().text()) || "Tanpa Judul";
      const thumbnail = $("img").first().attr("src") || $('meta[property="og:image"]').attr("content") || `${BASE_URL}/favicon.ico`;
      const description = clean($('meta[name="description"]').attr("content") || $("p").first().text()).slice(0, 500);

      const authorEl = $('a[href*="/author/"], .author-name').first();
      const author = clean(authorEl.text()) || "MCPELife Team";
      const dateMatch = pageText.match(/(Published|Updated)\s+(\d{1,2}\s+[A-Za-z]+\s+\d{4})/i);
      const ratingMatch = pageText.match(/(\d+(\.\d+)?)\s*\/\s*5/);
      const dlCount = pageText.match(/([\d,]+)\s+downloads/i);
      const commCount = pageText.match(/(\d+)\s+comments/i);

      // screenshot
      const screenshots: string[] = [];
      $("img").each((_, el) => {
        const src = $(el).attr("src") || $(el).attr("data-src") || "";
        if ((src.includes("img.mcpelife.com") || src.includes("wp-content/uploads")) && !/logo|rating|svg/i.test(src)) {
          if (!screenshots.includes(src)) screenshots.push(src);
        }
        if (screenshots.length >= 8) return false;
      });

      // kumpulkan variasi unduhan
      const downloadLinks: Array<{ title: string; info: string; url: string }> = [];
      $('a[href*="/download/"]').each((_, el) => {
        let href = $(el).attr("href") || "";
        if (href.match(/\/download\/\d+\/?$/)) {
          if (!href.startsWith("http")) href = `${BASE_URL}${href}`;
          if (!downloadLinks.some((d) => d.url === href)) {
            const container = $(el).closest("div, li, tr");
            const info = clean(container.text()).slice(0, 150) || "File langsung";
            const itemTitle = clean($(el).attr("title") || $(el).text()) || "Download";
            downloadLinks.push({ title: itemTitle, info, url: href });
          }
        }
        if (downloadLinks.length >= 10) return false;
      });

      // resolve maksimal 4 mirror pertama (hemat waktu)
      const downloads = [];
      for (const dl of downloadLinks.slice(0, 4)) {
        const direct = await resolveDirect(dl.url);
        downloads.push({ title: dl.title, info: dl.info, ...direct });
      }

      return Response.json({
        ok: true,
        detail: {
          title,
          url,
          thumbnail,
          author,
          date: dateMatch?.[2] || "Baru-baru ini",
          rating: ratingMatch ? `${ratingMatch[1]}/5.0` : null,
          total_downloads: dlCount?.[1] || null,
          total_comments: commCount?.[1] || null,
          description,
          screenshots,
          downloads,
        },
      });
    }

    /* ---- default: home/trending ringan ---- */
    const doc = await load("/");
    if (!doc) return Response.json({ ok: false, error: "Gagal menghubungi MCPELife" }, { status: 502 });
    const results = scrapeList(doc.$);
    return Response.json({
      ok: true,
      categories: [
        { name: "APK & Beta", endpoint: "/download/" },
        { name: "Mods", endpoint: "/mods/" },
        { name: "Maps", endpoint: "/maps/" },
        { name: "Textures", endpoint: "/textures/" },
        { name: "Shaders", endpoint: "/shaders/" },
        { name: "Skins", endpoint: "/skins/" },
        { name: "Seeds", endpoint: "/seeds/" },
        { name: "Launcher & Soft", endpoint: "/soft/" },
      ],
      total: results.length,
      results,
    });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses permintaan Minecraft" }, { status: 500 });
  }
}
