import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Cek profil username lintas platform — permintaan #18.
 * Masukkan username (tanpa @) → sistem memeriksa real-time di tiap platform,
 * lalu menampilkan akun mana saja yang aktif + variasi username populer.
 */

type Status = "registered" | "absent" | "unknown";

interface PlatformResult {
  platform: string;
  url: string;
  status: Status;
}

interface PlatformDef {
  name: string;
  build: (u: string) => string;
  /** cara cek: "json-ok" (200=ada, 404=tidak) atau "html-sniff" (cari penanda) */
  mode: "json-ok" | "html-sniff";
  /** penanda halaman tidak ditemukan (regex, html-sniff) */
  notFoundMark?: RegExp;
  /** penanda akun ada (opsional) */
  foundMark?: RegExp;
}

const PLATFORMS: PlatformDef[] = [
  {
    name: "TikTok",
    build: (u) => `https://www.tiktok.com/@${u}`,
    mode: "html-sniff",
    notFoundMark: /Couldn't find this account|Page Not Found|"statusCode":404|tiktok-404/i,
    foundMark: /"@type":"Person"|"author"|sigi/i,
  },
  {
    name: "Instagram",
    build: (u) => `https://www.instagram.com/${u}/`,
    mode: "html-sniff",
    notFoundMark: /Sorry, this page isn't available|Page Not Found|"statusCode":404/i,
    foundMark: /og:title|ProfileMeta|edge_owner_to_timeline_media/i,
  },
  {
    name: "YouTube",
    build: (u) => `https://www.youtube.com/@${u}`,
    mode: "html-sniff",
    notFoundMark: /404 Not Found|Sorry, we couldn|<title>404/i,
    foundMark: /canonicalBaseUrl|"channelMetadataEntity|og:url/i,
  },
  {
    name: "Twitter/X",
    build: (u) => `https://x.com/${u}`,
    mode: "html-sniff",
    notFoundMark: /This account doesn’t exist|page doesn’t exist|Sorry, that page/i,
    foundMark: /profile|@/i,
  },
  {
    name: "GitHub",
    build: (u) => `https://api.github.com/users/${u}`,
    mode: "json-ok",
  },
  {
    name: "Reddit",
    build: (u) => `https://www.reddit.com/user/${u}/about.json`,
    mode: "json-ok",
  },
  {
    name: "Telegram",
    build: (u) => `https://t.me/${u}`,
    mode: "html-sniff",
    notFoundMark: /tgme_page_not_found|If you have Telegram, you can view and join/i,
    // akun nyata punya blok foto + info tambahan; halaman "belum ada" tidak punya
    foundMark: /tgme_page_photo|tgme_page_extra|tgme_page_additional/i,
  },
  {
    name: "SoundCloud",
    build: (u) => `https://soundcloud.com/${u}`,
    mode: "html-sniff",
    notFoundMark: /We can’t find that|Page not found|404/i,
  },
  {
    name: "Pinterest",
    build: (u) => `https://www.pinterest.com/${u}/`,
    mode: "html-sniff",
    notFoundMark: /Sorry! We couldn't find|Page not found|404/i,
  },
  {
    name: "Threads",
    build: (u) => `https://www.threads.net/@${u}`,
    mode: "html-sniff",
    notFoundMark: /Sorry, this page isn't available|Page Not Found/i,
  },
  {
    name: "Twitch",
    build: (u) => `https://www.twitch.tv/${u}`,
    mode: "html-sniff",
    notFoundMark: /Sorry, the page you|does not exist|content unavailable/i,
  },
  {
    name: "Facebook",
    build: (u) => `https://www.facebook.com/${u}`,
    mode: "html-sniff",
    notFoundMark: /This content isn't available|Page Not Found/i,
  },
];

/** Platform utama untuk mode variasi (biar jumlah request terkendali). */
const CORE_PLATFORMS = ["TikTok", "Instagram", "YouTube", "Twitter/X", "GitHub"];

async function checkOne(p: PlatformDef, u: string): Promise<PlatformResult> {
  const url = p.build(u);
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "text/html,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(9000),
    });

    if (p.mode === "json-ok") {
      if (res.status === 200) return { platform: p.name, url: p.build(u).replace("api.github.com/users", "github.com"), status: "registered" };
      if (res.status === 404) return { platform: p.name, url: p.build(u).replace("api.github.com/users", "github.com"), status: "absent" };
      return { platform: p.name, url: p.build(u).replace("api.github.com/users", "github.com"), status: "unknown" };
    }

    // html-sniff
    if (res.status === 404 || res.status === 410) {
      return { platform: p.name, url, status: "absent" };
    }
    if (!res.ok && res.status !== 200) {
      return { platform: p.name, url, status: "unknown" };
    }
    const html = (await res.text()).slice(0, 400_000);
    if (p.notFoundMark?.test(html)) return { platform: p.name, url, status: "absent" };
    if (p.foundMark?.test(html)) return { platform: p.name, url, status: "registered" };
    return { platform: p.name, url, status: "unknown" };
  } catch {
    return { platform: p.name, url, status: "unknown" };
  }
}

/** Susun variasi username yang lebih BERAGAM & realistis (V2-new, keluhan #14).
 *  Sebelumnya template tetap (123, _official, .id…) membuat semua hasil tampak
 *  "pola berulang" (billy.id, asep.id, anjai.id…). Sekarang variasi dirotasi
 *  berdasarkan hash username — tiap nama dapat kombinasi berbeda, ditambah
 *  tahun lahir umum & gaya penulisan platform yang nyata dipakai orang. */
function variants(u: string): string[] {
  // hash sederhana → rotasi supaya 2 username berbeda dapat kombinasi berbeda
  let h = 0;
  for (const ch of u) h = (h * 31 + ch.charCodeAt(0)) >>> 0;

  const base = u.replace(/[._]/g, "");
  const dotted = u.replace(/_/g, ".");
  const years = ["07", "09", "14", "16", "99", "03", "11", "20"];
  const y1 = years[h % years.length];
  const y2 = years[(h >> 3) % years.length];

  const pool: string[] = [
    `${base}${y1}`,
    `${base}_${y1}`,
    `${base}.${y1}`,
    `${dotted}`,
    `${base}${y2}`,
    `the${base}`,
    `real${base}`,
    `${base}_official`,
    `${base}official`,
    `its${base}`,
    `${base}_id`,
    `${base}.id`,
    `${base}x`,
    `${base}${(h % 89) + 10}`,
    `im${base}`,
    `${base}_`,
    `${base}gg`,
    `${base}user`,
  ];

  // rotasi: mulai dari offset hash, ambil 8 variasi unik
  const out: string[] = [];
  const seen = new Set<string>([u]);
  for (let i = 0; i < pool.length && out.length < 8; i++) {
    const cand = pool[(i + h) % pool.length];
    if (!seen.has(cand) && /^[a-zA-Z0-9._]{2,30}$/.test(cand)) {
      seen.add(cand);
      out.push(cand);
    }
  }
  return out;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`usrchk:${ip}`, 10, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak pemeriksaan — tunggu sebentar" }, { status: 429 });
  }

  const raw = (req.nextUrl.searchParams.get("u") || "").trim().replace(/^@+/, "");
  const deep = req.nextUrl.searchParams.get("deep") === "1";

  if (!/^[a-zA-Z0-9._]{2,30}$/.test(raw)) {
    return Response.json(
      { ok: false, error: "Username hanya boleh huruf, angka, titik, dan garis bawah (2-30 karakter)" },
      { status: 400 }
    );
  }

  // cek username utama di semua platform (paralel)
  const main = await Promise.all(PLATFORMS.map((p) => checkOne(p, raw)));

  // mode variasi: cek variasi di platform inti — HANYA yang benar-benar
  // ditemukan yang dikembalikan (V2-new #14: "yang ketemu aja")
  let suggestions: Array<{ username: string; results: PlatformResult[]; foundCount: number }> = [];
  if (deep) {
    const vars = variants(raw);
    const checks = await Promise.all(
      vars.map(async (v) => {
        const defs = PLATFORMS.filter((p) => CORE_PLATFORMS.includes(p.name));
        const results = await Promise.all(defs.map((p) => checkOne(p, v)));
        return { username: v, results, foundCount: results.filter((r) => r.status === "registered").length };
      })
    );
    suggestions = checks.filter((c) => c.foundCount > 0);
  }

  return Response.json({
    ok: true,
    username: raw,
    results: main,
    foundCount: main.filter((r) => r.status === "registered").length,
    suggestions,
  });
}
