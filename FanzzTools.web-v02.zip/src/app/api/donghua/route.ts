import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP, DONGHUA_MAINTENANCE } from "@/lib/constants";
import * as cheerio from "cheerio";

export const runtime = "nodejs";

/**
 * Nonton Donghua — topdonghua.com (anime China sub indo).
 * Endpoint: ?home | ?q= | ?url= (detail+episode) | ?watch= (video dailymotion)
 *
 * zuperupdt #16 — NONAKTIFKAN DONGHUA ("sedang dalam pemeliharaan"):
 * LAYAR 1 (server): seluruh endpoint menjawab { maintenance: true } — klien
 * mana pun (termasuk yang menyimpan cache lama) diarahkan ke layar
 * pemeliharaan. Sistem/scrapper TIDAK dihapus — cukup ubah konstanta
 * DONGHUA_MAINTENANCE jadi false di src/lib/constants.ts untuk mengaktifkan
 * ulang (atau set env FANZZ_DONGHUA_ENABLED=1).
 */

const BASE = "https://topdonghua.com";

async function fetchHtml(url: string): Promise<string | null> {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

interface DhCard {
  judul: string;
  url: string;
}

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000;

/** V2-new: katalog judul lokal — halaman ?s= milik topdonghua TIDAK berfungsi
 *  secara server-side (selalu mengembalikan beranda), jadi pencarian dilakukan
 *  pada katalog yang diambil dari /all-anime (+halamannya), disimpan 1 jam. */
interface CatalogEntry {
  judul: string;
  url: string;
}
const CATALOG_CACHE = { at: 0, list: [] as CatalogEntry[] };
const CATALOG_TTL = 60 * 60 * 1000;

function titleFromSlug(slug: string): string {
  return slug
    .replace(/-episode-\d+$/i, "")
    .replace(/-/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

async function getCatalog(): Promise<CatalogEntry[]> {
  if (Date.now() - CATALOG_CACHE.at < CATALOG_TTL && CATALOG_CACHE.list.length) return CATALOG_CACHE.list;
  const list: CatalogEntry[] = [];
  const seen = new Set<string>();
  // ambil beranda + 3 halaman katalog (± 96 judul) — cukup ringan, di-cache 1 jam
  const pages = [`${BASE}/`, `${BASE}/all-anime`, `${BASE}/all-anime/page/2`, `${BASE}/all-anime/page/3`];
  for (const p of pages) {
    const html = await fetchHtml(p);
    if (!html) continue;
    for (const m of html.matchAll(/href="(?:https:\/\/topdonghua\.com\/)?\/?(watch\/[a-z0-9-]+)"/g)) {
      const href = m[1];
      const slug = href.replace(/^watch\//, "");
      if (seen.has(slug)) continue;
      seen.add(slug);
      list.push({ judul: titleFromSlug(slug), url: `${BASE}/watch/${slug}` });
    }
  }
  if (list.length) {
    CATALOG_CACHE.at = Date.now();
    CATALOG_CACHE.list = list;
  }
  return list;
}

function localSearch(list: CatalogEntry[], q: string): CatalogEntry[] {
  const needle = q.toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  if (!needle) return [];
  const scored = list
    .map((c) => {
      const hay = c.judul.toLowerCase();
      let score = 0;
      if (hay === needle) score = 100;
      else if (hay.startsWith(needle)) score = 80;
      else if (hay.includes(needle)) score = 60;
      else {
        // kata-per-kata
        const words = needle.split(" ").filter(Boolean);
        const hit = words.filter((w) => hay.includes(w)).length;
        if (hit) score = 30 + (hit / words.length) * 25;
      }
      return { c, score };
    })
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score);
  return scored.slice(0, 24).map((x) => x.c);
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  /* zuperupdt #16 LAYAR 1 (server): kunci pemeliharaan — semua endpoint mati.
   * Bisa dimatikan lewat env FANZZ_DONGHUA_ENABLED=1 tanpa rebuild kode. */
  const enabled = process.env.FANZZ_DONGHUA_ENABLED === "1" || DONGHUA_MAINTENANCE === false;
  if (!enabled) {
    return Response.json(
      {
        ok: false,
        maintenance: true,
        error: "Fitur Donghua sedang dalam pemeliharaan. Silakan coba lagi nanti.",
      },
      { status: 503 }
    );
  }

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`dh:${ip}`, 25, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request, tunggu sebentar" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;
  const ckey = sp.toString();

  try {
    const hit = CACHE.get(ckey);
    if (hit && Date.now() - hit.at < TTL) {
      return Response.json({ ok: true, ...(hit.data as object) });
    }

    let payload: Record<string, unknown> | null = null;

    /* ---- HOME: hot / update / ongoing / upcoming / completed ---- */
    if (sp.get("home") !== null) {
      const html = await fetchHtml(BASE);
      if (!html) payload = null;
      else {
        const $ = cheerio.load(html);
        const sections: Record<string, DhCard[]> = {
          hot: [], update: [], ongoing: [], upcoming: [], completed: [],
        };
        const map: Array<[string, RegExp]> = [
          ["hot", /hot series/i], ["update", /recently|update/i], ["ongoing", /ongoing/i],
          ["upcoming", /upcoming/i], ["completed", /completed/i],
        ];
        $("h2").each((_, el) => {
          const st = $(el).text().trim();
          const key = map.find(([, re]) => re.test(st))?.[0];
          if (!key) return;
          let container = $(el).parent();
          for (let i = 0; i < 5; i++) {
            const links = container.find("a[href*='watch/'], a[href*='anime/']");
            if (links.length > 0) break;
            container = container.parent();
          }
          const seen = new Set<string>();
          container.find("a[href*='watch/'], a[href*='anime/']").each((__, linkEl) => {
            const href = $(linkEl).attr("href") || "";
            const text = $(linkEl).text().replace(/\s+/g, " ").trim();
            if (!href || text.length < 3 || seen.has(href)) return;
            seen.add(href);
            if (sections[key].length >= 20) return;
            sections[key].push({
              judul: text.slice(0, 100),
              url: href.startsWith("http") ? href : BASE + "/" + href.replace(/^\//, ""),
            });
          });
        });
        payload = { sections };
      }
    }
    /* ---- SEARCH (V2-new: katalog lokal — ?s= milik sumber tidak berfungsi server-side) ---- */
    else if (sp.get("q")) {
      const q = sp.get("q")!.slice(0, 80);
      const list = await getCatalog();
      const results = localSearch(list, q);
      payload = { query: q, results, totalCatalog: list.length };
    }
    /* ---- DETAIL (episode list) ---- */
    else if (sp.get("url")) {
      const url = sp.get("url")!;
      if (!url.includes("topdonghua")) {
        return Response.json({ ok: false, error: "Hanya halaman topdonghua yang diizinkan" }, { status: 400 });
      }
      const html = await fetchHtml(url);
      if (!html) payload = null;
      else {
        const $ = cheerio.load(html);
        const judul = $("h1").first().text().replace(/\s+/g, " ").trim() || $("title").text().trim();
        const sinopsis = $(".description, .synopsis, [class*='synopsis'], [class*='description']")
          .first().text().replace(/\s+/g, " ").trim() || null;
        const genres: string[] = [];
        $("a[href*='genre']").each((_, el) => {
          const t = $(el).text().trim();
          if (t && t.length < 30 && !genres.includes(t) && !/genre list/i.test(t)) genres.push(t);
        });
        const episodes: DhCard[] = [];
        const seen = new Set<string>();
        $("a[href*='watch/']").each((_, el) => {
          const href = $(el).attr("href") || "";
          const text = $(el).text().replace(/\s+/g, " ").trim();
          if (!href || !text || seen.has(href)) return;
          seen.add(href);
          episodes.push({
            judul: text.slice(0, 80),
            url: href.startsWith("http") ? href : BASE + "/" + href.replace(/^\//, ""),
          });
        });
        payload = { judul, sinopsis, genres, totalEpisodes: episodes.length, episodes };
      }
    }
    /* ---- WATCH (ambil video dailymotion) ---- */
    else if (sp.get("watch")) {
      const url = sp.get("watch")!;
      if (!url.includes("topdonghua")) {
        return Response.json({ ok: false, error: "Hanya halaman topdonghua yang diizinkan" }, { status: 400 });
      }
      const html = await fetchHtml(url);
      if (!html) payload = null;
      else {
        const $ = cheerio.load(html);
        const title = $("title").text().replace(/\s+/g, " ").trim();
        const locked = /window\.__episodeLocked\s*=\s*true/.test(html);
        const firstServer = html.match(/window\.firstServerUrl\s*=\s*["']([^"']+)["']/)?.[1] || null;

        let dmId: string | null = null;
        if (firstServer) dmId = firstServer.match(/video=([a-zA-Z0-9]+)/)?.[1] || null;
        if (!dmId) dmId = firstServer?.match(/\/video\/([a-zA-Z0-9]+)/)?.[1] || null;

        // V2-new: kumpulkan episode lain (navigasi next/prev)
        const episodeLinks: DhCard[] = [];
        const seen = new Set<string>();
        $("a[href*='episode'], a[href*='watch/']").each((_, el) => {
          const href = $(el).attr("href") || "";
          const text = $(el).text().replace(/\s+/g, " ").trim();
          if (!href || !text || seen.has(href)) return;
          seen.add(href);
          episodeLinks.push({
            judul: text.slice(0, 60),
            url: href.startsWith("http") ? href : BASE + "/" + href.replace(/^\//, ""),
          });
        });

        // V2-new (perbaikan "gagal terus"): pakai URL pemutar ASLI yang dipakai
        // situs (geo.dailymotion.com player) — rekonstruksi www.dailymotion.com
        // dengan ID ter-mask sering ditolak pemutar. Fallback berurutan.
        const embedCandidates: string[] = [];
        if (firstServer) embedCandidates.push(firstServer);
        if (dmId) {
          embedCandidates.push(`https://www.dailymotion.com/embed/video/${dmId}?autoplay=1`);
          embedCandidates.push(`https://geo.dailymotion.com/player/x110cm.html?video=${dmId}`);
        }

        payload = {
          judul: title,
          locked,
          video: embedCandidates.length
            ? {
                platform: dmId ? "dailymotion" : "embed",
                videoId: dmId || undefined,
                embedUrl: embedCandidates[0],
                /** alternatif pemutar — dipakai view bila yang utama gagal */
                altEmbeds: embedCandidates.slice(1),
              }
            : null,
          episodeLinks: episodeLinks.slice(0, 40),
        };
      }
    } else {
      return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
    }

    if (!payload) {
      return Response.json({ ok: false, error: "Sumber donghua lagi bermasalah — coba lagi" }, { status: 502 });
    }
    CACHE.set(ckey, { at: Date.now(), data: payload });
    return Response.json({ ok: true, ...payload });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses" }, { status: 500 });
  }
}
