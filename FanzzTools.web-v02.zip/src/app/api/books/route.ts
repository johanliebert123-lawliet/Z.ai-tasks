import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Pustaka buku — jutaan buku dari arsip dunia (Internet Archive) sampai
 * koleksi modern (Open Library). Baca langsung via reader in-app.
 *
 *  ?q=...&page=1  → cari judul/penulis/topik
 *  (tanpa q)       → koleksi populer (paling banyak diunduh)
 */

export interface BookItem {
  id: string;
  title: string;
  creator: string;
  year: string;
  cover: string | null;
  provider: "archive" | "openlibrary" | "gbooks";
  readUrl: string | null;
  infoUrl: string;
  downloads?: number;
}

const g = globalThis as unknown as { __fanzzBooksCache?: Map<string, { items: BookItem[]; at: number }> };
if (!g.__fanzzBooksCache) g.__fanzzBooksCache = new Map();
const cache = g.__fanzzBooksCache;

function decode(s: string): string {
  return s
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&nbsp;/g, " ")
    .trim();
}

async function searchArchive(q: string | null, page: number): Promise<BookItem[]> {
  const start = (page - 1) * 24;
  const query = q
    ? `(${q}) AND mediatype:texts`
    : "mediatype:texts AND NOT collection:(usenet-*)";
  const sort = q ? "" : "-downloads";
  const url =
    `https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}` +
    `&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=downloads` +
    `&sort%5B%5D=${encodeURIComponent(sort)}&rows=24&start=${start}&page=1&output=json&scope=all`;
  const r = await fetch(url, {
    headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok) return [];
  const d = await r.json();
  const docs = (d?.response?.docs || []) as Array<Record<string, unknown>>;
  return docs
    .filter((doc) => typeof doc.identifier === "string")
    .map((doc) => {
      const id = String(doc.identifier);
      const titleRaw = doc.title;
      const title = Array.isArray(titleRaw) ? String(titleRaw[0]) : String(titleRaw || id);
      const creatorRaw = doc.creator;
      const creator = Array.isArray(creatorRaw) ? String(creatorRaw[0]) : String(creatorRaw || "");
      const year = String(doc.year || "").slice(0, 4);
      return {
        id,
        title: decode(title),
        creator: decode(creator),
        year,
        cover: `https://archive.org/services/img/${id}`,
        provider: "archive" as const,
        readUrl: `https://archive.org/embed/${id}`,
        infoUrl: `https://archive.org/details/${id}`,
        downloads: Number(doc.downloads) || undefined,
      };
    });
}

async function searchOpenLibrary(q: string, page: number): Promise<BookItem[]> {
  const r = await fetch(
    `https://openlibrary.org/search.json?q=${encodeURIComponent(q)}&page=${page}&limit=24&fields=key,title,author_name,first_publish_year,cover_i,ia,has_fulltext`,
    {
      headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    }
  );
  if (!r.ok) return [];
  const d = await r.json();
  const docs = (d?.docs || []) as Array<Record<string, unknown>>;
  return docs
    .filter((doc) => typeof doc.key === "string")
    .map((doc) => {
      const key = String(doc.key).replace(/^\/works\//, "");
      const ia = Array.isArray(doc.ia) ? String(doc.ia[0] || "") : String(doc.ia || "");
      return {
        id: `ol-${key}`,
        title: String(doc.title || "Tanpa judul"),
        creator: Array.isArray(doc.author_name) ? String(doc.author_name[0] || "") : "",
        year: String(doc.first_publish_year || "").slice(0, 4),
        cover: doc.cover_i ? `https://covers.openlibrary.org/b/id/${doc.cover_i}-M.jpg` : null,
        provider: "openlibrary" as const,
        readUrl: ia ? `https://archive.org/embed/${ia}` : null,
        infoUrl: `https://openlibrary.org${doc.key}`,
      };
    });
}

/** Google Books — koleksi modern sampai terbaru (preview/pinjam di halaman resmi). */
async function searchGoogleBooks(q: string, page: number): Promise<BookItem[]> {
  const start = (page - 1) * 12;
  const r = await fetch(
    `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(q)}&startIndex=${start}&maxResults=12&country=US`,
    {
      headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    }
  );
  if (!r.ok) return [];
  const d = await r.json();
  const items = (d?.items || []) as Array<Record<string, unknown>>;
  return items
    .filter((it) => it?.id && (it as { volumeInfo?: unknown }).volumeInfo)
    .map((it) => {
      const v = (it.volumeInfo || {}) as Record<string, unknown>;
      const imgs = (v.imageLinks || {}) as Record<string, string>;
      const cover = imgs.thumbnail || imgs.smallThumbnail || null;
      const authors = Array.isArray(v.authors) ? String(v.authors[0] || "") : "";
      return {
        id: `gb-${String(it.id)}`,
        title: String(v.title || "Tanpa judul"),
        creator: authors,
        year: String(v.publishedDate || "").slice(0, 4),
        cover: cover ? cover.replace(/^http:/, "https:").replace("&edge=curl", "") : null,
        provider: "gbooks" as const,
        readUrl: null, // reader Google gak bisa di-iframe — buka di halaman resmi
        infoUrl: String(v.infoLink || `https://books.google.com/books?id=${String(it.id)}`),
      };
    });
}

/** Cari padanan di Internet Archive berdasarkan judul+penulis — dipakai untuk
 *  buku Google Books/Open Library yang tidak punya readUrl sendiri. */
async function lookupArchive(title: string, creator: string): Promise<BookItem | null> {
  try {
    const q = creator
      ? `title:(${title}) AND creator:(${creator}) AND mediatype:texts`
      : `title:(${title}) AND mediatype:texts`;
    const url =
      `https://archive.org/advancedsearch.php?q=${encodeURIComponent(q)}` +
      `&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=creator&fl%5B%5D=year&fl%5B%5D=downloads` +
      `&rows=3&page=1&output=json&scope=all`;
    const r = await fetch(url, {
      headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
    if (!r.ok) return null;
    const d = await r.json();
    const docs = (d?.response?.docs || []) as Array<Record<string, unknown>>;
    for (const doc of docs) {
      const id = String(doc.identifier || "");
      if (!id) continue;
      const t = Array.isArray(doc.title) ? String(doc.title[0]) : String(doc.title || title);
      // validasi kasar: minimal 40% kata kunci judul cocok
      const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").split(/\s+/).filter((w) => w.length > 2);
      const want = new Set(norm(title));
      const have = norm(t);
      const match = want.size ? want.size - [...want].filter((w) => !have.includes(w)).length : 1;
      if (match / Math.max(1, want.size) < 0.4) continue;
      return {
        id,
        title: t,
        creator: Array.isArray(doc.creator) ? String(doc.creator[0] || "") : String(doc.creator || creator || ""),
        year: String(doc.year || "").slice(0, 4),
        cover: `https://archive.org/services/img/${id}`,
        provider: "archive",
        readUrl: `https://archive.org/embed/${id}`,
        infoUrl: `https://archive.org/details/${id}`,
        downloads: Number(doc.downloads) || undefined,
      };
    }
    return null;
  } catch {
    return null;
  }
}

/** Buku populer kurasi — dipakai bila Open Library & arsip tidak terjangkau
 *  (jaringan datacenter tertentu). Klik kartu = cari versi terbaca otomatis. */
const CURATED_POPULAR: Array<{ title: string; creator: string; year: string }> = [
  { title: "Laskar Pelangi", creator: "Andrea Hirata", year: "2005" },
  { title: "Bumi Manusia", creator: "Pramoedya Ananta Toer", year: "1980" },
  { title: "Atomic Habits", creator: "James Clear", year: "2018" },
  { title: "Rich Dad Poor Dad", creator: "Robert T. Kiyosaki", year: "1997" },
  { title: "The Psychology of Money", creator: "Morgan Housel", year: "2020" },
  { title: "Filosofi Teras", creator: "Henry Manampiring", year: "2018" },
  { title: "Harry Potter and the Philosopher's Stone", creator: "J. K. Rowling", year: "1997" },
  { title: "The Little Prince", creator: "Antoine de Saint-Exupéry", year: "1943" },
  { title: "1984", creator: "George Orwell", year: "1949" },
  { title: "Animal Farm", creator: "George Orwell", year: "1945" },
  { title: "To Kill a Mockingbird", creator: "Harper Lee", year: "1960" },
  { title: "The Great Gatsby", creator: "F. Scott Fitzgerald", year: "1925" },
  { title: "Pride and Prejudice", creator: "Jane Austen", year: "1813" },
  { title: "Frankenstein", creator: "Mary Shelley", year: "1818" },
  { title: "Dracula", creator: "Bram Stoker", year: "1897" },
  { title: "The Adventures of Sherlock Holmes", creator: "Arthur Conan Doyle", year: "1892" },
  { title: "Tenggelamnya Kapal Van Der Wijck", creator: "Hamka", year: "1938" },
  { title: "Ronggeng Dukuh Paruk", creator: "Ahmad Tohari", year: "1982" },
  { title: "Sang Pemimpi", creator: "Andrea Hirata", year: "2006" },
  { title: "Perahu Kertas", creator: "Dee Lestari", year: "2009" },
  { title: "Negeri 5 Menara", creator: "Ahmad Fuadi", year: "2009" },
  { title: "Dilan 1990", creator: "Pidi Baiq", year: "2014" },
  { title: "The Subtle Art of Not Giving a F*ck", creator: "Mark Manson", year: "2016" },
  { title: "Sapiens: A Brief History of Humankind", creator: "Yuval Noah Harari", year: "2011" },
  { title: "Thinking, Fast and Slow", creator: "Daniel Kahneman", year: "2011" },
  { title: "Ikigai: The Japanese Secret to a Long and Happy Life", creator: "Héctor García", year: "2016" },
  { title: "Hujan Bulan Juni", creator: "Sapardi Djoko Damono", year: "1994" },
  { title: "Aku ingin menciummu sekali saja", creator: "Sapardi Djoko Damono", year: "1989" },
];

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`books:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  /* ---------- V2.11 (#34): seksi "Sedang Populer" ---------- */
  if (req.nextUrl.searchParams.get("popular") !== null) {
    const pCache = cache.get("popular:v2");
    if (pCache && Date.now() - pCache.at < 30 * 60 * 1000) {
      return Response.json({ ok: true, items: pCache.items, cached: true });
    }
    // 1) Open Library tren mingguan (jujur: hanya tren pembaca Open Library)
    let items: BookItem[] = [];
    try {
      const r = await fetch("https://openlibrary.org/trending/weekly.json?limit=24", {
        headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
        signal: AbortSignal.timeout(12000),
      });
      if (r.ok) {
        const d = (await r.json()) as { works?: Array<Record<string, unknown>> };
        items = (d?.works || []).slice(0, 24).map((w, i) => {
          const key = String(w.key || "").replace(/^\/works\//, "");
          const cov = w.cover_i ? `https://covers.openlibrary.org/b/id/${w.cover_i}-M.jpg` : null;
          return {
            id: `olt-${key || i}`,
            title: String(w.title || "Tanpa judul"),
            creator: Array.isArray(w.author_name) ? String(w.author_name[0] || "") : "",
            year: String(w.first_publish_year || "").slice(0, 4),
            cover: cov,
            provider: "openlibrary" as const,
            readUrl: null,
            infoUrl: key ? `https://openlibrary.org/works/${key}` : "https://openlibrary.org",
          };
        }).filter((b) => b.title !== "Tanpa judul");
      }
    } catch {
      /* lanjut fallback */
    }
    // 2) fallback: arsip terbanyak diunduh
    if (!items.length) {
      try {
        items = await searchArchive(null, 1);
        items = items.filter((b) => b.readUrl).slice(0, 24);
      } catch {
        items = []; // jaringan ke arsip tidak terjangkau → lanjut kurasi
      }
    }
    // 3) fallback terakhir: daftar kurasi (selalu tampil — judul populer abadi)
    if (!items.length) {
      items = CURATED_POPULAR.map((b, i) => ({
        id: `cur-${i}`,
        title: b.title,
        creator: b.creator,
        year: b.year,
        cover: null,
        provider: "openlibrary" as const,
        readUrl: null,
        infoUrl: "",
      }));
    }
    cache.set("popular:v2", { items, at: Date.now() });
    return Response.json({ ok: true, items });
  }

  // mode pencarian cadangan: buku tanpa readUrl dicari padanannya di Internet Archive
  const lookupTitle = (req.nextUrl.searchParams.get("lookup") || "").trim().slice(0, 120);
  if (lookupTitle) {
    const creator = (req.nextUrl.searchParams.get("creator") || "").trim().slice(0, 80);
    const found = await lookupArchive(lookupTitle, creator);
    if (found) {
      return Response.json({ ok: true, found });
    }
    return Response.json(
      { ok: false, error: "Versi lengkap buku ini tidak ditemukan di arsip publik." },
      { status: 404 }
    );
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 120);
  const page = Math.min(Math.max(Number(req.nextUrl.searchParams.get("page")) || 1, 1), 20);
  const cacheKey = `v1:${q}:${page}`;

  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.at < 10 * 60 * 1000) {
    return Response.json({ ok: true, items: cached.items, cached: true });
  }

  // arsip dulu (koleksi klasik sampai modern), open library + google books pelengkap
  const results = await Promise.allSettled([
    searchArchive(q || null, page),
    q ? searchOpenLibrary(q, page) : Promise.resolve([] as BookItem[]),
    q ? searchGoogleBooks(q, page) : Promise.resolve([] as BookItem[]),
  ]);

  let items: BookItem[] = [];
  if (results[0].status === "fulfilled" && results[0].value.length) {
    items.push(...results[0].value);
  }
  const seen = new Set(items.map((b) => b.title.toLowerCase()));
  const addMore = (idx: number) => {
    if (results[idx].status !== "fulfilled") return;
    for (const b of results[idx].value) {
      if (!seen.has(b.title.toLowerCase())) {
        items.push(b);
        seen.add(b.title.toLowerCase());
      }
    }
  };
  addMore(1);
  addMore(2);
  items = items.slice(0, 36);

  // kalau semua sumber gagal (misal jaringan blokir) — jujur kasih tau
  if (!items.length) {
    return Response.json({
      ok: false,
      error: "Sumber buku lagi gak bisa dihubungi. Coba lagi sebentar lagi ya.",
    }, { status: 502 });
  }

  cache.set(cacheKey, { items, at: Date.now() });
  return Response.json({ ok: true, items, page });
}
