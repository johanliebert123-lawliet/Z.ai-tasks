import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { TMDB_BASE, TMDB_KEY, UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

interface TmdbItem {
  id: number;
  title?: string;
  name?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  vote_average?: number;
  release_date?: string;
  first_air_date?: string;
  media_type?: string;
  overview?: string;
}

const CACHE_TTL = 5 * 60 * 1000; // 5 menit
const g = globalThis as unknown as { __fanzzHomeCache?: { at: number; data: unknown } };

function mapItem(it: TmdbItem, forceType?: string) {
  return {
    id: it.id,
    title: it.title || it.name || "Tanpa Judul",
    type: forceType || it.media_type || (it.first_air_date ? "tv" : "movie"),
    poster: it.poster_path
      ? `https://image.tmdb.org/t/p/w342${it.poster_path}`
      : null,
    rating: it.vote_average ? Math.round(it.vote_average * 10) / 10 : 0,
    year: (it.release_date || it.first_air_date || "").slice(0, 4),
    overview: it.overview || "",
  };
}

export async function GET(_req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = _req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`home:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request, sabar ya" }, { status: 429 });
  }

  const cached = g.__fanzzHomeCache;
  if (cached && Date.now() - cached.at < CACHE_TTL) {
    return Response.json(cached.data);
  }

  async function tmdb(path: string) {
    const res = await fetch(`${TMDB_BASE}${path}${path.includes("?") ? "&" : "?"}api_key=${TMDB_KEY}`, {
      headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
      next: { revalidate: 300 },
    });
    if (!res.ok) throw new Error(`TMDB ${res.status}`);
    return res.json();
  }

  try {
    const [trendingMovies, trendingTv, topMovies, topTv, upcoming] =
      await Promise.all([
        tmdb("/trending/movie/week"),
        tmdb("/trending/tv/week"),
        tmdb("/movie/top_rated"),
        tmdb("/tv/top_rated"),
        tmdb("/movie/upcoming"),
      ]);

    const data = {
      ok: true,
      trending: [
        ...(trendingMovies.results || []).slice(0, 18).map((i: TmdbItem) => mapItem(i, "movie")),
        ...(trendingTv.results || []).slice(0, 10).map((i: TmdbItem) => mapItem(i, "tv")),
      ],
      topMovies: (topMovies.results || []).slice(0, 18).map((i: TmdbItem) => mapItem(i, "movie")),
      topSeries: (topTv.results || []).slice(0, 18).map((i: TmdbItem) => mapItem(i, "tv")),
      upcoming: (upcoming.results || []).slice(0, 18).map((i: TmdbItem) => mapItem(i, "movie")),
    };

    g.__fanzzHomeCache = { at: Date.now(), data };
    return Response.json(data);
  } catch (e) {
    return Response.json(
      {
        ok: false,
        error:
          e instanceof Error
            ? `Gagal ambil data film: ${e.message}`
            : "Gagal ambil data film",
      },
      { status: 502 }
    );
  }
}
