import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { TMDB_BASE, TMDB_KEY, UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`search:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 80);
  const page = Math.max(1, Math.min(500, Number(req.nextUrl.searchParams.get("page")) || 1));
  if (q.length < 2) {
    return Response.json({ ok: true, results: [], total_pages: 0, page });
  }

  try {
    const res = await fetch(
      `${TMDB_BASE}/search/multi?api_key=${TMDB_KEY}&query=${encodeURIComponent(q)}&page=${page}&include_adult=false&language=id-ID`,
      {
        headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
        signal: AbortSignal.timeout(15000),
        next: { revalidate: 120 },
      }
    );
    if (!res.ok) throw new Error(`TMDB ${res.status}`);
    const data = await res.json();

    const results = (data.results || [])
      .filter((r: { media_type?: string }) => r.media_type !== "person")
      .map(
        (r: {
          id: number;
          title?: string;
          name?: string;
          poster_path?: string | null;
          vote_average?: number;
          release_date?: string;
          first_air_date?: string;
          media_type?: string;
          overview?: string;
        }) => ({
          id: r.id,
          title: r.title || r.name || "Tanpa Judul",
          type: r.media_type || (r.first_air_date ? "tv" : "movie"),
          poster: r.poster_path
            ? `https://image.tmdb.org/t/p/w342${r.poster_path}`
            : null,
          rating: r.vote_average ? Math.round(r.vote_average * 10) / 10 : 0,
          year: (r.release_date || r.first_air_date || "").slice(0, 4),
          overview: (r.overview || "").slice(0, 300),
        })
      );

    return Response.json({
      ok: true,
      results,
      total_pages: Math.min(data.total_pages || 1, 50),
      page: data.page || page,
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Pencarian gagal" },
      { status: 502 }
    );
  }
}
