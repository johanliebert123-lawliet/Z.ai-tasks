import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { UA_MOBILE, TMDB_KEY, TMDB_BASE, TMDB_IMG } from "@/lib/constants";

export const runtime = "nodejs";

/** Cache IDLIX 30 menit — situsnya agresif nge-block request beruntun (Cloudflare). */
let cache: { at: number; data: unknown } | null = null;
const CACHE_TTL = 30 * 60 * 1000;
const IDLIX_BASE = process.env.IDLIX_BASE || "https://z2.idlixku.com";

interface IdlixItem {
  title: string;
  slug: string;
  posterPath?: string;
  releaseDate?: string;
  quality?: string;
  voteAverage?: string;
}

interface MappedItem {
  id: number;
  title: string;
  type: "movie" | "tv";
  poster: string | null;
  year: string;
  rating: number;
  quality?: string;
}

/** Cari TMDB id dari judul (movie dulu, lalu tv). */
async function resolveTmdb(title: string, year?: string): Promise<MappedItem | null> {
  const yearQ = year ? `&year=${year}` : "";
  const tryOne = async (kind: "movie" | "tv") => {
    try {
      const res = await fetch(
        `${TMDB_BASE}/search/${kind}?api_key=${TMDB_KEY}&query=${encodeURIComponent(title)}${kind === "tv" ? "&first_air_date_year=" + (year || "") : yearQ}&language=id-ID&page=1`,
        { signal: AbortSignal.timeout(8000) }
      );
      if (!res.ok) return null;
      const d = await res.json();
      const hit = (d.results || [])[0];
      if (!hit) return null;
      return {
        id: hit.id as number,
        title: (hit.title || hit.name || title) as string,
        type: kind,
        poster: hit.poster_path ? `${TMDB_IMG}/w300${hit.poster_path}` : null,
        year: String((hit.release_date || hit.first_air_date || "").slice(0, 4) || year || ""),
        rating: Number(hit.vote_average || 0),
      };
    } catch {
      return null;
    }
  };
  const m = await tryOne("movie");
  if (m) return m;
  return tryOne("tv");
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  /* zuperupdt #5: rate limit (celah audit — sebelumnya tanpa batas) */
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`idlix:${ip}`, 12, 60 * 1000).ok) return tooManyResponse();

  if (cache && Date.now() - cache.at < CACHE_TTL) {
    return Response.json({ ok: true, cached: true, items: cache.data });
  }

  try {
    let d: { data?: IdlixItem[] } | null = null;
    // 2 percobaan (kadang CF challenge hanya sesaat)
    for (let attempt = 0; attempt < 2 && !d; attempt++) {
      try {
        const res = await fetch(`${IDLIX_BASE}/api/movies?page=1`, {
          headers: {
            "User-Agent": UA_MOBILE,
            Accept: "application/json",
            Referer: `${IDLIX_BASE}/`,
            "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
          },
          signal: AbortSignal.timeout(15000),
          cache: "no-store",
        });
        const ct = (res.headers.get("content-type") || "").toLowerCase();
        if (!res.ok || (ct && !ct.includes("json"))) continue;
        const text = await res.text();
        if (text.trimStart().startsWith("<")) continue;
        d = JSON.parse(text) as { data?: IdlixItem[] };
      } catch {
        /* coba lagi */
      }
    }
    if (!d) throw new Error("idlix_blocked");
    const list = (d.data || []).slice(0, 14);

    const mapped = await Promise.all(
      list.map(async (it) => {
        const year = (it.releaseDate || "").slice(0, 4);
        const tm = await resolveTmdb(it.title, year);
        if (tm) return { ...tm, quality: it.quality };
        return {
          id: 0,
          title: it.title,
          type: "movie" as const,
          poster: it.posterPath ? `${TMDB_IMG}/w300${it.posterPath}` : null,
          year,
          rating: Number(parseFloat(it.voteAverage || "0")),
          quality: it.quality,
        };
      })
    );

    const items = mapped.filter((m) => m.id !== 0);
    cache = { at: Date.now(), data: items };
    return Response.json({ ok: true, cached: false, items });
  } catch {
    return Response.json(
      { ok: false, error: "Sumber IDLIX sedang sibuk (Cloudflare). Coba lagi nanti.", items: [] },
      { status: 202 }
    );
  }
}
