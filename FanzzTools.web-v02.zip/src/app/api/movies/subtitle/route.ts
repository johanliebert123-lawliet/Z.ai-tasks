import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { TMDB_KEY, TMDB_BASE, UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Subtitle film → file WebVTT buat dipasang ke player (param sub_file vidlink).
 *
 * Rantai: TMDB id → detail (judul + tahun) → subtitlecat.com search →
 * scan halaman subtitle → unduh .srt bahasa yang diminta (sudah ada versinya)
 * → konversi ke WebVTT → serve (CORS *).
 *
 * V0.01 (permintaan #8b & #9): SEMUA kode bahasa ISO 639-1 didukung
 * (id, en, ar, es, fr, de, ja, ko, pt, ru, th, tr, vi, zh, dll).
 * CC AI: bila subtitle bahasa target tidak ada, subtitle cadangan (en/id)
 * diterjemahkan AI ke bahasa target apa pun — default Indonesia.
 */

/** Whitelist kode bahasa yang didukung subtitlecat. */
const LANG_CODES = new Set([
  "id", "en", "ar", "es", "fr", "de", "it", "pt", "ru", "ja", "ko",
  "zh", "th", "tr", "vi", "nl", "pl", "sv", "da", "fi", "no", "cs",
  "el", "he", "hi", "hu", "id", "ms", "ro", "sk", "sl", "sr", "uk",
  "bg", "hr", "lt", "lv", "et", "is", "sq", "mk", "bn", "ta", "te",
  "fa", "ur", "sw", "af", "ca", "eu", "gl", "ka", "hy", "az", "kk",
  "uz", "mn", "my", "km", "lo", "tl", "bn",
]);

/** Nama bahasa untuk prompt AI + label. */
const LANG_NAMES: Record<string, string> = {
  id: "Bahasa Indonesia", en: "English", ar: "Arabic", es: "Spanish", fr: "French",
  de: "German", it: "Italian", pt: "Portuguese", ru: "Russian", ja: "Japanese",
  ko: "Korean", zh: "Chinese", th: "Thai", tr: "Turkish", vi: "Vietnamese",
  nl: "Dutch", pl: "Polish", ms: "Malay", tl: "Filipino", hi: "Hindi",
  he: "Hebrew", fa: "Persian", ur: "Urdu", bn: "Bengali", ta: "Tamil",
  uk: "Ukrainian", el: "Greek", sv: "Swedish", da: "Danish", fi: "Finnish",
  no: "Norwegian", cs: "Czech", ro: "Romanian", hu: "Hungarian", sk: "Slovak",
};

interface SubCacheEntry {
  vtt: string;
  found: number;
}

const g = globalThis as unknown as {
  __fanzzSubCache?: Map<string, SubCacheEntry>;
};
if (!g.__fanzzSubCache) g.__fanzzSubCache = new Map();
const subCache = g.__fanzzSubCache;

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Detail judul dari TMDB (cache 1 jam via fetch cache). */
async function getTitle(
  tmdbId: number,
  type: "movie" | "tv"
): Promise<{ title: string; year: string } | null> {
  try {
    const r = await fetch(`${TMDB_BASE}/${type}/${tmdbId}?api_key=${TMDB_KEY}&language=en-US`, {
      signal: AbortSignal.timeout(10000),
      next: { revalidate: 3600 },
    });
    if (!r.ok) return null;
    const d = await r.json();
    const title = String(d?.title || d?.name || "");
    if (!title) return null;
    const date = String(d?.release_date || d?.first_air_date || "");
    return { title, year: date.slice(0, 4) };
  } catch {
    return null;
  }
}

/** Cari daftar halaman subtitle dari pencarian subtitlecat. */
async function searchSubPages(query: string): Promise<string[]> {
  try {
    const r = await fetch(
      `https://www.subtitlecat.com/index.php?search=${encodeURIComponent(query)}`,
      {
        headers: { "User-Agent": UA_DESKTOP, Accept: "text/html" },
        signal: AbortSignal.timeout(12000),
      }
    );
    if (!r.ok) return [];
    const html = await r.text();
    return [...html.matchAll(/href="(subs\/[^"]+\.html)"/g)]
      .map((m) => m[1])
      .slice(0, 6);
  } catch {
    return [];
  }
}

/** Scan satu halaman subtitle → link .srt bahasa target (langsung unduh). */
async function findSrtInPage(pageUrl: string, lang: string): Promise<string | null> {
  try {
    const r = await fetch(`https://www.subtitlecat.com/${pageUrl}`, {
      headers: { "User-Agent": UA_DESKTOP, Accept: "text/html" },
      signal: AbortSignal.timeout(12000),
    });
    if (!r.ok) return null;
    const html = await r.text();
    const m = html.match(new RegExp(`href="([^"]*-${lang}\\.srt)"`));
    return m ? m[1] : null;
  } catch {
    return null;
  }
}

/** Unduh file .srt dari subtitlecat. */
async function downloadSrt(path: string): Promise<string | null> {
  try {
    const r = await fetch(`https://www.subtitlecat.com${path}`, {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "*/*",
        Referer: `https://www.subtitlecat.com/${path.split("/").slice(0, -1).join("/")}/`,
      },
      signal: AbortSignal.timeout(20000),
    });
    if (!r.ok) return null;
    const buf = await r.arrayBuffer();
    if (buf.byteLength < 100 || buf.byteLength > 3 * 1024 * 1024) return null;
    return new TextDecoder("utf-8").decode(buf);
  } catch {
    return null;
  }
}

/** Konversi SRT → WebVTT. */
function srtToVtt(srt: string): string {
  const body = srt
    .replace(/\r+/g, "")
    .replace(/^\uFEFF/, "")
    .replace(/^WEBVTT.*\n?/i, "")
    .replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, "$1.$2");
  return `WEBVTT\n\n${body.trim()}\n`;
}

/**
 * Terjemahkan seluruh file SRT ke bahasa target memakai AI (z-ai-web-dev-sdk).
 * Dipakai sebagai cadangan CC AI: bila subtitle bahasa target tidak tersedia di
 * sumber, subtitle cadangan diterjemahkan otomatis (per segmen, hasil di-cache).
 * V0.01: bahasa target bisa APA PUN (default id) sesuai permintaan #9.
 */
async function aiTranslateSrt(srt: string, targetLang: string): Promise<string | null> {
  try {
    const { default: ZAI } = await import("z-ai-web-dev-sdk");
    const zai = await ZAI.create();
    const lines = srt.split(/\r?\n/).filter((l) => l.trim() !== "");
    // kelompokkan jadi segmen [index, time, text...]
    const segments: Array<{ time: string; text: string }> = [];
    for (let i = 0; i < lines.length; i++) {
      if (/-->/.test(lines[i])) {
        const time = lines[i].trim();
        const text: string[] = [];
        for (let j = i + 1; j < lines.length && !/-->/.test(lines[j]) && !/^\d+$/.test(lines[j]); j++) {
          text.push(lines[j]);
        }
        if (text.length) segments.push({ time, text: text.join("\n") });
      }
    }
    if (!segments.length) return null;

    // terjemahkan per batch (maks 40 segmen per permintaan biar aman token)
    const out: Array<{ time: string; text: string }> = [];
    const BATCH = 40;
    for (let start = 0; start < segments.length; start += BATCH) {
      const batch = segments.slice(start, start + BATCH);
      const numbered = batch.map((s, i) => `${i + 1}. ${s.text.replace(/\n/g, " / ")}`).join("\n");
      const completion = await zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content:
              `Anda penerjemah subtitle film profesional. Terjemahkan tiap baris bernomor ke ${
                LANG_NAMES[targetLang] || targetLang
              }. Pertahankan nomor baris persis seperti input (satu baris per nomor). Jangan menambahkan komentar apa pun. Balas HANYA hasil terjemahan.`,
          },
          { role: "user", content: numbered },
        ],
      });
      const content = completion?.choices?.[0]?.message?.content || "";
      const map = new Map<number, string>();
      for (const m of content.matchAll(/^\s*(\d+)\.\s*(.+)$/gm)) {
        map.set(Number(m[1]), m[2].trim());
      }
      batch.forEach((s, i) => {
        const translated = map.get(i + 1);
        if (translated) out.push({ time: s.time, text: translated.replace(/\s*\/\s*/g, "\n") });
        else out.push(s); // gagal menerjemahkan segmen → pakai teks asli
      });
    }

    // susun ulang jadi SRT
    const blocks = out.map((s, i) => `${i + 1}\n${s.time}\n${s.text}`);
    return blocks.join("\n\n") + "\n";
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  // subtitle dipasang player pihak ketiga (vidlink) → tanpa session,
  // rate-limit ketat per IP
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`sub:${ip}`, 40, 60 * 1000).ok) {
    return new Response("Too many requests", { status: 429 });
  }

  const tmdbId = Number(req.nextUrl.searchParams.get("id"));
  const type = req.nextUrl.searchParams.get("type") === "tv" ? "tv" : "movie";
  // V0.01: terima semua kode bahasa ISO — default "id" (Indonesia) sesuai permintaan #9
  const langRaw = (req.nextUrl.searchParams.get("lang") || "id").trim().toLowerCase().slice(0, 8);
  const lang = LANG_CODES.has(langRaw) ? langRaw : "id";
  const season = Number(req.nextUrl.searchParams.get("season")) || 0;
  const episode = Number(req.nextUrl.searchParams.get("episode")) || 0;
  const aiEnabled = req.nextUrl.searchParams.get("ai") === "1";

  if (!Number.isInteger(tmdbId) || tmdbId <= 0) {
    return new Response("ID tidak valid", { status: 400 });
  }

  const cacheKey = `${type}:${tmdbId}:${lang}:${season}:${episode}:${aiEnabled ? "ai" : "noai"}`;
  const cached = subCache.get(cacheKey);
  if (cached && Date.now() - cached.found < 6 * 3600 * 1000) {
    return new Response(cached.vtt, {
      headers: {
        "Content-Type": "text/vtt; charset=utf-8",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "public, max-age=3600",
      },
    });
  }

  try {
    const meta = await getTitle(tmdbId, type);
    if (!meta) throw new Error("no meta");

    // strategi query: tv + episode → "judul sXeY" duluan, lalu judul + tahun
    const queries: string[] = [];
    if (type === "tv" && season > 0 && episode > 0) {
      const se = `s${String(season).padStart(2, "0")}e${String(episode).padStart(2, "0")}`;
      queries.push(`${meta.title} ${se}`);
      queries.push(`${meta.title} ${season}x${episode}`);
    }
    if (meta.year) queries.push(`${meta.title} ${meta.year}`);
    queries.push(meta.title);

    let srt: string | null = null;
    outer: for (const q of queries) {
      const pages = await searchSubPages(q);
      for (const page of pages.slice(0, 4)) {
        await sleep(250); // jeda agar tidak dianggap bot
        const srtPath = await findSrtInPage(decodeURIComponent(page), lang);
        if (srtPath) {
          srt = await downloadSrt(srtPath);
          if (srt) break outer;
        }
      }
    }

    // CC AI (V0.01 — semua bahasa): subtitle bahasa target tidak ketemu →
    // ambil versi bahasa cadangan (en → id) lalu terjemahkan dengan AI.
    if (!srt && aiEnabled) {
      const fallbackLangs = lang === "en" ? ["id", "en"] : ["en", "id"];
      outer2: for (const fbLang of fallbackLangs) {
        if (fbLang === lang) continue;
        for (const q of queries) {
          const pages = await searchSubPages(q);
          for (const page of pages.slice(0, 4)) {
            await sleep(250);
            const srtPath = await findSrtInPage(decodeURIComponent(page), fbLang);
            if (srtPath) {
              const raw = await downloadSrt(srtPath);
              if (raw) {
                // batasi ukuran biar terjemahan tidak terlalu lama
                const limited = raw.length > 90_000 ? raw.slice(0, 90_000) : raw;
                const translated = await aiTranslateSrt(limited, lang);
                if (translated) {
                  srt = translated;
                  break outer2;
                }
                // AI gagal → pakai subtitle bahasa cadangan apa adanya
                srt = limited;
                break outer2;
              }
            }
          }
        }
      }
    }

    if (!srt) throw new Error("no subtitle");

    const vtt = srtToVtt(srt);
    subCache.set(cacheKey, { vtt, found: Date.now() });

    return new Response(vtt, {
      headers: {
        "Content-Type": "text/vtt; charset=utf-8",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch {
    // kosong tapi tetap 200 + VTT valid supaya player gak error
    return new Response("WEBVTT\n\n", {
      headers: {
        "Content-Type": "text/vtt; charset=utf-8",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-store",
      },
    });
  }
}
