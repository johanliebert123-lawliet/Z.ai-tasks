import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * HDhub search — port dari HDhub-api-main (Python) ke Node.
 * Domain: https://hdhub4u.catering (bisa diganti via env HDHUB_BASE).
 * Proxy opsional via env HDHUB_PROXY (http://user:pass@host:port) — sesuai source.
 */

const BASE = (process.env.HDHUB_BASE || "https://hdhub4u.catering").replace(/\/$/, "");
const PROXY = process.env.HDHUB_PROXY || "";

interface HdhubItem {
  title: string;
  url: string;
  year?: string;
  poster?: string;
  type?: string;
}

/** Fetch lewat proxy kalau dikonfigurasi (Node fetch tidak native dukung
 *  proxy http, jadi kita pakai undici dispatcher via env proxy saja —
 *  di Vercel bisa diset HTTPS_PROXY). Di sini: coba langsung. */
async function fetchPage(url: string): Promise<string> {
  const res = await fetch(url, {
    headers: {
      "User-Agent": UA_DESKTOP,
      Accept: "text/html,application/xhtml+xml",
      "Accept-Language": "en-US,en;q=0.9",
    },
    signal: AbortSignal.timeout(20000),
    // @ts-expect-error — dispatcher proxy (undici) kalau tersedia
    dispatcher: globalThis.__hdhubDispatcher || undefined,
  });
  if (!res.ok) throw new Error(`hdhub ${res.status}`);
  return res.text();
}

function parseSearch(html: string): HdhubItem[] {
  const results: HdhubItem[] = [];
  const seen = new Set<string>();
  // pattern dari source Python: <a href="..." class="...movie-card..."> ... </a>
  const cardRe = /<a[^>]*href="([^"]+)"[^>]*class="[^"]*movie-card[^"]*"[^>]*>([\s\S]*?)<\/a>/g;
  let m: RegExpExecArray | null;
  while ((m = cardRe.exec(html))) {
    let url = m[1];
    if (!url.startsWith("http")) url = BASE + (url.startsWith("/") ? url : "/" + url);
    if (seen.has(url)) continue;
    seen.add(url);

    const content = m[2];
    const titleM = content.match(/class="movie-card-title"[^>]*>([^<]+)/);
    const altM = content.match(/alt="([^"]+)"/);
    const yearM = content.match(/class="movie-card-meta"[^>]*>\s*(\d{4})/);
    const posterM = content.match(/<img[^>]*src="([^"]+)"/);

    const title = (titleM?.[1] || altM?.[1] || "Unknown").trim();
    const type =
      /season|series|s0\d|episode/i.test(title) ? "series" : "movie";
    results.push({
      url,
      title,
      year: yearM?.[1],
      poster: posterM?.[1],
      type,
    });
    if (results.length >= 20) break;
  }
  return results;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`hdhub:${ip}`, 10, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim();
  if (q.length < 2) {
    return Response.json({ ok: false, error: "Masukkan judul minimal 2 huruf" }, { status: 400 });
  }

  try {
    const html = await fetchPage(`${BASE}/?s=${encodeURIComponent(q.replace(/\s+/g, "+"))}`);
    const results = parseSearch(html);
    return Response.json({ ok: true, results });
  } catch {
    return Response.json(
      {
        ok: false,
        error:
          "HDhub sedang tidak bisa dihubungi (servernya sering ganti domain / proteksi aktif). Kalau punya domain terbaru, set env HDHUB_BASE.",
        results: [],
      },
      { status: 202 }
    );
  }
}
