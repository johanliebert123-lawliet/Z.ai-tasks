import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { EMBED_SERVERS, LK21_SERVERS, MOVIEZONE_BASE, UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

export interface ServerOption {
  id: string;
  name: string;
  url: string;
  source: "moviezone" | "fanzz" | "lk21";
  compat: boolean;
  subParam: boolean;
  /** "file" = sub dikontrol dari tombol Fanzz (param sub_file), "cc" = lewat menu player */
  subMode?: "file" | "cc";
  note?: string;
}

function fanzzServers(
  tmdbId: number,
  season?: number,
  episode?: number,
  sub?: string,
  subFileUrl?: string
): ServerOption[] {
  return EMBED_SERVERS.map((s) => {
    let url = s.build(tmdbId, season, episode);
    // server dengan subMode "file": pasang file VTT FanzzTools via param resmi
    if (s.subMode === "file" && sub && sub !== "off" && subFileUrl) {
      url +=
        (url.includes("?") ? "&" : "?") +
        `sub_file=${encodeURIComponent(subFileUrl)}` +
        `&sub_label=${encodeURIComponent(sub)}`;
    }
    return {
      id: s.id,
      name: s.name,
      url,
      source: "fanzz" as const,
      compat: Boolean(s.compat),
      subParam: Boolean(s.subParam),
      subMode: s.subMode,
      note: s.note,
    };
  });
}

/** LK21 Stream Premium — ditambahkan V0.01 (permintaan #2). */
function lk21Servers(
  tmdbId: number,
  season?: number,
  episode?: number,
  sub?: string,
  subFileUrl?: string
): ServerOption[] {
  return LK21_SERVERS.map((s) => {
    let url = s.build(tmdbId, season, episode);
    if (s.subMode === "file" && sub && sub !== "off" && subFileUrl) {
      url +=
        (url.includes("?") ? "&" : "?") +
        `sub_file=${encodeURIComponent(subFileUrl)}` +
        `&sub_label=${encodeURIComponent(sub)}`;
    }
    return {
      id: s.id,
      name: s.name,
      url,
      source: "lk21" as const,
      compat: Boolean(s.compat),
      subParam: Boolean(s.subParam),
      subMode: s.subMode,
      note: s.note,
    };
  });
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`srv:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const tmdbId = Number(req.nextUrl.searchParams.get("id"));
  const type = req.nextUrl.searchParams.get("type") === "tv" ? "tv" : "movie";
  const seasonRaw = Number(req.nextUrl.searchParams.get("season"));
  const episodeRaw = Number(req.nextUrl.searchParams.get("episode"));
  // V0.01: sub menerima SEMUA kode bahasa ISO (id, en, ar, es, ...) — bukan hanya id/en
  const sub = (req.nextUrl.searchParams.get("sub") || "id").trim().toLowerCase().slice(0, 8);
  const season = type === "tv" && Number.isInteger(seasonRaw) && seasonRaw > 0 ? seasonRaw : undefined;
  const episode =
    type === "tv" && Number.isInteger(episodeRaw) && episodeRaw > 0 ? episodeRaw : undefined;

  if (!Number.isInteger(tmdbId) || tmdbId <= 0) {
    return Response.json({ ok: false, error: "ID tidak valid" }, { status: 400 });
  }

  // URL subtitle VTT (absolute, origin dari request ini) — dipakai server subMode "file"
  const ai = req.nextUrl.searchParams.get("ai") === "1";
  const subParams = new URLSearchParams({
    id: String(tmdbId),
    type,
    lang: /^[a-z]{2}(-[a-z]{2})?$/.test(sub) ? sub : "id",
  });
  if (season) subParams.set("season", String(season));
  if (episode) subParams.set("episode", String(episode));
  if (ai) subParams.set("ai", "1");
  // origin dari header host (bukan nextUrl.origin — di standalone server bisa jadi 0.0.0.0)
  const host = req.headers.get("x-forwarded-host") || req.headers.get("host") || "";
  const proto = req.headers.get("x-forwarded-proto") || (host.startsWith("localhost") || host.startsWith("127.") || host.startsWith("0.0.0.0") ? "http" : "https");
  const origin = host ? `${proto}://${host}` : req.nextUrl.origin;
  const subFileUrl = sub !== "off" ? `${origin}/api/movies/subtitle?${subParams}` : undefined;

  // Server dari moviezone (slug pakai tmdb id) — hanya yang masih hidup.
  // PERBAIKAN V2a: diprioritaskan sebagai sumber utama; slug episode TV
  // (tv-<id>-s<season>e<episode>) juga dicoba bila ada.
  let mzServers: ServerOption[] = [];
  try {
    const slugCandidates = [
      type === "tv" && season && episode ? `${type}-${tmdbId}-s${season}e${episode}` : null,
      `${type}-${tmdbId}`,
    ].filter(Boolean) as string[];
    for (const slug of slugCandidates) {
      const r = await fetch(`${MOVIEZONE_BASE}/detail/${slug}`, {
        headers: {
          "User-Agent": UA_MOBILE,
          Accept: "application/json",
          Referer: "https://moviezone.web.id/",
        },
        signal: AbortSignal.timeout(12000),
        next: { revalidate: 1800 },
      });
      if (!r.ok) continue;
      const d = await r.json();
      const raw = d?.stream?.servers;
      if (Array.isArray(raw)) {
        const DEAD = /vsembed|multiembed|superembed/i;
        mzServers = raw
          .filter((s: { server?: string; url?: string }) => {
            const name = String(s.server || "");
            return typeof s.url === "string" && s.url && !DEAD.test(name);
          })
          .map(
            (s: { server?: string; url: string }, i: number): ServerOption => {
              let url = s.url;
              const isVidlink = /vidlink/i.test(s.server || "");
              // VidLink dari MovieZone juga diberi sub_file FanzzTools supaya
              // tombol sub di aplikasi tetap mengendalikan subtitlenya.
              if (isVidlink && sub !== "off" && subFileUrl) {
                url +=
                  (url.includes("?") ? "&" : "?") +
                  `sub_file=${encodeURIComponent(subFileUrl)}` +
                  `&sub_label=${encodeURIComponent(sub)}`;
              }
              return {
                id: `mz-${i}`,
                name: s.server ? `MovieZone • ${s.server}` : `MovieZone ${i + 1}`,
                url,
                source: "moviezone",
                compat: /2embed|superembed|vidsrc|vidlink|multiembed|vsembed/i.test(
                  s.server || ""
                ),
                subParam: /vidsrc|vidlink/i.test(s.server || ""),
                subMode: isVidlink ? "file" : "cc",
                note: isVidlink ? "Sumber utama — MovieZone (sub via sini)" : "Sumber utama — MovieZone",
              };
            }
          );
        if (mzServers.length) break;
      }
    }
  } catch {
    /* moviezone opsional */
  }

  const own = fanzzServers(tmdbId, season, episode, sub, subFileUrl);
  const lk21 = lk21Servers(tmdbId, season, episode, sub, subFileUrl);

  // PERBAIKAN V2a: server MovieZone menjadi UTAMA (diurutkan paling depan)
  // sesuai permintaan — LK21 Stream Premium menyusul (V0.01), server Fanzz cadangan.
  return Response.json({
    ok: true,
    servers: [...mzServers, ...lk21, ...own],
    sub,
    moviezone: mzServers.length > 0,
  });
}
