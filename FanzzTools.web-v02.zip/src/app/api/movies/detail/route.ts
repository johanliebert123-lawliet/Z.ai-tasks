import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { TMDB_BASE, TMDB_KEY, TMDB_IMG, UA_MOBILE, MOVIEZONE_BASE } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`detail:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const id = Number(req.nextUrl.searchParams.get("id"));
  const type = req.nextUrl.searchParams.get("type") === "tv" ? "tv" : "movie";
  if (!Number.isInteger(id) || id <= 0 || id > 99_999_999) {
    return Response.json({ ok: false, error: "ID film tidak valid" }, { status: 400 });
  }

  const tmdbHeaders = {
    "User-Agent": UA_MOBILE,
    Accept: "application/json",
    Referer: "https://moviezone.web.id/",
  };

  try {
    // Detail utama dari moviezone (sinopsis Indonesia + servers siap pakai)
    const slug = `${type === "tv" ? "tv" : "movie"}-${id}`;
    const mz = await fetch(`${MOVIEZONE_BASE}/detail/${slug}`, {
      headers: tmdbHeaders,
      signal: AbortSignal.timeout(15000),
      next: { revalidate: 3600 },
    })
      .then((r) => (r.ok ? r.json() : null))
      .catch(() => null);

    // TMDB untuk data lengkap + seasons
    const [detailRes, creditsRes] = await Promise.all([
      fetch(
        `${TMDB_BASE}/${type}/${id}?api_key=${TMDB_KEY}&language=id-ID`,
        { headers: tmdbHeaders, signal: AbortSignal.timeout(15000), next: { revalidate: 3600 } }
      ),
      fetch(`${TMDB_BASE}/${type}/${id}/credits?api_key=${TMDB_KEY}&language=id-ID`, {
        headers: tmdbHeaders,
        signal: AbortSignal.timeout(15000),
        next: { revalidate: 3600 },
      }),
    ]);
    if (!detailRes.ok) throw new Error("Film tidak ditemukan");
    const detail = await detailRes.json();
    const credits = creditsRes.ok ? await creditsRes.json() : { cast: [], crew: [] };

    const seasons = (detail.seasons || [])
      .filter((s: { episode_count?: number }) => (s.episode_count || 0) > 0)
      .map((s: { id: number; season_number: number; name: string; episode_count: number; air_date?: string; poster_path?: string | null }) => ({
        id: s.id,
        number: s.season_number,
        name: s.name,
        episodes: s.episode_count,
        year: (s.air_date || "").slice(0, 4),
        poster: s.poster_path ? `${TMDB_IMG}/w185${s.poster_path}` : null,
      }));

    const data = {
      ok: true,
      id,
      type,
      title: detail.title || detail.name || mz?.title || "Tanpa Judul",
      tagline: mz?.tagline || detail.tagline || "",
      overview: mz?.synopsis || detail.overview || "",
      poster: detail.poster_path
        ? `${TMDB_IMG}/w500${detail.poster_path}`
        : mz?.poster || null,
      backdrop: detail.backdrop_path
        ? `${TMDB_IMG}/original${detail.backdrop_path}`
        : mz?.backdrop || null,
      rating: Math.round((detail.vote_average || 0) * 10) / 10,
      voteCount: detail.vote_count || 0,
      year: (detail.release_date || detail.first_air_date || mz?.year || "").slice(0, 4),
      releaseDate: detail.release_date || detail.first_air_date || "",
      duration: mz?.duration || (type === "movie" ? detail.runtime : null),
      genres: (detail.genres || []).map((g: { id: number; name: string }) => g.name),
      status: detail.status || "",
      numberOfSeasons: detail.number_of_seasons || 0,
      seasons,
      cast: (credits.cast || []).slice(0, 12).map(
        (c: { id: number; name: string; character?: string; profile_path?: string | null }) => ({
          id: c.id,
          name: c.name,
          character: c.character || "",
          photo: c.profile_path ? `${TMDB_IMG}/w185${c.profile_path}` : null,
        })
      ),
      directors: (credits.crew || [])
        .filter((c: { job?: string }) => c.job === "Director")
        .slice(0, 3)
        .map((c: { name: string }) => c.name),
      trailer:
        detail.videos?.results?.find(
          (v: { type: string; site: string; key: string }) =>
            v.site === "YouTube" && v.type === "Trailer"
        )?.key || null,
      // server streaming dari moviezone (kalau ada)
      servers:
        mz?.stream?.servers?.map(
          (s: { server?: string; name?: string; url?: string }, i: number) => ({
            id: `mz-${i}`,
            name: s.server || s.name || `Server ${i + 1}`,
            url: s.url || "",
            source: "moviezone",
          })
        ) || [],
    };

    return Response.json(data);
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal memuat detail" },
      { status: 502 }
    );
  }
}
