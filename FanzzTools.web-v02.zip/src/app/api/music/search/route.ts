import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

const YTM_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
const FILTER_SONGS = "EgWKAQIIAWoSEAQQAxAFEAkQChAVEBAQERAO"; // filter lagu

interface YtmSong {
  videoId: string;
  title: string;
  artist: string;
  album?: string;
  duration: string;
  plays?: string;
  thumbnail: string;
}

function extractSongs(data: unknown): YtmSong[] {
  const out: YtmSong[] = [];
  const contents =
    (data as { contents?: { tabbedSearchResultsRenderer?: { tabs?: Array<{ tabRenderer?: { content?: { sectionListRenderer?: { contents?: unknown[] } } } }> } } })?.contents
      ?.tabbedSearchResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
      ?.contents || [];

  const walkShelf = (shelf: unknown) => {
    const items =
      (
        shelf as {
          musicShelfRenderer?: { contents?: Array<Record<string, unknown>> };
        }
      )?.musicShelfRenderer?.contents || [];
    for (const it of items) {
      const mr = (it as { musicResponsiveListItemRenderer?: Record<string, unknown> })
        ?.musicResponsiveListItemRenderer;
      if (!mr) continue;
      const flexColumns = (mr.flexColumns || []) as Array<{
        musicResponsiveListItemFlexColumnRenderer?: {
          text?: { runs?: Array<{ text: string }> };
        };
      }>;
      const titleRuns = flexColumns[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];
      const subRuns = flexColumns[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];

      const pl =
        (mr as { playlistItemData?: { videoId?: string } }).playlistItemData?.videoId ||
        (mr as { overlay?: { musicItemThumbnailOverlayRenderer?: { content?: { musicPlayButtonRenderer?: { playNavigationEndpoint?: { watchEndpoint?: { videoId?: string } } } } } } }).overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
      if (!pl) continue;

      const title = titleRuns.map((r) => r.text).join("") || "Tanpa Judul";
      const subText = subRuns.map((r) => r.text).join("");
      const parts = subText.split("•").map((p) => p.trim());
      const artist = parts[0] || "";
      const album = parts.length > 2 ? parts[1] : undefined;

      // duration: locale ID pakai titik ("5.04" = 5:04), locale EN pakai ":" (5:04)
      const durRaw = parts[parts.length - 1] || "";
      let duration = "";
      if (/^\d+:\d{2}$/.test(durRaw)) duration = durRaw;
      else if (/^\d+\.\d{1,2}$/.test(durRaw)) {
        const [mm, ss] = durRaw.split(".");
        duration = `${mm}:${ss.padStart(2, "0")}`;
      }

      const playsRuns = flexColumns[2]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];
      const plays = playsRuns.map((r) => r.text).join("").trim() || undefined;

      const thumbs =
        ((mr as { thumbnail?: { musicThumbnailRenderer?: { thumbnail?: { thumbnails?: Array<{ url: string; width: number }> } } } }).thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails as Array<{ url: string; width: number }>) || [];
      const best = thumbs.length ? thumbs[thumbs.length - 1] : null;

      out.push({
        videoId: String(pl),
        title,
        artist,
        album,
        duration,
        plays,
        thumbnail: best?.url || `https://i.ytimg.com/vi/${pl}/mqdefault.jpg`,
      });
      if (out.length >= 25) break;
    }
  };

  for (const section of contents) {
    walkShelf(section);
    const sh =
      (section as { musicCardShelfRenderer?: unknown })?.musicCardShelfRenderer;
    if (sh) walkShelf(sh);
  }
  return out;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`msearch:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 100);
  if (q.length < 1) return Response.json({ ok: true, songs: [] });

  try {
    const res = await fetch(
      `https://music.youtube.com/youtubei/v1/search?key=${YTM_KEY}&prettyPrint=false`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Origin: "https://music.youtube.com",
          Referer: "https://music.youtube.com/",
          "User-Agent": UA_MOBILE,
        },
        body: JSON.stringify({
          context: {
            client: {
              clientName: "WEB_REMIX",
              clientVersion: "1.20240101.00.00",
              hl: "id",
              gl: "ID",
            },
          },
          query: q,
          params: FILTER_SONGS,
        }),
        signal: AbortSignal.timeout(20000),
      }
    );
    if (!res.ok) throw new Error(`YTM ${res.status}`);
    const data = await res.json();
    const songs = extractSongs(data);
    return Response.json({ ok: true, songs });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Pencarian musik gagal" },
      { status: 502 }
    );
  }
}
