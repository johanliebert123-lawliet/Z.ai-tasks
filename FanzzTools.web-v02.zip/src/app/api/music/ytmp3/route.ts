import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * YTMP3 — PEMUTARAN INSTAN (V2.11, perbaikan keluhan #1/#11/#33).
 *
 * Keluhan lama: "cuman lagu paling atas doang yang bisa diputar dalam 1
 * pencarian" + "delay lama tiap ganti lagu".
 *
 * Akar masalah: rantai provider LAMA sekuensial (InnerTube 3 klien = 36 detik
 * waktu-habis, lalu faa/puruboy yang mudah dibatasi setelah 1-2 konversi).
 * Saat IP server diblokir player Google, hanya permintaan PERTAMA yang
 * kebagian konversi pihak ketiga — sisanya gagal.
 *
 * Sekarang SEMUA jalur berjalan PARALEL dan yang pertama sukses menang:
 *  1. InnerTube player (3 klien serentak — URL audio langsung via proxy)
 *  2. savetube (3 CDN serentak, teknik NanzMusify: /info → AES-128-CBC →
 *     /download; terbukti bekerja dari IP yang diblokir Google)
 *  3. faa + puruboy (CDN publik)
 * Latensi = penyedia tercepat yang hidup, bukan jumlah semua waktu-habis.
 */

interface SongResult {
  videoId: string;
  title: string;
  thumbnail: string;
  /** URL yang diputar klien: proxy untuk googlevideo, langsung untuk CDN publik */
  mp3: string;
  /** URL asli (untuk unduhan via /api/download/file) */
  mp3Direct?: string;
  duration?: string;
  source: string;
}

interface CacheEntry {
  at: number;
  ttl: number;
  result: SongResult;
}

const g = globalThis as unknown as {
  __fanzzYtmp3Cache?: Map<string, CacheEntry>;
  __fanzzYtmp3Inflight?: Map<string, Promise<SongResult | null>>;
};
if (!g.__fanzzYtmp3Cache) g.__fanzzYtmp3Cache = new Map();
if (!g.__fanzzYtmp3Inflight) g.__fanzzYtmp3Inflight = new Map();
const CACHE = g.__fanzzYtmp3Cache;
const INFLIGHT = g.__fanzzYtmp3Inflight;
/** TTL per sumber: googlevideo ~6 jam; URL presigned savetube/CDN publik ~90 menit */
const TTL_BY_SOURCE = (source: string): number => {
  if (source.startsWith("innertube")) return 6 * 60 * 60 * 1000;
  return 90 * 60 * 1000;
};

function extractId(url: string): string {
  const m = url.match(/(?:youtu\.be\/|v=|shorts\/|embed\/)([a-zA-Z0-9_-]{6,})/) || null;
  return m ? m[1] : url.slice(0, 20);
}

function proxied(url: string): string {
  return `/api/stream/proxy?url=${encodeURIComponent(url)}`;
}

/* ================= 1) InnerTube player — 3 klien PARALEL ================= */

interface ItFormat {
  itag?: number;
  mimeType?: string;
  bitrate?: number;
  url?: string;
  contentLength?: number;
}

interface ItResp {
  playabilityStatus?: { status?: string; reason?: string };
  videoDetails?: { title?: string; thumbnail?: { thumbnails?: Array<{ url: string }> }; lengthSeconds?: string };
  streamingData?: { formats?: ItFormat[]; adaptiveFormats?: ItFormat[] };
}

const IT_CLIENTS: Array<{ label: string; url: string; ua: string; body: (videoId: string) => string }> = [
  {
    label: "WEB_REMIX",
    url: "https://music.youtube.com/youtubei/v1/player?key=AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8&prettyPrint=false",
    ua: UA_MOBILE,
    body: (videoId) =>
      JSON.stringify({
        context: { client: { clientName: "WEB_REMIX", clientVersion: "1.20240101.00.00", hl: "id", gl: "ID" } },
        videoId,
        contentCheckOk: true,
        racyCheckOk: true,
      }),
  },
  {
    label: "ANDROID",
    url: "https://www.youtube.com/youtubei/v1/player?key=AIzaSyA8eiZ6MbvHE99rrNozEsAmhFAiX3-Ey7A&prettyPrint=false",
    ua: "com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip",
    body: (videoId) =>
      JSON.stringify({
        context: { client: { clientName: "ANDROID", clientVersion: "19.09.37", androidSdkVersion: 30, hl: "id", gl: "ID" } },
        videoId,
        contentCheckOk: true,
        racyCheckOk: true,
      }),
  },
  {
    label: "IOS",
    url: "https://www.youtube.com/youtubei/v1/player?key=AIzaSyB-63vPrdThhKuerbB2N_l7Kwwcxj6yUAc&prettyPrint=false",
    ua: "com.google.ios.youtube/19.09.3 (iPhone14,3; U; CPU iOS 15_6 like Mac OS X)",
    body: (videoId) =>
      JSON.stringify({
        context: { client: { clientName: "IOS", clientVersion: "19.09.3", deviceModel: "iPhone14,3", hl: "id", gl: "ID" } },
        videoId,
        contentCheckOk: true,
        racyCheckOk: true,
      }),
  },
];

function pickAudioFormat(d: ItResp): ItFormat | null {
  const audios = [...(d.streamingData?.adaptiveFormats || []), ...(d.streamingData?.formats || [])].filter(
    (f) => (f.mimeType || "").startsWith("audio/") && typeof f.url === "string" && /^https?:\/\//.test(f.url)
  );
  if (!audios.length) return null;
  return audios.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))[0];
}

async function itClient(client: (typeof IT_CLIENTS)[number], videoId: string): Promise<SongResult | null> {
  try {
    const res = await fetch(client.url, {
      method: "POST",
      headers: { "Content-Type": "application/json", "User-Agent": client.ua, Origin: "https://www.youtube.com" },
      body: client.body(videoId),
      signal: AbortSignal.timeout(9000),
    });
    if (!res.ok) return null;
    const d = (await res.json()) as ItResp;
    if (d?.playabilityStatus?.status !== "OK") return null;
    const best = pickAudioFormat(d);
    if (!best?.url) return null;
    const thumbs = d?.videoDetails?.thumbnail?.thumbnails || [];
    return {
      videoId,
      title: d?.videoDetails?.title || "Lagu",
      thumbnail: thumbs.length ? thumbs[thumbs.length - 1].url : `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`,
      mp3: proxied(best.url),
      mp3Direct: best.url,
      duration: d?.videoDetails?.lengthSeconds
        ? `${Math.floor(Number(d.videoDetails.lengthSeconds) / 60)}:${String(Number(d.videoDetails.lengthSeconds) % 60).padStart(2, "0")}`
        : undefined,
      source: `innertube-${client.label.toLowerCase()}`,
    };
  } catch {
    return null;
  }
}

async function viaInnerTube(videoId: string): Promise<SongResult | null> {
  const results = await Promise.all(IT_CLIENTS.map((c) => itClient(c, videoId)));
  return results.find((r) => r) || null;
}

/* ================= 2) savetube — 3 CDN PARALEL (teknik NanzMusify) ================= */

const ST_CDNS = ["cdn405.savetube.vip", "cdn403.savetube.vip", "cdn401.savetube.vip"];
const ST_HEADERS = {
  "content-type": "application/json",
  origin: "https://yt.savetube.me",
  "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
};

interface StInfo {
  key?: string;
  title?: string;
  duration?: number;
  thumbnail?: string;
}

async function stCdn(cdn: string, videoId: string): Promise<SongResult | null> {
  try {
    const fullUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const infoRes = await fetch(`https://${cdn}/v2/info`, {
      method: "POST",
      headers: ST_HEADERS,
      body: JSON.stringify({ url: fullUrl }),
      signal: AbortSignal.timeout(9000),
    });
    if (!infoRes.ok) return null;
    const infoJson = (await infoRes.json()) as { data?: string };
    const encryptedData = infoJson?.data;
    if (!encryptedData) return null;
    const crypto = await import("node:crypto");
    const encrypted = Buffer.from(encryptedData, "base64");
    const decipher = crypto.createDecipheriv(
      "aes-128-cbc",
      Buffer.from("C5D58EF67A7584E4A29F6C35BBC4EB12", "hex"),
      encrypted.subarray(0, 16)
    );
    const decrypted = JSON.parse(
      Buffer.concat([decipher.update(encrypted.subarray(16)), decipher.final()]).toString()
    ) as StInfo;
    if (!decrypted?.key) return null;
    const dlRes = await fetch(`https://${cdn}/download`, {
      method: "POST",
      headers: ST_HEADERS,
      body: JSON.stringify({ id: videoId, downloadType: "audio", quality: "128", key: decrypted.key }),
      signal: AbortSignal.timeout(9000),
    });
    if (!dlRes.ok) return null;
    const dlJson = (await dlRes.json()) as { data?: { downloadUrl?: string }; downloadUrl?: string };
    const audioUrl = dlJson?.data?.downloadUrl || dlJson?.downloadUrl;
    if (typeof audioUrl !== "string" || !/^https?:\/\//.test(audioUrl)) return null;
    const dur = decrypted.duration || 0;
    return {
      videoId,
      title: decrypted.title || "Lagu",
      thumbnail: `https://i.ytimg.com/vi/${videoId}/mqdefault.jpg`,
      mp3: audioUrl,
      mp3Direct: audioUrl,
      duration: dur ? `${Math.floor(dur / 60)}:${String(Math.floor(dur % 60)).padStart(2, "0")}` : undefined,
      source: `savetube-${cdn.slice(0, 6)}`,
    };
  } catch {
    return null;
  }
}

async function viaSavetube(videoId: string): Promise<SongResult | null> {
  // V2 UpdSec FIX "delay banget": dulu CASCADE 3 CDN × 9 detik = 27 detik
  // bila hanya CDN ke-3 yang hidup. Sekarang 3 CDN BERBALAP PARALEL —
  // latensi = CDN tercepat (~3-9 detik). Risiko pembatasan laju tetap
  // rendah karena tiap request hanya 1 panggilan per CDN.
  const results = await Promise.all(ST_CDNS.map((cdn) => stCdn(cdn, videoId)));
  return results.find((r) => r) || null;
}

/* ================= 3) faa + puruboy ================= */

async function fetchJsonCurl(url: string, timeoutSec = 15): Promise<Record<string, unknown> | null> {
  const { execFile } = await import("child_process");
  return new Promise((resolve) => {
    execFile(
      "curl",
      ["-s", "-m", String(timeoutSec), "-A", UA_MOBILE, "-H", "Accept: application/json", "--compressed", url],
      { timeout: (timeoutSec + 5) * 1000, maxBuffer: 4 * 1024 * 1024 },
      (err, stdout) => {
        if (err || typeof stdout !== "string") return resolve(null);
        const t = stdout.trimStart();
        if (!t.startsWith("{")) return resolve(null);
        try {
          resolve(JSON.parse(t) as Record<string, unknown>);
        } catch {
          resolve(null);
        }
      }
    );
  });
}

async function viaFaa(url: string): Promise<SongResult | null> {
  try {
    let d: Record<string, unknown> | null = null;
    try {
      const res = await fetch(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(url)}`, {
        headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
        signal: AbortSignal.timeout(8000),
      });
      if (res.ok) {
        const text = await res.text();
        if (!text.trimStart().startsWith("<")) d = JSON.parse(text);
      }
    } catch {
      /* lanjut cURL */
    }
    if (!d?.status) {
      d = await fetchJsonCurl(`https://api-faa.my.id/faa/ytmp3?url=${encodeURIComponent(url)}`);
    }
    if (d?.status && d?.result) {
      const r = d.result as Record<string, unknown>;
      if (typeof r.mp3 === "string" && /^https?:\/\//.test(r.mp3)) {
        return {
          videoId: extractId(url),
          title: String(r.title || "Lagu"),
          thumbnail: String(r.thumbnail || ""),
          mp3: String(r.mp3),
          mp3Direct: String(r.mp3),
          duration: r.duration ? String(r.duration) : undefined,
          source: "faa",
        };
      }
    }
    return null;
  } catch {
    return null;
  }
}

async function viaPuruboy(url: string): Promise<SongResult | null> {
  try {
    const res = await fetch("https://puruboy-api.vercel.app/api/downloader/ytmp3", {
      method: "POST",
      headers: { "Content-Type": "application/json", "User-Agent": UA_MOBILE },
      body: JSON.stringify({ url }),
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return null;
    const d = await res.json();
    const dl = d?.result?.downloadUrl || d?.result?.url || d?.result?.mp3;
    if (dl) {
      return {
        videoId: extractId(url),
        title: d.result.title || "Lagu",
        thumbnail: d.result.thumbnail || "",
        mp3: String(dl),
        mp3Direct: String(dl),
        duration: d.result.duration,
        source: "puruboy",
      };
    }
    return null;
  } catch {
    return null;
  }
}

/* ================= handler ================= */

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`ytmp3:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu sebentar" }, { status: 429 });
  }

  const raw = (req.nextUrl.searchParams.get("url") || "").trim();
  const videoId = (req.nextUrl.searchParams.get("id") || "").trim();
  const fresh = req.nextUrl.searchParams.get("fresh") === "1";
  if (!/^https?:\/\/(www\.)?(youtube\.com|youtu\.be|music\.youtube\.com)\//.test(raw) && !/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
    return Response.json({ ok: false, error: "Tautan/ID YouTube tidak valid" }, { status: 400 });
  }

  const url = raw || `https://www.youtube.com/watch?v=${videoId}`;
  const key = extractId(url);

  // fresh=1 → lewati cache (klien melaporkan audio mati; URL presigned kedaluwarsa)
  if (!fresh) {
    const hit = CACHE.get(key);
    if (hit && Date.now() - hit.at < hit.ttl) {
      return Response.json({ ok: true, result: hit.result, cached: true });
    }
  }

  // DEDUPE: panggilan ganda untuk lagu yang sama (double-click) menunggu
  // permintaan pertama — bukan menembak semua penyedia dua kali.
  let resolveTask = INFLIGHT.get(key);
  if (!resolveTask) {
    resolveTask = resolveSong(url, key);
    INFLIGHT.set(key, resolveTask);
    resolveTask.finally(() => INFLIGHT.delete(key)).catch(() => {});
  }
  const result = await resolveTask;
  if (!result) {
    return Response.json(
      { ok: false, error: "Gagal memproses lagu (semua sumber sedang membatasi). Silakan coba lagi atau pilih lagu lain." },
      { status: 502 }
    );
  }

  CACHE.set(key, { at: Date.now(), ttl: TTL_BY_SOURCE(result.source), result });
  if (CACHE.size > 400) {
    const first = CACHE.keys().next().value;
    if (first) CACHE.delete(first);
  }
  return Response.json({ ok: true, result });
}

/** Balapan paralel semua penyedia — dipisah agar bisa didedupe per lagu. */
async function resolveSong(url: string, key: string): Promise<SongResult | null> {
  const providers: Array<() => Promise<SongResult | null>> = [
    () => viaInnerTube(key), // 3 klien InnerTube berlomba di dalamnya
    () => viaSavetube(key), // cascade 3 CDN savetube
    () => viaFaa(url),
    () => viaPuruboy(url),
  ];
  return new Promise<SongResult | null>((resolve) => {
    let pending = providers.length;
    let settled = false;
    const finish = (r: SongResult | null) => {
      if (settled) return;
      if (r) {
        settled = true;
        resolve(r);
        return;
      }
      pending -= 1;
      if (pending === 0) {
        settled = true;
        resolve(null);
      }
    };
    providers.forEach((p) => {
      p().then(finish, () => finish(null));
    });
    // jaring pengaman: tutup balapan setelah 30 detik
    setTimeout(() => finish(null), 30000);
  });
}
