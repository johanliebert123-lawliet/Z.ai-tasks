import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Lagu Sedang Populer (V2-new — permintaan #1).
 * Endpoint browse/charts YouTube Music dibatasi untuk sebagian jaringan server,
 * tetapi endpoint SEARCH terbukti andal — jadi bagian "Populer" diisi dari
 * beberapa kueri tren yang dirotasi harian, digabung & di-dedupe.
 */

const YTM_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
const FILTER_SONGS = "EgWKAQIIAWoSEAQQAxAFEAkQChAVEBAQERAO";

/** Rotasi kueri tren per hari supaya tidak monoton. */
const QUERY_POOL = [
  ["lagu viral", "lagu populer indonesia", "lagu terbaru populer"],
  ["top hits indonesia", "lagu hits", "lagu enak didengar"],
  ["lagu barat populer", "trending songs", "hits 2026"],
  ["lagu indo viral", "populer sekarang", "lagu nostalgia hits"],
];

interface PopSong {
  videoId: string;
  title: string;
  artist: string;
  duration: string;
  thumbnail: string;
}

function extractSongs(data: unknown): PopSong[] {
  const out: PopSong[] = [];
  const contents =
    (data as { contents?: { tabbedSearchResultsRenderer?: { tabs?: Array<{ tabRenderer?: { content?: { sectionListRenderer?: { contents?: unknown[] } } } }> } } })?.contents
      ?.tabbedSearchResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
      ?.contents || [];
  const walkShelf = (shelf: unknown) => {
    const items =
      (shelf as { musicShelfRenderer?: { contents?: Array<Record<string, unknown>> } })?.musicShelfRenderer?.contents || [];
    for (const it of items) {
      const mr = (it as { musicResponsiveListItemRenderer?: Record<string, unknown> })?.musicResponsiveListItemRenderer;
      if (!mr) continue;
      const flexColumns = (mr.flexColumns || []) as Array<{
        musicResponsiveListItemFlexColumnRenderer?: { text?: { runs?: Array<{ text: string }> } };
      }>;
      const titleRuns = flexColumns[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];
      const subRuns = flexColumns[1]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs || [];
      const pl =
        (mr as { playlistItemData?: { videoId?: string } }).playlistItemData?.videoId ||
        (mr as { overlay?: { musicItemThumbnailOverlayRenderer?: { content?: { musicPlayButtonRenderer?: { playNavigationEndpoint?: { watchEndpoint?: { videoId?: string } } } } } } }).overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint?.watchEndpoint?.videoId;
      if (!pl) continue;
      const title = titleRuns.map((r) => r.text).join("") || "Tanpa Judul";
      const parts = subRuns.map((r) => r.text).join("").split("•").map((p) => p.trim());
      const artist = parts[0] || "";
      const durRaw = parts[parts.length - 1] || "";
      let duration = "";
      if (/^\d+:\d{2}$/.test(durRaw)) duration = durRaw;
      else if (/^\d+\.\d{1,2}$/.test(durRaw)) {
        const [mm, ss] = durRaw.split(".");
        duration = `${mm}:${ss.padStart(2, "0")}`;
      }
      out.push({
        videoId: String(pl),
        title,
        artist,
        duration,
        thumbnail: `https://i.ytimg.com/vi/${pl}/mqdefault.jpg`,
      });
      if (out.length >= 30) break;
    }
  };
  for (const section of contents) walkShelf(section);
  return out;
}

async function searchYtm(q: string): Promise<PopSong[]> {
  try {
    const res = await fetch(`https://music.youtube.com/youtubei/v1/search?key=${YTM_KEY}&prettyPrint=false`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Origin: "https://music.youtube.com",
        Referer: "https://music.youtube.com/",
        "User-Agent": UA_MOBILE,
      },
      body: JSON.stringify({
        context: { client: { clientName: "WEB_REMIX", clientVersion: "1.20240101.00.00", hl: "id", gl: "ID" } },
        query: q,
        params: FILTER_SONGS,
      }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return [];
    return extractSongs(await res.json());
  } catch {
    return [];
  }
}

const CACHE = { at: 0, songs: [] as PopSong[] };
const TTL = 30 * 60 * 1000;

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`mpop:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  if (Date.now() - CACHE.at < TTL && CACHE.songs.length) {
    return Response.json({ ok: true, songs: CACHE.songs, cached: true });
  }

  // rotasi kueri harian + satu kueri tetap
  const day = Math.floor(Date.now() / 86400000);
  const queries = ["lagu viral", ...QUERY_POOL[day % QUERY_POOL.length]];

  const results = await Promise.all(queries.map((q) => searchYtm(q)));
  const seen = new Set<string>();
  const merged: PopSong[] = [];
  // interleave: ambil bergantian dari tiap kueri supaya campuran seimbang
  const maxLen = Math.max(...results.map((r) => r.length));
  for (let i = 0; i < maxLen && merged.length < 24; i++) {
    for (const r of results) {
      if (r[i] && !seen.has(r[i].videoId)) {
        seen.add(r[i].videoId);
        merged.push(r[i]);
      }
    }
  }

  if (!merged.length) {
    return Response.json({ ok: false, error: "Daftar lagu populer tidak dapat dimuat — coba lagi beberapa saat." }, { status: 502 });
  }
  CACHE.at = Date.now();
  CACHE.songs = merged;
  return Response.json({ ok: true, songs: merged });
}
