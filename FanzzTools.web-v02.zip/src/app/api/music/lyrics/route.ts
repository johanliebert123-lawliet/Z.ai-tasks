import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

interface LyricLine {
  time: string;
  text: string;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`lyr:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const title = (req.nextUrl.searchParams.get("title") || "").trim().slice(0, 120);
  const artist = (req.nextUrl.searchParams.get("artist") || "").trim().slice(0, 120);
  if (title.length < 2) {
    return Response.json({ ok: false, error: "Judul lagu wajib" }, { status: 400 });
  }

  const q = artist ? `${artist} ${title}` : title;

  try {
    const res = await fetch(
      `https://lrclib.net/api/search?q=${encodeURIComponent(q)}`,
      {
        headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
        signal: AbortSignal.timeout(15000),
      }
    );
    if (!res.ok) throw new Error(`LRCLIB ${res.status}`);
    const arr = (await res.json()) as Array<{
      id: number;
      trackName: string;
      artistName: string;
      duration?: number;
      plainLyrics?: string;
      syncedLyrics?: string;
    }>;
    if (!Array.isArray(arr) || !arr.length) {
      return Response.json({ ok: true, lyrics: null, message: "Lirik tidak ditemukan" });
    }

    const withSynced = arr.find((a) => a.syncedLyrics) || arr[0];

    let lines: LyricLine[] = [];
    if (withSynced.syncedLyrics) {
      lines = withSynced.syncedLyrics
        .split("\n")
        .map((l) => {
          const m = l.match(/^\[(\d+):(\d{2})(?:\.(\d{2,3}))?\](.*)$/);
          if (!m) return null;
          const min = Number(m[1]);
          const sec = Number(m[2]);
          const text = (m[4] || "").trim();
          if (!text) return null;
          return {
            time: `${String(min).padStart(2, "0")}:${String(sec).padStart(2, "0")}`,
            text,
          };
        })
        .filter(Boolean) as LyricLine[];
    }

    if (!lines.length && withSynced.plainLyrics) {
      lines = withSynced.plainLyrics
        .split("\n")
        .filter((l) => l.trim())
        .map((l) => ({ time: "", text: l.trim() }));
    }

    return Response.json({
      ok: true,
      lyrics: lines.length
        ? { type: withSynced.syncedLyrics ? "synced" : "plain", lines }
        : null,
      track: withSynced.trackName,
      artist: withSynced.artistName,
      message: lines.length ? undefined : "Lirik tidak tersedia",
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal ambil lirik" },
      { status: 502 }
    );
  }
}
