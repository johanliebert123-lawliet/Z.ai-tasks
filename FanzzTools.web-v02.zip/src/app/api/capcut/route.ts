import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";
import {
  sendVerificationCode,
  registerVerifyLogin,
  getUserInfo,
  claimTrial7d,
  generateSecurePassword,
} from "@/lib/capcut";

export const runtime = "nodejs";

/**
 * CapCut Pro generator — bikin akun CapCut aktif + klaim Pro trial 7 hari.
 * POST { action: "create", email?, password? }  → kirim OTP ke email
 * POST { action: "register", email, password, code } → daftar + login → cookie
 * POST { action: "trial", cookie } → klaim Pro 7 hari
 * Email sementara dibikin lewat temp-mail.io (infra Email Trial FanzzTools).
 */

const TEMPMAIL_API = "https://api.internal.temp-mail.io/api/v3";

function tmHeaders() {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let cors = "";
  for (let i = 0; i < 15; i++) cors += chars.charAt(Math.floor(Math.random() * chars.length));
  return {
    "Content-Type": "application/json",
    "Application-Name": "web",
    "Application-Version": "4.0.0",
    "X-CORS-Header": cors,
    "User-Agent": UA_DESKTOP,
    Referer: "https://temp-mail.io/",
  };
}

async function createTempEmail(): Promise<string> {
  const res = await fetch(`${TEMPMAIL_API}/email/new`, {
    method: "POST",
    headers: tmHeaders(),
    body: JSON.stringify({ min_name_length: 10, max_name_length: 12 }),
    signal: AbortSignal.timeout(20000),
  });
  if (!res.ok) throw new Error(`temp-mail ${res.status}`);
  const d = await res.json();
  if (!d?.email) throw new Error("Gagal membuat email sementara");
  return String(d.email);
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`cc:${ip}`, 6, 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Bentar — generator CapCut cuma bisa 6x per menit" },
      { status: 429 }
    );
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });

  const action = String(body.action || "");

  try {
    if (action === "create") {
      const email = body.email ? String(body.email).slice(0, 100) : await createTempEmail();
      const password = body.password ? String(body.password).slice(0, 60) : generateSecurePassword();
      await sendVerificationCode(email, password);
      return Response.json({
        ok: true,
        email,
        password,
        hint: "OTP udah dikirim ke email di atas — buka Email Trial / inbox kamu, salin kodenya (6 digit), lalu lanjut ke langkah berikutnya.",
      });
    }

    if (action === "register") {
      const email = String(body.email || "");
      const password = String(body.password || "");
      const code = String(body.code || "").trim();
      if (!email || !password || !/^\d{4,8}$/.test(code)) {
        return Response.json({ ok: false, error: "Email, password, dan kode OTP wajib benar" }, { status: 400 });
      }
      const { userId, cookie } = await registerVerifyLogin(email, password, code);
      const info = await getUserInfo(cookie);
      return Response.json({
        ok: true,
        email,
        password,
        userId,
        cookie,
        info: info
          ? {
              name: info.name || info.screen_name || null,
              region: info.region || null,
            }
          : null,
      });
    }

    if (action === "trial") {
      const cookie = String(body.cookie || "");
      if (!cookie.includes("=")) {
        return Response.json({ ok: false, error: "Cookie akun tidak valid" }, { status: 400 });
      }
      const r = await claimTrial7d(cookie);
      return Response.json({ ok: true, ...r });
    }

    return Response.json({ ok: false, error: "Action tidak dikenal" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Generator CapCut gagal";
    return Response.json({ ok: false, error: msg }, { status: 502 });
  }
}
