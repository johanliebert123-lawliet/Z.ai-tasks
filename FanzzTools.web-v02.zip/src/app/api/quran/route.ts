import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";

export const runtime = "nodejs";

/**
 * Qur'an Digital (V2 Modern-UpdSec).
 *
 * Sumber utama: equran.id v2 (Arab Utsmani + latin + terjemahan Indonesia
 * Kemenag + audio per ayat 5 imam + audio full surah).
 * Sumber tafsir: equran.id v2 tafsir (Kemenag Indonesia).
 *
 * Endpoint:
 *  ?list=1                → daftar 114 surah + daftar 21 imam pilihan
 *  ?surah=2               → ayat-ayat surah Al-Baqarah (+global ayah utk audio CDN)
 *  ?surah=2&tafsir=1      → + tafsir Kemenag per ayat
 *
 * Audio per ayat (imam pilihan lengkap) dibangun client dari
 * https://cdn.islamic.network/quran/audio/128/{imam}/{globalAyah}.mp3
 * memakai nomor ayat global yang sudah dihitung server di sini.
 */

/** Jumlah ayat per surah (1..114) — untuk hitung nomor ayat GLOBAL. */
const AYAT_PER_SURAH = [
  7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
  112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53,
  89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 22, 24, 13, 14, 11, 11, 18, 12,
  12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26,
  30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6,
];

/** 15 imam TERSEDIA (perbaikan #3 zuperupdt — uji langsung 2026-09-19):
 *  6 imam lama DIHAPUS karena mati di SEMUA sumber (403 cdn.islamic.network
 *  dan tidak tersedia di everyayah/equran): ibrahimakhbar, aymanswoaid,
 *  parhizgar, ahmedibrahim, alkrasan, abdullahbasfar. Sisanya terverifikasi
 *  punya minimal satu sumber audio per-ayat yang sehat. */
export const IMAM_LIST = [
  { id: "ar.alafasy", name: "Mishary Rashid Alafasy" },
  { id: "ar.abdulbasitmurattal", name: "Abdul Basit Abdus Samad (Murattal)" },
  { id: "ar.abdurrahmaansudais", name: "Abdurrahman As-Sudais" },
  { id: "ar.husary", name: "Mahmoud Khalil Al-Husary" },
  { id: "ar.husarymujawwad", name: "Al-Husary (Mujawwad)" },
  { id: "ar.mahermuaiqly", name: "Maher Al Muaiqly" },
  { id: "ar.minshawi", name: "Mohamed Siddiq Al-Minshawi" },
  { id: "ar.minshawimujawwad", name: "Al-Minshawi (Mujawwad)" },
  { id: "ar.shaatree", name: "Abu Bakr Ash-Shaatree" },
  { id: "ar.hudhaify", name: "Ali Al-Hudhaify" },
  { id: "ar.muhammadayyoub", name: "Muhammad Ayyoub" },
  { id: "ar.muhammadjibreel", name: "Muhammad Jibreel" },
  { id: "ar.ahmedajamy", name: "Ahmed Al Ajamy" },
  { id: "ar.hanirifai", name: "Hani Ar-Rifai" },
  { id: "ar.abdulsamad", name: "Abdul Basit (Mujawwad)" },
];

const CACHE = new Map<string, { at: number; data: unknown }>();
const LIST_TTL = 24 * 60 * 60 * 1000;
const AYAT_TTL = 6 * 60 * 60 * 1000;

interface EqSurahList {
  code?: number;
  data?: Array<{
    nomor: number;
    nama: string;
    namaLatin: string;
    jumlahAyat: number;
    tempatTurun: string;
    arti: string;
    deskripsi?: string;
    audioFull?: Record<string, string>;
  }>;
}

interface EqSurahDetail {
  code?: number;
  data?: {
    nomor: number;
    nama: string;
    namaLatin: string;
    jumlahAyat: number;
    tempatTurun: string;
    arti: string;
    deskripsi?: string;
    audioFull?: Record<string, string>;
    ayat: Array<{
      nomorAyat: number;
      teksArab: string;
      teksLatin: string;
      teksIndonesia: string;
      audio?: Record<string, string>;
    }>;
  };
}

interface EqTafsir {
  code?: number;
  data?: { tafsir: Array<{ ayat: number; teks: string }> };
}

function globalAyahNumber(surah: number, ayat: number): number {
  let n = 0;
  for (let i = 0; i < surah - 1 && i < AYAT_PER_SURAH.length; i++) n += AYAT_PER_SURAH[i];
  return n + ayat;
}

/** Nama qari audioFull equran.id (6 kunci: 01..06 — "06" Yasser Al-Dosari
 *  kini tersedia di API equran.id, terverifikasi 2026-09-19). */
const EQ_AUDIO_NAMES: Record<string, string> = {
  "01": "Abdullah Al-Juhany",
  "02": "Abdul Muhsin Al-Qasim",
  "03": "Abdurrahman as-Sudais",
  "04": "Ibrahim Al-Dossari",
  "05": "Misyari Rasyid Al-Afasy",
  "06": "Yasser Al-Dosari",
};

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`quran:${ip}`, 40, 60 * 1000).ok) {
    return tooManyResponse("Kebanyakan request — tunggu sebentar");
  }

  const sp = req.nextUrl.searchParams;
  const H = { Accept: "application/json" };

  /* ---- daftar surah ---- */
  if (sp.get("list")) {
    const hit = CACHE.get("list");
    if (hit && Date.now() - hit.at < LIST_TTL) {
      return Response.json({ ok: true, ...(hit.data as Record<string, unknown>), cached: true });
    }
    try {
      const res = await fetch("https://equran.id/api/v2/surat", {
        headers: H,
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error("up");
      const d = (await res.json()) as EqSurahList;
      const surahs = (d.data || []).map((s) => ({
        nomor: s.nomor,
        nama: s.nama,
        namaLatin: s.namaLatin,
        jumlahAyat: s.jumlahAyat,
        tempatTurun: s.tempatTurun,
        arti: s.arti,
        deskripsi: s.deskripsi?.slice(0, 400) || null,
        audioFull: s.audioFull || null,
      }));
      const out = {
        total: surahs.length,
        surahs,
        imamPerAyat: IMAM_LIST,
        imamAudioFull: Object.entries(EQ_AUDIO_NAMES).map(([key, name]) => ({ key, name })),
      };
      CACHE.set("list", { at: Date.now(), data: out });
      return Response.json({ ok: true, ...out });
    } catch {
      return Response.json({ ok: false, error: "Gagal memuat daftar surah — coba lagi" }, { status: 502 });
    }
  }

  /* ---- detail surah ---- */
  const nomor = Number(sp.get("surah"));
  if (Number.isFinite(nomor) && nomor >= 1 && nomor <= 114) {
    const wantTafsir = sp.get("tafsir") === "1";
    const key = `s${nomor}${wantTafsir ? "t" : ""}`;
    const hit = CACHE.get(key);
    if (hit && Date.now() - hit.at < AYAT_TTL) {
      return Response.json({ ok: true, ...(hit.data as Record<string, unknown>), cached: true });
    }
    try {
      const [resS, resT] = await Promise.all([
        fetch(`https://equran.id/api/v2/surat/${nomor}`, { headers: H, signal: AbortSignal.timeout(20000) }),
        wantTafsir
          ? fetch(`https://equran.id/api/v2/tafsir/${nomor}`, { headers: H, signal: AbortSignal.timeout(20000) })
          : Promise.resolve(null),
      ]);
      if (!resS.ok) throw new Error("up");
      const d = (await resS.json()) as EqSurahDetail;
      if (!d.data?.ayat) throw new Error("empty");

      const tafsirMap = new Map<number, string>();
      if (resT && resT.ok) {
        const t = (await resT.json()) as EqTafsir;
        for (const item of t.data?.tafsir || []) tafsirMap.set(item.ayat, item.teks);
      }

      const out = {
        surah: {
          nomor: d.data.nomor,
          nama: d.data.nama,
          namaLatin: d.data.namaLatin,
          jumlahAyat: d.data.jumlahAyat,
          tempatTurun: d.data.tempatTurun,
          arti: d.data.arti,
          deskripsi: d.data.deskripsi?.slice(0, 600) || null,
          audioFull: d.data.audioFull || null,
        },
        imamPerAyat: IMAM_LIST,
        imamAudioFull: Object.entries(EQ_AUDIO_NAMES).map(([k, n]) => ({ key: k, name: n })),
        ayat: d.data.ayat.map((a) => ({
          nomorAyat: a.nomorAyat,
          globalAyah: globalAyahNumber(d.data.nomor, a.nomorAyat),
          teksArab: a.teksArab,
          teksLatin: a.teksLatin,
          teksIndonesia: a.teksIndonesia,
          tafsir: tafsirMap.get(a.nomorAyat) || null,
          /** URL audio per-ayat untuk 5 imam equran.id */
          audio: a.audio || null,
        })),
      };
      CACHE.set(key, { at: Date.now(), data: out });
      return Response.json({ ok: true, ...out });
    } catch {
      return Response.json({ ok: false, error: "Gagal memuat surah — coba lagi" }, { status: 502 });
    }
  }

  return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
}
