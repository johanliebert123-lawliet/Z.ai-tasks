import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";
import { fetchStreamOrNull, restream } from "@/lib/stream-fetch";

export const runtime = "nodejs";

/**
 * PERBAIKAN (permintaan #1 lama — "imam lagi bermasalah"):
 *   audio di-STREAM lewat route ini (same-origin — bebas CORS).
 *
 * PERBARUAN zuperupdt (permintaan #3 — " Qur'an player lambat & lagu terpotong"):
 *  a. AKAR "lagu terpotong": fetch memakai AbortSignal.timeout(25dtk) yang
 *     memutus BODY yang sedang mengalir → audio full-surah berhenti di detik
 *     25. Sekarang timer hanya sampai header diterima (connect timeout sejati,
 *     helper stream-fetch) → audio mengalir sampai tuntas.
 *  b. AKAR "lambat": beberapa imam populer dijawab 403 oleh
 *     cdn.islamic.network (hasil uji langsung 2026-09-19: Sudais, Basit
 *     Murattal, Minshawi Mujawwad, Hanan Rifai, Abdul Basit Mujawwad) padahal
 *     setiap request kandidat PERTAMA selalu ke sana → tiap ayat buang satu
 *     roundtrip. Sekarang urutan kandidat PER-IMAM: sumber yang terbukti
 *     sehat didahulukan (peta PRIORITY_SOURCE di bawah).
 *  c. 6 imam yang mati di SEMUA sumber (403 islamic.network + tidak ada di
 *     everyayah) DIHAPUS dari daftar (lihat route /api/quran):
 *     ibrahimakhbar, aymanswoaid, parhizgar, ahmedibrahim, alkrasan,
 *     abdullahbasfar.
 *  d. Fallback equran.id audio-partial diperluas (Sudais + Alafasy).
 */

/** Folder everyayah.com per imam (terverifikasi tersedia). */
const EVERYAYAH: Record<string, string> = {
  "ar.alafasy": "Alafasy_128kbps",
  "ar.abdulbasitmurattal": "Abdul_Basit_Murattal_64kbps",
  "ar.abdurrahmaansudais": "Abdurrahmaan_As-Sudais_192kbps",
  "ar.husary": "Husary_128kbps",
  "ar.husarymujawwad": "Husary_Mujawwad_64kbps",
  "ar.mahermuaiqly": "MaherAlMuaiqly128kbps",
  "ar.minshawi": "Minshawy_Murattal_128kbps",
  "ar.minshawimujawwad": "Minshawy_Mujawwad_64kbps",
  "ar.shaatree": "Abu_Bakr_Ash-Shaatree_128kbps",
  "ar.hudhaify": "Hudhaify_128kbps",
  "ar.muhammadayyoub": "Muhammad_Ayyoub_128kbps",
  "ar.muhammadjibreel": "Muhammad_Jibreel_64kbps",
  "ar.hanirifai": "Hani_Rifai_192kbps",
  "ar.abdulsamad": "Abdul_Basit_Mujawwad_128kbps",
};

/** Imam cdn.islamic.network yang punya audio FULL surah 128kbps. */
const ISLAMIC_NET_FULL = new Set([
  "ar.alafasy", "ar.husary", "ar.hudhaify",
  "ar.minshawi", "ar.shaatree", "ar.mahermuaiqly",
  "ar.muhammadayyoub",
]);

/** Map imam → qari audio-partial equran.id (kunci 01..06). */
const EQ_PARTIAL: Record<string, string> = {
  "ar.abdurrahmaansudais": "03",
  "ar.alafasy": "05",
};

const EQ_PARTIAL_QARI: Record<string, string> = {
  "01": "Abdullah-Al-Juhany",
  "02": "Abdul-Muhsin-Al-Qasim",
  "03": "Abdurrahman-as-Sudais",
  "04": "Ibrahim-Al-Dossari",
  "05": "Misyari-Rasyid-Al-Afasi",
  "06": "Yasser-Al-Dosari",
};

/**
 * PERBARUAN #3b: imam yang dijawab 403 oleh cdn.islamic.network (uji langsung
 * 2026-09-19). Untuk imam ini sumber PERTAMA adalah everyayah.com supaya
 * tidak ada roundtrip terbuang per ayat (inilah biang "player lambat").
 */
const ISLAMIC_NET_403 = new Set([
  "ar.abdulbasitmurattal",
  "ar.abdurrahmaansudais",
  "ar.minshawimujawwad",
  "ar.hanirifai",
  "ar.abdulsamad",
]);

/** Cache negatif jangka pendek: kandidat yang barusan gagal tidak dicoba
 *  ulang selama 10 menit (menghemat roundtrip untuk imam bermasalah). */
const NEG_CACHE = new Map<string, number>();
const NEG_TTL = 10 * 60 * 1000;
function negRecent(key: string): boolean {
  const at = NEG_CACHE.get(key);
  return !!at && Date.now() - at < NEG_TTL;
}

const pad3 = (n: number) => String(n).padStart(3, "0");

/** Jumlah ayat per surah (1..114) — untuk hitung nomor ayat GLOBAL. */
const AYAT_PER_SURAH = [
  7, 286, 200, 176, 120, 165, 206, 75, 129, 109, 123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
  112, 78, 118, 64, 77, 227, 93, 88, 69, 60, 34, 30, 73, 54, 45, 83, 182, 88, 75, 85, 54, 53,
  89, 59, 37, 35, 38, 29, 18, 45, 60, 49, 62, 55, 78, 96, 29, 58, 24, 13, 14, 11, 11, 18, 12,
  12, 30, 52, 52, 44, 28, 28, 20, 56, 40, 31, 50, 40, 46, 42, 29, 19, 36, 25, 22, 17, 19, 26,
  30, 20, 15, 21, 11, 8, 8, 19, 5, 8, 8, 11, 11, 8, 3, 9, 5, 4, 7, 3, 6, 3, 5, 4, 5, 6,
];

/** Ambil kandidat URL untuk satu ayat, urut prioritas PER-IMAM (perbaikan #3b). */
function perAyahCandidates(imam: string, surah: number, ayat: number): string[] {
  let global = ayat;
  for (let i = 0; i < surah - 1 && i < AYAT_PER_SURAH.length; i++) global += AYAT_PER_SURAH[i];

  const islamic = `https://cdn.islamic.network/quran/audio/128/${imam}/${global}.mp3`;
  const everyayah = EVERYAYAH[imam]
    ? `https://everyayah.com/data/${EVERYAYAH[imam]}/${pad3(surah)}${pad3(ayat)}.mp3`
    : null;
  const eq = EQ_PARTIAL[imam]
    ? `https://cdn.equran.id/audio-partial/${EQ_PARTIAL_QARI[EQ_PARTIAL[imam]]}/${pad3(surah)}${pad3(ayat)}.mp3`
    : null;

  // imam yang 403 di islamic.network → everyayah dulu (hemat 1 roundtrip/ayat)
  if (ISLAMIC_NET_403.has(imam)) {
    const c: string[] = [];
    if (everyayah) c.push(everyayah);
    c.push(islamic);
    if (eq) c.push(eq);
    return c;
  }
  const c = [islamic];
  if (everyayah) c.push(everyayah);
  if (eq) c.push(eq);
  return c;
}

/** Host yang diizinkan untuk mode full-surah (URL dari equran.id API). */
const FULL_ALLOWED = /^(cdn\.equran\.id|cdn\.islamic\.network)$/;

function headersFor(target: URL): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": UA_DESKTOP,
    Accept: "audio/mpeg, audio/*;q=0.9, */*;q=0.5",
    "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
  };
  if (/islamic\.network|equran\.id$/.test(target.hostname)) {
    h.Referer = "https://equran.id/";
  } else if (/everyayah\.com$/.test(target.hostname)) {
    h.Referer = "https://everyayah.com/";
  }
  return h;
}

/** Coba satu URL; sukses = Response streaming dengan header audio.
 *  PERBARUAN #3a: timer hanya sampai header (body bebas mengalir) —
 *  inilah perbaikan "lagu/audio terpotong". */
async function tryStream(url: string, range: string | undefined): Promise<Response | null> {
  if (negRecent(url)) return null;
  const upstream = await fetchStreamOrNull(url, {
    headers: headersFor(new URL(url)),
    redirect: "follow",
    connectTimeoutMs: 12000,
    range,
  });
  if (!upstream) {
    NEG_CACHE.set(url, Date.now());
    if (NEG_CACHE.size > 400) {
      // pangkas cache negatif lama
      const cut = Date.now() - NEG_TTL;
      for (const [k, at] of NEG_CACHE) if (at < cut) NEG_CACHE.delete(k);
    }
    return null;
  }
  return restream(upstream, { "Cache-Control": "public, max-age=86400" });
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`quran-audio:${ip}`, 90, 60 * 1000).ok) {
    return tooManyResponse("Terlalu banyak request audio — tunggu sebentar");
  }

  const sp = req.nextUrl.searchParams;
  const range = req.headers.get("range") || undefined;

  /* ---- mode FULL SURAH: proxy URL audio-full equran (host diizinkan saja) ---- */
  if (sp.get("full")) {
    const raw = sp.get("url") || "";
    let target: URL;
    try {
      target = new URL(raw);
    } catch {
      return Response.json({ ok: false, error: "URL audio tidak valid" }, { status: 400 });
    }
    if (!/^https:$/.test(target.protocol) || !FULL_ALLOWED.test(target.hostname)) {
      return Response.json({ ok: false, error: "Sumber audio full-surah tidak diizinkan" }, { status: 400 });
    }
    const res = await tryStream(target.toString(), range);
    if (res) return res;
    // cadangan: audio-surah islamic.network bila imam tersedia
    const imam = sp.get("imam") || "";
    const surah = Number(sp.get("surah"));
    if (ISLAMIC_NET_FULL.has(imam) && Number.isFinite(surah) && surah >= 1 && surah <= 114) {
      const res2 = await tryStream(`https://cdn.islamic.network/quran/audio-surah/128/${imam}/${surah}.mp3`, range);
      if (res2) return res2;
    }
    return Response.json({ ok: false, error: "Audio full surah gagal dimuat dari semua sumber" }, { status: 502 });
  }

  /* ---- mode PER AYAT ---- */
  const imam = (sp.get("imam") || "").slice(0, 40);
  const surah = Number(sp.get("surah"));
  const ayat = Number(sp.get("ayat"));
  if (!/^[a-z]{2}\.[a-z]+$/i.test(imam) || !Number.isFinite(surah) || surah < 1 || surah > 114 || !Number.isFinite(ayat) || ayat < 1 || ayat > 286) {
    return Response.json({ ok: false, error: "Parameter audio tidak valid" }, { status: 400 });
  }

  for (const cand of perAyahCandidates(imam, surah, ayat)) {
    const res = await tryStream(cand, range);
    if (res) return res;
  }
  return Response.json({ ok: false, error: "Audio ayat ini gagal dimuat dari semua sumber — coba imam lain." }, { status: 502 });
}
