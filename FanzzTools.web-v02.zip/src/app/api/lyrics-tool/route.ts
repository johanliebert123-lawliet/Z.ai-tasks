import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * "Lyrics Music Python" — pencarian lirik lagu lengkap (permintaan #14).
 * Sumber: LRCLIB (gratis, tanpa kunci) — lirik polos + lirik tersinkron
 * per nada/panjang lagu (timestamp per baris, format LRC).
 *
 * Endpoint:
 *   ?q=<judul/artis>          → daftar lagu
 *   ?id=<id lagurclib>        → lirik lengkap (plain + synced)
 */

interface TrackHit {
  id: number;
  name: string;
  artistName: string;
  albumName?: string;
  duration?: number;
  instrumental?: boolean;
}

async function lrcGet(path: string): Promise<unknown | null> {
  try {
    const res = await fetch(`https://lrclib.net${path}`, {
      headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (text.trimStart().startsWith("<")) return null;
    return JSON.parse(text);
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`lyr:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 120);
  const id = (req.nextUrl.searchParams.get("id") || "").trim();

  /* ---- detail lirik ---- */
  if (id) {
    if (!/^\d+$/.test(id)) {
      return Response.json({ ok: false, error: "ID lagu tidak valid" }, { status: 400 });
    }
    const d = (await lrcGet(`/api/get/${id}`)) as Record<string, unknown> | null;
    if (!d || !d.id) {
      return Response.json({ ok: false, error: "Lirik tidak ditemukan" }, { status: 404 });
    }
    return Response.json({
      ok: true,
      track: {
        id: d.id,
        name: d.trackName || d.name || "",
        artistName: d.artistName || "",
        albumName: d.albumName || "",
        duration: d.duration,
        instrumental: Boolean(d.instrumental),
      },
      plainLyrics: typeof d.plainLyrics === "string" ? d.plainLyrics : "",
      syncedLyrics: typeof d.syncedLyrics === "string" ? d.syncedLyrics : "",
    });
  }

  /* ---- pencarian ---- */
  if (!q) {
    return Response.json({ ok: false, error: "Ketik judul lagu atau nama artis" }, { status: 400 });
  }

  const hits = (await lrcGet(`/api/search?q=${encodeURIComponent(q)}`)) as Array<Record<string, unknown>> | null;
  if (!hits || !Array.isArray(hits)) {
    return Response.json(
      { ok: false, error: "Pencarian lirik gagal — coba beberapa saat lagi." },
      { status: 502 }
    );
  }

  const tracks: TrackHit[] = hits.slice(0, 20).map((h) => ({
    id: Number(h.id),
    name: String(h.trackName || h.name || ""),
    artistName: String(h.artistName || ""),
    albumName: h.albumName ? String(h.albumName) : undefined,
    duration: h.duration ? Number(h.duration) : undefined,
    instrumental: Boolean(h.instrumental),
  }));

  return Response.json({ ok: true, query: q, count: tracks.length, tracks });
}
