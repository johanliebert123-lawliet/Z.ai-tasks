import { NextRequest } from "next/server";
import crypto from "crypto";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { isPrivateHost } from "@/lib/validate";

export const runtime = "nodejs";
export const maxDuration = 30;

/**
 * ScreenshotOne — tangkapan layar situs untuk alat keamanan (FanzSec-Update).
 *
 * Proxy SERVER-SIDE ke https://api.screenshotone.com/take.
 *
 * Mengapa proxy (bukan panggil langsung dari browser):
 *  - ACCESS_KEY/SECRET_KEY TIDAK PERNAH dikirim ke browser (server-side only)
 *  - validasi URL + anti-SSRF (host internal/lokal ditolak) tetap di tangan kita
 *  - rate-limit per IP + wajib sesi login
 *
 * Kejujuran (no fake):
 *  - Bila SCREENSHOTONE_ACCESS_KEY belum di-set → 501 SCREENSHOT_NOT_CONFIGURED
 *    (TIDAK pernah menggambar/menipu gambar placeholder "berhasil").
 *  - Bila upstream gagal → 502 dengan pesan apa adanya.
 *
 * Kontrak upstream (api.screenshotone.com, dari dokumen publik):
 *  GET /take?access_key=...&url=...&viewport_width=...&format=jpg&...
 *  - sukses → bytes gambar (Content-Type image/*)
 *  - gagal  → status 4xx + body teks/JSON berisi keterangan
 *  Permintaan bertanda tangan: tambah param `signature` = HMAC-SHA256 dari
 *  query-string (tanpa signature) memakai SECRET_KEY. Bila SECRET_KEY tidak
 *  di-set, permintaan dikirim tanpa tanda tangan (mode access_key saja).
 */

const ACCESS_KEY = process.env.SCREENSHOTONE_ACCESS_KEY || "";
const SECRET_KEY = process.env.SCREENSHOTONE_SECRET_KEY || "";
const BASE = "https://api.screenshotone.com/take";

/** Query ScreenshotOne yang kita kunci untuk keamanan biaya & hasil konsisten. */
function buildParams(url: string): URLSearchParams {
  const p = new URLSearchParams({
    access_key: ACCESS_KEY,
    url,
    // viewport & render
    viewport_width: "1280",
    viewport_height: "800",
    device_scale_factor: "1",
    format: "jpg",
    image_quality: "80",
    response_type: "image",
    // cache di sisi ScreenshotOne hemat kuota; timeout & delay wajar
    cache: "true",
    timeout: "20",
    delay: "0",
    full_page: "false",
  });
  if (SECRET_KEY) {
    // signature = HMAC-SHA256(query tanpa signature) — protokol ScreenshotOne
    const sig = crypto.createHmac("sha256", SECRET_KEY).update(p.toString()).digest("hex");
    p.set("signature", sig);
  }
  return p;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  // 6 tangkapan per menit per IP — screenshot mahal di kuota upstream
  if (!rateLimit(`shot:${ip}`, 6, 60 * 1000).ok) {
    return tooManyResponse("Batas tangkapan layar tercapai — tunggu sebentar");
  }

  // validasi input DULU (sebelum cek konfigurasi) — input jahat ditolak
  // bahkan saat fitur belum dikonfigurasi
  const raw = (req.nextUrl.searchParams.get("url") || "").trim();
  if (!raw || raw.length > 500) {
    return Response.json({ ok: false, error: "URL tidak valid" }, { status: 400 });
  }

  let target: URL;
  try {
    target = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
  } catch {
    return Response.json({ ok: false, error: "URL tidak bisa dibaca" }, { status: 400 });
  }
  if (target.protocol !== "https:" && target.protocol !== "http:") {
    return Response.json({ ok: false, error: "Hanya http/https" }, { status: 400 });
  }
  // ANTI-SSRF: host internal/lokal/private tidak boleh dipotret
  if (isPrivateHost(target.hostname)) {
    return Response.json({ ok: false, error: "Host internal/lokal tidak diizinkan" }, { status: 400 });
  }

  if (!ACCESS_KEY) {
    return Response.json(
      {
        ok: false,
        error: "SCREENSHOT_NOT_CONFIGURED",
        message:
          "Fitur tangkapan layar belum dikonfigurasi. Admin harus menyetel SCREENSHOTONE_ACCESS_KEY (lihat SCREENSHOTONE-SETUP.md). Tanpa kunci, tangkapan layar tidak dibuat-buat.",
      },
      { status: 501 }
    );
  }

  try {
    const upstream = await fetch(`${BASE}?${buildParams(target.toString()).toString()}`, {
      headers: { Accept: "image/*,application/json" },
      signal: AbortSignal.timeout(25000),
    });

    const ct = upstream.headers.get("content-type") || "";
    if (upstream.ok && ct.startsWith("image/")) {
      const bytes = new Uint8Array(await upstream.arrayBuffer());
      if (bytes.length < 64) {
        // gambar mustahil sekecil ini → dianggap gagal, jangan kirim sampah
        return Response.json(
          { ok: false, error: "Tangkapan layar kosong dari upstream" },
          { status: 502 }
        );
      }
      return new Response(bytes, {
        status: 200,
        headers: {
          "Content-Type": ct,
          "Cache-Control": "private, max-age=300",
          "X-Screenshot-Source": "screenshotone",
        },
      });
    }

    // gagal — baca keterangan error (di-crop, tidak panjang; TIDAK berisi kunci)
    const detail = (await upstream.text()).slice(0, 220).replace(/access_key=[^&\s]+/g, "access_key=***");
    return Response.json(
      { ok: false, error: `ScreenshotOne menolak (HTTP ${upstream.status})`, detail },
      { status: 502 }
    );
  } catch (e) {
    const msg = e instanceof Error && e.name === "TimeoutError" ? "Tangkapan layar timeout" : "Gagal menghubungi ScreenshotOne";
    return Response.json({ ok: false, error: msg }, { status: 502 });
  }
}
