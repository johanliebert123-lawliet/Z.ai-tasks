import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { isPrivateHost } from "@/lib/validate";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Cek Keamanan Website (V2 Modern-UpdSec) — pemindai header & konfigurasi
 * yang SUPER KETAT dan transparan. Semua pengecekan bersifat pasif
 * (hanya membaca respons HTTP publik) — tidak melakukan eksploitasi.
 *
 * 18+ pemeriksaan:
 *  1.  HTTPS wajib + redirect http→https
 *  2.  HSTS (max-age ideal ≥ 1 tahun + includeSubDomains + preload)
 *  3.  X-Frame-Options / CSP frame-ancestors (clickjacking)
 *  4.  X-Content-Type-Options: nosniff
 *  5.  Referrer-Policy
 *  6.  Content-Security-Policy (ada / kualitas: unsafe-inline/eval/object)
 *  7.  Permissions-Policy
 *  8.  Cookie: HttpOnly / Secure / SameSite
 *  9.  Banner versi (Server / X-Powered-By / X-AspNet-Version)
 *  10. Mixed content (resource http:// di halaman https)
 *  11. CORS reflektif / wildcard pada Origin asing
 *  12. Form action tidak aman (http://)
 *  13. X-XSS-Protection (legacy, bobot kecil)
 *  14. COOP / CORP / COEP (isolasi lintas-origin)
 *  15. security.txt (/.well-known/security.txt)
 *  16. robots.txt & sitemap.xml (info keterbukaan)
 *  17. Iklan fingerprint (meta) — info teknologi via generator
 *  18. Cache-Control pada halaman HTML dinamis (no-store untuk data sensitif)
 *
 * Skor: 0-100 berbobot + grade A+ … F + rekomendasi per temuan.
 */

interface Finding {
  id: string;
  name: string;
  status: "pass" | "warn" | "fail" | "info";
  weight: number;
  score: number; // 0..1 dari bobot
  detail: string;
  fix?: string;
}

const UA = UA_DESKTOP;

async function safeFetch(url: string, extraHeaders: Record<string, string> = {}, timeoutMs = 15000) {
  try {
    return await fetch(url, {
      headers: { "User-Agent": UA, Accept: "text/html,*/*;q=0.8", ...extraHeaders },
      redirect: "manual",
      signal: AbortSignal.timeout(timeoutMs),
    });
  } catch {
    return null;
  }
}

function parseCookies(res: Response) {
  const raw = res.headers.getSetCookie?.() || [];
  return raw.map((c) => ({
    name: c.split("=")[0]?.trim() || "cookie",
    httpOnly: /;\s*httponly/i.test(c),
    secure: /;\s*secure/i.test(c),
    sameSite: (/;\s*samesite=([^;]+)/i.exec(c)?.[1] || "").trim(),
  }));
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`secscan:${ip}`, 8, 60 * 1000).ok) {
    return tooManyResponse("Batas pemindaian tercapai — tunggu sebentar");
  }

  const raw = (req.nextUrl.searchParams.get("url") || "").trim();
  if (!raw || raw.length > 500) {
    return Response.json({ ok: false, error: "URL tidak valid" }, { status: 400 });
  }

  let target: URL;
  try {
    target = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
  } catch {
    return Response.json({ ok: false, error: "URL tidak bisa dibaca" }, { status: 400 });
  }
  if (target.protocol !== "https:" && target.protocol !== "http:") {
    return Response.json({ ok: false, error: "Hanya http/https" }, { status: 400 });
  }
  if (isPrivateHost(target.hostname)) {
    return Response.json({ ok: false, error: "Host internal/lokal tidak diizinkan" }, { status: 400 });
  }

  // ---- 1. respons utama (follow redirect manual, max 5) ----
  let hops = 0;
  let cur = target;
  let res = await safeFetch(cur.toString());
  const redirectChain: string[] = [];
  while (res && [301, 302, 303, 307, 308].includes(res.status) && hops < 5) {
    const loc = res.headers.get("location");
    if (!loc) break;
    redirectChain.push(`${res.status} → ${loc.slice(0, 120)}`);
    const next = new URL(loc, cur);
    if (isPrivateHost(next.hostname)) break;
    cur = next;
    res = await safeFetch(cur.toString());
    hops++;
  }
  if (!res) {
    return Response.json({ ok: false, error: "Host tidak merespons / timeout" }, { status: 502 });
  }

  const finalUrl = cur;
  const isHttps = finalUrl.protocol === "https:";
  const h = res.headers;
  const findings: Finding[] = [];
  const add = (f: Finding) => findings.push(f);

  const html = /html/i.test(h.get("content-type") || "") ? await res.text().catch(() => "") : "";

  // 1. HTTPS
  if (isHttps) {
    // cek redirect http → https
    const httpProbe = await safeFetch(`http://${finalUrl.host}${finalUrl.pathname}`);
    const redirectsUp = httpProbe ? [301, 302, 303, 307, 308].includes(httpProbe.status) : false;
    if (redirectsUp || httpProbe === null) {
      add({ id: "https", name: "HTTPS + redirect otomatis", status: "pass", weight: 14, score: 1, detail: `Halaman disajikan via HTTPS${redirectsUp ? " dan HTTP otomatis dialihkan ke HTTPS" : ""}.` });
    } else {
      add({ id: "https", name: "HTTPS aktif, HTTP tidak dialihkan", status: "warn", weight: 14, score: 0.6, detail: "HTTPS jalan, tapi versi http:// masih bisa diakses tanpa pengalihan — pengguna bisa ter-hijack di jaringan publik.", fix: "Pasang redirect 301 dari http:// ke https:// di server/CDN." });
    }
  } else {
    add({ id: "https", name: "TIDAK memakai HTTPS", status: "fail", weight: 14, score: 0, detail: "Seluruh trafik plaintext — bisa disadap & dimodifikasi di jaringan.", fix: "Pasang sertifikat TLS (Let's Encrypt gratis) + paksa HTTPS." });
  }

  // 2. HSTS
  const hsts = h.get("strict-transport-security") || "";
  if (hsts) {
    const maxAge = Number(/max-age=(\d+)/i.exec(hsts)?.[1] || 0);
    const hasSub = /includesubdomains/i.test(hsts);
    const hasPreload = /preload/i.test(hsts);
    const skor = (maxAge >= 31536000 ? 0.7 : maxAge >= 15552000 ? 0.5 : 0.3) + (hasSub ? 0.15 : 0) + (hasPreload ? 0.15 : 0);
    add({
      id: "hsts", name: "Strict-Transport-Security",
      status: skor >= 0.85 ? "pass" : skor >= 0.5 ? "warn" : "fail",
      weight: 8, score: skor,
      detail: `max-age=${Math.round(maxAge / 86400)} hari${hasSub ? " + includeSubDomains" : ""}${hasPreload ? " + preload" : ""}.`,
      fix: skor < 0.85 ? "Naikkan max-age ≥ 31536000, tambah includeSubDomains; preload bila yakin semua subdomain siap HTTPS." : undefined,
    });
  } else {
    add({ id: "hsts", name: "HSTS tidak ada", status: "fail", weight: 8, score: 0, detail: "Browser tidak diinstruksikan memakai HTTPS — downgrade attack (SSL-strip) mungkin.", fix: "Kirim header Strict-Transport-Security: max-age=31536000; includeSubDomains." });
  }

  // 3. Clickjacking
  const xfo = h.get("x-frame-options") || "";
  const csp = h.get("content-security-policy") || "";
  const fa = /frame-ancestors/i.test(csp);
  if (fa || /deny|sameorigin/i.test(xfo)) {
    add({ id: "clickjack", name: "Proteksi clickjacking", status: "pass", weight: 8, score: fa ? 1 : 0.85, detail: fa ? "CSP frame-ancestors aktif (proteksi modern)." : `X-Frame-Options: ${xfo}.` });
  } else {
    add({ id: "clickjack", name: "Bisa di-iframe situs lain", status: "fail", weight: 8, score: 0, detail: "Tanpa X-Frame-Options/CSP frame-ancestors — rentan clickjacking/UI redress.", fix: "Tambah X-Frame-Options: SAMEORIGIN atau CSP frame-ancestors 'self'." });
  }

  // 4. nosniff
  const nosniff = (h.get("x-content-type-options") || "").toLowerCase() === "nosniff";
  add({
    id: "nosniff", name: "X-Content-Type-Options",
    status: nosniff ? "pass" : "fail", weight: 5, score: nosniff ? 1 : 0,
    detail: nosniff ? "nosniff aktif." : "Browser boleh menebak tipe konten (MIME-sniffing) — file upload bisa dieksekusi.",
    fix: nosniff ? undefined : "Kirim header X-Content-Type-Options: nosniff.",
  });

  // 5. Referrer-Policy
  const rp = h.get("referrer-policy") || "";
  const rpGood = ["no-referrer", "strict-origin-when-cross-origin", "same-origin", "strict-origin"].includes(rp);
  add({
    id: "refpol", name: "Referrer-Policy",
    status: rpGood ? "pass" : rp ? "warn" : "fail", weight: 4, score: rpGood ? 1 : rp ? 0.5 : 0,
    detail: rp ? `Kebijakan: ${rp}.` : "Tidak diatur — URL lengkap bocor ke situs pihak ketiga via Referer.",
    fix: rpGood ? undefined : "Tambah Referrer-Policy: strict-origin-when-cross-origin.",
  });

  // 6. CSP kualitas
  if (csp) {
    let skor = 0.55;
    const notes: string[] = [];
    if (!/script-src[^;]*'unsafe-inline'/i.test(csp) && !/default-src[^;]*'unsafe-inline'/i.test(csp)) { skor += 0.2; } else notes.push("unsafe-inline pada script");
    if (!/script-src[^;]*'unsafe-eval'/i.test(csp)) { skor += 0.1; } else notes.push("unsafe-eval");
    if (/object-src[^;]*'none'/i.test(csp)) skor += 0.08;
    if (/base-uri/i.test(csp)) skor += 0.04;
    skor = Math.min(1, skor);
    add({
      id: "csp", name: "Content-Security-Policy",
      status: skor >= 0.8 ? "pass" : "warn", weight: 10, score: skor,
      detail: `CSP ada (${csp.length} karakter)${notes.length ? ` — catatan: ${notes.join(", ")}` : " — konfigurasi cukup ketat"}.`,
      fix: skor < 0.8 ? "Hindari unsafe-inline/eval di script-src, tambah object-src 'none' + base-uri." : undefined,
    });
  } else {
    add({ id: "csp", name: "Content-Security-Policy tidak ada", status: "fail", weight: 10, score: 0, detail: "Tanpa CSP, XSS punya ruang lebar: skrip eksternal & inline apa pun boleh jalan.", fix: "Terapkan CSP bertahap: default-src 'self'; lalu perketat dengan nonce/hash." });
  }

  // 7. Permissions-Policy
  const pp = h.get("permissions-policy") || "";
  add({
    id: "permpol", name: "Permissions-Policy",
    status: pp ? "pass" : "warn", weight: 3, score: pp ? 1 : 0,
    detail: pp ? `Aktif: ${pp.slice(0, 120)}` : "API sensitif (kamera/mikrofon/geolokasi) tidak dibatasi per-iframe.",
    fix: pp ? undefined : "Tambah Permissions-Policy: camera=(), microphone=(), geolocation=().",
  });

  // 8. Cookies
  const cookies = parseCookies(res);
  if (cookies.length) {
    const bad = cookies.filter((c) => !c.httpOnly || !c.secure || !c.sameSite);
    const ratio = 1 - bad.length / cookies.length;
    add({
      id: "cookies", name: "Keamanan cookie",
      status: ratio === 1 ? "pass" : ratio >= 0.5 ? "warn" : "fail", weight: 7, score: ratio,
      detail: `${cookies.length} cookie — ${bad.length ? `${bad.length} lemah: ${bad.slice(0, 4).map((c) => c.name).join(", ")}` : "semua berflag HttpOnly/Secure/SameSite"}.`,
      fix: bad.length ? "Set semua cookie dengan HttpOnly; Secure; SameSite=Lax/Strict." : undefined,
    });
  } else {
    add({ id: "cookies", name: "Tidak ada cookie di respons", status: "info", weight: 3, score: 1, detail: "Tidak ada cookie yang di-set pada halaman utama — tidak ada yang perlu dinilai." });
  }

  // 9. Banner versi
  const banners = ["server", "x-powered-by", "x-aspnet-version", "x-aspnetmvc-version"]
    .map((k) => h.get(k) ? `${k}: ${h.get(k)}` : null)
    .filter(Boolean) as string[];
  add({
    id: "banner", name: "Pengungkapan versi teknologi",
    status: banners.length ? "warn" : "pass", weight: 4, score: banners.length ? 0.2 : 1,
    detail: banners.length ? banners.join(" · ") : "Tidak membocorkan Server / X-Powered-By.",
    fix: banners.length ? "Matikan banner: poweredByHeader off (Next.js), ServerTokens Prod (Apache), server_tokens off (nginx)." : undefined,
  });

  // 10. Mixed content
  if (isHttps && html) {
    const mixed = (html.match(/(?:src|href)=["']http:\/\/[^"']+/gi) || []).length;
    add({
      id: "mixed", name: "Mixed content (HTTP di halaman HTTPS)",
      status: mixed === 0 ? "pass" : "fail", weight: 6, score: mixed === 0 ? 1 : 0,
      detail: mixed === 0 ? "Semua resource dari HTTPS." : `${mixed} resource masih dimuat lewat http:// — bisa dimodifikasi penyerang (contoh injeksi skrip di jaringan publik).`,
      fix: mixed ? "Ganti semua URL resource ke https:// (atau protokol-relatif //host/path)." : undefined,
    });
  } else {
    add({ id: "mixed", name: "Mixed content", status: "info", weight: 3, score: 1, detail: "Halaman tidak HTTPS — pengecekan mixed content tidak relevan." });
  }

  // 11. CORS
  const corsProbe = await safeFetch(finalUrl.toString(), { Origin: "https://evil-fanzz-probe.example" });
  const acao = corsProbe?.headers.get("access-control-allow-origin") || "";
  const refl = acao === "https://evil-fanzz-probe.example";
  const star = acao === "*";
  add({
    id: "cors", name: "CORS",
    status: refl ? "fail" : star ? "warn" : "pass", weight: 5, score: refl ? 0 : star ? 0.4 : 1,
    detail: refl ? "Origin ASING dipantulkan di Access-Control-Allow-Origin — API/data bisa dibaca situs lain." : star ? "ACAO: * (publik penuh) — aman hanya bila memang API publik tanpa data sensitif." : acao ? `ACAO: ${acao}` : "Tidak membuka CORS untuk origin asing.",
    fix: refl ? "Validasi whitelist origin — jangan pantulkan Origin header." : undefined,
  });

  // 12. Form action http
  if (html) {
    const badForms = (html.match(/<form[^>]+action=["']http:\/\/[^"']+/gi) || []).length;
    add({
      id: "form", name: "Form submit aman",
      status: badForms ? "fail" : "pass", weight: 5, score: badForms ? 0 : 1,
      detail: badForms ? `${badForms} form mengirim data ke http:// (plaintext).` : "Semua form mengirim ke HTTPS / relatif.",
      fix: badForms ? "Ubah action form ke https://." : undefined,
    });
  } else {
    add({ id: "form", name: "Form submit aman", status: "info", weight: 2, score: 1, detail: "Halaman bukan HTML — dilewati." });
  }

  // 13. X-XSS-Protection
  const xxss = h.get("x-xss-protection") || "";
  add({
    id: "xxssp", name: "X-XSS-Protection (legacy)",
    status: xxss ? "info" : "info", weight: 2, score: xxss ? 1 : 0.8,
    detail: xxss ? `${xxss} (usang di browser modern, CSP yang penting).` : "Tidak ada — header ini sudah usang, CSP jadi penggantinya (bukan temuan serius).",
  });

  // 14. COOP/CORP/COEP
  const coop = h.get("cross-origin-opener-policy") || "";
  const corp = h.get("cross-origin-resource-policy") || "";
  add({
    id: "coop", name: "Isolasi lintas-origin (COOP/CORP)",
    status: coop && corp ? "pass" : coop || corp ? "warn" : "warn", weight: 3,
    score: coop && corp ? 1 : coop || corp ? 0.6 : 0.3,
    detail: `COOP: ${coop || "—"} · CORP: ${corp || "—"}. Melindungi dari tabnabbing & Spectre cross-origin.`,
    fix: "Tambah COOP same-origin dan CORP sesuai kebutuhan embedding.",
  });

  // 15. security.txt
  const secTxt = await safeFetch(new URL("/.well-known/security.txt", finalUrl).toString(), {}, 8000);
  add({
    id: "sectxt", name: "security.txt",
    status: secTxt?.ok ? "pass" : "info", weight: 2, score: secTxt?.ok ? 1 : 0.5,
    detail: secTxt?.ok ? "Ditemukan /.well-known/security.txt — kanal laporan kerentanan jelas." : "Tidak ada /.well-known/security.txt (opsional — nilai tambah keamanan).",
  });

  // 16. robots & sitemap (info)
  const robots = await safeFetch(new URL("/robots.txt", finalUrl).toString(), {}, 8000);
  add({
    id: "robots", name: "robots.txt",
    status: robots?.ok ? "info" : "info", weight: 1, score: 1,
    detail: robots?.ok ? "robots.txt ada (indeks mesin pencari diatur)." : "robots.txt tidak ada — semua halaman bisa diindeks.",
  });

  // 17. Teknologi via generator meta
  const gen = /<meta[^>]+name=["']generator["'][^>]+content=["']([^"']+)/i.exec(html)?.[1];
  add({
    id: "generator", name: "Meta generator",
    status: gen ? "warn" : "pass", weight: 2, score: gen ? 0.3 : 1,
    detail: gen ? `Membocorkan teknologi: ${gen.slice(0, 80)} — membantu penyerang mencari CVE spesifik versi.` : "Tidak membocorkan generator.",
    fix: gen ? "Hapus meta name=generator dari <head>." : undefined,
  });

  // 18. Cache-Control HTML dinamis
  const cc = h.get("cache-control") || "";
  const hasSessionCookie = cookies.some((c) => /sess|token|auth|sid/i.test(c.name));
  add({
    id: "cache", name: "Cache-Control",
    status: !hasSessionCookie || /no-store|no-cache|private/i.test(cc) ? "pass" : "warn",
    weight: 3, score: !hasSessionCookie || /no-store|no-cache|private/i.test(cc) ? 1 : 0.3,
    detail: hasSessionCookie ? `Halaman dengan cookie sesi — cache: ${cc || "(tidak diatur)"}.` : `cache-control: ${cc || "(tidak diatur)"}.`,
    fix: hasSessionCookie && !/no-store|private/i.test(cc) ? "Halaman ber-session harus no-store/private supaya tak tersimpan di cache bersama." : undefined,
  });

  // ---- skor akhir ----
  const totalWeight = findings.reduce((n, f) => n + f.weight, 0);
  const earned = findings.reduce((n, f) => n + f.weight * f.score, 0);
  const score = Math.round((earned / totalWeight) * 100);
  const grade =
    score >= 95 ? "A+" : score >= 90 ? "A" : score >= 80 ? "B" : score >= 70 ? "C" : score >= 55 ? "D" : score >= 40 ? "E" : "F";

  const passCount = findings.filter((f) => f.status === "pass").length;
  const warnCount = findings.filter((f) => f.status === "warn").length;
  const failCount = findings.filter((f) => f.status === "fail").length;

  return Response.json({
    ok: true,
    target: finalUrl.toString(),
    scannedAt: Date.now(),
    redirectChain,
    httpStatus: res.status,
    title: (/html/i.test(h.get("content-type") || "") ? /<title[^>]*>([^<]*)/i.exec(html)?.[1] : "") || null,
    score,
    grade,
    summary: { pass: passCount, warn: warnCount, fail: failCount, total: findings.length },
    findings,
    serverHeader: h.get("server") || null,
    poweredBy: h.get("x-powered-by") || null,
  });
}
