import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

const API = "https://api.internal.temp-mail.io/api/v3";

function headers() {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let cors = "";
  for (let i = 0; i < 15; i++)
    cors += chars.charAt(Math.floor(Math.random() * chars.length));
  return {
    Accept: "application/json",
    "Application-Name": "web",
    "Application-Version": "4.0.0",
    "X-CORS-Header": cors,
    "User-Agent": UA_DESKTOP,
    Referer: "https://temp-mail.io/",
  };
}

function stripHtml(html: string): string {
  return html
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function extractOtp(text: string): string | null {
  if (!text) return null;
  // pola kode dengan pemisah
  const spaced = text.match(/\b(\d{3}[-\s]\d{3})\b/);
  if (spaced) return spaced[1].replace(/[-\s]/g, "");
  // pola keyword + angka
  const kw = text.match(
    /(?:kode|code|otp|pin|verifikasi|verification)[^0-9a-zA-Z]{0,20}([0-9A-Z]{4,8})\b/i
  );
  if (kw) return kw[1];
  // 6 digit berdiri sendiri (bukan tahun)
  const bare = text.match(/\b(\d{6})\b/);
  if (bare && !/^(19|20)\d{4}$/.test(bare[1])) return bare[1];
  return null;
}

function extractVerifyLink(html: string, text: string): string | null {
  const candidates: Array<{ url: string; score: number }> = [];
  const push = (url: string, base: number) => {
    const u = url.replace(/&amp;/g, "&");
    const low = u.toLowerCase();
    let score = base;
    if (/verify|confirm|activate|login|magic|reset|auth|token|code=|key=/.test(low))
      score += 15;
    if (/unsubscribe|keluar|news|social|facebook|twitter|instagram|tiktok/i.test(low))
      score -= 50;
    if (score > 0) candidates.push({ url: u, score });
  };

  const hrefs = [...html.matchAll(/href=["']([^"']+)["']/g)].map((m) => m[1]);
  for (const h of hrefs) {
    if (/^https?:\/\//.test(h)) push(h, 5);
  }
  const bare = text.match(/https?:\/\/[^\s<>"]+/g) || [];
  for (const b of bare) push(b, 5);

  candidates.sort((a, b) => b.score - a.score);
  return candidates[0]?.url || null;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`inbox:${ip}`, 200, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const email = (req.nextUrl.searchParams.get("email") || "").trim().toLowerCase();
  if (
    !/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email) ||
    email.length > 100
  ) {
    return Response.json({ ok: false, error: "Email tidak valid" }, { status: 400 });
  }

  try {
    const res = await fetch(`${API}/email/${encodeURIComponent(email)}/messages`, {
      headers: headers(),
      cache: "no-store",
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) {
      // code 101 "Email not found" = inbox masih kosong (email virtual sebelum pesan pertama masuk)
      let code = 0;
      try {
        code = (await res.json())?.code || 0;
      } catch {
        /* ignore */
      }
      if (res.status === 400 && code === 101) {
        return Response.json({ ok: true, email, total: 0, messages: [] });
      }
      throw new Error(`temp-mail ${res.status}`);
    }
    const msgs = (await res.json()) as Array<{
      id: string;
      from: string;
      subject: string;
      bodyText?: string;
      bodyHtml?: string;
      createdAt: string;
      attachmentsSize?: number;
    }>;

    const list = (msgs || []).slice(0, 25).map((m) => {
      const html = m.bodyHtml || "";
      const text = m.bodyText || stripHtml(html);
      return {
        id: m.id,
        from: m.from || "(tidak diketahui)",
        subject: m.subject || "(tanpa subjek)",
        preview: text.slice(0, 180),
        date: m.createdAt,
        otp: extractOtp(`${m.subject}\n${text}`),
        verifyLink: extractVerifyLink(html, text),
      };
    });

    return Response.json({ ok: true, email, total: list.length, messages: list });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal cek inbox" },
      { status: 502 }
    );
  }
}
