import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

const API = "https://api.internal.temp-mail.io/api/v3";

function headers() {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  let cors = "";
  for (let i = 0; i < 15; i++)
    cors += chars.charAt(Math.floor(Math.random() * chars.length));
  return {
    "Content-Type": "application/json",
    "Application-Name": "web",
    "Application-Version": "4.0.0",
    "X-CORS-Header": cors,
    "User-Agent": UA_DESKTOP,
    Referer: "https://temp-mail.io/",
  };
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`mail:${ip}`, 15, 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Terlalu sering bikin email, tunggu sebentar" },
      { status: 429 }
    );
  }

  // body opsional: { min, max } buat panjang nama
  let min = 10,
    max = 12;
  try {
    const b = (await req.json()) as { min?: number; max?: number };
    if (b?.min) min = Math.max(8, Math.min(20, Number(b.min)));
    if (b?.max) max = Math.max(min, Math.min(24, Number(b.max)));
  } catch {
    /* default */
  }

  try {
    const res = await fetch(`${API}/email/new`, {
      method: "POST",
      headers: headers(),
      body: JSON.stringify({ min_name_length: min, max_name_length: max }),
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) throw new Error(`temp-mail ${res.status}`);
    const d = await res.json();
    if (!d?.email) throw new Error("Gagal membuat email");
    return Response.json({ ok: true, email: d.email, token: d.token || null });
  } catch (e) {
    return Response.json(
      {
        ok: false,
        error:
          e instanceof Error
            ? `Gagal membuat email sementara: ${e.message}`
            : "Gagal membuat email sementara",
      },
      { status: 502 }
    );
  }
}
