import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";

export const runtime = "nodejs";

/**
 * Jadwal Sholat (V2 Modern-UpdSec).
 *
 * Sumber: Aladhan API (gratis, tanpa kunci) — metode 20 = KEMENAG Indonesia,
 * madzhab Syafi'i (school=0). Hasil di-cache 30 menit di server supaya
 * hemat dan cepat.
 *
 * Endpoint:
 *  ?lat=-6.2&lon=106.82            → jadwal hari ini + info hari ini/hijriah
 *  ?lat=..&lon=..&date=DD-MM-YYYY   → jadwal tanggal tertentu
 */

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 30 * 60 * 1000;

interface AladhanResp {
  code?: number;
  data?: {
    timings?: Record<string, string>;
    date?: {
      readable?: string;
      hijri?: { date?: string; day?: string; month?: { en?: string; ar?: string }; year?: string };
      gregorian?: { date?: string; weekday?: { en?: string } };
    };
    meta?: { timezone?: string; method?: { name?: string } };
  };
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`prayer:${ip}`, 30, 60 * 1000).ok) {
    return tooManyResponse("Kebanyakan request — tunggu sebentar");
  }

  const sp = req.nextUrl.searchParams;
  const lat = Number(sp.get("lat"));
  const lon = Number(sp.get("lon"));
  const date = (sp.get("date") || "").trim();

  if (!Number.isFinite(lat) || !Number.isFinite(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return Response.json({ ok: false, error: "Koordinat tidak valid" }, { status: 400 });
  }
  if (date && !/^\d{2}-\d{2}-\d{4}$/.test(date)) {
    return Response.json({ ok: false, error: "Format tanggal harus DD-MM-YYYY" }, { status: 400 });
  }

  const key = `${lat.toFixed(3)},${lon.toFixed(3)},${date}`;
  const hit = CACHE.get(key);
  if (hit && Date.now() - hit.at < TTL) {
    return Response.json({ ok: true, ...(hit.data as Record<string, unknown>), cached: true });
  }

  const datePath = date || new Date().toISOString().slice(0, 10).split("-").reverse().join("-");
  const url = `https://api.aladhan.com/v1/timings/${datePath}?latitude=${lat}&longitude=${lon}&method=20&school=0`;

  try {
    const res = await fetch(url, {
      headers: { Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return Response.json({ ok: false, error: "Sumber jadwal tidak merespons" }, { status: 502 });
    const d = (await res.json()) as AladhanResp;
    if (d?.code !== 200 || !d.data?.timings) {
      return Response.json({ ok: false, error: "Jadwal tidak ditemukan untuk lokasi ini" }, { status: 404 });
    }

    const t = d.data.timings;
    const pick = (k: string) => (t[k] || "").split(" ")[0]; // buang "(WIB)" dst.

    const out = {
      timings: {
        subuh: pick("Fajr"),
        terbit: pick("Sunrise"),
        dzuhur: pick("Dhuhr"),
        ashar: pick("Asr"),
        maghrib: pick("Maghrib"),
        isya: pick("Isha"),
        imsak: pick("Imsak"),
        tengahMalam: pick("Midnight"),
      },
      raw: t,
      date: {
        gregorian: d.data.date?.gregorian?.date || null,
        readable: d.data.date?.readable || null,
        hijri: d.data.date?.hijri
          ? {
              date: d.data.date.hijri.date,
              day: d.data.date.hijri.day,
              month: d.data.date.hijri.month?.en,
              monthAr: d.data.date.hijri.month?.ar,
              year: d.data.date.hijri.year,
            }
          : null,
      },
      meta: {
        timezone: d.data.meta?.timezone || null,
        method: d.data.meta?.method?.name || "Kemenag Indonesia",
      },
      // koordinat Kaaba untuk arah kiblat (dihitung client dari lokasi user)
      kaaba: { lat: 21.4224779, lon: 39.8261887 },
    };

    CACHE.set(key, { at: Date.now(), data: out });
    return Response.json({ ok: true, ...out });
  } catch {
    return Response.json({ ok: false, error: "Gagal mengambil jadwal — coba lagi" }, { status: 502 });
  }
}
