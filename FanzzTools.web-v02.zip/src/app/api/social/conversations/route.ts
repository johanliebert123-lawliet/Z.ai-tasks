import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { ensureProfile, listConversations, totalUnread } from "@/lib/social-store";

export const runtime = "nodejs";

/** Daftar percakapan + jumlah belum dibaca (badge). */
export async function GET(req: Request) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = (req.headers.get("x-forwarded-for") || "anon").split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-conv:${ip}`, 120, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  ensureProfile(session);
  return Response.json({
    ok: true,
    conversations: listConversations(session.uid),
    unread: totalUnread(session.uid),
    serverTime: Date.now(),
  });
}
