import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { listGroups } from "@/lib/social-store";

export const runtime = "nodejs";

/** Daftar grup: punyaku + grup publik buat di-join. */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  /* zuperupdt #5: rate limit (celah audit — sebelumnya tanpa batas) */
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`social-groups:${ip}`, 40, 60 * 1000).ok) return tooManyResponse();
  const { mine, discover } = listGroups(session.uid);
  return Response.json({ ok: true, mine, discover });
}
