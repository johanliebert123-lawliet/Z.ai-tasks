import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { ensureProfile, updateProfile, publicProfile, totalUnread } from "@/lib/social-store";

export const runtime = "nodejs";

/** Profil sosial: pastikan terdaftar + sync lokasi/favorit + badge unread. */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-profile:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  let body: Record<string, unknown> = {};
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    /* kosong boleh */
  }

  let p = ensureProfile(session);
  const hasUpdate =
    typeof body.country === "string" ||
    typeof body.countryCode === "string" ||
    typeof body.city === "string" ||
    typeof body.bio === "string" ||
    typeof body.avatar === "string" ||
    body.avatar === null ||
    typeof body.favSong === "object" ||
    typeof body.watched === "object";

  if (hasUpdate) {
    p = updateProfile(session, {
      ...(typeof body.country === "string" ? { country: body.country } : {}),
      ...(typeof body.countryCode === "string" ? { countryCode: body.countryCode } : {}),
      ...(typeof body.city === "string" ? { city: body.city } : {}),
      ...(typeof body.bio === "string" ? { bio: body.bio } : {}),
      // V2 UpdSec: foto profil — data URL (validasi ketat di updateProfile)
      ...((typeof body.avatar === "string" || body.avatar === null) ? { avatar: body.avatar as string | null } : {}),
      ...(body.favSong && typeof body.favSong === "object"
        ? {
            favSong: {
              title: String((body.favSong as Record<string, unknown>).title || ""),
              artist: String((body.favSong as Record<string, unknown>).artist || ""),
              thumb: ((body.favSong as Record<string, unknown>).thumb as string | undefined) || undefined,
            },
          }
        : {}),
      ...(body.watched && typeof body.watched === "object"
        ? {
            watched: {
              title: String((body.watched as Record<string, unknown>).title || ""),
              poster: ((body.watched as Record<string, unknown>).poster as string | null) || null,
              type: String((body.watched as Record<string, unknown>).type || ""),
            },
          }
        : {}),
    });
  }

  // FanzSec-Update: bila avatar ditolak, gagal dengan JUJUR (bug lama:
  // ditolak diam-diam → foto "hilang" saat reload)
  const rejected = (p as { avatarRejected?: string }).avatarRejected;
  if (rejected) {
    return Response.json({ ok: false, error: rejected }, { status: 422 });
  }
  return Response.json({
    ok: true,
    profile: publicProfile(p),
    unread: totalUnread(session.uid),
  });
}

/** GET: profil sendiri + unread. */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const p = ensureProfile(session);
  const since = Number(req.nextUrl.searchParams.get("since")) || 0;
  return Response.json({
    ok: true,
    profile: publicProfile(p),
    unread: totalUnread(session.uid),
    serverTime: Date.now(),
    since,
  });
}
