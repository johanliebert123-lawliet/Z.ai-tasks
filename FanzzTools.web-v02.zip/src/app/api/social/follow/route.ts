import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { ensureProfile, toggleFollow, getProfile, publicProfile } from "@/lib/social-store";

export const runtime = "nodejs";

/** Follow / unfollow user. */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-follow:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  let body: { target?: string };
  try {
    body = (await req.json()) as { target?: string };
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const target = String(body.target || "");
  if (!target || target === session.uid) {
    return Response.json({ ok: false, error: "Target tidak valid" }, { status: 400 });
  }

  const me = ensureProfile(session);
  if (!getProfile(target)) {
    return Response.json({ ok: false, error: "User tidak ditemukan" }, { status: 404 });
  }

  const following = toggleFollow(session.uid, target);
  const t = getProfile(target);

  return Response.json({
    ok: true,
    following,
    user: t ? publicProfile(t) : null,
    me: publicProfile(me),
  });
}
