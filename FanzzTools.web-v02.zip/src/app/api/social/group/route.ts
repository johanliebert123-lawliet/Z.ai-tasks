import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import {
  createGroup, getGroup, groupMembers, getGroupMessages, sendGroupMessage,
  joinGroup, leaveGroup, setAdmin, kickMember, addMember, publicGroup,
} from "@/lib/social-store";

export const runtime = "nodejs";

/**
 * API Grup — semua operasi grup chat.
 * GET  ?gid=          → info grup + anggota + pesan (after=)
 * GET  (tanpa gid)    → (dipakai /api/social/groups)
 * POST { action: "create" | "join" | "leave" | "promote" | "demote" | "kick" | "send", ... }
 */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const gid = req.nextUrl.searchParams.get("gid");
  if (!gid) return Response.json({ ok: false, error: "gid wajib" }, { status: 400 });

  const gr = getGroup(gid);
  if (!gr) return Response.json({ ok: false, error: "Grup gak ketemu (mungkin udah dihapus)" }, { status: 404 });

  const after = req.nextUrl.searchParams.get("after");
  const messages = getGroupMessages(gid, Number(after) || 0);
  const members = groupMembers(gid) || [];
  const me = members.find((m) => m.uid === session.uid);

  return Response.json({
    ok: true,
    group: publicGroup(gr),
    you: me ? { isAdmin: me.isAdmin, isOwner: me.isOwner } : null,
    members,
    messages,
  });
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`grp:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });

  const action = String(body.action || "");
  const me = session.uid;

  switch (action) {
    case "create": {
      const name = String(body.name || "");
      const desc = body.desc ? String(body.desc) : undefined;
      const gr = createGroup(me, name, desc);
      if (!gr) return Response.json({ ok: false, error: "Nama grup minimal 3 huruf" }, { status: 400 });
      return Response.json({ ok: true, group: publicGroup(gr) });
    }
    case "join": {
      const r = joinGroup(me, String(body.gid || ""));
      if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
      return Response.json({ ok: true });
    }
    case "leave": {
      const r = leaveGroup(me, String(body.gid || ""));
      if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
      return Response.json({ ok: true });
    }
    case "promote":
    case "demote": {
      const r = setAdmin(me, String(body.gid || ""), String(body.target || ""), action === "promote");
      if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 403 });
      return Response.json({ ok: true });
    }
    case "add": {
      // V0.01 (permintaan #15): admin/owner menambahkan anggota via ID/username
      const r = addMember(me, String(body.gid || ""), String(body.target || ""));
      if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
      return Response.json({ ok: true, added: (r as { added?: string }).added });
    }
    case "kick": {
      const r = kickMember(me, String(body.gid || ""), String(body.target || ""));
      if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 403 });
      return Response.json({ ok: true });
    }
    case "send": {
      const gid = String(body.gid || "");
      const gr = getGroup(gid);
      if (!gr) return Response.json({ ok: false, error: "Grup gak ketemu" }, { status: 404 });
      if (!gr.members.includes(me)) {
        return Response.json({ ok: false, error: "Join dulu buat bisa ngirim pesan di grup ini" }, { status: 403 });
      }
      const type = String(body.type || "text");
      if (!["text", "image", "vn"].includes(type)) {
        return Response.json({ ok: false, error: "Tipe pesan tidak valid" }, { status: 400 });
      }
      const m = sendGroupMessage(me, gid, {
        type: type as "text" | "image" | "vn",
        text: body.text ? String(body.text) : undefined,
        data: body.data ? String(body.data) : undefined,
        dur: body.dur ? Number(body.dur) : undefined,
      });
      if (!m) return Response.json({ ok: false, error: "Gagal kirim pesan" }, { status: 500 });
      return Response.json({ ok: true, message: m });
    }
    default:
      return Response.json({ ok: false, error: "Action tidak dikenal" }, { status: 400 });
  }
}
