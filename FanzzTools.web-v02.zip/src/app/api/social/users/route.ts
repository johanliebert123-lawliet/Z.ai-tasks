import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import {
  ensureProfile, searchProfiles, getProfile, publicProfile,
  listFollowers, listFollowing,
} from "@/lib/social-store";

export const runtime = "nodejs";

/** Cari pengguna FanzzTools (username / negara) — email tidak pernah dibagikan. */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-users:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  ensureProfile(session);
  const q = (req.nextUrl.searchParams.get("q") || "").slice(0, 60);
  const uid = req.nextUrl.searchParams.get("uid") || "";
  const list = req.nextUrl.searchParams.get("list") || "";

  // detail satu user
  if (uid) {
    const p = getProfile(uid);
    if (!p) return Response.json({ ok: false, error: "User tidak ditemukan" }, { status: 404 });
    const me = getProfile(session.uid);

    // daftar followers / following user itu (profil publik, email tetap tersembunyi)
    if (list === "followers" || list === "following") {
      const users = list === "followers" ? listFollowers(uid) : listFollowing(uid);
      return Response.json({ ok: true, uid, list, total: users.length, users });
    }

    return Response.json({
      ok: true,
      user: publicProfile(p),
      isFollowing: Boolean(me?.following.includes(uid)),
      isFollower: Boolean(me?.followers.includes(uid)),
    });
  }

  return Response.json({ ok: true, users: searchProfiles(q, session.uid) });
}
