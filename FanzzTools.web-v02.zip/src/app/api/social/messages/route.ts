import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import {
  ensureProfile,
  getProfile,
  getMessages,
  sendMessage,
  type ChatMsgType,
} from "@/lib/social-store";

export const runtime = "nodejs";

/**
 * Pesan chat realtime (polling):
 *  GET  ?peer=<uid>&after=<id>  → pesan baru setelah id (polling 1.5–2 detik)
 *  POST { peer, type, text?, data?, dur? } → kirim pesan
 */

const MAX_DATA_LEN = 2.5 * 1024 * 1024; // 2.5MB data-URL base64 (~1.8MB file)
const MSG_LIMIT = 40;

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-msg-get:${ip}`, 240, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const peer = req.nextUrl.searchParams.get("peer") || "";
  const after = Number(req.nextUrl.searchParams.get("after")) || 0;
  if (!peer || peer === session.uid) {
    return Response.json({ ok: false, error: "Peer tidak valid" }, { status: 400 });
  }
  const peerProfile = getProfile(peer);
  if (!peerProfile) {
    return Response.json({ ok: false, error: "User tidak ditemukan" }, { status: 404 });
  }

  ensureProfile(session);
  const messages = getMessages(session.uid, peer, after);

  return Response.json({
    ok: true,
    messages: messages.slice(-MSG_LIMIT),
    peer: { uid: peerProfile.uid, username: peerProfile.username },
  });
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`soc-msg-post:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan pesan, pelan-pelan 😅" }, { status: 429 });
  }

  let body: { peer?: string; type?: string; text?: string; data?: string; dur?: number };
  try {
    body = (await req.json()) as typeof body;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const peer = String(body.peer || "");
  const type = (["text", "image", "vn"].includes(String(body.type)) ? body.type : "text") as ChatMsgType;
  const text = typeof body.text === "string" ? body.text : "";
  const data = typeof body.data === "string" ? body.data : "";
  const dur = Number(body.dur) || 0;

  if (!peer || peer === session.uid) {
    return Response.json({ ok: false, error: "Penerima tidak valid" }, { status: 400 });
  }
  if (!getProfile(peer)) {
    return Response.json({ ok: false, error: "Penerima tidak ditemukan" }, { status: 404 });
  }
  if (type === "text" && !text.trim()) {
    return Response.json({ ok: false, error: "Pesan kosong" }, { status: 400 });
  }
  if ((type === "image" || type === "vn") && (!data.startsWith("data:") || data.length > MAX_DATA_LEN)) {
    return Response.json({ ok: false, error: "File terlalu besar (maks ±1.8MB)" }, { status: 413 });
  }

  ensureProfile(session);
  const m = sendMessage(session.uid, peer, { type, text, data, dur });
  if (!m) {
    return Response.json({ ok: false, error: "Gagal mengirim" }, { status: 502 });
  }
  return Response.json({ ok: true, message: { ...m, data: undefined } });
}
