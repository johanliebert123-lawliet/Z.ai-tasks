import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Anime Sub Indo — proxy ke otakudesu via bintangapi.
 * Endpoint: ?home | ?q= | ?schedule | ?completed=&page= | ?id= | ?stream= | ?refresh=1
 *
 * V2-new (perbaikan "tidak ditemukan terus"):
 *  - ?refresh=1 melewati cache (tombol Muat ulang).
 *  - Pencarian: bila otakudesu 0 hasil, fallback ke database Jikan (MyAnimeList)
 *    supaya judul tetap ketemu (kartu Jikan → klik = cari versi sub indo otomatis).
 *  - Stream: 8 mirror diperiksa — route menandai mirror terbaik via /api/anime/resolve.
 */

const BASE = "https://bintangapi.my.id/api/nonton/otakudesu";
const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000; // 10 menit

async function proxyGet(path: string, noCache = false): Promise<Record<string, unknown> | null> {
  const cacheKey = noCache ? `#nc#${path}` : path;
  const hit = CACHE.get(cacheKey);
  if (hit && Date.now() - hit.at < TTL) return hit.data as Record<string, unknown>;

  /** zuperupdt #10 — COBA DUA KALI dengan jeda singkat.
   *  Akar "mirror tidak tersedia": bintangapi KADANG menjawab
   *  kosong/500 SEKALI (terverifikasi langsung: panggilan pertama /home
   *  → list kosong; panggilan ulang sesaat kemudian → normal). Tanpa
   *  retry, satu jawaban kosong langsung diteruskan ke view → error. */
  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) await new Promise((r) => setTimeout(r, 1200));
    try {
      const res = await fetch(BASE + path, {
        headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
        signal: AbortSignal.timeout(45000),
      });
      if (!res.ok) continue; // coba ulang
      const text = await res.text();
      if (text.trimStart().startsWith("<")) continue; // challenge/error → ulangi
      const d = JSON.parse(text);
      if (d?.success === false) continue;
      // deteksi "sukses tapi kosong" (animeList [] padahal endpoint list) → ulangi
      const data = (d?.data ?? d) as Record<string, unknown> | null;
      const list = (data?.animeList ?? (data?.ongoing as Record<string, unknown> | undefined)?.animeList ?? (data?.completed as Record<string, unknown> | undefined)?.animeList) as unknown[] | undefined;
      if (Array.isArray(list) && list.length === 0 && /home|ongoing|completed|search/.test(path) && attempt === 0) {
        continue;
      }
      CACHE.set(cacheKey, { at: Date.now(), data: d });
      return d;
    } catch {
      /* ulangi */
    }
  }
  return null;
}

/** Cek apakah respons stream punya mirror yang bisa diputar. */
function streamHasLinks(d: Record<string, unknown> | null): boolean {
  if (!d) return false;
  const data = (d.data ?? d) as Record<string, unknown>;
  const streams = (data?.streams || []) as Array<{ links?: unknown[] }>;
  const embed = String(data?.embedUrl || "");
  return Boolean(embed && /^https?:\/\//.test(embed)) || streams.some((s) => Array.isArray(s.links) && s.links.length > 0);
}

interface JikanCard {
  title: string;
  animeId: string;
  thumbnail: string | null;
  status: string;
  score: number;
  type: string;
  fromJikan: true;
}

/** Fallback pencarian via Jikan (MyAnimeList) — dipakai kalau otakudesu 0 hasil. */
async function jikanSearch(q: string): Promise<JikanCard[]> {
  try {
    const res = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(q)}&sfw=true&limit=20`, {
      headers: { Accept: "application/json", "User-Agent": UA_MOBILE },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return [];
    const d = (await res.json()) as { data?: Array<Record<string, unknown>> };
    return (d?.data || []).map((a) => ({
      title: String(a?.title || ""),
      animeId: `jikan:${a?.mal_id ?? ""}:${String(a?.title || "").slice(0, 60)}`,
      thumbnail: (a?.images?.jpg?.image_url as string) || null,
      status: a?.airing ? "Ongoing" : "Completed",
      score: Number(a?.score) || 0,
      type: String(a?.type || "TV"),
      fromJikan: true as const,
    })).filter((c) => c.title);
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`anime:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu sebentar" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;
  const noCache = sp.get("refresh") !== null;

  try {
    let d: Record<string, unknown> | null = null;

    if (sp.get("home") !== null) {
      d = await proxyGet("/home", noCache);
    } else if (sp.get("q")) {
      const q = sp.get("q")!.slice(0, 80);
      d = await proxyGet(`/search?q=${encodeURIComponent(q)}`, noCache);
      const data = (d?.data ?? d) as Record<string, unknown>;
      const list = (data?.animeList || []) as unknown[];
      // Fallback Jikan bila otakudesu tidak punya hasil — supaya judul tetap ketemu
      if (!list.length) {
        const jikan = await jikanSearch(q);
        if (jikan.length) {
          return Response.json({ ok: true, data: { query: q, animeList: jikan, fromJikan: true } });
        }
      }
    } else if (sp.get("schedule") !== null) {
      d = await proxyGet("/schedule", noCache);
    } else if (sp.get("completed") !== null) {
      const page = Math.max(1, Math.min(67, Number(sp.get("page")) || 1));
      d = await proxyGet(`/completed?page=${page}`, noCache);
    } else if (sp.get("id")) {
      d = await proxyGet(`/detail?id=${encodeURIComponent(sp.get("id")!.slice(0, 160))}`, noCache);
    } else if (sp.get("stream")) {
      const raw = sp.get("stream")!.slice(0, 200);
      // normalisasi: terima URL lengkap maupun slug polos
      const slugOnly = raw
        .replace(/^https?:\/\/[^/]+\/episode\//i, "")
        .replace(/\/+$/, "");
      const candidates = [
        raw.startsWith("http") ? raw : null,
        `https://otakudesu.blog/episode/${slugOnly}/`,
        slugOnly,
      ].filter(Boolean) as string[];

      // coba tiap format sampai stream beneran punya mirror
      for (const cand of candidates) {
        const dTry = await proxyGet(`/stream?id=${encodeURIComponent(cand)}`, noCache);
        if (streamHasLinks(dTry)) {
          d = dTry;
          break;
        }
        if (!d) d = dTry; // simpan respons pertama buat diagnostik
      }
    } else {
      return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
    }

    if (!d) {
      return Response.json(
        { ok: false, error: "Sumber anime sedang bermasalah — silakan coba lagi beberapa saat" },
        { status: 502 }
      );
    }
    return Response.json({ ok: true, data: d.data ?? d });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses permintaan" }, { status: 500 });
  }
}
