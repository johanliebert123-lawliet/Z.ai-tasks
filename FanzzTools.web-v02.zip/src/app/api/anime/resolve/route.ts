import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { resolveMirror, proxyStreamUrl } from "@/lib/mirror-resolver";

export const runtime = "nodejs";

/**
 * Resolve mirror anime (V2-new):
 *  ?url=<URL embed mirror>&referer=<halaman episode>
 *
 * Mengubah halaman embed (vidhide/filedon/odstream/dll.) menjadi URL video
 * langsung (m3u8/mp4) yang sudah di-proxy — diputar dengan NativePlayer,
 * bebas iklan, bisa diskip & diputar ulang (jawaban keluhan #5).
 */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`anires:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu" }, { status: 429 });
  }

  const url = (req.nextUrl.searchParams.get("url") || "").trim().slice(0, 500);
  const referer = (req.nextUrl.searchParams.get("referer") || "").trim().slice(0, 300) || null;
  if (!/^https?:\/\//i.test(url)) {
    return Response.json({ ok: false, error: "URL mirror tidak valid" }, { status: 400 });
  }

  try {
    const stream = await resolveMirror(url, referer);
    if (!stream) {
      return Response.json(
        {
          ok: false,
          error:
            "Mirror ini tidak dapat diubah menjadi pemutar native (sumber memblokir server). Otomatis memakai pemutar embed bawaan — atau pilih mirror lain.",
        },
        { status: 404 }
      );
    }
    return Response.json({
      ok: true,
      stream: {
        ...stream,
        playUrl: proxyStreamUrl(stream.url, referer),
      },
    });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses mirror" }, { status: 500 });
  }
}
