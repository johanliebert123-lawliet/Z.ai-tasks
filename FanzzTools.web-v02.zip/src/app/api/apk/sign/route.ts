import { NextRequest } from "next/server";
import { readFile } from "fs/promises";
import path from "path";
import * as fflate from "fflate";
import forge from "node-forge";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { buildAlignedZip, jarSignCertRsa, b64encode, sha256 } from "@/lib/apk-builder";

export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * FanzSec-Update — APK SIGNING SERVER-SIDE.
 *
 * SEBELUM (cacat serius): private key (public/apk/key.pem) bisa diunduh siapa
 * saja dari browser dan dipakai menandatangani APK apa pun — kunci lama dianggap
 * TERKOMPROMI. SEKARANG:
 *  - key.pem & cert.pem DIHAPUS dari public/
 *  - tanda tangan CERT.RSA dibuat di server lewat endpoint ini
 *  - kunci produksi bisa diset lewat env APK_SIGN_KEY_PEM + APK_SIGN_CERT_PEM
 *  - bila env tidak diset: kunci self-signed dibuat DETERMINISTIK dari
 *    HMAC(APP_SECRET, "fanzz-apk-sign-v1") — unik per deployment, tidak pernah
 *    keluar dari server, tidak perlu storage (serverless-friendly)
 *  - endpoint: wajib login (session), rate-limited, validasi struktur &
 *    identitas template (digest classes.dex), batas ukuran — TIDAK menerima
 *    APK arbitrer untuk ditandatangani
 */

const MAX_UPLOAD = 25 * 1024 * 1024; // 25 MB — cukup untuk hasil builder (template + aset user)
const MAX_ENTRIES = 400;

/** cache kunci per-instance (globalThis supaya bertahan antar invocation warm) */
interface SignMat {
  certPem: string;
  keyPem: string;
}
const g = globalThis as { __fanzzApkSignMat?: SignMat };

function deterministicKeyMaterial(): SignMat {
  if (g.__fanzzApkSignMat) return g.__fanzzApkSignMat;

  const envKey = process.env.APK_SIGN_KEY_PEM?.trim();
  const envCert = process.env.APK_SIGN_CERT_PEM?.trim();
  if (envKey && envCert) {
    g.__fanzzApkSignMat = { keyPem: envKey, certPem: envCert };
    return g.__fanzzApkSignMat;
  }

  // kunci deterministik dari APP_SECRET (server-only, ≥32 karakter)
  const secret = process.env.APP_SECRET || "";
  if (secret.trim().length < 32) {
    throw new Error("APP_SECRET wajib di-set (min 32 karakter) untuk penandatanganan APK.");
  }
  const seedMac = forge.hmac.create();
  seedMac.start("sha256", secret);
  seedMac.update("fanzz-apk-sign-v1");
  const seedHex = seedMac.digest().toHex();

  // PRNG deterministik dari seed HMAC berantai
  const prng = {
    getRandomValues: (arr: Uint8Array) => {
      let filled = 0;
      while (filled < arr.length) {
        const h = forge.hmac.create();
        h.start("sha256", secret);
        h.update(seedHex + ":" + filled);
        const bytes = forge.util.hexToBytes(h.digest().toHex());
        for (let i = 0; i < bytes.length && filled < arr.length; i++) {
          arr[filled++] = bytes[i] & 0xff;
        }
      }
      return arr;
    },
  };

  const keys = forge.pki.rsa.generateKeyPair({ bits: 2048, prng, workers: 2 });
  const cert = forge.pki.createCertificate();
  cert.publicKey = keys.publicKey;
  cert.serialNumber = seedHex.slice(0, 30);
  cert.validity.notBefore = new Date(Date.now() - 60 * 1000);
  cert.validity.notAfter = new Date(Date.now() + 30 * 365 * 24 * 60 * 60 * 1000);
  const attrs = [
    { name: "commonName", value: "FanzzTools APK Builder" },
    { name: "organizationName", value: "FanzzProject" },
    { shortName: "OU", value: "Fanzz-Dev." },
    { shortName: "C", value: "ID" },
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs);
  cert.sign(keys.privateKey, forge.md.sha256.create());

  const mat: SignMat = {
    keyPem: forge.pki.privateKeyToPem(keys.privateKey),
    certPem: forge.pki.certificateToPem(cert),
  };
  g.__fanzzApkSignMat = mat;
  return mat;
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`apksign:${ip}`, 8, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan tanda tangan — beri jeda" }, { status: 429 });
  }

  try {
    const form = await req.formData();
    const apkFile = form.get("apk");
    if (!(apkFile instanceof File)) {
      return Response.json({ ok: false, error: "Body tidak valid (apk)" }, { status: 400 });
    }
    if (apkFile.size > MAX_UPLOAD) {
      return Response.json({ ok: false, error: "APK terlalu besar (maks 25 MB)" }, { status: 413 });
    }

    const buf = new Uint8Array(await apkFile.arrayBuffer());

    // ==== validasi 1: adalah ZIP? ====
    let entries: Record<string, Uint8Array>;
    try {
      entries = fflate.unzipSync(buf);
    } catch {
      return Response.json({ ok: false, error: "Berkas bukan ZIP/APK valid" }, { status: 400 });
    }
    const names = Object.keys(entries);
    if (names.length === 0 || names.length > MAX_ENTRIES) {
      return Response.json({ ok: false, error: "Struktur APK tidak wajar (jumlah entri)" }, { status: 400 });
    }

    // ==== validasi 2: path traversal / nama berbahaya ====
    if (names.some((nm) => nm.includes("..") || nm.startsWith("/") || /^[a-z]:/i.test(nm) || nm.includes("\\"))) {
      return Response.json({ ok: false, error: "Struktur APK tidak wajar (nama entri)" }, { status: 400 });
    }

    // ==== validasi 3: struktur hasil builder FanzzTools ====
    const required = ["AndroidManifest.xml", "resources.arsc", "classes.dex", "META-INF/MANIFEST.MF", "META-INF/CERT.SF"];
    for (const r of required) {
      if (!entries[r]) {
        return Response.json({ ok: false, error: "APK tidak memiliki struktur hasil FanzzTools APK Builder" }, { status: 400 });
      }
    }
    if (entries["META-INF/CERT.RSA"]) {
      return Response.json({ ok: false, error: "APK sudah bertanda tangan — tolak input tidak dikenal" }, { status: 400 });
    }

    // ==== validasi 4: identitas template (digest classes.dex harus identik) ====
    let templateDexDigest = "";
    try {
      const templatePath = path.join(process.cwd(), "public", "apk", "template.apk");
      const templateBytes = new Uint8Array(await readFile(templatePath));
      const templateEntries = fflate.unzipSync(templateBytes);
      const td = templateEntries["classes.dex"];
      if (td) templateDexDigest = b64encode(await sha256(td));
    } catch {
      return Response.json({ ok: false, error: "Template internal tidak dapat dibaca — tanda tangan dibatalkan" }, { status: 500 });
    }
    const incomingDexDigest = b64encode(await sha256(entries["classes.dex"]));
    if (!templateDexDigest || incomingDexDigest !== templateDexDigest) {
      // classes.dex HARUS byte-identik dengan template resmi (builder menyalin apa adanya)
      return Response.json({ ok: false, error: "Identitas template tidak cocok — hanya APK hasil FanzzTools APK Builder yang ditandatangani" }, { status: 403 });
    }

    // ==== tanda tangani (server-side) ====
    const mat = deterministicKeyMaterial();
    const certRsa = jarSignCertRsa(entries["META-INF/CERT.SF"], mat.certPem, mat.keyPem);

    // ==== rakit ulang zip aligned dengan CERT.RSA ====
    const finalEntries: Array<{ name: string; data: Uint8Array; level: number }> = names
      .filter((nm) => nm !== "META-INF/MANIFEST.MF" && nm !== "META-INF/CERT.SF")
      .map((nm) => ({
        name: nm,
        data: entries[nm],
        level: nm === "resources.arsc" ? 0 : 6,
      }));
    finalEntries.unshift(
      { name: "META-INF/MANIFEST.MF", data: entries["META-INF/MANIFEST.MF"], level: 6 },
      { name: "META-INF/CERT.SF", data: entries["META-INF/CERT.SF"], level: 6 },
      { name: "META-INF/CERT.RSA", data: certRsa, level: 6 }
    );

    const signed = buildAlignedZip(finalEntries);

    // fingerprint sertifikat untuk UI (publik, bukan rahasia)
    const cert = forge.pki.certificateFromPem(mat.certPem);
    const fp = forge.pki.getPublicKeyFingerprint(cert.publicKey, { md: forge.md.sha256.create(), encoding: "hex" }).slice(0, 32);

    return new Response(signed as unknown as BodyInit, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.android.package-archive",
        "X-Cert-Fingerprint": fp,
        "Cache-Control": "no-store",
      },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Gagal menandatangani APK";
    return Response.json({ ok: false, error: msg }, { status: 500 });
  }
}
