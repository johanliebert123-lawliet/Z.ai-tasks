import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Cuaca Live (zuperupdt #17) — GRATIS, TANPA API KEY MILIK PENGGUNA.
 *
 * Endpoint:
 *   ?lat=&lon=   → cuaca sekarang + hari ini + BESOK + beberapa hari
 *   ?q=<kota>    → cari kota (geocoding)
 *
 * Rantai sumber (failover otomatis):
 *   Prakiraan : Open-Meteo (utama) → wttr.in (cadangan, format j1)
 *   Geocoding : Open-Meteo geocoding (utama) → Nominatim OSM (cadangan)
 * Kedua-duanya layanan publik gratis tanpa kunci. Bila kuota harian IP
 * server habis (429 dari Open-Meteo), pesan jujur diteruskan + cadangan
 * dipakai otomatis.
 */

const OM = "https://api.open-meteo.com/v1/forecast";
const OM_GEO = "https://geocoding-api.open-meteo.com/v1/search";
const WTTR = "https://wttr.in";
const NOMINATIM = "https://nominatim.openstreetmap.org/search";

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000; // 10 menit

interface Kota {
  nama: string;
  region: string;
  negara: string;
  lat: number;
  lon: number;
}

/* ---------------- GEOCODING (2 sumber) ---------------- */
async function geoOpenMeteo(q: string): Promise<Kota[]> {
  const res = await fetch(`${OM_GEO}?name=${encodeURIComponent(q)}&count=8&language=id&format=json`, {
    signal: AbortSignal.timeout(9000),
  });
  if (!res.ok) return [];
  const d = (await res.json()) as { results?: Array<{ name: string; latitude: number; longitude: number; country?: string; admin1?: string }> };
  return (d.results || []).map((r) => ({ nama: r.name, region: r.admin1 || "", negara: r.country || "", lat: r.latitude, lon: r.longitude }));
}

async function geoNominatim(q: string): Promise<Kota[]> {
  const res = await fetch(`${NOMINATIM}?q=${encodeURIComponent(q)}&format=json&limit=6&accept-language=id`, {
    headers: { "User-Agent": "FanzzTools-V2/2.13 (cuaca tool)" },
    signal: AbortSignal.timeout(9000),
  });
  if (!res.ok) return [];
  const d = (await res.json()) as Array<{ display_name: string; lat: string; lon: string }>;
  return (d || []).map((r) => {
    const bag = String(r.display_name || "").split(",").map((s) => s.trim());
    return {
      nama: bag[0] || q,
      region: bag[1] || "",
      negara: bag[bag.length - 1] || "",
      lat: Number(r.lat),
      lon: Number(r.lon),
    };
  }).filter((k) => Number.isFinite(k.lat) && Number.isFinite(k.lon));
}

/* ---------------- PRAKIRAAN: Open-Meteo ---------------- */
async function prakiraOpenMeteo(lat: number, lon: number): Promise<Record<string, unknown> | null> {
  const params = new URLSearchParams({
    latitude: String(lat),
    longitude: String(lon),
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,precipitation,weather_code,wind_speed_10m",
    daily: "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,precipitation_probability_max,uv_index_max",
    timezone: "auto",
    forecast_days: "6",
  });
  const res = await fetch(`${OM}?${params.toString()}`, { signal: AbortSignal.timeout(12000) });
  if (!res.ok) return null;
  const d = (await res.json()) as Record<string, unknown>;
  const cur = (d.current || {}) as Record<string, number>;
  const daily = (d.daily || {}) as Record<string, unknown>;
  if (!cur.time && cur.temperature_2m === undefined) return null;
  const harian = ((daily.time as string[]) || []).slice(0, 6).map((t, i) => ({
    tanggal: t,
    kode: Number((daily.weather_code as number[] | undefined)?.[i] ?? 0),
    max: Math.round(Number((daily.temperature_2m_max as number[] | undefined)?.[i] ?? 0)),
    min: Math.round(Number((daily.temperature_2m_min as number[] | undefined)?.[i] ?? 0)),
    hujanProb: Number((daily.precipitation_probability_max as number[] | undefined)?.[i] ?? 0),
    uv: Number((daily.uv_index_max as number[] | undefined)?.[i] ?? 0),
    sunrise: String((daily.sunrise as string[] | undefined)?.[i] || ""),
    sunset: String((daily.sunset as string[] | undefined)?.[i] || ""),
  }));
  return {
    lokasi: { lat, lon, zonaWaktu: String(d.timezone || "auto"), utcOffset: Number(d.utc_offset_seconds || 0) / 3600 },
    sekarang: {
      suhu: Math.round(Number(cur.temperature_2m ?? 0)),
      terasa: Math.round(Number(cur.apparent_temperature ?? 0)),
      lembap: Math.round(Number(cur.relative_humidity_2m ?? 0)),
      angin: Math.round(Number(cur.wind_speed_10m ?? 0)),
      hujan: Number(cur.precipitation ?? 0),
      kode: Number(cur.weather_code ?? 0),
      siang: Number(cur.is_day ?? 1) === 1,
      waktu: String(cur.time || ""),
    },
    harian,
    besok: harian[1] || null,
  };
}

/** Kode cuaca wttr.in (weatherDesc/weatherCode) → kode WMO (perkiraan terdekat). */
function wttrKeWmo(cc: Record<string, string>): number {
  const d = String(cc.weatherCode || "");
  if (d === "113") return 0; // cerah
  if (d === "116" || d === "119") return 2; // berawan sebagian/berawan
  if (d === "122" || d === "143") return 3; // overcast/kabut
  if (d === "176" || d === "263" || d === "266") return 51; // gerimis
  if (d === "293" || d === "296" || d === "299" || d === "302") return 61; // hujan ringan
  if (d === "305" || d === "308" || d === "311" || d === "314") return 63; // hujan sedang-deras
  if (d === "200") return 95; // badai
  if (/snow|ice|sleet/i.test(String(cc.weatherDesc || ""))) return 71;
  return 3;
}

/* ---------------- PRAKIRAAN: wttr.in (cadangan) ---------------- */
async function prakiraWttr(lat: number, lon: number): Promise<Record<string, unknown> | null> {
  const res = await fetch(`${WTTR}/${lat},${lon}?format=j1`, {
    headers: { "User-Agent": UA_MOBILE },
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) return null;
  const d = (await res.json()) as {
    current_condition?: Array<Record<string, string>>;
    weather?: Array<{ date: string; maxtempC: string; mintempC: string; hourly?: Array<{ chanceofrain?: string; time?: string; UVIndex?: string }> }>;
  };
  const cc = d.current_condition?.[0];
  if (!cc) return null;
  const jamSekarang = new Date().getHours();
  const harian = (d.weather || []).slice(0, 6).map((w, i) => {
    const hujanProb = Math.max(0, ...((w.hourly || []).map((h) => Number(h.chanceofrain) || 0)));
    const uv = Math.max(0, ...((w.hourly || []).map((h) => Number(h.UVIndex) || 0)));
    return {
      tanggal: w.date,
      kode: i === 0 ? wttrKeWmo(cc) : 3,
      max: Math.round(Number(w.maxtempC) || 0),
      min: Math.round(Number(w.mintempC) || 0),
      hujanProb,
      uv,
      sunrise: "",
      sunset: "",
    };
  });
  return {
    lokasi: { lat, lon, zonaWaktu: "auto (wttr.in)", utcOffset: 0 },
    sekarang: {
      suhu: Math.round(Number(cc.temp_C) || 0),
      terasa: Math.round(Number(cc.FeelsLikeC) || 0),
      lembap: Math.round(Number(cc.humidity) || 0),
      angin: Math.round(Number(cc.windspeedKmph) || 0),
      hujan: Number(cc.precipMM) || 0,
      kode: wttrKeWmo(cc),
      siang: jamSekarang >= 6 && jamSekarang < 18,
      waktu: cc.observation_time || "",
    },
    harian,
    besok: harian[1] || null,
  };
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`cuaca:${ip}`, 30, 60 * 1000).ok) return tooManyResponse();

  const sp = req.nextUrl.searchParams;

  /* ---- geocoding: cari kota (2 sumber, failover) ---- */
  const q = sp.get("q");
  if (q) {
    const key = `geo:${q.toLowerCase().slice(0, 60)}`;
    const hit = CACHE.get(key);
    if (hit && Date.now() - hit.at < 60 * 60 * 1000) {
      return Response.json({ ok: true, ...(hit.data as object) });
    }
    const bersih = q.slice(0, 60);
    let hasil: Kota[] = [];
    try { hasil = await geoOpenMeteo(bersih); } catch { /* lanjut cadangan */ }
    if (!hasil.length) {
      try { hasil = await geoNominatim(bersih); } catch { /* kedua-duanya gagal */ }
    }
    if (!hasil.length) {
      return Response.json({ ok: false, error: "Pencarian kota gagal — layanan lokasi sedang tidak terjangkau. Coba lagi atau pakai GPS." }, { status: 502 });
    }
    const out = { hasil: hasil.slice(0, 8) };
    CACHE.set(key, { at: Date.now(), data: out });
    return Response.json({ ok: true, ...out });
  }

  /* ---- cuaca per koordinat (failover Open-Meteo → wttr.in) ---- */
  const lat = Number(sp.get("lat"));
  const lon = Number(sp.get("lon"));
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return Response.json({ ok: false, error: "Koordinat tidak valid" }, { status: 400 });
  }

  const key = `w:${lat.toFixed(3)},${lon.toFixed(3)}`;
  const hit = CACHE.get(key);
  if (hit && Date.now() - hit.at < TTL) {
    return Response.json({ ok: true, ...(hit.data as object), cached: true });
  }

  let out: Record<string, unknown> | null = null;
  let sumber = "open-meteo";
  try { out = await prakiraOpenMeteo(lat, lon); } catch { out = null; }
  if (!out) {
    sumber = "wttr.in";
    try { out = await prakiraWttr(lat, lon); } catch { out = null; }
  }
  if (!out) {
    return Response.json({ ok: false, error: "Gagal memuat cuaca — kedua sumber (Open-Meteo & wttr.in) sedang tidak terjangkau atau kena batas kuota harian. Coba lagi beberapa saat." }, { status: 502 });
  }
  CACHE.set(key, { at: Date.now(), data: out });
  return Response.json({ ok: true, ...out, sumber });
}
