import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { listLocations } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/location?deviceId= — riwayat lokasi perangkat (fitur opsional). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-loc:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();
  const deviceId = (req.nextUrl.searchParams.get("deviceId") || "").slice(0, 40);
  if (!deviceId) return Response.json({ ok: false, error: "deviceId wajib" }, { status: 400 });
  return Response.json({ ok: true, locations: listLocations(session, deviceId) });
}
