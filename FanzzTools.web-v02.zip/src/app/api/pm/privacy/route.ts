import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { privacySummary, purgeData } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/privacy — Privacy Center: fitur aktif, jumlah data, retensi. */
export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  return Response.json({ ok: true, ...privacySummary(session) });
}

/** POST — hapus data ({ what: usage|location|media|alerts|all }). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-priv:${ip}`, 10, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }
  const what = String(body.what || "");
  if (!["usage", "location", "media", "alerts", "all"].includes(what)) {
    return Response.json({ ok: false, error: "Jenis data tidak dikenal" }, { status: 400 });
  }
  const r = purgeData(session, what as "usage" | "location" | "media" | "alerts" | "all");
  return Response.json({ ok: true, deleted: r.deleted });
}
