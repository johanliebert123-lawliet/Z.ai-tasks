import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { PM_CHILD_MAX_AGE, PM_ADULT_AGE, PM_ENROLL_TTL_MS, RETENTION } from "@/lib/pm-store";
import { dataDirInfo } from "@/lib/persist";
import { pgStatus, pgPing } from "@/lib/pg-bridge";

export const runtime = "nodejs";

/**
 * GET /api/pm/health — health check Parent Monitor (PUBLIK, tanpa data rumah).
 * Dipakai companion app di HP anak untuk memastikan server terjangkau
 * sebelum pairing/sinkronisasi. TIDAK membocorkan: DATABASE_URL, APP_SECRET,
 * kredensial, token, atau data household apa pun — hanya status layanan +
 * status penyimpanan + konstanta kebijakan.
 *
 * FanzSec-Update: health kini MELAKUKAN connectivity check sungguhan ke
 * database (bukan sekadar bilang "ok") dan menampilkan mode penyimpanan:
 *   storage.mode         = "database" | "memory"
 *   databaseConfigured   = DATABASE_URL di-set?
 *   databaseReady        = koneksi+query terakhir sukses?
 * Bila DATABASE_URL di-set tapi DB gagal → databaseReady=false (dan route PM
 * sensitif menolak dengan DATABASE_UNAVAILABLE — fail-closed, bukan fallback
 * diam-diam).
 */
export async function GET(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-health:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();

  const storage = dataDirInfo();
  // connectivity check NYATA (bukan sekadar flag) — dengan timeout pendek
  if (pgStatus().configured) {
    await pgPing(4000);
  }
  const pg = pgStatus();
  const mode = pg.configured ? "database" : "memory";

  return Response.json(
    {
      ok: true,
      service: "fanzz-parent-monitor",
      version: "2.12.0",
      serverTime: Date.now(),
      policy: {
        childMaxAge: PM_CHILD_MAX_AGE,
        adultAge: PM_ADULT_AGE,
        enrollmentTtlMinutes: Math.round(PM_ENROLL_TTL_MS / 60000),
        retention: RETENTION,
      },
      storage: {
        mode,
        persistent: storage.persistent,
        databaseConfigured: pg.configured,
        databaseReady: pg.ready,
        /** diagnostik umum (tanpa string koneksi/secret) */
        databaseLastError: pg.lastError ? "ada (lihat log server)" : null,
        lastDbWriteOk: pg.lastWriteOk || null,
        lastDbReadOk: pg.lastReadOk || null,
      },
      /** fitur yang TIDAK ada by design (anti-spyware) */
      forbidden: [
        "keylogger", "otp-interception", "chat-content-capture", "silent-screenshot",
        "hidden-location", "full-gallery-scrape", "remote-shell", "stealth-mode",
      ],
    },
    { headers: { "Cache-Control": "no-store" } }
  );
}
