import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { setAttestation, getHousehold, isAttested } from "@/lib/pm-store";

export const runtime = "nodejs";

/**
 * POST /api/pm/attest — pernyataan wali resmi (gate legal Parent Monitor).
 * Syarat: pengguna menyatakan diri orang tua/wali resmi dari anak sendiri,
 * anak yang dipantau berusia di bawah 18 tahun (atau masih tanggungan dan
 * menyetujui pemantauan bila sudah dewasa, maks 35 tahun), dan tool ini
 * TIDAK digunakan untuk memantau orang lain (pasangan/pekerja/orang luar).
 */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-attest:${ip}`, 10, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  if (body.confirm !== true) {
    return Response.json({ ok: false, error: "Pernyataan wali resmi belum dikonfirmasi." }, { status: 400 });
  }

  const birthYear = Number(body.parentBirthYear);
  const h = setAttestation(
    session,
    Number.isFinite(birthYear) && birthYear >= 1900 && birthYear <= new Date().getFullYear() ? Math.floor(birthYear) : undefined
  );
  return Response.json({ ok: true, attested: isAttested(h), attestation: h.attestation });
}

/** GET — status attestation saat ini. */
export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const h = getHousehold(session);
  return Response.json({ ok: true, attested: isAttested(h), attestation: h.attestation || null });
}
