import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { listMedia, deleteMedia, deleteAllMedia } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/media?deviceId= — galeri metadata+thumbnail perangkat (opsional, default OFF). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-med:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();
  const deviceId = (req.nextUrl.searchParams.get("deviceId") || "").slice(0, 40);
  if (!deviceId) return Response.json({ ok: false, error: "deviceId wajib" }, { status: 400 });
  return Response.json({ ok: true, media: listMedia(session, deviceId) });
}

/** DELETE ?id= hapus satu, atau ?deviceId=&all=1 hapus semua. */
export async function DELETE(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  const deviceId = (req.nextUrl.searchParams.get("deviceId") || "").slice(0, 40);
  const all = req.nextUrl.searchParams.get("all") !== null;
  if (id) {
    const r = deleteMedia(session, id);
    if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
    return Response.json({ ok: true });
  }
  if (deviceId && all) {
    const r = deleteAllMedia(session, deviceId);
    return Response.json({ ok: true, deleted: r.count });
  }
  return Response.json({ ok: false, error: "Parameter tidak lengkap" }, { status: 400 });
}
