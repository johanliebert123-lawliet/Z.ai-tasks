import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { overview } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/overview — dashboard bootstrap parent (household/children/devices/alerts/audit). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-ov:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();
  return Response.json({ ok: true, ...overview(session) });
}
