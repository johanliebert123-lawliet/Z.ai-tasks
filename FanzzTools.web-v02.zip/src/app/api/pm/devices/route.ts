import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { listDevices, createDevice, patchDevice, revokeDevice, deleteDevice, rotateDeviceToken, type DeviceStatus } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/devices — daftar perangkat household sendiri. */
export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const { getHousehold } = await import("@/lib/pm-store");
  const h = getHousehold(session);
  return Response.json({ ok: true, devices: listDevices(h.id) });
}

/** POST — tambah perangkat (untuk mode "Connect Existing Companion"). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-dv:${ip}`, 20, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const result = createDevice(session, String(body.childId || "").slice(0, 40), String(body.label || ""), {
    usage: body.features && typeof body.features === "object" ? (body.features as Record<string, unknown>).usage !== false : undefined,
    status: undefined,
    location: (body.features as Record<string, unknown> | undefined)?.location === true,
    media: (body.features as Record<string, unknown> | undefined)?.media === true,
  });
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true, device: result.device });
}

/** PATCH ?id= — rename / pause / resume / atur fitur / rotate token. */
export async function PATCH(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  // rotasi token perangkat (token baru dikembalikan SEKALI ini saja)
  if (body.action === "rotate-token") {
    const token = rotateDeviceToken(id);
    if (!token) return Response.json({ ok: false, error: "Perangkat tidak ditemukan." }, { status: 400 });
    return Response.json({ ok: true, token, note: "Simpan token baru di perangkat — token lama sudah tidak valid." });
  }
  if (body.action === "revoke") {
    const r = revokeDevice(session, id);
    if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
    return Response.json({ ok: true });
  }

  const f = (body.features || {}) as Record<string, unknown>;
  const result = patchDevice(session, id, {
    label: typeof body.label === "string" ? body.label : undefined,
    status: typeof body.status === "string" ? (body.status as DeviceStatus) : undefined,
    features: {
      usage: f.usage !== undefined ? f.usage === true : undefined,
      status: f.status !== undefined ? f.status === true : undefined,
      location: f.location !== undefined ? f.location === true : undefined,
      media: f.media !== undefined ? f.media === true : undefined,
    },
  });
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true });
}

/** DELETE ?id= — hapus perangkat + seluruh data monitoringnya. */
export async function DELETE(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  const result = deleteDevice(session, id);
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true });
}
