import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { authDevice, ingestUsage } from "@/lib/pm-store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/** POST /api/pm/device/usage — kirim statistik pemakaian aplikasi (idempotent upsert). */
export async function POST(req: NextRequest) {
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-usi:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const entries = Array.isArray(body.entries) ? (body.entries as Array<Record<string, unknown>>) : [];
  const r = ingestUsage(auth, {
    date: typeof body.date === "string" ? body.date : undefined,
    entries: entries.map((e) => ({
      pkg: String(e.pkg || ""),
      app: typeof e.app === "string" ? e.app : undefined,
      usageMs: Number(e.usageMs) || 0,
      launches: Number(e.launches) || 0,
    })),
  });
  return Response.json({ ok: true, count: r.count });
}
