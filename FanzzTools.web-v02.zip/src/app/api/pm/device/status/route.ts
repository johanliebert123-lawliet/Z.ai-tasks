import { NextRequest } from "next/server";
import { authDevice } from "@/lib/pm-store";
import { rateLimit } from "@/lib/store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/** GET /api/pm/device/status — konfigurasi + fitur aktif untuk companion.
 *  zuperupdt #5: rate limit ditambahkan (celah audit — sebelumnya tanpa batas). */
export async function GET(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-devstatus:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — tunggu sebentar." }, { status: 429 });
  }
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const { device, household } = auth;
  return Response.json({
    ok: true,
    device: {
      id: device.id,
      label: device.label,
      status: device.status,
      features: device.features,
      childNickname: null,
    },
    household: { name: household.name, attested: !!household.attestation },
    serverTime: Date.now(),
  });
}
