import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { authDevice, deviceDisconnect } from "@/lib/pm-store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/**
 * POST /api/pm/device/disconnect — perangkat anak memutus monitoring sendiri.
 * Hak transparansi anak: companion menampilkan tombol ini di layar utama.
 */
export async function POST(req: NextRequest) {
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-dc:${ip}`, 10, 60 * 1000).ok) return tooManyResponse();
  deviceDisconnect(auth);
  return Response.json({ ok: true });
}
