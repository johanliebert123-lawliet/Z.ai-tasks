import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { authDevice, ingestLocation } from "@/lib/pm-store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/** POST /api/pm/device/location — kirim posisi (hanya bila fitur lokasi AKTIF). */
export async function POST(req: NextRequest) {
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-loi:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const r = ingestLocation(auth, Number(body.lat), Number(body.lon), Number(body.accuracy));
  if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 403 });
  return Response.json({ ok: true });
}
