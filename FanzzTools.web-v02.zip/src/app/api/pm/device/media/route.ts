import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { authDevice, ingestMedia } from "@/lib/pm-store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/**
 * POST /api/pm/device/media — kirim metadata + thumbnail media yang DIPILIH
 * pengguna perangkat (Photo Picker) — hanya bila fitur media AKTIF.
 * Tidak ada scraping galeri diam-diam.
 */
export async function POST(req: NextRequest) {
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-mi:${ip}`, 30, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const items = Array.isArray(body.items) ? (body.items as Array<Record<string, unknown>>) : [];
  const r = ingestMedia(auth, items.map((it) => ({
    kind: it.kind === "video" ? "video" as const : "photo" as const,
    size: Number(it.size) || undefined,
    thumb: typeof it.thumb === "string" ? it.thumb : undefined,
  })));
  return Response.json({ ok: true, count: r.count });
}
