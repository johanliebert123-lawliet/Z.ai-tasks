import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { beginEnrollment, completeEnrollment, markConsentShown } from "@/lib/pm-store";

export const runtime = "nodejs";

/**
 * POST /api/pm/device/enroll — pairing 2-FASE dari perangkat anak (zuperupdt #7).
 *
 * FASE 1 (scan): body { qrPayload } ATAU { code } + { model, androidVersion, appVersion }
 *   → perangkat dibuat status PENDING_CONSENT (BELUM terhubung, TANPA token).
 *   → respons: { deviceId, consentTicket, householdName, childNickname,
 *                deviceLabel, features, consentRequired: true }
 *   Galat terstruktur: { ok:false, error:"PAIRING_EXPIRED", message:"..." }
 *   Kode galat: INVALID_QR, QR_SIGNATURE_INVALID, PAIRING_NOT_FOUND,
 *     PAIRING_EXPIRED, PAIRING_USED, PAIRING_CANCELLED, PAIRING_REJECTED,
 *     HOUSEHOLD_GONE, RATE_LIMITED, BAD_REQUEST.
 *
 * FASE 1b (opsional, dipanggil saat layar persetujuan terbuka):
 *   body { deviceId, consentTicket, action:"shown" } → status CONSENT_REQUIRED
 *   (dashboard orang tua melihat "menunggu persetujuan anak" secara live).
 *
 * FASE 2 (consent): body { deviceId, consentTicket, consent: true|false }
 *   consent:true  → status CONNECTED + token perangkat (satu kali lihat).
 *   consent:false → status REJECTED (kode mati, orang tua diberi tahu).
 *   Galat: CONSENT_INVALID, CONSENT_EXPIRED, DEVICE_NOT_PENDING, ...
 *
 * Token TIDAK PERNAH diterbitkan sebelum anak menekan "Saya Setuju" —
 * consent selalu di depan koneksi (prinsip anti-spyware).
 */
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-enroll:${ip}`, 20, 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "RATE_LIMITED", message: "Terlalu banyak percobaan pairing — tunggu sebentar." },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "BAD_REQUEST", message: "Body tidak valid." }, { status: 400 });
  }

  const deviceInfo = {
    model: typeof body.model === "string" ? body.model : undefined,
    androidVersion: typeof body.androidVersion === "string" ? body.androidVersion : undefined,
    appVersion: typeof body.appVersion === "string" ? body.appVersion : undefined,
  };

  const structuredError = (status: number, code: string, message: string) =>
    Response.json({ ok: false, error: code, message }, { status });

  /* ---------- FASE 1b / 2: consent (deviceId + consentTicket) ---------- */
  if (typeof body.deviceId === "string" && typeof body.consentTicket === "string") {
    const deviceId = body.deviceId.slice(0, 40);
    const ticket = body.consentTicket.slice(0, 200);

    if (body.action === "shown") {
      const r = markConsentShown(deviceId, ticket);
      if (!r.ok) return structuredError(400, r.error.code, r.error.message);
      return Response.json({ ok: true, status: r.data.status });
    }

    if (typeof body.consent === "boolean") {
      const r = completeEnrollment(deviceId, ticket, body.consent);
      if (!r.ok) return structuredError(400, r.error.code, r.error.message);
      const d = r.data;
      if (d.status === "rejected") {
        // anak menolak — tidak ada token, perangkat tidak terhubung
        return Response.json({
          ok: true,
          status: "rejected",
          deviceId: d.deviceId,
          householdName: d.householdName,
          childNickname: d.childNickname,
          deviceLabel: d.deviceLabel,
          features: d.features,
          message: "Koneksi ditolak. Kode pairing tidak lagi berlaku.",
        });
      }
      return Response.json({
        ok: true,
        status: "connected",
        deviceId: d.deviceId,
        token: d.token, // satu kali lihat — disimpan companion, server hanya menyimpan hash
        householdName: d.householdName,
        childNickname: d.childNickname,
        deviceLabel: d.deviceLabel,
        features: d.features,
        serverUrl: `${req.nextUrl.origin}`,
      });
    }

    return structuredError(400, "BAD_REQUEST", "Sertakan consent: true/false (atau action: \"shown\").");
  }

  /* ---------- FASE 1: scan QR / input kode ---------- */
  // QR payload boleh juga ditempel manual (hasil scan aplikasi lain) —
  // protokol kustom FANZZ-PM1|id|code|exp|sig diparse langsung di server.
  const qrPayload = typeof body.qrPayload === "string" ? body.qrPayload.slice(0, 300) : undefined;
  const code = typeof body.code === "string" ? body.code.slice(0, 24) : undefined;
  if (!qrPayload && !code) {
    return structuredError(400, "BAD_REQUEST", "Sertakan QR payload atau kode manual.");
  }

  const result = beginEnrollment({ qrPayload, code }, deviceInfo);
  if (!result.ok) {
    // kode galat CONSENT_REQUIRED tidak mungkin di fase 1 — mapping aman
    return structuredError(400, result.error.code, result.error.message);
  }

  const p = result.data;
  return Response.json({
    ok: true,
    status: "pending",
    deviceId: p.deviceId,
    consentTicket: p.consentTicket, // sekali pakai — untuk fase 2
    householdName: p.householdName,
    childNickname: p.childNickname,
    deviceLabel: p.deviceLabel,
    features: p.features,
    consentRequired: true,
    message: "Pindai berhasil. Perangkat BELUM terhubung — tekan \u201cSaya Setuju\u201d di layar berikutnya untuk menghubungkan.",
  });
}
