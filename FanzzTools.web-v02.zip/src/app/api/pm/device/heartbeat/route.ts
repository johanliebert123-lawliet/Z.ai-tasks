import { NextRequest } from "next/server";
import { rateLimit, tooManyResponse } from "@/lib/store";
import { authDevice, deviceHeartbeat } from "@/lib/pm-store";

export const runtime = "nodejs";

function bearer(req: NextRequest): string | null {
  const h = req.headers.get("authorization") || "";
  const m = /^Bearer\s+(.+)$/i.exec(h);
  return m ? m[1].trim() : null;
}

/** POST /api/pm/device/heartbeat — baterai/jaringan/permission/last-seen. */
export async function POST(req: NextRequest) {
  const auth = authDevice(bearer(req));
  if (!auth) return Response.json({ ok: false, error: "Token perangkat tidak valid / dicabut." }, { status: 401 });
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-hb:${ip}`, 120, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const r = deviceHeartbeat(auth, {
    battery: typeof body.battery === "number" ? body.battery : undefined,
    charging: typeof body.charging === "boolean" ? body.charging : undefined,
    network: typeof body.network === "string" ? body.network : undefined,
    model: typeof body.model === "string" ? body.model : undefined,
    androidVersion: typeof body.androidVersion === "string" ? body.androidVersion : undefined,
    appVersion: typeof body.appVersion === "string" ? body.appVersion : undefined,
    permissions: body.permissions && typeof body.permissions === "object" ? (body.permissions as Record<string, string>) : undefined,
  });
  return Response.json({ ok: true, paused: r.paused, features: r.features, serverTime: Date.now() });
}
