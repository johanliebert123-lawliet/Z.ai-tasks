import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { usageReport } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/usage?childId=&days=1|7|30 — laporan pemakaian aplikasi anak. */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-usg:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();

  const childId = (req.nextUrl.searchParams.get("childId") || "").slice(0, 40);
  const daysRaw = Number(req.nextUrl.searchParams.get("days"));
  const days: 1 | 7 | 30 = daysRaw === 7 || daysRaw === 30 ? daysRaw : 1;
  if (!childId) return Response.json({ ok: false, error: "childId wajib" }, { status: 400 });

  const rows = usageReport(session, childId, days);
  // ringkas per aplikasi
  const byApp = new Map<string, { pkg: string; app: string; usageMs: number; launches: number }>();
  for (const r of rows) {
    const cur = byApp.get(r.pkg) || { pkg: r.pkg, app: r.app, usageMs: 0, launches: 0 };
    cur.usageMs += r.usageMs;
    cur.launches += r.launches;
    byApp.set(r.pkg, cur);
  }
  // ringkas per hari (total)
  const byDate = new Map<string, number>();
  for (const r of rows) byDate.set(r.date, (byDate.get(r.date) || 0) + r.usageMs);

  return Response.json({
    ok: true,
    days,
    rows: rows.slice(0, 200),
    topApps: [...byApp.values()].sort((a, b) => b.usageMs - a.usageMs).slice(0, 15),
    daily: [...byDate.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(([date, usageMs]) => ({ date, usageMs })),
    totalMs: rows.reduce((s, r) => s + r.usageMs, 0),
  });
}
