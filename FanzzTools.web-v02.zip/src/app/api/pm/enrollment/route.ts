import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { generateEnrollment, cancelEnrollment, getEnrollmentStatus } from "@/lib/pm-store";

export const runtime = "nodejs";

/**
 * POST /api/pm/enrollment — buat / batalkan kode pairing.
 * QR payload: FANZZ-PM1|id|code|exp|HMAC — satu-kali-pakai, 10 menit,
 * TIDAK berisi password/token permanen/rahasia apa pun.
 */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-enr:${ip}`, 20, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const action = String(body.action || "");

  if (action === "generate") {
    // V2.12: fitur pilihan orang tua ikut dengan QR (bukan hardcoded lagi)
    const f = (body.features && typeof body.features === "object") ? body.features as Record<string, unknown> : undefined;
    const result = generateEnrollment(
      session,
      String(body.childId || "").slice(0, 40),
      String(body.deviceLabel || ""),
      {
        usage: f?.usage !== false,
        status: f?.status !== false,
        location: f?.location === true,
        media: f?.media === true,
      }
    );
    if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
    return Response.json({
      ok: true,
      enrollment: {
        id: result.enrollment.row.id,
        code: result.enrollment.code,
        qrPayload: result.enrollment.qrPayload,
        expiresAt: result.enrollment.expiresAt,
        status: "created", // zuperupdt #7: mesin status baru (dulu "waiting")
      },
    });
  }

  if (action === "cancel") {
    const r = cancelEnrollment(session, String(body.enrollmentId || "").slice(0, 40));
    if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 400 });
    return Response.json({ ok: true });
  }

  return Response.json({ ok: false, error: "Aksi tidak dikenal" }, { status: 400 });
}

/** GET ?id= — polling status pairing (dashboard). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-enrs:${ip}`, 120, 60 * 1000).ok) return tooManyResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  const r = getEnrollmentStatus(session, id);
  if (!r.ok) return Response.json({ ok: false, error: r.error }, { status: 404 });
  return Response.json({ ok: true, status: r.status, expiresAt: r.expiresAt, deviceId: r.deviceId || null, serverTime: Date.now() });
}
