import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { listChildren, createChild, updateChild, deleteChild } from "@/lib/pm-store";

export const runtime = "nodejs";

/** GET /api/pm/children — daftar anak household sendiri. */
export async function GET() {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const h = (await import("@/lib/pm-store")).getHousehold;
  const hh = h(session);
  return Response.json({ ok: true, children: listChildren(hh.id) });
}

/** POST — tambah anak (batas usia 35 tahun sesuai permintaan pemilik). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`pm-ch:${ip}`, 20, 60 * 1000).ok) return tooManyResponse();

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const result = createChild(session, {
    nickname: typeof body.nickname === "string" ? body.nickname : "",
    birthYear: body.birthYear ? Number(body.birthYear) : undefined,
    avatar: typeof body.avatar === "string" ? body.avatar : undefined,
    notes: typeof body.notes === "string" ? body.notes : undefined,
  });
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true, child: result.child, warning: result.warning || null });
}

/** PATCH ?id= — ubah anak. */
export async function PATCH(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }
  const result = updateChild(session, id, {
    nickname: typeof body.nickname === "string" ? body.nickname : undefined,
    birthYear: body.birthYear === null ? null : body.birthYear ? Number(body.birthYear) : undefined,
    avatar: body.avatar === null ? undefined : typeof body.avatar === "string" ? body.avatar : undefined,
    notes: typeof body.notes === "string" ? body.notes : undefined,
    disabled: typeof body.disabled === "boolean" ? body.disabled : undefined,
  });
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true });
}

/** DELETE ?id= — hapus anak (+ cabut semua perangkatnya). */
export async function DELETE(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  const result = deleteChild(session, id);
  if (!result.ok) return Response.json({ ok: false, error: result.error }, { status: 400 });
  return Response.json({ ok: true });
}
