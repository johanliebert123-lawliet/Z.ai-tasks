import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Info BMKG real-time — permintaan #12.
 * Sumber resmi: data.bmkg.go.id (autogempa, gempa dirasakan, gempa terkini).
 * Header browser lengkap + Referer wajib — tanpa itu BMKG menolak (403).
 */

interface Quake {
  tanggal: string;
  jam: string;
  magnitudo: string;
  kedalaman: string;
  lintang: string;
  bujur: string;
  wilayah: string;
  potensi: string;
  dirasakan?: string;
  shakemap?: string;
}

function mapQuake(g: Record<string, unknown>): Quake {
  return {
    tanggal: String(g.Tanggal || g.tanggal || ""),
    jam: String(g.Jam || g.jam || ""),
    magnitudo: String(g.Magnitude || g.magnitudo || "?"),
    kedalaman: String(g.Kedalaman || g.kedalaman || "?"),
    lintang: String(g.Lintang || g.lintang || ""),
    bujur: String(g.Bujur || g.bujur || ""),
    wilayah: String(g.Wilayah || g.wilayah || ""),
    potensi: String(g.Potensi || g.potensi || ""),
    dirasakan: g.Dirasakan ? String(g.Dirasakan) : undefined,
    shakemap: g.Shakemap
      ? `https://data.bmkg.go.id/DataMKG/TEWS/${String(g.Shakemap)}`
      : undefined,
  };
}

async function bmkgJson(path: string): Promise<Record<string, unknown> | null> {
  try {
    const res = await fetch(`https://data.bmkg.go.id/DataMKG/TEWS/${path}`, {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "application/json, text/html,application/xhtml+xml",
        "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
        Referer: "https://www.bmkg.go.id/",
      },
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (text.trimStart().startsWith("<")) return null;
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    return null;
  }
}

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 90 * 1000;

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`bmkg:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan" }, { status: 429 });
  }

  const key = "bmkg-all";
  const hit = CACHE.get(key);
  if (hit && Date.now() - hit.at < TTL) {
    return Response.json({ ok: true, ...(hit.data as object) });
  }

  const [auto, dirasakan, terkini] = await Promise.all([
    bmkgJson("autogempa.json"),
    bmkgJson("gempadirasakan.json"),
    bmkgJson("gempaterkini.json"),
  ]);

  if (!auto && !dirasakan && !terkini) {
    return Response.json(
      { ok: false, error: "Data BMKG sedang tidak dapat diambil — silakan coba beberapa saat lagi." },
      { status: 502 }
    );
  }

  const autoRaw = auto?.Infogempa as Record<string, unknown> | undefined;
  const autoGempa = autoRaw
    ? mapQuake((autoRaw.gempa as Record<string, unknown>) || autoRaw)
    : null;
  const feltList = ((dirasakan?.Infogempa as Record<string, unknown> | undefined)?.gempa || dirasakan?.Infogempa) as
    | Array<Record<string, unknown>>
    | undefined;
  const recentList = ((terkini?.Infogempa as Record<string, unknown> | undefined)?.gempa || terkini?.Infogempa) as
    | Array<Record<string, unknown>>
    | undefined;
  const felt = Array.isArray(feltList) ? feltList.slice(0, 8).map(mapQuake) : [];
  const recent = Array.isArray(recentList) ? recentList.slice(0, 12).map(mapQuake) : [];

  const payload = {
    auto: autoGempa,
    felt,
    recent,
    updatedAt: Date.now(),
  };
  CACHE.set(key, { at: Date.now(), data: payload });

  return Response.json({ ok: true, ...payload });
}
