import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";
import { fetchStream } from "@/lib/stream-fetch";

export const runtime = "nodejs";

/**
 * Proxy unduh/preview file media — PERBAIKAN V2a (route ini sebelumnya tidak ada).
 * - Mendukung HTTP Range (209/206) supaya preview video/audio dapat di-seek.
 * - Menyuntik Referer/UA yang sesuai untuk CDN yang protektif
 *   (googlevideo, tiktokcdn, aceimg, dll).
 * - Tidak pernah mengirim HTML error ke klien: bila sumber menjawab HTML
 *   (halaman challenge/404), klien menerima JSON error yang rapi.
 */

/** Host CDN → header khusus supaya file boleh diambil. */
function sourceHeaders(target: URL): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": UA_DESKTOP,
    Accept: "*/*",
    "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
  };
  const host = target.hostname;
  if (/googlevideo\.com$/.test(host)) {
    h.Referer = "https://www.youtube.com/";
    h.Origin = "https://www.youtube.com";
  } else if (/tiktokcdn|tiktok\.com|byteoversea|musicaldy/i.test(host)) {
    h.Referer = "https://www.tiktok.com/";
  } else if (/aceimg|aicdn/i.test(host)) {
    h.Referer = "https://api-faa.my.id/";
  } else if (/tikwm|tikwm\.com/i.test(host)) {
    h.Referer = "https://tikwm.com/";
  } else if (/instagram|cdninstagram|fbcdn/i.test(host)) {
    h.Referer = "https://www.instagram.com/";
  } else if (/varhad/i.test(host)) {
    h.Referer = "https://v2.api-varhad.my.id/";
  }
  return h;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`dlfile:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu sebentar" }, { status: 429 });
  }

  const url = (req.nextUrl.searchParams.get("url") || "").trim().slice(0, 800);
  const name = (req.nextUrl.searchParams.get("name") || "").slice(0, 150);
  const inline = req.nextUrl.searchParams.get("inline") !== null;

  if (!/^https?:\/\//i.test(url)) {
    return Response.json({ ok: false, error: "Tautan file tidak valid" }, { status: 400 });
  }

  let target: URL;
  try {
    target = new URL(url);
  } catch {
    return Response.json({ ok: false, error: "Tautan file tidak valid" }, { status: 400 });
  }

  const range = req.headers.get("range") || undefined;
  /** mode redirect: klien minta langsung ke URL sumber tanpa proxy */
  const direct = req.nextUrl.searchParams.get("direct") !== null;

  if (direct) {
    // arahkan browser langsung ke file sumber (CDN tertentu menolak proxy server)
    return Response.redirect(target.toString(), 302);
  }

  try {
    // PERBAIKAN "unduhan putus di tengah" (zuperupdt #3/#8): dulu
    // AbortSignal.timeout memutus body yang sedang mengalir → file besar
    // gagal di tengah jalan. fetchStream hanya membatasi waktu SAMPAI header
    // diterima; setelah itu body mengalir sampai tuntas.
    const upstream = await fetchStream(target.toString(), {
      headers: {
        ...sourceHeaders(target),
        ...(range ? { Range: range } : {}),
      },
      redirect: "follow",
      connectTimeoutMs: 25000,
    });

    // Bila sumber menjawab HTML (halaman error/challenge), jangan teruskan —
    // itulah akar pesan "error DOCTYPE" yang dulu muncul di aplikasi.
    const ct = (upstream.headers.get("content-type") || "").toLowerCase();
    if (!upstream.ok || ct.includes("text/html") || ct.includes("application/json")) {
      // PERBAIKAN V0.01: bila proxy ditolak sumber (mis. googlevideo terikat IP),
      // coba sekali lagi TANPA Referer/Origin — beberapa CDN justru menolak header itu.
      if (upstream.status === 403 && !/googlevideo\.com$/.test(target.hostname)) {
        try {
          const retry = await fetchStream(target.toString(), {
            headers: { "User-Agent": UA_DESKTOP, Accept: "*/*", ...(range ? { Range: range } : {}) },
            redirect: "follow",
            connectTimeoutMs: 25000,
          });
          const ct2 = (retry.headers.get("content-type") || "").toLowerCase();
          if (retry.ok && !ct2.includes("text/html")) {
            const h2 = new Headers();
            h2.set("Content-Type", ct2.split(";")[0] || "application/octet-stream");
            const cl2 = retry.headers.get("content-length");
            if (cl2) h2.set("Content-Length", cl2);
            const cr2 = retry.headers.get("content-range");
            if (cr2) h2.set("Content-Range", cr2);
            h2.set("Accept-Ranges", "bytes");
            h2.set("Cache-Control", "private, max-age=600");
            h2.set(
              "Content-Disposition",
              `${inline ? "inline" : "attachment"}; filename="${(name || "fanzz-media").replace(/["\\]/g, "").slice(0, 120)}"`
            );
            return new Response(retry.body, { status: retry.status === 206 ? 206 : 200, headers: h2 });
          }
        } catch {
          /* lanjut respons error rapi */
        }
      }
      return Response.json(
        { ok: false, error: `File tidak dapat diambil dari server sumber (HTTP ${upstream.status}). Silakan coba kualitas lain atau gunakan tombol unduh langsung.`, directUrl: target.toString() },
        { status: 502 }
      );
    }

    const headers = new Headers();
    headers.set("Content-Type", ct.split(";")[0] || "application/octet-stream");
    const cl = upstream.headers.get("content-length");
    if (cl) headers.set("Content-Length", cl);
    const cr = upstream.headers.get("content-range");
    if (cr) headers.set("Content-Range", cr);
    headers.set("Accept-Ranges", "bytes");
    headers.set("Cache-Control", "private, max-age=600");
    headers.set(
      "Content-Disposition",
      `${inline ? "inline" : "attachment"}; filename="${(name || "fanzz-media").replace(/["\\]/g, "").slice(0, 120)}"`
    );

    // 206 bila upstream menjawab partial (range dipenuhi)
    return new Response(upstream.body, {
      status: upstream.status === 206 ? 206 : 200,
      headers,
    });
  } catch {
    return Response.json(
      { ok: false, error: "Koneksi ke server sumber terputus — silakan coba lagi." },
      { status: 502 }
    );
  }
}
