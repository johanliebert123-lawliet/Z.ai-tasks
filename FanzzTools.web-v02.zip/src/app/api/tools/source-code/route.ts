import { NextRequest } from "next/server";
import * as cheerio from "cheerio";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { isHttpUrl, isPrivateHost } from "@/lib/validate";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Ambil Source Code Web (V2 Modern-UpdSec) — alat LEGAL untuk melihat
 * HTML/CSS/JS halaman web lain, seperti "View Page Source" / Ctrl+U.
 *
 * Prinsip:
 *  - Hanya mengambil halaman yang PUBLIK (GET tanpa kredensial).
 *  - TIDAK menembus login/paywall/apapun — bukan alat peretasan.
 *  - SSRF-guard ketat: target internal/localhost ditolak.
 *  - Hasil: struktur ringkas (judul, meta, jumlah elemen) + HTML mentah
 *    + daftar CSS/JS internal-eksternal + inline style/script.
 *
 * Endpoint: GET ?url=https://contoh.com[&mode=raw]
 */

const MAX_HTML_BYTES = 4 * 1024 * 1024; // 4 MB

interface InlineBlock {
  type: "style" | "script";
  lang?: string;
  content: string;
  bytes: number;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`srccode:${ip}`, 15, 60 * 1000).ok) {
    return tooManyResponse("Terlalu banyak permintaan ambil source — tunggu sebentar");
  }

  const raw = (req.nextUrl.searchParams.get("url") || "").trim();
  if (!raw || raw.length > 500) {
    return Response.json({ ok: false, error: "URL tidak valid" }, { status: 400 });
  }

  let target: URL;
  try {
    target = new URL(raw.startsWith("http") ? raw : `https://${raw}`);
  } catch {
    return Response.json({ ok: false, error: "URL tidak bisa dibaca" }, { status: 400 });
  }
  if (target.protocol !== "https:" && target.protocol !== "http:") {
    return Response.json({ ok: false, error: "Hanya http/https" }, { status: 400 });
  }
  if (isPrivateHost(target.hostname)) {
    return Response.json({ ok: false, error: "Host internal/lokal tidak diizinkan" }, { status: 400 });
  }

  try {
    // redirect manual dengan re-validasi SSRF tiap lompatan
    let res = await fetch(target.toString(), {
      headers: {
        "User-Agent": UA_DESKTOP,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
      },
      redirect: "manual",
      signal: AbortSignal.timeout(20000),
    });
    for (let hop = 0; [301, 302, 303, 307, 308].includes(res.status) && hop < 5; hop++) {
      const loc = res.headers.get("location");
      if (!loc) break;
      const next = new URL(loc, target);
      if (!/^https?:$/.test(next.protocol) || isPrivateHost(next.hostname)) {
        return Response.json({ ok: false, error: "Redirect ke host tidak diizinkan" }, { status: 400 });
      }
      target = next;
      res = await fetch(target.toString(), {
        headers: { "User-Agent": UA_DESKTOP, Accept: "text/html,*/*;q=0.8" },
        redirect: "manual",
        signal: AbortSignal.timeout(20000),
      });
    }

    if (!res.ok) {
      return Response.json({ ok: false, error: `Sumber menolak (HTTP ${res.status})` }, { status: 502 });
    }

    const ctype = res.headers.get("content-type") || "";
    if (!/html|xml|text\/plain/i.test(ctype) && ctype !== "") {
      return Response.json(
        { ok: false, error: `Halaman ini bukan dokumen HTML (tipe: ${ctype.split(";")[0] || "tidak diketahui"})` },
        { status: 400 }
      );
    }

    let html = await res.text();
    if (html.length > MAX_HTML_BYTES) html = html.slice(0, MAX_HTML_BYTES);

    const $ = cheerio.load(html);

    // ---- struktur ringkas ----
    const meta: Record<string, string> = {};
    $("meta").each((_, el) => {
      const key = $(el).attr("name") || $(el).attr("property") || "";
      const val = $(el).attr("content") || "";
      if (key && val && Object.keys(meta).length < 30) meta[key] = val.slice(0, 300);
    });

    const stylesheets: string[] = [];
    $('link[rel="stylesheet"]').each((_, el) => {
      const href = $(el).attr("href");
      if (href) stylesheets.push(new URL(href, target).toString().slice(0, 500));
    });

    const scripts: string[] = [];
    $("script[src]").each((_, el) => {
      const src = $(el).attr("src");
      if (src) scripts.push(new URL(src, target).toString().slice(0, 500));
    });

    const inline: InlineBlock[] = [];
    $("style, script:not([src])").each((_, el) => {
      const tag = (el as { tagName?: string }).tagName?.toLowerCase() || "";
      const content = $(el).html() || "";
      if (content.trim()) {
        inline.push({
          type: tag === "style" ? "style" : "script",
          lang: $(el).attr("type") || undefined,
          content: content.length > 30000 ? `${content.slice(0, 30000)}\n/* … terpotong (${content.length} karakter) */` : content,
          bytes: content.length,
        });
      }
      if (inline.length >= 60) return false;
    });

    const stats = {
      htmlBytes: html.length,
      htmlLines: html.split("\n").length,
      elements: $("*").length,
      images: $("img").length,
      links: $("a[href]").length,
      forms: $("form").length,
      tables: $("table").length,
      iframes: $("iframe").length,
      stylesheets: stylesheets.length,
      externalScripts: scripts.length,
      inlineBlocks: inline.length,
    };

    return Response.json({
      ok: true,
      url: target.toString(),
      finalUrl: target.toString(),
      httpStatus: res.status,
      title: ($("title").first().text() || "").trim().slice(0, 200),
      meta: {
        description: meta["description"] || meta["og:description"] || null,
        generator: meta["generator"] || null,
        viewport: meta["viewport"] || $("meta[name='viewport']").attr("content") || null,
        charset: $("meta[charset]").attr("charset") || null,
        ogImage: meta["og:image"] || null,
        themeColor: meta["theme-color"] || null,
      },
      counts: stats,
      stylesheets: stylesheets.slice(0, 40),
      scripts: scripts.slice(0, 40),
      inline: inline.slice(0, 40),
      html,
    });
  } catch {
    return Response.json({ ok: false, error: "Gagal mengambil halaman (timeout / host tidak merespons)" }, { status: 502 });
  }
}
