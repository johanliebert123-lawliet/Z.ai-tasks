import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { listStories } from "@/lib/story-store";

export const runtime = "nodejs";

/** GET /api/story/list — semua story aktif (global), milikku paling atas. */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-list:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const groups = listStories(session.uid);
  return Response.json({
    ok: true,
    groups,
    serverTime: Date.now(),
  });
}
