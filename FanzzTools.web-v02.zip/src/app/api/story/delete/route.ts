import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { deleteStory } from "@/lib/story-store";

export const runtime = "nodejs";

/** DELETE /api/story/delete?id= — hapus story milik sendiri. */
export async function DELETE(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-del:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const id = (req.nextUrl.searchParams.get("id") || "").slice(0, 40);
  const ok = deleteStory(session.uid, id);
  if (!ok) return Response.json({ ok: false, error: "Status tidak ditemukan / bukan milikmu" }, { status: 404 });
  return Response.json({ ok: true });
}
