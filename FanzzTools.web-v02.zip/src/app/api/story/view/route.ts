import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { viewStory, storyView } from "@/lib/story-store";

export const runtime = "nodejs";

/** POST /api/story/view — tandai "ditonton" + ambil story lengkap (video). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-view:${ip}`, 90, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const id = String(body.id || "").slice(0, 40);
  viewStory(session.uid, id);
  const story = storyView(id, session.uid);
  if (!story) return Response.json({ ok: false, error: "Status tidak ditemukan / kedaluwarsa" }, { status: 404 });
  return Response.json({ ok: true, story });
}
