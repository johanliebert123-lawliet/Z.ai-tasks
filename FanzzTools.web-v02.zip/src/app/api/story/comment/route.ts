import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { commentStory, getStory } from "@/lib/story-store";

export const runtime = "nodejs";

/** POST /api/story/comment — komentar di story. */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-comment:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const id = String(body.id || "").slice(0, 40);
  const text = typeof body.text === "string" ? body.text : "";
  const c = commentStory(session, id, text);
  if (!c) return Response.json({ ok: false, error: "Komentar kosong / status tidak ditemukan" }, { status: 400 });

  const s = getStory(id);
  return Response.json({ ok: true, comment: c, total: s?.comments.length || 0 });
}
