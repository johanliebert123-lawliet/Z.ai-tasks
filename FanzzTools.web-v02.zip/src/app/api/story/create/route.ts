import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { createStory, STORY_MAX_PER_USER } from "@/lib/story-store";

export const runtime = "nodejs";

/** POST /api/story/create — unggah FanzzStory (teks / video+caption / foto+musik).
 *  PERBARUAN #4: mode foto — musik latar opsional, durasi tampil 14 detik
 *  (musik dipotong 14 detik saat diputar). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-create:${ip}`, 10, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering unggah — tunggu sebentar" }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const type = body.type === "video" ? "video" : body.type === "photo" ? "photo" : "text";
  const result = createStory(session, {
    type,
    text: typeof body.text === "string" ? body.text : "",
    bg: Number(body.bg) || 0,
    data: typeof body.data === "string" ? body.data : undefined,
    music: typeof body.music === "string" ? body.music : undefined,
    // PERMINTAAN #3: videoId lagu library musik (untuk penyegaran URL audio)
    musicVideo: typeof body.musicVideo === "string" ? body.musicVideo.slice(0, 16) : undefined,
  });

  if (!result.ok) {
    return Response.json({ ok: false, error: result.error }, { status: 400 });
  }

  return Response.json({
    ok: true,
    story: { id: result.story.id, expiresAt: result.story.expiresAt },
    maxPerUser: STORY_MAX_PER_USER,
  });
}
