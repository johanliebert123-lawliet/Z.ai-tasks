import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { likeStory, getStory } from "@/lib/story-store";

export const runtime = "nodejs";

/** POST /api/story/like — like/unlike story. */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`story-like:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const id = String(body.id || "").slice(0, 40);
  const result = likeStory(session.uid, id);
  if (!result) return Response.json({ ok: false, error: "Status tidak ditemukan / sudah kedaluwarsa" }, { status: 404 });

  const s = getStory(id);
  return Response.json({ ok: true, liked: result.liked, likes: s?.likes.length || 0 });
}
