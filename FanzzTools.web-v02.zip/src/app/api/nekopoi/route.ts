import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";
import * as cheerio from "cheerio";
import { resolveMirror, proxyStreamUrl } from "@/lib/mirror-resolver";

export const runtime = "nodejs";

/**
 * Nekopoi (21+) — PERBARUAN V0.01 (permintaan #5).
 *
 * Sumber UTAMA sekarang: dixzz-neko-api (API publik rapi — latest/search/detail
 * dengan embeds + m3u8s + downloads langsung). Bila API itu gagal, otomatis
 * fallback ke scraper halaman nekopoi.care langsung (parser lama tetap dipakai).
 *
 * Konten dewasa: client WAJIB pakai gerbang verifikasi usia 21+.
 */

const BASE = "https://nekopoi.care";
const DIXZZ = "https://dixzz-neko-api.vercel.app/api";

const HEADERS: Record<string, string> = {
  "User-Agent": UA_MOBILE,
  Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
  "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
  "Sec-Fetch-Dest": "document",
  "Sec-Fetch-Mode": "navigate",
  "Sec-Fetch-Site": "none",
  "Upgrade-Insecure-Requests": "1",
};

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 5 * 60 * 1000;

async function getHtml(path: string, referer?: string): Promise<string | null> {
  try {
    const res = await fetch(BASE + path, {
      headers: { ...HEADERS, ...(referer ? { Referer: referer, "Sec-Fetch-Site": "same-origin" } : {}) },
      redirect: "follow",
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) return null;
    return await res.text();
  } catch {
    return null;
  }
}

/** Ambil JSON dari dixzz-neko-api (timeout pendek, deteksi HTML ketat). */
async function dixzz(path: string): Promise<Record<string, unknown> | null> {
  try {
    const res = await fetch(DIXZZ + path, {
      headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (text.trimStart().startsWith("<")) return null;
    const d = JSON.parse(text);
    if (d?.success === false) return null;
    return d as Record<string, unknown>;
  } catch {
    return null;
  }
}

interface NkpItem {
  title: string;
  url: string;
  thumbnail?: string | null;
  genre?: string | null;
  date?: string | null;
}

function parseList(html: string, limit = 30): NkpItem[] {
  const $ = cheerio.load(html);
  const out: NkpItem[] = [];
  const seen = new Set<string>();

  const push = (title: string, url: string, thumb?: string | null) => {
    title = title.replace(/\s+/g, " ").trim();
    if (!title || title.length < 4 || !url.includes("nekopoi")) return;
    if (/feed|hentai-list|about|contact|dmca|privacy| disclaimer/i.test(url)) return;
    const full = url.startsWith("http") ? url : BASE + url;
    if (seen.has(full)) return;
    seen.add(full);
    out.push({ title, url: full, thumbnail: thumb || null });
  };

  $("article, .post, .hentry, .box").each((_, el) => {
    const a = $(el).find("h2 a, h1 a, .entry-title a, .title a").first();
    const img = $(el).find("img").first();
    push(a.text(), a.attr("href") || "", img.attr("src") || img.attr("data-src"));
    if (out.length >= limit) return false;
  });

  if (out.length < 6) {
    $("h2 a, h3 a").each((_, a) => {
      const href = $(a).attr("href") || "";
      const img = $(a).closest("li, div, article").find("img").first();
      push($(a).text(), href, img.attr("src") || img.attr("data-src"));
      if (out.length >= limit) return false;
    });
  }
  return out.slice(0, limit);
}

/** Normalisasi item dari dixzz supaya bentuknya sama dengan parser lama. */
function dixzzItems(data: Array<Record<string, unknown>>): NkpItem[] {
  return data
    .map((d) => ({
      title: String(d.title || "").replace(/\s+/g, " ").trim(),
      url: String(d.url || ""),
      thumbnail: String(d.image || d.cover || "") || null,
      date: d.date ? String(d.date) : null,
    }))
    .filter((x) => x.title && /^https?:\/\/nekopoi/i.test(x.url))
    .slice(0, 30);
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`nkp:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu sebentar" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;
  const ckey = sp.toString();

  /* ---- zuperupdt #9 (tambahan dari tobatanj): PROXY GAMBAR ----
   * ?img=<url gambar nekopoi> — beberapa ISP/browser memblokir gambar
   * nekopoi.care langsung (hotlink protection / DNS bersih). Server
   * mengambil gambarnya lalu mengirim ulang same-origin supaya thumbnail
   * SELALU tampil. Hanya host nekopoi yang diizinkan. */
  if (sp.get("img") !== null) {
    const img = (sp.get("img") || "").slice(0, 400);
    let target: URL;
    try {
      target = new URL(img);
    } catch {
      return new Response("URL gambar tidak valid", { status: 400 });
    }
    if (!/^https?:$/.test(target.protocol) || !/nekopoi\./i.test(target.hostname)) {
      return new Response("Hanya gambar nekopoi yang diizinkan", { status: 400 });
    }
    try {
      const upstream = await fetch(target.toString(), {
        headers: { "User-Agent": UA_MOBILE, Referer: "https://nekopoi.care/", Accept: "image/*,*/*;q=0.8" },
        redirect: "follow",
        signal: AbortSignal.timeout(20000),
      });
      const ct = (upstream.headers.get("content-type") || "").toLowerCase();
      if (!upstream.ok || !ct.startsWith("image/")) {
        return new Response("Gambar tidak tersedia", { status: 502 });
      }
      const h = new Headers();
      h.set("Content-Type", ct);
      h.set("Cache-Control", "public, max-age=86400");
      return new Response(upstream.body, { status: 200, headers: h });
    } catch {
      return new Response("Gambar gagal dimuat", { status: 502 });
    }
  }

  /* ---- zuperupdt #9 (tambahan dari tobatanj): DAFTAR GENRE ----
   * ?genres=1 — daftar genre dari halaman depan (pendekatan tobatanj). */
  if (sp.get("genres") !== null) {
    const hit = CACHE.get("genres");
    if (hit && Date.now() - hit.at < 24 * 60 * 60 * 1000) {
      return Response.json({ ok: true, ...(hit.data as object) });
    }
    const html = await getHtml("/");
    if (html) {
      const $ = cheerio.load(html);
      const genres: Array<{ name: string; url: string }> = [];
      const seen = new Set<string>();
      $("a[href*='/genre/'], a[href*='?genre=']").each((_, el) => {
        const href = $(el).attr("href") || "";
        const name = $(el).text().replace(/\s+/g, " ").trim();
        if (!name || name.length > 30) return;
        const full = href.startsWith("http") ? href : BASE + href;
        const key = name.toLowerCase();
        if (seen.has(key) || !full.includes("nekopoi")) return;
        seen.add(key);
        genres.push({ name, url: full });
      });
      const out = { genres: genres.slice(0, 40) };
      if (genres.length) CACHE.set("genres", { at: Date.now(), data: out });
      return Response.json({ ok: true, ...out });
    }
    return Response.json({ ok: false, error: "Daftar genre tidak tersedia" }, { status: 502 });
  }

  try {
    const hit = CACHE.get(ckey);
    if (hit && Date.now() - hit.at < TTL && sp.get("resolve") === null) {
      return Response.json({ ok: true, ...(hit.data as object) });
    }

    let payload: Record<string, unknown> | null = null;

    /* ---- V2-new: RESOLVE MIRROR → STREAM NATIVE ----
     * ?resolve=<url embed>&referer=<halaman episode nekopoi>
     * Mengubah halaman embed (playmogo/streampoi/dll.) menjadi m3u8/mp4
     * langsung yang diputar NativePlayer — bebas iklan, bisa diskip &
     * diputar ulang (jawaban keluhan #5: playmogo 1&2 gagal, streampoi
     * penuh iklan & tidak bisa diskip). */
    if (sp.get("resolve") !== null) {
      const embedUrl = (sp.get("resolve") || "").slice(0, 400);
      const referer = (sp.get("referer") || "").slice(0, 300) || null;
      if (!/^https?:\/\//.test(embedUrl)) {
        return Response.json({ ok: false, error: "URL mirror tidak valid" }, { status: 400 });
      }
      const stream = await resolveMirror(embedUrl, referer);
      if (!stream) {
        return Response.json(
          {
            ok: false,
            error:
              "Server tidak dapat membaca mirror ini (kemungkinan diblokir). Pemain cadangan embed akan dipakai — atau pilih server lain.",
          },
          { status: 404 }
        );
      }
      payload = {
        stream: { ...stream, playUrl: proxyStreamUrl(stream.url, referer) },
      };
    }
    /* ---- TERBARU ---- */
    else if (sp.get("latest") !== null) {
      const page = Math.max(1, Math.min(20, Number(sp.get("page")) || 1));
      // sumber utama: dixzz-neo-api
      const d = await dixzz(`/latest?page=${page}`);
      const items = d && Array.isArray(d.data) ? dixzzItems(d.data as Array<Record<string, unknown>>) : [];
      if (items.length) {
        payload = { items, source: "dixzz" };
      } else {
        // fallback scraper langsung
        const html = await getHtml(page > 1 ? `/page/${page}/` : "/");
        payload = html ? { items: parseList(html), source: "scrape" } : null;
      }
    }
    /* ---- SEARCH ---- */
    else if (sp.get("q")) {
      const q = sp.get("q")!.slice(0, 80);
      const page = Math.max(1, Math.min(20, Number(sp.get("page")) || 1));
      const d = await dixzz(`/search?q=${encodeURIComponent(q)}&page=${page}`);
      const items = d && Array.isArray(d.data) ? dixzzItems(d.data as Array<Record<string, unknown>>) : [];
      if (items.length) {
        payload = { query: q, items, source: "dixzz" };
      } else {
        const html = await getHtml(`/?s=${encodeURIComponent(q)}`);
        payload = html ? { query: q, items: parseList(html), source: "scrape" } : null;
      }
    }
    /* ---- DETAIL ---- */
    else if (sp.get("url")) {
      const url = sp.get("url")!;
      if (!url.includes("nekopoi")) {
        return Response.json({ ok: false, error: "Hanya halaman nekopoi yang diizinkan" }, { status: 400 });
      }

      // dixzz: /api/detail?url=/hentai/slug/
      let detailPath = "";
      try {
        const u = new URL(url);
        detailPath = u.pathname;
      } catch {
        detailPath = url.replace(BASE, "");
      }
      const d = await dixzz(`/detail?url=${encodeURIComponent(detailPath)}`);
      const dd = d?.data as Record<string, unknown> | undefined;

      if (dd && (Array.isArray(dd.embeds) || Array.isArray(dd.m3u8s))) {
        // nama mirror dari host
        const embeds = (dd.embeds as string[] || []).filter((e) => /^https?:\/\//.test(e));
        const BAD_EMBED = /discord(app)?\.com|disqus|recaptcha|doubleclick|adsbygoogle|telegram\.org|t\.me\//i;
        const streamLinks = embeds
          .filter((e) => !BAD_EMBED.test(e))
          .map((e) => {
            let name = "Mirror";
            try {
              const host = new URL(e).hostname.replace(/^www\./, "");
              name = host.split(".")[0].replace(/^player\.?/, "");
              name = name.charAt(0).toUpperCase() + name.slice(1);
            } catch {
              /* default */
            }
            return { name, url: e };
          });
        const m3u8s = (dd.m3u8s as string[] || []).filter((m) => /^https?:\/\//.test(m));
        const downloadsRaw = (dd.downloads as Array<Record<string, unknown>> || []);
        const downloadLinks: Array<{ text: string; url: string }> = [];
        for (const grp of downloadsRaw) {
          const q = String(grp.name || "");
          for (const l of (grp.links as Array<Record<string, unknown>>) || []) {
            const host = String(l.host || "");
            const dlUrl = String(l.url || "");
            if (/^https?:\/\//.test(dlUrl)) {
              downloadLinks.push({ text: `${q} • ${host}`.trim(), url: dlUrl });
            }
          }
        }
        const meta = (dd.metadata as Record<string, string>) || {};
        payload = {
          url,
          title: String(dd.title || "Tanpa judul"),
          thumbnail: String((dd as Record<string, unknown>).image || "") || null,
          info: Object.entries(meta).map(([k, v]) => `${k}: ${v}`),
          genres: String(meta.genres || "").split(",").map((s) => s.trim()).filter(Boolean),
          synopsis: null,
          streamLinks,
          m3u8s,
          m3u8: m3u8s[0] || null,
          downloadLinks: downloadLinks.slice(0, 15),
          source: "dixzz",
        };
      } else {
        // fallback: scraper halaman langsung (parser lama)
        const path = url.replace(BASE, "");
        const html = await getHtml(path);
        if (!html) payload = null;
        else {
          const $ = cheerio.load(html);
          const title = $("h1.entry-title, h1.post-title, h1").first().text().trim();
          const img = $("img").first();
          const thumbnail = img.attr("src") || img.attr("data-src") || null;

          const info: string[] = [];
          $(".info li, .entry-meta li, .gmr-movie-data li, .data li, .catlinks li").each((_, el) => {
            const t = $(el).text().replace(/\s+/g, " ").trim();
            if (t && t.length < 120) info.push(t);
          });
          const genres: string[] = [];
          $(".genre a, .genres a, .tag a, a[href*='genre']").each((_, el) => {
            const t = $(el).text().trim();
            if (t && t.length < 30 && !genres.includes(t)) genres.push(t);
          });
          const synopsis =
            $(".synopsis, .entry-content, .gmr-movie-synopsis").first().text().replace(/\s+/g, " ").trim() || null;

          const streamLinks: Array<{ name: string; url: string }> = [];
          const BAD_EMBED = /discord(app)?\.com|discord|disqus|google\.com\/recaptcha|doubleclick|adsbygoogle|telegram\.org|t\.me\//i;
          $("iframe").each((_, el) => {
            const src = $(el).attr("src") || $(el).attr("data-src") || "";
            if (src && /^https?:\/\//.test(src) && !BAD_EMBED.test(src)) {
              let name = "Mirror";
              try {
                const host = new URL(src).hostname.replace(/^www\./, "");
                const base = host.split(".")[0];
                name = base.charAt(0).toUpperCase() + base.slice(1);
              } catch {
                /* biarkan "Mirror" */
              }
              streamLinks.push({ name, url: src });
            }
          });
          const m3u8s = [...html.matchAll(/https?:\/\/[^"'\s]+\.m3u8[^"'\s]*/g)].map((m) => m[0]);
          const mp4 = html.match(/https?:\/\/[^"'\s]+\.mp4[^"'\s]*/);

          const downloadLinks: Array<{ text: string; url: string }> = [];
          $("a[href*='mirrored'], a[href*='download'], a[href*='mega.nz'], a[href*='onedrive']").each((_, el) => {
            const href = $(el).attr("href") || "";
            const text = $(el).text().replace(/\s+/g, " ").trim();
            if (/^https?:\/\//.test(href) && !BAD_EMBED.test(href) && downloadLinks.length < 12) {
              downloadLinks.push({ text: text || "Unduhan", url: href });
            }
          });

          payload = {
            url,
            title: title || "Tanpa judul",
            thumbnail,
            info,
            genres,
            synopsis,
            streamLinks,
            downloadLinks,
            m3u8s: [...new Set(m3u8s)].slice(0, 6),
            m3u8: m3u8s[0] || null,
            mp4: mp4?.[0] || null,
            source: "scrape",
          };
        }
      }
    } else {
      return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
    }

    if (!payload) {
      return Response.json({ ok: false, error: "Sumber sedang bermasalah — silakan coba beberapa saat lagi" }, { status: 502 });
    }
    CACHE.set(ckey, { at: Date.now(), data: payload });
    return Response.json({ ok: true, ...payload });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses permintaan" }, { status: 500 });
  }
}
