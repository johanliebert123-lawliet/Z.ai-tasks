import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { amAuth, amActivate } from "@/lib/am";
import { isEmail } from "@/lib/validate";

export const runtime = "nodejs";

/** Verifikasi magic link → login → aktivasi premium. */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`amverify:${ip}`, 12, 5 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Terlalu banyak percobaan. Tunggu sebentar ya." },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const email = String(body.email || "").trim().toLowerCase();
  const link = String(body.link || "").trim();
  if (!isEmail(email)) {
    return Response.json({ ok: false, error: "Email tidak valid" }, { status: 400 });
  }
  if (link.length < 10) {
    return Response.json(
      { ok: false, error: "Magic link belum lengkap — salin utuh URL dari email." },
      { status: 400 }
    );
  }

  // 1) login via magic link
  const v = await amAuth(email, link);
  if (!v.ok || !v.idToken) {
    return Response.json(
      { ok: false, error: v.error || "Verifikasi gagal" },
      { status: 502 }
    );
  }

  // 2) aktivasi premium
  const premium = await amActivate(v.idToken);

  const now = new Date();
  const until = new Date();
  until.setFullYear(until.getFullYear() + 1);

  return Response.json({
    ok: true,
    message: premium.ok
      ? "Verifikasi berhasil — Premium Alight Motion aktif! 🎉"
      : "Login berhasil, tapi aktivasi premium gagal. Coba kirim ulang magic link baru lalu verifikasi lagi.",
    data: {
      uid: v.uid || "-",
      email: v.user?.email || email,
      emailVerified: v.user?.emailVerified ?? true,
      displayName: v.user?.displayName || null,
      photoUrl: v.user?.photoUrl || null,
      createdAt: v.user?.createdAt
        ? new Date(Number(v.user.createdAt)).toISOString()
        : null,
      lastLoginAt: v.user?.lastLoginAt
        ? new Date(Number(v.user.lastLoginAt)).toISOString()
        : now.toISOString(),
      isNewUser: v.isNewUser,
      status: premium.ok ? "ACTIVE" : "INACTIVE",
      membershipStatus: premium.ok ? "PREMIUM_ACTIVE" : "LOGIN_ONLY",
      planName: "Alight Motion Pro / Member",
      subscriptionType: "Yearly VIP License",
      orderId: premium.order || null,
      activatedAt: now.toISOString(),
      validUntil: until.toLocaleDateString("id-ID", {
        year: "numeric",
        month: "long",
        day: "numeric",
      }),
      validUntilTimestamp: until.getTime(),
      premiumError: premium.ok ? null : premium.error,
      profile: v.user || null,
    },
  });
}
