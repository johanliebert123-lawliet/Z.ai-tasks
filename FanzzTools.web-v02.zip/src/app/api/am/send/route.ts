import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { amSendLink, friendlyFirebaseError } from "@/lib/am";
import { isEmail } from "@/lib/validate";

export const runtime = "nodejs";

/** Kirim magic link ke email user (via Firebase Alight Motion). */
export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`amsend:${ip}`, 6, 5 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Terlalu sering kirim link. Tunggu 5 menit ya." },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const email = String(body.email || "").trim().toLowerCase();
  if (!isEmail(email)) {
    return Response.json({ ok: false, error: "Email tidak valid" }, { status: 400 });
  }

  const r = await amSendLink(email);
  if (!r.ok) {
    return Response.json(
      { ok: false, error: friendlyFirebaseError(r.error || "Gagal mengirim link") },
      { status: 502 }
    );
  }

  return Response.json({
    ok: true,
    message: `Magic link terkirim ke ${email}. Cek inbox maupun folder spam ya.`,
  });
}
