import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { findUserByEmail, createUser, rateLimit } from "@/lib/store";
import { isBcryptHash, isEmail, isPassword, isUsername } from "@/lib/validate";

export const runtime = "nodejs";

function serializeCookie(name: string, value: string, maxAge: number) {
  const parts = [
    `${name}=${value}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAge}`,
  ];
  if (process.env.NODE_ENV === "production") parts.push("Secure");
  return parts.join("; ");
}

export async function POST(req: NextRequest) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  // V2 UpdSec: limit login diperketat (15→12/5 menit) + blokir total per email
  if (!rateLimit(`login:${ip}`, 12, 5 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Terlalu banyak percobaan login. Tunggu 5 menit." },
      { status: 429 }
    );
  }

  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const { email, password, vaultHash, username } = body;

  if (!isEmail(email) || !isPassword(password)) {
    return Response.json(
      { ok: false, error: "Email atau password tidak valid (password minimal 8 karakter)" },
      { status: 400 }
    );
  }

  const mail = String(email).toLowerCase().trim();
  // V2 UpdSec: anti brute-force per-email juga (bukan cuma per-IP)
  if (!rateLimit(`loginem:${mail}`, 8, 15 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Akun ini sementara dikunci karena terlalu banyak percobaan gagal. Coba lagi dalam 15 menit." },
      { status: 429 }
    );
  }
  const rec = findUserByEmail(mail);

  // Alur normal: user ada di registry server
  if (rec) {
    const ok = await bcrypt.compare(String(password), rec.hash);
    if (!ok) {
      // V2 UpdSec: pesan generik — jangan bocorkan status email
      return Response.json(
        { ok: false, error: "Email atau password salah. Coba lagi." },
        { status: 401 }
      );
    }
    const token = await import("@/lib/session").then((m) =>
      m.signSession({ uid: rec.uid, username: rec.username, email: rec.email })
    );
    const res = Response.json({
      ok: true,
      user: {
        uid: rec.uid,
        username: rec.username,
        email: rec.email,
        createdAt: rec.createdAt,
      },
      vaultHash: rec.hash,
    });
    res.headers.append(
      "Set-Cookie",
      serializeCookie("fanzz_session", token, 30 * 24 * 3600)
    );
    return res;
  }

  // Alur restore: server ke-reset (cold start), akun dipulihkan dari vault client
  if (isBcryptHash(vaultHash)) {
    const ok = await bcrypt.compare(String(password), String(vaultHash));
    if (ok) {
      const name = isUsername(username)
        ? String(username).trim()
        : mail.split("@")[0].slice(0, 20);
      const user = await createUser(name, mail, String(password));
      const token = await import("@/lib/session").then((m) =>
        m.signSession({ uid: user.uid, username: user.username, email: user.email })
      );
      const res = Response.json({
        ok: true,
        restored: true,
        user: {
          uid: user.uid,
          username: user.username,
          email: user.email,
          createdAt: user.createdAt,
        },
        vaultHash: user.hash,
      });
      res.headers.append(
        "Set-Cookie",
        serializeCookie("fanzz_session", token, 30 * 24 * 3600)
      );
      return res;
    }
    return Response.json(
      { ok: false, error: "Email atau password salah. Coba lagi." },
      { status: 401 }
    );
  }

  return Response.json(
    {
      ok: false,
      needRestore: true,
      error:
        "Akun tidak ditemukan di server (mungkin baru restart). Kalau udah pernah daftar di device ini, coba lagi — atau daftar ulang.",
    },
    { status: 404 }
  );
}
