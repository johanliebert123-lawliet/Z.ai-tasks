import { getSession } from "@/lib/session";

export const runtime = "nodejs";

export async function GET() {
  const session = await getSession();
  if (!session) {
    return Response.json({ ok: false }, { status: 401 });
  }
  return Response.json({
    ok: true,
    user: {
      uid: session.uid,
      username: session.username,
      email: session.email,
    },
  });
}
