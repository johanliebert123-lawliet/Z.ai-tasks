import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { createUser, findUserByEmail, rateLimit } from "@/lib/store";
import { signSession, SESSION_COOKIE } from "@/lib/session";
import { isEmail, isPassword, isUsername } from "@/lib/validate";

export const runtime = "nodejs";

function serializeCookie(name: string, value: string, maxAge: number) {
  const parts = [
    `${name}=${value}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${maxAge}`,
  ];
  if (process.env.NODE_ENV === "production") parts.push("Secure");
  return parts.join("; ");
}

export async function POST(req: NextRequest) {
  const ip =
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`reg:${ip}`, 5, 10 * 60 * 1000).ok) {
    return Response.json(
      { ok: false, error: "Terlalu banyak percobaan daftar. Tunggu 10 menit." },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }
  const { username, email, password } = (body || {}) as Record<string, unknown>;

  if (!isUsername(username))
    return Response.json(
      { ok: false, error: "Username 3-24 karakter (huruf, angka, titik, underscore)" },
      { status: 400 }
    );
  if (!isEmail(email))
    return Response.json({ ok: false, error: "Format email tidak valid" }, { status: 400 });
  if (!isPassword(password))
    return Response.json(
      { ok: false, error: "Password minimal 8 karakter (keamanan diperketat)" },
      { status: 400 }
    );

  const mail = String(email).toLowerCase().trim();
  if (findUserByEmail(mail)) {
    return Response.json(
      { ok: false, error: "Email udah terdaftar. Login aja langsung." },
      { status: 409 }
    );
  }

  const user = await createUser(String(username).trim(), mail, String(password));

  const token = await signSession({
    uid: user.uid,
    username: user.username,
    email: user.email,
  });

  const res = Response.json({
    ok: true,
    user: {
      uid: user.uid,
      username: user.username,
      email: user.email,
      createdAt: user.createdAt,
    },
    vaultHash: user.hash, // client simpan buat restore kalau server reset
  });
  res.headers.append(
    "Set-Cookie",
    serializeCookie(SESSION_COOKIE, token, 30 * 24 * 3600)
  );
  return res;
}
