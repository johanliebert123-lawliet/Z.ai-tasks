import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";
import { isPrivateHost } from "@/lib/validate";
import { fetchStream } from "@/lib/stream-fetch";

export const runtime = "nodejs";

/**
 * Proxy streaming video (V2-new):
 *  ?url=<m3u8|mp4|segment>&referer=<origin halaman embed — opsional>
 *
 * Fungsi:
 *  1. Suntik User-Agent + Referer server-side (menembus hotlink-protection CDN
 *     keluarga streamruby/vidhide yang menolak permintaan tanpa Referer asal).
 *  2. Untuk playlist .m3u8: tulis ulang URL segmen + atribut URI= supaya
 *     segmen juga lewat proxy ini (relatif → absolut → proxy).
 *  3. Range header diteruskan (206 partial) — membuat seek/skip mulus.
 */

function proxied(u: string, referer: string | null): string {
  const p = new URLSearchParams({ url: u });
  if (referer) p.set("referer", referer);
  return `/api/stream/proxy?${p.toString()}`;
}

function absolutize(base: string, u: string): string {
  try {
    return new URL(u, base).toString();
  } catch {
    return u;
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`sproxy:${ip}`, 240, 60 * 1000).ok) {
    return new Response("Terlalu banyak permintaan streaming", { status: 429 });
  }

  const raw = req.nextUrl.searchParams.get("url") || "";
  const referer = req.nextUrl.searchParams.get("referer") || null;
  if (!/^https?:\/\//i.test(raw) || raw.length > 2048) {
    return new Response("URL tidak valid", { status: 400 });
  }

  // V2 UpdSec — SSRF guard LENGKAP (bukan cuma regex lama):
  //  - 172.16.0.0/12, 100.64.0.0/10 (CGNAT), 169.254.0.0/16, multicast, TEST-NET
  //  - IPv6 unique-local & link-local
  //  - bentuk desimal/heksa aneh dari IP
  //  - DAN re-validasi SETELAH redirect (anti DNS-rebinding ke internal)
  let target: URL;
  try {
    target = new URL(raw);
    if (isPrivateHost(target.hostname)) {
      return new Response("Host tidak diizinkan", { status: 400 });
    }
  } catch {
    return new Response("URL tidak valid", { status: 400 });
  }

  const headers: Record<string, string> = {
    "User-Agent": UA_DESKTOP,
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9,id-ID;q=0.8",
  };
  if (referer) headers.Referer = referer;
  const range = req.headers.get("range");
  if (range) headers.Range = range;

  try {
    // V2 UpdSec: redirect manual — tiap lompatan di-revalidasi host-nya
    // (redirect:"follow" bisa mendarat di IP internal = DNS-rebinding SSRF)
    //
    // PERBAIKAN "lagu terpotong" (zuperupdt #3): dulu fetch memakai
    // AbortSignal.timeout(30dtk) yang MEMUTUS body yang sedang mengalir —
    // lagu lebih dari 30 detik berhenti di tengah. Sekarang timer hanya
    // sampai header diterima (fetchStream) → body bebas mengalir sampai selesai.
    let upstream = await fetchStream(target.toString(), {
      headers,
      redirect: "manual",
      connectTimeoutMs: 20000,
    });
    for (let hop = 0; [301, 302, 303, 307, 308].includes(upstream.status) && hop < 5; hop++) {
      const loc = upstream.headers.get("location");
      if (!loc) break;
      const nextUrl = new URL(loc, target);
      if (!/^https?:$/.test(nextUrl.protocol) || isPrivateHost(nextUrl.hostname)) {
        return new Response("Redirect ke host tidak diizinkan", { status: 400 });
      }
      target = nextUrl;
      upstream = await fetchStream(target.toString(), {
        headers,
        redirect: "manual",
        connectTimeoutMs: 20000,
      });
    }
    if ([301, 302, 303, 307, 308].includes(upstream.status)) {
      return new Response("Terlalu banyak redirect", { status: 508 });
    }
    if (!upstream.ok && upstream.status !== 206) {
      return new Response(`Sumber menolak (${upstream.status})`, { status: 502 });
    }

    const ctype = upstream.headers.get("content-type") || "";

    /* ---- playlist m3u8: tulis ulang URL segmen ---- */
    const finalUrl = target.toString();
    const isM3u8 = /\.m3u8(\?|$)/i.test(finalUrl) || /mpegurl/i.test(ctype);
    if (isM3u8) {
      const text = await upstream.text();
      const lines = text.split("\n");
      const out: string[] = [];
      for (let line of lines) {
        const t = line.trim();
        if (!t) {
          out.push(line);
          continue;
        }
        if (t.startsWith("#")) {
          // atribut URI="..." (KEY / MEDIA / dsb)
          if (/URI="/.test(t)) {
            line = line.replace(/URI="([^"]+)"/g, (_m, u: string) => `URI="${proxied(absolutize(finalUrl, String(u)), referer)}"`);
          }
          out.push(line);
        } else {
          out.push(proxied(absolutize(finalUrl, t), referer));
        }
      }
      return new Response(out.join("\n"), {
        status: 200,
        headers: {
          "Content-Type": "application/vnd.apple.mpegurl",
          "Cache-Control": "no-store",
        },
      });
    }

    /* ---- file media: streaming + Range passthrough ---- */
    const rh = new Headers();
    for (const h of ["content-type", "content-length", "content-range", "accept-ranges", "etag", "last-modified"]) {
      const v = upstream.headers.get(h);
      if (v) rh.set(h, v);
    }
    if (!rh.get("content-type")) rh.set("content-type", /mp4/i.test(target.toString()) ? "video/mp4" : "application/octet-stream");
    rh.set("Cache-Control", "public, max-age=600");
    return new Response(upstream.body, { status: upstream.status, headers: rh });
  } catch {
    return new Response("Gagal menghubungi sumber video", { status: 502 });
  }
}
