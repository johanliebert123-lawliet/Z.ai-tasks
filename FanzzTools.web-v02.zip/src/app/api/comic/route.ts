import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Baca Komik — ComicVerse (V2-new, permintaan #20).
 * Sumber: sankavollerei.web.id wrapper dari Bacakomik.
 * Endpoint: ?list=<latest|top|populer|recomen> | ?q= | ?detail=<slug> | ?chapter=<slug>
 *
 * Item punya field `type` (Manhwa / Manhua / Manga) — dipakai view untuk
 * tiga kategori: Manhwa, Manhua, Comic (Manga) + tab Semua.
 */

const BASE = "https://www.sankavollerei.web.id/comic/bacakomik";

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 10 * 60 * 1000;

interface ComicItem {
  title: string;
  slug: string;
  cover: string;
  rating?: string;
  type?: string;
  chapter?: string;
  genre?: string;
}

async function apiGet(path: string): Promise<Record<string, unknown> | null> {
  const hit = CACHE.get(path);
  if (hit && Date.now() - hit.at < TTL) return hit.data as Record<string, unknown>;
  try {
    const res = await fetch(BASE + path, {
      headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
      signal: AbortSignal.timeout(20000),
    });
    if (!res.ok) return null;
    const text = await res.text();
    if (!text.trimStart().startsWith("{")) return null;
    const d = JSON.parse(text) as Record<string, unknown>;
    if (d?.success === false) return null;
    CACHE.set(path, { at: Date.now(), data: d });
    return d;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`comic:${ip}`, 40, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;

  try {
    /* ---- daftar ---- */
    if (sp.get("list")) {
      const which = sp.get("list")!;
      if (!["latest", "top", "populer", "recomen"].includes(which)) {
        return Response.json({ ok: false, error: "Kategori daftar tidak dikenal" }, { status: 400 });
      }
      const d = await apiGet(`/${which}`);
      const komikList = (d?.komikList as ComicItem[]) || [];
      if (!komikList.length) {
        return Response.json({ ok: false, error: "Daftar komik tidak dapat dimuat — coba lagi beberapa saat." }, { status: 502 });
      }
      return Response.json({ ok: true, items: komikList });
    }

    /* ---- pencarian ---- */
    if (sp.get("q")) {
      const q = sp.get("q")!.slice(0, 80).trim();
      if (!q) return Response.json({ ok: true, items: [] });
      const d = await apiGet(`/search/${encodeURIComponent(q)}`);
      const komikList = (d?.komikList as ComicItem[]) || [];
      return Response.json({ ok: true, items: komikList });
    }

    /* ---- detail ---- */
    if (sp.get("detail")) {
      const slug = sp.get("detail")!.slice(0, 160).replace(/[^a-zA-Z0-9-]/g, "");
      const d = await apiGet(`/detail/${slug}`);
      const detail = (d?.detail as Record<string, unknown>) || null;
      if (!detail) {
        return Response.json({ ok: false, error: "Komik tidak ditemukan — coba cari lewat pencarian." }, { status: 404 });
      }
      return Response.json({ ok: true, detail });
    }

    /* ---- chapter (gambar) ---- */
    if (sp.get("chapter")) {
      const slug = sp.get("chapter")!.slice(0, 200).replace(/[^a-zA-Z0-9-]/g, "");
      const d = await apiGet(`/chapter/${slug}`);
      const images = (d?.images as string[]) || [];
      if (!images.length) {
        return Response.json({ ok: false, error: "Halaman chapter tidak dapat dimuat — coba lagi." }, { status: 404 });
      }
      return Response.json({ ok: true, title: String(d?.title || "Chapter"), images });
    }

    return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses permintaan komik" }, { status: 500 });
  }
}
