import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/** Reverse geocoding koordinat → alamat (Nominatim / OpenStreetMap). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`geo:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering" }, { status: 429 });
  }

  const lat = parseFloat(req.nextUrl.searchParams.get("lat") || "");
  const lon = parseFloat(req.nextUrl.searchParams.get("lon") || "");
  if (isNaN(lat) || isNaN(lon) || Math.abs(lat) > 90 || Math.abs(lon) > 180) {
    return Response.json({ ok: false, error: "Koordinat tidak valid" }, { status: 400 });
  }

  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json&zoom=16&accept-language=id`,
      {
        headers: {
          "User-Agent": "FanzzTools-V2/2.3 (web tools app)",
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(12000),
      }
    );
    if (!res.ok) throw new Error("nominatim " + res.status);
    const d = await res.json();
    const a = d.address || {};
    let kecamatan = a.suburb || a.city_district || a.neighbourhood || a.quarter || "";
    let provinsi = a.state || "";
    if ((!kecamatan || !provinsi) && d.display_name) {
      // fallback posisi: display_name = "..., [kecamatan], kota, [provinsi], ..."
      const parts = String(d.display_name).split(", ").map((s: string) => s.trim());
      const city = a.city || a.town || a.municipality || "";
      const cityIdx = city ? parts.findIndex((p) => p === city) : -1;
      if (cityIdx > 0) {
        for (let i = cityIdx - 1; i >= 0 && !kecamatan; i--) {
          if (parts[i] && !/^\d+$/.test(parts[i]) && parts[i] !== a.road && parts[i] !== a.city_block && parts[i] !== a.village) {
            kecamatan = parts[i];
          }
        }
      }
      if (!provinsi && cityIdx >= 0 && cityIdx + 1 < parts.length - 2) {
        const cand = parts[cityIdx + 1];
        if (cand && !/^\d+$/.test(cand) && cand !== a.country) provinsi = cand;
      }
    }
    return Response.json({
      ok: true,
      address: {
        road: a.road || a.pedestrian || "",
        kelurahan: a.village || a.hamlet || a.neighbourhood || a.quarter || "",
        kecamatan,
        kota: a.city || a.town || a.municipality || "",
        kabupaten: a.county || a.state_district || "",
        provinsi,
        negara: a.country || "",
        postcode: a.postcode || "",
        countryCode: a.country_code || "",
        display: d.display_name || "",
      },
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal reverse geocode" },
      { status: 502 }
    );
  }
}
