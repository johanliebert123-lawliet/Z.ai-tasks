import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    name: "FanzzTools.V2 API",
    version: "2.0.0",
    status: "ok",
    tools: [
      "/api/auth/*",
      "/api/movies/*",
      "/api/music/*",
      "/api/email/*",
      "/api/download",
      "/api/download/file",
      "/api/am/*",
      "/api/ai/*",
    ],
  });
}
