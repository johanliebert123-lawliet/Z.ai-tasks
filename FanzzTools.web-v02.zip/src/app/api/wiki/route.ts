import { NextRequest } from "next/server";
import http2 from "node:http2";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Pencarian ensiklopedia (Wikipedia ID + EN):
 *  ?q=...        -> hasil pencarian (judul, deskripsi, gambar)
 *  ?title=...&lang=id -> isi artikel (HTML disanitasa)
 *
 * Catatan: Wikipedia menolak fetch HTTP/1.1 dengan UA browser (403),
 * jadi request dikirim via HTTP/2 (node:http2) - persis seperti browser asli.
 */

export interface WikiResult {
  title: string;
  desc: string;
  thumb: string | null;
  lang: string;
}

/** Fetch API Wikipedia — MULTI-STRATEGI (V2-new, perbaikan "Wikipedia bermasalah mulu"):
 *  1. fetch biasa (jalan di Vercel — Wikipedia memblokir sebagian IP datacenter saja)
 *  2. HTTP/2 dengan UA browser (meniru browser asli — jalan di VPS/datacenter)
 *  3. cURL subprocess (fingerprint TLS berbeda)
 *  Semua dengan timeout 10 detik + 1 kali ulangan. */
async function wikiFetch(lang: string, params: Record<string, string>): Promise<Record<string, unknown> | null> {
  const qs = new URLSearchParams({ format: "json", formatversion: "2", ...params });
  const path = `/w/api.php?${qs}`;
  const host = `${lang}.wikipedia.org`;

  // 1) fetch biasa
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const res = await fetch(`https://${host}${path}`, {
        headers: { "User-Agent": UA_DESKTOP, Accept: "application/json" },
        signal: AbortSignal.timeout(10000),
      });
      if (res.ok) {
        const text = await res.text();
        if (text.trimStart().startsWith("{")) return JSON.parse(text) as Record<string, unknown>;
      }
    } catch {
      /* strategi berikutnya */
    }
  }

  // 2) HTTP/2 seperti browser
  const viaH2 = await new Promise<Record<string, unknown> | null>((resolve) => {
    let settled = false;
    let data = "";
    let session: http2.ClientHttp2Session | null = null;
    const done = (v: Record<string, unknown> | null) => {
      if (settled) return;
      settled = true;
      resolve(v);
    };
    try {
      session = http2.connect(`https://${host}`);
      session.setTimeout(12000, () => {
        session?.destroy();
        done(null);
      });
      session.on("error", () => done(null));
      const req = session.request({
        ":path": path,
        "user-agent": UA_DESKTOP,
        accept: "application/json",
      });
      req.on("data", (c: Buffer) => {
        data += c;
      });
      req.on("error", () => {
        session?.destroy();
        done(null);
      });
      req.on("end", () => {
        session?.close();
        try {
          done(JSON.parse(data) as Record<string, unknown>);
        } catch {
          done(null);
        }
      });
      req.end();
    } catch {
      done(null);
    }
  });
  if (viaH2) return viaH2;

  // 3) cURL subprocess
  const { execFile } = await import("child_process");
  return new Promise((resolve) => {
    execFile(
      "curl",
      ["-s", "-m", "12", "-A", UA_DESKTOP, "-H", "Accept: application/json", "--compressed", `https://${host}${path}`],
      { timeout: 17000, maxBuffer: 16 * 1024 * 1024 },
      (err, stdout) => {
        if (err || typeof stdout !== "string") return resolve(null);
        const t = stdout.trimStart();
        if (!t.startsWith("{")) return resolve(null);
        try {
          resolve(JSON.parse(t) as Record<string, unknown>);
        } catch {
          resolve(null);
        }
      }
    );
  });
}

/** Sanitasi HTML artikel Wikipedia jadi markup aman buat render in-app. */
function sanitizeWikiHtml(html: string, lang: string): string {
  let h = html;
  // buang blok bahaya & elemen gak perlu
  h = h.replace(/<script[\s\S]*?<\/script>/gi, "");
  h = h.replace(/<style[\s\S]*?<\/style>/gi, "");
  h = h.replace(/<!--[\s\S]*?-->/g, "");
  h = h.replace(/<span class="mw-editsection"[\s\S]*?<\/span>/gi, "");
  h = h.replace(/<input[\s\S]*?>/gi, "");
  h = h.replace(/<button[\s\S]*?<\/button>/gi, "");
  h = h.replace(/<form[\s\S]*?<\/form>/gi, "");
  h = h.replace(/<sup[^>]*class="[^"]*reference[^"]*"[^>]*>[\s\S]*?<\/sup>/gi, "");
  h = h.replace(/<table[^>]*class="[^"]*(infobox|metadata|navbox|sidebar|vertical-navbox|ambox)[^"]*"[^>]*>[\s\S]*?<\/table>/gi, "");
  h = h.replace(/<div[^>]*class="[^"]*(thumb|metadata|mbox-small|hatnote|navbox|portal|sistersitebox)[^"]*"[^>]*>[\s\S]*?<\/div>/gi, "");
  // buang atribut styling/tambahan
  h = h.replace(/\s(?:style|class|id|about|typeof|property|rel|resource|data-[a-z-]+)="[^"]*"/gi, "");
  // srcset bikin berat — buang, sisain src
  h = h.replace(/\ssrcset="[^"]*"/gi, "");
  h = h.replace(/\sdecoding="[^"]*"/gi, "");
  h = h.replace(/\sloading="[^"]*"/gi, "");
  // link internal → absolute + tab baru
  h = h.replace(/href="\/wiki\/([^"]*)"/g, (_, slug) => `href="https://${lang}.wikipedia.org/wiki/${slug}" target="_blank" rel="noreferrer"`);
  // gambar perkecil (thumbnail 480px)
  h = h.replace(/src="(\/\/upload\.wikimedia\.org\/[^"]*)"/g, (m, u: string) => {
    const small = u.replace(/\/(\d+)px-/, "/480px-");
    return `src="https:${small}" loading="lazy" referrerpolicy="no-referrer"`;
  });
  // buang atribut width/height hardcoded biar responsif
  h = h.replace(/\s(?:width|height)="\d+"/gi, "");
  return h.slice(0, 240000);
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`wiki:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 120);
  const title = (req.nextUrl.searchParams.get("title") || "").trim().slice(0, 160);
  const lang = req.nextUrl.searchParams.get("lang") === "en" ? "en" : "id";

  /* ---- baca artikel ---- */
  if (title) {
    const d = await wikiFetch(lang, {
      action: "parse",
      page: title,
      prop: "text",
      redirects: "1",
    });
    if (!d) {
      return Response.json(
        { ok: false, error: "Wikipedia lagi sibuk — coba buka artikelnya lagi ya." },
        { status: 502 }
      );
    }
    const html = (d?.parse as { text?: unknown } | undefined)?.text;
    const raw =
      typeof html === "string"
        ? html
        : ((html as unknown as Record<string, string>)?.["*"] as string) || "";
    if (!raw) {
      return Response.json({ ok: false, error: "Artikel tidak ditemukan" }, { status: 404 });
    }
    const pageTitle = ((d?.parse as { title?: string })?.title) || title;
    return Response.json({
      ok: true,
      title: pageTitle,
      html: sanitizeWikiHtml(raw, lang),
      lang,
    });
  }

  /* ---- pencarian ---- */
  if (!q) {
    return Response.json({ ok: false, error: "Query kosong" }, { status: 400 });
  }

  const d = await wikiFetch(lang, {
    action: "query",
    list: "search",
    srsearch: q,
    srlimit: "12",
  });
  if (!d) {
    return Response.json(
      { ok: false, error: "Wikipedia lagi sibuk nih — tunggu sebentar lalu cari lagi ya." },
      { status: 502 }
    );
  }
  const hits = ((d?.query as { search?: Array<{ title: string }> })?.search) || [];

  // perkaya: deskripsi + gambar + potongan awal
  let results: WikiResult[] = hits.map((h) => ({
    title: h.title,
    desc: "",
    thumb: null,
    lang,
  }));

  if (results.length) {
    const d2 = await wikiFetch(lang, {
      action: "query",
      prop: "pageimages|extracts",
      exintro: "1",
      explaintext: "1",
      exsentences: "2",
      piprop: "thumbnail",
      pithumbsize: "400",
      titles: results.map((r) => r.title).join("|"),
    });
    const pages = ((d2?.query as { pages?: Array<{ title: string; extract?: string; thumbnail?: { source: string } }> })?.pages) || [];
    const byTitle = new Map(pages.map((p) => [p.title, p]));
    results = results.map((r) => {
      const p = byTitle.get(r.title);
      return {
        ...r,
        desc: (p?.extract || "").slice(0, 220),
        thumb: p?.thumbnail?.source || null,
      };
    });
  }

  return Response.json({ ok: true, results });
}
