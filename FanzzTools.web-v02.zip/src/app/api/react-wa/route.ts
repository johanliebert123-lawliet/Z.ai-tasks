import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/**
 * reactChWa — react emoji ke pesan saluran WhatsApp (FanzSec-Update).
 *
 * Proxy SERVER-SIDE ke API reactCh (api.jerexd.my.id). Alasan proxy:
 *  - API key TIDAK boleh ikut terkirim ke browser (tetap di server saja)
 *  - bisa ditambah rate-limit + validasi sesi di sisi FanzzTools
 *
 * Kontrak API upstream (diverifikasi langsung 2026-09-22):
 *  GET https://api.jerexd.my.id/api/whatsapp/reactch?apikey=KEY&url=<pesan>&emoji=<e1,e2>
 *  - 200 → { status:true, result:{ reaction, reactions[], task:{ status } } }
 *  - 429 → { status:false, error:"... tunggu N detik lagi untuk target postingan yang sama" }
 *  - 400 → url wajib diisi
 *
 * Key bisa di-rotate lewat env JEREXD_APIKEY tanpa ubah kode.
 */

/** Default key bawaan (server-side only — TIDAK pernah masuk client bundle). */
const API_KEY = process.env.JEREXD_APIKEY || "HAFIZ-XD";
const BASE = "https://api.jerexd.my.id/api/whatsapp/reactch";

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

/** Ambil jumlah detik jeda dari pesan rate-limit upstream (mis. "tunggu 14 detik lagi"). */
function parseWaitSeconds(text: string): number {
  const m = text.match(/(\d+)\s*(?:detik|second|sec)/i);
  return m ? Math.max(1, Number(m[1])) : 0;
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  // 30 permintaan proxy per menit per IP — cukup untuk loop react + auto-retry
  if (!rateLimit(`rwa:${ip}`, 30, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak react — mohon beri jeda" }, { status: 429 });
  }

  const body = (await req.json().catch(() => null)) as Record<string, unknown> | null;
  if (!body) return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });

  const action = String(body.action || "react");

  try {
    if (action === "react") {
      const url = String(body.url || "").trim();
      // maks 2 emoji digabung per react — aturan yang sama seperti desain awal
      const reactions = (Array.isArray(body.reactions) ? body.reactions : [])
        .map((r) => String(r).slice(0, 16))
        .filter(Boolean)
        .slice(0, 2);

      if (!/^https?:\/\//.test(url) || !url.includes("whatsapp.com")) {
        return Response.json({ ok: false, error: "Tautan pesan saluran WhatsApp tidak valid" }, { status: 400 });
      }
      if (!reactions.length) {
        return Response.json({ ok: false, error: "Pilih minimal 1 emoji" }, { status: 400 });
      }

      const params = new URLSearchParams({ apikey: API_KEY, url });
      // upstream menerima kombinasi koma, contoh "🔥,❤️"
      params.set("emoji", reactions.join(","));

      const res = await fetch(`${BASE}?${params.toString()}`, {
        method: "GET",
        headers: { "User-Agent": UA, Accept: "application/json" },
        signal: AbortSignal.timeout(60000),
      });
      const d = (await res.json().catch(() => null)) as Record<string, unknown> | null;

      // 429 = antrean per postingan yang sama: sampaikan sisa detik agar UI bisa auto-tunggu
      if (res.status === 429 || d?.statusCode === 429) {
        const rawErr = String((d?.error as string) || "Server react sibuk");
        const waitSec = parseWaitSeconds(rawErr);
        return Response.json(
          { ok: false, retry: true, waitSec: waitSec || 15, error: rawErr },
          { status: 429 }
        );
      }

      if (res.status === 200 && d?.status === true) {
        const result = (d.result || {}) as Record<string, unknown>;
        const task = (result.task || {}) as Record<string, unknown>;
        return Response.json({
          ok: true,
          queued: true,
          reaction: String(result.reaction || reactions.join("")),
          taskStatus: String(task.status || "Queued"),
          responseTime: String(result.response_time || ""),
        });
      }

      // 400 / 401 / 500 dll — sampaikan error apa adanya (tanpa bocorkan apikey)
      const rawErr = String((d?.error as string) || (d?.message as string) || `Server react menolak (HTTP ${res.status})`);
      return Response.json({ ok: false, error: rawErr }, { status: 502 });
    }

    return Response.json({ ok: false, error: "Action tidak dikenal" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error && e.name === "TimeoutError" ? "Server react timeout" : "Gagal menghubungi server react";
    return Response.json({ ok: false, error: msg }, { status: 502 });
  }
}
