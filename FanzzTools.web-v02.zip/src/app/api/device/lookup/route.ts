import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";
import { gunzipSync } from "fflate";
import { DEVICE_DB_B64 } from "@/lib/device-db";

export const runtime = "nodejs";

let dbMap: Record<string, string> | null = null;

function getDb(): Record<string, string> {
  if (dbMap) return dbMap;
  const gz = Buffer.from(DEVICE_DB_B64, "base64");
  const raw = gunzipSync(new Uint8Array(gz));
  const text = new TextDecoder().decode(raw);
  const map: Record<string, string> = {};
  for (const line of text.split("\n")) {
    const tab = line.indexOf("\t");
    if (tab <= 0) continue;
    map[line.slice(0, tab)] = line.slice(tab + 1);
  }
  dbMap = map;
  return map;
}

/** Lookup nama marketing HP dari model code (mis. V2414 → Vivo Y18i). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  /* zuperupdt #5: rate limit (celah audit — sebelumnya tanpa batas) */
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`devlookup:${ip}`, 60, 60 * 1000).ok) return tooManyResponse();

  const model = (req.nextUrl.searchParams.get("model") || "").trim();
  if (!model || model.length > 40) {
    return Response.json({ ok: false, name: null });
  }

  const db = getDb();
  const name = db[model] || null;
  return Response.json({ ok: true, name });
}
