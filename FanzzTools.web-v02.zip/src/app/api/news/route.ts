import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Berita terkini — update tiap menit (cache server 60 detik).
 *
 * - Utama: sesuai lokasi user (country code). Indonesia → CNN Indonesia +
 *   Antara; Rusia → RT + Google News RU; negara lain → Google News versi
 *   negara itu + BBC World.
 * - Kategori lain: CNN Indonesia (nasional/teknologi/olahraga/ekonomi/hiburan)
 *   + Google News topik.
 */

export interface NewsItem {
  title: string;
  url: string;
  source: string;
  image: string | null;
  pubDate: string;
  summary: string;
  cred: "tinggi" | "sedang";
}

const g = globalThis as unknown as {
  __fanzzNewsCache?: Map<string, { items: NewsItem[]; at: number }>;
};
if (!g.__fanzzNewsCache) g.__fanzzNewsCache = new Map();
const cache = g.__fanzzNewsCache;

const CATS = ["utama", "nasional", "internasional", "teknologi", "olahraga", "ekonomi", "hiburan", "sains"];

/** bahasa Google News per negara (fallback en). */
const LANGS: Record<string, string> = {
  ID: "id", RU: "ru", US: "en", GB: "en", MY: "ms", SG: "en", JP: "ja", KR: "ko",
  CN: "zh-Hans", IN: "en", AU: "en", DE: "de", FR: "fr", NL: "nl", SA: "ar",
  AE: "ar", TH: "th", VN: "vi", PH: "en", BR: "pt", CA: "en", TR: "tr", EG: "ar",
  PK: "en", BD: "bn", ES: "es", IT: "it", PT: "pt",
};

function decode(s: string): string {
  return s
    .replace(/<!\[CDATA\[|\]\]>/g, "")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .trim();
}

function stripTags(s: string): string {
  return decode(s.replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
}

/** Parser RSS tanpa dependensi. */
function parseRss(xml: string, source: string, cred: "tinggi" | "sedang", limit = 14): NewsItem[] {
  const out: NewsItem[] = [];
  const items = xml.split(/<item[\s>]/).slice(1);
  for (const it of items) {
    if (out.length >= limit) break;
    const titleM = it.match(/<title>([\s\S]*?)<\/title>/);
    const linkM = it.match(/<link>([\s\S]*?)<\/link>/) || it.match(/<guid[^>]*isPermaLink="false"[^>]*>([\s\S]*?)<\/guid>/);
    const dateM = it.match(/<pubDate>([\s\S]*?)<\/pubDate>/) || it.match(/<(\w+:[Dd]ate)>([\s\S]*?)<\/\w+:[Dd]ate>/);
    const descM = it.match(/<description>([\s\S]*?)<\/description>/);

    const title = titleM ? decode(titleM[1]) : "";
    let url = linkM ? decode(linkM[1]) : "";
    if (!/^https?:\/\//.test(url)) {
      const alt = it.match(/<guid[^>]*>(https?:\/\/[^<]+)<\/guid>/);
      if (alt) url = decode(alt[1]);
    }
    if (!title || !url) continue;

    // gambar: enclosure > media:content > media:thumbnail > <img> di description
    let image: string | null = null;
    const enc = it.match(/<enclosure[^>]*url="([^"]+)"/);
    const media = it.match(/<media:content[^>]*url="([^"]+)"/) || it.match(/<media:thumbnail[^>]*url="([^"]+)"/);
    const descRaw = descM ? descM[1] : "";
    const imgInDesc = descRaw.match(/<img[^>]*src=["']([^"']+)["']/);
    image = (enc && enc[1]) || (media && media[1]) || (imgInDesc && imgInDesc[1]) || null;
    if (image && image.startsWith("//")) image = "https:" + image;

    const summary = stripTags(descRaw).slice(0, 260);
    const pubDate = dateM ? decode(dateM[1]) : "";

    out.push({ title, url, source, image, pubDate, summary, cred });
  }
  return out;
}

async function fetchRss(url: string, timeout = 12000): Promise<string | null> {
  try {
    const r = await fetch(url, {
      headers: { "User-Agent": UA_DESKTOP, Accept: "application/rss+xml, application/xml, text/xml, */*" },
      signal: AbortSignal.timeout(timeout),
      cache: "no-store",
    });
    if (!r.ok) return null;
    const t = await r.text();
    return t.includes("<item") || t.includes("<entry") ? t : null;
  } catch {
    return null;
  }
}

function sourcesFor(cat: string, cc: string): Array<{ url: string; name: string; cred: "tinggi" | "sedang" }> {
  const country = (cc || "ID").toUpperCase();
  const lang = LANGS[country] || "en";
  const gnews = (q: string) =>
    `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=${lang}&gl=${country}&ceid=${country}:${lang}`;

  if (cat === "utama") {
    if (country === "ID") {
      return [
        { url: "https://www.cnnindonesia.com/rss", name: "CNN Indonesia", cred: "tinggi" },
        { url: "https://www.antaranews.com/rss/top-news", name: "ANTARA", cred: "tinggi" },
        { url: `https://news.google.com/rss?hl=id&gl=ID&ceid=ID:id`, name: "Google Berita", cred: "sedang" },
      ];
    }
    if (country === "RU") {
      return [
        { url: "https://www.rt.com/rss/news/", name: "RT", cred: "sedang" },
        { url: `https://news.google.com/rss?hl=ru&gl=RU&ceid=RU:ru`, name: "Google Новости", cred: "sedang" },
      ];
    }
    return [
      { url: `https://news.google.com/rss?hl=${lang}&gl=${country}&ceid=${country}:${lang}`, name: "Google News", cred: "sedang" },
      { url: "https://feeds.bbci.co.uk/news/rss.xml", name: "BBC News", cred: "tinggi" },
    ];
  }
  if (country === "ID") {
    switch (cat) {
      case "nasional": return [{ url: "https://www.cnnindonesia.com/nasional/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "internasional": return [{ url: "https://www.cnnindonesia.com/internasional/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "teknologi": return [{ url: "https://www.cnnindonesia.com/teknologi/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "olahraga": return [{ url: "https://www.cnnindonesia.com/olahraga/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "ekonomi": return [{ url: "https://www.cnnindonesia.com/ekonomi/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "hiburan": return [{ url: "https://www.cnnindonesia.com/hiburan/rss", name: "CNN Indonesia", cred: "tinggi" }];
      case "sains": return [{ url: gnews("sains teknologi penelitian"), name: "Google Berita", cred: "sedang" }];
    }
  }
  // negara lain: topik via Google News berbahasa negara itu
  const topicQ: Record<string, string> = {
    nasional: "national news",
    internasional: "world news",
    teknologi: "technology news",
    olahraga: "sports news",
    ekonomi: "economy business news",
    hiburan: "entertainment news",
    sains: "science news",
  };
  return [{ url: gnews(topicQ[cat] || "news"), name: "Google News", cred: "sedang" }];
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`news:${ip}`, 60, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const cat = (req.nextUrl.searchParams.get("cat") || "utama").toLowerCase();
  const cc = (req.nextUrl.searchParams.get("cc") || "ID").slice(0, 2).toUpperCase();
  const key = `${cat}:${cc}`;

  const cached = cache.get(key);
  if (cached && Date.now() - cached.at < 60 * 1000) {
    return Response.json({ ok: true, items: cached.items, cached: true });
  }

  const sources = sourcesFor(CATS.includes(cat) ? cat : "utama", cc);
  const results = await Promise.allSettled(
    sources.map((s) => fetchRss(s.url).then((xml) => (xml ? parseRss(xml, s.name, s.cred) : [])))
  );

  // gabung interleave biar adil antar sumber
  const merged: NewsItem[] = [];
  const lists = results.map((r) => (r.status === "fulfilled" ? r.value : []));
  const seen = new Set<string>();
  for (let i = 0; i < 20; i++) {
    for (const list of lists) {
      if (list[i]) {
        const dupeKey = list[i].title.toLowerCase().slice(0, 60);
        if (seen.has(dupeKey)) continue;
        seen.add(dupeKey);
        merged.push(list[i]);
      }
    }
  }

  // urut berdasarkan waktu terbaru
  merged.sort((a, b) => new Date(b.pubDate).getTime() - new Date(a.pubDate).getTime());

  const items = merged.slice(0, 30);
  cache.set(key, { items, at: Date.now() });

  return Response.json({
    ok: true,
    items,
    country: cc,
    updatedAt: Date.now(),
  });
}
