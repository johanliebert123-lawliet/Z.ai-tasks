import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Cek fakta / indikasi hoaks untuk satu judul berita.
 * Sumber: turnbackhoax.id (Mafindo) + cekfakta.com + Google News "fact check".
 * Hasil "clear" ≠ 100% terbukti benar — hanya tidak ditemukan laporan hoaks.
 */

function decode(s: string): string {
  return s
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&nbsp;/g, " ")
    .trim();
}

interface FactHit {
  title: string;
  url: string;
  source: string;
}

async function wpSearch(host: string, label: string, q: string): Promise<FactHit[]> {
  try {
    const r = await fetch(
      `https://${host}/?s=${encodeURIComponent(q)}`,
      {
        headers: { "User-Agent": UA_DESKTOP, Accept: "text/html" },
        signal: AbortSignal.timeout(10000),
      }
    );
    if (!r.ok) return [];
    const html = await r.text();
    const hits: FactHit[] = [];
    const re = /<h[12][^>]*class="[^"]*(?:entry-title|post-title|cd-title)[^"]*"[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) && hits.length < 4) {
      const title = decode(m[2].replace(/<[^>]+>/g, "")).trim();
      if (title && m[1].startsWith("http")) hits.push({ title, url: m[1], source: label });
    }
    return hits;
  } catch {
    return [];
  }
}

async function gnewsFactCheck(q: string): Promise<FactHit[]> {
  try {
    const r = await fetch(
      `https://news.google.com/rss/search?q=${encodeURIComponent(`"${q}" fact check OR cek fakta OR hoax`)}&hl=id&gl=ID&ceid=ID:id`,
      {
        headers: { "User-Agent": UA_DESKTOP },
        signal: AbortSignal.timeout(10000),
      }
    );
    if (!r.ok) return [];
    const xml = await r.text();
    const hits: FactHit[] = [];
    const items = xml.split("<item>").slice(1);
    for (const it of items.slice(0, 5)) {
      const t = it.match(/<title>([\s\S]*?)<\/title>/);
      const l = it.match(/<link>([\s\S]*?)<\/link>/);
      if (t && l) {
        hits.push({
          title: decode(t[1].replace(/<!\[CDATA\[|\]\]>/g, "")),
          url: decode(l[1]),
          source: "Google Berita",
        });
      }
    }
    return hits;
  } catch {
    return [];
  }
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`factcheck:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan request" }, { status: 429 });
  }

  const q = (req.nextUrl.searchParams.get("q") || "").trim().slice(0, 140);
  if (q.length < 8) {
    return Response.json({ ok: false, error: "Judul terlalu pendek" }, { status: 400 });
  }

  // kata kunci inti (buang portal & tanda baca berlebih)
  const core = q
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 3)
    .slice(0, 6)
    .join(" ");
  const query = core || q.slice(0, 60);

  const [tbh, cfk, gn] = await Promise.allSettled([
    wpSearch("turnbackhoax.id", "TurnBackHoax (Mafindo)", query),
    wpSearch("cekfakta.com", "CekFakta", query),
    gnewsFactCheck(query),
  ]);

  const hits = [
    ...(tbh.status === "fulfilled" ? tbh.value : []),
    ...(cfk.status === "fulfilled" ? cfk.value : []),
    ...(gn.status === "fulfilled" ? gn.value : []),
  ];

  return Response.json({
    ok: true,
    query,
    verdict: hits.length ? "flagged" : "clear",
    hits: hits.slice(0, 6),
    checkedAt: Date.now(),
  });
}
