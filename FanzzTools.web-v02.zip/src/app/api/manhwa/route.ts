import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_MOBILE } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Baca Manhwa — dua sumber digabung:
 *
 * 1. manwhaku.my.id (API JSON internal, butuh cookie sesi mw_csrf + header
 *    Sec-Fetch same-origin). Katalog & pembaca chapter utama.
 *    PERBAIKAN V2a: endpoint search upstream selalu mengembalikan satu objek
 *    yang sama untuk query apa pun (rusak) — kini hasil satu-objek hanya
 *    dipakai bila judulnya benar-benar cocok, sisanya dibuang.
 * 2. MangaDex (api.mangadex.org) — pencarian cadangan yang stabil dengan
 *    katalog manhwa/manhua/manga sangat lengkap, termasuk pembaca chapter
 *    via at-home server.
 *
 * Endpoint: ?home= | ?q= | ?slug= (detail) | ?read= (gambar chapter)
 *           | ?mdq= (search mangadex) | ?mdid= (detail mangadex)
 *           | ?mdchapter= (chapter list) | ?mdpages= (gambar chapter mangadex)
 */

const BASE = "https://manwhaku.my.id";
const MD = "https://api.mangadex.org";

/** Situs manwhaku menolak klien non-browser — header lengkap + cookie wajib. */
function browserHeaders(cookie: string, sameOrigin: boolean): Record<string, string> {
  return {
    "User-Agent": UA_MOBILE,
    Accept: "application/json, text/plain, */*",
    "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
    "Sec-CH-UA": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    "Sec-CH-UA-Mobile": "?1",
    "Sec-CH-UA-Platform": '"Android"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": sameOrigin ? "same-origin" : "none",
    Referer: "https://manwhaku.my.id/",
    ...(cookie ? { Cookie: cookie } : {}),
  };
}

const g = globalThis as unknown as { __mwCookie?: string; __mwCookieAt?: number };

async function getCookie(): Promise<string> {
  if (g.__mwCookie && g.__mwCookieAt && Date.now() - g.__mwCookieAt < 10 * 60 * 1000) {
    return g.__mwCookie;
  }
  try {
    const res = await fetch(BASE, {
      headers: {
        "User-Agent": UA_MOBILE,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "id-ID,id;q=0.9",
        "Sec-Fetch-Dest": "document",
        "Sec-Fetch-Mode": "navigate",
        "Sec-Fetch-Site": "none",
        "Upgrade-Insecure-Requests": "1",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(30000),
    });
    const cookies = res.headers.getSetCookie?.() || [];
    const jar = cookies.map((c) => c.split(";")[0]).join("; ");
    if (jar) {
      g.__mwCookie = jar;
      g.__mwCookieAt = Date.now();
      return jar;
    }
    return g.__mwCookie || "";
  } catch {
    return g.__mwCookie || "";
  }
}

async function apiGet<T = Record<string, unknown>>(path: string, tries = 2): Promise<T | null> {
  const cookie = await getCookie();
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(BASE + path, {
        headers: browserHeaders(cookie, true),
        redirect: "follow",
        signal: AbortSignal.timeout(40000),
      });
      if (res.status === 401 || res.status === 403) {
        // cookie basi → ambil ulang lalu retry
        g.__mwCookie = "";
        g.__mwCookieAt = 0;
        const fresh = await getCookie();
        if (i < tries - 1 && fresh && fresh !== cookie) continue;
      }
      if (!res.ok) return null;
      const text = await res.text();
      if (text.trimStart().startsWith("<")) return null;
      return JSON.parse(text) as T;
    } catch {
      /* retry */
    }
  }
  return null;
}

async function mdGet<T = Record<string, unknown>>(path: string): Promise<T | null> {
  try {
    const res = await fetch(MD + path, {
      headers: { "User-Agent": UA_MOBILE, Accept: "application/json" },
      signal: AbortSignal.timeout(25000),
    });
    if (!res.ok) return null;
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

interface ApiManga {
  title: string;
  slug: string;
  chapter?: string;
  link?: string;
  thumb?: string;
  coverImage?: string;
  type?: string;
  rating?: string;
  source?: string;
}

interface ApiChapter {
  title?: string;
  chapter?: string;
  chapterNumber?: string;
  slug?: string;
  url?: string;
}

function normalizeCard(m: ApiManga) {
  return {
    judul: (m.title || "").slice(0, 100),
    slug: m.slug,
    sumber: "manwhaku" as const,
    url: m.link ? (m.link.startsWith("http") ? m.link : BASE + m.link) : `${BASE}/manga/${m.slug}`,
    thumbnail: m.thumb || m.coverImage || null,
    type: m.type || null,
    rating: m.rating || null,
    chapterTerbaru: m.chapter || null,
  };
}

/** Ambil judul terbaik MangaDex (utamakan English → romaji → apa pun). */
function mdTitle(attributes: Record<string, unknown>): string {
  const title = (attributes?.title || {}) as Record<string, string>;
  const alt = (attributes?.altTitles || []) as Array<Record<string, string>>;
  return (
    title.en ||
    title["ja-ro"] ||
    title.ko ||
    title.ja ||
    Object.values(title)[0] ||
    alt.find((a) => a.en)?.en ||
    alt.find((a) => a["ja-ro"])?.["ja-ro"] ||
    Object.values(alt[0] || {})[0] ||
    "Tanpa Judul"
  );
}

function mdCover(mangaId: string, relationships: Array<{ type?: string; attributes?: Record<string, unknown> }>): string | null {
  const cover = relationships?.find((r) => r?.type === "cover_art");
  const file = cover?.attributes?.fileName as string | undefined;
  return file ? `https://uploads.mangadex.org/covers/${mangaId}/${file}.256.jpg` : null;
}

const MD_CONTENT_RATING = "&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica";
const MD_STATUS = "&status[]=ongoing&status[]=completed&status[]=hiatus&status[]=cancelled";

interface MdManga {
  id: string;
  attributes: Record<string, unknown>;
  relationships: Array<{ type?: string; attributes?: Record<string, unknown> }>;
}

async function mdSearch(q: string): Promise<unknown[]> {
  const d = await mdGet<{ data?: MdManga[] }>(
    `/manga?title=${encodeURIComponent(q)}&limit=12&order[followedCount]=desc${MD_CONTENT_RATING}${MD_STATUS}&includes[]=cover_art&hasAvailableChapters=true`
  );
  return (d?.data || []).map((m) => ({
    judul: mdTitle(m.attributes).slice(0, 100),
    slug: `md-${m.id}`,
    sumber: "mangadex",
    url: `${MD}/manga/${m.id}`,
    thumbnail: mdCover(m.id, m.relationships || []),
    type: String((m.attributes?.originalLanguage as string) || "").toUpperCase() === "KO" ? "Manhwa" : String((m.attributes?.originalLanguage as string) || "").toUpperCase() === "ZH" ? "Manhua" : "Manga",
    rating: null,
    chapterTerbaru: null,
    deskripsi: ((m.attributes?.description || {}) as Record<string, string>)?.en?.slice(0, 300) || null,
  }));
}

const CACHE = new Map<string, { at: number; data: unknown }>();
const TTL = 5 * 60 * 1000;

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`mw:${ip}`, 25, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — mohon tunggu sebentar" }, { status: 429 });
  }

  const sp = req.nextUrl.searchParams;
  const ckey = sp.toString();

  try {
    const hit = CACHE.get(ckey);
    if (hit && Date.now() - hit.at < TTL) {
      return Response.json({ ok: true, ...(hit.data as object) });
    }

    let payload: Record<string, unknown> | null = null;

    /* ---- HOME: katalog populer (manwhaku + populer MangaDex) ---- */
    if (sp.get("home") !== null) {
      const d = await apiGet<{ success: boolean; data: ApiManga[] | { data?: ApiManga[] } }>("/api/manga?page=1");
      const list = d?.success
        ? (Array.isArray(d.data) ? d.data : ((d.data as { data?: ApiManga[] })?.data || []))
        : [];
      const mdHome = await mdGet<{ data?: MdManga[] }>(
        `/manga?limit=24&order[followedCount]=desc${MD_CONTENT_RATING}&includes[]=cover_art&hasAvailableChapters=true`
      );
      const mdCards = (mdHome?.data || []).map((m) => ({
        judul: mdTitle(m.attributes).slice(0, 100),
        slug: `md-${m.id}`,
        sumber: "mangadex",
        url: `${MD}/manga/${m.id}`,
        thumbnail: mdCover(m.id, m.relationships || []),
        type: String((m.attributes?.originalLanguage as string) || "").toUpperCase() === "KO" ? "Manhwa" : "Manga",
        rating: null,
        chapterTerbaru: null,
      }));
      // gabung: manwhaku dulu, lalu MangaDex yang belum ada (dedup judul)
      const seen = new Set<string>();
      const merged = [...list.map(normalizeCard), ...mdCards].filter((c) => {
        const k = c.judul.toLowerCase().slice(0, 40);
        if (seen.has(k)) return false;
        seen.add(k);
        return true;
      });
      payload = merged.length ? { manga: merged.slice(0, 48) } : null;
    }
    /* ---- SEARCH: manwhaku (kadang rusak) + MangaDex (stabil), digabung ---- */
    else if (sp.get("q")) {
      const q = sp.get("q")!.slice(0, 80);
      const results: Array<Record<string, unknown>> = [];

      // 1) manwhaku — endpoint search-nya sering mengembalikan SATU objek yang
      //    sama untuk semua query. Validasi: hanya terima bila judulnya cocok.
      const d = await apiGet<{ success: boolean; data: ApiManga[] | Record<string, unknown> }>(
        `/api/manga/search?q=${encodeURIComponent(q)}`
      );
      if (d?.success) {
        const ql = q.toLowerCase();
        if (Array.isArray(d.data)) {
          results.push(...d.data.map(normalizeCard));
        } else {
          const obj = d.data as ApiManga & { results?: ApiManga[] };
          const title = String(obj?.title || "");
          const tokens = ql.split(/\s+/).filter(Boolean);
          const matches = tokens.length > 0 && tokens.some((t) => title.toLowerCase().includes(t));
          if (matches) results.push(normalizeCard(obj));
          if (Array.isArray(obj?.results)) results.push(...obj.results.map(normalizeCard));
        }
      }

      // 2) MangaDex — sumber pencarian utama yang stabil
      try {
        results.push(...(await mdSearch(q)));
      } catch {
        /* mangadex opsional */
      }

      payload = { query: q, results: results.slice(0, 30) };
    }
    /* ---- DETAIL MANGADEX ---- */
    else if (sp.get("mdid")) {
      const id = sp.get("mdid")!.replace(/[^a-z0-9-]/gi, "").slice(0, 60);
      const [m, feed] = await Promise.all([
        mdGet<{ data: MdManga }>(`/manga/${id}?includes[]=cover_art&includes[]=author&includes[]=artist`),
        mdGet<{ data: Array<{ id: string; attributes: Record<string, unknown> }> }>(
          `/manga/${id}/feed?translatedLanguage[]=en&translatedLanguage[]=id&order[chapter]=desc&limit=300${MD_CONTENT_RATING}`
        ),
      ]);
      const manga = m?.data;
      if (!manga) {
        payload = null;
      } else {
        const attrs = manga.attributes || {};
        // chapter yang dapat dibaca langsung (punya halaman, bukan tautan eksternal)
        const allChapters = feed?.data || [];
        const readable = allChapters.filter((c) => {
          const a = c.attributes || {};
          return !a.externalUrl && (Number(a.pages) || 0) > 0;
        });
        const chapterSource = readable.length ? readable : allChapters;
        const chapters = chapterSource.map((c) => ({
          chapter: c.attributes?.chapter ? `Chapter ${c.attributes.chapter}` : "Oneshot",
          slug: `mdch_${c.id}`,
          url: c.attributes?.externalUrl ? String(c.attributes.externalUrl) : `${MD}/chapter/${c.id}`,
          lang: String(c.attributes?.translatedLanguage || ""),
          title: String(c.attributes?.title || ""),
          eksternal: Boolean(c.attributes?.externalUrl),
        }));
        const desc = (attrs?.description || {}) as Record<string, string>;
        const authorRel = (manga.relationships || []).find((r) => r?.type === "author");
        payload = {
          judul: mdTitle(attrs),
          sumber: "mangadex",
          slug: `md-${id}`,
          sebagianEksternal: readable.length === 0 && allChapters.length > 0,
          thumbnail: mdCover(id, manga.relationships || []),
          synopsis: desc.en || desc.id || null,
          type: String((attrs?.originalLanguage as string) || "").toUpperCase() === "KO" ? "Manhwa" : "Manga",
          status: String(attrs?.status || "") || null,
          rating: null,
          author: (authorRel?.attributes?.name as string) || null,
          genres: ((attrs?.tags || []) as Array<{ attributes?: { name?: Record<string, string> } }>)
            .map((t) => t?.attributes?.name?.en)
            .filter(Boolean)
            .slice(0, 10),
          totalChapters: chapters.length,
          chapters,
        };
      }
    }
    /* ---- CHAPTER LIST MANGADEX (ringan, tanpa detail) ---- */
    else if (sp.get("mdchapter")) {
      const id = sp.get("mdchapter")!.replace(/[^a-z0-9-]/gi, "").slice(0, 60);
      const feed = await mdGet<{ data: Array<{ id: string; attributes: Record<string, unknown> }> }>(
        `/manga/${id}/feed?translatedLanguage[]=en&translatedLanguage[]=id&order[chapter]=desc&limit=300${MD_CONTENT_RATING}`
      );
      payload = feed?.data
        ? {
            chapters: feed.data
              .filter((c) => {
                const a = c.attributes || {};
                return !a.externalUrl && (Number(a.pages) || 0) > 0;
              })
              .map((c) => ({
                chapter: c.attributes?.chapter ? `Chapter ${c.attributes.chapter}` : "Oneshot",
                slug: `mdch_${c.id}`,
                url: `${MD}/chapter/${c.id}`,
                lang: String(c.attributes?.translatedLanguage || ""),
                title: String(c.attributes?.title || ""),
              })),
          }
        : null;
    }
    /* ---- READ MANGADEX (gambar via at-home server) ---- */
    else if (sp.get("mdpages")) {
      const chapterId = sp.get("mdpages")!.replace(/[^a-z0-9-]/gi, "").slice(0, 60);
      // metadata chapter dulu (nomor + manga id + prev/next)
      const [ch, home] = await Promise.all([
        mdGet<{ data: { attributes: Record<string, unknown>; relationships: Array<{ type?: string; id?: string }> } }>(`/chapter/${chapterId}`),
        mdGet<{ baseUrl: string; chapter: { hash: string; data: string[]; dataSaver: string[] } }>(`/at-home/server/${chapterId}`),
      ]);
      if (!home?.baseUrl || !home?.chapter) {
        payload = null;
      } else {
        const attrs = ch?.data?.attributes || {};
        const mangaRel = (ch?.data?.relationships || []).find((r) => r?.type === "manga");
        // prev/next: ambil daftar chapter manga ini lalu cari posisi
        let prevSlug: string | null = null;
        let nextSlug: string | null = null;
        if (mangaRel?.id) {
          const feed = await mdGet<{ data: Array<{ id: string; attributes: Record<string, unknown> }> }>(
            `/manga/${mangaRel.id}/feed?translatedLanguage[]=en&translatedLanguage[]=id&order[chapter]=desc&limit=300${MD_CONTENT_RATING}`
          );
          const readable = (feed?.data || []).filter((c) => {
            const a = c.attributes || {};
            return !a.externalUrl && (Number(a.pages) || 0) > 0;
          });
          const idx = readable.findIndex((c) => c.id === chapterId);
          if (idx >= 0) {
            prevSlug = readable[idx + 1] ? `mdch_${readable[idx + 1].id}` : null; // lebih lama
            nextSlug = readable[idx - 1] ? `mdch_${readable[idx - 1].id}` : null; // lebih baru
          }
        }
        const images = (home.chapter.data || []).map(
          (f) => `${home.baseUrl}/data/${home.chapter.hash}/${f}`
        );
        payload = {
          judul: "MangaDex",
          chapter: attrs?.chapter ? `Chapter ${attrs.chapter}` : "Oneshot",
          totalImages: images.length,
          totalPages: images.length,
          images: images.slice(0, 200),
          prevSlug,
          nextSlug,
        };
      }
    }
    /* ---- DETAIL (manwhaku) ---- */
    else if (sp.get("slug")) {
      const slug = sp.get("slug")!.replace(/[^a-z0-9-]/gi, "").slice(0, 120);
      const d = await apiGet<{ success: boolean; data: Record<string, unknown> }>(`/api/manga/${slug}`);
      if (!d?.success || !d.data) {
        payload = null;
      } else {
        const dd = d.data;
        payload = {
          judul: String(dd.title || slug),
          sumber: "manwhaku",
          thumbnail: String(dd.coverImage || "") || null,
          synopsis: dd.synopsis ? String(dd.synopsis).slice(0, 2000) : null,
          type: dd.type || null,
          status: dd.status || null,
          rating: dd.rating || null,
          author: dd.author || null,
          genres: Array.isArray(dd.genres) ? dd.genres : [],
          totalChapters: Array.isArray(dd.chapters) ? (dd.chapters as ApiChapter[]).length : 0,
          chapters: (Array.isArray(dd.chapters) ? (dd.chapters as ApiChapter[]) : []).map((c) => ({
            chapter: String(c.chapter || c.title || c.chapterNumber || "").slice(0, 60) || "Chapter",
            slug: String(c.slug || ""),
            url: c.slug ? `${BASE}/read/${c.slug}` : "",
          })),
        };
      }
    }
    /* ---- READ (manwhaku) ---- */
    else if (sp.get("read")) {
      const slug = sp.get("read")!
        .replace(BASE, "")
        .replace("/read/", "")
        .replace(/[^a-z0-9-]/gi, "")
        .slice(0, 160);
      const d = await apiGet<{ success: boolean; data: Record<string, unknown> }>(`/api/chapter/${slug}`);
      if (!d?.success || !d.data) {
        payload = null;
      } else {
        const dd = d.data as {
          manga?: string;
          chapter?: string;
          totalPages?: number;
          images?: string[];
          prevChapterSlug?: string | null;
          nextChapterSlug?: string | null;
        };
        payload = {
          judul: dd.manga || slug,
          chapter: dd.chapter || "Chapter",
          totalImages: (dd.images || []).length,
          totalPages: dd.totalPages || (dd.images || []).length,
          images: (dd.images || []).slice(0, 120),
          prevSlug: dd.prevChapterSlug || null,
          nextSlug: dd.nextChapterSlug || null,
        };
      }
    } else {
      return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
    }

    if (!payload) {
      return Response.json(
        { ok: false, error: "Sumber manhwa sedang bermasalah — silakan coba lagi beberapa saat" },
        { status: 502 }
      );
    }
    CACHE.set(ckey, { at: Date.now(), data: payload });
    return Response.json({ ok: true, ...payload });
  } catch {
    return Response.json({ ok: false, error: "Gagal memproses permintaan" }, { status: 500 });
  }
}
