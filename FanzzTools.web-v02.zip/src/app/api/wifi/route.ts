import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";

export const runtime = "nodejs";

/**
 * WiFi Analyzer (zuperupdt #15) — pendukung server untuk tools "Check WiFi".
 *
 *   ?ip=1        → IP publik pengguna + ISP/org + negara (untuk panel jaringan)
 *   ?dns=1       → cek resolver DNS pengguna dari sisi KLIEN tidak memungkinkan
 *                  (CORS) — server menyediakan daftar endpoint DoH publik yang
 *                  dicoba KLIEN sendiri; route ini hanya penanda kebijakan.
 *   ?check=<pw>&ssid=<ssid>&brand=<brand>
 *                → audit password: cocokkan dengan maksimal 10 pola password
 *                  default/umum (tebakan dibatasi 10 — lebih dari itu selalu
 *                  dijawab "tidak ditemukan" sesuai spesifikasi pemilik).
 *
 * Semua hanya untuk JARINGAN MILIK SENDIRI (audit keamanan router sendiri).
 */

/** 10 pola tebakan password default paling umum (urut popularitas Indonesia). */
function kandidatPassword(ssid: string, brand: string): string[] {
  const s = (ssid || "").replace(/\s+/g, "").toLowerCase().slice(0, 16);
  const b = (brand || "").toLowerCase();
  const out: string[] = [];
  const add = (x: string) => {
    if (x && x.length >= 4 && !out.includes(x) && out.length < 10) out.push(x);
  };
  add("admin"); add("password"); add("12345678"); add("1234567890");
  add("admin123"); add(`${s}1234`); add(s);
  if (/indihome|ztel|huawei|hg6|f660|f609/.test(b) || b === "") { add("adminwifi"); add("wifi12345"); }
  if (/tplink|tp-link/.test(b)) { add("tplink1234"); }
  if (/fritz/.test(b)) { add("fritzbox"); }
  add("internet"); add("0123456789");
  return out.slice(0, 10); // MAKSIMAL 10 TEBAKAN — spesifikasi #15
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`wifi:${ip}`, 20, 60 * 1000).ok) return tooManyResponse();

  const sp = req.nextUrl.searchParams;

  /* ---- panel IP publik + ISP ---- */
  if (sp.get("ip") !== null) {
    const clientIp = (req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "").replace(/[^0-9a-fA-F:.]/g, "");
    if (!clientIp || clientIp === "anon") {
      return Response.json({ ok: false, error: "IP klien tidak terbaca (mungkin lewat proxy internal)" }, { status: 400 });
    }
    try {
      const res = await fetch(`http://ip-api.com/json/${encodeURIComponent(clientIp)}?fields=status,country,regionName,city,isp,org,as,reverse,mobile,proxy,hosting,query`, {
        signal: AbortSignal.timeout(10000),
      });
      const d = (await res.json()) as Record<string, unknown>;
      if (d?.status !== "success") throw new Error("up");
      return Response.json({
        ok: true,
        ip: String(d.query || clientIp),
        isp: String(d.isp || ""),
        org: String(d.org || ""),
        negara: String(d.country || ""),
        region: String(d.regionName || ""),
        kota: String(d.city || ""),
        reverse: String(d.reverse || ""),
        mobile: !!d.mobile,
        proxy: !!d.proxy,
      });
    } catch {
      // fallback: kembalikan IP saja tanpa detail ISP
      return Response.json({ ok: true, ip: clientIp, isp: "(detail ISP tidak tersedia)", org: "", negara: "", region: "", kota: "", reverse: "", mobile: false, proxy: false });
    }
  }

  /* ---- audit password: maks 10 tebakan pola default ---- */
  if (sp.get("check") !== null) {
    const pw = (sp.get("pw") || "").slice(0, 64);
    const ssid = (sp.get("ssid") || "").slice(0, 32);
    const brand = (sp.get("brand") || "").slice(0, 32);
    if (!pw) return Response.json({ ok: false, error: "Masukkan password WiFi kamu (hanya untuk audit, tidak dikirim ke mana pun selain server sendiri)" }, { status: 400 });
    const kandidat = kandidatPassword(ssid, brand);
    const cocok = kandidat.indexOf(pw);
    if (cocok >= 0) {
      return Response.json({
        ok: true,
        lemah: true,
        status: "LEMAH",
        cocokPada: cocok + 1,
        totalTebakan: kandidat.length,
        kandidat,
        pesan: `Password kamu cocok dengan pola default umum #${cocok + 1} dari ${kandidat.length} tebakan. Sangat mudah ditebak — GANTI SEGERA di halaman admin router.`,
      });
    }
    return Response.json({
      ok: true,
      lemah: false,
      status: "KUAT",
      totalTebakan: kandidat.length,
      kandidat,
      pesan: `Password tidak ditemukan — ${kandidat.length} tebakan pola default umum semuanya gagal. Password kamu tidak termasuk pola lemah umum. Bagus!`,
    });
  }

  /* ---- daftar kandidat tebakan (preview) ---- */
  if (sp.get("guess") !== null) {
    const ssid = (sp.get("ssid") || "").slice(0, 32);
    const brand = (sp.get("brand") || "").slice(0, 32);
    const kandidat = kandidatPassword(ssid, brand);
    return Response.json({ ok: true, kandidat, totalTebakan: kandidat.length, pesan: "Maksimal 10 tebakan pola default (spesifikasi tools). Untuk jaringan milik sendiri saja." });
  }

  return Response.json({ ok: false, error: "Parameter tidak dikenal" }, { status: 400 });
}
