import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/** Domain lookup via RDAP (standar internet, gratis, tanpa API key). */
/** Bootstrap RDAP IANA: TLD → server resmi. Cache 24 jam di memori. */
let bootstrapCache: { at: number; map: Record<string, string> } | null = null;

async function getRdapBase(tld: string): Promise<string | null> {
  const now = Date.now();
  if (!bootstrapCache || now - bootstrapCache.at > 24 * 3600 * 1000) {
    const res = await fetch("https://data.iana.org/rdap/dns.json", {
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) throw new Error("bootstrap rdap gagal");
    const d = (await res.json()) as { services?: Array<[string[], string[]]> };
    const map: Record<string, string> = {};
    for (const [tlds, urls] of d.services || []) {
      for (const t of tlds) {
        map[t.toLowerCase()] = (urls[0] || "").replace(/\/$/, "");
      }
    }
    bootstrapCache = { at: now, map };
  }
  return bootstrapCache.map[tld.toLowerCase()] || null;
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`domain:${ip}`, 15, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering" }, { status: 429 });
  }

  const domain = (req.nextUrl.searchParams.get("d") || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0];

  if (!/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/.test(domain)) {
    return Response.json({ ok: false, error: "Domain tidak valid (contoh: google.com)" }, { status: 400 });
  }

  const tld = domain.split(".").pop() || "";

  try {
    const base = await getRdapBase(tld);
    // fallback kalau bootstrap gagal: coba verisign (.com/.net) → rdap.org
    const candidates = base
      ? [base]
      : [`https://rdap.verisign.com/${tld}/v1`, "https://rdap.org"];

    let d: Record<string, unknown> | null = null;
    let lastErr = "";
    for (const b of candidates) {
      try {
        const res = await fetch(`${b}/domain/${encodeURIComponent(domain)}`, {
          headers: { Accept: "application/rdap+json, application/json" },
          signal: AbortSignal.timeout(15000),
          redirect: "follow",
        });
        if (res.status === 404) {
          return Response.json({ ok: false, error: "Domain tidak ditemukan / belum terdaftar" }, { status: 404 });
        }
        if (!res.ok) {
          lastErr = `rdap ${res.status}`;
          continue;
        }
        const ct = (res.headers.get("content-type") || "").toLowerCase();
        if (ct && !ct.includes("json")) {
          lastErr = "respon bukan JSON";
          continue;
        }
        d = (await res.json()) as Record<string, unknown>;
        break;
      } catch (e) {
        lastErr = e instanceof Error ? e.message : "rdap gagal";
      }
    }
    if (!d) throw new Error(lastErr || "RDAP tidak merespon");

    // ekstrak data penting
    const events = (d.events || []) as Array<{ eventAction: string; eventDate: string }>;
    const entities = (d.entities || []) as Array<{
      roles?: string[];
      vcardArray?: unknown[];
      handle?: string;
    }>;

    const vcardName = (e: (typeof entities)[number]): string => {
      const v = e.vcardArray as unknown[] | undefined;
      if (!Array.isArray(v) || !Array.isArray(v[1])) return "";
      for (const item of v[1] as Array<unknown>) {
        const it = item as string[];
        if (it[0] === "fn") return String(it[3] || "");
      }
      return "";
    };

    const registrar = entities.find((e) => e.roles?.includes("registrar"));
    const registrant = entities.find((e) => e.roles?.includes("registrant"));
    const nameservers: string[] = ((d.nameservers || []) as Array<{ ldhName?: string; unicodeName?: string }>).map(
      (n) => n.unicodeName || n.ldhName || ""
    ).filter(Boolean);

    const fmtDate = (iso: string) => {
      try {
        return new Date(iso).toLocaleDateString("id-ID", {
          year: "numeric", month: "long", day: "numeric",
        });
      } catch {
        return iso;
      }
    };

    const ev = (action: string) => {
      const e = events.find((x) => x.eventAction === action);
      return e ? fmtDate(e.eventDate) : "-";
    };

    return Response.json({
      ok: true,
      result: {
        domain: (d.ldhName as string) || domain,
        registrar: registrar ? vcardName(registrar) || registrar.handle || "-" : "-",
        pemilik: registrant ? vcardName(registrant) || "-" : "(disembunyikan / privasi)",
        status: ((d.status || []) as string[]).slice(0, 3),
        didaftarkan: ev("registration"),
        diubah: ev("last changed"),
        kedaluwarsa: ev("expiration"),
        nameservers,
        sumber: "RDAP (IANA)",
      },
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal lookup domain" },
      { status: 502 }
    );
  }
}
