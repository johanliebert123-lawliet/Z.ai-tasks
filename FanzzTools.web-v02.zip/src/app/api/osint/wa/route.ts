import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { COUNTRY_PREFIXES, detectCountry, detectWaType, e164Plain } from "@/lib/nokos";

export const runtime = "nodejs";

/**
 * WhatsApp Info (V2.11 #28) — informasi nomor WA yang JUJUR:
 *  - validitas format & asal negara (numbering plan, offline)
 *  - indikasi jenis (reguler/indikasi business dari pola nomor — bukan kepastian)
 *  - tautan wa.me + info operator dari prefix (bila terpetakan)
 *
 *  Yang TIDAK tersedia untuk publik (ditulis terus terang di hasil): nama
 *  profil WA, foto profil, tanggal dibuat, dan status business sesungguhnya —
 *  itu hanya bisa dilihat sesama kontak melalui aplikasi WhatsApp, atau lewat
 *  WhatsApp Business API resmi (butuh persetujuan Meta). Alat apa pun yang
 *  mengaku bisa menariknya tanpa sesi WhatsApp adalah pembodohan/berisiko.
 */

/** Prefix → nama operator Indonesia (indikasi kasar dari 3-4 digit setelah 62). */
const OPERATOR_ID: Array<{ awal: string[]; nama: string }> = [
  { awal: ["811", "812", "813", "821", "822", "851", "852", "853"], nama: "Telkomsel" },
  { awal: ["814", "815", "816", "855", "856", "857", "858"], nama: "Indosat Ooredoo" },
  { awal: ["817", "818", "819", "859", "877", "878"], nama: "XL Axiata" },
  { awal: ["838", "831", "832", "833", "834", "835", "836", "837"], nama: "Axis" },
  { awal: ["895", "896", "897", "898", "899"], nama: "Three (3)" },
  { awal: ["881", "882", "883", "884", "885", "886", "887", "888", "889"], nama: "Smartfren" },
];

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`wainfo:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — tunggu sebentar" }, { status: 429 });
  }

  const input = (req.nextUrl.searchParams.get("number") || "").trim().slice(0, 32);
  if (!input) return Response.json({ ok: false, error: "Nomor kosong" }, { status: 400 });

  // normalisasi: buang spasi, strip, titik, kurung
  const bersih = input.replace(/[\s\-().]/g, "");
  if (!/^\+?\d{8,15}$/.test(bersih)) {
    return Response.json({ ok: false, error: "Format nomor tidak dikenali — masukkan 8-15 digit (boleh diawali +)." }, { status: 400 });
  }

  const e164 = e164Plain(bersih);
  const def = detectCountry(e164);
  const jumlahNegara = COUNTRY_PREFIXES.length;

  if (!def) {
    return Response.json({
      ok: true,
      hasil: {
        valid: false,
        e164,
        negara: null,
        waMe: `https://wa.me/${e164}`,
        catatan: [
          "Kode negara tidak dikenali dalam basis numbering plan kami — nomor mungkin salah ketik atau dari negara yang belum terpetakan.",
        ],
        jumlahNegara,
      },
    });
  }

  const sisa = e164.slice(def.prefix.length);
  const mobileOk = def.mobile?.some((m) => sisa.startsWith(m)) ?? true;

  // operator (khusus Indonesia)
  let operator: string | null = null;
  if (def.iso === "ID") {
    const op3 = sisa.slice(0, 3);
    operator = OPERATOR_ID.find((o) => o.awal.includes(op3))?.nama || null;
  }

  const jenis = detectWaType(e164);

  const catatan: string[] = [];
  catatan.push(`Nomor valid untuk ${def.country} (format E.164: ${e164}).`);
  if (def.mobile?.length) {
    catatan.push(
      mobileOk
        ? `Prefix ${sisa.slice(0, Math.min(3, def.mobile[0]?.length || 2))}… cocok dengan jangkauan nomor seluler ${def.country}.`
        : `PERHATIAN: prefix ini tidak berada di jangkauan nomor seluler umum ${def.country} (prefiks seluler yang dikenal: ${def.mobile.slice(0, 6).join(", ")}…). Nomor mungkin telepon tetap atau tidak aktif.`,
    );
  }
  catatan.push(
    "Nama profil, foto profil, tanggal dibuat akun, dan status WhatsApp Business TIDAK dapat ditarik oleh alat publik mana pun — hanya terlihat sesama kontak di aplikasi, atau lewat WhatsApp Business API resmi Meta. Alat yang mengaku bisa adalah tidak jujur.",
  );

  return Response.json({
    ok: true,
    hasil: {
      valid: mobileOk,
      e164,
      negara: { nama: def.country, iso: def.iso, bendera: def.flag, prefix: `+${def.prefix}` },
      operator,
      jenisIndikasi: jenis,
      panjangSisa: sisa.length,
      waMe: `https://wa.me/${e164}`,
      catatan,
      jumlahNegara,
    },
  });
}
