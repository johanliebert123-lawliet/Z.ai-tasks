import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit, tooManyResponse } from "@/lib/store";

export const runtime = "nodejs";

/**
 * Cek nomor HP Indonesia: operator + jenis kartu + region.
 * Murni pembacaan prefix lokal (tanpa kirim nomor ke luar).
 */

interface OperatorInfo {
  name: string;
  brand: string;
  jenis: string;
  warna: string;
}

const PREFIXES: Array<{ p: string; op: OperatorInfo }> = [
  // Telkomsel
  { p: "811", op: { name: "Telkomsel", brand: "simPATI / Kartu As", jenis: "Pra-pembayaran", warna: "merah-putih" } },
  { p: "812", op: { name: "Telkomsel", brand: "simPATI / Halo", jenis: "Pra & pasca", warna: "merah-putih" } },
  { p: "813", op: { name: "Telkomsel", brand: "simPATI / Halo", jenis: "Pra & pasca", warna: "merah-putih" } },
  { p: "821", op: { name: "Telkomsel", brand: "simPATI", jenis: "Pra-pembayaran", warna: "merah-putih" } },
  { p: "822", op: { name: "Telkomsel", brand: "Loop", jenis: "Pra-pembayaran", warna: "merah-putih" } },
  { p: "823", op: { name: "Telkomsel", brand: "simPATI", jenis: "Pra-pembayaran", warna: "merah-putih" } },
  { p: "851", op: { name: "Telkomsel", brand: "Halo", jenis: "Pasca-bayar", warna: "merah-putih" } },
  { p: "852", op: { name: "Telkomsel", brand: "Halo", jenis: "Pasca-bayar", warna: "merah-putih" } },
  { p: "853", op: { name: "Telkomsel", brand: "Halo", jenis: "Pasca-bayar", warna: "merah-putih" } },
  // Indosat
  { p: "814", op: { name: "Indosat Ooredoo Hutchison", brand: "IM3 (Mentari)", jenis: "Pra-pembayaran", warna: "kuning" } },
  { p: "815", op: { name: "Indosat Ooredoo Hutchison", brand: "IM3 (Mentari)", jenis: "Pra-pembayaran", warna: "kuning" } },
  { p: "816", op: { name: "Indosat Ooredoo Hutchison", brand: "Matrix", jenis: "Pasca-bayar", warna: "kuning" } },
  { p: "855", op: { name: "Indosat Ooredoo Hutchison", brand: "Matrix", jenis: "Pasca-bayar", warna: "kuning" } },
  { p: "856", op: { name: "Indosat Ooredoo Hutchison", brand: "IM3", jenis: "Pra-pembayaran", warna: "kuning" } },
  { p: "857", op: { name: "Indosat Ooredoo Hutchison", brand: "IM3", jenis: "Pra-pembayaran", warna: "kuning" } },
  { p: "858", op: { name: "Indosat Ooredoo Hutchison", brand: "IM3", jenis: "Pra-pembayaran", warna: "kuning" } },
  // XL Axiata
  { p: "817", op: { name: "XL Axiata", brand: "XL", jenis: "Pasca-bayar", warna: "biru" } },
  { p: "818", op: { name: "XL Axiata", brand: "XL", jenis: "Pasca-bayar", warna: "biru" } },
  { p: "819", op: { name: "XL Axiata", brand: "XL", jenis: "Pasca-bayar", warna: "biru" } },
  { p: "859", op: { name: "XL Axiata", brand: "XL", jenis: "Pra & pasca", warna: "biru" } },
  { p: "877", op: { name: "XL Axiata", brand: "XL", jenis: "Pra-pembayaran", warna: "biru" } },
  { p: "878", op: { name: "XL Axiata", brand: "XL", jenis: "Pra-pembayaran", warna: "biru" } },
  // Axis
  { p: "831", op: { name: "XL Axiata", brand: "AXIS", jenis: "Pra-pembayaran", warna: "ungu-hijau" } },
  { p: "832", op: { name: "XL Axiata", brand: "AXIS", jenis: "Pra-pembayaran", warna: "ungu-hijau" } },
  { p: "833", op: { name: "XL Axiata", brand: "AXIS", jenis: "Pra-pembayaran", warna: "ungu-hijau" } },
  { p: "838", op: { name: "XL Axiata", brand: "AXIS", jenis: "Pra-pembayaran", warna: "ungu-hijau" } },
  // Tri (3)
  { p: "895", op: { name: "Tri (Hutchison 3 Indonesia)", brand: "3 (Tri)", jenis: "Pra-pembayaran", warna: "hitam-putih" } },
  { p: "896", op: { name: "Tri (Hutchison 3 Indonesia)", brand: "3 (Tri)", jenis: "Pra-pembayaran", warna: "hitam-putih" } },
  { p: "897", op: { name: "Tri (Hutchison 3 Indonesia)", brand: "3 (Tri)", jenis: "Pra-pembayaran", warna: "hitam-putih" } },
  { p: "898", op: { name: "Tri (Hutchison 3 Indonesia)", brand: "3 (Tri)", jenis: "Pra-pembayaran", warna: "hitam-putih" } },
  { p: "899", op: { name: "Tri (Hutchison 3 Indonesia)", brand: "3 (Tri)", jenis: "Pra-pembayaran", warna: "hitam-putih" } },
  // Smartfren
  { p: "881", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "882", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "883", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "884", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "885", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "886", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "887", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "888", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  { p: "889", op: { name: "Smartfren", brand: "Smartfren", jenis: "Pra-pembayaran", warna: "merah-biru" } },
  // Byru (Telkomsat maritime)
  { p: "891", op: { name: "Byru (Telkomsat)", brand: "Byru", jenis: "Maritim", warna: "biru" } },
  { p: "892", op: { name: "Byru (Telkomsat)", brand: "Byru", jenis: "Maritim", warna: "biru" } },
  { p: "893", op: { name: "Byru (Telkomsat)", brand: "Byru", jenis: "Maritim", warna: "biru" } },
];

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();
  /* zuperupdt #5: rate limit (celah audit — sebelumnya tanpa batas) */
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`osint-phone:${ip}`, 30, 60 * 1000).ok) return tooManyResponse();

  const raw = (req.nextUrl.searchParams.get("number") || "").trim();
  let num = raw.replace(/[^\d+]/g, "");
  if (num.startsWith("+62")) num = "0" + num.slice(3);
  if (num.startsWith("62") && num.length >= 10) num = "0" + num.slice(2);
  num = num.replace(/\D/g, "");

  if (!/^(?:0|62)?8\d{7,13}$/.test(num)) {
    return Response.json(
      { ok: false, error: "Nomor HP Indonesia tidak valid (contoh: 08123456789)" },
      { status: 400 }
    );
  }

  // normalisasi ke 08xx
  if (num.startsWith("62")) num = "0" + num.slice(2);
  const prefix = num.slice(1, 4); // 8xx

  const hit = PREFIXES.find((x) => x.p === prefix);
  if (!hit) {
    return Response.json({
      ok: true,
      result: {
        nomor: num,
        operator: "Tidak dikenal",
        brand: "-",
        jenis: "-",
        catatan: "Prefix ini belum ada di database — bisa nomor baru atau tidak valid.",
      },
    });
  }

  return Response.json({
    ok: true,
    result: {
      nomor: num,
      prefix: `+62 ${prefix}`,
      operator: hit.op.name,
      brand: hit.op.brand,
      jenis: hit.op.jenis,
      warna: hit.op.warna,
      panjangNomor: num.length,
      catatan:
        num.length < 10
          ? "Panjang nomor kurang dari umumnya (10-14 digit) — cek lagi."
          : num.length > 14
            ? "Panjang nomor lebih dari umumnya (10-14 digit) — cek lagi."
            : "Format normal ✅",
    },
  });
}
