import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { decodeNik } from "@/lib/nik";

export const runtime = "nodejs";

/**
 * NIK Validasi Massal (V2.11 #16 — versi LEGAL yang dijanjikan):
 * tempel banyak NIK (satu per baris / dipisah koma) → dapat tabel valid/tidak,
 * wilayah + tanggal lahir hasil pembacaan struktur angka, plus penanda
 * anomali (tanggal tidak mungkin, kode wilayah tak dikenal, dsb.).
 *
 * Ini pembacaan struktur digit (baisa disebut parsing) — BUKAN lookup data
 * penduduk. Nama/alamat pemilik hanya bisa diverifikasi lewat Dukcapil.
 */

interface BarisMassal {
  input: string;
  nik: string;
  valid: boolean;
  anomali: string[];
  wilayah: { provinsi: string; kabupatenKota: string; kecamatan: string; kodePos?: string };
  pribadi: { jenisKelamin: string; tanggalLahir: string; umur: string };
}

export async function POST(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`nikmass:${ip}`, 10, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering — tunggu sebentar" }, { status: 429 });
  }

  let body: { daftar?: string } = {};
  try {
    body = (await req.json()) as { daftar?: string };
  } catch {
    return Response.json({ ok: false, error: "Body tidak valid" }, { status: 400 });
  }

  const mentah = String(body.daftar || "").slice(0, 8000);
  const kandidat = mentah
    .split(/[\n,;\s]+/)
    .map((s) => s.replace(/\D/g, ""))
    .filter((s) => s.length >= 10)
    .slice(0, 100);

  if (!kandidat.length) {
    return Response.json({ ok: false, error: "Tidak ada NIK yang terbaca — tempel minimal satu (angka saja atau 16 digit)." }, { status: 400 });
  }

  const baris: BarisMassal[] = kandidat.map((input) => {
    const r = decodeNik(input);
    const anomali: string[] = [...r.errors];
    if (input.length !== 16) anomali.push(`Panjang ${input.length} digit (harus 16)`);
    // anomali tambahan: nomor urut 0000
    if (/^0+$/.test(r.nomorUrut || "")) anomali.push("Nomor urut 0000 (jarang untuk NIK terbitan resmi)");
    return {
      input,
      nik: r.nik,
      valid: r.valid && input.length === 16,
      anomali,
      wilayah: r.wilayah,
      pribadi: { jenisKelamin: r.pribadi.jenisKelamin, tanggalLahir: r.pribadi.tanggalLahir, umur: r.pribadi.umur },
    };
  });

  const ringkas = {
    total: baris.length,
    valid: baris.filter((b) => b.valid).length,
    tidakValid: baris.filter((b) => !b.valid).length,
    anomali: baris.filter((b) => b.valid && b.anomali.length > 0).length,
  };

  return Response.json({ ok: true, baris, ringkas });
}
