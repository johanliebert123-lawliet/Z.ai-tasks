import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { decodeNik } from "@/lib/nik";

export const runtime = "nodejs";

/** Decode NIK 16 digit → data wilayah + tanggal lahir + gender (pembacaan struktur angka). */
export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`nik:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering, tunggu sebentar" }, { status: 429 });
  }

  const nik = (req.nextUrl.searchParams.get("nik") || "").trim();
  const result = decodeNik(nik);
  return Response.json({ ok: true, result });
}
