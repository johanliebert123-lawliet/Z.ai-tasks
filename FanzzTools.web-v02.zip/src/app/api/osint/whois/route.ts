import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/**
 * WHOIS klasik (port 43) — lookup raw domain + ikuti referral IANA.
 * Pelengkap RDAP di tab Cek Domain.
 */

import net from "node:net";

function whoisQuery(server: string, query: string, timeoutMs = 15000): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const sock = net.createConnection({ host: server, port: 43 }, () => {
      sock.write(query + "\r\n");
    });
    sock.setTimeout(timeoutMs);
    sock.on("data", (d) => chunks.push(d));
    sock.on("timeout", () => {
      sock.destroy();
      resolve(Buffer.concat(chunks).toString("utf-8"));
    });
    sock.on("error", (err) => reject(err));
    sock.on("close", () => resolve(Buffer.concat(chunks).toString("utf-8")));
  });
}

const DOMAIN_RE = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/i;

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`whois:${ip}`, 12, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Kebanyakan lookup — tunggu sebentar" }, { status: 429 });
  }

  const domain = (req.nextUrl.searchParams.get("d") || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");

  if (!DOMAIN_RE.test(domain)) {
    return Response.json({ ok: false, error: "Domain tidak valid (contoh: example.com)" }, { status: 400 });
  }
  // IP publik juga boleh
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(domain);

  try {
    // langkah 1: root server
    let raw = await whoisQuery(isIp ? "whois.arin.net" : "whois.iana.org", domain);

    // langkah 2: ikut referral whois server berikutnya (kalau ada)
    const referral = raw.match(/whois:\s*(\S+)/i)?.[1];
    if (referral && referral !== "whois.iana.org" && !/^\d+\./.test(referral)) {
      try {
        const raw2 = await whoisQuery(referral, domain);
        if (raw2 && raw2.length > 50) {
          raw = `# Referral: ${referral}\n${raw2}`;
        }
      } catch {
        /* pakai hasil root */
      }
    }

    if (!raw || raw.trim().length < 10) {
      return Response.json(
        { ok: false, error: "Data WHOIS kosong — domain mungkin belum terdaftar atau servernya lagi down" },
        { status: 404 }
      );
    }

    return Response.json({
      ok: true,
      domain,
      raw: raw.slice(0, 8000),
      referred: referral || null,
    });
  } catch (e) {
    const msg = e instanceof Error ? `Gagal query WHOIS: ${e.message}` : "Gagal query WHOIS";
    return Response.json({ ok: false, error: msg }, { status: 502 });
  }
}
