import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";
import { UA_DESKTOP } from "@/lib/constants";

export const runtime = "nodejs";

/**
 * Email Checker (V2.11 #25) — pemeriksa email yang JUJUR (tanpa pembodohan):
 *  1. Validasi format
 *  2. MX record domain (real — DNS langsung)
 *  3. Deteksi domain sekali-pakai (disposable)
 *  4. Profil Gravatar publik (indikasi akun lama/aktif)
 *  5. Reputasi via emailrep.io bila tersedia (kini sering butuh kunci — dilewati tenang)
 *
 *  Yang TIDAK bisa dicek siapa pun secara publik (dan kami tuliskan terus
 *  terang di hasil): daftar situs tempat email terdaftar, kebocoran kata sandi
 *  per-email (butuh kunci HIBP), tanggal pembuatan akun, dan nomor WA terkait.
 *  Untuk cek kebocoran, hasil menyertakan tautan resmi haveibeenpwned.com.
 */

const DISPOSABLE = new Set([
  "mailinator.com", "temp-mail.org", "tempmail.com", "10minutemail.com", "guerrillamail.com",
  "yopmail.com", "throwawaymail.com", "getnada.com", "dispostable.com", "sharklasers.com",
  "trashmail.com", "fakeinbox.com", "maildrop.cc", "mailnesia.com", "discard.email",
  "spam4.me", "tempr.email", "burnermail.io", "inboxkitten.com", "moakt.com",
  "emailondeck.com", "mohmal.com", "tempmailaddress.com", "mailtemp.net", "1secmail.com",
  "tmpmail.org", "internxt.com", "altmails.com", "cs.email", "emltmp.com",
]);

interface HasilCek {
  email: string;
  formatValid: boolean;
  domain: string;
  mx: { ada: boolean; catatan: string[] } | null;
  disposable: boolean;
  gravatar: boolean;
  reputasi: { reputasi: string; mencurigakan: boolean; bocor: boolean; malicious: boolean; firstSeen: string | null } | null;
  verdict: "baik" | "perhatian" | "buruk" | "tidak-valid";
  catatan: string[];
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`emailcheck:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu banyak permintaan — tunggu sebentar" }, { status: 429 });
  }

  const email = (req.nextUrl.searchParams.get("email") || "").trim().toLowerCase().slice(0, 160);
  if (!email) return Response.json({ ok: false, error: "Email kosong" }, { status: 400 });

  const formatValid = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(email);
  if (!formatValid) {
    const hasil: HasilCek = {
      email,
      formatValid: false,
      domain: "",
      mx: null,
      disposable: false,
      gravatar: false,
      reputasi: null,
      verdict: "tidak-valid",
      catatan: ["Format alamat email tidak valid."],
    };
    return Response.json({ ok: true, hasil });
  }

  const domain = email.split("@")[1];

  // 1) MX record — real via DNS
  let mx: HasilCek["mx"] = null;
  try {
    const dns = await import("node:dns").then((m) => m.promises);
    const catatan = await dns.resolveMx(domain);
    mx = {
      ada: catatan.length > 0,
      catatan: catatan.sort((a, b) => a.priority - b.priority).slice(0, 3).map((c) => c.exchange),
    };
  } catch {
    mx = { ada: false, catatan: [] };
  }

  const disposable = DISPOSABLE.has(domain);

  // 2) Gravatar — profil publik terkait email (indikasi, bukan kepastian)
  let gravatar = false;
  try {
    const crypto = await import("node:crypto");
    const hash = crypto.createHash("md5").update(email.trim().toLowerCase()).digest("hex");
    const res = await fetch(`https://gravatar.com/avatar/${hash}?d=404`, {
      method: "HEAD",
      headers: { "User-Agent": UA_DESKTOP },
      signal: AbortSignal.timeout(8000),
      redirect: "follow",
    });
    gravatar = res.ok;
  } catch {
    gravatar = false;
  }

  // 3) emailrep.io — reputasi (bila API terbuka tersedia; 429/401 dilewati)
  let reputasi: HasilCek["reputasi"] = null;
  try {
    const res = await fetch(`https://emailrep.io/${encodeURIComponent(email)}`, {
      headers: { Accept: "application/json", "User-Agent": UA_DESKTOP },
      signal: AbortSignal.timeout(8000),
    });
    if (res.ok) {
      const d = (await res.json()) as Record<string, unknown>;
      reputasi = {
        reputasi: String(d.reputation || "?"),
        mencurigakan: Boolean(d.suspicious),
        bocor: Boolean(d.data_breach || d.credentials_leaked),
        malicious: Boolean(d.malicious),
        firstSeen: d.first_seen ? String(d.first_seen) : null,
      };
    }
  } catch {
    /* tidak wajib */
  }

  // verdict
  const catatan: string[] = [];
  let verdict: HasilCek["verdict"] = "baik";
  if (!mx.ada) {
    verdict = "buruk";
    catatan.push("Domain tidak memiliki catatan MX — email ke alamat ini tidak akan pernah sampai (domain mati atau salah ketik).");
  } else if (disposable) {
    verdict = "perhatian";
    catatan.push("Domain ini adalah layanan email sekali pakai (disposable) — biasanya dipakai untuk registrasi sementara.");
  } else {
    catatan.push("Domain aktif dan dapat menerima email (MX terverifikasi).");
  }
  if (gravatar) catatan.push("Email memiliki profil Gravatar publik — biasanya akun lama/sering dipakai.");
  else catatan.push("Tidak ada profil Gravatar publik (wajar — mayoritas orang tidak memakainya).");
  if (reputasi) {
    if (reputasi.malicious || reputasi.mencurigakan || reputasi.reputasi === "low") {
      verdict = verdict === "baik" ? "perhatian" : verdict;
      catatan.push(`Reputasi emailrep.io: ${reputasi.reputasi}${reputasi.mencurigakan ? " (mencurigakan)" : ""}.`);
    }
    if (reputasi.bocor) {
      verdict = verdict === "baik" ? "perhatian" : verdict;
      catatan.push("Emailrep menandai email ini pernah muncul di kebocoran data.");
    }
  }

  const hasil: HasilCek = { email, formatValid: true, domain, mx, disposable, gravatar, reputasi, verdict, catatan };
  return Response.json({ ok: true, hasil });
}
