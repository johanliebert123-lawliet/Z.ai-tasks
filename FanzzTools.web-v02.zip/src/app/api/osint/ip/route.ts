import { NextRequest } from "next/server";
import { requireSession, unauthorizedResponse, rateLimit } from "@/lib/store";

export const runtime = "nodejs";

/** IP lookup via ipwho.is — IP sendiri atau IP tertentu. */
/** Apakah string ini IP publik yang layak dilacak? */
function looksPublicIp(s: string): boolean {
  if (!s) return false;
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(s)) {
    return !(
      s.startsWith("10.") ||
      s.startsWith("127.") ||
      s.startsWith("192.168.") ||
      s.startsWith("169.254.") ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(s) ||
      /^0\./.test(s)
    );
  }
  // IPv6 — tolak loopback / link-local / unique-local / IPv4-mapped
  return /^[0-9a-f:]+$/i.test(s) && s.includes(":") && !/^(::1|f[cd]|fe80|::ffff:)/i.test(s);
}

export async function GET(req: NextRequest) {
  const session = await requireSession();
  if (!session) return unauthorizedResponse();

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "anon";
  if (!rateLimit(`osintip:${ip}`, 20, 60 * 1000).ok) {
    return Response.json({ ok: false, error: "Terlalu sering" }, { status: 429 });
  }

  let target = (req.nextUrl.searchParams.get("ip") || "").trim();
  if (target === "me" || !target) {
    const fwd = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "";
    target = looksPublicIp(fwd) ? fwd : "";
    if (!target) {
      // kosong → ipwho.is bakal baca IP pengakses (di belakang proxy server)
      target = "";
    }
  }
  if (target && !/^(\d{1,3}\.){3}\d{1,3}$/.test(target) && !/^[0-9a-fA-F:]+$/.test(target)) {
    return Response.json({ ok: false, error: "Format IP tidak valid" }, { status: 400 });
  }

  try {
    const res = await fetch(`https://ipwho.is/${target}`, {
      headers: { Accept: "application/json", "User-Agent": "Mozilla/5.0" },
      signal: AbortSignal.timeout(12000),
    });
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    if (ct && !ct.includes("json")) throw new Error("respon bukan JSON");
    const d = await res.json();
    if (d?.success === false) {
      return Response.json({ ok: false, error: d?.message || "IP tidak ditemukan" }, { status: 404 });
    }
    return Response.json({
      ok: true,
      result: {
        ip: d.ip,
        tipe: d.type,
        negara: d.country,
        countryCode: d.country_code,
        ibukota: d.capital,
        provinsi: d.region,
        kota: d.city,
        kodepos: d.postal,
        koordinat: [d.latitude, d.longitude],
        bendera: d.flag?.emoji || "",
        telepon: d.calling_code,
        timezone: d.timezone?.id,
        utcOffset: d.timezone?.utc,
        asn: d.connection?.asn,
        org: d.connection?.org,
        isp: d.connection?.isp,
        domain: d.connection?.domain,
      },
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Gagal lookup IP" },
      { status: 502 }
    );
  }
}
