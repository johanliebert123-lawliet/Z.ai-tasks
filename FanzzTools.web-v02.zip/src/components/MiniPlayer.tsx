"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useApp } from "@/lib/app-store";
import { Play, Pause, X, Music4, Rewind, FastForward, Minimize2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function fmtTime(t: number): string {
  if (!Number.isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

/** Posisi default bubble: kanan bawah (di atas bottom nav). */
const BUBBLE_HOME = { x: 0, y: 0 };

export default function MiniPlayer() {
  const { currentSong, isPlaying, playSong, stopSong, setAudioEl, setPlaying } = useApp();
  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [seeking, setSeeking] = useState<number | null>(null);
  const seekingRef = useRef(false);

  /** V2-new (#18): mode tampilan — DEFAULT "full" (popup biasa). Tombol kotak
   *  di sisi KIRI-ATAS popup mengubahnya jadi "bubble" (bulat kecil, draggable). */
  const [mode, setMode] = useState<"bubble" | "full">("full");
  const [pos, setPos] = useState(BUBBLE_HOME);
  const dragRef = useRef<{ startX: number; startY: number; baseX: number; baseY: number; moved: boolean } | null>(null);

  useEffect(() => {
    if (audioRef.current) setAudioEl(audioRef.current);
  }, [setAudioEl]);

  // reset waktu kalau ganti lagu — lewat microtask biar gak cascading render
  useEffect(() => {
    queueMicrotask(() => {
      setTime(0);
      setDuration(0);
    });
  }, [currentSong?.videoId]);

  const onTimeUpdate = useCallback(() => {
    const a = audioRef.current;
    if (!a || seekingRef.current) return;
    setTime(a.currentTime);
    if (Number.isFinite(a.duration) && a.duration > 0) setDuration(a.duration);
  }, []);

  const onLoadedMeta = useCallback(() => {
    const a = audioRef.current;
    if (a && Number.isFinite(a.duration)) setDuration(a.duration);
  }, []);

  /** V2.11 (#33): audio gagal dimuat (URL kedaluwarsa/diblokir) → selesaikan
   *  ulang lewat server SEKALI per lagu dengan fresh=1, lalu putar lagi. */
  const retriedRef = useRef<Set<string>>(new Set());
  const onAudioError = useCallback(async () => {
    const song = useApp.getState().currentSong;
    if (!song?.videoId) return;
    if (retriedRef.current.has(song.videoId)) return; // sudah pernah dicoba
    retriedRef.current.add(song.videoId);
    try {
      const res = await fetch(`/api/music/ytmp3?url=https://www.youtube.com/watch?v=${song.videoId}&fresh=1`);
      const d = await res.json();
      if (d?.ok && d.result?.mp3 && d.result.mp3 !== song.mp3) {
        playSong({ ...song, mp3: d.result.mp3, title: d.result.title || song.title });
        return;
      }
    } catch {
      /* biarkan pesan di bawah */
    }
    useApp.getState().setPlaying(false);
    toast({
      title: "Lagu ini gagal dimuat",
      description: "Sumber audionya sedang bermasalah — coba lagu lain atau putar ulang sebentar lagi.",
      variant: "destructive",
    });
  }, [playSong, toast]);

  /** Lompat ±detik */
  const skip = (delta: number) => {
    const a = audioRef.current;
    if (!a) return;
    const max = Number.isFinite(a.duration) && a.duration > 0 ? a.duration : a.currentTime + delta;
    const t = Math.min(Math.max(a.currentTime + delta, 0), max);
    a.currentTime = t;
    setTime(t);
  };

  /** Drag seek bar */
  const onSeekInput = (v: number) => {
    setSeeking(v);
    if (duration) setTime(v);
  };
  const onSeekCommit = (v: number) => {
    const a = audioRef.current;
    if (a) a.currentTime = v;
    setSeeking(null);
    seekingRef.current = false;
    setTime(v);
  };

  // kalau user lagi drag, jangan override posisi bar
  const onPointerDown = () => {
    seekingRef.current = true;
  };

  const shownTime = seeking ?? time;

  /* ====== drag bubble (pointer events, jalan di mouse & sentuhan) ====== */
  const onBubblePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      baseX: pos.x,
      baseY: pos.y,
      moved: false,
    };
  };
  const onBubblePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    if (!d) return;
    const dx = e.clientX - d.startX;
    const dy = e.clientY - d.startY;
    if (Math.abs(dx) > 4 || Math.abs(dy) > 4) d.moved = true;
    // batas dalam viewport
    const maxX = window.innerWidth - 76;
    const maxY = window.innerHeight - 150;
    setPos({
      x: Math.min(0, Math.max(-maxX, d.baseX + dx)),
      y: Math.min(0, Math.max(-maxY, d.baseY + dy)),
    });
  };
  const onBubblePointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    dragRef.current = null;
    (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
    // tap (bukan drag) → kembalikan ke popup penuh, musik tetap jalan
    if (d && !d.moved) {
      setMode("full");
    }
  };

  return (
    <>
      <audio
        ref={audioRef}
        onEnded={() => setPlaying(false)}
        onPause={() => setPlaying(false)}
        onPlay={() => setPlaying(true)}
        onTimeUpdate={onTimeUpdate}
        onLoadedMetadata={onLoadedMeta}
        onError={onAudioError}
        preload="auto"
      />
      <AnimatePresence>
        {currentSong && mode === "bubble" && (
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 320, damping: 24 }}
            className="fanzz-bubble-drag fixed right-4 bottom-24 z-40 md:bottom-6"
            style={{ transform: `translate(${pos.x}px, ${pos.y}px)` }}
          >
            <div
              onPointerDown={onBubblePointerDown}
              onPointerMove={onBubblePointerMove}
              onPointerUp={onBubblePointerUp}
              onPointerCancel={onBubblePointerUp}
              title="Geser untuk memindahkan — ketuk untuk memperbesar"
              className="relative h-14 w-14 cursor-grab select-none overflow-hidden rounded-full glass-strong shadow-2xl ring-1 ring-cyan-400/25 active:cursor-grabbing"
            >
              {currentSong.thumbnail ? (
                <img src={currentSong.thumbnail} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-cyan-500 to-teal-600 text-white">
                  <Music4 className="h-5 w-5" />
                </div>
              )}
              {/* indikator play/pause tipis di atas thumbnail */}
              <div className="absolute inset-0 flex items-center justify-center bg-black/35 backdrop-blur-[1px]">
                {isPlaying ? (
                  <span className="flex items-end gap-0.5">
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        animate={{ height: [4, 12, 6, 14, 4] }}
                        transition={{ repeat: Infinity, duration: 0.8, delay: d * 0.12 }}
                        className="w-1 rounded-full bg-cyan-300"
                      />
                    ))}
                  </span>
                ) : (
                  <Play className="h-5 w-5 text-white/90" />
                )}
              </div>
              {/* tombol X kecil di kanan atas bubble — menutup + membatalkan musik */}
              <button
                onPointerDown={(e) => e.stopPropagation()}
                onClick={(e) => {
                  e.stopPropagation();
                  stopSong();
                }}
                aria-label="Tutup dan hentikan musik"
                className="absolute -right-1 -top-1 z-10 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-white shadow-md ring-2 ring-black/40 active:scale-90"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          </motion.div>
        )}

        {currentSong && mode === "full" && (
          <motion.div
            initial={{ y: 90, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 90, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed inset-x-0 bottom-[68px] z-40 px-3 md:bottom-4 md:left-auto md:right-4 md:w-96 md:px-0"
          >
            <div className="glass-strong rounded-2xl p-2.5 shadow-2xl ring-1 ring-cyan-400/20">
              {/* baris info + kontrol */}
              <div className="flex items-center gap-3">
                {/* V2-new (#18): tombol KOTAK di sisi KIRI ATAS — kecilkan jadi bubble bulat */}
                <button
                  onClick={() => setMode("bubble")}
                  aria-label="Kecilkan jadi lingkaran kecil (musik tetap berjalan)"
                  title="Jadikan pop-up bulat — musik tetap berjalan"
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-300 ring-1 ring-cyan-400/30 transition-all hover:bg-cyan-500/25 active:scale-90"
                >
                  <Minimize2 className="h-4 w-4" />
                </button>
                <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-xl">
                  {currentSong.thumbnail ? (
                    <img src={currentSong.thumbnail} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-cyan-500 to-teal-600 text-white">
                      <Music4 className="h-5 w-5" />
                    </div>
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold">{currentSong.title}</p>
                  <p className="truncate text-[10px] text-muted-foreground">{currentSong.artist}</p>
                  {/* equalizer animasi */}
                  <div className="mt-0.5 flex h-2 items-end gap-0.5">
                    {[0, 1, 2, 3, 4].map((d) => (
                      <motion.span
                        key={d}
                        animate={isPlaying ? { height: [2, 7, 3, 8, 2] } : { height: 2 }}
                        transition={{ repeat: isPlaying ? Infinity : 0, duration: 0.8, delay: d * 0.1 }}
                        className="w-1 rounded-full bg-cyan-400"
                      />
                    ))}
                  </div>
                </div>

                {/* skip mundur 10s */}
                <button
                  onClick={() => skip(-10)}
                  aria-label="Mundur 10 detik"
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-cyan-300"
                >
                  <Rewind className="h-4 w-4" />
                  <span className="sr-only">10 detik</span>
                </button>
                <button
                  onClick={() => playSong(currentSong)}
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/25 transition-transform hover:scale-105 active:scale-95"
                >
                  {isPlaying ? <Pause className="h-4.5 w-4.5" /> : <Play className="h-4.5 w-4.5" />}
                </button>
                {/* skip maju 10s */}
                <button
                  onClick={() => skip(10)}
                  aria-label="Maju 10 detik"
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-cyan-300"
                >
                  <FastForward className="h-4 w-4" />
                </button>
                {/* V0.01 (#13b): X = tutup popup + batalkan musik */}
                <button
                  onClick={stopSong}
                  aria-label="Tutup dan hentikan musik"
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-red-500/15 hover:text-red-400"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* seek bar — bisa digeser/diskip (V2-new: dijaga agar tetap responsif) */}
              <div className="mt-2 flex items-center gap-2.5">
                <span className="w-8 shrink-0 text-right text-[9.5px] font-bold tabular-nums text-muted-foreground">
                  {fmtTime(shownTime)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration || 100}
                  step={0.5}
                  value={Math.min(shownTime, duration || shownTime)}
                  onPointerDown={onPointerDown}
                  onChange={(e) => onSeekInput(Number(e.target.value))}
                  onPointerUp={(e) => onSeekCommit(Number((e.target as HTMLInputElement).value))}
                  onTouchEnd={(e) => {
                    const v = Number((e.target as HTMLInputElement).value);
                    onSeekCommit(v);
                  }}
                  onKeyUp={(e) => onSeekCommit(Number((e.target as HTMLInputElement).value))}
                  aria-label="Geser posisi lagu"
                  className="fanzz-range h-1.5 w-full cursor-pointer appearance-none rounded-full"
                  style={{
                    background: `linear-gradient(to right, rgb(34 211 238) 0%, rgb(13 148 136) ${
                      duration ? (shownTime / duration) * 100 : 0
                    }%, rgba(148, 163, 184, 0.28) ${
                      duration ? (shownTime / duration) * 100 : 0
                    }%)`,
                  }}
                />
                <span className="w-8 shrink-0 text-[9.5px] font-bold tabular-nums text-muted-foreground">
                  {duration ? fmtTime(duration) : "0:00"}
                </span>
              </div>

              {/* V2-new (#18): petunjuk mode bubble dipindah ke tombol kotak kiri atas */}
              <p className="mt-1 px-1 text-center text-[9.5px] text-muted-foreground">
                Tekan tombol kotak (kiri atas) untuk jadikan pop-up bulat — musik tetap berjalan
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
