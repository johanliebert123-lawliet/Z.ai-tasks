"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { useApp } from "@/lib/app-store";
import {
  ArrowLeft, Send, Loader2, Mic, Square, ImagePlus, Check, CheckCheck, X,
} from "lucide-react";

export interface ChatPeer {
  uid: string;
  name: string;
}

interface Msg {
  id: number;
  from: string;
  to: string;
  type: "text" | "image" | "vn";
  text?: string;
  data?: string;
  dur?: number;
  ts: number;
  seen: boolean;
  fromName?: string;
}

function fmtClock(ts: number): string {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

/** Kompres gambar jadi JPEG kecil (maks 1280px, ±300KB). */
async function compressImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file).catch(() => null);
  if (!bitmap) throw new Error("Gambar gak kebaca");
  const max = 1280;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const w = Math.round(bitmap.width * scale);
  const h = Math.round(bitmap.height * scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, w, h);
  bitmap.close?.();
  let q = 0.85;
  let dataUrl = canvas.toDataURL("image/jpeg", q);
  while (dataUrl.length > 1.9 * 1024 * 1024 && q > 0.3) {
    q -= 0.15;
    dataUrl = canvas.toDataURL("image/jpeg", q);
  }
  return dataUrl;
}

/** Pilih mimeType yang didukung browser buat rekam VN. */
function pickRecorderMime(): string {
  const cands = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4", "audio/ogg;codecs=opus"];
  for (const m of cands) {
    if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m)) return m;
  }
  return "";
}

/** Thread chat realtime — dipakai di ChatView & overlay nonton film. */
export default function ChatThread({
  peer,
  onBack,
  compact = false,
  group,
}: {
  peer: ChatPeer;
  onBack?: () => void;
  compact?: boolean;
  /** Mode grup: peer.uid = gid, peer.name = nama grup */
  group?: boolean;
}) {
  const { user } = useApp();
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const [err, setErr] = useState("");
  const [imgBusy, setImgBusy] = useState(false);
  /** V2 UpdSec: foto profil lawan bicara — tampil di header thread */
  const [peerAvatar, setPeerAvatar] = useState<string | null>(null);
  const lastIdRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recSecsRef = useRef(0);

  const scrollDown = useCallback(() => {
    queueMicrotask(() => {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    });
  }, []);

  // V2 UpdSec: ambil foto profil lawan bicara (1:1) sekali saat thread dibuka
  useEffect(() => {
    if (group) return;
    fetch(`/api/social/users?uid=${encodeURIComponent(peer.uid)}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.user?.avatar) setPeerAvatar(d.user.avatar);
      })
      .catch(() => {});
  }, [peer.uid, group]);

  const poll = useCallback(
    async (silent = false) => {
      try {
        const r = await fetch(
          group
            ? `/api/social/group?gid=${encodeURIComponent(peer.uid)}&after=${lastIdRef.current}`
            : `/api/social/messages?peer=${encodeURIComponent(peer.uid)}&after=${lastIdRef.current}`
        );
        const d = await r.json();
        if (d?.ok && d.messages?.length) {
          for (const m of d.messages as Msg[]) {
            if (m.id > lastIdRef.current) lastIdRef.current = m.id;
          }
          setMessages((prev) => {
            const seen = new Set(prev.map((m) => m.id));
            return [...prev, ...(d.messages as Msg[]).filter((m) => !seen.has(m.id))];
          });
          scrollDown();
        } else if (!silent && d?.error) {
          setErr(String(d.error));
        }
      } catch {
        /* polling optional */
      }
    },
    [peer.uid, scrollDown, group]
  );

  // muat awal + polling
  useEffect(() => {
    lastIdRef.current = 0;
    setMessages([]);
    poll(true);
    pollRef.current = setInterval(() => poll(true), group ? 2500 : 2000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [peer.uid, poll, group]);

  useEffect(() => {
    scrollDown();
  }, [messages, scrollDown]);

  const send = async (payload: { type: "text" | "image" | "vn"; text?: string; data?: string; dur?: number }) => {
    if (sending) return;
    setSending(true);
    setErr("");
    try {
      const r = await fetch(group ? "/api/social/group" : "/api/social/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(group ? { action: "send", gid: peer.uid, ...payload } : { peer: peer.uid, ...payload }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal kirim");
      await poll(true);
      setInput("");
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Gagal kirim pesan");
    } finally {
      setSending(false);
    }
  };

  const sendText = () => {
    const t = input.trim();
    if (!t || sending) return;
    setInput("");
    send({ type: "text", text: t });
  };

  const pickImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.type.startsWith("image/")) return;
    if (f.size > 15 * 1024 * 1024) {
      setErr("Gambar kegedean (maks 15MB, otomatis dikompres)");
      return;
    }
    setImgBusy(true);
    try {
      const data = await compressImage(f);
      await send({ type: "image", data });
    } catch {
      setErr("Gambar gagal diproses");
    } finally {
      setImgBusy(false);
    }
  };

  /** Rekam VN — klik mulai, klik lagi stop & kirim */
  const toggleRecord = async () => {
    if (recording) {
      recorderRef.current?.stop();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mime = pickRecorderMime();
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      chunksRef.current = [];
      rec.ondataavailable = (ev) => {
        if (ev.data.size) chunksRef.current.push(ev.data);
      };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (recTimerRef.current) clearInterval(recTimerRef.current);
        setRecording(false);
        const dur = recSecsRef.current;
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        if (blob.size > 1024) {
          const reader = new FileReader();
          reader.onloadend = async () => {
            const dataUrl = String(reader.result || "");
            if (dataUrl.length <= 2.4 * 1024 * 1024) {
              await send({ type: "vn", data: dataUrl, dur });
            } else {
              setErr("VN kepanjangan (maks ±2 menit)");
            }
          };
          reader.readAsDataURL(blob);
        }
        recSecsRef.current = 0;
        setRecSecs(0);
      };
      recorderRef.current = rec;
      rec.start(250);
      setRecording(true);
      recSecsRef.current = 0;
      setRecSecs(0);
      recTimerRef.current = setInterval(() => {
        if (recSecsRef.current >= 119) {
          recorderRef.current?.stop();
          return;
        }
        recSecsRef.current += 1;
        setRecSecs(recSecsRef.current);
      }, 1000);
    } catch {
      setErr("Gak bisa akses mikrofon — cek izin browser");
    }
  };

  // bersihin recorder kalau unmount
  useEffect(() => {
    return () => {
      if (recTimerRef.current) clearInterval(recTimerRef.current);
      try {
        recorderRef.current?.stop();
      } catch {
        /* ignore */
      }
    };
  }, []);

  return (
    <div className="flex h-full flex-col">
      {/* header thread */}
      <div className="flex items-center gap-2.5 border-b border-[var(--surface-line)] pb-2.5">
        {onBack && (
          <button onClick={onBack} className="rounded-xl p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground">
            <ArrowLeft className="h-4 w-4" />
          </button>
        )}
        {peerAvatar ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={peerAvatar} alt={peer.name} className="h-9 w-9 rounded-xl object-cover" />
        ) : (
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-sm font-extrabold text-white">
            {peer.name.charAt(0).toUpperCase()}
          </div>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold">{peer.name}</p>
          <p className="text-[10px] text-emerald-400">{group ? "grup • realtime" : "online • realtime"}</p>
        </div>
      </div>

      {/* daftar pesan */}
      <div
        ref={scrollRef}
        className="min-h-0 flex-1 space-y-2 overflow-y-auto py-3 pr-1"
        style={{ maxHeight: compact ? "42vh" : "calc(100dvh - 330px)" }}
      >
        {messages.length === 0 && (
          <p className="py-8 text-center text-xs text-muted-foreground">
            Belum ada pesan — mulai ngobrol sama {peer.name} 👋
          </p>
        )}
        {messages.map((m) => {
          const mine = m.from === user?.uid;
          return (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 8, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className={`flex ${mine ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`chat-bubble-${mine ? "out" : "in"} max-w-[78%] rounded-2xl px-3 py-2 text-sm ${
                  mine
                    ? "bg-gradient-to-br from-red-500 to-red-700 text-white"
                    : "glass text-foreground"
                }`}
              >
                {group && !mine && m.fromName && (
                  <p className="mb-0.5 text-[10px] font-extrabold text-red-300">{m.fromName}</p>
                )}
                {m.type === "text" && <p className="whitespace-pre-wrap break-words">{m.text}</p>}
                {m.type === "image" && m.data && (
                  <a href={m.data} target="_blank" rel="noreferrer" download="foto-chat.jpg">
                    <img src={m.data} alt="foto" className="max-h-60 w-full rounded-xl object-cover" />
                  </a>
                )}
                {m.type === "vn" && m.data && <VnBubble data={m.data} dur={m.dur} mine={mine} />}
                <p className={`mt-1 flex items-center justify-end gap-1 text-[9px] ${mine ? "text-white/70" : "text-muted-foreground"}`}>
                  {fmtClock(m.ts)}
                  {mine && !group && (m.seen ? <CheckCheck className="h-3 w-3" /> : <Check className="h-3 w-3" />)}
                </p>
              </div>
            </motion.div>
          );
        })}
      </div>

      {err && (
        <p className="mb-1.5 rounded-lg bg-red-500/10 px-2.5 py-1.5 text-[10.5px] text-red-300">
          {err}
          <button onClick={() => setErr("")} className="float-right"><X className="h-3 w-3" /></button>
        </p>
      )}

      {/* bar input */}
      <div className="glass-strong flex items-end gap-1.5 rounded-2xl p-1.5">
        <input ref={imgInputRef} type="file" accept="image/*" className="hidden" onChange={pickImage} />
        {!recording ? (
          <>
            <button
              onClick={() => imgInputRef.current?.click()}
              disabled={imgBusy || sending}
              className="rounded-xl p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-red-400 disabled:opacity-40"
              title="Kirim gambar"
            >
              {imgBusy ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <ImagePlus className="h-4.5 w-4.5" />}
            </button>
            <button
              onClick={toggleRecord}
              disabled={sending || imgBusy}
              className="rounded-xl p-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-red-400 disabled:opacity-40"
              title="Rekam pesan suara (VN)"
            >
              <Mic className="h-4.5 w-4.5" />
            </button>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendText();
                }
              }}
              rows={1}
              placeholder="Ketik pesan..."
              className="max-h-24 min-h-[38px] flex-1 resize-none bg-transparent px-1 text-sm outline-none placeholder:text-muted-foreground"
            />
            <button
              onClick={sendText}
              disabled={sending || !input.trim()}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg shadow-red-500/25 transition-transform active:scale-90 disabled:opacity-40"
            >
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </button>
          </>
        ) : (
          <div className="flex w-full items-center gap-2.5 px-1.5 py-1">
            <span className="flex h-2 w-2 shrink-0 animate-pulse rounded-full bg-red-500" />
            <span className="flex-1 text-xs font-bold text-red-300">
              Merekam VN… {Math.floor(recSecs / 60)}:{String(recSecs % 60).padStart(2, "0")}
              <span className="ml-2 inline-flex items-end gap-0.5">
                {[0, 1, 2, 3, 4].map((d) => (
                  <span key={d} className="vn-bar w-0.5 rounded-full bg-red-400" style={{ animationDelay: `${d * 0.12}s` }} />
                ))}
              </span>
            </span>
            <button
              onClick={toggleRecord}
              className="flex items-center gap-1.5 rounded-xl bg-red-500 px-3 py-1.5 text-xs font-bold text-white transition-transform active:scale-90"
            >
              <Square className="h-3 w-3 fill-white" /> Stop & Kirim
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

/** Bubble VN — play custom + durasi. */
export function VnBubble({ data, dur, mine }: { data: string; dur?: number; mine: boolean }) {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggle = () => {
    const a = audioRef.current;
    if (!a) return;
    if (playing) {
      a.pause();
    } else {
      a.play().catch(() => {});
    }
  };

  return (
    <div className="flex items-center gap-2.5 py-0.5">
      <audio ref={audioRef} src={data} onPlay={() => setPlaying(true)} onPause={() => setPlaying(false)} onEnded={() => setPlaying(false)} preload="metadata" />
      <button
        onClick={toggle}
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
          mine ? "bg-white/25" : "bg-gradient-to-br from-red-500 to-red-700"
        } text-white transition-transform active:scale-90`}
        aria-label={playing ? "Jeda VN" : "Putar VN"}
      >
        <svg viewBox="0 0 24 24" className="h-4 w-4 fill-white">
          {playing ? (
            <>
              <rect x="6" y="5" width="4" height="14" rx="1.5" />
              <rect x="14" y="5" width="4" height="14" rx="1.5" />
            </>
          ) : (
            <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.88l11-6.86a1.04 1.04 0 0 0 0-1.76l-11-6.86A1.04 1.04 0 0 0 8 5.14z" />
          )}
        </svg>
      </button>
      <div className="flex h-8 items-end gap-0.5">
        {[3, 9, 5, 12, 6, 10, 4, 8].map((h, i) => (
          <span
            key={i}
            className={`w-0.5 rounded-full ${mine ? "bg-white/80" : "bg-red-400"}`}
            style={{
              height: playing ? undefined : h,
              animation: playing ? `vnWave 0.9s ${i * 0.09}s ease-in-out infinite alternate` : undefined,
            }}
          />
        ))}
      </div>
      <span className={`text-[10px] font-bold ${mine ? "text-white/80" : "text-muted-foreground"}`}>
        VN {dur ? `${dur}s` : ""}
      </span>
    </div>
  );
}
