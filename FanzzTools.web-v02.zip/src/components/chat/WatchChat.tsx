"use client";

import { useEffect, useState } from "react";
import { Loader2, MessageCircle, Search as SearchIcon2 } from "lucide-react";
import ChatThread, { type ChatPeer } from "@/components/chat/ChatThread";

interface MiniConv {
  peer: { uid: string; username: string; avatarColor: string; online: boolean };
  last: { text: string; ts: number };
  unread: number;
}

/** Panel chat sambil nonton — dipakai FilmView & AnimeView. */
export default function WatchChat() {
  const [peer, setPeer] = useState<ChatPeer | null>(null);
  const [convs, setConvs] = useState<MiniConv[] | null>(null);
  const [query, setQuery] = useState("");
  const [searchUsers, setSearchUsers] = useState<Array<{ uid: string; username: string }>>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    fetch("/api/social/conversations")
      .then((r) => r.json())
      .then((d) => d?.ok && setConvs(d.conversations))
      .catch(() => setConvs([]));
  }, []);

  const doSearch = (q: string) => {
    setQuery(q);
    if (q.trim().length < 1) {
      setSearchUsers([]);
      return;
    }
    setSearching(true);
    fetch(`/api/social/users?q=${encodeURIComponent(q.trim())}`)
      .then((r) => r.json())
      .then((d) => setSearchUsers(d?.users || []))
      .catch(() => setSearchUsers([]))
      .finally(() => setSearching(false));
  };

  if (peer) {
    return (
      <div className="h-[46vh]">
        <ChatThread peer={peer} onBack={() => setPeer(null)} compact />
      </div>
    );
  }

  return (
    <div>
      <p className="mb-2 flex items-center gap-1.5 text-xs font-bold">
        <MessageCircle className="h-3.5 w-3.5 text-red-400" /> Ngobrol sambil nonton
      </p>
      <div className="relative mb-2.5">
        <SearchIcon2 className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => doSearch(e.target.value)}
          placeholder="Cari username buat diajak nonton bareng..."
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-2.5 pl-9 pr-3 text-xs outline-none focus:border-red-400/50"
        />
        {searching && <Loader2 className="absolute right-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 animate-spin text-red-400" />}
      </div>

      {/* hasil cari */}
      {searchUsers.length > 0 && (
        <div className="mb-2.5 max-h-32 space-y-1.5 overflow-y-auto">
          {searchUsers.slice(0, 6).map((u) => (
            <button
              key={u.uid}
              onClick={() => {
                setPeer({ uid: u.uid, name: u.username });
                setSearchUsers([]);
                setQuery("");
              }}
              className="flex w-full items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2 text-left transition-colors hover:bg-secondary"
            >
              <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-br from-red-500 to-red-700 text-[10px] font-extrabold text-white">
                {u.username.charAt(0).toUpperCase()}
              </span>
              <span className="truncate text-xs font-bold">{u.username}</span>
            </button>
          ))}
        </div>
      )}

      {/* percakapan terakhir */}
      {convs === null ? (
        <div className="space-y-1.5">
          {[0, 1].map((i) => <div key={i} className="h-11 rounded-xl shimmer" />)}
        </div>
      ) : convs.length === 0 ? (
        <p className="py-4 text-center text-[11px] text-muted-foreground">
          Belum ada obrolan — cari username di atas buat mulai chat 👆
        </p>
      ) : (
        <div className="max-h-40 space-y-1.5 overflow-y-auto">
          {convs.slice(0, 5).map((c) => (
            <button
              key={c.peer.uid}
              onClick={() => setPeer({ uid: c.peer.uid, name: c.peer.username })}
              className="flex w-full items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2 text-left transition-colors hover:bg-secondary"
            >
              <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${c.peer.avatarColor} text-[10px] font-extrabold text-white`}>
                {c.peer.username.charAt(0).toUpperCase()}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-xs font-bold">{c.peer.username}</span>
                <span className="block truncate text-[10px] text-muted-foreground">{c.last.text}</span>
              </span>
              {c.unread > 0 && (
                <span className="flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[9px] font-extrabold text-white">
                  {c.unread}
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
