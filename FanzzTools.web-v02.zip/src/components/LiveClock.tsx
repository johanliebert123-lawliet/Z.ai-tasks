"use client";

import { useEffect, useState } from "react";
import { Clock3 } from "lucide-react";

/**
 * Jam real-time pengguna (V2 Modern-UpdSec) — detik berjalan,
 * mengikuti zona waktu perangkat + tanggal Indonesia.
 */
export default function LiveClock({ compact = false }: { compact?: boolean }) {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // hindari perbedaan tampilan server/client (SSR-safe)
  if (!now) {
    return <span className="tabular-nums opacity-0">00:00:00</span>;
  }

  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"][now.getDay()];
  const tgl = now.toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });

  if (compact) {
    return (
      <span className="flex items-center gap-1.5 text-[10px] font-extrabold tabular-nums text-muted-foreground" title={`${hari}, ${tgl}`}>
        <Clock3 className="h-3.5 w-3.5 text-red-400" />
        {hh}:{mm}:{ss}
      </span>
    );
  }

  return (
    <div className="flex items-center gap-2.5 rounded-xl bg-secondary/50 px-3 py-2">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-red-500 to-red-700 text-white">
        <Clock3 className="h-4 w-4" />
      </span>
      <div>
        <p className="text-[13px] font-black leading-none tabular-nums">{hh}:{mm}:{ss}</p>
        <p className="mt-0.5 text-[9px] font-bold text-muted-foreground">{hari}, {tgl}</p>
      </div>
    </div>
  );
}
