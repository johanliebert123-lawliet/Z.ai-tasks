"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useApp } from "@/lib/app-store";
import { watchBattery, getDeviceInfo, getLocationGps, getLocationByIp } from "@/lib/device-info";
import {
  Smartphone, BatteryCharging, BatteryFull, BatteryLow, BatteryMedium, BatteryWarning,
  MapPin, Navigation, RefreshCw, Loader2, Cpu, Globe2, Wifi,
} from "lucide-react";

/** Card status perangkat: HP, baterai real-time, dan lokasi. */
export default function DeviceStatusCard() {
  const { battery, device, geo, setBattery, setDevice, setGeo } = useApp();
  const [locLoading, setLocLoading] = useState(false);

  // init sekali: baterai + perangkat
  useEffect(() => {
    let unwatch = () => {};
    let alive = true;
    (async () => {
      const u = await watchBattery((b) => {
        if (alive) setBattery(b);
      });
      unwatch = u;
    })();
    (async () => {
      try {
        const d = await getDeviceInfo();
        if (alive && !useApp.getState().device) setDevice(d);
      } catch {
        /* ignore */
      }
    })();
    return () => {
      alive = false;
      unwatch();
    };
  }, [setBattery, setDevice]);

  const refreshLocation = async (forceGps = false) => {
    if (locLoading) return;
    setLocLoading(true);
    try {
      let g: Awaited<ReturnType<typeof getLocationGps>> = null;
      if (forceGps || !useApp.getState().geo) {
        g = await getLocationGps();
      }
      if (!g) g = await getLocationByIp();
      if (g) setGeo(g);
    } finally {
      setLocLoading(false);
    }
  };

  // auto-init lokasi sekali (kalau belum ada dan belum diminta)
  useEffect(() => {
    if (!geo && !locLoading) {
      const t = setTimeout(() => refreshLocation(false), 600);
      return () => clearTimeout(t);
    }
  }, []);

  const pct = battery && battery.supported ? Math.round(battery.level * 100) : null;

  const BatteryIcon =
    battery?.charging
      ? BatteryCharging
      : pct != null && pct <= 15
        ? BatteryWarning
        : pct != null && pct <= 30
          ? BatteryLow
          : pct != null && pct <= 60
            ? BatteryMedium
            : BatteryFull;

  const batteryColor = battery?.charging
    ? "text-emerald-400"
    : pct != null && pct <= 20
      ? "text-red-400"
      : pct != null && pct <= 40
        ? "text-amber-400"
        : "text-emerald-400";

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass overflow-hidden rounded-3xl"
    >
      <div className="flex items-center justify-between px-4 pt-4">
        <p className="flex items-center gap-1.5 text-xs font-extrabold">
          <Smartphone className="h-3.5 w-3.5 text-cyan-400" /> HP &amp; Lokasi Kamu
        </p>
        <span className="rounded-full bg-cyan-500/10 px-2 py-0.5 text-[9px] font-extrabold text-cyan-300">REAL-TIME</span>
      </div>

      <div className="grid grid-cols-1 gap-2 p-3">
        {/* perangkat */}
        <div className="flex items-center gap-3 rounded-2xl bg-secondary/50 px-3.5 py-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-slate-500 to-slate-700 text-white">
            <Smartphone className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-extrabold">{device?.modelName || "Mendeteksi…"}</p>
            <p className="truncate text-[10.5px] text-muted-foreground">
              {device ? `${device.os} • ${device.browser} • ${device.screen}` : "OS, browser & layar…"}
            </p>
          </div>
        </div>

        {/* baterai */}
        <div className="flex items-center gap-3 rounded-2xl bg-secondary/50 px-3.5 py-3">
          <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-colors ${
            battery?.charging ? "bg-gradient-to-br from-emerald-500 to-teal-600" : "bg-gradient-to-br from-lime-500 to-green-600"
          } text-white`}>
            <BatteryIcon className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className={`text-[13px] font-extrabold ${batteryColor}`}>
              {pct != null ? `${pct}%` : "Tidak tersedia"}
              {battery?.charging ? " — sedang dicas ⚡" : ""}
            </p>
            <p className="text-[10.5px] text-muted-foreground">
              {pct != null
                ? battery?.charging
                  ? "Pengisian daya aktif, update real-time"
                  : "Level baterai real-time"
                : "Browser tidak mendukung Battery API"}
            </p>
            {/* bar level */}
            {pct != null && (
              <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-black/25">
                <motion.div
                  animate={{ width: `${pct}%` }}
                  transition={{ type: "spring", stiffness: 120, damping: 20 }}
                  className={`h-full rounded-full ${
                    battery?.charging
                      ? "bg-gradient-to-r from-emerald-400 to-teal-400"
                      : pct <= 20
                        ? "bg-gradient-to-r from-red-500 to-orange-500"
                        : "bg-gradient-to-r from-lime-400 to-emerald-500"
                  }`}
                />
              </div>
            )}
          </div>
        </div>

        {/* lokasi */}
        <div className="flex items-center gap-3 rounded-2xl bg-secondary/50 px-3.5 py-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white">
            <MapPin className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            {geo ? (
              <>
                <p className="truncate text-[13px] font-extrabold">
                  {[geo.kecamatan || geo.kelurahan, geo.kota || geo.kabupaten, geo.provinsi]
                    .filter(Boolean)
                    .join(", ") || "Lokasi terdeteksi"}
                </p>
                <p className="truncate text-[10.5px] text-muted-foreground">
                  {geo.negara} • {geo.lat.toFixed(5)}, {geo.lon.toFixed(5)}
                  {geo.postcode ? ` • ${geo.postcode}` : ""}
                </p>
                <p className="mt-0.5 text-[9.5px] font-bold text-red-400">
                  {geo.mode === "gps" ? "🛰️ Presisi GPS" : "📡 Estimasi dari IP"}
                </p>
              </>
            ) : locLoading ? (
              <>
                <p className="text-[13px] font-extrabold">Mendeteksi lokasi…</p>
                <p className="text-[10.5px] text-muted-foreground">Minta izin lokasi di browser</p>
              </>
            ) : (
              <>
                <p className="text-[13px] font-extrabold">Lokasi belum aktif</p>
                <p className="text-[10.5px] text-muted-foreground">Tekan tombol refresh untuk deteksi</p>
              </>
            )}
          </div>
          <button
            onClick={() => refreshLocation(true)}
            disabled={locLoading}
            className="shrink-0 rounded-xl bg-secondary p-2 text-muted-foreground transition-colors hover:text-red-400 disabled:opacity-50"
            title="Deteksi ulang lokasi (GPS)"
          >
            {locLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </button>
        </div>

        {/* info tambahan */}
        {device && (
          <div className="flex flex-wrap gap-1.5 px-0.5">
            {device.network && (
              <span className="flex items-center gap-1 rounded-full bg-secondary/60 px-2 py-1 text-[9.5px] font-bold text-muted-foreground">
                <Wifi className="h-3 w-3" /> {device.network}
              </span>
            )}
            {device.cores && (
              <span className="flex items-center gap-1 rounded-full bg-secondary/60 px-2 py-1 text-[9.5px] font-bold text-muted-foreground">
                <Cpu className="h-3 w-3" /> {device.cores} core{device.cores > 1 ? "s" : ""}
              </span>
            )}
            {device.memory && (
              <span className="flex items-center gap-1 rounded-full bg-secondary/60 px-2 py-1 text-[9.5px] font-bold text-muted-foreground">
                <Cpu className="h-3 w-3" /> RAM ~{device.memory} GB
              </span>
            )}
            {device.timezone && (
              <span className="flex items-center gap-1 rounded-full bg-secondary/60 px-2 py-1 text-[9.5px] font-bold text-muted-foreground">
                <Globe2 className="h-3 w-3" /> {device.timezone}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
