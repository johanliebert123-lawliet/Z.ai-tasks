"use client";

import { useEffect, useMemo, useState } from "react";

/**
 * Animasi gagak — tema Dark Charcoal-Blood (permintaan #8).
 * Banyak gagak abu-hitam bermata merah menyala (gaya Sharingan Itachi)
 * terbang bersamaan tapi bertahap (staggered), dari tiga arah:
 *   1) kiri → kanan (sedikit turun-naik, sayap mengepak)
 *   2) kanan → kiri-bawah (menyilang turun)
 *   3) bawah → kiri (naik diagonal)
 * Mata merah punya efek "lensing" — glow yang berdenyut + lingkaran
 * pupil kecil (mengesankan mata dōjutsu yang hidup).
 */

interface CrowSpec {
  id: number;
  /** arah terbang */
  dir: "ltr" | "rtl-down" | "b2l";
  /** posisi awal vertikal (%) */
  top: number;
  /** ukuran (px tinggi) */
  size: number;
  /** durasi animasi (detik) */
  dur: number;
  /** jeda mulai (detik) — biar gak semua berangkat bareng */
  delay: number;
  /** gelap tubuh */
  darkness: number;
  /** intensitas mata */
  eyeIntensity: number;
  /** flap speed */
  flap: number;
}

function CrowSvg({ crow }: { crow: CrowSpec }) {
  const bodyColor = `rgb(${crow.darkness}, ${crow.darkness}, ${crow.darkness + 6})`;
  const wingColor = `rgb(${crow.darkness + 14}, ${crow.darkness + 14}, ${crow.darkness + 22})`;
  return (
    <svg
      viewBox="0 0 64 40"
      width={crow.size * 1.6}
      height={crow.size}
      style={{ filter: "drop-shadow(0 2px 6px rgba(0,0,0,0.6))" }}
    >
      {/* sayap atas (anatomis, mengepak via CSS) */}
      <g className="fanzz-crow-wing-up">
        <path
          d="M30 18 Q18 2 4 6 Q14 10 16 14 Q10 14 6 18 Q14 18 18 20 Q12 24 8 28 Q18 26 24 24 Z"
          fill={wingColor}
          stroke="rgba(0,0,0,0.35)"
          strokeWidth="0.5"
        />
      </g>
      {/* badan */}
      <ellipse cx="34" cy="21" rx="13" ry="6" fill={bodyColor} />
      {/* ekor */}
      <path d="M45 19 L60 15 L58 22 L60 28 L45 24 Z" fill={bodyColor} />
      {/* kepala */}
      <circle cx="22" cy="17" r="5.2" fill={bodyColor} />
      {/* paruh */}
      <path d="M17.5 16.5 L11 17.8 L17.5 19 Z" fill="rgb(28,26,26)" />
      {/* MATA merah sharingan — glow berdenyut + pupil lensing */}
      <circle cx="21" cy="16.2" r="1.9" fill="#ff1a1a" className="fanzz-crow-eye" />
      <circle cx="21" cy="16.2" r="1.9" fill="none" stroke="#ff4d4d" strokeWidth="0.45" opacity="0.85" className="fanzz-crow-eye-ring" />
      <circle cx="21" cy="16.2" r="0.62" fill="#2b0000" />
      {/* kaki kecil terlipat saat terbang */}
      <path d="M34 26 L36 29 M38 26 L39 29" stroke="rgb(20,20,20)" strokeWidth="0.9" />
      {/* sayap bawah */}
      <g className="fanzz-crow-wing-down">
        <path
          d="M30 22 Q20 34 8 34 Q16 28 18 26 Q12 26 7 24 Q16 22 24 22 Z"
          fill={wingColor}
          stroke="rgba(0,0,0,0.3)"
          strokeWidth="0.5"
        />
      </g>
    </svg>
  );
}

export default function CrowAnimation({ onDone }: { onDone?: () => void }) {
  const [alive, setAlive] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => {
      setAlive(false);
      onDone?.();
    }, 7000);
    return () => clearTimeout(t);
  }, [onDone]);

  const crows = useMemo<CrowSpec[]>(() => {
    const list: CrowSpec[] = [];
    let seed = 1337;
    const rnd = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
    // V2-new (#13): gerombolan lebih besar & lebih seram — 3 gelombang + 1 gagak alfa raksasa
    // 1) kiri → kanan (10 ekor)
    for (let i = 0; i < 10; i++) {
      list.push({
        id: i,
        dir: "ltr",
        top: 6 + rnd() * 38,
        size: 24 + rnd() * 34,
        dur: 3.0 + rnd() * 2.0,
        delay: i * 0.12 + rnd() * 0.25,
        darkness: 18 + Math.floor(rnd() * 20),
        eyeIntensity: 0.85 + rnd() * 0.6,
        flap: 0.42 + rnd() * 0.38,
      });
    }
    // 2) kanan → kiri-bawah (9 ekor)
    for (let i = 0; i < 9; i++) {
      list.push({
        id: 100 + i,
        dir: "rtl-down",
        top: 3 + rnd() * 26,
        size: 20 + rnd() * 30,
        dur: 3.4 + rnd() * 2.2,
        delay: 0.25 + i * 0.14 + rnd() * 0.3,
        darkness: 14 + Math.floor(rnd() * 18),
        eyeIntensity: 0.8 + rnd() * 0.6,
        flap: 0.4 + rnd() * 0.38,
      });
    }
    // 3) bawah → kiri (8 ekor)
    for (let i = 0; i < 8; i++) {
      list.push({
        id: 200 + i,
        dir: "b2l",
        top: 56 + rnd() * 34,
        size: 22 + rnd() * 30,
        dur: 3.6 + rnd() * 1.8,
        delay: 0.5 + i * 0.13 + rnd() * 0.3,
        darkness: 24 + Math.floor(rnd() * 16),
        eyeIntensity: 0.85 + rnd() * 0.55,
        flap: 0.45 + rnd() * 0.32,
      });
    }
    // 4) GAGAK ALFA — paling besar, paling gelap, menembus layar paling akhir
    list.push({
      id: 999,
      dir: "ltr",
      top: 30,
      size: 78,
      dur: 3.2,
      delay: 1.1,
      darkness: 8,
      eyeIntensity: 1.4,
      flap: 0.36,
    });
    return list;
  }, []);

  if (!alive) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[90] overflow-hidden">
      {/* selubung gelap transisi tema — lebih pekat & berdenyut */}
      <div className="fanzz-crow-veil absolute inset-0 bg-black" />
      {/* V2-new (#13): vignette merah darah + kabut seram */}
      <div
        className="absolute inset-0 opacity-70"
        style={{
          background:
            "radial-gradient(ellipse at center, transparent 30%, rgba(90,0,0,0.28) 72%, rgba(30,0,0,0.6) 100%)",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(180deg, rgba(120,0,0,0.12), transparent 40%, rgba(80,0,0,0.18))",
          animation: "fanzz-blood-pulse 2.6s ease-in-out infinite",
        }}
      />

      {crows.map((c) => {
        // posisi awal & animasi per arah
        const anim =
          c.dir === "ltr"
            ? "fanzz-crow-fly-ltr"
            : c.dir === "rtl-down"
              ? "fanzz-crow-fly-rtl-down"
              : "fanzz-crow-fly-b2l";
        const startLeft =
          c.dir === "ltr" ? "-12vw" : c.dir === "rtl-down" ? "104vw" : "96vw";
        const startTop = c.dir === "b2l" ? `${Math.min(92, c.top + 6)}vh` : `${c.top}vh`;
        return (
          <div
            key={c.id}
            className={`absolute ${anim}`}
            style={{
              left: startLeft,
              top: startTop,
              animationDuration: `${c.dur}s`,
              animationDelay: `${c.delay}s`,
              ["--crow-flap" as string]: `${c.flap}s`,
              ["--crow-eye" as string]: `${c.eyeIntensity}`,
            }}
          >
            <CrowSvg crow={c} />
          </div>
        );
      })}
    </div>
  );
}
