"use client";

import { ShieldAlert } from "lucide-react";

/**
 * Cap Anti-Klaim FanzzTools (V2 Modern-UpdSec, revisi tampilan).
 *
 * PERUBAHAN: dulu cap ini dirender sebagai BUBBLE MELAYANG (fixed, pojok
 * kanan bawah) — sesuai permintaan pemilik, sekarang cap ini TIDAK lagi
 * melayang/pop-up. Cap tampil sebagai TEKS STATIS di bagian PALING BAWAH
 * beranda (di dalam footer), rapi dan tidak menghalangi pandangan.
 *
 * Nilai konstanta tetap dibekukan (Object.freeze) — tidak dapat diubah
 * lewat kode. Lapisan kepemilikan lain tetap berjalan:
 *  - header HTTP X-Copyright (next.config.ts)
 *  - peringatan console (SecurityGuard.tsx)
 */

export const FANZZ_COPYRIGHT = Object.freeze({
  by: "By : Fanzz-Dev.",
  brand: "©FanzzProject",
  since: "2026-10-12",
  warning:
    "Tidak Boleh Mengklaim Web FanzzTools ini sebagai project atau website buatan anda jika tidak ingin terkena masalah!",
});

/** Cap statis — dipanggil di dalam <footer> beranda (bukan bubble). */
export default function CopyrightBadge() {
  return (
    <div className="select-none" aria-label="Cap kepemilikan FanzzTools">
      <p className="text-[10.5px] font-extrabold text-red-200/90">
        {FANZZ_COPYRIGHT.by}{" "}
        <span className="text-white/85">{FANZZ_COPYRIGHT.brand}</span>{" "}
        <span className="text-white/60">{FANZZ_COPYRIGHT.since}</span>
      </p>
      <p className="mx-auto mt-1.5 flex max-w-md items-start justify-center gap-1.5 text-[9.5px] font-bold leading-relaxed text-amber-300/80">
        <ShieldAlert className="mt-px h-3 w-3 shrink-0" />
        <span>{FANZZ_COPYRIGHT.warning}</span>
      </p>
    </div>
  );
}
