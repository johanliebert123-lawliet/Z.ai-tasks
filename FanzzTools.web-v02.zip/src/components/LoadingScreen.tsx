"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

const STATUS_TEXTS = [
  "Menyalakan mesin tools...",
  "Menyiapkan koleksi film...",
  "Membangunkan AI-nya...",
  "Ngecek server musik...",
  "Hampir siap nih...",
];

export default function LoadingScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [statusIdx, setStatusIdx] = useState(0);

  useEffect(() => {
    const start = Date.now();
    const dur = 2600;
    const iv = setInterval(() => {
      const p = Math.min(100, ((Date.now() - start) / dur) * 100);
      setProgress(p);
      setStatusIdx(Math.min(STATUS_TEXTS.length - 1, Math.floor(p / 22)));
      if (p >= 100) {
        clearInterval(iv);
        setTimeout(onDone, 450);
      }
    }, 60);
    return () => clearInterval(iv);
  }, [onDone]);

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background bg-grid overflow-hidden"
      exit={{ opacity: 0, scale: 1.06 }}
      transition={{ duration: 0.5, ease: "easeInOut" }}
    >
      {/* orbs blur dekoratif */}
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-red-600/25 blur-[90px] animate-float" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-blue-800/25 blur-[90px] animate-float" style={{ animationDelay: "1.2s" }} />
      <div className="pointer-events-none absolute top-1/3 right-1/4 h-40 w-40 rounded-full bg-cyan-500/15 blur-[70px] animate-float" style={{ animationDelay: "0.6s" }} />

      {/* logo ring */}
      <div className="relative mb-8">
        <motion.div
          className="absolute -inset-6 rounded-full border-2 border-dashed border-red-500/40 animate-spin-slow"
        />
        <motion.div
          className="absolute -inset-3 rounded-2.5xl bg-gradient-to-br from-red-500 to-red-700 opacity-40 blur-xl animate-pulse-glow"
        />
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 16 }}
          className="relative flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-red-500 via-blue-800 to-blue-900 shadow-2xl"
        >
          <svg viewBox="0 0 24 24" className="h-12 w-12 text-white" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
          </svg>
        </motion.div>
      </div>

      {/* nama */}
      <motion.h1
        initial={{ y: 16, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.15 }}
        className="text-4xl font-extrabold tracking-tight text-glow"
      >
        <span className="gradient-text gradient-animate">FanzzTools</span>
        <span className="ml-1.5 text-red-400/90 text-2xl align-top font-bold">V2</span>
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mt-2 text-sm text-muted-foreground"
      >
        All-in-One Tools • Film • AI • Musik & lebih banyak
      </motion.p>

      {/* progress */}
      <div className="mt-10 w-56 sm:w-72">
        <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
          <motion.div
            className="h-full rounded-full bg-gradient-to-r from-red-500 to-blue-600"
            style={{ width: `${progress}%` }}
          />
        </div>
        <AnimatePresence mode="wait">
          <motion.p
            key={statusIdx}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="mt-3 text-center text-xs text-muted-foreground"
          >
            {STATUS_TEXTS[statusIdx]}
          </motion.p>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
