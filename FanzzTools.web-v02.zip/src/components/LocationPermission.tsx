"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useApp } from "@/lib/app-store";
import { getLocationGps, getLocationByIp } from "@/lib/device-info";
import { MapPin, Navigation, Loader2, X, Globe2, CheckCircle2 } from "lucide-react";

/**
 * Dialog izin lokasi — muncul SEKALI saat pertama masuk app.
 * Kalau diizinkan → GPS presisi + reverse geocode (kecamatan/kota/provinsi/negara).
 * Kalau ditolak → otomatis fallback estimasi via IP.
 */
export default function LocationPermission() {
  const { geoAsked, markGeoAsked, setGeo } = useApp();
  const [state, setState] = useState<"ask" | "loading" | "done">("ask");
  const [geoState, setGeoState] = useState<"gps" | "estimasi" | null>(null);

  // jangan tampil lagi kalau sudah pernah ditanya (session storage = sekali per sesi)
  const [asked, setAsked] = useState(true);
  useEffect(() => {
    queueMicrotask(() => {
      try {
        setAsked(sessionStorage.getItem("fanzz_geo_asked") === "1");
      } catch {
        setAsked(false);
      }
    });
  }, []);

  const allow = async () => {
    setState("loading");
    const g = await getLocationGps();
    if (g) {
      setGeo(g);
      setGeoState("gps");
    } else {
      const est = await getLocationByIp();
      if (est) {
        setGeo(est);
        setGeoState("estimasi");
      }
    }
    try {
      sessionStorage.setItem("fanzz_geo_asked", "1");
    } catch {
      /* ignore */
    }
    markGeoAsked();
    setState("done");
    setTimeout(() => {
      setAsked(true);
    }, 2600);
  };

  const skip = () => {
    try {
      sessionStorage.setItem("fanzz_geo_asked", "1");
    } catch {
      /* ignore */
    }
    markGeoAsked();
    // tetap ambil estimasi IP biar web "tahu" lokasi kasarnya
    getLocationByIp().then((g) => {
      if (g) setGeo(g);
    });
    setAsked(true);
  };

  const visible = !asked && !geoAsked;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[60] flex items-end justify-center bg-black/60 p-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ y: 80, opacity: 0, scale: 0.98 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 60, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 26 }}
            className="glass-strong w-full max-w-sm rounded-3xl p-5 shadow-2xl"
          >
            {state === "done" ? (
              <div className="py-4 text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 260, damping: 16 }}
                  className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white"
                >
                  <CheckCircle2 className="h-7 w-7" />
                </motion.div>
                <p className="text-sm font-extrabold">
                  {geoState === "gps" ? "Lokasi presisi aktif! 🛰️" : geoState === "estimasi" ? "Pakai estimasi ya 📡" : "Siap!"}
                </p>
                <p className="mt-1 text-[11px] text-muted-foreground">
                  {geoState === "gps"
                    ? "Kecamatan, kota, provinsi & koordinat real-time udah kebaca."
                    : "Lokasi diperkirakan dari IP — aktifkan izin GPS kapan aja dari card Lokasi."}
                </p>
              </div>
            ) : state === "loading" ? (
              <div className="py-8 text-center">
                <Loader2 className="mx-auto mb-3 h-8 w-8 animate-spin text-red-400" />
                <p className="text-sm font-bold">Mendeteksi lokasi…</p>
                <p className="mt-1 text-[11px] text-muted-foreground">Butuh beberapa detik, santai aja</p>
              </div>
            ) : (
              <>
                <div className="mb-4 flex items-center gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg shadow-red-500/25">
                    <Navigation className="h-6 w-6" />
                  </span>
                  <div>
                    <p className="text-sm font-extrabold">Izinkan akses lokasi?</p>
                    <p className="text-[11px] text-muted-foreground">Biar FanzzTools tau kamu ada di mana</p>
                  </div>
                </div>
                <div className="mb-4 space-y-2 text-[11px] leading-relaxed text-muted-foreground">
                  <p className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0 text-red-400" />
                    Kamu bakal liat <b>kecamatan, kota, provinsi, negara, sampe koordinat</b> kamu — real-time.
                  </p>
                  <p className="flex items-start gap-2">
                    <Globe2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                    Apabila tidak diizinkan, aplikasi memakai <b>perkiraan dari IP</b> — tetap berfungsi.
                  </p>
                  <p className="flex items-start gap-2">
                    <X className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    Data lokasi hanya di perangkat Anda, tidak disimpan di server.
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={allow}
                    className="flex-1 rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-3 text-xs font-extrabold text-white shadow-lg shadow-red-500/25 transition-transform active:scale-95"
                  >
                    Izinkan Lokasi
                  </button>
                  <button
                    onClick={skip}
                    className="rounded-xl bg-secondary/70 px-4 py-3 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
                  >
                    Nanti aja
                  </button>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
