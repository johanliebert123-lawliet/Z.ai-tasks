"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Loader2, Maximize2, RotateCw, Subtitles, Volume2, VolumeX } from "lucide-react";

/**
 * NativePlayer — pemutar video native <video> + hls.js (V2-new).
 *
 * Keunggulan dibanding iframe embed:
 *  - bebas iklan/pop-up (tidak me-render halaman mirror sama sekali)
 *  - bisa di-seek / diputar ulang / di-skip (keluhan pengguna #5)
 *  - fullscreen + kunci landscape
 *  - dukungan track subtitle (VTT) opsional
 *
 * Props:
 *  - src: URL video (m3u8/mp4). Bisa URL /api/stream/proxy?... agar CORS + Referer diurus server.
 *  - poster, title, onEnded, subtitle (URL vtt), compact (mode kecil di player musik).
 */

export default function NativePlayer({
  src,
  poster,
  title,
  subtitle,
  onEnded,
  autoPlay = true,
}: {
  src: string;
  poster?: string;
  title?: string;
  /** URL subtitle .vtt opsional — otomatis dipasang & dinyalakan */
  subtitle?: string | null;
  onEnded?: () => void;
  autoPlay?: boolean;
}) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadKey, setReloadKey] = useState(0);
  const [muted, setMuted] = useState(false);
  const [hlsSupported, setHlsSupported] = useState<boolean | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [duration, setDuration] = useState(0);

  const isHls = /\.m3u8/i.test(src.split("?")[0]);

  /* ---- pasang hls.js kalau perlu ---- */
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    let hls: { destroy: () => void; on: (e: string, cb: (e: unknown, d: { fatal?: boolean }) => void) => void; loadSource: (s: string) => void; attachMedia: (m: HTMLVideoElement) => void } | null = null;
    let cancelled = false;

    const nativeHls = v.canPlayType("application/vnd.apple.mpegurl") !== "";
    const setup = async () => {
      if (!isHls || nativeHls) {
        setHlsSupported(true);
        v.src = src;
        return;
      }
      // Chromium desktop tidak bisa m3u8 native — pakai hls.js via MSE
      try {
        const mod = await import("hls.js");
        const Hls = mod.default;
        if (!Hls.isSupported()) {
          // upaya terakhir: coba native saja (Safari)
          setHlsSupported(nativeHls);
          v.src = src;
          return;
        }
        const inst = new Hls({ enableWorker: true, lowLatencyMode: false, maxBufferLength: 30 });
        hls = inst as unknown as typeof hls;
        setHlsSupported(true);
        inst.loadSource(src);
        inst.attachMedia(v);
        inst.on("hlsError" as "hlsError", (_e, data) => {
          if (data?.fatal) setError("Aliran video terputus — tekan muat ulang.");
        });
      } catch {
        setError("Gagal memuat modul pemutar HLS.");
      }
    };
    if (!cancelled) void setup();

    return () => {
      cancelled = true;
      try {
        hls?.destroy();
      } catch {
        /* abaikan */
      }
    };
     
  }, [src, reloadKey]);

  /* ---- pasang track subtitle ---- */
  useEffect(() => {
    const v = videoRef.current;
    if (!v || !subtitle) return;
    // lepas track lama
    v.querySelectorAll("track").forEach((t) => t.remove());
    const tr = document.createElement("track");
    tr.kind = "subtitles";
    tr.label = "Subtitle";
    tr.src = subtitle;
    tr.default = true;
    v.appendChild(tr);
    const onLoaded = () => {
      if (v.textTracks[0]) {
        v.textTracks[0].mode = "showing";
        setSubOn(true);
      }
    };
    v.addEventListener("loadedmetadata", onLoaded, { once: true });
    return () => v.removeEventListener("loadedmetadata", onLoaded);
     
  }, [subtitle]);

  const [subOn, setSubOn] = useState(false);
  const toggleSub = () => {
    const v = videoRef.current;
    if (!v) return;
    const t = v.textTracks[0];
    if (!t) return;
    t.mode = t.mode === "showing" ? "hidden" : "showing";
    setSubOn(t.mode === "showing");
  };

  /* ---- fullscreen + kunci landscape ---- */
  const goFullscreenLandscape = useCallback(async () => {
    const el = wrapRef.current;
    if (!el) return;
    try {
      if (!document.fullscreenElement) {
        await el.requestFullscreen();
        const orientation = screen.orientation as (ScreenOrientation & { lock?: (o: string) => Promise<void> }) | undefined;
        await orientation?.lock?.("landscape").catch(() => {});
      } else {
        const orientation = screen.orientation as (ScreenOrientation & { unlock?: () => void }) | undefined;
        orientation?.unlock?.();
        await document.exitFullscreen();
      }
    } catch {
      /* beberapa browser membatasi — abaikan */
    }
  }, []);

  const fmt = (t: number) => {
    if (!Number.isFinite(t) || t < 0) t = 0;
    const h = Math.floor(t / 3600);
    const m = Math.floor((t % 3600) / 60);
    const s = Math.floor(t % 60);
    return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
  };

  return (
    <div ref={wrapRef} className="relative w-full overflow-hidden rounded-2xl bg-black shadow-2xl">
      <div className="relative aspect-video w-full">
        {loading && !error && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/70">
            <Loader2 className="h-8 w-8 animate-spin text-red-400" />
            <p className="text-[11px] font-bold text-white/80">Menyiapkan pemutar native…</p>
            <p className="text-[9px] text-white/50">Tanpa iklan — bisa diskip & diputar ulang</p>
          </div>
        )}
        {error && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2.5 bg-black/85 p-6 text-center">
            <p className="text-sm font-bold text-red-300">{error}</p>
            <button
              onClick={() => {
                setError("");
                setLoading(true);
                setReloadKey((k) => k + 1);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3.5 py-2 text-xs font-bold text-white"
            >
              <RotateCw className="h-3.5 w-3.5" /> Muat ulang video
            </button>
          </div>
        )}
        <video
          key={reloadKey}
          ref={videoRef}
          poster={poster}
          className="h-full w-full bg-black"
          controls
          playsInline
          autoPlay={autoPlay}
          muted={muted}
          crossOrigin="anonymous"
          onLoadedMetadata={() => {
            setLoading(false);
            const v = videoRef.current;
            if (v && Number.isFinite(v.duration)) setDuration(v.duration);
          }}
          onTimeUpdate={() => {
            const v = videoRef.current;
            if (v) setElapsed(v.currentTime);
          }}
          onWaiting={() => setLoading(true)}
          onPlaying={() => setLoading(false)}
          onError={() => {
            setLoading(false);
            setError("Video tidak dapat diputar dari sumber ini — coba mirror lain atau muat ulang.");
          }}
          onEnded={onEnded}
        />
      </div>

      {/* bar kontrol ekstra */}
      <div className="flex items-center gap-1.5 border-t border-white/10 bg-black/60 px-2.5 py-2">
        <button
          onClick={goFullscreenLandscape}
          className="flex items-center gap-1.5 rounded-xl bg-white/10 px-2.5 py-1.5 text-[10px] font-bold text-white transition-colors hover:bg-white/20"
          title="Fullscreen + kunci landscape"
        >
          <Maximize2 className="h-3.5 w-3.5" /> Fullscreen
        </button>
        <button
          onClick={() => {
            const v = videoRef.current;
            if (v) {
              v.muted = !v.muted;
              setMuted(v.muted);
            }
          }}
          className="flex items-center gap-1.5 rounded-xl bg-white/10 px-2.5 py-1.5 text-[10px] font-bold text-white transition-colors hover:bg-white/20"
        >
          {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />} {muted ? "Suara: mati" : "Suara: nyala"}
        </button>
        {subtitle ? (
          <button
            onClick={toggleSub}
            className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[10px] font-bold transition-colors ${
              subOn ? "bg-red-500 text-white" : "bg-white/10 text-white hover:bg-white/20"
            }`}
          >
            <Subtitles className="h-3.5 w-3.5" /> CC
          </button>
        ) : null}
        <button
          onClick={() => {
            setError("");
            setLoading(true);
            setReloadKey((k) => k + 1);
          }}
          className="flex items-center gap-1.5 rounded-xl bg-white/10 px-2.5 py-1.5 text-[10px] font-bold text-white transition-colors hover:bg-white/20"
          title="Muat ulang (bypass cache)"
        >
          <RotateCw className="h-3.5 w-3.5" /> Muat ulang
        </button>
        <span className="ml-auto text-[10px] font-bold tabular-nums text-white/60">
          {fmt(elapsed)} / {duration ? fmt(duration) : "—"}
        </span>
        <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[8.5px] font-extrabold text-emerald-300">NATIVE</span>
      </div>

      {title && <p className="clamp-1 bg-black/70 px-3 py-2 text-[11px] font-bold text-white/80">{title}</p>}
    </div>
  );
}
