"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { analyzeJpegExif, analyzePng, type ImageMetaResult } from "@/lib/image-meta";
import { fileFingerprints } from "@/lib/security-scan";
import { useToast } from "@/hooks/use-toast";
import { IconImageMeta, IconHashIoc } from "./security-icons";
import { ImagePlus, Loader2, MapPin, Info, Camera, Hash } from "lucide-react";

/**
 * 8. IMAGE METADATA ANALYZER — FanzzSecurity.
 * Parser EXIF lokal: kamera, software, tanggal, GPS (bila tertanam), dimensi.
 * JUJUR: bila EXIF sudah dihapus (umum foto WhatsApp) → "Metadata tidak
 * tersedia" — lokasi/tanggal TIDAK ditebak.
 */
export default function ImageMetaTool() {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ImageMetaResult | null>(null);
  const [thumb, setThumb] = useState<string | null>(null);
  const [hash, setHash] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string>("");
  const fileRef = useRef<HTMLInputElement>(null);

  const pick = async (f: File | null) => {
    if (!f) return;
    setBusy(true);
    setResult(null);
    setHash(null);
    setThumb(null);
    setFileName(f.name);
    try {
      const url = URL.createObjectURL(f);
      setThumb(url);
      const buf = await f.arrayBuffer();
      // hash
      setHash((await fileFingerprints(buf)).sha256);
      // parser
      const head = new Uint8Array(buf.slice(0, 4));
      let r: ImageMetaResult | null = null;
      if (head[0] === 0xff && head[1] === 0xd8) r = analyzeJpegExif(buf);
      else if (head[0] === 0x89 && head[1] === 0x50) r = analyzePng(buf);
      else {
        toast({ title: "Format belum didukung", description: "Saat ini parser metadata lokal mendukung JPEG & PNG." });
      }
      setResult(r);
    } catch (e) {
      toast({ title: "Gagal membaca gambar", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-300">
          <IconImageMeta className="h-5 w-5" />
        </span>
        <div>
          <h3 className="text-sm font-extrabold">Analisis Metadata Gambar</h3>
          <p className="text-[10px] text-muted-foreground">EXIF, kamera, GPS (bila ada) — lokal, tanpa tebakan</p>
        </div>
      </div>

      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-cyan-500/25 bg-cyan-500/5 px-4 py-6 text-center transition hover:border-cyan-400/50">
        <input ref={fileRef} type="file" accept="image/jpeg,image/png" className="hidden" onChange={(e) => pick(e.target.files?.[0] || null)} />
        {busy ? (
          <Loader2 className="h-6 w-6 animate-spin text-cyan-400" />
        ) : (
          <>
            <ImagePlus className="h-6 w-6 text-cyan-400" />
            <p className="text-[11px] font-bold text-foreground/90">Pilih JPEG / PNG</p>
            <p className="text-[9px] text-muted-foreground">Dibaca langsung di browser — tidak diunggah</p>
          </>
        )}
      </label>

      {result && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-3 rounded-xl border border-white/5 bg-[#0e1526] p-3.5">
          <div className="flex gap-3">
            {thumb && <img src={thumb} alt="pratinjau" className="h-20 w-20 shrink-0 rounded-lg object-cover ring-1 ring-cyan-400/20" />}
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-bold">{fileName}</p>
              <p className="mt-0.5 text-[10px] text-muted-foreground">
                {result.format} • {result.width}×{result.height} px
              </p>
              <p className={`mt-1 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-extrabold ${result.hasExif ? "bg-cyan-500/15 text-cyan-300" : "bg-white/10 text-muted-foreground"}`}>
                <Camera className="h-3 w-3" /> {result.hasExif ? "Metadata ditemukan" : "Metadata tidak tersedia"}
              </p>
            </div>
          </div>

          {hash && (
            <p className="mt-2 flex items-start gap-1.5 break-all rounded-lg bg-black/30 px-2 py-1.5 font-mono text-[8.5px] text-cyan-300/80">
              <Hash className="mt-0.5 h-3 w-3 shrink-0" /> SHA-256: {hash}
            </p>
          )}

          {result.gps && (
            <div className="mt-2 flex items-start gap-2 rounded-lg bg-red-500/10 p-2.5 ring-1 ring-red-400/25">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
              <div>
                <p className="text-[10px] font-extrabold text-red-300">GPS tertanam pada foto</p>
                <p className="mt-0.5 text-[9px] leading-relaxed text-red-200/80">{result.gps.label}</p>
                <a
                  href={`https://www.openstreetmap.org/?mlat=${result.gps.lat}&mlon=${result.gps.lon}#map=15/${result.gps.lat}/${result.gps.lon}`}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  className="mt-1 inline-block rounded-md bg-red-500/20 px-2 py-1 text-[9px] font-bold text-red-200"
                >
                  Lihat perkiraan di peta (OpenStreetMap)
                </a>
              </div>
            </div>
          )}

          {result.fields.length > 0 && (
            <div className="mt-2.5 space-y-1">
              <p className="text-[9px] font-extrabold uppercase tracking-wider text-muted-foreground">Field metadata terbaca</p>
              {result.fields.map((f, i) => (
                <div key={i} className="flex items-baseline justify-between gap-2 rounded-lg bg-white/5 px-2.5 py-1.5 text-[10px]">
                  <span className="shrink-0 font-semibold text-cyan-200/90">{f.key}</span>
                  <span className="break-all text-right text-muted-foreground">{f.value}</span>
                </div>
              ))}
            </div>
          )}

          {result.notes.map((n, i) => (
            <p key={i} className="mt-2 flex items-start gap-1.5 text-[9px] leading-relaxed text-muted-foreground">
              <Info className="mt-0.5 h-3 w-3 shrink-0 text-cyan-400/60" /> {n}
            </p>
          ))}
        </motion.div>
      )}
    </div>
  );
}
