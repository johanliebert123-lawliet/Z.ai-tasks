"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { IconDeviceSec } from "./security-icons";
import { Smartphone, Laptop, ShieldCheck, ChevronDown, ChevronUp, Wifi, Bluetooth, KeyRound, DatabaseBackup, Eye, Globe, Download } from "lucide-react";

/**
 * 11. DEVICE SECURITY ADVISOR — FanzzSecurity.
 * Panduan hardening per platform (Android/iOS/Windows/macOS/Linux) dengan
 * langkah step-by-step yang mobile-friendly. Konten berbasis praktik
 * keamanan umum yang berlaku lintas perangkat — TIDAK mengklaim data
 * spesifik per-model yang memerlukan sumber data eksternal (jujur: panduan
 * umum, bukan database kerentanan perangkat).
 */

type Platform = "android" | "ios" | "windows" | "macos" | "linux";

const PLATFORMS: Array<{ id: Platform; label: string; note: string }> = [
  { id: "android", label: "Android", note: "Termasuk Vivo, Oppo, Xiaomi, Samsung, Realme, Infinix, dll — langkah sama, nama menu bisa beda sedikit per brand" },
  { id: "ios", label: "iOS / iPhone / iPad", note: "Semua model — pengaturan seragam sejak iOS 15+" },
  { id: "windows", label: "Windows", note: "Windows 10/11" },
  { id: "macos", label: "macOS", note: "OS X El Capitan ke atas" },
  { id: "linux", label: "Linux", note: "Distribusi umum (Debian/Ubuntu/Fedora/Arch)" },
];

interface Section {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  steps: string[];
}

const CONTENT: Record<Platform, Section[]> = {
  android: [
    {
      icon: ShieldCheck,
      title: "Update & Patch",
      steps: [
        "Buka Setelan → Tentang ponsel → Pembaruan perangkat lunak. Install semua update keamanan (patch bulanan).",
        "Aktifkan pembaruan otomatis Google Play System: Setelan → Keamanan & privasi → Google Play system update.",
        "Cek umur dukungan perangkat: brand umumnya memberi patch 2-4 tahun. Perangkat yang sudah tidak menerima patch sebaiknya tidak dipakai untuk transaksi/perbankan.",
      ],
    },
    {
      icon: Download,
      title: "Higienitas Instalasi Aplikasi",
      steps: [
        "Pasang aplikasi HANYA dari Google Play / App Store resmi brand. Hindari APK dari situs/forum/telegram — sumber APK pihak ketiga adalah vektor malware Android nomor satu.",
        "Sebelum install, periksa: nama developer, jumlah unduhan, tanggal rilis, dan izin yang diminta (apakah masuk akal untuk fungsi aplikasinya?).",
        "Nonaktifkan 'Install aplikasi tidak dikenal' untuk semua browser/file manager: Setelan → Aplikasi → Akses khusus → Pasang aplikasi tidak dikenal.",
        "Auditor berkala: Setelan → Aplikasi → urutkan berdasar 'Terakhir digunakan' → hapus aplikasi yang tidak dipakai 90 hari+.",
      ],
    },
    {
      icon: Eye,
      title: "Izin & Privasi",
      steps: [
        "Tinjau izin per aplikasi: Setelan → Privasi → Pengelola izin. Cabut izin Lokasi/Kamera/Mikrofon untuk aplikasi yang tidak jelas butuhnya.",
        "Untak izin lokasi: pilih 'Hanya saat aplikasi digunakan' — hindari 'Selalu' kecuali benar-benar perlu (mis. navigasi).",
        "Aktifkan Google Play Protect (pemindai aplikasi bawaan) dan jalankan scan berkala.",
      ],
    },
    {
      icon: Wifi,
      title: "Wi-Fi & Jaringan",
      steps: [
        "Hindari Wi-Fi publik tanpa password untuk login/transaksi. Bila terpaksa, gunakan VPN terpercaya atau data seluler.",
        "Nonaktifkan 'Deteksi jaringan otomatis/terbuka' dan hapus jaringan Wi-Fi lama yang tidak dikenal.",
        "Matikan Wi-Fi & Bluetooth saat tidak dipakai — mengurangi permukaan serangan (Wi-Fi direct, Bluetooth pairing request).",
      ],
    },
    {
      icon: KeyRound,
      title: "Kunci Layar & Akun",
      steps: [
        "Gunakan PIN 6+ digit/pola kuat/biometrik — hindari pola 'L' atau 'Z' yang gampang ditebak dari bekas goresan.",
        "Aktifkan Find My Device (Google) supaya bisa melacak/menghapus data dari jauh bila hilang.",
        "Aktifkan verifikasi 2 langkah di akun Google + pencadangan kode pemulihan di tempat aman (bukan di galeri HP).",
        "Periksa aktivitas akun: myaccount.google.com/security secara berkala.",
      ],
    },
  ],
  ios: [
    {
      icon: ShieldCheck,
      title: "Update & Patch",
      steps: [
        "Setelan → Umum → Pembaruan Perangkat Lunak → aktifkan 'Pembaruan Otomatis'.",
        "iPhone berhenti menerima patch ±5-7 tahun sejak rilis. Perangkat lebih tua dari itu rawan kerentanan publik.",
      ],
    },
    {
      icon: Eye,
      title: "Izin & Privasi",
      steps: [
        "Setelan → Privasi & Keamanan → tinjau tiap kategori (Lokasi, Kamera, Mikrofon, Foto) → set 'Hanya Saat Digunakan' atau tolak.",
        "Aktifkan 'App Privacy Report' (iOS 15+) untuk melacak frekuensi akses sensor/lokasi per aplikasi.",
        "Setelan → Safari → 'Cegah Pelacakan Lintas Situs' + 'Sembunyikan Alamat IP' aktif.",
      ],
    },
    {
      icon: KeyRound,
      title: "Kunci Layar & Akun",
      steps: [
        "Gunakan kode sandi 6+ digit alfanumerik (bukan 4 digit).",
        "Aktifkan Face ID/Touch ID + 'Hapus Data setelah 10 percobaan gagal' bila Anda yakin tidak sering lupa.",
        "Aktifkan Find My (termasuk 'Jaringan Find My') + iCloud Backup terenkripsi.",
        "Apple ID: aktifkan autentikasi dua faktor dan simpan Recovery Key di tempat aman.",
      ],
    },
  ],
  windows: [
    {
      icon: ShieldCheck,
      title: "Update & Defender",
      steps: [
        "Windows Update aktif otomatis (termasuk 'Microsoft Update untuk produk lain').",
        "Windows Security → Proteksi virus & ancaman aktif (Defender real-time ON), jalankan 'Quick scan' mingguan.",
        "Aktifkan 'Keamanan perangkat' → Core isolation → Memory integrity (berbasis virtualisasi).",
      ],
    },
    {
      icon: Download,
      title: "Higienitas Instalasi",
      steps: [
        "Unduh software hanya dari situs resmi vendor. Hindari 'crack/keygen' — selain ilegal, ini pembungkus malware paling umum.",
        "Periksa installer sebelum eksekusi: klik kanan → Properties → baris digital signature valid atau tidak.",
        "Uninstall aplikasi usang: Control Panel → Programs. Setiap aplikasi terpasang = permukaan serangan.",
      ],
    },
    {
      icon: Wifi,
      title: "Jaringan & Browser",
      steps: [
        "Gunakan jaringan 'Private' di rumah (bukan 'Public') — firewall rule berbeda.",
        "Aktifkan DNS terenkripsi (DoH/DoT) di router/browser untuk mengurangi spoofing DNS.",
        "Browser: pasang pemblokir skrip per-situs bila perlu, jangan pasang ekstensi dari sumber tak dikenal.",
      ],
    },
  ],
  macos: [
    {
      icon: ShieldCheck,
      title: "Update & Gatekeeper",
      steps: [
        "Setelan Sistem → Umum → Pembaruan Perangkat Lunak → aktifkan otomatis.",
        "System Settings → Privacy & Security → izinkan aplikasi 'App Store dan developer teridentifikasi' saja.",
        "Aktifkan FileVault (enkripsi disk penuh) — wajib untuk laptop.",
      ],
    },
    {
      icon: KeyRound,
      title: "Akun & Kunci",
      steps: [
        "Gunakan Apple ID dengan autentikasi dua faktor.",
        "Set password BIOS/firmware (Intel Mac: firmware password) untuk mencegah boot dari eksternal tanpa izin.",
      ],
    },
  ],
  linux: [
    {
      icon: ShieldCheck,
      title: "Update & Paket",
      steps: [
        "Update rutin lewat manajer paket distro (apt/dnf/pacman) — repositori resmi saja.",
        "Aktifkan unattended-upgrades untuk patch keamanan otomatis (Debian/Ubuntu).",
        "Hindari skrip install 'curl | bash' dari proyek tak dikenal — baca dulu isinya.",
      ],
    },
    {
      icon: KeyRound,
      title: "Hardening Dasar",
      steps: [
        "Nonaktifkan SSH password login — pakai kunci (ssh-ed25519) + fail2ban.",
        "Firewall aktif (ufw/firewalld) — default deny incoming.",
        "Enkripsi disk (LUKS) untuk laptop; audit layanan berjalan: systemctl list-units --type=service.",
      ],
    },
  ],
};

export default function DeviceSecTool() {
  const [platform, setPlatform] = useState<Platform>("android");
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const sections = CONTENT[platform];
  const meta = PLATFORMS.find((p) => p.id === platform)!;

  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-300">
          <IconDeviceSec className="h-5 w-5" />
        </span>
        <div>
          <h3 className="text-sm font-extrabold">Device Security Advisor</h3>
          <p className="text-[10px] text-muted-foreground">Panduan hardening step-by-step per platform</p>
        </div>
      </div>

      <div className="mb-3 flex flex-wrap gap-1.5">
        {PLATFORMS.map((p) => (
          <button
            key={p.id}
            onClick={() => { setPlatform(p.id); setOpenIdx(0); }}
            className={`rounded-full px-3 py-1.5 text-[10px] font-bold transition ${platform === p.id ? "bg-gradient-to-r from-cyan-500 to-blue-700 text-white" : "bg-white/5 text-muted-foreground hover:text-foreground"}`}
          >
            {p.label}
          </button>
        ))}
      </div>

      <p className="mb-3 rounded-lg bg-cyan-500/8 px-2.5 py-2 text-[9px] leading-relaxed text-cyan-100/70">
        <Laptop className="mr-1 inline h-3 w-3" /> {meta.note}
      </p>

      <div className="space-y-2">
        {sections.map((s, i) => {
          const open = openIdx === i;
          return (
            <div key={s.title} className="overflow-hidden rounded-xl border border-white/5 bg-[#0e1526]">
              <button
                onClick={() => setOpenIdx(open ? null : i)}
                className="flex w-full items-center gap-2.5 px-3.5 py-3 text-left"
                aria-expanded={open}
              >
                <s.icon className="h-4 w-4 shrink-0 text-cyan-400" />
                <span className="flex-1 text-[11px] font-extrabold text-foreground/90">{s.title}</span>
                {open ? <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />}
              </button>
              {open && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} className="border-t border-white/5">
                  <ol className="space-y-2 px-3.5 py-3">
                    {s.steps.map((st, j) => (
                      <li key={j} className="flex items-start gap-2 text-[10.5px] leading-relaxed text-muted-foreground">
                        <span className="mt-px flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 text-[8px] font-extrabold text-cyan-300">{j + 1}</span>
                        {st}
                      </li>
                    ))}
                  </ol>
                </motion.div>
              )}
            </div>
          );
        })}
      </div>

      <p className="mt-3 rounded-lg bg-white/5 p-2.5 text-[9px] leading-relaxed text-muted-foreground">
        Panduan ini adalah praktik hardening umum yang berlaku lintas model perangkat. Basis data kerentanan spesifik per-model/serial (mis. CVE tertentu pada firmware tertentu) memerlukan sumber data eksternal yang belum terintegrasi — tidak dikarang di sini.
      </p>
    </div>
  );
}
