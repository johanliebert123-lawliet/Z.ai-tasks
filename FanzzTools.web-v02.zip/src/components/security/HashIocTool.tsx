"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { fileFingerprints } from "@/lib/security-scan";
import { IconHashIoc } from "./security-icons";
import { FileSearch, Loader2, Copy, KeyRound, Binary, ShieldQuestion } from "lucide-react";

/**
 * 12. HASH / IOC / SECURITY INDICATOR ANALYZER + white-hat utilities:
 *  - hitung SHA-256/SHA-1 file lokal
 *  - deteksi tipe hash dari string (md5/sha1/sha256/sha512)
 *  - JWT decoder (TANPA verifikasi signature — dekode payload untuk inspeksi)
 *  - Base64 decoder
 * JUJUR: analisis reputasi IOC (first seen/last seen) memerlukan sumber
 * reputasi yang belum terkonfigurasi → ditampilkan sebagai "tidak tersedia",
 * tidak dikarang "clean".
 */

type Tab = "hash" | "jwt" | "b64";
const TABS: Array<{ id: Tab; label: string }> = [
  { id: "hash", label: "Hash & File" },
  { id: "jwt", label: "JWT Decode" },
  { id: "b64", label: "Base64" },
];

function detectHashType(s: string): { type: string; bits: number } | null {
  const t = s.trim().toLowerCase();
  if (!/^[a-f0-9]+$/.test(t)) return null;
  const len = t.length;
  if (len === 32) return { type: "MD5", bits: 128 };
  if (len === 40) return { type: "SHA-1", bits: 160 };
  if (len === 64) return { type: "SHA-256", bits: 256 };
  if (len === 128) return { type: "SHA-512", bits: 512 };
  return null;
}

export default function HashIocTool() {
  const { toast } = useToast();
  const [tab, setTab] = useState<Tab>("hash");
  const [hashInput, setHashInput] = useState("");
  const [fileHash, setFileHash] = useState<{ name: string; sha256: string; sha1: string; size: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [jwtInput, setJwtInput] = useState("");
  const [jwtOut, setJwtOut] = useState<{ header: string; payload: string; expState: string } | null>(null);
  const [b64Input, setB64Input] = useState("");
  const [b64Out, setB64Out] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const hashType = detectHashType(hashInput);

  const pickFile = async (f: File | null) => {
    if (!f) return;
    setBusy(true);
    try {
      const buf = await f.arrayBuffer();
      const fp = await fileFingerprints(buf);
      setFileHash({ name: f.name, sha256: fp.sha256, sha1: fp.sha1, size: f.size });
    } catch {
      toast({ title: "File tidak bisa dibaca", variant: "destructive" });
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const decodeJwt = () => {
    try {
      const parts = jwtInput.trim().split(".");
      if (parts.length < 2) throw new Error("Format JWT minimal header.payload");
      const dec = (p: string) => {
        const b = p.replace(/-/g, "+").replace(/_/g, "/");
        const json = atob(b + "=".repeat((4 - (b.length % 4)) % 4));
        return JSON.stringify(JSON.parse(decodeURIComponent(escape(json))), null, 2);
      };
      const header = dec(parts[0]);
      const payload = dec(parts[1]);
      let expState = "Token tidak memuat klaim `exp` (tidak ada kedaluwarsa).";
      try {
        const p = JSON.parse(payload);
        if (p.exp) {
          const d = new Date(p.exp * 1000);
          expState = d.getTime() > Date.now() ? `Berlaku sampai ${d.toLocaleString("id-ID")} (belum kedaluwarsa)` : `KEDALUWARSA sejak ${d.toLocaleString("id-ID")}`;
        }
      } catch { /* payload bukan JSON klaim biasa */ }
      setJwtOut({ header, payload, expState });
    } catch (e) {
      toast({ title: "JWT tidak valid", description: e instanceof Error ? e.message : "", variant: "destructive" });
      setJwtOut(null);
    }
  };

  const decodeB64 = () => {
    try {
      const b = b64Input.trim().replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
      const bin = atob(b + "=".repeat((4 - (b.length % 4)) % 4));
      // tampilkan sebagai UTF-8 bila bisa
      const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
      let text: string;
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
      } catch {
        text = Array.from(bytes.slice(0, 256)).map((x) => x.toString(16).padStart(2, "0")).join(" ") + (bytes.length > 256 ? " …" : "");
      }
      setB64Out(text.slice(0, 8000));
    } catch {
      toast({ title: "Base64 tidak valid", variant: "destructive" });
      setB64Out(null);
    }
  };

  const copy = (t: string) => {
    navigator.clipboard.writeText(t).then(() => toast({ title: "Disalin ke clipboard" }));
  };

  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-300">
          <IconHashIoc className="h-5 w-5" />
        </span>
        <div>
          <h3 className="text-sm font-extrabold">Hash / IOC Analyzer</h3>
          <p className="text-[10px] text-muted-foreground">Utilitas white-hat: hash, JWT decode, Base64</p>
        </div>
      </div>

      <div className="mb-3 flex flex-wrap gap-1.5">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded-full px-3 py-1.5 text-[10px] font-bold transition ${tab === t.id ? "bg-gradient-to-r from-cyan-500 to-blue-700 text-white" : "bg-white/5 text-muted-foreground hover:text-foreground"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "hash" && (
        <div className="space-y-3">
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground">
              <KeyRound className="h-3 w-3" /> Tempel hash untuk diidentifikasi
            </label>
            <input
              value={hashInput}
              onChange={(e) => setHashInput(e.target.value)}
              placeholder="mis. 44d88612fea8a8f36de82e1278abb02f atau 275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2108df2f2f2f..."
              className="w-full rounded-xl border border-cyan-500/15 bg-[#0e1526] px-3 py-2.5 font-mono text-[11px] outline-none focus:border-cyan-400/40"
            />
            {hashInput && (
              <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} className="mt-2 space-y-1.5">
                {hashType ? (
                  <div className="rounded-lg bg-cyan-500/10 p-2.5 ring-1 ring-cyan-400/25">
                    <p className="text-[11px] font-extrabold text-cyan-300">Tipe: {hashType.type} ({hashType.bits}-bit)</p>
                    <p className="mt-1 flex items-start gap-1.5 text-[9px] leading-relaxed text-muted-foreground">
                      <ShieldQuestion className="mt-0.5 h-3 w-3 shrink-0" />
                      Cek reputasi hash (threat intel) belum terkonfigurasi di deployment ini — status &quot;clean/terdeteksi&quot; tidak bisa diberikan tanpa sumber reputasi nyata. Hash di atas bisa Anda periksa sendiri di layanan publik (mis. VirusTotal) bila mau.
                    </p>
                  </div>
                ) : (
                  <p className="rounded-lg bg-white/5 p-2.5 text-[10px] text-muted-foreground">Bukan format hash hex standar (MD5/SHA-1/SHA-256/SHA-512).</p>
                )}
              </motion.div>
            )}
          </div>

          <div className="border-t border-white/5 pt-3">
            <label className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground">
              <FileSearch className="h-3 w-3" /> Atau hitung hash dari file
            </label>
            <label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed border-cyan-500/25 bg-cyan-500/5 px-4 py-4 text-[10px] font-bold text-cyan-200 transition hover:border-cyan-400/50">
              <input ref={fileRef} type="file" className="hidden" onChange={(e) => pickFile(e.target.files?.[0] || null)} />
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileSearch className="h-4 w-4" />}
              {busy ? "Menghitung…" : "Pilih file (dihitung lokal)"}
            </label>
            {fileHash && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-2 space-y-1.5">
                <p className="truncate text-[10px] font-bold">{fileHash.name} • {(fileHash.size / 1024).toFixed(1)} KB</p>
                <div className="flex items-start gap-1.5 rounded-lg bg-black/30 px-2 py-1.5">
                  <p className="min-w-0 flex-1 break-all font-mono text-[8.5px] text-cyan-300/80">SHA-256: {fileHash.sha256}</p>
                  <button onClick={() => copy(fileHash.sha256)} aria-label="Salin SHA-256" className="text-muted-foreground hover:text-cyan-300">
                    <Copy className="h-3 w-3" />
                  </button>
                </div>
                <div className="flex items-start gap-1.5 rounded-lg bg-black/30 px-2 py-1.5">
                  <p className="min-w-0 flex-1 break-all font-mono text-[8.5px] text-cyan-300/80">SHA-1: {fileHash.sha1}</p>
                  <button onClick={() => copy(fileHash.sha1)} aria-label="Salin SHA-1" className="text-muted-foreground hover:text-cyan-300">
                    <Copy className="h-3 w-3" />
                  </button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      )}

      {tab === "jwt" && (
        <div className="space-y-2.5">
          <textarea
            value={jwtInput}
            onChange={(e) => setJwtInput(e.target.value)}
            rows={4}
            placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NSJ9.signature…"
            className="fanzsec-scroll w-full rounded-xl border border-cyan-500/15 bg-[#0e1526] px-3 py-2.5 font-mono text-[10px] outline-none focus:border-cyan-400/40"
          />
          <button onClick={decodeJwt} disabled={!jwtInput.trim()} className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-blue-700 py-2.5 text-[11px] font-bold text-white disabled:opacity-40">
            Decode (tanpa verifikasi signature)
          </button>
          {jwtOut && (
            <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="space-y-1.5">
              <div className="rounded-lg bg-black/30 p-2.5">
                <p className="mb-1 text-[9px] font-extrabold uppercase text-cyan-300/80">Header</p>
                <pre className="whitespace-pre-wrap break-all font-mono text-[9px] text-foreground/90">{jwtOut.header}</pre>
              </div>
              <div className="rounded-lg bg-black/30 p-2.5">
                <p className="mb-1 text-[9px] font-extrabold uppercase text-cyan-300/80">Payload (claims)</p>
                <pre className="whitespace-pre-wrap break-all font-mono text-[9px] text-foreground/90">{jwtOut.payload}</pre>
              </div>
              <p className="rounded-lg bg-amber-500/10 px-2.5 py-2 text-[9px] leading-relaxed text-amber-200/90">
                Kedaluwarsa: {jwtOut.expState} — dekode ini TIDAK memverifikasi signature (bukan bukti keaslian token).
              </p>
            </motion.div>
          )}
        </div>
      )}

      {tab === "b64" && (
        <div className="space-y-2.5">
          <textarea
            value={b64Input}
            onChange={(e) => setB64Input(e.target.value)}
            rows={4}
            placeholder="aGVsbG8gd29ybGQ= / URL-safe (- _) juga didukung"
            className="fanzsec-scroll w-full rounded-xl border border-cyan-500/15 bg-[#0e1526] px-3 py-2.5 font-mono text-[10px] outline-none focus:border-cyan-400/40"
          />
          <button onClick={decodeB64} disabled={!b64Input.trim()} className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-blue-700 py-2.5 text-[11px] font-bold text-white disabled:opacity-40">
            <Binary className="mr-1.5 inline h-3.5 w-3.5" /> Decode Base64
          </button>
          {b64Out !== null && (
            <pre className="fanzsec-scroll max-h-52 overflow-auto whitespace-pre-wrap break-all rounded-lg bg-black/30 p-2.5 font-mono text-[9px] text-foreground/90">{b64Out}</pre>
          )}
        </div>
      )}
    </div>
  );
}
