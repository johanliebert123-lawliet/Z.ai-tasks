"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import dynamic from "next/dynamic";
import { useApp } from "@/lib/app-store";
import {
  IconFanzzSecurity, IconScanner, IconWebScan, IconDomain, IconIp, IconEmailSec,
  IconPhoneIntel, IconImageMeta, IconApkAnalyzer, IconDeviceSec, IconOsint,
  IconHashIoc, IconWhois, IconMalware, IconShieldCheck, FanzSecLogo,
} from "./security-icons";
import { Music, Play, Pause, RotateCcw, Volume2, ChevronRight, ArrowRight, Info } from "lucide-react";

/* Tool berat di-lazy-load — jangan blok render pertama FanzzSecurity */
const FileScanTool = dynamic(() => import("./FileScanTool"), { ssr: false, loading: () => <p className="p-4 text-center text-[10px] text-muted-foreground">Memuat pemindai file…</p> });
const ImageMetaTool = dynamic(() => import("./ImageMetaTool"), { ssr: false, loading: () => <p className="p-4 text-center text-[10px] text-muted-foreground">Memuat analisis metadata…</p> });
const HashIocTool = dynamic(() => import("./HashIocTool"), { ssr: false, loading: () => <p className="p-4 text-center text-[10px] text-muted-foreground">Memuat analyzer hash…</p> });
const DeviceSecTool = dynamic(() => import("./DeviceSecTool"), { ssr: false, loading: () => <p className="p-4 text-center text-[10px] text-muted-foreground">Memuat advisor perangkat…</p> });

/* ================= MUSIK WHITEHAT — singleton modul =================
 * Satu elemen audio SELURUH APLIKASI (tidak pernah duplikat), loop otomatis.
 * Autoplay best-effort: bila browser memblokir, tombol play tetap tersedia
 * dan status TIDAK dipalsukan menjadi "playing".
 */
let whitehatAudio: HTMLAudioElement | null = null;
let whitehatWantPlay = false;

function getWhitehatAudio(): HTMLAudioElement {
  if (!whitehatAudio) {
    whitehatAudio = new Audio("/music/whitehat.mp3");
    whitehatAudio.loop = true;
    whitehatAudio.preload = "none";
  }
  return whitehatAudio;
}

function useWhitehat() {
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState<string | null>(null);

  useEffect(() => {
    const a = getWhitehatAudio();
    const onPlay = () => { setPlaying(true); setFailed(null); };
    const onPause = () => setPlaying(false);
    const onErr = () => {
      setPlaying(false);
      // 4 = MEDIA_ERR_SRC_NOT_SUPPORTED → file belum diletakkan
      setFailed(a.error?.code === 4
        ? "File musik belum ditempatkan — letakkan whitehat.mp3 di folder public/music/ project, lalu deploy ulang."
        : "Musik gagal diputar (file rusak atau format tidak didukung browser).");
    };
    a.addEventListener("play", onPlay);
    a.addEventListener("pause", onPause);
    a.addEventListener("error", onErr);
    // sinkron status awal (mis. audio masih berjalan dari view sebelumnya) —
    // lewat microtask agar tidak cascading render
    queueMicrotask(() => setPlaying(!a.paused && !a.ended));
    // best-effort resume autoplay bila sebelumnya user sudah memutar
    if (whitehatWantPlay && a.paused) {
      a.play().catch(() => { /* autoplay diblokir — status tetap jujur */ });
    }
    return () => {
      a.removeEventListener("play", onPlay);
      a.removeEventListener("pause", onPause);
      a.removeEventListener("error", onErr);
    };
  }, []);

  const toggle = async () => {
    const a = getWhitehatAudio();
    if (a.paused) {
      whitehatWantPlay = true;
      try { await a.play(); } catch { /* browser blokir autoplay — status tetap pause (jujur) */ }
    } else {
      whitehatWantPlay = false;
      a.pause();
    }
  };

  const restart = async () => {
    const a = getWhitehatAudio();
    a.currentTime = 0;
    whitehatWantPlay = true;
    try { await a.play(); } catch { /* blokir autoplay — tetap jujur */ }
  };

  return { playing, failed, toggle, restart };
}

/* ================= DATA TOOLS ================= */
type ToolId = string; // id bebas — tool lokal maupun pintasan view lain

interface SecTool {
  id: ToolId;
  n: number;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  /** tool lokal (buka panel di halaman ini) vs tool yang sudah ada (pindah view) */
  local?: boolean;
  view?: string;
  note?: string;
}

const SEC_TOOLS: SecTool[] = [
  { id: "filescan", n: 1, title: "Pindai File", desc: "SHA-256, deteksi MIME magic-byte, ekstensi menyamar, inspeksi arsip (anti zip-slip)", icon: IconScanner, local: true },
  { id: "secscan", n: 2, title: "Pindai Web / URL", desc: "HTTPS, header keamanan, TLS, CSP, HSTS — 18+ pemeriksaan", icon: IconWebScan, view: "secscan" },
  { id: "email", n: 3, title: "Email & Breach", desc: "Email trial + OTP (tool internal FanzzTools)", icon: IconEmailSec, view: "email", note: "Cek paparan breach (haveibeenpwned) memerlukan API key yang belum dikonfigurasi" },
  { id: "osint", n: 4, title: "NIK Validator", desc: "Format & region NIK — parse struktur, bukan database rahasia", icon: IconWhois, view: "osint" },
  { id: "osint2", n: 5, title: "WHOIS / DNS / Domain", desc: "Real-time WHOIS, A/MX/TXT/NS, DMARC, SPF", icon: IconDomain, view: "osint" },
  { id: "osint3", n: 6, title: "IP Intelligence", desc: "ASN, ISP, negara, kota aproksimasi — dari sumber publik", icon: IconIp, view: "osint" },
  { id: "osint4", n: 7, title: "Phone Intelligence", desc: "Validasi nomor, operator, tipe line — bukan GPS", icon: IconPhoneIntel, view: "osint" },
  { id: "imagemeta", n: 8, title: "Metadata Gambar", desc: "EXIF: kamera, tanggal, GPS bila tertanam — tanpa tebakan", icon: IconImageMeta, local: true },
  { id: "filescan2", n: 9, title: "Analisis APK", desc: "Struktur APK, manifest, DEX, tanda tangan, library native", icon: IconApkAnalyzer, local: true, note: "Gunakan tool Pindai File dengan file .apk — inspeksi struktur statis" },
  { id: "secscan2", n: 10, title: "HTTP Security / TLS", desc: "Header, sertifikat, kebijakan cookie", icon: IconShieldCheck, view: "secscan" },
  { id: "devicesec", n: 11, title: "Device Security Advisor", desc: "Hardening Android/iOS/Windows/macOS/Linux step-by-step", icon: IconDeviceSec, local: true },
  { id: "hashioc", n: 12, title: "Hash / IOC Analyzer", desc: "Hash file, JWT decode, Base64 — utilitas white-hat", icon: IconHashIoc, local: true },
];

type SecTab = "overview" | "tools" | "status";

export default function FanzzSecurityView() {
  const { setView } = useApp();
  const [tab, setTab] = useState<SecTab>("overview");
  const [openLocal, setOpenLocal] = useState<ToolId | null>(null);
  const { playing, failed, toggle, restart } = useWhitehat();

  const openTool = (t: SecTool) => {
    if (t.local) {
      setOpenLocal(t.id === "filescan2" ? "filescan" : t.id);
      setTab("tools");
    } else if (t.view) {
      setView(t.view as never);
    }
  };

  return (
    <div className="fanzzsec relative -mx-4 px-4 pb-6 md:-mx-8 md:px-8">
      {/* ==== header FanzzSecurity ==== */}
      <div className="fanzzsec-hero relative mb-4 overflow-hidden rounded-2xl border border-cyan-500/20 p-5">
        <div className="relative z-10 flex items-center gap-3.5">
          <IconFanzzSecurity className="h-12 w-12 text-cyan-300 drop-shadow-[0_0_14px_rgba(34,211,238,0.4)]" />
          <div className="min-w-0 flex-1">
            <h1 className="text-xl font-black tracking-tight text-white sm:text-2xl">
              Fanzz<span className="text-cyan-400">Security</span>
            </h1>
            <p className="text-[11px] text-cyan-100/70">Security Center — analisis nyata, hasil jujur, tanpa drama.</p>
          </div>
          {/* tombol musik whitehat — kanan atas */}
          <div className="flex shrink-0 items-center gap-1.5">
            <button
              onClick={restart}
              aria-label="Putar ulang musik dari awal"
              className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-500/10 text-cyan-300 ring-1 ring-cyan-400/25 transition hover:bg-cyan-500/20"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <button
              onClick={toggle}
              aria-label={playing ? "Jeda musik whitehat" : "Putar musik whitehat"}
              className={`flex h-9 w-9 items-center justify-center rounded-xl ring-1 transition ${
                playing
                  ? "bg-gradient-to-br from-cyan-500 to-blue-700 text-white shadow-lg shadow-cyan-500/30 ring-cyan-300/40"
                  : "bg-cyan-500/10 text-cyan-300 ring-cyan-400/25 hover:bg-cyan-500/20"
              }`}
            >
              {playing ? <Volume2 className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
          </div>
        </div>
        {playing && (
          <div className="relative z-10 mt-2 flex items-center gap-1.5 text-[9px] font-bold text-cyan-300/80">
            <Music className="h-3 w-3" /> whitehat.mp3 — loop aktif
          </div>
        )}
        {failed && (
          <p className="relative z-10 mt-2 rounded-lg bg-amber-500/10 px-2.5 py-1.5 text-[9px] leading-relaxed text-amber-200/90">{failed}</p>
        )}
      </div>

      {/* ==== navigasi tab ==== */}
      <div className="mb-4 flex gap-1.5 overflow-x-auto">
        {([
          { id: "overview", label: "Ringkasan" },
          { id: "tools", label: "Security Tools" },
          { id: "status", label: "Status Keamanan" },
        ] as Array<{ id: SecTab; label: string }>).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative shrink-0 rounded-full px-4 py-2 text-[11px] font-extrabold transition ${
              tab === t.id ? "text-white" : "text-cyan-100/60 hover:text-cyan-100"
            }`}
          >
            {tab === t.id && (
              <motion.span
                layoutId="sec-tab-pill"
                className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500 to-blue-700 shadow-lg shadow-cyan-500/25"
                transition={{ type: "spring", stiffness: 380, damping: 32 }}
              />
            )}
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
        {/* pintasan FanzSec.Ai */}
        <button
          onClick={() => setView("fanzsec" as never)}
          className="ml-auto flex shrink-0 items-center gap-2 rounded-full border border-cyan-400/30 bg-cyan-500/10 px-4 py-2 text-[11px] font-extrabold text-cyan-200 transition hover:bg-cyan-500/20"
        >
          <FanzSecLogo className="h-5 w-5" /> FanzSec.Ai <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* ==== konten tab ==== */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.18, ease: "easeOut" }}
        >
          {/* ---------- RINGKASAN ---------- */}
          {tab === "overview" && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                {[
                  { label: "Tools aktif", value: "12", sub: "4 lokal + 8 terintegrasi" },
                  { label: "Analisis file", value: "LOKAL", sub: "browser Anda, nol upload" },
                  { label: "AI Assistant", value: "FanzSec.Ai", sub: "49 MB per lampiran" },
                  { label: "Fake verdict", value: "0", sub: "hasil jujur atau unavailable" },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-3">
                    <p className="text-[9px] font-bold uppercase tracking-wider text-cyan-100/50">{s.label}</p>
                    <p className="mt-1 text-base font-black text-cyan-300">{s.value}</p>
                    <p className="text-[9px] text-muted-foreground">{s.sub}</p>
                  </div>
                ))}
              </div>

              <div className="rounded-2xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-4">
                <p className="flex items-center gap-2 text-xs font-extrabold text-cyan-200">
                  <IconShieldCheck className="h-4 w-4" /> Prinsip FanzzSecurity
                </p>
                <div className="mt-2.5 space-y-2 text-[11px] leading-relaxed text-muted-foreground">
                  <p className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-400" />
                    <span><b className="text-foreground">User-controlled</b> — semua pemeriksaan dijalankan atas permintaan Anda, hasil ditampilkan apa adanya.</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-400" />
                    <span><b className="text-foreground">Tanpa hasil palsu</b> — tanpa engine reputasi yang terkonfigurasi, verdict ditampilkan HEURISTIC_ONLY/UNSCANNABLE, bukan mengarang "virus detected" atau "100% aman".</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-400" />
                    <span><b className="text-foreground">Privasi</b> — pemindaian file & metadata berjalan lokal di browser; tidak ada file yang dikirim ke pihak ketiga.</span>
                  </p>
                  <p className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-400" />
                    <span><b className="text-foreground">White-hat</b> — tool untuk pertahanan & pembelajaran legal, bukan untuk menyerang milik orang lain.</span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setTab("tools")}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-700 py-3.5 text-xs font-extrabold text-white shadow-lg shadow-cyan-500/25"
              >
                Buka 12 Security Tools <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* ---------- TOOLS ---------- */}
          {tab === "tools" && (
            <div className="space-y-3">
              <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                {SEC_TOOLS.map((t) => (
                  <motion.button
                    key={`${t.id}-${t.n}`}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => openTool(t)}
                    className={`group rounded-xl border p-3.5 text-left transition ${
                      t.local
                        ? "border-cyan-500/20 bg-[#0a0f1c]/70 hover:border-cyan-400/40 hover:bg-cyan-500/5"
                        : "border-white/8 bg-[#0c1322]/60 hover:border-cyan-400/25"
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${t.local ? "bg-cyan-500/15 text-cyan-300" : "bg-white/5 text-cyan-200/70"}`}>
                        <t.icon className="h-4.5 w-4.5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[11.5px] font-extrabold text-foreground/95">
                          <span className="mr-1 text-[9px] font-mono text-cyan-400/60">{String(t.n).padStart(2, "0")}</span>
                          {t.title}
                        </p>
                        <p className="mt-0.5 line-clamp-2 text-[9.5px] leading-snug text-muted-foreground">{t.desc}</p>
                      </div>
                      {t.local ? (
                        <span className="rounded-full bg-cyan-500/20 px-1.5 py-0.5 text-[8px] font-extrabold text-cyan-300">LOKAL</span>
                      ) : (
                        <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground/60" />
                      )}
                    </div>
                    {t.note && <p className="mt-1.5 text-[8.5px] italic text-amber-300/70">{t.note}</p>}
                  </motion.button>
                ))}
              </div>

              {/* panel tool lokal yang dibuka */}
              <AnimatePresence>
                {openLocal && (
                  <motion.div
                    key={openLocal}
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="overflow-hidden"
                  >
                    {openLocal === "filescan" && <FileScanTool />}
                    {openLocal === "imagemeta" && <ImageMetaTool />}
                    {openLocal === "hashioc" && <HashIocTool />}
                    {openLocal === "devicesec" && <DeviceSecTool />}
                    <button onClick={() => setOpenLocal(null)} className="mx-auto mt-2 block text-[10px] font-bold text-muted-foreground hover:text-red-400">
                      Tutup panel
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* ---------- STATUS KEAMANAN ---------- */}
          {tab === "status" && (
            <div className="space-y-2.5">
              {[
                { name: "Pemindai file (hash + heuristik)", state: "AKTIF", note: "lokal di browser" },
                { name: "Pemindai web/URL & header", state: "AKTIF", note: "via Cek Keamanan Web (tool internal)" },
                { name: "Analisis metadata gambar (EXIF)", state: "AKTIF", note: "JPEG/PNG lokal" },
                { name: "Hash/IOC & JWT analyzer", state: "AKTIF", note: "lokal" },
                { name: "FanzSec.Ai (AI security)", state: "AKTIF", note: "lampiran maks 49 MB, diproses lokal" },
                { name: "Reputation engine (VirusTotal dsb.)", state: "TIDAK TERKONFIGURASI", note: "verdict malware eksternal tidak diklaim" },
                { name: "Breach exposure API (email)", state: "TIDAK TERKONFIGURASI", note: "status paparan breach tidak dipalsukan" },
              ].map((s) => (
                <div key={s.name} className="flex items-center gap-3 rounded-xl border border-white/5 bg-[#0a0f1c]/70 p-3">
                  <span className={`h-2 w-2 shrink-0 rounded-full ${s.state === "AKTIF" ? "bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.6)]" : "bg-amber-500"}`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-bold text-foreground/90">{s.name}</p>
                    <p className="text-[9px] text-muted-foreground">{s.note}</p>
                  </div>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[8.5px] font-extrabold ${s.state === "AKTIF" ? "bg-cyan-500/15 text-cyan-300" : "bg-amber-500/15 text-amber-300"}`}>
                    {s.state}
                  </span>
                </div>
              ))}
              <p className="flex items-start gap-2 rounded-xl bg-white/5 p-3 text-[9px] leading-relaxed text-muted-foreground">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400/70" />
                Status di atas adalah kondisi nyata deployment ini. Kapabilitas yang membutuhkan layanan pihak ketiga ditandai jujur sebagai tidak terkonfigurasi — FanzzSecurity tidak menampilkan hasil keamanan yang dikarang.
              </p>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
