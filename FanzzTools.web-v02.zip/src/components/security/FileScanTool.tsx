"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { scanFile, type FileScanResult } from "@/lib/security-scan";
import { IconScanner } from "./security-icons";
import { Upload, FileCheck2, AlertTriangle, ShieldAlert, Loader2, X, Trash2, Info } from "lucide-react";

/**
 * 1. FILE SECURITY SCANNER — FanzzSecurity.
 * Pilihan 1-10 file, semua jenis (analisis lokal: SHA-256 + magic-byte +
 * kecocokan ekstensi + inspeksi arsip anti zip-slip/bomb). Tidak ada file
 * yang dijalankan & tidak ada file yang dikirim keluar.
 * Verdict JUJUR: HEURISTIC_ONLY / SUSPICIOUS — engine antivirus belum
 * dikonfigurasi, jadi TIDAK pernah mengklaim "virus detected".
 */
export default function FileScanTool() {
  const { toast } = useToast();
  const [results, setResults] = useState<FileScanResult[]>([]);
  const [scanning, setScanning] = useState(false);
  const [stage, setStage] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<{ name: string; total: number } | null>(null);

  const pick = async (files: FileList | null) => {
    if (!files?.length) return;
    const arr = Array.from(files).slice(0, 10);
    if (files.length > 10) {
      toast({ title: "Maksimal 10 file", description: "Hanya 10 file pertama yang dipindai." });
    }
    setScanning(true);
    setResults([]);
    setPreview({ name: `${arr.length} file`, total: arr.length });
    const out: FileScanResult[] = [];
    try {
      for (let i = 0; i < arr.length; i++) {
        const f = arr[i];
        setStage(`${i + 1}/${arr.length} • ${f.name.slice(0, 28)}`);
        out.push(await scanFile(f));
        setResults([...out]);
      }
    } catch (e) {
      toast({ title: "Pemindaian gagal", description: e instanceof Error ? e.message : "File tidak bisa dibaca", variant: "destructive" });
    } finally {
      setScanning(false);
      setStage("");
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const statusStyle = (s: FileScanResult["status"]) =>
    s === "SUSPICIOUS"
      ? { chip: "bg-red-500/15 text-red-300 ring-red-400/30", icon: <ShieldAlert className="h-4 w-4" /> }
      : { chip: "bg-cyan-500/10 text-cyan-300 ring-cyan-400/25", icon: <FileCheck2 className="h-4 w-4" /> };

  const recLabel: Record<FileScanResult["recommendation"], string> = {
    KEEP: "KEEP — aman menurut heuristik, tetap hati-hati sumber",
    REVIEW: "REVIEW — tinjau sumber & tujuan file sebelum dipakai",
    QUARANTINE: "QUARANTINE — isolasi file bila tidak yakin",
    REMOVE_RECOMMENDED: "REMOVE RECOMMENDED — indikator kuat penyamaran/pola berbahaya",
  };

  return (
    <div className="rounded-2xl border border-cyan-500/15 bg-[#0a0f1c]/70 p-4">
      <div className="mb-3 flex items-center gap-2.5">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-300">
          <IconScanner className="h-5 w-5" />
        </span>
        <div>
          <h3 className="text-sm font-extrabold">Pindai File</h3>
          <p className="text-[10px] text-muted-foreground">1-10 file • semua format • analisis lokal (hash, magic-byte, arsip)</p>
        </div>
      </div>

      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-cyan-500/25 bg-cyan-500/5 px-4 py-7 text-center transition hover:border-cyan-400/50 hover:bg-cyan-500/10">
        <input
          ref={fileRef}
          type="file"
          multiple
          className="hidden"
          onChange={(e) => pick(e.target.files)}
        />
        {scanning ? (
          <>
            <Loader2 className="h-6 w-6 animate-spin text-cyan-400" />
            <p className="text-[11px] font-bold text-cyan-300">{stage}</p>
            <p className="text-[9px] text-muted-foreground">Menghitung hash & memeriksa struktur…</p>
          </>
        ) : (
          <>
            <Upload className="h-6 w-6 text-cyan-400" />
            <p className="text-[11px] font-bold text-foreground/90">Pilih file untuk dipindai</p>
            <p className="text-[9px] text-muted-foreground">File TIDAK dikirim ke mana pun — diproses di browser Anda</p>
          </>
        )}
      </label>

      {preview && !scanning && results.length > 0 && (
        <button onClick={() => { setResults([]); setPreview(null); }} className="mt-3 flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground hover:text-red-400">
          <Trash2 className="h-3 w-3" /> Bersihkan hasil
        </button>
      )}

      <div className="mt-3 space-y-2.5">
        {results.map((r, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className="rounded-xl border border-white/5 bg-[#0e1526] p-3.5"
          >
            <div className="flex items-start gap-2.5">
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold text-foreground" title={r.name}>{r.name}</p>
                <p className="mt-0.5 text-[9px] text-muted-foreground">
                  {(r.size / 1024).toFixed(1)} KB • {r.mimeLabel} {r.ext && `(.${r.ext})`} • {r.durationMs} ms
                </p>
              </div>
              <span className={`flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-[9px] font-extrabold ring-1 ${statusStyle(r.status).chip}`}>
                {statusStyle(r.status).icon}
                {r.status}
              </span>
            </div>

            {/* risk score — definisi jujur */}
            <div className="mt-2.5">
              <div className="flex items-center justify-between text-[9px] font-bold">
                <span className="text-muted-foreground">Risk score</span>
                <span className={r.riskScore >= 60 ? "text-red-400" : r.riskScore >= 25 ? "text-amber-400" : "text-emerald-400"}>{r.riskScore}%</span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/10">
                <div
                  className={`h-full rounded-full ${r.riskScore >= 60 ? "bg-red-500" : r.riskScore >= 25 ? "bg-amber-500" : "bg-emerald-500"}`}
                  style={{ width: `${Math.max(3, r.riskScore)}%` }}
                />
              </div>
              <p className="mt-1 text-[8px] leading-relaxed text-muted-foreground/70">
                Skor dari sinyal statis yang terdeteksi (ekstensi vs isi, struktur arsip, pola penyamaran) — BUKAN probabilitas file terinfeksi.
              </p>
            </div>

            {/* sha */}
            <p className="mt-2 break-all rounded-lg bg-black/30 px-2 py-1.5 font-mono text-[8.5px] text-cyan-300/80" aria-label="SHA-256">
              SHA-256: {r.sha256}
            </p>

            {/* sinyal */}
            <div className="mt-2 space-y-1">
              {r.signals.map((s, j) => (
                <div key={j} className="flex items-start gap-1.5 text-[10px] leading-relaxed">
                  {s.level === "danger" ? (
                    <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-red-400" />
                  ) : s.level === "warn" ? (
                    <AlertTriangle className="mt-0.5 h-3 w-3 shrink-0 text-amber-400" />
                  ) : (
                    <Info className="mt-0.5 h-3 w-3 shrink-0 text-cyan-400/70" />
                  )}
                  <div className="min-w-0">
                    <span className={`font-bold ${s.level === "danger" ? "text-red-300" : s.level === "warn" ? "text-amber-300" : "text-foreground/80"}`}>{s.label}</span>
                    <span className="text-muted-foreground"> — {s.detail}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* rekomendasi */}
            <p className={`mt-2 rounded-lg px-2.5 py-1.5 text-[9px] font-bold ${r.recommendation === "REMOVE_RECOMMENDED" ? "bg-red-500/10 text-red-300" : r.recommendation === "REVIEW" ? "bg-amber-500/10 text-amber-300" : "bg-emerald-500/10 text-emerald-300"}`}>
              {recLabel[r.recommendation]}
            </p>
          </motion.div>
        ))}
      </div>

      <p className="mt-3 rounded-lg bg-white/5 p-2.5 text-[9px] leading-relaxed text-muted-foreground">
        Batas analisis: pemindai ini heuristik statis lokal (bukan engine antivirus) — verdict MALICIOUS memerlukan reputation engine yang belum terkonfigurasi.
        Tidak ada file yang dijalankan atau diunggah ke pihak ketian (justru: nol permintaan keluar).
      </p>
    </div>
  );
}
