/**
 * FanzzSecurity — ikon SVG kustom (bukan emoji, bukan sticker).
 * Sistem stroke/fill konsisten: stroke 1.8, sudut rounded, warna via currentColor
 * + aksen cyan untuk highlight (diwarisi tema).
 */
import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { className?: string };
const base = (p: P) => ({
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
  ...p,
});

/** FanzzSecurity — perisai hexagonal dengan inti pemindai */
export function IconFanzzSecurity(p: P) {
  return (
    <svg {...base(p)}>
      <path d="M12 2.5 20 6.4v5.1c0 4.9-3.4 8.4-8 10-4.6-1.6-8-5.1-8-10V6.4L12 2.5Z" />
      <path d="M12 8v3.2" />
      <circle cx="12" cy="14.4" r="1.1" fill="currentColor" stroke="none" />
      <path d="M8.8 11.2a4.5 4.5 0 0 1 0 6.4M15.2 11.2a4.5 4.5 0 0 0 0 6.4" opacity="0.55" />
    </svg>
  );
}

/** scanner — garis pemindai di atas dokumen */
export function IconScanner(p: P) {
  return (
    <svg {...base(p)}>
      <path d="M4 8V5.5A1.5 1.5 0 0 1 5.5 4H8M16 4h2.5A1.5 1.5 0 0 1 20 5.5V8M20 16v2.5a1.5 1.5 0 0 1-1.5 1.5H16M8 20H5.5A1.5 1.5 0 0 1 4 18.5V16" />
      <path d="M4 12h16" />
      <path d="M7.5 9.5h9M7.5 14.5h6" opacity="0.5" />
    </svg>
  );
}

/** shield-check */
export function IconShieldCheck(p: P) {
  return (
    <svg {...base(p)}>
      <path d="M12 2.5 20 6v5.4c0 4.7-3.3 8.2-8 10.1-4.7-1.9-8-5.4-8-10.1V6l8-3.5Z" />
      <path d="m8.8 11.8 2.2 2.2 4.2-4.6" />
    </svg>
  );
}

/** malware — bug di dalam segitiga peringatan */
export function IconMalware(p: P) {
  return (
    <svg {...base(p)}>
      <path d="M12 3 21 19.5H3L12 3Z" />
      <ellipse cx="12" cy="14.6" rx="2.1" ry="3" />
      <path d="M12 11.6V9.7M10.4 12.2l-1.8-1.4M13.6 12.2l1.8-1.4M9.9 14.6H7.6M14.1 14.6h2.3M10.3 16.8l-1.3 1.6M13.7 16.8l1.3 1.6" />
    </svg>
  );
}

/** web scan — browser + garis scan */
export function IconWebScan(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="3" y="4" width="18" height="16" rx="2.5" />
      <path d="M3 9h18M6.5 6.5h.01M9 6.5h.01" />
      <path d="M7 13.5h6M7 16.5h9" opacity="0.6" />
      <path d="M4 12.2h16" strokeWidth="2" />
    </svg>
  );
}

/** domain — globe + centang */
export function IconDomain(p: P) {
  return (
    <svg {...base(p)}>
      <circle cx="10.5" cy="11.5" r="7.5" />
      <path d="M3 11.5h15M10.5 4c2.4 2 3.6 4.7 3.6 7.5S12.9 17 10.5 19c-2.4-2-3.6-4.7-3.6-7.5S8.1 6 10.5 4Z" />
      <path d="m14.5 15.5 3 3 3.5-5" />
    </svg>
  );
}

/** DNS — hierarki node */
export function IconDns(p: P) {
  return (
    <svg {...base(p)}>
      <circle cx="12" cy="4.5" r="2" />
      <circle cx="5" cy="18" r="2" />
      <circle cx="12" cy="18" r="2" />
      <circle cx="19" cy="18" r="2" />
      <path d="M12 6.5v4M12 10.5 5.6 16.2M12 10.5v5.5M12 10.5l6.4 5.7" />
    </svg>
  );
}

/** IP — alamat jaringan */
export function IconIp(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="2.5" y="8" width="19" height="8" rx="2" />
      <path d="M6 12h.01M10 12h.01M14 12h.01M18 12h.01" strokeWidth="2.6" />
      <path d="M6 16v2M18 16v2" opacity="0.5" />
    </svg>
  );
}

/** WHOIS — dokumen identitas domain */
export function IconWhois(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="4" y="3" width="16" height="18" rx="2.5" />
      <circle cx="10" cy="9.5" r="2.4" />
      <path d="M6.6 15.6c.6-1.8 1.9-2.7 3.4-2.7s2.8.9 3.4 2.7" />
      <path d="M15.5 7h2M15.5 10h2M15.5 13h2" opacity="0.6" />
    </svg>
  );
}

/** email security — amplop + perisai kecil */
export function IconEmailSec(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="2.5" y="5" width="19" height="13" rx="2.5" />
      <path d="m3.5 7 8.5 6 8.5-6" />
      <path d="M16.6 14.2h4.4l-2.2 2.8-2.2-2.8Z" fillOpacity="0.25" />
    </svg>
  );
}

/** phone intelligence — sinyal ponsel */
export function IconPhoneIntel(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="7" y="2.5" width="10" height="19" rx="2.5" />
      <path d="M10.5 18.8h3" />
      <path d="M3.5 12.5a8.5 8.5 0 0 1 0-2M20.5 12.5a8.5 8.5 0 0 0 0-2" opacity="0.6" />
    </svg>
  );
}

/** image metadata — foto + tag data */
export function IconImageMeta(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="3" y="5" width="18" height="14" rx="2.5" />
      <circle cx="8.5" cy="9.5" r="1.6" />
      <path d="m4 17 4.5-4.5 3 3 3-4 5.5 5" />
      <path d="M15.5 6.5h4M17.5 4.5v4" />
    </svg>
  );
}

/** APK analyzer — robot android + kaca pembesar */
export function IconApkAnalyzer(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="5" y="6" width="14" height="12" rx="2" />
      <path d="M9 10.5h.01M15 10.5h.01" strokeWidth="2.6" />
      <path d="M9.5 14h5" />
      <path d="m14.5 15.5 4 4M21 17.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
    </svg>
  );
}

/** device security — ponsel + perisai */
export function IconDeviceSec(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="5" y="2.5" width="11" height="19" rx="2.5" />
      <path d="M9 5.5h3" />
      <path d="M18.5 12.5c1.2 1 1.9 2.2 1.9 3.6 0 2.5-1.9 4.4-4.2 5.4-2.3-1-4.2-2.9-4.2-5.4 0-1.4.7-2.6 1.9-3.6" />
    </svg>
  );
}

/** OSINT — kaca pembesar */
export function IconOsint(p: P) {
  return (
    <svg {...base(p)}>
      <circle cx="10.5" cy="10.5" r="6.5" />
      <path d="m15.5 15.5 5 5" />
      <path d="M6.8 10.5a3.7 3.7 0 0 1 7.4 0" opacity="0.55" />
    </svg>
  );
}

/** hash/IOC — kisi sidik jari digital */
export function IconHashIoc(p: P) {
  return (
    <svg {...base(p)}>
      <rect x="4" y="3" width="16" height="18" rx="2.5" />
      <path d="M8 8h.01M12 8h.01M16 8h.01M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01" strokeWidth="2.2" />
    </svg>
  );
}

/** FanzSec.Ai — logo utama: kepala AI cyber bertopi koboi,
 *  SATU mata kiri menyala cyan (glow), bukan emoji/sticker. */
export function FanzSecLogo({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" aria-hidden="true">
      <defs>
        <radialGradient id="fz-eye" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#7dfaff" />
          <stop offset="0.55" stopColor="#22d3ee" />
          <stop offset="1" stopColor="#0e7490" />
        </radialGradient>
        <linearGradient id="fz-hat" x1="14" y1="8" x2="50" y2="22" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#334155" />
          <stop offset="1" stopColor="#0f172a" />
        </linearGradient>
      </defs>
      {/* kepala AI */}
      <rect x="16" y="24" width="32" height="26" rx="9" fill="#1c2733" stroke="#3f5568" strokeWidth="1.6" />
      {/* sisi panel */}
      <path d="M22 46v-8M42 46v-8" stroke="#3f5568" strokeWidth="1.4" strokeLinecap="round" />
      {/* topi koboi */}
      <path d="M12.5 22c4.8 2.4 11.9-3.2 19.5-3.2S46.7 24.4 51.5 22c-2.2 5.4-7.8 7.6-19.5 7.6S14.7 27.4 12.5 22Z" fill="url(#fz-hat)" stroke="#64748b" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M25 18.8c0-3 2.4-4.8 7-4.8s7 1.8 7 4.8c0 2-1 3-2.4 3H27.4c-1.4 0-2.4-1-2.4-3Z" fill="url(#fz-hat)" stroke="#64748b" strokeWidth="1.5" />
      <path d="M10.5 22.6c-1.8-.4-3.4.3-4 1.8M53.5 22.6c1.8-.4 3.4.3 4 1.8" stroke="#64748b" strokeWidth="1.5" strokeLinecap="round" />
      {/* mata kiri menyala cyan */}
      <ellipse cx="25" cy="35" rx="5.6" ry="6.4" fill="url(#fz-eye)" />
      <ellipse cx="25" cy="35" rx="2.2" ry="2.8" fill="#e0feff" />
      <ellipse cx="25" cy="35" rx="8.4" ry="9" fill="none" stroke="#22d3ee" strokeOpacity="0.5" strokeWidth="1.4" />
      {/* mata kanan biasa */}
      <rect x="36.4" y="30.6" width="6.4" height="8.8" rx="3" fill="#0b1620" stroke="#3f5568" strokeWidth="1.6" />
      <rect x="38.8" y="33.4" width="2.4" height="3.2" rx="1.2" fill="#5f7b8e" />
      {/* mulut grill */}
      <path d="M26.5 44.5h11" stroke="#3f5568" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M30 44.5v2.6M34 44.5v2.6" stroke="#3f5568" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  );
}

/** FanzSec.Ai — versi mini untuk bubble melayang */
export function FanzSecBubble({ className = "h-12 w-12" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" aria-hidden="true">
      <defs>
        <radialGradient id="fz-b-eye" cx="0.5" cy="0.5" r="0.5">
          <stop offset="0" stopColor="#7dfaff" />
          <stop offset="1" stopColor="#0e7490" />
        </radialGradient>
      </defs>
      <circle cx="24" cy="24" r="22" fill="#0f1a24" stroke="#22d3ee" strokeOpacity="0.45" strokeWidth="1.6" />
      {/* topi koboi mini */}
      <path d="M9.5 20c3.6 1.8 8.9-2.4 14.5-2.4S35.4 21.8 38.5 20c-1.7 4-5.9 5.7-14.5 5.7S11.2 24 9.5 20Z" fill="#1e293b" stroke="#64748b" strokeWidth="1.2" />
      <path d="M19 16.5c0-2.2 1.8-3.6 5-3.6s5 1.4 5 3.6-.7 2.2-1.7 2.2h-6.6c-1 0-1.7-.9-1.7-2.2Z" fill="#1e293b" stroke="#64748b" strokeWidth="1.2" />
      {/* mata kiri glowing */}
      <ellipse cx="18.5" cy="27" rx="4.2" ry="4.8" fill="url(#fz-b-eye)" />
      <ellipse cx="18.5" cy="27" rx="6.3" ry="7" fill="none" stroke="#22d3ee" strokeOpacity="0.5" strokeWidth="1.1" />
      {/* mata kanan */}
      <rect x="27" y="23.5" width="4.8" height="6.6" rx="2.4" fill="#0b1620" stroke="#3f5568" strokeWidth="1.2" />
      {/* mulut */}
      <path d="M20 35.5h8" stroke="#3f5568" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
