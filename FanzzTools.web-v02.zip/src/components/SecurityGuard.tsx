"use client";

import { useEffect } from "react";

/**
 * Pengaman klien (V2 Modern-UpdSec — diperkuat).
 *
 * Tujuan: MENAIKKAN HAMBATAN pengambilan source code UI, bukan menjamin
 * mustahil (tidak ada web yang bisa 100% anti-inspect — semua HTML/CSS/JS
 * pada akhirnya harus dikirim ke browser pengunjung).
 *
 * Lapisan di sini:
 *  1. Menu klik-kanan (view-source / copy element) dinonaktifkan di produksi.
 *  2. Kombinasi tombol pintas source/save dinonaktifkan:
 *     F12, Ctrl+Shift+I/J/C, Ctrl+U, Ctrl+S, Ctrl+P (di luar input).
 *  3. Drag gambar & elemen media dimatikan (anti save-as cepat).
 *  4. Seleksi teks pada elemen struktural dibatasi via CSS (tetap boleh
 *     di input/textarea/area teks yang memang perlu disalin user).
 *  5. Deteksi DevTools terbuka → tampilkan peringatan kepemilikan anti-klaim
 *     + watermark berkala (penanda bila screenshot/recode diambil).
 *  6. Anti iframe embedding sudah diurus header (X-Frame-Options + CSP
 *     frame-ancestors) di next.config.ts.
 */
export default function SecurityGuard() {
  useEffect(() => {
    if (process.env.NODE_ENV !== "production") return;

    const isEditable = (el: EventTarget | null) => {
      const t = el as HTMLElement | null;
      if (!t) return false;
      return (
        /^(input|textarea)$/i.test(t.tagName) ||
        t.isContentEditable === true
      );
    };

    // 1) blokir menu konteks (view-source / copy element / save image as)
    const onContext = (e: MouseEvent) => {
      if (isEditable(e.target)) return;
      e.preventDefault();
    };
    document.addEventListener("contextmenu", onContext);

    // 2) blokir shortcut source/save/print
    const onKey = (e: KeyboardEvent) => {
      if (isEditable(e.target)) return;
      const k = (e.key || "").toLowerCase();
      const ctrl = e.ctrlKey || e.metaKey;
      // F12 — DevTools
      if (e.key === "F12") {
        e.preventDefault();
        return;
      }
      // Ctrl+Shift+I / J / C — inspect / console / view element
      if (ctrl && e.shiftKey && ["i", "j", "c"].includes(k)) {
        e.preventDefault();
        return;
      }
      // Ctrl+U — view-source, Ctrl+S — save page, Ctrl+P — print→pdf
      if (ctrl && ["u", "s", "p"].includes(k)) {
        e.preventDefault();
        return;
      }
    };
    document.addEventListener("keydown", onKey, true);

    // 3) anti drag gambar/media (save-as cepat via drag ke desktop)
    const onDragStart = (e: DragEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && /^(img|video|audio|source)$/i.test(t.tagName)) e.preventDefault();
    };
    document.addEventListener("dragstart", onDragStart);

    // 4) batasi seleksi teks elemen struktural (style global sekali pasang)
    const style = document.createElement("style");
    style.id = "fanzz-anticopy";
    style.textContent = `
      body :not(input):not(textarea):not([contenteditable="true"]):not([data-fanzz-selectable="1"]) {
        -webkit-user-select: none;
        user-select: none;
      }
      body input, body textarea, [contenteditable="true"], [data-fanzz-selectable="1"] {
        -webkit-user-select: text !important;
        user-select: text !important;
      }
    `;
    document.head.appendChild(style);

    // 5) tanda tangan anti-klaim + deteksi DevTools sederhana
    const warn = () => {
      console.log(
        "%c⚠ FanzzTools V2 — ©FanzzProject • By: Fanzz-Dev. 2026-10-12",
        "color:#22d3ee;font-weight:bold;font-size:16px"
      );
      console.log(
        "%cDilarang menyalin, mengambil source code, atau mengklaim web ini sebagai buatan anda.\nSemua API dilindungi sesi login, rate-limit server, dan penandaan aktivitas.\nMengutak-atik kode ini = melanggar kepemilikan FanzzProject.",
        "color:#f59e0b;font-size:11px"
      );
    };
    warn();
    const t = setInterval(warn, 30000);

    // deteksi DevTools via perbedaan dimensi (heuristik ringan — tanpa nge-freeze)
    let devtoolsOpen = false;
    const detect = () => {
      const threshold = 170;
      const open =
        window.outerWidth - window.innerWidth > threshold ||
        window.outerHeight - window.innerHeight > threshold;
      if (open && !devtoolsOpen) {
        devtoolsOpen = true;
        console.warn(
          "%c[FanzzTools] DevTools terdeteksi. Aktivitas pemeriksaan dicatat. Ingat kepemilikan: ©FanzzProject — By: Fanzz-Dev.",
          "color:#ef4444;font-size:12px;font-weight:bold"
        );
      } else if (!open) {
        devtoolsOpen = false;
      }
    };
    window.addEventListener("resize", detect);
    detect();

    return () => {
      document.removeEventListener("contextmenu", onContext);
      document.removeEventListener("keydown", onKey, true);
      document.removeEventListener("dragstart", onDragStart);
      window.removeEventListener("resize", detect);
      clearInterval(t);
      style.remove();
    };
  }, []);

  return null;
}
