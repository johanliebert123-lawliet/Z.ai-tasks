"use client";

import { FanzzLogo } from "@/components/tools/shared";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, LogIn, UserPlus, Mail, Lock, AtSign, ShieldCheck, Sparkles } from "lucide-react";
import { saveVault, type AppUser } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";

export default function AuthGate({ onLogin }: { onLogin: (u: AppUser) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    setLoading(true);

    try {
      if (mode === "register") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username, email, password }),
        });
        const d = await res.json();
        if (!res.ok || !d.ok) throw new Error(d.error || "Registrasi gagal");
        saveVault({
          email: d.user.email,
          username: d.user.username,
          hash: d.vaultHash,
        });
        toast({ title: `Welcome, ${d.user.username}! 🎉`, description: "Akun lo udah aktif. Gaskeun!" });
        onLogin(d.user);
      } else {
        // login: coba biasa, kalau needRestore pakai vault
        const vault =
          typeof window !== "undefined"
            ? JSON.parse(localStorage.getItem("fanzz_vault_v2") || "null")
            : null;
        let res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        });
        let d = await res.json();
        if (!res.ok && d?.needRestore && vault?.email === email.toLowerCase().trim()) {
          res = await fetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              email,
              password,
              vaultHash: vault.hash,
              username: vault.username,
            }),
          });
          d = await res.json();
        }
        if (!res.ok || !d.ok) throw new Error(d.error || "Login gagal");
        saveVault({
          email: d.user.email,
          username: d.user.username,
          hash: d.vaultHash,
        });
        toast({
          title: `Halo balik, ${d.user.username}! 👋`,
          description: d.restored ? "Akun lo berhasil dipulihkan otomatis." : undefined,
        });
        onLogin(d.user);
      }
    } catch (err) {
      toast({
        title: "Waduh gagal 😵",
        description: err instanceof Error ? err.message : "Coba lagi ya",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, y: -24 }}
      className="relative flex min-h-dvh items-center justify-center bg-background bg-grid px-4 py-10 overflow-hidden"
    >
      <div className="pointer-events-none absolute -top-32 left-1/4 h-80 w-80 rounded-full bg-red-600/20 blur-[100px] animate-float" />
      <div className="pointer-events-none absolute -bottom-32 right-1/4 h-80 w-80 rounded-full bg-blue-800/20 blur-[100px] animate-float" style={{ animationDelay: "1s" }} />

      <motion.div
        initial={{ y: 28, opacity: 0, scale: 0.97 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ type: "spring", stiffness: 160, damping: 20 }}
        className="glass-strong w-full max-w-sm rounded-3xl p-7 shadow-2xl glow-ring"
      >
        {/* logo */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl animate-pulse-glow">
            <FanzzLogo className="h-16 w-16 drop-shadow-xl" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight">
            <span className="gradient-text">FanzzTools</span>
            <span className="ml-1 text-red-400 text-lg align-top font-bold">V2</span>
          </h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Silakan masuk untuk mengakses seluruh tools
          </p>
        </div>

        {/* toggle mode */}
        <div className="mb-5 grid grid-cols-2 gap-1 rounded-xl bg-secondary/70 p-1">
          {(["login", "register"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMode(m)}
              className={`relative rounded-lg py-2 text-sm font-semibold transition-colors ${
                mode === m ? "text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {mode === m && (
                <motion.span
                  layoutId="auth-tab"
                  className="absolute inset-0 rounded-lg bg-gradient-to-r from-red-500 to-red-700"
                  transition={{ type: "spring", stiffness: 350, damping: 30 }}
                />
              )}
              <span className="relative z-10 flex items-center justify-center gap-1.5">
                {m === "login" ? <LogIn className="h-3.5 w-3.5" /> : <UserPlus className="h-3.5 w-3.5" />}
                {m === "login" ? "Masuk" : "Daftar"}
              </span>
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-3.5">
          <AnimatePresence initial={false}>
            {mode === "register" && (
              <motion.div
                key="username-field"
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <Label htmlFor="username" className="text-xs text-muted-foreground">
                  Nama User
                </Label>
                <div className="relative mt-1">
                  <AtSign className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="misal: fanzz_ganteng"
                    className="rounded-xl border-border/60 bg-secondary/50 pl-9"
                    maxLength={24}
                    required
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div>
            <Label htmlFor="email" className="text-xs text-muted-foreground">
              Email
            </Label>
            <div className="relative mt-1">
              <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@lo.com"
                className="rounded-xl border-border/60 bg-secondary/50 pl-9"
                maxLength={120}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="password" className="text-xs text-muted-foreground">
              Password
            </Label>
            <div className="relative mt-1">
              <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="minimal 8 karakter"
                className="rounded-xl border-border/60 bg-secondary/50 pl-9"
                minLength={6}
                maxLength={72}
                required
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-5 text-base font-bold shadow-lg shadow-red-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99] disabled:opacity-70"
          >
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : mode === "login" ? (
              <>
                <LogIn className="mr-1.5 h-4.5 w-4.5" /> Masuk
              </>
            ) : (
              <>
                <Sparkles className="mr-1.5 h-4.5 w-4.5" /> Bikin Akun
              </>
            )}
          </Button>
        </form>

        <p className="mt-5 flex items-center justify-center gap-1.5 text-center text-[11px] text-muted-foreground">
          <ShieldCheck className="h-3.5 w-3.5 text-red-400/70" />
          Session lo dienkripsi & disimpan aman di cookie httpOnly
        </p>
      </motion.div>
    </motion.div>
  );
}
