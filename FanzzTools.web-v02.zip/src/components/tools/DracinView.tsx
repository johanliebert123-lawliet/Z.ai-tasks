"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState, CardSkeleton } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Tv2, Search, Loader2, ArrowLeft, Play, RefreshCw, ListVideo,
  ChevronLeft, ChevronRight, Star, Layers, Smartphone, ShieldAlert,
} from "lucide-react";

/**
 * Nonton Dracin V2.11 (#6/#34): katalog TMDB + pemutaran lewat server embed
 * FanzzTools (/api/movies/servers?type=tv) — sama stabilnya dengan Nonton Film.
 */

const PLAYER_SANDBOX = "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

interface DramaItem {
  id: string;
  tmdbId: number;
  title: string;
  cover: string;
  year?: string;
  genres?: string[];
  episodesCount?: number;
  url: string;
  origin?: string;
}

interface Detail {
  id: string;
  tmdbId: number;
  title: string;
  cover: string;
  synopsis: string;
  genres: Array<{ name: string; slug: string }>;
  seasons: Array<{ number: number; name: string; episodeCount: number }>;
  currentSeason: number;
  episodes: Array<{ number: number; title: string; url: string }>;
  episodesCount: number;
  year?: string;
  rating?: string;
  origin?: string;
  recommendations: DramaItem[];
}

interface ServerOption {
  id: string;
  name: string;
  url: string;
  source: string;
  compat: boolean;
  note?: string;
}

type Mode = "browse" | "detail" | "play";

const REGIONS = [
  { id: "cn", label: "China" },
  { id: "kr", label: "Korea" },
  { id: "all", label: "Semua Asia" },
];

export default function DracinView() {
  const [mode, setMode] = useState<Mode>("browse");
  const [dramas, setDramas] = useState<DramaItem[] | null>(null);
  const [genres, setGenres] = useState<Array<{ name: string; slug: string }>>([]);
  const [genre, setGenre] = useState("semua");
  const [region, setRegion] = useState("cn");
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [detail, setDetail] = useState<Detail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // pemutar
  const [servers, setServers] = useState<ServerOption[]>([]);
  const [activeServer, setActiveServer] = useState<ServerOption | null>(null);
  const [serversLoading, setServersLoading] = useState(false);
  const [playerState, setPlayerState] = useState<"loading" | "ready" | "timeout">("loading");
  const [iframeKey, setIframeKey] = useState(0);
  const [playCtx, setPlayCtx] = useState<{ tmdbId: number; season: number; episode: number; title: string } | null>(null);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const playerWrapRef = useRef<HTMLDivElement>(null);

  const loadHome = useCallback(async (g: string, r: string) => {
    setLoading(true);
    setError("");
    setDramas(null);
    try {
      const url = g && g !== "semua"
        ? `/api/dracin?region=${r}&genre=${encodeURIComponent(g)}`
        : `/api/dracin?region=${r}`;
      const res = await fetch(url);
      const d = await res.json();
      if (d?.ok) {
        setDramas(d.dramas || []);
        if (d.genres?.length) setGenres(d.genres);
      } else throw new Error(d?.error || "Gagal memuat");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat daftar drama");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadHome(genre, region);
  }, [loadHome, genre, region]);

  const doSearch = async () => {
    const t = q.trim();
    if (!t) return;
    setLoading(true);
    setError("");
    setDramas(null);
    try {
      const res = await fetch(`/api/dracin?q=${encodeURIComponent(t)}`);
      const d = await res.json();
      if (d?.ok) setDramas(d.dramas || []);
      else throw new Error(d?.error || "Tidak ada hasil");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Pencarian gagal");
    } finally {
      setLoading(false);
    }
  };

  const openDetail = async (item: DramaItem) => {
    setDetailLoading(true);
    setDetail(null);
    setMode("detail");
    try {
      const res = await fetch(`/api/dracin?detail=${item.tmdbId}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Detail tidak ditemukan");
      setDetail(d.detail);
      pushHistory("dracin", {
        id: d.detail.id,
        title: d.detail.title,
        poster: d.detail.cover,
        subtitle: `${d.detail.episodesCount || "?"} episode`,
        url: String(item.tmdbId),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal membuka detail");
    } finally {
      setDetailLoading(false);
    }
  };

  /** Ganti season di halaman detail. */
  const changeSeason = async (seasonNumber: number) => {
    if (!detail) return;
    setDetailLoading(true);
    try {
      const res = await fetch(`/api/dracin?detail=${detail.tmdbId}&season=${seasonNumber}`);
      const d = await res.json();
      if (d?.ok) setDetail(d.detail);
    } finally {
      setDetailLoading(false);
    }
  };

  /** Buka pemutar episode → ambil daftar server embed lalu render iframe. */
  const openEpisode = useCallback(async (tmdbId: number, season: number, episode: number, title: string) => {
    setPlayCtx({ tmdbId, season, episode, title });
    setMode("play");
    setServersLoading(true);
    setServers([]);
    setActiveServer(null);
    setError("");
    try {
      const res = await fetch(`/api/movies/servers?type=tv&id=${tmdbId}&season=${season}&episode=${episode}&sub=id`);
      const d = await res.json();
      if (d?.ok && d.servers?.length) {
        setServers(d.servers);
        // pilih otomatis: VidLink (punya sub_file) bila ada, selain itu server pertama
        const vidlink = d.servers.find((s: ServerOption) => /vidlink/i.test(s.name));
        setActiveServer(vidlink || d.servers[0]);
      } else {
        throw new Error(d?.error || "Tidak ada server yang tersedia untuk episode ini");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat server");
    } finally {
      setServersLoading(false);
    }
  }, []);

  // timeout pemutar — server lambat → tampil pilihan muat ulang
  useEffect(() => {
    if (mode !== "play" || !activeServer) return;
    setPlayerState("loading");
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setPlayerState((s) => (s === "loading" ? "timeout" : s));
    }, 15000);
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [activeServer, iframeKey, mode]);

  const goFullscreenLandscape = () => {
    const el = playerWrapRef.current;
    if (!el) return;
    el.requestFullscreen?.().then(() => {
      window.screen.orientation?.lock?.("landscape").catch(() => {});
    }).catch(() => {});
  };

  const navigateEp = (delta: number) => {
    if (!playCtx || !detail) return;
    const eps = detail.episodes;
    const idx = eps.findIndex((e) => e.number === playCtx.episode);
    const next = eps[idx + delta];
    if (next) openEpisode(playCtx.tmdbId, playCtx.season, next.number, next.title);
  };

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<Tv2 className="h-5 w-5" />}
        title="Nonton Dracin"
        desc="Drama Asia (China/Korea) — katalog TMDB, diputar lewat 20+ server embed FanzzTools."
      />

      {mode === "browse" && (
        <>
          {/* pencarian */}
          <div className="flex gap-2">
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && doSearch()}
              placeholder="Cari judul drama Asia…"
              className="rounded-xl"
            />
            <Button onClick={doSearch} disabled={!q.trim()} className="rounded-xl bg-gradient-to-r from-rose-500 to-red-600 text-white">
              <Search className="h-4 w-4" />
            </Button>
          </div>

          {/* pilihan asal negara */}
          <div className="flex gap-2">
            {REGIONS.map((r) => (
              <button
                key={r.id}
                onClick={() => setRegion(r.id)}
                className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                  region === r.id
                    ? "bg-gradient-to-r from-rose-500 to-red-600 text-white"
                    : "glass text-muted-foreground hover:text-foreground"
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          {/* pilihan genre */}
          <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
            {[{ name: "Semua", slug: "semua" }, ...genres].map((g) => (
              <button
                key={g.slug}
                onClick={() => setGenre(g.slug)}
                className={`shrink-0 rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                  genre === g.slug
                    ? "bg-gradient-to-r from-rose-500 to-red-600 text-white"
                    : "glass text-muted-foreground hover:text-foreground"
                }`}
              >
                {g.name}
              </button>
            ))}
          </div>

          {loading && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
              {Array.from({ length: 12 }).map((_, i) => (
                <CardSkeleton key={i} />
              ))}
            </div>
          )}
          {error && !loading && (
            <div className="space-y-3">
              <EmptyState icon={<RefreshCw className="h-8 w-8" />} title={error} desc="Coba muat ulang daftar." />
              <div className="flex justify-center">
                <Button onClick={() => loadHome(genre, region)} variant="secondary" className="rounded-xl">
                  <RefreshCw className="mr-1.5 h-4 w-4" /> Muat ulang
                </Button>
              </div>
            </div>
          )}
          {dramas && dramas.length === 0 && !loading && !error && (
            <EmptyState icon={<Tv2 className="h-8 w-8" />} title="Tidak ada drama ditemukan" desc="Coba kata kunci, genre, atau asal negara lain." />
          )}

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
            {dramas?.map((d, i) => (
              <motion.button
                key={`${d.id}-${i}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
                onClick={() => openDetail(d)}
                className="group overflow-hidden rounded-2xl glass text-left transition-transform hover:scale-[1.03]"
              >
                <div className="relative aspect-[2/3] w-full overflow-hidden bg-secondary">
                  {d.cover ? (
                    <img
                      src={d.cover}
                      alt={d.title}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform group-hover:scale-105"
                      referrerPolicy="no-referrer"
                      onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")}
                    />
                  ) : null}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
                  {d.year ? (
                    <span className="absolute right-1.5 top-1.5 rounded-lg bg-black/60 px-1.5 py-0.5 text-[9px] font-bold text-white/90 backdrop-blur-sm">
                      {d.year}
                    </span>
                  ) : null}
                  <div className="absolute inset-x-0 bottom-0 p-2">
                    <p className="line-clamp-2 text-[11px] font-bold leading-tight text-white">{d.title}</p>
                    {d.genres?.length ? (
                      <p className="mt-0.5 truncate text-[9px] text-white/60">{d.genres.slice(0, 3).join(" • ")}</p>
                    ) : null}
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </>
      )}

      {mode === "detail" && (
        <div>
          <Button variant="ghost" onClick={() => { setMode("browse"); setError(""); }} className="mb-3 rounded-xl px-3">
            <ArrowLeft className="mr-1 h-4 w-4" /> Kembali
          </Button>

          {detailLoading && (
            <div className="flex items-center justify-center gap-2 py-16 text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin text-rose-400" /> Memuat detail drama…
            </div>
          )}

          {detail && !detailLoading && (
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="h-40 w-28 shrink-0 overflow-hidden rounded-2xl bg-secondary ring-1 ring-[var(--surface-line)]">
                  {detail.cover && (
                    <img src={detail.cover} alt={detail.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <h2 className="text-lg font-extrabold leading-tight">{detail.title}</h2>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-[10px] font-bold text-muted-foreground">
                    {detail.rating ? (
                      <span className="flex items-center gap-1 text-amber-300">
                        <Star className="h-3 w-3 fill-current" /> {detail.rating}
                      </span>
                    ) : null}
                    {detail.year ? <span>{detail.year}</span> : null}
                    {detail.origin ? <span>{detail.origin}</span> : null}
                    <span className="flex items-center gap-1">
                      <Layers className="h-3 w-3" /> {detail.episodesCount} episode
                    </span>
                  </div>
                  {detail.genres?.length ? (
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {detail.genres.slice(0, 6).map((g) => (
                        <span key={g.slug} className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[9px] font-bold text-rose-300">
                          {g.name}
                        </span>
                      ))}
                    </div>
                  ) : null}
                  <p className="mt-2 line-clamp-4 text-xs leading-relaxed text-muted-foreground">{detail.synopsis}</p>
                </div>
              </div>

              {/* pilih season */}
              {detail.seasons.length > 1 && (
                <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
                  {detail.seasons.map((s) => (
                    <button
                      key={s.number}
                      onClick={() => changeSeason(s.number)}
                      className={`shrink-0 rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                        detail.currentSeason === s.number
                          ? "bg-gradient-to-r from-rose-500 to-red-600 text-white"
                          : "glass text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {s.name} ({s.episodeCount})
                    </button>
                  ))}
                </div>
              )}

              <section>
                <h3 className="mb-2.5 flex items-center gap-2 text-sm font-bold">
                  <ListVideo className="h-4 w-4 text-rose-400" /> Daftar Episode ({detail.episodes.length})
                </h3>
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 md:grid-cols-8">
                  {detail.episodes.map((ep) => (
                    <button
                      key={ep.number}
                      onClick={() => openEpisode(detail.tmdbId, detail.currentSeason, ep.number, ep.title)}
                      title={ep.title}
                      className="rounded-xl glass py-2 text-xs font-bold transition-colors hover:bg-rose-500/20 hover:text-rose-300"
                    >
                      {ep.number}
                    </button>
                  ))}
                </div>
              </section>

              {detail.recommendations?.length ? (
                <section>
                  <h3 className="mb-2.5 text-sm font-bold">Rekomendasi Serupa</h3>
                  <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
                    {detail.recommendations.slice(0, 10).map((r, i) => (
                      <button
                        key={`${r.id}-${i}`}
                        onClick={() => openDetail(r)}
                        className="w-24 shrink-0 overflow-hidden rounded-xl glass text-left"
                      >
                        <div className="aspect-[2/3] w-full overflow-hidden bg-secondary">
                          {r.cover && (
                            <img src={r.cover} alt={r.title} loading="lazy" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                          )}
                        </div>
                        <p className="line-clamp-2 p-1.5 text-[9px] font-bold leading-tight">{r.title}</p>
                      </button>
                    ))}
                  </div>
                </section>
              ) : null}
            </div>
          )}
        </div>
      )}

      {mode === "play" && (
        <div>
          <Button
            variant="ghost"
            onClick={() => { setMode("detail"); setActiveServer(null); setError(""); }}
            className="mb-3 rounded-xl px-3"
          >
            <ArrowLeft className="mr-1 h-4 w-4" /> Kembali ke detail
          </Button>

          {serversLoading && (
            <div className="flex flex-col items-center justify-center gap-3 rounded-2xl bg-black py-20 text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin text-rose-400" />
              <p className="text-xs">Menyiapkan server episode…</p>
            </div>
          )}

          {!serversLoading && error && (
            <EmptyState icon={<Play className="h-8 w-8" />} title="Episode gagal dimuat" desc={error} />
          )}

          {!serversLoading && activeServer && (
            <div className="space-y-3">
              <div ref={playerWrapRef} className="relative overflow-hidden rounded-2xl bg-black shadow-2xl">
                <div className="aspect-video w-full">
                  <iframe
                    key={`${activeServer.id}-${iframeKey}`}
                    src={activeServer.url}
                    title="Fanzz Dracin Player"
                    className="h-full w-full border-0"
                    allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                    allowFullScreen
                    referrerPolicy="no-referrer"
                    sandbox={PLAYER_SANDBOX}
                    onLoad={() => setPlayerState("ready")}
                  />
                </div>

                {/* tombol landscape */}
                <button
                  onClick={goFullscreenLandscape}
                  className="absolute left-2 top-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
                  title="Layar penuh mode landscape"
                >
                  <Smartphone className="h-3.5 w-3.5 -rotate-90" /> Landscape
                </button>

                <AnimatePresence>
                  {playerState === "loading" && (
                    <motion.div initial={{ opacity: 1 }} exit={{ opacity: 0 }} className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 backdrop-blur-sm">
                      <Loader2 className="h-8 w-8 animate-spin text-rose-400" />
                      <p className="text-xs text-white/80">Memuat server <span className="font-bold">{activeServer.name}</span>...</p>
                    </motion.div>
                  )}
                  {playerState === "timeout" && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-6 text-center backdrop-blur-sm">
                      <ShieldAlert className="h-8 w-8 text-amber-400" />
                      <p className="text-sm font-bold text-white">Server lambat / macet</p>
                      <p className="text-xs text-white/60">Coba muat ulang atau ganti server di bawah.</p>
                      <Button size="sm" onClick={() => { setIframeKey((k) => k + 1); setPlayerState("loading"); }} className="rounded-xl bg-rose-500 hover:bg-rose-600">
                        <RefreshCw className="mr-1 h-3.5 w-3.5" /> Muat ulang
                      </Button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* pilih server */}
              <div>
                <p className="mb-2 text-xs font-bold text-muted-foreground">
                  Server pemutar ({servers.length}) — bila satu lambat, coba yang lain:
                </p>
                <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
                  {servers.map((s) => (
                    <button
                      key={s.id}
                      onClick={() => { setActiveServer(s); setPlayerState("loading"); }}
                      className={`shrink-0 rounded-xl px-3 py-2 text-[11px] font-bold transition-colors ${
                        activeServer.id === s.id
                          ? "bg-gradient-to-r from-rose-500 to-red-600 text-white"
                          : "glass text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* navigasi episode */}
              <div className="flex items-center justify-between gap-2">
                <Button variant="secondary" className="rounded-xl" onClick={() => navigateEp(-1)} disabled={!playCtx || playCtx.episode <= 1}>
                  <ChevronLeft className="h-4 w-4" /> Sebelumnya
                </Button>
                <span className="truncate px-2 text-center text-[11px] font-bold text-muted-foreground">
                  E{playCtx?.episode} — {playCtx?.title}
                </span>
                <Button variant="secondary" className="rounded-xl" onClick={() => navigateEp(1)}>
                  Berikutnya <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <p className="rounded-xl bg-rose-500/10 px-3 py-2 text-[10px] leading-relaxed text-rose-300/80">
                Sumber: katalog TMDB + server embed FanzzTools (VidLink, VidSrc, MovieZone, LK21, dll).
                Subtitle Indonesia otomatis bila server menyediakannya (VidLink & LK21 Premium) — cek menu CC di dalam pemutar.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
