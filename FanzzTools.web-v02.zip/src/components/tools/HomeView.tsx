"use client";

import { motion } from "framer-motion";
import { useApp, getWatchHistory, type ViewId } from "@/lib/app-store";
import { MovieCard } from "@/components/tools/shared";
import DeviceStatusCard from "@/components/DeviceStatusCard";
import {
  Clapperboard,
  Bot,
  Music4,
  Download,
  MailPlus,
  Zap,
  Tv,
  Tv2,
  Sparkles,
  ChevronRight,
  Flame,
  Star,
  CalendarDays,
  TrendingUp,
  History,
  Fingerprint,
  Package,
  MessageCircle,
  Newspaper,
  Library,
  BookOpen,
  BookOpen as BookIcon,
  Swords,
  ImageIcon,
  Heart,
  Scissors,
  Dices,
  Music2,
  ShieldAlert,
  Book,
  Palette,
  QrCode,
  Calculator,
  Brain,
  Grid3X3,
  Code2,
  ShieldCheck,
  Blocks,
  Moon,
  Clock3,
  Gamepad2,
  ShieldCheck as ShieldPm,
} from "lucide-react";
import { useEffect, useState } from "react";
import CopyrightBadge from "@/components/CopyrightBadge";

interface HomeData {
  trending: Array<{ id: number; title: string; type: string; poster: string | null; rating: number; year: string }>;
  topMovies: Array<{ id: number; title: string; type: string; poster: string | null; rating: number; year: string }>;
  topSeries: Array<{ id: number; title: string; type: string; poster: string | null; rating: number; year: string }>;
  upcoming: Array<{ id: number; title: string; type: string; poster: string | null; rating: number; year: string }>;
}

const TOOLS: Array<{
  view: ViewId;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  desc: string;
  gradient: string;
  badge?: string;
}> = [
  // FanzSec-Update — Security Center + AI Security Assistant
  { view: "security", icon: ShieldCheck, title: "FanzzSecurity", desc: "Security Center: pindai file/web, metadata, hash/IOC, device advisor + musik whitehat", gradient: "from-cyan-500 to-blue-800", badge: "BARU" },
  { view: "fanzsec", icon: ShieldPm, title: "FanzSec.Ai", desc: "AI Security Assistant — white-hat, analisis lampiran sampai 49 MB", gradient: "from-red-500 to-cyan-600", badge: "BARU" },
  // V2.12 Security-Updt — Parent Monitor / Family Cyber Safety
  { view: "pm", icon: ShieldPm, title: "Parent Monitor", desc: "Family Cyber Safety — pantau HP anak legal & transparan (maks usia anak 35 th)", gradient: "from-blue-600 to-blue-600" },
  // V2 Modern-UpdSec: halaman All-Tools + tools baru di beranda
  { view: "alltools", icon: Grid3X3, title: "The All-Tools", desc: "Semua tools + pencarian + yang akan datang", gradient: "from-red-500 to-red-700", badge: "BARU" },
  { view: "story", icon: Clock3, title: "FanzzStory", desc: "Status 22 jam — teks/foto+musik/video, like & komentar", gradient: "from-rose-500 to-red-600", badge: "BARU" },
  { view: "ibadah", icon: Moon, title: "Ruang Ibadah", desc: "Jadwal sholat, kiblat, bacaan, semua agama", gradient: "from-emerald-500 to-teal-600", badge: "BARU" },
  { view: "quran", icon: BookOpen, title: "Qur'an Digital", desc: "114 surah, 21 imam, tafsir & terjemahan", gradient: "from-green-600 to-emerald-600", badge: "BARU" },
  { view: "debat", icon: Sparkles, title: "Debat Filosofis AI", desc: "Test psikologi + 8 level + skor & unduh", gradient: "from-amber-500 to-red-600", badge: "BARU" },
  { view: "sourcecode", icon: Code2, title: "Ambil Source Code", desc: "HTML/CSS/JS web lain — legal & rapi", gradient: "from-cyan-500 to-sky-600", badge: "BARU" },
  { view: "secscan", icon: ShieldCheck, title: "Cek Keamanan Web", desc: "18+ pemeriksaan, skor A+ s/d F", gradient: "from-emerald-600 to-cyan-600", badge: "BARU" },
  { view: "minecraft", icon: Blocks, title: "Download Minecraft", desc: "APK, mods, maps, shaders, versi lengkap", gradient: "from-green-600 to-lime-600", badge: "BARU" },
  { view: "studio", icon: Palette, title: "Studio Gambar", desc: "13 generator: spiral, brat, IQC, chat palsu, KTP dummy…", gradient: "from-red-500 to-cyan-600", badge: "BARU" },
  // V2.11 (#23 #35 #29 #30): 4 tools baru di beranda
  { view: "hdimage", icon: Sparkles, title: "Image HD", desc: "HD-kan foto sampai 8K + rasio blur", gradient: "from-cyan-500 to-sky-600", badge: "BARU" },
  { view: "qr", icon: QrCode, title: "QR Studio", desc: "Buat QR bergaya + pindai/analisis", gradient: "from-emerald-500 to-teal-600", badge: "BARU" },
  { view: "kalkulator", icon: Calculator, title: "Kalkulator", desc: "Matematika + rumus fisika solver", gradient: "from-red-500 to-red-700", badge: "BARU" },
  { view: "iqtest", icon: Brain, title: "Tes IQ", desc: "75 soal, hasil jujur + kartu PNG", gradient: "from-blue-700 to-blue-700", badge: "BARU" },
  // V2-new (#4): SEMUA tools tampil di beranda — tidak ada yang disembunyikan
  { view: "chat", icon: MessageCircle, title: "Chat Sosial", desc: "Chat realtime, grup, VN, follow", gradient: "from-red-500 to-red-700" },
  { view: "anime", icon: Tv, title: "Nonton Anime", desc: "Sub indo, jadwal, player native", gradient: "from-amber-500 to-orange-600" },
  { view: "manhwa", icon: BookIcon, title: "Baca Manhwa", desc: "Komik full color + search", gradient: "from-cyan-500 to-teal-600" },
  { view: "komik", icon: Book, title: "Baca Komik", desc: "Manhwa + Manhua + Comic (ComicVerse)", gradient: "from-orange-500 to-amber-600", badge: "BARU" },
  { view: "donghua", icon: Swords, title: "Nonton Donghua", desc: "Anime China, hot & akan tayang", gradient: "from-blue-600 to-blue-600" },
  { view: "dracin", icon: Tv2, title: "Nonton Dracin", desc: "Drama Asia sub Indonesia", gradient: "from-rose-500 to-red-600" },
  { view: "gacha", icon: Dices, title: "Gacha Nokos", desc: "Nomor virtual + negara valid", gradient: "from-cyan-500 to-red-700" },
  { view: "lyrics", icon: Music2, title: "Lyrics Music", desc: "Lirik lagu full + tersinkron", gradient: "from-teal-500 to-emerald-600" },
  { view: "profanity", icon: ShieldAlert, title: "Deteksi Kata Sensitif", desc: "Multi-bahasa + leet + hate speech", gradient: "from-red-500 to-rose-600" },
  { view: "history", icon: History, title: "Riwayat", desc: "Riwayat per tools, rapi terpisah", gradient: "from-slate-500 to-gray-600" },
  { view: "aiimage", icon: ImageIcon, title: "AI Image Gen", desc: "Bikin gambar cuma dari teks", gradient: "from-cyan-500 to-red-700" },
  { view: "reactwa", icon: Heart, title: "React Saluran WA", desc: "React emoji ke pesan saluran", gradient: "from-red-500 to-rose-600" },
  { view: "capcut", icon: Scissors, title: "CapCut Pro Gen", desc: "Akun aktif + Pro trial 7 hari", gradient: "from-sky-500 to-blue-600" },
  { view: "nekopoi", icon: Flame, title: "Nekopoi 21+", desc: "Konten dewasa (verifikasi usia)", gradient: "from-rose-500 to-red-600", badge: "21+" },
  { view: "news", icon: Newspaper, title: "Berita", desc: "Update tiap menit + cek fakta", gradient: "from-emerald-500 to-teal-600" },
  { view: "books", icon: Library, title: "Baca Buku/PDF", desc: "Pustaka arsip dunia + PDF lokal", gradient: "from-cyan-500 to-teal-600" },
  { view: "wiki", icon: BookOpen, title: "Pencarian Wiki", desc: "Indonesia & English — langsung baca", gradient: "from-amber-500 to-orange-600" },
  { view: "film", icon: Clapperboard, title: "Nonton Film", desc: "Streaming + sub ID/EN bisa diatur", gradient: "from-red-500 to-red-700" },
  { view: "ai", icon: Bot, title: "AI Chat", desc: "3 mode + riwayat & tugas latar belakang", gradient: "from-blue-700 to-cyan-600" },
  { view: "music", icon: Music4, title: "Musik", desc: "Cari, populer, preview & download", gradient: "from-red-500 to-rose-600" },
  { view: "downloader", icon: Download, title: "Downloader", desc: "Preview dulu + simpan langsung", gradient: "from-emerald-500 to-teal-600" },
  { view: "email", icon: MailPlus, title: "Email Trial", desc: "Email sementara + auto deteksi OTP", gradient: "from-amber-500 to-orange-600" },
  { view: "am", icon: Zap, title: "AM Active", desc: "Premium Alight Motion (auto email trial)", gradient: "from-cyan-500 to-teal-600", badge: "PRO" },
  { view: "osint", icon: Fingerprint, title: "OSINT", desc: "NIK, IP, nomor, domain, WHOIS + username", gradient: "from-blue-600 to-blue-600" },
  { view: "apk", icon: Package, title: "APK Builder", desc: "HTML/ZIP jadi app Android", gradient: "from-orange-500 to-red-600" },
];

export default function HomeView() {
  const { user, setView, openFilm } = useApp();
  const [data, setData] = useState<HomeData | null>(null);
  const [history, setHistory] = useState<Array<{ id: number; type: "movie" | "tv"; title: string; poster: string | null; at: number }>>([]);

  useEffect(() => {
    queueMicrotask(() => setHistory(getWatchHistory().slice(0, 10)));
    fetch("/api/movies/home")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d?.ok && setData(d))
      .catch(() => {});
  }, []);

  const hour = new Date().getHours();
  const greet = hour < 5 ? "Masih terjaga pada dini hari" : hour < 11 ? "Selamat pagi" : hour < 15 ? "Selamat siang" : hour < 19 ? "Selamat sore" : "Selamat malam";

  return (
    <div className="space-y-7 pb-4">

      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass relative overflow-hidden rounded-3xl p-5 sm:p-7"
      >
        <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-red-500/25 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -left-10 h-40 w-40 rounded-full bg-blue-700/20 blur-3xl" />
        <p className="text-xs font-medium text-muted-foreground">{greet}</p>
        <h2 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">
          Halo, <span className="gradient-text">{user?.username || "Sahabat Fanzz"}</span>
        </h2>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Semua tools favorit lo ada di satu tempat. Mau ngapain hari ini?
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => setView("film")}
            className="flex items-center gap-1.5 rounded-full bg-gradient-to-r from-red-500 to-red-700 px-4 py-2 text-xs font-bold text-white shadow-lg shadow-red-500/25 transition-transform hover:scale-105 active:scale-95"
          >
            <Flame className="h-3.5 w-3.5" /> Nonton Film
          </button>
          <button
            onClick={() => setView("ai")}
            className="flex items-center gap-1.5 rounded-full glass px-4 py-2 text-xs font-bold text-red-300 transition-transform hover:scale-105 active:scale-95"
          >
            <Sparkles className="h-3.5 w-3.5" /> Chat AI
          </button>
        </div>
      </motion.section>

      {/* Status perangkat: HP, baterai real-time, lokasi */}
      <DeviceStatusCard />

      {/* Grid tools */}
      <section>
        <h3 className="mb-3 flex items-center gap-2 text-base font-bold">
          <Zap className="h-4.5 w-4.5 text-red-400" /> Semua Tools
        </h3>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {TOOLS.map((t, i) => (
            <motion.button
              key={t.view}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -4, scale: 1.02 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => setView(t.view)}
              className="group relative overflow-hidden rounded-2xl glass p-4 text-left"
            >
              <div className={`absolute -right-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br ${t.gradient} opacity-20 blur-xl transition-opacity group-hover:opacity-40`} />
              <div className={`relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${t.gradient} text-white shadow-md`}>
                <t.icon className="h-5 w-5" />
              </div>
              <div className="relative mt-2.5 flex items-center gap-1.5">
                <p className="text-sm font-bold">{t.title}</p>
                {t.badge && (
                  <span className={`rounded-full px-1.5 py-px text-[8.5px] font-extrabold tracking-wide ${
                    t.badge === "SOON" ? "bg-amber-500/20 text-amber-300" : "bg-red-500/20 text-red-300"
                  }`}>
                    {t.badge}
                  </span>
                )}
              </div>
              <p className="relative mt-0.5 text-[11px] leading-snug text-muted-foreground clamp-2">{t.desc}</p>
            </motion.button>
          ))}
        </div>
      </section>

      {/* Riwayat nonton */}
      {history.length > 0 && (
        <section>
          <h3 className="mb-3 flex items-center gap-2 text-base font-bold">
            <History className="h-4.5 w-4.5 text-red-400" /> Lanjutin Nonton
          </h3>
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
            {history.map((h, i) => (
              <div key={`${h.id}-${h.at}`} className="w-28 shrink-0">
                <MovieCard
                  index={i}
                  title={h.title}
                  poster={h.poster}
                  type={h.type}
                  onClick={() => openFilm(h.id, h.type)}
                />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Trending */}
      {data && (
        <section>
          <h3 className="mb-3 flex items-center gap-2 text-base font-bold">
            <TrendingUp className="h-4.5 w-4.5 text-red-400" /> Trending Minggu Ini
          </h3>
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
            {data.trending.slice(0, 14).map((m, i) => (
              <div key={m.id} className="w-28 shrink-0">
                <MovieCard
                  index={i}
                  title={m.title}
                  poster={m.poster}
                  rating={m.rating}
                  year={m.year}
                  type={m.type}
                  onClick={() => openFilm(m.id, m.type === "tv" ? "tv" : "movie")}
                />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Top rated */}
      {data && (
        <section>
          <h3 className="mb-3 flex items-center gap-2 text-base font-bold">
            <Star className="h-4.5 w-4.5 text-amber-400" /> Rating Tertinggi
          </h3>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {data.topMovies.slice(0, 6).map((m, i) => (
              <MovieCard
                key={m.id}
                index={i}
                title={m.title}
                poster={m.poster}
                rating={m.rating}
                year={m.year}
                onClick={() => openFilm(m.id, "movie")}
              />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming */}
      {data && (
        <section>
          <h3 className="mb-3 flex items-center gap-2 text-base font-bold">
            <CalendarDays className="h-4.5 w-4.5 text-emerald-400" /> Akan Tayang
          </h3>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {data.upcoming.slice(0, 6).map((m, i) => (
              <MovieCard
                key={m.id}
                index={i}
                title={m.title}
                poster={m.poster}
                rating={m.rating}
                year={m.year}
                onClick={() => openFilm(m.id, "movie")}
              />
            ))}
          </div>
        </section>
      )}

      {!data && (
        <div className="space-y-3">
          <div className="h-5 w-40 rounded shimmer" />
          <div className="no-scrollbar flex gap-3 overflow-hidden">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="w-28 shrink-0 aspect-[2/3] rounded-2xl shimmer" />
            ))}
          </div>
        </div>
      )}

      {/* V2.11 (#24) + UpdSec: footer beranda — tujuan web, hak cipta, himbauan bijak.
          Cap anti-klaim kini STATIS di bagian paling bawah (bukan bubble/pop-up lagi). */}
      <footer className="mt-10 border-t border-[var(--surface-line)] pt-5">
        <div className="space-y-2 text-center">
          <p className="text-[11px] font-bold text-muted-foreground">
            FanzzTools V2 — platform serbaguna: hiburan, produktivitas, kreator gambar, dan pembelajaran.
          </p>
          <p className="mx-auto max-w-md text-[10px] leading-relaxed text-muted-foreground/70">
            Dibuat untuk mempermudah keperluan digital sehari-hari secara gratis dan mandiri.
            Sebagian konten bersumber dari pihak ketiga dan tetap milik pemiliknya masing-masing.
          </p>
          <p className="text-[10px] font-bold text-muted-foreground/80">
            Hak cipta © 2026 By : Fanzz-Dev. — FanzzProject. <span className="text-red-300">Gunakan dengan bijak!</span>
          </p>
          {/* cap anti-klaim — teks statis di paling bawah */}
          <CopyrightBadge />
        </div>
      </footer>
    </div>
  );
}
