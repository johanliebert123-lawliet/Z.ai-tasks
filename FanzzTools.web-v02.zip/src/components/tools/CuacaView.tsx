"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import { useApp } from "@/lib/app-store";
import {
  CloudSun, Search, Loader2, MapPin, Droplets, Wind, Thermometer, Sunrise,
  Sunset, Umbrella, RefreshCw, Navigation, CalendarDays,
} from "lucide-react";

/**
 * Cuaca Live (zuperupdt #17).
 *  - Cuaca REAL-TIME berbasis GPS (tombol "Gunakan GPS Saya") + cari kota manual
 *  - ANIMASI yang cocok dengan kondisi: matahari berputar-bercahaya, awan
 *    bergerak, hujan berguguran, badai kilat, kabut meluber, salju turun
 *  - Suhu sekarang + terasa + kelembapan + angin
 *  - PRAKIRAAN BESOK (juga 5 hari ke depan): min/max, peluang hujan, UV
 * Sumber: Open-Meteo via /api/cuaca — gratis, tanpa API key pengguna.
 */

interface KodeCuaca {
  label: string;
  emoji: string;
  anim: "cerah" | "cerah-berawan" | "berawan" | "kabut" | "hujan" | "hujan-lebat" | "salju" | "badai";
}

/** Peta kode cuaca WMO → label + jenis animasi. */
function kodeCuaca(kode: number, siang: boolean): KodeCuaca {
  if (kode === 0) return { label: siang ? "Cerah" : "Cerah Malam", emoji: siang ? "☀️" : "🌙", anim: "cerah" };
  if (kode === 1) return { label: "Cerah Berawan", emoji: siang ? "🌤️" : "🌙", anim: "cerah-berawan" };
  if (kode === 2) return { label: "Berawan Sebagian", emoji: "⛅", anim: "cerah-berawan" };
  if (kode === 3) return { label: "Berawan", emoji: "☁️", anim: "berawan" };
  if (kode === 45 || kode === 48) return { label: "Berkabut", emoji: "🌫️", anim: "kabut" };
  if (kode >= 51 && kode <= 57) return { label: "Gerimis", emoji: "🌦️", anim: "hujan" };
  if (kode >= 61 && kode <= 67) return { label: "Hujan", emoji: "🌧️", anim: "hujan" };
  if (kode >= 71 && kode <= 77) return { label: "Salju", emoji: "🌨️", anim: "salju" };
  if (kode >= 80 && kode <= 82) return { label: "Hujan Deras", emoji: "🌧️", anim: "hujan-lebat" };
  if (kode >= 85 && kode <= 86) return { label: "Hujan Salju", emoji: "🌨️", anim: "salju" };
  if (kode >= 95) return { label: "Badai Petir", emoji: "⛈️", anim: "badai" };
  return { label: "Tidak Diketahui", emoji: "🌡️", anim: "berawan" };
}

interface DataCuaca {
  lokasi: { lat: number; lon: number; zonaWaktu: string };
  sekarang: { suhu: number; terasa: number; lembap: number; angin: number; hujan: number; kode: number; siang: boolean; waktu: string };
  harian: Array<{ tanggal: string; kode: number; max: number; min: number; hujanProb: number; uv: number; sunrise: string; sunset: string }>;
  besok: { tanggal: string; kode: number; max: number; min: number; hujanProb: number; uv: number; sunrise: string; sunset: string } | null;
}

const HARI = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

/* ================= ANIMASI CUACA ================= */
function Awan({ x, y, skala, durasi, gelap }: { x: string; y: string; skala: number; durasi: number; gelap?: boolean }) {
  return (
    <motion.div
      className="absolute"
      style={{ left: x, top: y }}
      animate={{ x: [-30, 30, -30] }}
      transition={{ duration: durasi, repeat: Infinity, ease: "easeInOut" }}
    >
      <div className="relative" style={{ transform: `scale(${skala})` }}>
        <div className={`h-10 w-24 rounded-full ${gelap ? "bg-slate-500/80" : "bg-white/85"}`} />
        <div className={`absolute -top-6 left-5 h-12 w-12 rounded-full ${gelap ? "bg-slate-500/80" : "bg-white/85"}`} />
        <div className={`absolute -top-3 left-14 h-9 w-9 rounded-full ${gelap ? "bg-slate-500/80" : "bg-white/85"}`} />
      </div>
    </motion.div>
  );
}
function Matahari() {
  return (
    <motion.div
      className="absolute left-1/2 top-6 -translate-x-1/2"
      animate={{ rotate: 360 }}
      transition={{ duration: 26, repeat: Infinity, ease: "linear" }}
    >
      <div className="relative h-16 w-16">
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-amber-300 to-orange-500 shadow-[0_0_50px_18px_rgba(251,191,36,0.55)]" />
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="absolute left-1/2 top-1/2 h-14 w-1.5 origin-bottom rounded-full bg-amber-300/80"
            style={{ transform: `rotate(${i * 45}deg) translateY(-40px)` }}
          />
        ))}
      </div>
    </motion.div>
  );
}
function Bulan() {
  return (
    <motion.div className="absolute left-1/2 top-7 -translate-x-1/2" animate={{ y: [0, -6, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}>
      <div className="h-14 w-14 rounded-full bg-gradient-to-br from-slate-200 to-slate-400 shadow-[0_0_40px_12px_rgba(226,232,240,0.35)]" />
    </motion.div>
  );
}
function Tetesan({ warna, jumlah, lebat }: { warna: string; jumlah: number; lebat?: boolean }) {
  return (
    <>
      {Array.from({ length: jumlah }).map((_, i) => (
        <motion.div
          key={i}
          className={`absolute rounded-full ${warna}`}
          style={{ left: `${(i * 97) % 100}%`, top: "-8%", width: lebat ? 3 : 2.5, height: lebat ? 18 : 12 }}
          animate={{ y: ["-10%", "420%"], opacity: [0, 1, 1, 0] }}
          transition={{ duration: lebat ? 0.75 : 1.15, repeat: Infinity, delay: (i * 0.13) % 1.1, ease: "linear" }}
        />
      ))}
    </>
  );
}
function Salju() {
  return (
    <>
      {Array.from({ length: 18 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute h-2 w-2 rounded-full bg-white/90"
          style={{ left: `${(i * 83) % 100}%`, top: "-6%" }}
          animate={{ y: ["-8%", "400%"], x: [0, 14, -10, 0], opacity: [0, 1, 1, 0] }}
          transition={{ duration: 3.4, repeat: Infinity, delay: (i * 0.21) % 2.4, ease: "linear" }}
        />
      ))}
    </>
  );
}
function Kilat() {
  return (
    <motion.div
      className="absolute left-1/2 top-8 -translate-x-1/2"
      animate={{ opacity: [0, 0, 1, 0, 0.6, 0] }}
      transition={{ duration: 2.4, repeat: Infinity, times: [0, 0.35, 0.4, 0.5, 0.55, 1] }}
    >
      <svg width="44" height="64" viewBox="0 0 44 64" fill="none">
        <path d="M24 2 L8 34 H20 L14 62 L38 26 H24 L30 2 Z" fill="#FDE047" stroke="#FACC15" strokeWidth="2" />
      </svg>
    </motion.div>
  );
}

/** Panel animasi sesuai kondisi cuaca. */
function AnimasiCuaca({ anim, siang }: { anim: KodeCuaca["anim"]; siang: boolean }) {
  return (
    <div className="relative h-40 w-full overflow-hidden rounded-2xl bg-gradient-to-b from-sky-500/25 via-sky-400/10 to-transparent">
      {/* latar langit */}
      {anim === "cerah" && (siang ? <Matahari /> : <Bulan />)}
      {anim === "cerah-berawan" && (
        <>
          {siang ? <Matahari /> : <Bulan />}
          <Awan x="8%" y="52%" skala={0.9} durasi={9} />
        </>
      )}
      {anim === "berawan" && (
        <>
          <Awan x="6%" y="18%" skala={1.05} durasi={11} gelap />
          <Awan x="52%" y="46%" skala={0.8} durasi={8} />
        </>
      )}
      {anim === "kabut" && (
        <>
          {[0, 1, 2].map((i) => (
            <motion.div
              key={i}
              className="absolute left-0 h-8 w-full rounded-full bg-slate-300/25 blur-md"
              style={{ top: `${28 + i * 22}%` }}
              animate={{ x: ["-12%", "10%", "-12%"] }}
              transition={{ duration: 7 + i * 2.4, repeat: Infinity, ease: "easeInOut" }}
            />
          ))}
        </>
      )}
      {(anim === "hujan" || anim === "hujan-lebat") && (
        <>
          <Awan x="14%" y="10%" skala={1.1} durasi={8} gelap />
          {anim === "hujan-lebat" && <Awan x="50%" y="4%" skala={0.9} durasi={7} gelap />}
          <Tetesan warna="bg-sky-300/90" jumlah={anim === "hujan-lebat" ? 34 : 20} lebat={anim === "hujan-lebat"} />
        </>
      )}
      {anim === "salju" && (
        <>
          <Awan x="18%" y="10%" skala={1.05} durasi={10} />
          <Salju />
        </>
      )}
      {anim === "badai" && (
        <>
          <Awan x="10%" y="6%" skala={1.2} durasi={7} gelap />
          <Awan x="55%" y="2%" skala={0.85} durasi={6} gelap />
          <Kilat />
          <Tetesan warna="bg-sky-200/80" jumlah={30} lebat />
        </>
      )}
    </div>
  );
}

export default function CuacaView() {
  const [query, setQuery] = useState("");
  const [kotaHasil, setKotaHasil] = useState<Array<{ nama: string; region: string; negara: string; lat: number; lon: number }> | null>(null);
  const [mencariKota, setMencariKota] = useState(false);
  const [data, setData] = useState<DataCuaca | null>(null);
  const [loading, setLoading] = useState(false);
  const [labelLokasi, setLabelLokasi] = useState("");
  const [gpsBusy, setGpsBusy] = useState(false);
  const { toast } = useToast();
  const { geo } = useApp();

  const muat = useCallback(async (lat: number, lon: number, label: string) => {
    setLoading(true);
    try {
      const r = await fetch(`/api/cuaca?lat=${lat}&lon=${lon}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memuat cuaca");
      setData(d as DataCuaca);
      setLabelLokasi(label);
      pushHistory("cuaca", { id: `${lat.toFixed(2)},${lon.toFixed(2)}`, title: `Cuaca ${label}`, subtitle: `${d.sekarang.suhu}°C • ${kodeCuaca(d.sekarang.kode, d.sekarang.siang).label}` });
    } catch (e) {
      toast({ title: "Gagal memuat cuaca", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  /* pakai geo global (sudah diizinkan pengguna) saat pertama buka */
  useEffect(() => {
    if (geo && geo.mode !== "loading") {
      void muat(geo.lat, geo.lon, geo.display || "Lokasi GPS");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pakaiGps = () => {
    if (!navigator.geolocation) {
      toast({ title: "Perangkat tidak mendukung GPS", variant: "destructive" });
      return;
    }
    setGpsBusy(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGpsBusy(false);
        void muat(pos.coords.latitude, pos.coords.longitude, `Lokasi GPS (±${Math.round(pos.coords.accuracy || 0)} m)`);
      },
      (err) => {
        setGpsBusy(false);
        toast({
          title: "GPS gagal",
          description: err.code === err.PERMISSION_DENIED
            ? "Izin lokasi ditolak — aktifkan izin lokasi lalu tekan lagi, atau cari kota manual."
            : "Posisi belum tersedia — coba lagi atau cari kota manual.",
          variant: "destructive",
        });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 },
    );
  };

  const cariKota = async () => {
    const q = query.trim();
    if (!q) return;
    setMencariKota(true);
    setKotaHasil(null);
    try {
      const r = await fetch(`/api/cuaca?q=${encodeURIComponent(q)}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      if (!d.hasil?.length) {
        toast({ title: "Kota tidak ketemu", description: "Coba nama kota lain (mis. Jakarta, Bandung, Medan)." });
      }
      setKotaHasil(d.hasil || []);
    } catch {
      toast({ title: "Pencarian gagal", variant: "destructive" });
    } finally {
      setMencariKota(false);
    }
  };

  const kondisi = useMemo(() => data ? kodeCuaca(data.sekarang.kode, data.sekarang.siang) : null, [data]);

  return (
    <div>
      <ToolHeader icon={<CloudSun className="h-5.5 w-5.5" />} title="Cuaca Live" subtitle="GPS real-time • animasi kondisi • prakiraan besok" accent="cyan" />

      {/* input lokasi */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && cariKota()}
            placeholder="Cari kota (Jakarta, Bandung, Tokyo…)"
            className="rounded-xl pl-10"
          />
        </div>
        <button onClick={pakaiGps} disabled={gpsBusy} className="flex h-10 shrink-0 items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 px-4 text-xs font-extrabold text-white disabled:opacity-60">
          {gpsBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Navigation className="h-4 w-4" />} GPS Saya
        </button>
      </div>

      {/* hasil pencarian kota */}
      {kotaHasil && kotaHasil.length > 0 && (
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {kotaHasil.map((k, i) => (
            <button
              key={`${k.nama}-${i}`}
              onClick={() => { setKotaHasil(null); void muat(k.lat, k.lon, `${k.nama}${k.region ? ", " + k.region : ""}`); }}
              className="glass flex items-center gap-2 rounded-xl p-3 text-left transition-transform active:scale-95"
            >
              <MapPin className="h-4 w-4 shrink-0 text-cyan-400" />
              <div className="min-w-0">
                <p className="truncate text-xs font-extrabold">{k.nama}</p>
                <p className="truncate text-[10px] text-muted-foreground">{[k.region, k.negara].filter(Boolean).join(", ")}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {loading && (
        <div className="mt-4 space-y-3">
          <div className="h-40 rounded-2xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      )}

      {!data && !loading && (
        <div className="mt-4">
          <EmptyState
            icon={<CloudSun className="h-10 w-10" />}
            title="Cek cuaca lokasi kamu"
            desc="Tekan GPS Saya untuk cuaca real-time di posisimu sekarang, atau cari nama kota mana pun. Lengkap dengan animasi kondisi, suhu, dan prakiraan besok."
          />
        </div>
      )}

      {data && kondisi && !loading && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-4">
          {/* panel utama + animasi */}
          <div className="glass overflow-hidden rounded-2xl p-4">
            <AnimasiCuaca anim={kondisi.anim} siang={data.sekarang.siang} />
            <div className="mt-3 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="flex items-center gap-1.5 truncate text-xs font-extrabold">
                  <MapPin className="h-3.5 w-3.5 text-cyan-400" /> {labelLokasi || "Lokasi"}
                </p>
                <p className="mt-1 text-5xl font-black tabular-nums">
                  {data.sekarang.suhu}°<span className="text-lg font-bold text-muted-foreground">C</span>
                </p>
                <p className="text-sm font-bold text-cyan-300">{kondisi.emoji} {kondisi.label}</p>
              </div>
              <button onClick={() => void muat(data.lokasi.lat, data.lokasi.lon, labelLokasi)} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-secondary text-muted-foreground active:scale-90" title="Segarkan">
                <RefreshCw className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
              {[
                { icon: Thermometer, label: "Terasa", nilai: `${data.sekarang.terasa}°C` },
                { icon: Droplets, label: "Kelembapan", nilai: `${data.sekarang.lembap}%` },
                { icon: Wind, label: "Angin", nilai: `${data.sekarang.angin} km/j` },
                { icon: Umbrella, label: "Hujan", nilai: `${data.sekarang.hujan} mm` },
              ].map((s) => (
                <div key={s.label} className="rounded-xl bg-secondary/50 p-2.5 text-center">
                  <s.icon className="mx-auto h-4 w-4 text-cyan-400" />
                  <p className="mt-1 text-[9px] font-black uppercase tracking-wide text-muted-foreground">{s.label}</p>
                  <p className="text-xs font-extrabold tabular-nums">{s.nilai}</p>
                </div>
              ))}
            </div>
          </div>

          {/* prakiraan BESOK */}
          {data.besok && (
            <div className="glass rounded-2xl p-4">
              <p className="mb-3 flex items-center gap-1.5 text-sm font-extrabold">
                <CalendarDays className="h-4 w-4 text-cyan-400" /> Prakiraan Besok
              </p>
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-4xl">{kodeCuaca(data.besok.kode, true).emoji}</span>
                  <div>
                    <p className="text-xs font-extrabold text-cyan-300">{kodeCuaca(data.besok.kode, true).label}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {new Date(data.besok.tanggal).toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "short" })}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black tabular-nums">
                    {data.besok.max}° <span className="text-[11px] font-bold text-muted-foreground">/ {data.besok.min}°</span>
                  </p>
                  <p className="text-[10px] font-bold text-muted-foreground">maks / min</p>
                </div>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2">
                <div className="rounded-xl bg-secondary/50 p-2.5 text-center">
                  <Umbrella className="mx-auto h-4 w-4 text-cyan-400" />
                  <p className="mt-1 text-[9px] font-black uppercase text-muted-foreground">Peluang Hujan</p>
                  <p className="text-xs font-extrabold tabular-nums">{data.besok.hujanProb}%</p>
                </div>
                <div className="rounded-xl bg-secondary/50 p-2.5 text-center">
                  <Sunrise className="mx-auto h-4 w-4 text-amber-400" />
                  <p className="mt-1 text-[9px] font-black uppercase text-muted-foreground">Matahari Terbit</p>
                  <p className="text-xs font-extrabold tabular-nums">{data.besok.sunrise.slice(11, 16)}</p>
                </div>
                <div className="rounded-xl bg-secondary/50 p-2.5 text-center">
                  <Sunset className="mx-auto h-4 w-4 text-orange-400" />
                  <p className="mt-1 text-[9px] font-black uppercase text-muted-foreground">Terbenam</p>
                  <p className="text-xs font-extrabold tabular-nums">{data.besok.sunset.slice(11, 16)}</p>
                </div>
              </div>
            </div>
          )}

          {/* N hari ke depan (6 dari Open-Meteo; 3 bila pakai cadangan wttr.in) */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-3 text-sm font-extrabold">{data.harian.length} Hari Ke Depan</p>
            <div className="space-y-1.5">
              {data.harian.map((h, i) => {
                const kc = kodeCuaca(h.kode, true);
                const d = new Date(h.tanggal);
                return (
                  <div key={h.tanggal} className={`flex items-center gap-3 rounded-xl px-3 py-2 ${i === 0 ? "bg-cyan-500/10" : "bg-secondary/40"}`}>
                    <span className="w-9 text-[10px] font-black uppercase text-muted-foreground">{i === 0 ? "Hari ini" : HARI[d.getDay()]}</span>
                    <span className="text-xl">{kc.emoji}</span>
                    <span className="min-w-0 flex-1 truncate text-[11px] font-bold text-muted-foreground">{kc.label}</span>
                    <span className="text-[10px] font-bold text-sky-300">{h.hujanProb}%</span>
                    <span className="text-xs font-black tabular-nums">
                      {h.max}° <span className="font-bold text-muted-foreground">{h.min}°</span>
                    </span>
                  </div>
                );
              })}
            </div>
            <p className="mt-3 text-[9.5px] leading-relaxed text-muted-foreground">
              Sumber data: Open-Meteo (gratis, tanpa API key) — di-cache 10 menit di server FanzzTools. Animasi menyesuaikan kondisi: cerah, berawan, hujan, badai, salju, hingga kabut.
            </p>
          </div>
        </motion.div>
      )}

      <AnimatePresence>{mencariKota && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Mencari kota…
        </motion.div>
      )}</AnimatePresence>
    </div>
  );
}
