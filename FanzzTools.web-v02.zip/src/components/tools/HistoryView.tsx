"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import {
  HISTORY_TOOLS, getHistory, removeHistory, clearHistory, clearAllHistory, fmtHistoryTime,
  type HistoryTool, type HistoryEntry,
} from "@/lib/history";
import { useApp, type ViewId } from "@/lib/app-store";
import { Button } from "@/components/ui/button";
import { History, Trash2, ExternalLink, Clock3, Sparkles } from "lucide-react";

/** riwayat tool → view tujuan saat entri diklik (bila relevan) */
const TOOL_TO_VIEW: Partial<Record<HistoryTool, ViewId>> = {
  film: "film",
  anime: "anime",
  manhwa: "manhwa",
  komik: "komik",
  donghua: "donghua",
  dracin: "dracin",
  nekopoi: "nekopoi",
  books: "books",
  music: "music",
  downloader: "downloader",
  lyrics: "lyrics",
  nokos: "gacha",
};

export default function HistoryView() {
  const [active, setActive] = useState<HistoryTool>("film");
  const [entries, setEntries] = useState<HistoryEntry[]>([]);
  const setView = useApp((s) => s.setView);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setEntries(getHistory(active)), 0);
    return () => clearTimeout(t);
  }, [active, tick]);

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<History className="h-5 w-5" />}
        title="Riwayat"
        desc="Semua riwayat aktivitas Anda, terpisah rapi per tools — film, anime, manhwa, musik, unduhan, dan lainnya."
      />

      {/* pilih tools */}
      <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
        {HISTORY_TOOLS.map((t) => {
          const count = getHistory(t.id).length;
          return (
            <button
              key={t.id}
              onClick={() => setActive(t.id)}
              className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                active === t.id
                  ? "bg-gradient-to-r from-red-500 to-red-700 text-white"
                  : "glass text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label}
              {count > 0 && (
                <span className={`rounded-full px-1.5 py-px text-[8px] font-extrabold ${active === t.id ? "bg-white/20" : "bg-secondary"}`}>
                  {count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* toolbar */}
      <div className="flex items-center justify-between gap-2">
        <p className="flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
          <Clock3 className="h-3.5 w-3.5" /> {entries.length} entri riwayat {HISTORY_TOOLS.find((t) => t.id === active)?.label}
        </p>
        <div className="flex gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              clearHistory(active);
              setTick((t) => t + 1);
            }}
            disabled={!entries.length}
            className="rounded-xl px-3 text-[11px]"
          >
            <Trash2 className="mr-1 h-3.5 w-3.5" /> Kosongkan tab ini
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              clearAllHistory();
              setTick((t) => t + 1);
            }}
            disabled={!entries.length}
            className="rounded-xl px-3 text-[11px] text-red-400 hover:text-red-300"
          >
            <Sparkles className="mr-1 h-3.5 w-3.5" /> Hapus semua riwayat
          </Button>
        </div>
      </div>

      {/* daftar entri */}
      {entries.length === 0 ? (
        <EmptyState
          icon={<History className="h-8 w-8" />}
          title={`Belum ada riwayat ${HISTORY_TOOLS.find((t) => t.id === active)?.label}`}
          desc="Aktivitas Anda di tools ini akan tercatat otomatis di sini."
        />
      ) : (
        <div className="space-y-2">
          {entries.map((e, i) => (
            <motion.div
              key={`${e.id}-${e.at}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.25) }}
              className="flex items-center gap-3 rounded-2xl glass p-2.5"
            >
              {/* poster/thumbnail */}
              <div className="h-12 w-9 shrink-0 overflow-hidden rounded-lg bg-secondary">
                {e.poster ? (
                  <img src={e.poster} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                    <History className="h-4 w-4" />
                  </div>
                )}
              </div>

              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-bold">{e.title}</p>
                {e.subtitle ? <p className="truncate text-[10px] text-muted-foreground">{e.subtitle}</p> : null}
                <p className="mt-0.5 text-[9px] text-muted-foreground/70">{fmtHistoryTime(e.at)}</p>
              </div>

              <div className="flex shrink-0 items-center gap-1">
                {e.url && /^https?:\/\//.test(e.url) && (
                  <a
                    href={e.url}
                    target="_blank"
                    rel="noopener noreferrer nofollow"
                    className="flex h-8 w-8 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                    aria-label="Buka tautan"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                )}
                {TOOL_TO_VIEW[active] && (
                  <button
                    onClick={() => setView(TOOL_TO_VIEW[active]!)}
                    className="rounded-xl bg-red-500/15 px-2.5 py-1.5 text-[10px] font-bold text-red-300 transition-transform active:scale-95"
                  >
                    Buka tools
                  </button>
                )}
                <button
                  onClick={() => {
                    removeHistory(active, e.id);
                    setTick((t) => t + 1);
                  }}
                  className="flex h-8 w-8 items-center justify-center rounded-xl text-muted-foreground transition-colors hover:bg-red-500/15 hover:text-red-400"
                  aria-label="Hapus entri"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
