"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useApp } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  KOTA_LIST, SHOLAT_WAJIB, SHOLAT_SUNNAH, SURAH_SARAN, BACAAN_SHOLAT, AGAMA_LIST, arahKiblat,
} from "@/lib/ibadah-data";
import {
  Moon, MapPin, Navigation, Loader2, Copy, Check, Compass, BookOpen, Sparkles,
  ChevronDown, ChevronUp, Church, Bot, Clock, Volume2,
} from "lucide-react";

/**
 * Ruang Ibadah (V2 Modern-UpdSec) — jadwal sholat + kiblat + bacaan sholat
 * lengkap (Arab/Latin/Arti, bisa disalin) + ibadah semua agama.
 * Qur'an digital ada di tools terpisah; Debat filosofis juga terpisah.
 */

interface PrayerData {
  timings: {
    subuh: string; terbit: string; dzuhur: string; ashar: string;
    maghrib: string; isya: string; imsak: string; tengahMalam: string;
  };
  date: {
    gregorian: string | null; readable: string | null;
    hijri: { date: string; day: string; month: string; monthAr: string; year: string } | null;
  };
  meta: { timezone: string | null; method: string };
}

const NAMA_WAKTU = [
  { id: "subuh", label: "Subuh", arab: "الفجر" },
  { id: "terbit", label: "Terbit", arab: "الشروق" },
  { id: "dzuhur", label: "Zuhur", arab: "الظهر" },
  { id: "ashar", label: "Ashar", arab: "العصر" },
  { id: "maghrib", label: "Maghrib", arab: "المغرب" },
  { id: "isya", label: "Isya", arab: "العشاء" },
] as const;

export default function IbadahView() {
  const { geo } = useApp();
  const { toast } = useToast();
  const [tab, setTab] = useState<"sholat" | "bacaan" | "agama">("sholat");
  const [kotaIdx, setKotaIdx] = useState<number>(0);
  const [pakaiGps, setPakaiGps] = useState(false);
  const [prayer, setPrayer] = useState<PrayerData | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [openBacaan, setOpenBacaan] = useState<number>(0);
  const [agamaIdx, setAgamaIdx] = useState(0);
  const [aliranOpen, setAliranOpen] = useState(false);

  // kompas kiblat
  const [heading, setHeading] = useState<number | null>(null);
  const [kiblatDeg, setKiblatDeg] = useState<number | null>(null);
  /** zuperupdt #13 — GPS langsung hasil tombol (bukan menunggu prompt global):
   *  keluhan "GPS sudah nyala tapi kiblat tidak bekerja" karena view hanya
   *  membaca geo GLOBAL (bisa null kalau prompt global sempat ditolak/
   *  di-skip). Sekarang tombol "Aktifkan Kompas + GPS" mengambil posisi
   *  SEGAR sendiri dan hasilnya dipakai sebagai sumber utama. */
  const [gpsOverride, setGpsOverride] = useState<{ lat: number; lon: number; label: string } | null>(null);
  const [gpsBusy, setGpsBusy] = useState(false);
  /** zuperupdt #13 — sensor hanya dipasang SETELAH gestur pengguna:
   *  sebagian browser Android (WebView/privacy setting) memblokir event
   *  sensor yang dipasang di luar konteks gestur — dulu listener dipasang
   *  di mount → "GPS nyala tapi kompas diam". */
  const [sensorOn, setSensorOn] = useState(false);

  const koordinat = useMemo(() => {
    // prioritas: hasil GPS segar dari tombol → geo global → kota pilihan
    if (gpsOverride) return gpsOverride;
    if (pakaiGps && geo && geo.mode !== "loading") return { lat: geo.lat, lon: geo.lon, label: geo.display || "Lokasi GPS" };
    const k = KOTA_LIST[kotaIdx];
    return { lat: k.lat, lon: k.lon, label: k.nama };
  }, [pakaiGps, geo, kotaIdx, gpsOverride]);

  const muatJadwal = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/ibadah/prayer?lat=${koordinat.lat}&lon=${koordinat.lon}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memuat jadwal");
      setPrayer(d as PrayerData);
      setKiblatDeg(arahKiblat(koordinat.lat, koordinat.lon));
    } catch (e) {
      toast({ title: "Gagal memuat jadwal sholat", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [koordinat.lat, koordinat.lon, toast]);

  useEffect(() => {
    void muatJadwal();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [koordinat.lat, koordinat.lon]);

  // kompas perangkat (untuk kiblat real-time) — PERBAIKAN #7:
  // dulu hanya `deviceorientation` (alpha RELATIF — bukan utara sejati di Android)
  // tanpa kompensasi rotasi layar → jarum salah arah / diam padahal browser support.
  // Sekarang: `deviceorientationabsolute` (Android Chrome, utara sejati) +
  // `deviceorientation` (fallback iOS webkitCompassHeading / e.absolute) +
  // kompensasi sudut rotasi layar + smoothing jitter.
  const [sensorMode, setSensorMode] = useState<"absolute" | "relative" | "none">("none");
  const smoothRef = useRef<number | null>(null);

  useEffect(() => {
    if (!sensorOn) return; // zuperupdt #13: pasang sensor HANYA setelah gestur
    let gotAbsolute = false;

    const sudutLayar = (): number => {
      try {
        return (screen.orientation?.angle ?? (window as unknown as { orientation?: number }).orientation ?? 0) || 0;
      } catch {
        return 0;
      }
    };

    // smoothing sudut melingkar (hindari lompatan 359→0)
    const halus = (target: number): number => {
      const prev = smoothRef.current;
      if (prev == null || !Number.isFinite(prev)) {
        smoothRef.current = target;
        return target;
      }
      let delta = ((target - prev + 540) % 360) - 180;
      const next = prev + delta * 0.25; // low-pass 25%
      smoothRef.current = next;
      return (next + 360) % 360;
    };

    const handler = (e: DeviceOrientationEvent & { webkitCompassHeading?: number; absolute?: boolean }) => {
      // iOS Safari: webkitCompassHeading = utara sejati (magnetic) langsung
      if (typeof e.webkitCompassHeading === "number" && Number.isFinite(e.webkitCompassHeading)) {
        gotAbsolute = true;
        setSensorMode("absolute");
        setHeading(halus((e.webkitCompassHeading - sudutLayar() + 360) % 360));
        return;
      }
      if (e.alpha == null || !Number.isFinite(e.alpha)) return;
      const base = (360 - ((e.alpha % 360) + 360) % 360) % 360; // alpha → heading dari utara
      if (e.absolute === true || e.type === "deviceorientationabsolute") {
        gotAbsolute = true;
        setSensorMode("absolute");
        setHeading(halus((base - sudutLayar() + 360) % 360));
      } else if (!gotAbsolute) {
        // sensor relatif — jarum bergerak tapi acuan bukan utara sejati
        setSensorMode("relative");
        setHeading(halus((base - sudutLayar() + 360) % 360));
      }
    };

    // deteksi dukungan sensor (untuk pesan status yang jujur)
    const cekSensor = setTimeout(() => {
      setSensorMode((m) => (m === "none" ? "none" : m));
    }, 1500);

    window.addEventListener("deviceorientationabsolute", handler as EventListener, true);
    window.addEventListener("deviceorientation", handler as EventListener, true);
    const onRot = () => { smoothRef.current = null; };
    window.addEventListener("orientationchange", onRot);
    return () => {
      clearTimeout(cekSensor);
      window.removeEventListener("deviceorientationabsolute", handler as EventListener, true);
      window.removeEventListener("deviceorientation", handler as EventListener, true);
      window.removeEventListener("orientationchange", onRot);
    };
  }, [sensorOn]);

  /** zuperupdt #13: GPS segar langsung dari tombol — high accuracy + timeout
   *  jelas. Hasil dipakai koordinat utama kiblat & jadwal (override). */
  const ambilGpsSegar = () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      toast({ title: "Perangkat tidak mendukung GPS", description: "Pilih kota terdekat secara manual di atas.", variant: "destructive" });
      return;
    }
    setGpsBusy(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude;
        const lon = pos.coords.longitude;
        setGpsOverride({ lat, lon, label: `GPS segar (±${Math.round(pos.coords.accuracy || 0)} m)` });
        setKiblatDeg(arahKiblat(lat, lon));
        setGpsBusy(false);
        toast({ title: "GPS terkunci 📍", description: `Posisi segar dipakai: ±${Math.round(pos.coords.accuracy || 0)} meter akurasi.` });
      },
      (err) => {
        setGpsBusy(false);
        const pesan =
          err.code === err.PERMISSION_DENIED
            ? "Izin lokasi ditolak — aktifkan izin lokasi untuk browser ini di pengaturan, lalu tekan tombol lagi."
            : err.code === err.POSITION_UNAVAILABLE
              ? "Posisi belum tersedia — keluar ke ruang terbuka lalu coba lagi."
              : "Waktu tunggu GPS habis — coba lagi di area dengan sinyal lebih baik.";
        toast({ title: "GPS gagal", description: pesan, variant: "destructive" });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 30000 },
    );
  };

  const aktifkanKompas = async () => {
    // zuperupdt #13: SATU tombol melakukan 3 hal dalam SATU gestur pengguna:
    //  (1) izin sensor iOS (kalau diminta), (2) pasang listener sensor —
    //  dipasang DALAM konteks gestur supaya browser Android tidak blokir,
    //  (3) ambil posisi GPS segar untuk arah kiblat yang akurat.
    type IOSDeviceOrientation = { requestPermission?: () => Promise<string> };
    const dop = (typeof DeviceOrientationEvent !== "undefined" ? DeviceOrientationEvent : null) as (typeof DeviceOrientationEvent & IOSDeviceOrientation) | null;
    if (dop && typeof dop.requestPermission === "function") {
      try {
        const p = await dop.requestPermission();
        if (p !== "granted") {
          toast({ title: "Izin kompas ditolak", description: "Arah kiblat tetap ditampilkan dalam bentuk derajat.", variant: "destructive" });
          return;
        }
      } catch {
        /* lanjut */
      }
    }
    setSensorOn(true); // pasang listener sensor dalam konteks gestur ini
    ambilGpsSegar(); // posisi segar — bukan menunggu geo global
    toast({
      title: "Kompas & GPS diaktifkan",
      description:
        sensorMode === "absolute"
          ? "Sensor kompas absolut aktif (utara sejati) — arahkan ponsel ke atas, jarum mengikuti arah kiblat."
          : sensorMode === "relative"
            ? "Sensor terdeteksi tapi bersifat RELATIF — kalibrasi dengan pola angka-8 beberapa kali agar acuan ke utara sejati."
            : "Sensor sedang diaktifkan (dalam gestur ini). Bila jarum tidak bergerak 2–3 detik, gerakkan ponsel pelan — derajat kiblat tetap tertera.",
    });
  };

  const salin = (teks: string, id: string) => {
    try {
      navigator.clipboard.writeText(teks);
      setCopied(id);
      setTimeout(() => setCopied(null), 1600);
      toast({ title: "Bacaan tersalin!" });
    } catch {
      toast({ title: "Gagal menyalin", variant: "destructive" });
    }
  };

  // sholat berikutnya (hitung dari jam sekarang)
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const nextPrayer = useMemo(() => {
    if (!prayer) return null;
    const nowMin = now.getHours() * 60 + now.getMinutes();
    const parse = (s: string) => {
      const m = /^(\d{1,2}):(\d{2})/.exec(s || "");
      return m ? Number(m[1]) * 60 + Number(m[2]) : null;
    };
    for (const w of NAMA_WAKTU) {
      if (w.id === "terbit") continue;
      const t = parse(prayer.timings[w.id]);
      if (t != null && t > nowMin) {
        const selisih = t - nowMin;
        return { nama: w.label, jam: prayer.timings[w.id], dalam: `${Math.floor(selisih / 60)}j ${selisih % 60}m` };
      }
    }
    return { nama: "Subuh", jam: prayer.timings.subuh, dalam: "besok" };
  }, [prayer, now]);

  const agama = AGAMA_LIST[agamaIdx];

  return (
    <div>
      <ToolHeader icon={<Moon className="h-5.5 w-5.5" />} title="Ruang Ibadah" subtitle="Jadwal sholat • kiblat • bacaan lengkap • semua agama" accent="emerald" />

      {/* tab utama */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {([
          { id: "sholat", label: "Jadwal Sholat & Kiblat" },
          { id: "bacaan", label: "Bacaan & Panduan" },
          { id: "agama", label: "Ibadah Semua Agama" },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`shrink-0 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
              tab === t.id ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ================= JADWAL SHOLAT + KIBLAT ================= */}
      {tab === "sholat" && (
        <div className="mt-4 space-y-4">
          {/* pilih lokasi */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
              <MapPin className="h-3.5 w-3.5 text-emerald-400" /> Lokasi — jadwal mengikuti Kemenag RI
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setPakaiGps((v) => !v)}
                className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-[11px] font-bold transition ${
                  pakaiGps ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                <Navigation className="h-3.5 w-3.5" /> GPS saya
              </button>
              {!pakaiGps && (
                <select
                  value={kotaIdx}
                  onChange={(e) => setKotaIdx(Number(e.target.value))}
                  className="flex-1 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs font-bold outline-none"
                >
                  {KOTA_LIST.map((k, i) => (
                    <option key={k.nama} value={i}>{k.nama}</option>
                  ))}
                </select>
              )}
              {pakaiGps && <span className="flex items-center text-[11px] font-bold text-emerald-300">{koordinat.label}</span>}
            </div>
          </div>

          {/* loading */}
          {loading && <div className="h-40 rounded-2xl shimmer" />}

          {/* kartu jadwal */}
          {!loading && prayer && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-[11px] font-bold text-muted-foreground">{koordinat.label} • {prayer.meta.method}</p>
                  {prayer.date.hijri && (
                    <p className="text-xs font-extrabold text-emerald-300">
                      {prayer.date.hijri.day} {prayer.date.hijri.month} {prayer.date.hijri.year} H
                    </p>
                  )}
                </div>
                {nextPrayer && (
                  <div className="rounded-xl bg-emerald-500/10 px-3 py-2 text-right">
                    <p className="text-[9px] font-bold text-muted-foreground">Berikutnya</p>
                    <p className="text-xs font-extrabold text-emerald-300">{nextPrayer.nama} · {nextPrayer.jam}</p>
                    <p className="text-[9px] font-bold text-emerald-400/80">dalam {nextPrayer.dalam}</p>
                  </div>
                )}
              </div>

              <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
                {NAMA_WAKTU.map((w) => (
                  <div
                    key={w.id}
                    className={`rounded-xl p-2.5 text-center ${
                      nextPrayer?.nama === w.label ? "bg-gradient-to-b from-emerald-500/25 to-teal-600/15 ring-1 ring-emerald-400/40" : "bg-secondary/50"
                    }`}
                  >
                    <p className="text-[9px] font-bold text-muted-foreground">{w.label}</p>
                    <p className="mt-0.5 text-sm font-extrabold tabular-nums">{prayer.timings[w.id]}</p>
                    <p className="text-[11px] leading-none text-emerald-300/70" dir="rtl">{w.arab}</p>
                  </div>
                ))}
              </div>
              <p className="mt-2.5 text-center text-[10px] text-muted-foreground">
                Imsak {prayer.timings.imsak} · Zona {prayer.meta.timezone || "lokal"}
              </p>
            </motion.div>
          )}

          {/* kompas kiblat */}
          {!loading && (
            <div className="glass rounded-2xl p-5">
              <div className="mb-3 flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-sm font-bold">
                  <Compass className="h-4 w-4 text-emerald-400" /> Arah Kiblat
                </p>
                <button onClick={aktifkanKompas} disabled={gpsBusy} className="flex items-center gap-1.5 rounded-xl bg-emerald-500/15 px-3 py-2 text-[10px] font-bold text-emerald-300 disabled:opacity-60">
                  <Compass className={`h-3.5 w-3.5 ${gpsBusy ? "animate-spin" : ""}`} /> {gpsBusy ? "Mencari GPS…" : sensorOn ? "Segarkan GPS" : "Aktifkan Kompas + GPS"}
                </button>
              </div>

              <div className="flex flex-col items-center">
                {/* papan kompas */}
                <div className="relative h-56 w-56">
                  {/* lingkaran kompas */}
                  <div className="absolute inset-0 rounded-full border-2 border-[var(--surface-line)] bg-black/30">
                    {["U", "TL", "T", "TG", "S", "BD", "B", "BL"].map((d, i) => {
                      const deg = i * 45;
                      const rad = ((deg - 90) * Math.PI) / 180;
                      const x = 50 + 42 * Math.cos(rad);
                      const y = 50 + 42 * Math.sin(rad);
                      return (
                        <span
                          key={d}
                          className={`absolute -translate-x-1/2 -translate-y-1/2 text-[11px] font-black ${d === "U" ? "text-rose-400" : "text-muted-foreground"}`}
                          style={{ left: `${x}%`, top: `${y}%` }}
                        >
                          {d}
                        </span>
                      );
                    })}
                  </div>
                  {/* jarum kiblat — relatif ke arah hadap perangkat */}
                  <div
                    className="absolute inset-0 transition-transform duration-200"
                    style={{ transform: `rotate(${heading != null ? kiblatDeg! - heading : kiblatDeg ?? 0}deg)` }}
                  >
                    <div className="absolute left-1/2 top-3 h-1/2 w-1 -translate-x-1/2 origin-bottom rounded-full bg-gradient-to-b from-emerald-400 to-emerald-600 shadow-[0_0_18px_rgba(16,185,129,0.8)]" />
                    {/* panah Ka'bah */}
                    <div className="absolute left-1/2 top-1.5 flex h-8 w-8 -translate-x-1/2 items-center justify-center rounded-lg bg-emerald-500 text-[14px] shadow-lg">
                      🕋
                    </div>
                  </div>
                  {/* pusat */}
                  <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/80" />
                </div>

                <p className="mt-3 text-center text-[11px] leading-relaxed text-muted-foreground">
                  {kiblatDeg != null && (
                    <>
                      Arah kiblat dari <b className="text-foreground">{koordinat.label}</b>:{" "}
                      <b className="text-emerald-300">{kiblatDeg.toFixed(1)}°</b> dari utara sejati.
                    </>
                  )}
                  <br />
                  {heading != null
                    ? sensorMode === "absolute"
                      ? "Sensor kompas absolut aktif — putar badan/ponsel sampai panah 🕋 lurus ke depan: itulah arah kiblat."
                      : "Sensor RELATIF (belum terkalibrasi ke utara sejati) — gerakkan ponsel pola angka-8 untuk kalibrasi, lalu samakan jarum."
                    : "Aktifkan kompas dan putar ponsel — panah 🕋 akan menunjuk arah Ka'bah."}
                  {heading != null && (
                    <span className="ml-1 rounded-full bg-emerald-500/10 px-1.5 py-px text-[9px] font-bold text-emerald-300">
                      {sensorMode === "absolute" ? "kompas absolut" : "kompas relatif"}
                    </span>
                  )}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================= BACAAN & PANDUAN ================= */}
      {tab === "bacaan" && (
        <div className="mt-4 space-y-4">
          {/* sholat wajib */}
          <section className="glass rounded-2xl p-4">
            <h3 className="mb-3 flex items-center gap-1.5 text-sm font-bold">
              <Clock className="h-4 w-4 text-emerald-400" /> Sholat Wajib — 5 Waktu & Rakaat
            </h3>
            <div className="space-y-2">
              {SHOLAT_WAJIB.map((s) => (
                <div key={s.nama} className="rounded-xl bg-secondary/50 p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-extrabold">{s.nama}</p>
                    <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10px] font-black text-emerald-300">{s.rakaat}</span>
                  </div>
                  <p className="mt-1 text-[10.5px] leading-relaxed text-muted-foreground">{s.waktu}</p>
                </div>
              ))}
            </div>
          </section>

          {/* bacaan sholat */}
          <section>
            <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
              <BookOpen className="h-4 w-4 text-emerald-400" /> Bacaan Sholat Lengkap — Arab • Latin • Arti
            </h3>
            <div className="space-y-2">
              {BACAAN_SHOLAT.map((b, i) => (
                <div key={i} className="glass overflow-hidden rounded-2xl">
                  <button
                    onClick={() => setOpenBacaan(openBacaan === i ? -1 : i)}
                    className="flex w-full items-center justify-between gap-2 p-3.5 text-left"
                  >
                    <span className="text-xs font-extrabold">{b.judul}</span>
                    {openBacaan === i ? <ChevronUp className="h-4 w-4 shrink-0 text-muted-foreground" /> : <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" />}
                  </button>
                  {openBacaan === i && (
                    <div className="space-y-3 border-t border-[var(--surface-line)] p-4" data-fanzz-selectable="1">
                      <div>
                        <div className="mb-2 flex items-center justify-between">
                          <p className="text-[9px] font-black uppercase tracking-wider text-emerald-400">Arab</p>
                          <button
                            onClick={() => salin(`${b.judul}\n\nArab:\n${b.arab}\n\nLatin:\n${b.latin}\n\nArti:\n${b.arti}`, `b-${i}`)}
                            className="flex items-center gap-1 rounded-lg bg-secondary px-2 py-1 text-[9px] font-bold text-muted-foreground"
                          >
                            {copied === `b-${i}` ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                            Salin semua
                          </button>
                        </div>
                        <p dir="rtl" className="rounded-xl bg-black/40 p-3 text-right text-[17px] leading-loose text-emerald-100">{b.arab}</p>
                      </div>
                      <div>
                        <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-teal-400">Latin</p>
                        <p className="text-[12px] italic leading-relaxed text-teal-100/90">{b.latin}</p>
                      </div>
                      <div>
                        <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-amber-400">Arti (Indonesia)</p>
                        <p className="text-[11.5px] leading-relaxed text-muted-foreground">{b.arti}</p>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* surah saranan */}
          <section className="glass rounded-2xl p-4">
            <h3 className="mb-1 flex items-center gap-1.5 text-sm font-bold">
              <Sparkles className="h-4 w-4 text-emerald-400" /> Saran Surah Setelah Al-Fatihah
            </h3>
            <p className="mb-3 text-[10px] text-muted-foreground">Al-Fatihah wajib tiap rakaat — surah pendek berikut dianjurkan pada rakaat selanjutnya:</p>
            <div className="grid grid-cols-2 gap-2">
              {SURAH_SARAN.map((s) => (
                <div key={s.nama} className="rounded-xl bg-secondary/50 p-2.5">
                  <div className="flex items-center justify-between gap-1">
                    <p className="truncate text-[11px] font-extrabold">{s.nama}</p>
                    <span className="shrink-0 text-[13px] text-emerald-300" dir="rtl">{s.arab}</span>
                  </div>
                  <p className="mt-0.5 text-[9.5px] leading-snug text-muted-foreground">{s.ket}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 rounded-xl bg-emerald-500/10 p-2.5 text-[10px] leading-relaxed text-emerald-200">
              Bacaan surah lengkap + audio per ayat oleh 21 imam tersedia di tools <b>Qur'an Digital</b>.
            </p>
          </section>

          {/* sholat sunnah */}
          <section className="glass rounded-2xl p-4">
            <h3 className="mb-3 flex items-center gap-1.5 text-sm font-bold">
              <Moon className="h-4 w-4 text-emerald-400" /> Sholat Sunnah — Rakaat & Keutamaan
            </h3>
            <div className="space-y-2">
              {SHOLAT_SUNNAH.map((s) => (
                <div key={s.nama} className="rounded-xl bg-secondary/50 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-extrabold">{s.nama}</p>
                    <span className="shrink-0 rounded-full bg-teal-500/15 px-2.5 py-1 text-[10px] font-black text-teal-300">{s.rakaat}</span>
                  </div>
                  <p className="mt-1 text-[10.5px] leading-relaxed text-muted-foreground">{s.keutamaan}</p>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {/* ================= SEMUA AGAMA ================= */}
      {tab === "agama" && (
        <div className="mt-4 space-y-4">
          {/* pilih agama */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {AGAMA_LIST.map((a, i) => (
              <button
                key={a.id}
                onClick={() => { setAgamaIdx(i); setAliranOpen(false); }}
                className={`shrink-0 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
                  agamaIdx === i ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                {a.nama}
              </button>
            ))}
          </div>

          <motion.div key={agama.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            {/* info dasar */}
            <div className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-lg">
                  {agama.id === "kristen-protestan" ? "✝️" : agama.id === "katolik" ? "✝️" : agama.id === "ortodoks" ? "☦️" : agama.id === "hindu" ? "🕉️" : agama.id === "buddha" ? "☸️" : agama.id === "konghucu" ? "☯️" : "🌍"}
                </span>
                <div>
                  <p className="text-sm font-extrabold">{agama.nama}</p>
                  <p className="text-[10px] text-muted-foreground">{agama.kitabSuci}</p>
                </div>
              </div>

              {/* aliran */}
              {agama.aliran && agama.aliran.length > 0 && (
                <div className="mt-3">
                  <button
                    onClick={() => setAliranOpen((v) => !v)}
                    className="flex w-full items-center justify-between rounded-xl bg-secondary/50 px-3 py-2.5 text-left"
                  >
                    <span className="text-[11px] font-bold text-muted-foreground">
                      {agama.nama === "Kristen Protestan" ? "Aliran/geraja" : "Aliran"} ({agama.aliran.length}) — pilih untuk dipelajari
                    </span>
                    {aliranOpen ? <ChevronUp className="h-3.5 w-3.5 text-muted-foreground" /> : <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />}
                  </button>
                  {aliranOpen && (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {agama.aliran.map((al) => (
                        <button
                          key={al}
                          onClick={() => setViewAskAI(`Jelaskan ajaran, sejarah singkat, perbedaan utama, dan ciri khas ibadah aliran ${al} dalam ${agama.nama}. Sertakan kitab/acuan dan tempat ibadahnya.`)}
                          className="rounded-full bg-emerald-500/10 px-3 py-1.5 text-[10px] font-bold text-emerald-300 transition-colors hover:bg-emerald-500/20"
                        >
                          {al} →
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}

              <div className="mt-3 space-y-2 text-[11px]">
                <div className="flex gap-2">
                  <Church className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                  <p className="text-muted-foreground"><b className="text-foreground">Rumah ibadah:</b> {agama.rumahIbadah}</p>
                </div>
                <div className="flex gap-2">
                  <Clock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                  <p className="text-muted-foreground"><b className="text-foreground">Hari suci:</b> {agama.hariSuci}</p>
                </div>
              </div>
            </div>

            {/* doa harian */}
            <section>
              <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
                <Volume2 className="h-4 w-4 text-emerald-400" /> Doa & Ibadah Harian
              </h3>
              <div className="space-y-2.5">
                {agama.doaHarian.map((d, i) => (
                  <div key={i} className="glass rounded-2xl p-4" data-fanzz-selectable="1">
                    <div className="mb-2 flex items-center justify-between gap-2">
                      <p className="text-xs font-extrabold">{d.judul}</p>
                      <button
                        onClick={() => salin(`${d.judul}\n\n${d.isi}`, `ag-${i}`)}
                        className="flex shrink-0 items-center gap-1 rounded-lg bg-secondary px-2 py-1 text-[9px] font-bold text-muted-foreground"
                      >
                        {copied === `ag-${i}` ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />} Salin
                      </button>
                    </div>
                    <p className="text-[11.5px] leading-relaxed text-muted-foreground">{d.isi}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* pengajian */}
            <section className="glass rounded-2xl p-4">
              <h3 className="mb-2 flex items-center gap-1.5 text-sm font-bold">
                <BookOpen className="h-4 w-4 text-emerald-400" /> Kegiatan Ibadah & Pengajian
              </h3>
              <p className="text-[11.5px] leading-relaxed text-muted-foreground">{agama.pengajian}</p>
            </section>

            <button
              onClick={() => setViewAskAI(`Berikan panduan lengkap beribadah sehari-hari untuk pemula dalam ${agama.nama}: urutan ibadah, doa-doa utama beserta teksnya, adab, dan kesalahan umum yang perlu dihindari.`)}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-3.5 text-xs font-extrabold text-white transition-transform active:scale-95"
            >
              <Bot className="h-4 w-4" /> Tanya AI: Panduan Ibadah {agama.nama}
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}

/* helper kecil: pindah ke view AI + isi pertanyaan (via localStorage handoff) */
function setViewAskAI(prompt: string) {
  try {
    localStorage.setItem("fanzz_ai_preask", prompt);
  } catch { /* ignore */ }
  // klik tombol nav "AI Chat" lewat state global
  const el = document.querySelector<HTMLButtonElement>("[data-nav-ai]");
  if (el) el.click();
}
