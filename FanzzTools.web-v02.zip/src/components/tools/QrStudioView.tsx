"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import { downloadCanvas, loadImageFromFile } from "@/components/tools/image-studio/lib";
import qrcode from "qrcode-generator";
import jsQR from "jsqr";
import { QrCode, ScanLine, Heart, Link2, Wifi, User, MapPin, FileText, Download, Upload, Loader2, Globe, Copy } from "lucide-react";

/**
 * QR Studio (V2.11 #35) — generator kode QR ber-gaya (kotak, bulat, titik,
 * HATI) + pemindai/penganalisis QR dari gambar. Semua diproses di perangkat.
 */

type BentukModul = "kotak" | "bulat" | "titik" | "hati";
type BentukMata = "kotak" | "bulat";

const KUNCI = "Testing Generator • By : FanzzTools™";

function heartPath(ctx: CanvasRenderingContext2D, x: number, y: number, s: number) {
  // hati kecil dalam kotak (x,y) ukuran s
  const cx = x + s / 2;
  const cy = y + s / 2;
  const r = s * 0.32;
  ctx.beginPath();
  ctx.moveTo(cx, cy + r * 0.9);
  ctx.bezierCurveTo(cx + r * 1.6, cy - r * 0.4, cx + r * 0.6, cy - r * 1.3, cx, cy - r * 0.35);
  ctx.bezierCurveTo(cx - r * 0.6, cy - r * 1.3, cx - r * 1.6, cy - r * 0.4, cx, cy + r * 0.9);
  ctx.closePath();
  ctx.fill();
}

function gambarQr(
  canvas: HTMLCanvasElement,
  teks: string,
  opsi: {
    bentuk: BentukModul;
    mata: BentukMata;
    fg: string;
    bg: string;
    margin: number;
    ukuran: number;
    logo: HTMLImageElement | null;
    watermark: boolean;
  },
) {
  const { bentuk, mata, fg, bg, margin, ukuran, logo, watermark } = opsi;
  // tingkat koreksi tinggi bila ada logo di tengah
  const ecc = logo ? "H" : "M";
  const qr = qrcode(0, ecc as "M" | "H");
  qr.addData(teks || "https://fanzz.tools");
  qr.make();
  const n = qr.getModuleCount();
  const padPx = ukuran * 0.04 * margin;

  const totalH = watermark ? ukuran + Math.round(ukuran * 0.085) : ukuran;
  canvas.width = ukuran;
  canvas.height = totalH;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, ukuran, totalH);

  const sel = (ukuran - padPx * 2) / n;

  // fungsi: apakah sel termasuk pola mata (3 sudut)
  const isMata = (r: number, c: number) =>
    (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7);

  ctx.fillStyle = fg;
  for (let r = 0; r < n; r++) {
    for (let c = 0; c < n; c++) {
      if (!qr.isDark(r, c)) continue;
      const x = padPx + c * sel;
      const y = padPx + r * sel;
      if (isMata(r, c)) continue; // mata digambar terpisah
      if (bentuk === "kotak") {
        ctx.fillRect(x, y, sel + 0.5, sel + 0.5);
      } else if (bentuk === "bulat") {
        ctx.beginPath();
        const rr = sel * 0.3;
        // bulatan sudut
        ctx.moveTo(x + rr, y);
        ctx.arcTo(x + sel, y, x + sel, y + sel, rr);
        ctx.arcTo(x + sel, y + sel, x, y + sel, rr);
        ctx.arcTo(x, y + sel, x, y, rr);
        ctx.arcTo(x, y, x + sel, y, rr);
        ctx.fill();
      } else if (bentuk === "titik") {
        ctx.beginPath();
        ctx.arc(x + sel / 2, y + sel / 2, sel * 0.44, 0, Math.PI * 2);
        ctx.fill();
      } else {
        heartPath(ctx, x, y, sel);
      }
    }
  }

  // pola mata (finder) 7×7 di 3 sudut
  const gambarMata = (mr: number, mc: number) => {
    const x0 = padPx + mc * sel;
    const y0 = padPx + mr * sel;
    const s7 = sel * 7;
    const tebal = sel;
    // luar
    ctx.fillStyle = fg;
    if (mata === "bulat") {
      ctx.beginPath();
      ctx.arc(x0 + s7 / 2, y0 + s7 / 2, s7 / 2 - 0.5, 0, Math.PI * 2);
      ctx.lineWidth = tebal;
      ctx.strokeStyle = fg;
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(x0 + s7 / 2, y0 + s7 / 2, sel * 1.1, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillRect(x0, y0, s7, tebal);
      ctx.fillRect(x0, y0 + s7 - tebal, s7, tebal);
      ctx.fillRect(x0, y0, tebal, s7);
      ctx.fillRect(x0 + s7 - tebal, y0, tebal, s7);
      ctx.fillRect(x0 + sel * 2, y0 + sel * 2, sel * 3, sel * 3);
    }
  };
  gambarMata(0, 0);
  gambarMata(0, n - 7);
  gambarMata(n - 7, 0);

  // logo tengah
  if (logo) {
    const ls = ukuran * 0.22;
    const lx = (ukuran - ls) / 2;
    const ly = (ukuran - ls) / 2;
    ctx.fillStyle = bg;
    const rr = ls * 0.22;
    ctx.beginPath();
    ctx.moveTo(lx + rr, ly);
    ctx.arcTo(lx + ls, ly, lx + ls, ly + ls, rr);
    ctx.arcTo(lx + ls, ly + ls, lx, ly + ls, rr);
    ctx.arcTo(lx, ly + ls, lx, ly, rr);
    ctx.arcTo(lx, ly, lx + ls, ly, rr);
    ctx.fill();
    const skala = Math.min(ls / logo.width, ls / logo.height) * 0.82;
    const dw = logo.width * skala;
    const dh = logo.height * skala;
    ctx.drawImage(logo, lx + (ls - dw) / 2, ly + (ls - dh) / 2, dw, dh);
  }

  // watermark baris bawah
  if (watermark) {
    ctx.fillStyle = fg;
    ctx.font = `600 ${Math.round(ukuran * 0.026)}px 'Archivo Narrow', Arial, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(KUNCI, ukuran / 2, ukuran + (totalH - ukuran) / 2);
    ctx.textAlign = "left";
  }
  return { modul: n };
}

/* ---------- analisis isi QR hasil pemindaian ---------- */
interface Analisis {
  tipe: "URL" | "WiFi" | "Kontak" | "Lokasi" | "Teks" | "Telepon" | "Email";
  ikon: React.ReactNode;
  baris: Array<{ label: string; nilai: string }>;
  url?: string;
}

function analisisQr(teks: string): Analisis {
  const t = teks.trim();
  if (/^WIFI:/i.test(t)) {
    const ambil = (k: string) => {
      const m = t.match(new RegExp(`${k}:((?:\\\\.|[^;])*)`, "i"));
      return m ? m[1].replace(/\\(.)/g, "$1") : "";
    };
    return {
      tipe: "WiFi",
      ikon: <Wifi className="h-5 w-5 text-emerald-400" />,
      baris: [
        { label: "SSID", nilai: ambil("S") || "-" },
        { label: "Keamanan", nilai: ambil("T").toUpperCase() || "Terbuka" },
        { label: "Kata sandi", nilai: ambil("P") || "(terbuka)" },
      ],
    };
  }
  if (/^BEGIN:VCARD/i.test(t)) {
    const nama = t.match(/FN:(.*)/i)?.[1] || "-";
    const tel = t.match(/TEL[^:]*:(.*)/i)?.[1] || "-";
    const email = t.match(/EMAIL[^:]*:(.*)/i)?.[1] || "-";
    return {
      tipe: "Kontak",
      ikon: <User className="h-5 w-5 text-cyan-400" />,
      baris: [
        { label: "Nama", nilai: nama },
        { label: "Telepon", nilai: tel },
        { label: "Email", nilai: email },
      ],
    };
  }
  if (/^geo:/i.test(t)) {
    const [lat, lng] = t.replace(/^geo:/i, "").split(",");
    return {
      tipe: "Lokasi",
      ikon: <MapPin className="h-5 w-5 text-rose-400" />,
      baris: [
        { label: "Lintang", nilai: lat || "-" },
        { label: "Bujur", nilai: lng || "-" },
      ],
      url: `https://maps.google.com/?q=${lat},${lng}`,
    };
  }
  if (/^https?:\/\//i.test(t)) {
    return { tipe: "URL", ikon: <Link2 className="h-5 w-5 text-sky-400" />, baris: [{ label: "Tautan", nilai: t }], url: t };
  }
  if (/^tel:/i.test(t)) {
    return { tipe: "Telepon", ikon: <FileText className="h-5 w-5 text-amber-400" />, baris: [{ label: "Nomor", nilai: t.replace(/^tel:/i, "") }], url: t };
  }
  if (/^mailto:/i.test(t)) {
    return { tipe: "Email", ikon: <FileText className="h-5 w-5 text-red-400" />, baris: [{ label: "Email", nilai: t.replace(/^mailto:/i, "") }], url: t };
  }
  return { tipe: "Teks", ikon: <FileText className="h-5 w-5 text-muted-foreground" />, baris: [{ label: "Isi", nilai: t }] };
}

/* ================= TAMPILAN ================= */

export default function QrStudioView() {
  const [tab, setTab] = useState<"buat" | "pindai">("buat");

  // generator
  const [mode, setMode] = useState<"teks" | "wifi" | "vcard">("teks");
  const [teks, setTeks] = useState("https://fanzz.tools");
  const [wifiSsid, setWifiSsid] = useState("WifiRumah");
  const [wifiPass, setWifiPass] = useState("rahasia123");
  const [vcNama, setVcNama] = useState("Fanzz-Dev");
  const [vcTel, setVcTel] = useState("+6281234567890");
  const [bentuk, setBentuk] = useState<BentukModul>("kotak");
  const [mata, setMata] = useState<BentukMata>("kotak");
  const [fg, setFg] = useState("#111111");
  const [bg, setBg] = useState("#ffffff");
  const [ukuran, setUkuran] = useState(1024);
  const [watermark, setWatermark] = useState(true);
  const [logo, setLogo] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  // pemindai
  const [memindai, setMemindai] = useState(false);
  const [hasilPindai, setHasilPindai] = useState<{ teks: string; analisis: Analisis } | null>(null);

  const isiQr = (() => {
    if (mode === "wifi") return `WIFI:T:WPA;S:${wifiSsid.replace(/([;,:\\])/g, "\\$1")};P:${wifiPass.replace(/([;,:\\])/g, "\\$1")};;`;
    if (mode === "vcard") return `BEGIN:VCARD\nVERSION:3.0\nFN:${vcNama}\nTEL:${vcTel}\nEND:VCARD`;
    return teks;
  })();

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      gambarQr(canvas, isiQr, { bentuk, mata, fg, bg, margin: 1, ukuran: 720, logo, watermark: false });
    } catch {
      toast({ title: "Teks terlalu panjang untuk QR", description: "Kurangi isi teksnya.", variant: "destructive" });
    }
  }, [isiQr, bentuk, mata, fg, bg, logo, toast]);

  useEffect(() => {
    render();
  }, [render]);

  const onLogo = async (f: File | null) => {
    if (!f) return setLogo(null);
    try {
      setLogo(await loadImageFromFile(f));
    } catch {
      toast({ title: "Logo gagal dimuat", variant: "destructive" });
    }
  };

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ekspor = document.createElement("canvas");
    try {
      gambarQr(ekspor, isiQr, { bentuk, mata, fg, bg, margin: 1, ukuran, logo, watermark });
    } catch {
      toast({ title: "Teks terlalu panjang untuk QR", variant: "destructive" });
      return;
    }
    // unduh lewat kanvas ekspor
    ekspor.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fanzz-qr-${ukuran}px.png`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 800);
    }, "image/png");
    pushHistory("qr", {
      id: `qr-${Date.now()}`,
      title: "QR dibuat",
      subtitle: `${mode} • ${ukuran}px • ${bentuk}`,
    });
    toast({ title: "QR terunduh!", description: `${ukuran}px — siap dipakai.` });
  };

  const pindai = async (f: File | null) => {
    if (!f) return;
    setMemindai(true);
    setHasilPindai(null);
    try {
      const img = await loadImageFromFile(f);
      // gambar ke kanvas dengan skala wajar (jsQR bekerja lebih baik dengan kontras tinggi)
      const maxSisi = 1400;
      const skala = Math.min(1, maxSisi / Math.max(img.width, img.height));
      const cv = document.createElement("canvas");
      cv.width = Math.round(img.width * skala);
      cv.height = Math.round(img.height * skala);
      const ctx = cv.getContext("2d")!;
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      const data = ctx.getImageData(0, 0, cv.width, cv.height);
      const kode = jsQR(data.data, data.width, data.height, { inversionAttempts: "attemptBoth" });
      if (kode?.data) {
        setHasilPindai({ teks: kode.data, analisis: analisisQr(kode.data) });
      } else {
        toast({
          title: "QR tidak terbaca",
          description: "Coba foto lebih tegak, lebih terang, dan QR memenuhi sebagian besar bidang gambar.",
          variant: "destructive",
        });
      }
    } catch {
      toast({ title: "Gambar gagal diproses", variant: "destructive" });
    } finally {
      setMemindai(false);
    }
  };

  return (
    <div>
      <ToolHeader
        icon={<QrCode className="h-6 w-6" />}
        title="QR Studio"
        subtitle="Buat QR bergaya (termasuk bentuk hati) & pindai/analisis QR dari gambar — semua di perangkat"
        accent="emerald"
      />

      <div className="mb-4 flex gap-2">
        {([
          { id: "buat", label: "Buat QR", icon: QrCode },
          { id: "pindai", label: "Pindai / Analisis", icon: ScanLine },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === t.id && <motion.span layoutId="qr-tab" className="absolute inset-0 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === "buat" ? (
        <div className="grid gap-5 lg:grid-cols-[340px_1fr]">
          <div className="glass rounded-2xl p-4">
            {/* jenis isi */}
            <div className="mb-3 flex flex-wrap gap-1.5">
              {([
                { id: "teks", label: "Teks / URL" },
                { id: "wifi", label: "WiFi" },
                { id: "vcard", label: "Kontak" },
              ] as const).map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMode(m.id)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                    mode === m.id ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>

            {mode === "teks" && (
              <>
                <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Isi QR — teks, tautan, atau tautan gambar</p>
                <textarea
                  value={teks}
                  onChange={(e) => setTeks(e.target.value.slice(0, 800))}
                  rows={3}
                  placeholder="https://contoh.com/foto.jpg"
                  className="w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-emerald-400/50"
                />
                <p className="mt-1 text-[9.5px] leading-snug text-muted-foreground">
                  Mau QR yang menampilkan gambar saat dipindai? Masukkan tautan (URL) gambar tersebut — QR menyimpan tautan, bukan berkas gambar.
                </p>
              </>
            )}
            {mode === "wifi" && (
              <>
                <p className="mb-1.5 mt-2 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Nama WiFi (SSID)</p>
                <input value={wifiSsid} onChange={(e) => setWifiSsid(e.target.value.slice(0, 40))} className="mb-2 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-emerald-400/50" />
                <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Kata sandi</p>
                <input value={wifiPass} onChange={(e) => setWifiPass(e.target.value.slice(0, 60))} className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-emerald-400/50" />
              </>
            )}
            {mode === "vcard" && (
              <>
                <p className="mb-1.5 mt-2 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Nama</p>
                <input value={vcNama} onChange={(e) => setVcNama(e.target.value.slice(0, 60))} className="mb-2 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-emerald-400/50" />
                <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Nomor telepon</p>
                <input value={vcTel} onChange={(e) => setVcTel(e.target.value.slice(0, 25))} className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-emerald-400/50" />
              </>
            )}

            {/* bentuk modul */}
            <p className="mb-1.5 mt-4 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Bentuk</p>
            <div className="flex flex-wrap gap-1.5">
              {(["kotak", "bulat", "titik", "hati"] as const).map((b) => (
                <button
                  key={b}
                  onClick={() => setBentuk(b)}
                  className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-[11px] font-bold capitalize transition ${
                    bentuk === b ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {b === "hati" && <Heart className="h-3 w-3 fill-current" />}
                  {b}
                </button>
              ))}
            </div>
            <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Sudut mata</p>
            <div className="flex gap-1.5">
              {(["kotak", "bulat"] as const).map((b) => (
                <button
                  key={b}
                  onClick={() => setMata(b)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold capitalize transition ${
                    mata === b ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>

            {/* warna */}
            <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Warna</p>
            <div className="flex gap-2">
              <label className="flex flex-1 items-center gap-2 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs">
                <input type="color" value={fg} onChange={(e) => setFg(e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" />
                <span className="font-mono text-[10px] text-muted-foreground">{fg}</span>
              </label>
              <label className="flex flex-1 items-center gap-2 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs">
                <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" />
                <span className="font-mono text-[10px] text-muted-foreground">{bg}</span>
              </label>
            </div>

            {/* logo tengah */}
            <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border/70 bg-secondary/30 px-3 py-2.5 text-[11px] font-bold text-muted-foreground transition hover:border-emerald-400/50 hover:text-foreground">
              <Upload className="h-3.5 w-3.5" /> {logo ? "Ganti logo tengah" : "Logo tengah (opsional)"}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => onLogo(e.target.files?.[0] || null)} />
            </label>
            {logo && (
              <button onClick={() => setLogo(null)} className="mt-1.5 text-[10px] font-bold text-emerald-400 underline underline-offset-2">
                hapus logo
              </button>
            )}

            {/* ukuran + watermark */}
            <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Ukuran unduhan</p>
            <div className="flex gap-1.5">
              {[512, 1024, 2048].map((u) => (
                <button
                  key={u}
                  onClick={() => setUkuran(u)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                    ukuran === u ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {u}px
                </button>
              ))}
            </div>
            <label className="mt-3 flex items-center gap-2 text-[11px] font-bold text-muted-foreground">
              <input type="checkbox" checked={watermark} onChange={(e) => setWatermark(e.target.checked)} className="h-3.5 w-3.5 accent-emerald-500" />
              Tulis “{KUNCI}” di bawah QR
            </label>

            <button
              onClick={unduh}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-3 text-xs font-extrabold text-white shadow-lg shadow-emerald-500/20 transition-transform active:scale-95"
            >
              <Download className="h-4 w-4" /> Unduh QR PNG
            </button>
          </div>

          <div className="flex items-start justify-center">
            <div className="rounded-2xl bg-white p-5 shadow-2xl ring-1 ring-border/40">
              <canvas ref={canvasRef} className="block h-auto w-[300px] max-w-full sm:w-[360px]" />
              {watermark && <p className="mt-2 text-center font-sans text-[10px] font-semibold text-black/70">{KUNCI}</p>}
            </div>
          </div>
        </div>
      ) : (
        <div className="mx-auto max-w-xl space-y-4">
          <label className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border/70 bg-secondary/30 py-12 text-center transition hover:border-emerald-400/50">
            {memindai ? <Loader2 className="h-8 w-8 animate-spin text-emerald-400" /> : <ScanLine className="h-8 w-8 text-emerald-400" />}
            <div>
              <p className="text-sm font-bold">{memindai ? "Memindai…" : "Unggah gambar berisi QR"}</p>
              <p className="mt-1 text-xs text-muted-foreground">JPG / PNG / WebP — dianalisis langsung di perangkat Anda</p>
            </div>
            <input type="file" accept="image/*" className="hidden" onChange={(e) => pindai(e.target.files?.[0] || null)} />
          </label>

          {hasilPindai && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-4">
              <div className="mb-3 flex items-center gap-2">
                {hasilPindai.analisis.ikon}
                <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-[11px] font-extrabold text-emerald-300">
                  {hasilPindai.analisis.tipe}
                </span>
              </div>
              <div className="space-y-2">
                {hasilPindai.analisis.baris.map((b) => (
                  <div key={b.label} className="rounded-xl bg-secondary/50 px-3 py-2.5">
                    <p className="text-[9.5px] font-bold uppercase tracking-wide text-muted-foreground">{b.label}</p>
                    <p className="mt-0.5 break-all text-sm font-bold">{b.nilai}</p>
                  </div>
                ))}
              </div>
              <div className="mt-3 flex flex-wrap gap-2">
                {hasilPindai.analisis.url && (
                  <a
                    href={hasilPindai.analisis.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-3.5 py-2.5 text-xs font-bold text-white"
                  >
                    <Globe className="h-3.5 w-3.5" /> Buka tautan
                  </a>
                )}
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(hasilPindai.teks);
                    toast({ title: "Tersalin ke papan klip" });
                  }}
                  className="flex items-center gap-1.5 rounded-xl bg-secondary px-3.5 py-2.5 text-xs font-bold"
                >
                  <Copy className="h-3.5 w-3.5" /> Salin isi mentah
                </button>
              </div>
              <p className="mt-3 rounded-xl bg-secondary/40 px-3 py-2 font-mono text-[10px] leading-relaxed text-muted-foreground">
                {hasilPindai.teks}
              </p>
            </motion.div>
          )}

          <p className="text-center text-[10px] leading-relaxed text-muted-foreground">
            Pemindai berjalan sepenuhnya di perangkat Anda — gambar tidak diunggah ke mana pun.
            QR menyimpan teks/tautan; “QR dari gambar” berarti QR berisi tautan gambar tersebut.
          </p>
        </div>
      )}
    </div>
  );
}
