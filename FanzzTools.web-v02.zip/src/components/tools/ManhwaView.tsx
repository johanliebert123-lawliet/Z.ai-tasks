"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import {
  BookOpen, Search, Loader2, ArrowLeft, ListOrdered, ChevronLeft, ChevronRight, X, XCircle,
} from "lucide-react";

interface MangaCard {
  judul: string;
  slug: string;
  sumber?: "manwhaku" | "mangadex";
  url: string;
  thumbnail?: string | null;
  type?: string | null;
  rating?: string | null;
  chapterTerbaru?: string | null;
}

interface Chapter {
  chapter: string;
  slug: string;
  url: string;
  lang?: string;
  title?: string;
  eksternal?: boolean;
}

interface MangaDetail {
  judul: string;
  sumber?: string;
  slug?: string;
  sebagianEksternal?: boolean;
  thumbnail?: string | null;
  synopsis?: string | null;
  type?: string | null;
  status?: string | null;
  rating?: string | null;
  author?: string | null;
  genres: string[];
  totalChapters: number;
  chapters: Chapter[];
}

interface ReaderState {
  judul: string;
  chapter: string;
  images: string[];
  prevSlug: string | null;
  nextSlug: string | null;
  chapters: Chapter[];
}

export default function ManhwaView() {
  const [manga, setManga] = useState<MangaCard[] | null>(null);
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<MangaDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [reader, setReader] = useState<ReaderState | null>(null);
  const [readerLoading, setReaderLoading] = useState(false);
  const [showChapterList, setShowChapterList] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadHome = useCallback(async () => {
    setManga(null);
    try {
      const r = await fetch("/api/manhwa?home=1");
      const d = await r.json();
      setManga(d?.ok ? (d.manga || []) : []);
    } catch {
      setManga([]);
    }
  }, []);

  useEffect(() => {
    loadHome();
  }, [loadHome]);

  const doSearch = (q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      loadHome();
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/manhwa?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        setManga(d?.ok ? (d.results || []) : []);
      } catch {
        setManga([]);
      } finally {
        setSearching(false);
      }
    }, 500);
  };

  const openDetail = async (slug: string) => {
    setDetailLoading(true);
    setDetail(null);
    setReader(null);
    try {
      // slug "md-xxx" → sumber MangaDex, selain itu → manwhaku
      const isMd = slug.startsWith("md-");
      const r = await fetch(`/api/manhwa?${isMd ? `mdid=${encodeURIComponent(slug.slice(3))}` : `slug=${encodeURIComponent(slug)}`}`);
      const d = await r.json();
      if (d?.ok) {
        setDetail({
          judul: d.judul,
          sumber: d.sumber,
          slug: d.slug || slug,
          sebagianEksternal: d.sebagianEksternal,
          thumbnail: d.thumbnail,
          synopsis: d.synopsis,
          type: d.type,
          status: d.status,
          rating: d.rating,
          author: d.author,
          genres: d.genres || [],
          totalChapters: d.totalChapters || 0,
          chapters: d.chapters || [],
        });
        window.scrollTo({ top: 0 });
      }
    } finally {
      setDetailLoading(false);
    }
  };

  const openChapter = async (slug: string, chapters: Chapter[]) => {
    if (!slug) return;
    setReaderLoading(true);
    setReader(null);
    try {
      // slug "mdch_xxx" → chapter MangaDex (at-home server), selain itu → manwhaku
      const isMd = slug.startsWith("mdch_");
      const r = await fetch(`/api/manhwa?${isMd ? `mdpages=${encodeURIComponent(slug.slice(5))}` : `read=${encodeURIComponent(slug)}`}`);
      const d = await r.json();
      if (d?.ok && d.images?.length) {
        setReader({
          judul: d.judul || "Manhwa",
          chapter: d.chapter || "Chapter",
          images: d.images,
          prevSlug: d.prevSlug || null,
          nextSlug: d.nextSlug || null,
          chapters,
        });
        // V0.01 (#7): catat riwayat chapter manhwa
        pushHistory("manhwa", {
          id: slug,
          title: d.judul || "Manhwa",
          subtitle: d.chapter || "Chapter",
        });
        window.scrollTo({ top: 0 });
      } else {
        // mungkin chapter eksternal → cari tautannya dari daftar chapter
        const ch = chapters.find((c) => c.slug === slug && c.eksternal && c.url);
        if (ch) {
          window.open(ch.url, "_blank", "noopener,noreferrer");
        }
      }
    } finally {
      setReaderLoading(false);
    }
  };

  /* ---------- READER ---------- */
  if (readerLoading) {
    return (
      <div>
        <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Baca Manhwa" subtitle="Komik full color • update tiap hari" accent="cyan" />
        <div className="flex h-[50vh] flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
          <p className="text-xs text-muted-foreground">Menyiapkan halaman chapter...</p>
        </div>
      </div>
    );
  }

  if (reader) {
    return (
      <div>
        {/* bar atas sticky reader */}
        <div className="sticky top-0 z-30 -mx-4 mb-3 flex items-center gap-2 bg-[var(--surface-header)] px-4 py-2.5 pt-safe backdrop-blur-xl md:-mx-8 md:px-8">
          <button
            onClick={() => setReader(null)}
            className="flex shrink-0 items-center gap-1 rounded-xl bg-secondary/70 px-2.5 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="min-w-0 flex-1">
            <p className="truncate text-xs font-extrabold">{reader.judul}</p>
            <p className="text-[10px] text-muted-foreground">{reader.chapter} • {reader.images.length} halaman</p>
          </div>
          <button
            onClick={() => setShowChapterList(true)}
            className="flex shrink-0 items-center gap-1 rounded-xl bg-cyan-500/15 px-2.5 py-2 text-[10px] font-bold text-cyan-300"
          >
            <ListOrdered className="h-3.5 w-3.5" /> Chapter
          </button>
        </div>

        {/* gambar halaman */}
        <div className="space-y-1.5">
          {reader.images.map((img, i) => (
            <div key={i} className="relative overflow-hidden rounded-xl bg-secondary">
              <img src={img} alt={`Halaman ${i + 1}`} loading={i < 2 ? "eager" : "lazy"} className="w-full" referrerPolicy="no-referrer" />
              <span className="absolute bottom-1.5 right-1.5 rounded-md bg-black/60 px-1.5 py-0.5 text-[9px] font-bold text-white/80">
                {i + 1}/{reader.images.length}
              </span>
            </div>
          ))}
        </div>

        {/* nav chapter bawah */}
        <div className="sticky bottom-0 z-30 -mx-4 mt-3 flex items-center gap-2 bg-[var(--surface-nav)] px-4 py-3 pb-safe backdrop-blur-xl md:-mx-8 md:px-8">
          <button
            onClick={() => reader.prevSlug && openChapter(reader.prevSlug, reader.chapters)}
            disabled={!reader.prevSlug}
            className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-secondary/70 py-3 text-xs font-bold disabled:opacity-40"
          >
            <ChevronLeft className="h-4 w-4" /> Sebelumnya
          </button>
          <button
            onClick={() => reader.nextSlug && openChapter(reader.nextSlug, reader.chapters)}
            disabled={!reader.nextSlug}
            className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 py-3 text-xs font-bold text-white shadow-lg shadow-cyan-500/20 disabled:opacity-40"
          >
            Berikutnya <ChevronRight className="h-4 w-4" />
          </button>
        </div>

        {/* sheet daftar chapter */}
        <AnimatePresence>
          {showChapterList && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm md:items-center"
              onClick={() => setShowChapterList(false)}
            >
              <motion.div
                initial={{ y: 60 }}
                animate={{ y: 0 }}
                exit={{ y: 60 }}
                onClick={(e) => e.stopPropagation()}
                className="max-h-[70vh] w-full max-w-md overflow-hidden rounded-t-3xl glass-strong md:rounded-3xl"
              >
                <div className="flex items-center justify-between border-b border-[var(--surface-line)] p-4">
                  <p className="text-sm font-extrabold">Daftar Chapter</p>
                  <button onClick={() => setShowChapterList(false)} className="rounded-xl p-1.5 text-muted-foreground hover:text-foreground">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <div className="max-h-[58vh] space-y-1.5 overflow-y-auto p-3">
                  {reader.chapters.map((c) => (
                    <button
                      key={c.slug || c.url}
                      onClick={() => {
                        setShowChapterList(false);
                        openChapter(c.slug, reader.chapters);
                      }}
                      className={`w-full rounded-xl px-3.5 py-2.5 text-left text-xs font-bold transition-colors ${
                        c.chapter === reader.chapter
                          ? "bg-cyan-500/20 text-cyan-300"
                          : "bg-secondary/50 hover:bg-secondary"
                      }`}
                    >
                      {c.chapter}
                    </button>
                  ))}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  /* ---------- DETAIL ---------- */
  if (detailLoading) {
    return (
      <div>
        <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Baca Manhwa" subtitle="Komik full color • update tiap hari" accent="cyan" />
        <div className="space-y-3">
          <div className="h-44 rounded-3xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (detail) {
    return (
      <div>
        <button onClick={() => setDetail(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Kembali
        </button>

        <div className="overflow-hidden rounded-3xl glass p-5">
          <div className="flex gap-4">
            {detail.thumbnail && (
              <img src={detail.thumbnail} alt="" className="h-36 w-24 shrink-0 rounded-2xl object-cover shadow-xl" referrerPolicy="no-referrer" />
            )}
            <div className="min-w-0 flex-1">
              <h2 className="clamp-3 text-base font-extrabold leading-snug">{detail.judul}</h2>
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[10px]">
                {detail.rating && <span className="rounded-full bg-amber-500/15 px-2 py-0.5 font-bold text-amber-300">★ {detail.rating}</span>}
                {detail.type && <span className="rounded-full bg-cyan-500/15 px-2 py-0.5 font-bold text-cyan-300">{detail.type}</span>}
                {detail.status && <span className="rounded-full bg-secondary/70 px-2 py-0.5 font-bold text-muted-foreground">{detail.status}</span>}
              </div>
              <p className="mt-1.5 text-xs font-bold text-muted-foreground">{detail.totalChapters} chapter tersedia</p>
              {detail.chapters.length > 0 && (
                <button
                  onClick={() => openChapter(detail.chapters[detail.chapters.length - 1].slug, detail.chapters)}
                  className="mt-3 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 py-3 text-xs font-extrabold text-white shadow-lg shadow-cyan-500/20 transition-transform active:scale-95"
                >
                  {detail.chapters[detail.chapters.length - 1].eksternal ? "Baca di situs resmi" : "Mulai dari Chapter Pertama"}
                </button>
              )}
              {detail.sebagianEksternal && (
                <p className="mt-2 text-[10px] leading-relaxed text-amber-300/90">
                  Judul ini berlisensi resmi — chapter-nya dibuka di situs penerbit (taut keluar).
                </p>
              )}
            </div>
          </div>
          {detail.genres.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {detail.genres.slice(0, 8).map((g) => (
                <span key={g} className="rounded-full bg-secondary/70 px-2 py-0.5 text-[10px] font-semibold text-muted-foreground">{g}</span>
              ))}
            </div>
          )}
        </div>

        {detail.synopsis && (
          <section className="mt-4 rounded-2xl glass p-4">
            <h3 className="mb-1.5 text-sm font-bold">Sinopsis</h3>
            <p className="whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{detail.synopsis}</p>
          </section>
        )}

        <section className="mt-4">
          <h3 className="mb-2.5 text-sm font-bold">Semua Chapter</h3>
          <div className="max-h-[60vh] space-y-1.5 overflow-y-auto pr-1">
            {detail.chapters.map((c) => (
              <button
                key={c.slug || c.url}
                onClick={() => openChapter(c.slug, detail.chapters)}
                className="flex w-full items-center justify-between gap-2 rounded-xl bg-secondary/50 px-3.5 py-3 text-left transition-colors hover:bg-secondary"
              >
                <span className="truncate text-xs font-bold">{c.chapter}{c.eksternal ? " • resmi" : ""}</span>
                <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              </button>
            ))}
            {detail.chapters.length === 0 && <EmptyState icon={<XCircle className="h-6 w-6" />} title="Belum ada chapter" desc="Manhwa ini belum memiliki chapter yang dapat dibaca." />}
          </div>
        </section>
      </div>
    );
  }

  /* ---------- HOME / SEARCH ---------- */
  return (
    <div>
      <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Baca Manhwa" subtitle="Komik full color • search • baca langsung" accent="cyan" />

      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => { setQuery(e.target.value); doSearch(e.target.value); }}
          placeholder="Cari judul manhwa..."
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-3.5 pl-10 pr-10 text-sm outline-none focus:border-cyan-400/50"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-cyan-400" />}
        {query && (
          <button onClick={() => { setQuery(""); loadHome(); }} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {manga === null ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="aspect-[3/4] rounded-2xl shimmer" />)}
        </div>
      ) : manga.length === 0 ? (
        <EmptyState icon={<BookOpen className="h-6 w-6" />} title="Tidak ditemukan" desc="Silakan coba kata kunci lain — pencarian mencakup dua sumber sekaligus." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {manga.map((m, i) => (
            <motion.button
              key={m.slug + i}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.3) }}
              onClick={() => openDetail(m.slug)}
              className="group overflow-hidden rounded-2xl glass p-2 text-left transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-secondary">
                {m.thumbnail ? (
                  <img src={m.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="flex h-full items-center justify-center"><BookOpen className="h-8 w-8 text-muted-foreground" /></div>
                )}
                {m.sumber === "mangadex" && (
                  <span className="absolute right-1.5 top-1.5 rounded-md bg-cyan-600/90 px-1.5 py-0.5 text-[8px] font-extrabold text-white">MDEX</span>
                )}
                {m.rating && (
                  <span className="absolute left-1.5 top-1.5 rounded-lg bg-black/70 px-1.5 py-0.5 text-[9px] font-extrabold text-amber-300 backdrop-blur-sm">
                    ★ {m.rating}
                  </span>
                )}
                {m.chapterTerbaru && (
                  <span className="absolute inset-x-1.5 bottom-1.5 truncate rounded-lg bg-black/70 px-1.5 py-1 text-[8.5px] font-bold text-white/85 backdrop-blur-sm">
                    {m.chapterTerbaru}
                  </span>
                )}
              </div>
              <p className="clamp-2 mt-2 px-0.5 text-[11.5px] font-bold leading-tight">{m.judul}</p>
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}
