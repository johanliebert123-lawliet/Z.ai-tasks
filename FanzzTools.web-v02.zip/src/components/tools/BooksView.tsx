"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import {
  Library, Search, Loader2, X, BookOpen, ExternalLink, ChevronLeft,
  ChevronRight, ZoomIn, ZoomOut, Upload, FileText, TrendingUp,
} from "lucide-react";

interface BookItem {
  id: string;
  title: string;
  creator: string;
  year: string;
  cover: string | null;
  provider: "archive" | "openlibrary" | "gbooks";
  readUrl: string | null;
  infoUrl: string;
  downloads?: number;
}

export default function BooksView() {
  const [tab, setTab] = useState<"online" | "local">("online");

  return (
    <div>
      <ToolHeader icon={<Library className="h-5.5 w-5.5" />} title="Baca Buku & PDF" subtitle="Jutaan buku arsip dunia + baca PDF dari HP kamu" accent="cyan" />

      {/* tabs */}
      <div className="mb-4 flex gap-2">
        {([
          { id: "online", label: "Pustaka Online", icon: Library },
          { id: "local", label: "PDF Lokal", icon: FileText },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3.5 py-2.5 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === t.id && <motion.span layoutId="books-tab" className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === "online" ? <OnlineLibrary /> : <LocalPdf />}
    </div>
  );
}

/* ================= PUSTAKA ONLINE ================= */

function OnlineLibrary() {
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<BookItem[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reading, setReading] = useState<BookItem | null>(null);
  const [lookupBusy, setLookupBusy] = useState(false);
  const [page, setPage] = useState(1);
  /** V2.11 (#34): buku sedang populer — tampil di atas sebelum mencari */
  const [popular, setPopular] = useState<BookItem[] | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    fetch("/api/books?popular")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setPopular(d?.ok ? d.items : []))
      .catch(() => setPopular([]));
  }, []);

  const load = useCallback(async (q: string, p: number) => {
    setLoading(true);
    setError("");
    try {
      const r = await fetch(`/api/books?q=${encodeURIComponent(q)}&page=${p}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memuat buku");
      setItems(d.items);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load("", 1);
  }, [load]);

  const doSearch = (q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    setPage(1);
    debounceRef.current = setTimeout(() => load(q.trim(), 1), 400);
  };

  /** PERBAIKAN V2a: buku tanpa readUrl otomatis dicari padanannya di Internet
   *  Archive — pesan "gagal" hanya muncul bila arsip juga tidak punya bukunya. */
  const openBook = async (b: BookItem) => {
    setReading(b);
    // V0.01 (#7): catat riwayat buku yang dibuka
    pushHistory("books", {
      id: b.id || b.title,
      title: b.title,
      subtitle: b.creator,
      poster: b.cover,
      url: b.readUrl,
    });
    if (b.readUrl) return;
    setLookupBusy(true);
    try {
      const r = await fetch(`/api/books?lookup=${encodeURIComponent(b.title)}&creator=${encodeURIComponent(b.creator || "")}`);
      const d = await r.json();
      if (d?.ok && d.found?.readUrl) {
        setReading(d.found);
      }
    } catch {
      /* biarkan tampilan fallback */
    } finally {
      setLookupBusy(false);
    }
  };

  return (
    <div>
      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            doSearch(e.target.value);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              setPage(1);
              load(query.trim(), 1);
            }
          }}
          placeholder="Cari judul, penulis, atau topik... (arsip klasik sampai buku modern)"
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-4 pl-10 pr-3 text-sm outline-none focus:border-cyan-400/50"
        />
        {loading && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-cyan-400" />}
      </div>

      {error && <p className="mb-3 rounded-xl bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-300">{error}</p>}

      {/* V2.11 (#34): seksi buku sedang populer — tampil saat belum mencari */}
      {!query.trim() && popular && popular.length > 0 && (
        <section className="mb-5">
          <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
            <TrendingUp className="h-4 w-4 text-cyan-400" /> Sedang Populer
            <span className="rounded-full bg-cyan-500/15 px-1.5 py-px text-[8.5px] font-extrabold text-cyan-300">TRENDING</span>
          </h3>
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
            {popular.slice(0, 16).map((b, i) => (
              <button
                key={b.id || `pop-${i}`}
                onClick={() => {
                  // klik = cari judul ini (menemukan versi yang bisa dibaca)
                  setQuery(b.title);
                  doSearch(b.title);
                }}
                className="group w-24 shrink-0 text-left"
                title={`${b.title} — ${b.creator}`}
              >
                <div className="relative aspect-[2/3] w-full overflow-hidden rounded-xl bg-gradient-to-br from-cyan-500/25 to-teal-600/15 ring-1 ring-cyan-400/20">
                  {b.cover ? (
                    <img src={b.cover} alt="" loading="lazy" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="flex h-full w-full flex-col items-center justify-center gap-1.5 p-2 text-center">
                      <Library className="h-5 w-5 text-cyan-300/70" />
                      <p className="line-clamp-4 text-[8.5px] font-bold leading-tight text-cyan-100/90">{b.title}</p>
                    </div>
                  )}
                  {b.year ? (
                    <span className="absolute right-1 top-1 rounded-md bg-black/60 px-1 py-px text-[8px] font-bold text-white/90">{b.year}</span>
                  ) : null}
                </div>
                <p className="mt-1 line-clamp-1 text-[9.5px] font-bold text-muted-foreground group-hover:text-foreground">{b.title}</p>
                <p className="line-clamp-1 text-[8px] text-muted-foreground/70">{b.creator}</p>
              </button>
            ))}
          </div>
          <p className="mt-1.5 text-[9px] text-muted-foreground/70">Ketuk kartu untuk mencari &amp; membaca bukunya.</p>
        </section>
      )}

      {loading ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="h-56 rounded-2xl shimmer" />)}
        </div>
      ) : !items || items.length === 0 ? (
        <EmptyState icon={<Library className="h-6 w-6" />} title="Buku tidak ditemukan" desc="Silakan coba judul atau penulis lain, misalnya 'Sherlock Holmes' atau 'sejarah'." />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {items.map((b, i) => (
              <motion.button
                key={b.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
                onClick={() => openBook(b)}
                className="group flex flex-col overflow-hidden rounded-2xl glass p-2 text-left transition-all hover:scale-[1.02]"
              >
                <div className="relative aspect-3/4 w-full overflow-hidden rounded-xl bg-secondary">
                  {b.cover ? (
                    <img
                      src={b.cover}
                      alt=""
                      className="h-full w-full object-cover"
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "";
                        (e.target as HTMLImageElement).style.display = "none";
                      }}
                    />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-cyan-400">
                      <BookOpen className="h-8 w-8" />
                    </div>
                  )}
                  {b.readUrl && (
                    <span className="absolute bottom-1.5 right-1.5 rounded-full bg-cyan-500 px-2 py-0.5 text-[8px] font-extrabold text-white opacity-0 transition-opacity group-hover:opacity-100">
                      BACA
                    </span>
                  )}
                </div>
                <p className="clamp-2 mt-2 text-[11px] font-bold leading-tight">{b.title}</p>
                <p className="mt-0.5 truncate text-[9.5px] text-muted-foreground">
                  {b.creator || "Sumber tidak diketahui"} {b.year ? `• ${b.year}` : ""}
                </p>
              </motion.button>
            ))}
          </div>

          {/* pagination */}
          <div className="mt-4 flex items-center justify-center gap-3">
            <button
              onClick={() => {
                const p = Math.max(1, page - 1);
                setPage(p);
                load(query.trim(), p);
                window.scrollTo({ top: 0 });
              }}
              disabled={page <= 1 || loading}
              className="flex items-center gap-1 rounded-xl glass px-3.5 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" /> Sebelumnya
            </button>
            <span className="text-xs font-bold text-muted-foreground">Hal {page}</span>
            <button
              onClick={() => {
                const p = page + 1;
                setPage(p);
                load(query.trim(), p);
                window.scrollTo({ top: 0 });
              }}
              disabled={items.length < 10 || loading}
              className="flex items-center gap-1 rounded-xl glass px-3.5 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground disabled:opacity-40"
            >
              Berikutnya <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </>
      )}

      {/* modal baca (embed archive.org) */}
      <AnimatePresence>
        {reading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex flex-col bg-black/90 backdrop-blur-sm"
          >
            <div className="flex items-center gap-2 bg-[var(--surface-side)] px-3 py-2.5 pt-safe">
              <button onClick={() => setReading(null)} className="rounded-xl p-2 text-muted-foreground transition-colors hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">{reading.title}</p>
                <p className="truncate text-[10px] text-muted-foreground">
                  {reading.provider === "archive"
                    ? "Internet Archive"
                    : reading.provider === "gbooks"
                      ? "Google Books"
                      : "Open Library"}{" "}
                  {reading.year ? `• ${reading.year}` : ""}
                </p>
              </div>
              <a
                href={reading.infoUrl}
                target="_blank"
                rel="noreferrer"
                className="rounded-xl glass p-2 text-muted-foreground transition-colors hover:text-foreground"
                title="Info buku"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
            {reading.readUrl ? (
              <iframe
                src={reading.readUrl}
                title={reading.title}
                className="h-full w-full flex-1 border-0 bg-white"
                allow="autoplay; fullscreen"
                allowFullScreen
              />
            ) : (
              <div className="flex flex-1 flex-col items-center justify-center gap-3 p-8 text-center">
                {lookupBusy ? (
                  <>
                    <Loader2 className="h-10 w-10 animate-spin text-cyan-400" />
                    <p className="text-sm font-bold">Mencari versi terbaca di arsip publik...</p>
                    <p className="max-w-xs text-xs text-muted-foreground">
                      Mencari padanan buku ini di Internet Archive agar dapat dibaca langsung.
                    </p>
                  </>
                ) : (
                  <>
                    <BookOpen className="h-10 w-10 text-muted-foreground" />
                    <p className="text-sm font-bold">Buku ini belum bisa dibaca penuh di sini</p>
                    <p className="max-w-xs text-xs text-muted-foreground">
                      Buku modern umumnya hanya dapat dipinjam/dipratinjau di halaman resminya.
                      Versi arsip publik belum tersedia untuk judul ini.
                    </p>
                    <a
                      href={reading.infoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-4 py-2.5 text-xs font-bold text-white"
                    >
                      <ExternalLink className="mr-1.5 inline h-3.5 w-3.5" /> Buka halaman buku
                    </a>
                  </>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= PDF LOKAL (pdf.js) ================= */

function LocalPdf() {
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [numPages, setNumPages] = useState(0);
  const [pageNum, setPageNum] = useState(1);
  const [zoom, setZoom] = useState(1);
  const [rendering, setRendering] = useState(false);
  const [error, setError] = useState("");
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pdfRef = useRef<{ numPages: number; getPage: (n: number) => Promise<{ getViewport: (o: { scale: number }) => { width: number; height: number }; render: (o: { canvasContext: CanvasRenderingContext2D; viewport: unknown }) => { promise: Promise<void> } }> } | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  const pick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.name.toLowerCase().endsWith(".pdf") && f.type !== "application/pdf") {
      setError("File harus PDF ya");
      return;
    }
    if (f.size > 120 * 1024 * 1024) {
      setError("Ukuran PDF melebihi batas (maksimal 120MB)");
      return;
    }
    setError("");
    setPdfFile(f);
    setPageNum(1);
    setZoom(1);
  };

  const renderPage = useCallback(
    async (n: number, z: number) => {
      const pdf = pdfRef.current;
      const canvas = canvasRef.current;
      if (!pdf || !canvas || rendering) return;
      setRendering(true);
      try {
        const page = await pdf.getPage(n);
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const base = Math.min(620, canvas.parentElement?.clientWidth || 620) / 620;
        const viewport = page.getViewport({ scale: (1.25 * z * base) as never });
        canvas.width = viewport.width * dpr;
        canvas.height = viewport.height * dpr;
        canvas.style.width = `${viewport.width}px`;
        canvas.style.height = `${viewport.height}px`;
        const ctx = canvas.getContext("2d")!;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        await page.render({ canvasContext: ctx, viewport } as never).promise;
      } catch {
        /* halaman rusak — lanjut */
      } finally {
        setRendering(false);
      }
    },
    [rendering]
  );

  // load pdf.js pas file dipilih
  useEffect(() => {
    if (!pdfFile) return;
    let cancelled = false;
    (async () => {
      setError("");
      setNumPages(0);
      try {
        const pdfjs = await import("pdfjs-dist");
        pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
        const buf = await pdfFile.arrayBuffer();
        const doc = await pdfjs.getDocument({ data: buf }).promise;
        if (cancelled) return;
        pdfRef.current = doc as unknown as typeof pdfRef.current;
        setNumPages(doc.numPages);
        setPageNum(1);
        setTimeout(() => renderPage(1, zoom), 60);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : "PDF gagal dibaca");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [pdfFile]);

  // re-render pas halaman/zoom ganti
  useEffect(() => {
    if (pdfRef.current && numPages > 0) renderPage(pageNum, zoom);
  }, [pageNum, zoom]);

  return (
    <div>
      <input ref={inputRef} type="file" accept="application/pdf,.pdf" className="hidden" onChange={pick} />

      {!pdfFile ? (
        <button
          onClick={() => inputRef.current?.click()}
          className="flex w-full flex-col items-center gap-3 rounded-3xl glass p-10 transition-all hover:scale-[1.01]"
        >
          <motion.span
            animate={{ y: [0, -8, 0] }}
            transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
            className="flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-xl shadow-cyan-500/25"
          >
            <Upload className="h-8 w-8" />
          </motion.span>
          <p className="text-sm font-extrabold">Buka PDF dari HP kamu</p>
          <p className="max-w-xs text-center text-[11px] leading-relaxed text-muted-foreground">
            Novel, komik, modul, materi sekolah, apapun — dibaca langsung di sini
            dengan zoom &amp; pindah halaman. File <b>tidak diunggah ke mana pun</b> — hanya diproses di perangkat Anda
          </p>
        </button>
      ) : (
        <div>
          {/* kontrol atas */}
          <div className="mb-2.5 flex flex-wrap items-center gap-2">
            <button
              onClick={() => setPdfFile(null)}
              className="flex items-center gap-1 rounded-xl glass px-3 py-2 text-[11px] font-bold text-muted-foreground transition-colors hover:text-foreground"
            >
              <X className="h-3.5 w-3.5" /> Tutup
            </button>
            <div className="flex items-center gap-1 rounded-xl glass px-2 py-1.5">
              <button onClick={() => setPageNum((p) => Math.max(1, p - 1))} disabled={pageNum <= 1} className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:text-foreground disabled:opacity-30">
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="min-w-14 text-center text-[11px] font-bold tabular-nums">
                {numPages ? `${pageNum}/${numPages}` : "..."}
              </span>
              <button onClick={() => setPageNum((p) => Math.min(numPages, p + 1))} disabled={pageNum >= numPages} className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:text-foreground disabled:opacity-30">
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="flex items-center gap-1 rounded-xl glass px-2 py-1.5">
              <button onClick={() => setZoom((z) => Math.max(0.6, +(z - 0.2).toFixed(1)))} className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:text-foreground">
                <ZoomOut className="h-4 w-4" />
              </button>
              <span className="min-w-10 text-center text-[11px] font-bold tabular-nums">{Math.round(zoom * 100)}%</span>
              <button onClick={() => setZoom((z) => Math.min(3, +(z + 0.2).toFixed(1)))} className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:text-foreground">
                <ZoomIn className="h-4 w-4" />
              </button>
            </div>
            {rendering && <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />}
            <span className="ml-auto max-w-32 truncate text-[10px] font-semibold text-muted-foreground">{pdfFile.name}</span>
          </div>

          {error && <p className="mb-2.5 rounded-xl bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300">⚠️ {error}</p>}

          {/* kanvas halaman */}
          <div className="overflow-auto rounded-2xl bg-black/60 p-2 ring-1 ring-white/10">
            <canvas ref={canvasRef} className="mx-auto rounded-lg bg-white shadow-2xl" />
          </div>

          {/* swipe tip */}
          <p className="mt-2 text-center text-[10px] text-muted-foreground">
            Geser (scroll) buat lihat seluruh halaman • tombol ‹ › buat pindah halaman
          </p>
        </div>
      )}
    </div>
  );
}
