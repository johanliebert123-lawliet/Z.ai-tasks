"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import { Type, Copy, Check, Wand2, Terminal, ArrowUpDown, Binary, Sparkles, Download } from "lucide-react";

/**
 * ASCII Art (zuperupdt — tools tambahan sesuai permintaan pemilik).
 *
 *  KEAMANAN KUNCI: TIDAK memakai API eksternal sama sekali (lebih aman dari
 *  "API gratis" — mustahil menyentuh API key pengguna). Semua huruf & logo
 *  dibangun LOKAL di browser.
 *
 *  - MULTI-VARIAN: Blok (huruf ASCII 5-baris), Terbalik (upside-down),
 *    Leetspeak, Biner, Hex, Lebar (fullwidth), Kecil (3-baris)
 *  - LOGO KALI DRAGON (ASCII) + preset seni lainnya (skull, kucing, panah)
 *  - Salin hasil 1 klik + unduh .txt
 */

/* ================= FONT BLOK 5-BARIS (A-Z 0-9 ?!.,-) ================= */
const FONT: Record<string, string[]> = {
  A: [" █████╗ ", "██╔══██╗", "███████║", "██╔══██║", "╚═╝ ╚═╝"],
  B: ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "╚█████╔╝"],
  C: [" ██████╗", "██╔════╝", "██║     ", "██║     ", "╚██████╗"],
  D: ["██████╗ ", "██╔══██╗", "██║  ██║", "██║  ██║", "╚██████╝"],
  E: ["███████╗", "██╔════╝", "█████╗  ", "██╔══╝  ", "███████╗"],
  F: ["███████╗", "██╔════╝", "█████╗  ", "██╔══╝  ", "╚═╝     "],
  G: [" ██████╗ ", "██╔════╝ ", "██║  ███╗", "██║   ██║", "╚██████╔╝"],
  H: ["██╗  ██╗", "██║  ██║", "███████║", "██╔══██║", "╚═╝  ╚═╝"],
  I: ["██╗", "██║", "██║", "██║", "╚═╝"],
  J: ["     ██╗", "     ██║", "     ██║", "██   ██║", "╚█████╔╝"],
  K: ["██╗  ██╗", "██║ ██╔╝", "█████╔╝ ", "██╔═██╗ ", "╚═╝ ╚═╝ "],
  L: ["██╗     ", "██║     ", "██║     ", "██║     ", "███████╗"],
  M: ["███╗   ███╗", "████╗ ████║", "██╔████╔██║", "██║╚██╔╝██║", "╚═╝ ╚═╝ ╚═╝"],
  N: ["███╗   ██╗", "████╗  ██║", "██╔██╗ ██║", "██║╚██╗██║", "╚═╝ ╚═══╝ "],
  O: [" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║   ██║", "╚██████╔╝"],
  P: ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔═══╝ ", "╚═╝    "],
  Q: [" ██████╗ ", "██╔═══██╗", "██║   ██║", "██║ ██╔╝", "╚█████╔╝"],
  R: ["██████╗ ", "██╔══██╗", "██████╔╝", "██╔══██╗", "╚═╝ ╚═╝ "],
  S: ["███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║"],
  T: ["████████╗", "   ██╔╝ ", "   ██║  ", "   ██║  ", "   ╚═╝  "],
  U: ["██╗   ██╗", "██║   ██║", "██║   ██║", "╚██████╔╝", " ╚═════╝ "],
  V: ["██╗   ██╗", "██║   ██║", "██║   ██║", "╚██╗ ██╔╝", " ╚████╔╝ "],
  W: ["██╗    ██╗", "██║    ██║", "██║ █╗ ██║", "██║███╗██║", "╚███╔███╔╝"],
  X: ["██╗  ██╗", "╚██╗██╔╝", " ╚███╔╝ ", "██╔╝████╗", "╚═╝ ╚═══╝"],
  Y: ["██╗   ██╗", "╚██╗ ██╔╝", " ╚████╔╝ ", "  ╚██╔╝  ", "   ╚═╝   "],
  Z: ["███████╗", "╚══██╔═╝", "   ██║  ", "   ██║  ", "   ╚═╝  "],
  "0": [" ██████╗ ", "██╔═══██╗", "██║▄▄ ██║", "██║██╔██║", "╚██████╔╝"],
  "1": [" ██╗", "███║", "╚██║", " ██║", " ╚═╝"],
  "2": [" ██████╗ ", "██╔════╝ ", "╚█████╗  ", "██╔══╝  ", "███████╗"],
  "3": ["██████╗ ", "╚════██╗", " █████╔╝", "██╔═══╝ ", "███████╗"],
  "4": ["██╗  ██╗", "██║  ██║", "███████║", "     ██║", "     ╚═╝"],
  "5": ["███████╗", "██╔════╝", "███████╗", "╚════██║", "███████║"],
  "6": [" ██████╗ ", "██╔════╝ ", "███████╗ ", "██╔══██║ ", "╚██████╔╝"],
  "7": ["███████╗", "╚════██║", "    ██╔╝", "    ██║ ", "    ╚═╝ "],
  "8": [" █████╗ ", "██╔══██╗", "╚█████╔╝", "██╔══██╗", "╚██████╔╝"],
  "9": [" █████╗ ", "██╔══██╗", "╚██████║", "     ██║", "     ╚═╝"],
  " ": ["   ", "   ", "   ", "   ", "   "],
  "?": ["██████╗ ", "╚════██╗", "   ▄█╔╝", "     ╚╝", "     █ "],
  "!": ["██╗", "██║", "██║", "╚═╝", "██╗"],
  ".": ["    ", "    ", "    ", "    ", " ▪═╝"],
  ",": ["    ", "    ", "    ", "▄▄╗ ", "╚══╝"],
  "-": ["      ", "      ", "█████╗", "      ", "      "],
  "+": ["     ", "  █╗ ", "████║", "  ╚╝ ", "     "],
};

/** Gambar teks dengan font blok. */
function blok(teks: string): string {
  const chars = teks.toUpperCase().split("").slice(0, 24);
  const baris = ["", "", "", "", ""];
  for (const c of chars) {
    const g = FONT[c] || FONT["?"];
    for (let i = 0; i < 5; i++) baris[i] += g[i] + " ";
  }
  return baris.join("\n");
}

/** Font kecil 2 baris (hemat ruang). */
const SMALL: Record<string, string[]> = {
  A: ["▄▀█", "█▀█"], B: ["█▄▄", "█▄█"], C: ["▄▀▀", "▀▄▄"], D: ["█▀▄", "█▄▀"], E: ["█▀▀", "██▄"],
  F: ["█▀▀", "█▀  "], G: ["▄▀▀", "█▄█"], H: ["█ █", "█▄█"], I: ["█", "█"], J: [" ▀█", "█▄█"],
  K: ["█▄▀", "█ █"], L: ["█  ", "█▄▄"], M: ["█▄▪█", "█ ▀ █"], N: ["█▄ █", "█ ▀█"], O: ["▄▀█", "█▄█"],
  P: ["█▀█", "█▀▀"], Q: ["▄▀█", "█▄▀"], R: ["█▀█", "██▀"], S: ["█▀", "▄█"], T: ["▀█▀", " █ "],
  U: ["█ █", "█▄█"], V: ["█ █", "▀▄▀"], W: ["█ ▪█", "█▄▀▄█"], X: ["█ █", " ▀ "], Y: ["█ █", " █ "],
  Z: ["▀▀█", "█▄▄"], " ": ["  ", "  "],
};
function kecil(teks: string): string {
  const chars = teks.toUpperCase().split("").slice(0, 48);
  const b = ["", ""];
  for (const c of chars) {
    const g = SMALL[c] || [" ? ", " ? "];
    b[0] += g[0] + " ";
    b[1] += g[1] + " ";
  }
  return b.join("\n");
}

/* ================= VARIAN TRANSFORMASI ================= */
const LEET: Record<string, string> = { a: "4", A: "4", e: "3", E: "3", i: "1", I: "1", o: "0", O: "0", s: "5", S: "5", t: "7", T: "7", b: "8", B: "8", g: "9", G: "9" };
function leet(teks: string): string {
  return teks.split("").map((c) => LEET[c] || c).join("");
}
function lebar(teks: string): string {
  return teks.split("").map((c) => String.fromCodePoint(c.charCodeAt(0) + 0xfee0)).join("");
}
function biner(teks: string): string {
  return teks.split("").map((c) => c.charCodeAt(0).toString(2).padStart(8, "0")).join(" ");
}
function heks(teks: string): string {
  return teks.split("").map((c) => c.charCodeAt(0).toString(16).padStart(2, "0")).join(" ");
}
const FLIP: Record<string, string> = {
  a: "ɐ", b: "q", c: "ɔ", d: "p", e: "ǝ", f: "ɟ", g: "ƃ", h: "ɥ", i: "ᴉ", j: "ɾ", k: "ʞ", l: "l", m: "ɯ",
  n: "u", o: "o", p: "d", q: "b", r: "ɹ", s: "s", t: "ʇ", u: "n", v: "ʌ", w: "ʍ", x: "x", y: "ʎ", z: "z",
  A: "∀", B: "𐐒", C: "Ɔ", D: "◖", E: "Ǝ", F: "Ⅎ", G: "⅁", H: "H", I: "I", J: "ſ", K: "ʞ", L: "˥", M: "W",
  N: "N", O: "O", P: "Ԁ", Q: "Ò", R: "ᴚ", S: "S", T: "⊥", U: "∩", V: "Λ", W: "M", X: "X", Y: "⅄", Z: "Z",
  "1": "Ɩ", "2": "ᄅ", "3": "Ɛ", "4": "ㄣ", "5": "ϛ", "6": "9", "7": "ㄥ", "8": "8", "9": "6", "0": "0",
  ".": "˙", ",": "'", "?": "¿", "!": "¡", "'": ",", '"': "„", "(": ")", ")": "(", "[": "]", "]": "[",
  "<": ">", ">": "<", "&": "⅋", _: "‾",
};
function terbalik(teks: string): string {
  return teks.split("").reverse().map((c) => FLIP[c] || c).join("");
}

/* ================= PRESET SENI ================= */
const PRESET: Record<string, { judul: string; seni: string }> = {
  kali: {
    judul: "Kali Linux Dragon",
    seni: `            ,.....                                   ,%&@@%&,.
         ,%@@@@@@@%,.                           ,%@@@@@@@@@@@@@@&%,
      ,%@@@@@@@@@@@@@@@%,.                    ,%@@@@@@@@@@@@@@@@@@@@@%,
    ,%@@@@@@@@@@@@@@@@@@@@@%,,            ,,&&@@@@@@@@@@@@@@@@@@@@@@@@%,
   &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%,
   &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%,
   &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%,
    &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
     %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
      &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
       %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
        &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
         %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
          &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
           %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
            &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
             %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
              &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
               %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                 %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                  &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                   %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                    &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                     %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                      &@@@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                       %@@@@@@@@@@@@@@@@@@@@@@@@@@@&.
                        &@@@@@@@@@@@@@@@@@@@@@@@@@&.
                         %@@@@@@@@@@@@@@@@@@@@@@@&.
                          &@@@@@@@@@@@@@@@@@@@@@&.
                           %@@@@@@@@@@@@@@@@@@@&.
                            &@@@@@@@@@@@@@@@@@&.
                             %@@@@@@@@@@@@@@@&.
                              &@@@@@@@@@@@@@&.
                               %@@@@@@@@@@@&.
                                &@@@@@@@@@&.
                                 %@@@@@@@&.
                                  &@@@@@&.
                                   %@@@&.
                                    &&&.`,
  },
  skull: {
    judul: "Tengkorak",
    seni: `      ______
   .-"      "-.
  /            \\
 |,  .-.  .-.  ,|
 | )(_o/  \\o_)( |
 |/     /\\     \\|
 (_     ^^     _)
  \\__|IIIIII|__/
   | \\IIIIII/ |
   \\          /
    \`--------\``,
  },
  kucing: {
    judul: "Kucing",
    seni: ` /\\_/\\  
( o.o ) 
 > ^ <  `,
  },
  sapa: {
    judul: "Sapaan",
    seni: `  __  __ ___ ___ _____ ___ ___ ___    ___ ___ 
 |  \\/  |_ _/ __|_   _|_ _| \\| __|  / __| __|
 | |\\/| || |\\__ \\ | |  | || .\` _|  \\__ \\ _| 
 |_|  |_|___|___/ |_| |___|_|\\___|  |___/___|
                                            `,
  },
};

const VARIAN = [
  { id: "blok", label: "Blok 5-baris", icon: Type },
  { id: "kecil", label: "Kecil 2-baris", icon: Type },
  { id: "lebar", label: "Lebar (fullwidth)", icon: ArrowUpDown },
  { id: "leet", label: "Leetspeak", icon: Wand2 },
  { id: "terbalik", label: "Terbalik", icon: ArrowUpDown },
  { id: "biner", label: "Biner", icon: Binary },
  { id: "heks", label: "Hexadesimal", icon: Binary },
] as const;

export default function AsciiView() {
  const [teks, setTeks] = useState("FANZZTOOLS");
  const [varian, setVarian] = useState<(typeof VARIAN)[number]["id"]>("blok");
  const [preset, setPreset] = useState<string | null>("kali");
  const [salin, setSalin] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    pushHistory("ascii", { id: "ascii-art", title: "ASCII Art", subtitle: "Multi-varian + logo Kali dragon" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hasil = useMemo(() => {
    const t = teks.slice(0, 64);
    switch (varian) {
      case "blok": return blok(t);
      case "kecil": return kecil(t);
      case "lebar": return lebar(t);
      case "leet": return leet(t);
      case "terbalik": return terbalik(t);
      case "biner": return biner(t);
      case "heks": return heks(t);
      default: return t;
    }
  }, [teks, varian]);

  const salinHasil = () => {
    navigator.clipboard?.writeText(hasil).then(() => {
      setSalin(true);
      setTimeout(() => setSalin(false), 1600);
      toast({ title: "ASCII tersalin!" });
    }).catch(() => toast({ title: "Gagal menyalin", variant: "destructive" }));
  };

  const unduh = () => {
    const blob = new Blob([hasil], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ascii-${varian}.txt`;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 3000);
  };

  const tampil = preset ? PRESET[preset].seni : hasil;

  return (
    <div>
      <ToolHeader icon={<Terminal className="h-5.5 w-5.5" />} title="ASCII Art" subtitle="Multi-varian • logo Kali dragon • 100% lokal tanpa API key" accent="cyan" />

      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        {/* kontrol */}
        <div className="glass rounded-2xl p-4">
          <p className="text-sm font-extrabold">1. Tulis teksmu</p>
          <Input
            value={teks}
            onChange={(e) => { setTeks(e.target.value); setPreset(null); }}
            placeholder="mis. FanzzTools / nama kamu"
            maxLength={64}
            className="mt-2 rounded-xl"
          />
          <p className="mt-1 text-[9.5px] text-muted-foreground">Maksimal 64 karakter (varian blok: 24 pertama dipakai).</p>

          <p className="mt-4 text-sm font-extrabold">2. Pilih varian</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {VARIAN.map((v) => (
              <button
                key={v.id}
                onClick={() => { setVarian(v.id); setPreset(null); }}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10.5px] font-bold transition ${
                  varian === v.id && !preset ? "bg-gradient-to-r from-cyan-500 to-sky-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                <v.icon className="h-3 w-3" /> {v.label}
              </button>
            ))}
          </div>

          <p className="mt-4 text-sm font-extrabold">3. Atau pakai karya siap pakai</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {Object.entries(PRESET).map(([k, p]) => (
              <button
                key={k}
                onClick={() => setPreset(k)}
                className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10.5px] font-bold transition ${
                  preset === k ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                <Sparkles className="h-3 w-3" /> {p.judul}
              </button>
            ))}
          </div>

          <div className="mt-4 flex gap-2">
            <button onClick={salinHasil} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 px-3 py-2.5 text-[11px] font-extrabold text-white">
              {salin ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />} Salin
            </button>
            <button onClick={unduh} className="flex items-center justify-center gap-1.5 rounded-xl bg-secondary px-3 py-2.5 text-[11px] font-extrabold text-muted-foreground">
              <Download className="h-3.5 w-3.5" /> .txt
            </button>
          </div>

          <p className="mt-3 rounded-xl bg-emerald-500/10 p-2.5 text-[9.5px] leading-relaxed text-emerald-200/80">
            Semua digenerate LANGSUNG di perangkatmu — tanpa server, tanpa API eksternal, tanpa API key pengguna sepenuhnya.
          </p>
        </div>

        {/* hasil */}
        <div className="glass min-w-0 rounded-2xl p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-sm font-extrabold">{preset ? PRESET[preset].judul : `Hasil — ${VARIAN.find((v) => v.id === varian)?.label}`}</p>
            <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-black text-muted-foreground">{tampil.split("\n").length} baris</span>
          </div>
          <motion.div
            key={`${varian}-${preset}-${teks}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="max-h-[520px] overflow-auto rounded-xl bg-black/60 p-4"
          >
            <pre className="whitespace-pre text-left font-mono text-[8px] leading-[1.15] text-emerald-300 sm:text-[10px]" data-fanzz-selectable="1">
              {tampil || "(kosong)"}
            </pre>
          </motion.div>
          <p className="mt-2 text-[9.5px] text-muted-foreground">
            Tips: hasil blok terlihat terbaik di font monospace (VS Code, notepad, editor teks). Tempel di bio/profile atau terminal-mu.
          </p>
          {!teks && !preset && (
            <div className="mt-3">
              <EmptyState icon={<Type className="h-8 w-8" />} title="Belum ada teks" desc="Tulis teks di panel kiri atau pilih karya siap pakai seperti logo Kali dragon." />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
