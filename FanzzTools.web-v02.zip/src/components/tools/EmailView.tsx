"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { useApp } from "@/lib/app-store";
import {
  MailPlus, Mail, RefreshCw, Copy, Inbox, KeyRound, Link2, Loader2, Trash2, Zap, Clock, ShieldCheck,
} from "lucide-react";

interface MailMsg {
  id: string;
  from: string;
  subject: string;
  preview: string;
  date: string;
  otp: string | null;
  verifyLink: string | null;
}

export default function EmailView() {
  const [email, setEmail] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [messages, setMessages] = useState<MailMsg[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [lastCheck, setLastCheck] = useState<Date | null>(null);
  const { setView } = useApp();
  const { toast } = useToast();
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async (addr?: string) => {
    const target = addr || email;
    if (!target) return;
    setRefreshing(true);
    try {
      const res = await fetch(`/api/email/messages?email=${encodeURIComponent(target)}`);
      const d = await res.json();
      if (d?.ok) {
        setMessages(d.messages || []);
        setLastCheck(new Date());
      }
    } catch {
      /* silent biar polling nyaman */
    } finally {
      setRefreshing(false);
    }
  }, [email]);

  const create = async () => {
    if (creating) return;
    setCreating(true);
    setMessages([]);
    setExpanded(null);
    try {
      const res = await fetch("/api/email/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const d = await res.json();
      if (!d?.ok || !d.email) throw new Error(d?.error || "Gagal membuat email");
      setEmail(d.email);
      setLastCheck(new Date());
      toast({ title: "Email trial siap! 📬", description: d.email });
    } catch (e) {
      toast({
        title: "Gagal bikin email 😢",
        description: e instanceof Error ? e.message : "Coba lagi",
        variant: "destructive",
      });
    } finally {
      setCreating(false);
    }
  };

  // auto refresh tiap 7 detik
  useEffect(() => {
    if (!autoRefresh || !email) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    refresh(email);
    timerRef.current = setInterval(() => refresh(email), 7000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [autoRefresh, email, refresh]);

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => toast({ title: `${label} dicopy! 📋` }));
  };

  const anyOtp = messages.find((m) => m.otp)?.otp;

  return (
    <div>
      <ToolHeader icon={<MailPlus className="h-5.5 w-5.5" />} title="Generate Email Trial" subtitle="Email sementara + auto deteksi OTP" accent="amber" />

      {/* kartu email */}
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass relative overflow-hidden rounded-3xl p-5">
        <div className="pointer-events-none absolute -right-14 -top-14 h-40 w-40 rounded-full bg-amber-500/20 blur-3xl" />
        {email ? (
          <>
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-amber-300/80">
              <Inbox className="h-3.5 w-3.5" /> Email Aktif Lo
            </div>
            <div className="mt-2 flex items-center gap-2">
              <p className="min-w-0 flex-1 truncate rounded-xl bg-secondary/60 px-3.5 py-3 font-mono text-sm font-bold text-amber-200">{email}</p>
              <button onClick={() => copy(email, "Email")} className="shrink-0 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 p-3 text-white shadow-lg shadow-amber-500/20 transition-transform hover:scale-105 active:scale-95">
                <Copy className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Button variant="secondary" size="sm" onClick={() => refresh()} disabled={refreshing} className="rounded-xl glass px-3">
                {refreshing ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="mr-1.5 h-3.5 w-3.5" />}
                Refresh
              </Button>
              <button
                onClick={() => setAutoRefresh(!autoRefresh)}
                className={`rounded-xl px-3 py-2 text-xs font-bold transition-colors ${autoRefresh ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-400/30" : "glass text-muted-foreground"}`}
              >
                <Zap className={`mr-1.5 inline h-3.5 w-3.5 ${autoRefresh ? "text-emerald-400" : ""}`} />
                Auto {autoRefresh ? "ON" : "OFF"}
              </button>
              <Button variant="secondary" size="sm" onClick={create} disabled={creating} className="rounded-xl glass px-3 text-amber-300">
                {creating ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <MailPlus className="mr-1.5 h-3.5 w-3.5" />}
                Email Baru
              </Button>
              {lastCheck && (
                <span className="ml-auto flex items-center gap-1 text-[10px] text-muted-foreground">
                  <Clock className="h-3 w-3" /> {lastCheck.toLocaleTimeString("id-ID")}
                </span>
              )}
            </div>
          </>
        ) : (
          <div className="py-6 text-center">
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ repeat: Infinity, duration: 2.6 }}
              className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-amber-400 to-orange-600 shadow-xl shadow-amber-500/25"
            >
              <Mail className="h-8 w-8 text-white" />
            </motion.div>
            <p className="mt-4 text-lg font-extrabold">Butuh email sementara?</p>
            <p className="mx-auto mt-1.5 max-w-[260px] text-xs leading-relaxed text-muted-foreground">
              Generate email trial instan buat daftar akun apapun — OTP & link verifikasi otomatis kebaca di sini.
            </p>
            <Button
              onClick={create}
              disabled={creating}
              className="mt-5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-6 py-5 text-sm font-bold shadow-xl shadow-amber-500/25 transition-transform hover:scale-105 active:scale-95"
            >
              {creating ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <MailPlus className="mr-2 h-4.5 w-4.5" />}
              Generate Email Trial
            </Button>
          </div>
        )}
      </motion.div>

      {/* OTP besar kalau ada */}
      <AnimatePresence>
        {anyOtp && (
          <motion.button
            initial={{ opacity: 0, y: 12, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.96 }}
            onClick={() => copy(anyOtp, "OTP")}
            className="mt-4 flex w-full items-center gap-4 rounded-3xl bg-gradient-to-r from-amber-500/15 to-orange-500/15 p-5 text-left ring-1 ring-amber-400/30"
          >
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-500/20 text-amber-300">
              <KeyRound className="h-6 w-6" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[10px] font-bold uppercase tracking-wider text-amber-300/80">Kode OTP Terdeteksi</p>
              <p className="font-mono text-2xl font-extrabold tracking-[0.2em] text-amber-200">{anyOtp}</p>
            </div>
            <span className="rounded-xl bg-amber-500 px-3 py-2 text-[11px] font-bold text-white">COPY</span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* inbox */}
      {email && (
        <section className="mt-4">
          <h3 className="mb-2.5 flex items-center justify-between text-sm font-bold">
            <span className="flex items-center gap-2"><Inbox className="h-4 w-4 text-amber-400" /> Inbox ({messages.length})</span>
          </h3>
          {messages.length === 0 ? (
            <div className="flex flex-col items-center gap-2 rounded-2xl border border-dashed border-border/60 py-10 text-center">
              <Loader2 className="h-5 w-5 animate-spin text-amber-400/70" />
              <p className="text-xs font-semibold text-muted-foreground">Nunggu email masuk...</p>
              <p className="max-w-[240px] text-[11px] text-muted-foreground/70">
                Kirim / daftar pakai email di atas, pesan bakal muncul otomatis di sini.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {messages.map((m, i) => (
                <motion.button
                  key={m.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => setExpanded(expanded === m.id ? null : m.id)}
                  className="w-full rounded-2xl glass p-3.5 text-left transition-colors hover:bg-secondary/60"
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-300">
                      <Mail className="h-4 w-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <p className="truncate text-xs font-bold">{m.subject}</p>
                        <span className="shrink-0 text-[10px] text-muted-foreground">
                          {new Date(m.date).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>
                      <p className="truncate text-[11px] text-muted-foreground">dari: {m.from}</p>
                      {m.otp && (
                        <span className="mt-1.5 inline-flex items-center gap-1 rounded-lg bg-amber-500/15 px-2 py-0.5 font-mono text-[11px] font-bold text-amber-300">
                          <KeyRound className="h-3 w-3" /> {m.otp}
                        </span>
                      )}
                      {expanded === m.id && (
                        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mt-2">
                          <p className="whitespace-pre-wrap break-words rounded-xl bg-secondary/60 p-3 text-[11px] leading-relaxed text-muted-foreground">{m.preview}</p>
                          {m.verifyLink && (
                            <span className="mt-2 flex items-center gap-1.5 break-all rounded-xl bg-cyan-500/10 px-3 py-2 text-[11px] font-medium text-cyan-300">
                              <Link2 className="h-3 w-3 shrink-0" /> {m.verifyLink}
                            </span>
                          )}
                        </motion.div>
                      )}
                    </div>
                  </div>
                </motion.button>
              ))}
            </div>
          )}
        </section>
      )}

      {/* synergy hint */}
      {email && (
        <div className="mt-4 flex items-start gap-2.5 rounded-2xl glass p-4">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <p className="text-[11px] leading-relaxed text-muted-foreground">
            <b className="text-foreground">Tips:</b> email ini bisa langsung dipakai buat aktivasi{" "}
            <button onClick={() => setView("am")} className="font-bold text-cyan-300 underline underline-offset-2">AM Active</button>{" "}
            — magic link-nya bakal muncul di inbox atas, tinggal copy!
          </p>
        </div>
      )}
    </div>
  );
}
