"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useApp, getFavSongs, getWatchHistory } from "@/lib/app-store";
import ChatThread from "@/components/chat/ChatThread";
import {
  MessageCircle, Search, Loader2, Users, UserPlus, UserCheck, User as UserIcon,
  ArrowLeft, UsersRound, Music4, Clapperboard, Globe2, Send, ChevronRight,
  Plus, Crown, Shield, ShieldOff, LogOut, UserMinus, X, ArrowRight,
} from "lucide-react";

interface PublicProfile {
  uid: string;
  /** ID publik pendek (LT-XXXXXX) — V0.01 #15 */
  fanzzId?: string;
  username: string;
  country: string | null;
  countryCode: string | null;
  city: string | null;
  bio: string | null;
  /** V2 UpdSec: foto profil user (data URL) — tampil di daftar chat & profil */
  avatar: string | null;
  avatarColor: string;
  favSongs: Array<{ title: string; artist: string; thumb?: string }>;
  watched: Array<{ title: string; poster?: string | null; type?: string }>;
  followers: number;
  following: number;
  online: boolean;
  lastSeen: number;
}

interface ConvItem {
  peer: PublicProfile;
  last: { text: string; type: string; ts: number; from: string };
  unread: number;
}

interface GroupInfo {
  gid: string;
  name: string;
  desc: string | null;
  owner: string;
  admins: string[];
  members: number;
  avatarColor: string;
  createdAt: number;
  lastActive: number;
}

interface GroupMember extends PublicProfile {
  isOwner: boolean;
  isAdmin: boolean;
}

const FLAG: Record<string, string> = {
  ID: "🇮🇩", US: "🇺🇸", GB: "🇬🇧", RU: "🇷🇺", MY: "🇲🇾", SG: "🇸🇬", JP: "🇯🇵",
  KR: "🇰🇷", CN: "🇨🇳", IN: "🇮🇳", AU: "🇦🇺", DE: "🇩🇪", FR: "🇫🇷", NL: "🇳🇱",
  SA: "🇸🇦", AE: "🇦🇪", TH: "🇹🇭", VN: "🇻🇳", PH: "🇵🇭", BR: "🇧🇷", CA: "🇨🇦",
  TR: "🇹🇷", EG: "🇪🇬", PK: "🇵🇰", BD: "🇧🇩", ES: "🇪🇸", IT: "🇮🇹", PT: "🇵🇹",
};

function flagOf(code: string | null): string {
  return (code && FLAG[code.toUpperCase()]) || "🌏";
}

function timeAgo(ts: number): string {
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return "baru saja";
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  return `${Math.floor(s / 86400)} hari lalu`;
}

type Tab = "chats" | "search" | "groups";

export default function ChatView() {
  const { chatPeer, geo, user } = useApp();
  const [tab, setTab] = useState<Tab>("chats");
  const [thread, setThread] = useState<{ uid: string; name: string; group?: boolean } | null>(null);
  const [convs, setConvs] = useState<ConvItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [users, setUsers] = useState<PublicProfile[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [profileCard, setProfileCard] = useState<PublicProfile | null>(null);
  const [followMap, setFollowMap] = useState<Record<string, boolean>>({});
  const [peopleList, setPeopleList] = useState<{ mode: "followers" | "following"; uid: string; users: PublicProfile[] } | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const profileSyncedRef = useRef(false);

  // deep-link chat dari view lain
  useEffect(() => {
    if (chatPeer) {
      setThread(chatPeer);
      useApp.setState({ chatPeer: null });
    }
  }, [chatPeer]);

  /** Daftar percakapan + profil (sync lokasi & favorit sekali). */
  const loadConvs = useCallback(async () => {
    try {
      const r = await fetch("/api/social/conversations");
      const d = await r.json();
      if (d?.ok) setConvs(d.conversations);
    } catch {
      /* ignore */
    }
  }, []);

  // sync profil: lokasi + favorit lagu + riwayat nonton (sekali per sesi)
  useEffect(() => {
    if (profileSyncedRef.current) return;
    profileSyncedRef.current = true;
    (async () => {
      try {
        const fav = getFavSongs()[0];
        const hist = getWatchHistory()[0];
        await fetch("/api/social/profile", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...(geo?.negara ? { country: geo.negara } : {}),
            ...(geo?.countryCode ? { countryCode: geo.countryCode } : {}),
            ...(geo?.kota ? { city: geo.kota } : {}),
            ...(fav ? { favSong: { title: fav.title, artist: fav.artist, thumb: fav.thumbnail } } : {}),
            ...(hist ? { watched: { title: hist.title, poster: hist.poster, type: hist.type } } : {}),
          }),
        });
      } catch {
        /* best effort */
      }
    })();
  }, [geo]);

  useEffect(() => {
    loadConvs();
    const t = setInterval(loadConvs, 5000);
    return () => clearInterval(t);
  }, [loadConvs, thread]);

  // pencarian user (debounce)
  const doSearch = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/social/users?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        if (d?.ok) setUsers(d.users);
      } catch {
        setUsers([]);
      } finally {
        setSearching(false);
      }
    }, 350);
  }, []);

  const openThread = (uid: string, name: string, group = false) => {
    setThread({ uid, name, group });
  };

  const doFollow = async (uid: string) => {
    try {
      const r = await fetch("/api/social/follow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: uid }),
      });
      const d = await r.json();
      if (d?.ok) {
        setFollowMap((m) => ({ ...m, [uid]: d.following }));
        if (profileCard?.uid === uid && d.user) setProfileCard(d.user);
      }
    } catch {
      /* ignore */
    }
  };

  const openProfile = async (uid: string) => {
    try {
      const r = await fetch(`/api/social/users?uid=${encodeURIComponent(uid)}`);
      const d = await r.json();
      if (d?.ok) {
        setProfileCard(d.user);
        setFollowMap((m) => ({ ...m, [uid]: Boolean(d.isFollowing) }));
      }
    } catch {
      /* ignore */
    }
  };

  /** Buka daftar followers / following user. */
  const openPeopleList = async (uid: string, mode: "followers" | "following") => {
    try {
      const r = await fetch(`/api/social/users?uid=${encodeURIComponent(uid)}&list=${mode}`);
      const d = await r.json();
      if (d?.ok) setPeopleList({ mode, uid, users: d.users || [] });
    } catch {
      /* ignore */
    }
  };

  /* ================= THREAD TERBUKA ================= */
  if (thread) {
    return (
      <div className="flex h-[calc(100dvh-190px)] flex-col md:h-[calc(100dvh-150px)]">
        <ChatThread key={thread.uid + (thread.group ? "-g" : "")} peer={thread} group={thread.group} onBack={() => setThread(null)} />
      </div>
    );
  }

  return (
    <div>
      <ToolHeader icon={<MessageCircle className="h-5.5 w-5.5" />} title="Chat Sosial" subtitle="Chat realtime • grup • follow • VN • foto" accent="fuchsia" />

      {/* tabs */}
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        {([
          { id: "chats", label: "Chat", icon: MessageCircle },
          { id: "search", label: "Cari Pengguna", icon: Search },
          { id: "groups", label: "Grup", icon: UsersRound },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === t.id && <motion.span layoutId="chat-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-red-500 to-red-700" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* ============ TAB: DAFTAR CHAT ============ */}
        {tab === "chats" && (
          <motion.div key="chats" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
            {convs === null ? (
              <div className="space-y-2">
                {[0, 1, 2].map((i) => <div key={i} className="h-16 rounded-2xl shimmer" />)}
              </div>
            ) : convs.length === 0 ? (
              <EmptyState
                icon={<MessageCircle className="h-6 w-6" />}
                title="Belum ada obrolan"
                desc="Cari pengguna di tab Cari Pengguna, lalu mulai ngobrol!"
              />
            ) : (
              <div className="space-y-2">
                {convs.map((c) => (
                  <button
                    key={c.peer.uid}
                    onClick={() => openThread(c.peer.uid, c.peer.username)}
                    className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
                  >
                    <div className="relative shrink-0">
                      {c.peer.avatar ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={c.peer.avatar} alt={c.peer.username} className="h-11 w-11 rounded-xl object-cover" />
                      ) : (
                        <div className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${c.peer.avatarColor} text-sm font-extrabold text-white`}>
                          {c.peer.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                      {c.peer.online && <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-background bg-emerald-500" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-1.5 truncate text-sm font-bold">
                        {c.peer.username}
                        <span className="text-[10px]">{flagOf(c.peer.countryCode)}</span>
                      </p>
                      <p className="truncate text-[11px] text-muted-foreground">
                        {c.last.from === user?.uid ? "Kamu: " : ""}{c.last.text}
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="text-[9px] text-muted-foreground">{timeAgo(c.last.ts)}</p>
                      {c.unread > 0 && (
                        <span className="mt-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-red-500 px-1.5 text-[10px] font-extrabold text-white">
                          {c.unread}
                        </span>
                      )}
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* ============ TAB: CARI PENGGUNA ============ */}
        {tab === "search" && (
          <motion.div key="search" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            <div className="relative mb-4">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  doSearch(e.target.value);
                }}
                placeholder="Cari username / negara... (misal: andi, rusia)"
                className="w-full rounded-xl border border-border/60 bg-secondary/50 py-3.5 pl-10 pr-3 text-sm outline-none focus:border-red-400/50"
              />
              {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-red-400" />}
            </div>

            {users === null ? (
              <p className="py-6 text-center text-xs text-muted-foreground">Ketik buat mulai nyari pengguna FanzzTools…</p>
            ) : users.length === 0 ? (
              <EmptyState
                icon={<UserPlus className="h-6 w-6" />}
                title="Belum ada yang ketemu"
                desc="User lain harus daftar dulu di FanzzTools biar muncul di pencarian."
              />
            ) : (
              <div className="space-y-2">
                {users.map((u) => (
                  <div key={u.uid} className="flex items-center gap-3 rounded-2xl glass p-3">
                    <button onClick={() => openProfile(u.uid)} className="relative shrink-0">
                      {u.avatar ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={u.avatar} alt={u.username} className="h-11 w-11 rounded-xl object-cover" />
                      ) : (
                        <div className={`flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br ${u.avatarColor} text-sm font-extrabold text-white`}>
                          {u.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                      {u.online && <span className="absolute -bottom-0.5 -right-0.5 h-3.5 w-3.5 rounded-full border-2 border-background bg-emerald-500" />}
                    </button>
                    <button onClick={() => openProfile(u.uid)} className="min-w-0 flex-1 text-left">
                      <p className="flex items-center gap-1.5 truncate text-sm font-bold">
                        {u.username}
                        <span className="text-[10px]">{flagOf(u.countryCode)}</span>
                      </p>
                      <p className="truncate text-[11px] text-muted-foreground">
                        {u.country || "Lokasi dirahasiakan"} • {u.followers} follower
                      </p>
                    </button>
                    <button
                      onClick={() => openThread(u.uid, u.username)}
                      className="flex shrink-0 items-center gap-1 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3 py-2 text-[11px] font-bold text-white shadow-lg shadow-red-500/20 transition-transform active:scale-95"
                    >
                      <Send className="h-3.5 w-3.5" /> Chat
                    </button>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {/* ============ TAB: GRUP ============ */}
        {tab === "groups" && (
          <motion.div key="groups" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            <GroupSection onOpenGroup={(gid, name) => openThread(gid, name, true)} onOpenProfile={openProfile} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============ MODAL DAFTAR FOLLOWERS/FOLLOWING ============ */}
      <AnimatePresence>
        {peopleList && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm md:items-center"
            onClick={() => setPeopleList(null)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[70vh] w-full max-w-md overflow-hidden rounded-t-3xl glass-strong md:rounded-3xl"
            >
              <div className="flex items-center justify-between border-b border-[var(--surface-line)] p-4">
                <p className="text-sm font-extrabold">
                  {peopleList.mode === "followers" ? "👥 Pengikut" : "➡️ Diikuti"} ({peopleList.users.length})
                </p>
                <button onClick={() => setPeopleList(null)} className="rounded-xl p-1.5 text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>
              <div className="max-h-[56vh] space-y-1.5 overflow-y-auto p-3">
                {peopleList.users.length === 0 ? (
                  <p className="py-8 text-center text-xs text-muted-foreground">Belum ada yang {peopleList.mode === "followers" ? "mengikuti" : "diikuti"}</p>
                ) : (
                  peopleList.users.map((u) => (
                    <button
                      key={u.uid}
                      onClick={() => {
                        setPeopleList(null);
                        openProfile(u.uid);
                      }}
                      className="flex w-full items-center gap-3 rounded-xl bg-secondary/50 px-3 py-2.5 text-left transition-colors hover:bg-secondary"
                    >
                      {u.avatar ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={u.avatar} alt={u.username} className="h-9 w-9 shrink-0 rounded-lg object-cover" />
                      ) : (
                        <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${u.avatarColor} text-xs font-extrabold text-white`}>
                          {u.username.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold">
                          {u.username} <span className="text-[10px]">{flagOf(u.countryCode)}</span>
                        </p>
                        <p className="truncate text-[10px] text-muted-foreground">{u.country || "—"} • {u.followers} follower</p>
                      </div>
                      <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    </button>
                  ))
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ============ KARTU PROFIL USER ============ */}
      <AnimatePresence>
        {profileCard && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm md:items-center"
            onClick={() => { setProfileCard(null); setPeopleList(null); }}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-t-3xl glass-strong p-5 md:rounded-3xl"
            >
              <div className="flex items-center gap-3.5">
                {profileCard.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={profileCard.avatar} alt={profileCard.username} className="h-16 w-16 shrink-0 rounded-2xl border-2 border-red-400/40 object-cover" />
                ) : (
                  <div className={`flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${profileCard.avatarColor} text-xl font-extrabold text-white`}>
                    {profileCard.username.charAt(0).toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-lg font-extrabold">{profileCard.username}</p>
                  <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <Globe2 className="h-3 w-3 text-red-400" />
                    {flagOf(profileCard.countryCode)} {profileCard.country || "Lokasi dirahasiakan"}
                    {profileCard.city ? ` • ${profileCard.city}` : ""}
                  </p>
                  <p className="mt-0.5 text-[10px] text-muted-foreground">
                    {profileCard.online ? "🟢 online" : `aktif ${timeAgo(profileCard.lastSeen)}`}
                  </p>
                </div>
                <button onClick={() => setProfileCard(null)} className="shrink-0 rounded-xl p-2 text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* followers / following — bisa diklik buat lihat siapa aja */}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  onClick={() => openPeopleList(profileCard.uid, "followers")}
                  className="flex items-center gap-2.5 rounded-xl bg-secondary/50 px-3.5 py-2.5 text-left transition-colors hover:bg-secondary"
                >
                  <Users className="h-4 w-4 shrink-0 text-red-400" />
                  <div>
                    <p className="text-sm font-extrabold leading-none">{profileCard.followers}</p>
                    <p className="mt-0.5 text-[9.5px] font-bold text-muted-foreground">Pengikut — ketuk lihat</p>
                  </div>
                </button>
                <button
                  onClick={() => openPeopleList(profileCard.uid, "following")}
                  className="flex items-center gap-2.5 rounded-xl bg-secondary/50 px-3.5 py-2.5 text-left transition-colors hover:bg-secondary"
                >
                  <UserCheck className="h-4 w-4 shrink-0 text-cyan-400" />
                  <div>
                    <p className="text-sm font-extrabold leading-none">{profileCard.following}</p>
                    <p className="mt-0.5 text-[9.5px] font-bold text-muted-foreground">Mengikuti — ketuk lihat</p>
                  </div>
                </button>
              </div>

              {profileCard.bio && <p className="mt-3 rounded-xl bg-secondary/50 px-3 py-2 text-xs">{profileCard.bio}</p>}

              {/* lagu favorit */}
              {profileCard.favSongs.length > 0 && (
                <div className="mt-3">
                  <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
                    <Music4 className="h-3.5 w-3.5 text-cyan-400" /> Lagu favorit
                  </p>
                  <div className="space-y-1.5">
                    {profileCard.favSongs.map((s, i) => (
                      <div key={i} className="flex items-center gap-2.5 rounded-xl bg-secondary/40 px-3 py-2">
                        {s.thumb ? (
                          <img src={s.thumb} alt="" className="h-8 w-8 rounded-lg object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-300"><Music4 className="h-4 w-4" /></div>
                        )}
                        <div className="min-w-0">
                          <p className="truncate text-xs font-semibold">{s.title}</p>
                          <p className="truncate text-[10px] text-muted-foreground">{s.artist}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* riwayat nonton */}
              {profileCard.watched.length > 0 && (
                <div className="mt-3">
                  <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
                    <Clapperboard className="h-3.5 w-3.5 text-red-400" /> Udh nonton
                  </p>
                  <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
                    {profileCard.watched.map((w, i) => (
                      <div key={i} className="w-20 shrink-0">
                        {w.poster ? (
                          <img src={w.poster} alt="" className="h-28 w-20 rounded-lg object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="flex h-28 w-20 items-center justify-center rounded-lg bg-secondary"><Clapperboard className="h-5 w-5 text-muted-foreground" /></div>
                        )}
                        <p className="mt-1 truncate text-[9px] font-semibold">{w.title}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* tombol aksi */}
              <div className="mt-4 flex gap-2">
                <button
                  onClick={() => doFollow(profileCard.uid)}
                  className={`flex flex-1 items-center justify-center gap-1.5 rounded-xl py-3 text-xs font-bold transition-all active:scale-95 ${
                    followMap[profileCard.uid]
                      ? "bg-secondary text-muted-foreground ring-1 ring-border"
                      : "bg-gradient-to-r from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/20"
                  }`}
                >
                  {followMap[profileCard.uid]
                    ? <><UserCheck className="h-4 w-4" /> Mengikuti</>
                    : <><UserPlus className="h-4 w-4" /> Follow</>}
                </button>
                <button
                  onClick={() => {
                    const p = profileCard;
                    setProfileCard(null);
                    openThread(p.uid, p.username);
                  }}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-3 text-xs font-bold text-white shadow-lg shadow-red-500/20 transition-transform active:scale-95"
                >
                  <Send className="h-4 w-4" /> Chat
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= TAB GRUP ================= */

function GroupSection({
  onOpenGroup,
  onOpenProfile,
}: {
  onOpenGroup: (gid: string, name: string) => void;
  onOpenProfile: (uid: string) => void;
}) {
  const [mine, setMine] = useState<GroupInfo[] | null>(null);
  const [discover, setDiscover] = useState<GroupInfo[] | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [gName, setGName] = useState("");
  const [gDesc, setGDesc] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [openGid, setOpenGid] = useState<string | null>(null);
  const [members, setMembers] = useState<GroupMember[] | null>(null);
  const [myRole, setMyRole] = useState<{ isAdmin: boolean; isOwner: boolean } | null>(null);
  const [groupInfo, setGroupInfo] = useState<GroupInfo | null>(null);

  const loadGroups = useCallback(async () => {
    try {
      const r = await fetch("/api/social/groups");
      const d = await r.json();
      if (d?.ok) {
        setMine(d.mine || []);
        setDiscover(d.discover || []);
      }
    } catch {
      setMine([]);
      setDiscover([]);
    }
  }, []);

  useEffect(() => {
    loadGroups();
  }, [loadGroups]);

  const loadGroupDetail = useCallback(async (gid: string) => {
    setMembers(null);
    try {
      const r = await fetch(`/api/social/group?gid=${encodeURIComponent(gid)}`);
      const d = await r.json();
      if (d?.ok) {
        setGroupInfo(d.group);
        setMembers(d.members || []);
        setMyRole(d.you);
      }
    } catch {
      setMembers([]);
    }
  }, []);

  useEffect(() => {
    if (openGid) loadGroupDetail(openGid);
  }, [openGid, loadGroupDetail]);

  const createGroup = async () => {
    if (busy || gName.trim().length < 3) return;
    setBusy(true);
    setErr("");
    try {
      const r = await fetch("/api/social/group", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "create", name: gName.trim(), desc: gDesc.trim() || undefined }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal bikin grup");
      setShowCreate(false);
      setGName("");
      setGDesc("");
      await loadGroups();
      setOpenGid(d.group.gid);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Gagal bikin grup");
    } finally {
      setBusy(false);
    }
  };

  const groupAction = async (action: string, gid: string, target?: string) => {
    try {
      const r = await fetch("/api/social/group", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, gid, target }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Aksi gagal");
      if (action === "leave") {
        setOpenGid(null);
        await loadGroups();
      } else {
        await loadGroupDetail(gid);
        if (action === "add" && d.added) {
          setErr("");
        }
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Aksi gagal");
    }
  };

  /* V0.01 (#15): tambah anggota oleh admin/owner via ID/username */
  const [addTarget, setAddTarget] = useState("");
  const [addBusy, setAddBusy] = useState(false);
  const doAddMember = async () => {
    const t = addTarget.trim();
    if (!t || !openGid || addBusy) return;
    setAddBusy(true);
    setErr("");
    try {
      const r = await fetch("/api/social/group", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "add", gid: openGid, target: t }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal menambahkan anggota");
      setAddTarget("");
      await loadGroupDetail(openGid);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Gagal menambahkan anggota");
    } finally {
      setAddBusy(false);
    }
  };

  /* ---- DETAIL GRUP (anggota + admin) ---- */
  if (openGid) {
    return (
      <div>
        <button onClick={() => setOpenGid(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Semua grup
        </button>

        {err && <p className="mb-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300">⚠️ {err}</p>}

        {groupInfo && (
          <div className="mb-4 flex items-center gap-3.5 rounded-2xl glass p-4">
            <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br ${groupInfo.avatarColor} text-white`}>
              <UsersRound className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-extrabold">{groupInfo.name}</p>
              <p className="text-[11px] text-muted-foreground">
                {groupInfo.members} anggota • {groupInfo.desc || "tanpa deskripsi"}
              </p>
            </div>
            <button
              onClick={() => onOpenGroup(groupInfo.gid, groupInfo.name)}
              className="flex shrink-0 items-center gap-1 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3 py-2.5 text-[11px] font-bold text-white shadow-lg shadow-red-500/20 active:scale-95"
            >
              <Send className="h-3.5 w-3.5" /> Buka Chat
            </button>
          </div>
        )}

        {/* kelola anggota */}
        <div className="mb-3 flex items-center justify-between">
          <p className="text-sm font-bold">Anggota ({members?.length ?? "..."})</p>
          {myRole && (
            <span className="rounded-full bg-red-500/15 px-2.5 py-1 text-[9.5px] font-extrabold text-red-300">
              {myRole.isOwner ? "KAMU OWNER" : myRole.isAdmin ? "KAMU ADMIN" : "ANGGOTA"}
            </span>
          )}
        </div>

        {/* V0.01 (#15): admin menambahkan anggota via ID FanzzTools / username */}
        {myRole?.isOwner || myRole?.isAdmin ? (
          <div className="mb-3 rounded-2xl glass p-2.5">
            <p className="mb-1.5 flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
              <UserPlus className="h-3 w-3" /> Tambahkan anggota — masukkan ID (LT-XXXXXX) atau username
            </p>
            <div className="flex gap-2">
              <input
                value={addTarget}
                onChange={(e) => setAddTarget(e.target.value.slice(0, 40))}
                onKeyDown={(e) => e.key === "Enter" && doAddMember()}
                placeholder="LT-2K7X9A atau username"
                className="min-w-0 flex-1 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-red-400/50"
              />
              <button
                onClick={doAddMember}
                disabled={!addTarget.trim() || addBusy}
                className="shrink-0 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3.5 py-2.5 text-xs font-bold text-white disabled:opacity-40"
              >
                {addBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Tambah"}
              </button>
            </div>
          </div>
        ) : null}

        {members === null ? (
          <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-14 rounded-2xl shimmer" />)}</div>
        ) : (
          <div className="space-y-1.5">
            {members.map((m) => (
              <div key={m.uid} className="flex items-center gap-3 rounded-2xl glass p-3">
                <button onClick={() => onOpenProfile(m.uid)} className="relative shrink-0">
                  {m.avatar ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={m.avatar} alt={m.username} className="h-10 w-10 rounded-xl object-cover" />
                  ) : (
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${m.avatarColor} text-xs font-extrabold text-white`}>
                      {m.username.charAt(0).toUpperCase()}
                    </div>
                  )}
                  {m.online && <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-background bg-emerald-500" />}
                </button>
                <button onClick={() => onOpenProfile(m.uid)} className="min-w-0 flex-1 text-left">
                  <p className="flex items-center gap-1.5 truncate text-xs font-bold">
                    {m.username}
                    {m.isOwner && <Crown className="h-3 w-3 text-amber-400" />}
                    {!m.isOwner && m.isAdmin && <Shield className="h-3 w-3 text-cyan-400" />}
                  </p>
                  <p className="truncate text-[10px] text-muted-foreground">
                    {m.fanzzId ? <span className="font-mono">{m.fanzzId}</span> : "—"} • {m.country || ""} • {m.followers} follower
                  </p>
                </button>
                {/* aksi admin (kalau aku admin & dia bukan owner) */}
                {myRole?.isOwner !== undefined && (myRole.isOwner || myRole.isAdmin) && !m.isOwner && m.uid !== useApp.getState().user?.uid ? (
                  <div className="flex shrink-0 gap-1">
                    {myRole.isOwner && !m.isAdmin && (
                      <button
                        onClick={() => groupAction("promote", openGid, m.uid)}
                        className="rounded-lg bg-cyan-500/15 p-1.5 text-cyan-300 transition-colors hover:bg-cyan-500/25"
                        title="Jadiin admin"
                      >
                        <Shield className="h-3.5 w-3.5" />
                      </button>
                    )}
                    {myRole.isOwner && m.isAdmin && (
                      <button
                        onClick={() => groupAction("demote", openGid, m.uid)}
                        className="rounded-lg bg-amber-500/15 p-1.5 text-amber-300 transition-colors hover:bg-amber-500/25"
                        title="Copot admin"
                      >
                        <ShieldOff className="h-3.5 w-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => groupAction("kick", openGid, m.uid)}
                      className="rounded-lg bg-red-500/15 p-1.5 text-red-300 transition-colors hover:bg-red-500/25"
                      title="Keluarkan dari grup"
                    >
                      <UserMinus className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        )}

        <button
          onClick={() => groupAction("leave", openGid)}
          className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl bg-red-500/10 py-3 text-xs font-bold text-red-300 transition-colors hover:bg-red-500/20"
        >
          <LogOut className="h-3.5 w-3.5" /> {myRole?.isOwner && groupInfo?.members === 1 ? "Hapus grup" : "Keluar dari grup"}
        </button>
      </div>
    );
  }

  /* ---- LIST GRUP ---- */
  return (
    <div>
      {err && <p className="mb-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300">⚠️ {err}</p>}

      {/* bikin grup */}
      <AnimatePresence>
        {showCreate ? (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
            <div className="mb-4 rounded-2xl glass p-4">
              <p className="mb-3 text-sm font-extrabold">Bikin grup baru</p>
              <input
                value={gName}
                onChange={(e) => { setGName(e.target.value); setErr(""); }}
                placeholder="Nama grup (minimal 3 huruf)"
                className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3.5 py-3 text-sm outline-none focus:border-red-400/50"
              />
              <input
                value={gDesc}
                onChange={(e) => setGDesc(e.target.value)}
                placeholder="Deskripsi (opsional)"
                className="mt-2 w-full rounded-xl border border-border/60 bg-secondary/50 px-3.5 py-3 text-sm outline-none focus:border-red-400/50"
              />
              <div className="mt-3 flex gap-2">
                <button
                  onClick={createGroup}
                  disabled={busy || gName.trim().length < 3}
                  className="flex-1 rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-3 text-xs font-extrabold text-white shadow-lg shadow-red-500/20 disabled:opacity-40"
                >
                  {busy ? <Loader2 className="mx-auto h-4 w-4 animate-spin" /> : "Buat Grup"}
                </button>
                <button onClick={() => setShowCreate(false)} className="rounded-xl bg-secondary/70 px-4 py-3 text-xs font-bold text-muted-foreground">
                  Batal
                </button>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {!showCreate && (
        <button
          onClick={() => setShowCreate(true)}
          className="mb-4 flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-red-400/40 bg-red-500/5 py-4 text-xs font-extrabold text-red-300 transition-all hover:bg-red-500/10 active:scale-[0.99]"
        >
          <Plus className="h-4 w-4" /> Bikin Grup Baru
        </button>
      )}

      {/* grupku */}
      <p className="mb-2 text-xs font-bold text-muted-foreground">GRUPKU</p>
      {mine === null ? (
        <div className="mb-5 space-y-2">{[0, 1].map((i) => <div key={i} className="h-16 rounded-2xl shimmer" />)}</div>
      ) : mine.length === 0 ? (
        <p className="mb-5 rounded-2xl glass p-4 text-center text-[11px] text-muted-foreground">
          Belum join grup — bikin sendiri di atas, atau join grup publik di bawah 👇
        </p>
      ) : (
        <div className="mb-5 space-y-2">
          {mine.map((g) => (
            <div key={g.gid} className="flex items-center gap-3 rounded-2xl glass p-3">
              <button onClick={() => setOpenGid(g.gid)} className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${g.avatarColor} text-white`}>
                <UsersRound className="h-5 w-5" />
              </button>
              <button onClick={() => setOpenGid(g.gid)} className="min-w-0 flex-1 text-left">
                <p className="truncate text-sm font-bold">{g.name}</p>
                <p className="text-[11px] text-muted-foreground">
                  {g.members} anggota • {g.desc || "ketuk buat kelola"}
                </p>
              </button>
              <button
                onClick={() => onOpenGroup(g.gid, g.name)}
                className="flex shrink-0 items-center gap-1 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3 py-2 text-[11px] font-bold text-white shadow-lg shadow-red-500/20 active:scale-95"
              >
                <Send className="h-3.5 w-3.5" /> Chat
              </button>
            </div>
          ))}
        </div>
      )}

      {/* discover */}
      <p className="mb-2 text-xs font-bold text-muted-foreground">GRUP PUBLIK — GAS JOIN</p>
      {discover === null ? (
        <div className="space-y-2">{[0, 1].map((i) => <div key={i} className="h-16 rounded-2xl shimmer" />)}</div>
      ) : discover.length === 0 ? (
        <p className="rounded-2xl glass p-4 text-center text-[11px] text-muted-foreground">
          Belum ada grup publik lain. Yang bikin duluan jadi legenda 😎
        </p>
      ) : (
        <div className="space-y-2">
          {discover.map((g) => (
            <div key={g.gid} className="flex items-center gap-3 rounded-2xl glass p-3">
              <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br ${g.avatarColor} text-white`}>
                <UsersRound className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">{g.name}</p>
                <p className="text-[11px] text-muted-foreground">{g.members} anggota • {g.desc || "grup publik"}</p>
              </div>
              <button
                onClick={() => groupAction("join", g.gid)}
                className="flex shrink-0 items-center gap-1 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-3 py-2 text-[11px] font-bold text-white shadow-lg shadow-cyan-500/20 active:scale-95"
              >
                <UserPlus className="h-3.5 w-3.5" /> Join
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
