"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Code2, Search, Loader2, Download, FileCode2, FileType2, Braces,
  Globe, Link2, Copy, ChevronDown, ChevronUp, Image as ImageIcon,
} from "lucide-react";

/**
 * Ambil Source Code Web (V2 Modern-UpdSec).
 * Melihat HTML/CSS/JS halaman web lain secara legal — seperti Ctrl+U /
 * "View Page Source", tapi rapi: ringkasan struktur + inline assets +
 * unduh 1 file HTML utuh. Bukan alat menembus login/paywall.
 */

interface SourceResult {
  ok: boolean;
  error?: string;
  url: string;
  httpStatus: number;
  title: string | null;
  meta: {
    description: string | null;
    generator: string | null;
    viewport: string | null;
    charset: string | null;
    ogImage: string | null;
    themeColor: string | null;
  };
  counts: {
    htmlBytes: number;
    htmlLines: number;
    elements: number;
    images: number;
    links: number;
    forms: number;
    tables: number;
    iframes: number;
    stylesheets: number;
    externalScripts: number;
    inlineBlocks: number;
  };
  stylesheets: string[];
  scripts: string[];
  inline: Array<{ type: "style" | "script"; lang?: string; content: string; bytes: number }>;
  html: string;
}

function fmtBytes(n: number) {
  if (n > 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  if (n > 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${n} B`;
}

export default function SourceCodeView() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [res, setRes] = useState<SourceResult | null>(null);
  const [tab, setTab] = useState<"ringkasan" | "html" | "css" | "js" | "aset">("ringkasan");
  const [htmlExpanded, setHtmlExpanded] = useState(false);
  const { toast } = useToast();

  const ambil = async () => {
    const u = url.trim();
    if (!u || loading) return;
    setLoading(true);
    setRes(null);
    try {
      const r = await fetch(`/api/tools/source-code?url=${encodeURIComponent(u)}`);
      const d = (await r.json()) as SourceResult;
      if (!d.ok) throw new Error(d.error || "Gagal mengambil");
      setRes(d);
      setTab("ringkasan");
      pushHistory("sourcecode", { id: d.url, title: d.title || d.url, subtitle: `${d.counts.htmlLines} baris HTML` });
    } catch (e) {
      toast({ title: "Gagal mengambil source", description: e instanceof Error ? e.message : "Cek URL-nya lagi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const salin = (teks: string, label: string) => {
    try {
      navigator.clipboard.writeText(teks);
      toast({ title: `${label} tersalin!` });
    } catch {
      toast({ title: "Gagal menyalin", variant: "destructive" });
    }
  };

  const unduhHtml = () => {
    if (!res) return;
    const blob = new Blob([res.html], { type: "text/html;charset=utf-8" });
    const a = document.createElement("a");
    let host = "halaman";
    try {
      host = new URL(res.url).hostname.replace(/[^a-z0-9.-]/gi, "");
    } catch { /* abaikan */ }
    const nama = `${host}-source.html`;
    // PERBAIKAN #6 (zuperupdt) — "unduh error HTTP di HP":
    // dulu URL.createObjectURL langsung di-revoke SETELAH a.click().
    // Di banyak browser mobile (esp. Android Chrome/WebView), unduhan belum
    // sempat dimulai saat blob URL sudah dicabut → "failed - network error".
    // Pola benar: (1) append ke DOM, (2) click, (3) revoke BELAKANGAN
    // (60 dtk) + fallback msSaveOrOpenBlob / window.open.
    try {
      const url = URL.createObjectURL(blob);
      a.href = url;
      a.download = nama;
      a.rel = "noopener";
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 60_000);
      toast({ title: "File HTML terunduh!", description: "1 file utuh — buka pakai text editor apa pun." });
    } catch {
      // fallback lama: navigator.msSaveOrOpenBlob (WebView lawas) / buka tab
      const nav = navigator as Navigator & { msSaveOrOpenBlob?: (b: Blob, n: string) => boolean };
      if (typeof nav.msSaveOrOpenBlob === "function") {
        nav.msSaveOrOpenBlob(blob, nama);
        toast({ title: "File HTML terunduh!" });
      } else {
        toast({ title: "Unduhan diblokir browser", description: "Gunakan tombol Salin HTML lalu simpan manual.", variant: "destructive" });
      }
    }
  };

  const inlineCss = res?.inline.filter((i) => i.type === "style") || [];
  const inlineJs = res?.inline.filter((i) => i.type === "script") || [];

  return (
    <div>
      <ToolHeader icon={<Code2 className="h-5.5 w-5.5" />} title="Ambil Source Code Web" subtitle="HTML • CSS • JS — legal seperti View Page Source" accent="cyan" />

      {/* input URL */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Globe className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && ambil()}
            placeholder="https://contoh-web.com"
            className="rounded-xl pl-10"
            inputMode="url"
          />
        </div>
        <button
          onClick={ambil}
          disabled={loading || !url.trim()}
          className="flex h-10 items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-4 text-xs font-extrabold text-white disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Ambil
        </button>
      </div>

      {loading && (
        <div className="mt-4 space-y-2">
          <div className="h-20 rounded-2xl shimmer" />
          <div className="h-40 rounded-2xl shimmer" />
        </div>
      )}

      {!res && !loading && (
        <div className="mt-4">
          <EmptyState
            icon={<Code2 className="h-10 w-10" />}
            title="Masukkan URL web mana pun"
            desc="Alat ini mengambil halaman publik (seperti Ctrl+U di browser) lalu menampilkan HTML, CSS inline, JS inline, dan daftar asetnya. Bisa diunduh jadi 1 file HTML."
          />
        </div>
      )}

      {res && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-4">
          {/* info utama */}
          <div className="glass rounded-2xl p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-extrabold">{res.title || "(tanpa judul)"}</p>
                <a href={res.url} target="_blank" rel="noopener noreferrer" className="mt-0.5 flex items-center gap-1 truncate text-[11px] text-cyan-300">
                  <Link2 className="h-3 w-3" /> {res.url}
                </a>
              </div>
              <button onClick={unduhHtml} className="flex shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-3 py-2 text-[10px] font-extrabold text-white">
                <Download className="h-3.5 w-3.5" /> Unduh HTML
              </button>
            </div>
            {res.meta.description && <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{res.meta.description}</p>}
            <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
              {[
                { label: "Baris", value: res.counts.htmlLines.toLocaleString("id") },
                { label: "Ukuran", value: fmtBytes(res.counts.htmlBytes) },
                { label: "Elemen", value: res.counts.elements.toLocaleString("id") },
                { label: "Gambar", value: res.counts.images },
                { label: "CSS", value: res.counts.stylesheets + inlineCss.length },
                { label: "JS", value: res.counts.externalScripts + inlineJs.length },
              ].map((s) => (
                <div key={s.label} className="rounded-xl bg-secondary/50 p-2 text-center">
                  <p className="text-sm font-extrabold text-cyan-300">{s.value}</p>
                  <p className="text-[9px] font-bold text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* tab */}
          <div className="flex gap-2 overflow-x-auto pb-1">
            {([
              { id: "ringkasan", label: "Ringkasan", icon: Braces },
              { id: "html", label: "HTML", icon: FileCode2 },
              { id: "css", label: `CSS (${inlineCss.length})`, icon: FileType2 },
              { id: "js", label: `JS (${inlineJs.length})`, icon: Braces },
              { id: "aset", label: "Aset Eksternal", icon: ImageIcon },
            ] as const).map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
                  tab === t.id ? "bg-gradient-to-r from-cyan-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                <t.icon className="h-3.5 w-3.5" /> {t.label}
              </button>
            ))}
          </div>

          {/* ringkasan */}
          {tab === "ringkasan" && (
            <div className="glass space-y-3 rounded-2xl p-4">
              {[
                ["Generator / CMS", res.meta.generator || "—"],
                ["Charset", res.meta.charset || "—"],
                ["Viewport", res.meta.viewport || "—"],
                ["HTTP Status", String(res.httpStatus)],
                ["Form", String(res.counts.forms)],
                ["Tabel", String(res.counts.tables)],
                ["Iframe", String(res.counts.iframes)],
                ["Link <a>", String(res.counts.links)],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-3 border-b border-[var(--surface-line)] pb-2 last:border-0 last:pb-0">
                  <span className="text-[11px] font-bold text-muted-foreground">{k}</span>
                  <span className="max-w-[60%] truncate text-[11px] font-bold">{v}</span>
                </div>
              ))}
            </div>
          )}

          {/* HTML */}
          {tab === "html" && (
            <div className="glass rounded-2xl p-4">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-xs font-extrabold">HTML mentah ({res.counts.htmlLines.toLocaleString("id")} baris)</p>
                <div className="flex gap-1.5">
                  <button onClick={() => salin(res.html, "HTML")} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                    <Copy className="h-3 w-3" /> Salin
                  </button>
                  <button onClick={() => setHtmlExpanded((v) => !v)} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                    {htmlExpanded ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    {htmlExpanded ? "Persingkat" : "Tampilkan semua"}
                  </button>
                </div>
              </div>
              <pre className="max-h-[420px] overflow-auto rounded-xl bg-black/60 p-3 text-[10px] leading-relaxed text-emerald-200/90">
                <code>{htmlExpanded ? res.html : res.html.split("\n").slice(0, 60).join("\n")}{!htmlExpanded && res.counts.htmlLines > 60 ? `\n… (${res.counts.htmlLines - 60} baris lagi — klik "Tampilkan semua")` : ""}</code>
              </pre>
            </div>
          )}

          {/* CSS inline */}
          {tab === "css" && (
            <div className="space-y-3">
              {inlineCss.length === 0 && <EmptyState icon={<FileType2 className="h-8 w-8" />} title="Tidak ada CSS inline" desc="Halaman ini memuat semua style dari file eksternal — lihat tab Aset Eksternal." />}
              {inlineCss.map((c, i) => (
                <div key={i} className="glass rounded-2xl p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-xs font-extrabold">Blok CSS #{i + 1} · {fmtBytes(c.bytes)}</p>
                    <button onClick={() => salin(c.content, "CSS")} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                      <Copy className="h-3 w-3" /> Salin
                    </button>
                  </div>
                  <pre className="max-h-[300px] overflow-auto rounded-xl bg-black/60 p-3 text-[10px] leading-relaxed text-sky-200/90">
                    <code>{c.content.slice(0, 6000)}{c.content.length > 6000 ? "\n…" : ""}</code>
                  </pre>
                </div>
              ))}
            </div>
          )}

          {/* JS inline */}
          {tab === "js" && (
            <div className="space-y-3">
              {inlineJs.length === 0 && <EmptyState icon={<Braces className="h-8 w-8" />} title="Tidak ada JavaScript inline" desc="Semua skrip dimuat dari file eksternal — lihat tab Aset Eksternal." />}
              {inlineJs.map((c, i) => (
                <div key={i} className="glass rounded-2xl p-4">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="text-xs font-extrabold">Skrip #{i + 1} {c.lang ? `· ${c.lang}` : ""} · {fmtBytes(c.bytes)}</p>
                    <button onClick={() => salin(c.content, "JS")} className="flex items-center gap-1 rounded-lg bg-secondary px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                      <Copy className="h-3 w-3" /> Salin
                    </button>
                  </div>
                  <pre className="max-h-[300px] overflow-auto rounded-xl bg-black/60 p-3 text-[10px] leading-relaxed text-amber-200/90">
                    <code>{c.content.slice(0, 6000)}{c.content.length > 6000 ? "\n…" : ""}</code>
                  </pre>
                </div>
              ))}
            </div>
          )}

          {/* aset eksternal */}
          {tab === "aset" && (
            <div className="space-y-3">
              <div className="glass rounded-2xl p-4">
                <p className="mb-2 text-xs font-extrabold text-sky-300">Stylesheet eksternal ({res.stylesheets.length})</p>
                {res.stylesheets.length === 0 && <p className="text-[11px] text-muted-foreground">Tidak ada.</p>}
                <div className="space-y-1.5">
                  {res.stylesheets.map((s) => (
                    <a key={s} href={s} target="_blank" rel="noopener noreferrer" className="block truncate rounded-lg bg-secondary/50 px-2.5 py-2 font-mono text-[10px] text-sky-200">
                      {s}
                    </a>
                  ))}
                </div>
              </div>
              <div className="glass rounded-2xl p-4">
                <p className="mb-2 text-xs font-extrabold text-amber-300">Skrip eksternal ({res.scripts.length})</p>
                {res.scripts.length === 0 && <p className="text-[11px] text-muted-foreground">Tidak ada.</p>}
                <div className="space-y-1.5">
                  {res.scripts.map((s) => (
                    <a key={s} href={s} target="_blank" rel="noopener noreferrer" className="block truncate rounded-lg bg-secondary/50 px-2.5 py-2 font-mono text-[10px] text-amber-200">
                      {s}
                    </a>
                  ))}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}
