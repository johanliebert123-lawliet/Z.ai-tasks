"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Blocks, Search, Loader2, Download, ChevronLeft, RefreshCw, Server,
  BookOpen, FileBox, HardDrive, Cpu, ArrowLeft, ExternalLink,
} from "lucide-react";

/**
 * Minecraft Downloader (V2 Modern-UpdSec) — scrape legal MCPELife:
 * APK & beta, mods, maps, textures, shaders, skins, seeds, launcher,
 * arsip versi lengkap + server Bedrock + panduan.
 * File diunduh lewat proxy /api/download/file (butuh sesi login).
 */

interface McItem {
  title: string;
  url: string;
  thumbnail: string;
  date: string;
  description: string;
}

interface McDetail {
  title: string;
  url: string;
  thumbnail: string;
  author: string;
  date: string;
  rating: string | null;
  total_downloads: string | null;
  total_comments: string | null;
  description: string;
  screenshots: string[];
  downloads: Array<{
    title: string;
    info: string;
    download_page: string;
    direct_url: string;
    file_name: string;
    file_size: string;
    architecture: string;
  }>;
}

const CATEGORIES = [
  { name: "APK & Beta", endpoint: "/download/" },
  { name: "Mods", endpoint: "/mods/" },
  { name: "Maps", endpoint: "/maps/" },
  { name: "Textures", endpoint: "/textures/" },
  { name: "Shaders", endpoint: "/shaders/" },
  { name: "Skins", endpoint: "/skins/" },
  { name: "Seeds", endpoint: "/seeds/" },
  { name: "Launcher & Soft", endpoint: "/soft/" },
];

export default function MinecraftView() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState<"beranda" | "versi" | "server" | "panduan">("beranda");
  const [cat, setCat] = useState<string>("/download/");
  const [page, setPage] = useState(1);
  const [items, setItems] = useState<McItem[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [detail, setDetail] = useState<McDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [versions, setVersions] = useState<Array<{ version_name: string; url: string }> | null>(null);
  const [servers, setServers] = useState<Array<{ title: string; address: string; port: number; players_online: string; description: string }> | null>(null);
  const [guides, setGuides] = useState<Array<{ title: string; url: string; summary: string; steps: string[] }> | null>(null);
  const { toast } = useToast();

  const loadCategory = useCallback(async (endpoint: string, p: number, refresh = false) => {
    setLoading(true);
    setItems(null);
    try {
      const r = await fetch(`/api/minecraft?category=${encodeURIComponent(endpoint)}&page=${p}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memuat");
      setItems(d.results);
      if (!d.results.length && p === 1) toast({ title: "Kategori kosong", description: "Coba kategori lain atau pencarian." });
    } catch (e) {
      toast({ title: "Gagal memuat", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (tab === "beranda" && items === null && !loading) loadCategory(cat, 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const doSearch = async () => {
    const q = query.trim();
    if (!q) return;
    setTab("beranda");
    setLoading(true);
    setItems(null);
    setDetail(null);
    try {
      const r = await fetch(`/api/minecraft?search=${encodeURIComponent(q)}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal mencari");
      setItems(d.results);
      if (!d.results.length) toast({ title: "Tidak ketemu", description: `Tidak ada hasil untuk "${q}" — coba kata lain.` });
    } catch (e) {
      toast({ title: "Gagal mencari", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  const openDetail = async (url: string) => {
    setDetailLoading(true);
    setDetail(null);
    try {
      const r = await fetch(`/api/minecraft?detail=${encodeURIComponent(url)}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal membuka");
      setDetail(d.detail);
      pushHistory("minecraft", { id: url, title: d.detail.title, subtitle: d.detail.date, poster: d.detail.thumbnail });
      window.scrollTo({ top: 0 });
    } catch (e) {
      toast({ title: "Gagal membuka detail", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setDetailLoading(false);
    }
  };

  const loadVersions = async () => {
    setTab("versi");
    if (versions) return;
    setLoading(true);
    try {
      const r = await fetch("/api/minecraft?versions=1");
      const d = await r.json();
      setVersions(d?.ok ? d.versions : []);
    } catch {
      setVersions([]);
      toast({ title: "Gagal memuat arsip versi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const loadServers = async () => {
    setTab("server");
    if (servers) return;
    setLoading(true);
    try {
      const r = await fetch("/api/minecraft?servers=1");
      const d = await r.json();
      setServers(d?.ok ? d.servers : []);
    } catch {
      setServers([]);
      toast({ title: "Gagal memuat server", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const loadGuides = async () => {
    setTab("panduan");
    if (guides) return;
    setLoading(true);
    try {
      const r = await fetch("/api/minecraft?guides=1");
      const d = await r.json();
      setGuides(d?.ok ? d.guides : []);
    } catch {
      setGuides([]);
      toast({ title: "Gagal memuat panduan", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const unduhFile = (d: McDetail["downloads"][number]) => {
    const name = `${(d.file_name || "minecraft-file").replace(/[\\/:*?"<>|]/g, " ").slice(0, 80)}`;
    const a = document.createElement("a");
    a.href = `/api/download/file?url=${encodeURIComponent(d.direct_url)}&name=${encodeURIComponent(name)}`;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    toast({ title: "Unduhan dimulai!", description: `${d.file_name} • ${d.file_size}` });
  };

  return (
    <div>
      <ToolHeader icon={<Blocks className="h-5.5 w-5.5" />} title="Download Minecraft" subtitle="APK • Mods • Maps • Shaders • Skins • Versi lengkap" accent="emerald" />

      {/* pencarian */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && doSearch()}
            placeholder="Cari mod / map / shader / versi Minecraft…"
            className="rounded-xl pl-10"
          />
        </div>
        <button
          onClick={doSearch}
          disabled={loading || !query.trim()}
          className="h-10 shrink-0 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 text-xs font-extrabold text-white disabled:opacity-50"
        >
          Cari
        </button>
      </div>

      {/* tab */}
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {([
          { id: "beranda", label: "Beranda", action: () => setTab("beranda") },
          { id: "versi", label: "Arsip Versi", action: loadVersions },
          { id: "server", label: "Server Bedrock", action: loadServers },
          { id: "panduan", label: "Panduan", action: loadGuides },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={t.action}
            className={`shrink-0 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
              tab === t.id ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ===== DETAIL ===== */}
      {detailLoading && (
        <div className="mt-4 space-y-2">
          <div className="h-44 rounded-2xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      )}

      {detail && !detailLoading && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-4">
          <button onClick={() => setDetail(null)} className="flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3 py-2 text-[11px] font-bold text-muted-foreground">
            <ArrowLeft className="h-3.5 w-3.5" /> Kembali
          </button>

          <div className="glass overflow-hidden rounded-2xl">
            {detail.screenshots[0] && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={detail.screenshots[0]} alt={detail.title} className="h-44 w-full object-cover" referrerPolicy="no-referrer" />
            )}
            <div className="p-4">
              <h2 className="text-base font-extrabold leading-snug">{detail.title}</h2>
              <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] font-bold">
                <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-emerald-300">oleh {detail.author}</span>
                <span className="rounded-full bg-secondary px-2.5 py-1 text-muted-foreground">{detail.date}</span>
                {detail.rating && <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-amber-300">★ {detail.rating}</span>}
                {detail.total_downloads && <span className="rounded-full bg-red-500/15 px-2.5 py-1 text-red-300">{detail.total_downloads} unduhan</span>}
              </div>
              <p className="mt-3 text-[11.5px] leading-relaxed text-muted-foreground">{detail.description}</p>
            </div>
          </div>

          {/* pilihan unduhan */}
          <section>
            <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
              <Download className="h-4 w-4 text-emerald-400" /> Pilihan Unduhan
            </h3>
            {detail.downloads.length === 0 && (
              <EmptyState icon={<FileBox className="h-8 w-8" />} title="Tidak ada file" desc="Halaman ini tidak menyediakan file unduhan yang bisa dibaca." />
            )}
            <div className="space-y-2.5">
              {detail.downloads.map((d, i) => (
                <div key={i} className="glass rounded-2xl p-4">
                  <p className="text-xs font-extrabold">{d.title}</p>
                  <div className="mt-2 flex flex-wrap gap-1.5 text-[10px] font-bold">
                    <span className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-muted-foreground"><HardDrive className="h-3 w-3" /> {d.file_size}</span>
                    <span className="flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-muted-foreground"><Cpu className="h-3 w-3" /> {d.architecture}</span>
                  </div>
                  <button
                    onClick={() => unduhFile(d)}
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-3 text-xs font-extrabold text-white transition-transform active:scale-95"
                  >
                    <Download className="h-4 w-4" /> Unduh via FanzzTools
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* screenshot */}
          {detail.screenshots.length > 1 && (
            <section>
              <h3 className="mb-2.5 text-sm font-bold">Tangkapan Layar</h3>
              <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
                {detail.screenshots.slice(0, 8).map((s, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img key={i} src={s} alt={`screenshot ${i + 1}`} className="h-32 w-auto shrink-0 rounded-xl object-cover" referrerPolicy="no-referrer" />
                ))}
              </div>
            </section>
          )}
        </motion.div>
      )}

      {/* ===== LISTING ===== */}
      {!detail && !detailLoading && tab === "beranda" && (
        <>
          {/* kategori */}
          <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
            {CATEGORIES.map((c) => (
              <button
                key={c.endpoint}
                onClick={() => {
                  setCat(c.endpoint);
                  setPage(1);
                  loadCategory(c.endpoint, 1);
                }}
                className={`shrink-0 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
                  cat === c.endpoint ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                {c.name}
              </button>
            ))}
            <button
              onClick={() => loadCategory(cat, page)}
              className="flex shrink-0 items-center gap-1 rounded-full bg-secondary px-3 py-2 text-[11px] font-bold text-muted-foreground"
              title="Muat ulang"
            >
              <RefreshCw className="h-3 w-3" />
            </button>
          </div>

          {loading && (
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-44 rounded-2xl shimmer" />
              ))}
            </div>
          )}

          {!loading && items && (
            <>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                {items.map((it, i) => (
                  <motion.button
                    key={it.url}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.03, 0.4) }}
                    onClick={() => openDetail(it.url)}
                    className="group overflow-hidden rounded-2xl glass text-left transition-transform active:scale-95"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={it.thumbnail} alt={it.title} className="h-28 w-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                    <div className="p-2.5">
                      <p className="clamp-2 text-[11px] font-extrabold leading-snug">{it.title}</p>
                      <p className="mt-1 text-[9px] font-bold text-muted-foreground">{it.date}</p>
                    </div>
                  </motion.button>
                ))}
              </div>

              {/* navigasi halaman */}
              <div className="mt-4 flex items-center justify-center gap-3">
                <button
                  onClick={() => {
                    const p = Math.max(1, page - 1);
                    setPage(p);
                    loadCategory(cat, p);
                  }}
                  disabled={page <= 1}
                  className="flex items-center gap-1 rounded-xl bg-secondary px-3.5 py-2 text-[11px] font-bold text-muted-foreground disabled:opacity-40"
                >
                  <ChevronLeft className="h-3.5 w-3.5" /> Sebelumnya
                </button>
                <span className="text-[11px] font-bold text-muted-foreground">Halaman {page}</span>
                <button
                  onClick={() => {
                    const p = page + 1;
                    setPage(p);
                    loadCategory(cat, p);
                  }}
                  disabled={!items.length}
                  className="rounded-xl bg-secondary px-3.5 py-2 text-[11px] font-bold text-muted-foreground disabled:opacity-40"
                >
                  Berikutnya
                </button>
              </div>
            </>
          )}
        </>
      )}

      {/* ===== VERSI ===== */}
      {tab === "versi" && (
        <div className="mt-4 space-y-2">
          {loading && <div className="h-40 rounded-2xl shimmer" />}
          {!loading && versions && versions.map((v) => (
            <button
              key={v.url}
              onClick={() => openDetail(v.url)}
              className="flex w-full items-center justify-between gap-3 rounded-2xl glass p-3.5 text-left transition-colors hover:bg-secondary/70"
            >
              <span className="flex min-w-0 items-center gap-2.5">
                <Blocks className="h-4 w-4 shrink-0 text-emerald-400" />
                <span className="truncate text-xs font-bold">{v.version_name}</span>
              </span>
              <ExternalLink className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
            </button>
          ))}
        </div>
      )}

      {/* ===== SERVER ===== */}
      {tab === "server" && (
        <div className="mt-4 space-y-2.5">
          {loading && <div className="h-40 rounded-2xl shimmer" />}
          {!loading && servers && servers.map((s) => (
            <div key={s.address} className="glass rounded-2xl p-4">
              <div className="flex items-center gap-2.5">
                <Server className="h-4 w-4 text-emerald-400" />
                <p className="min-w-0 flex-1 truncate text-xs font-extrabold">{s.title}</p>
                <span className="shrink-0 rounded-full bg-emerald-500/15 px-2.5 py-1 text-[9px] font-black text-emerald-300">{s.players_online}</span>
              </div>
              <div className="mt-2.5 flex items-center gap-2 rounded-xl bg-black/50 px-3 py-2.5">
                <code className="flex-1 truncate font-mono text-[11px] text-emerald-300">{s.address}<span className="text-muted-foreground">:{s.port}</span></code>
                <button
                  onClick={() => {
                    navigator.clipboard?.writeText(`${s.address}:${s.port}`);
                    toast({ title: "Alamat server tersalin!" });
                  }}
                  className="rounded-lg bg-secondary px-2 py-1 text-[9px] font-bold text-muted-foreground"
                >
                  SALIN
                </button>
              </div>
              <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">{s.description}</p>
            </div>
          ))}
        </div>
      )}

      {/* ===== PANDUAN ===== */}
      {tab === "panduan" && (
        <div className="mt-4 space-y-3">
          {loading && <div className="h-40 rounded-2xl shimmer" />}
          {!loading && guides && guides.map((g) => (
            <div key={g.url} className="glass rounded-2xl p-4">
              <p className="flex items-center gap-2 text-xs font-extrabold">
                <BookOpen className="h-4 w-4 text-emerald-400" /> {g.title}
              </p>
              <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{g.summary}</p>
              <ol className="mt-2.5 space-y-1.5">
                {g.steps.map((s, i) => (
                  <li key={i} className="flex gap-2 text-[10.5px] leading-relaxed text-muted-foreground">
                    <span className="flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-[9px] font-black text-emerald-300">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
              <a href={g.url} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-1.5 text-[10px] font-bold text-emerald-300">
                Buka halaman asli <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
