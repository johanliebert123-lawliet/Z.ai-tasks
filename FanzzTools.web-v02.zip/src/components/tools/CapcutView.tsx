"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Scissors, Loader2, Copy, Check, Sparkles, ShieldCheck, Zap, RefreshCw, ExternalLink, KeyRound,
} from "lucide-react";

type Step = 1 | 2 | 3;

interface Account {
  email: string;
  password: string;
  userId?: string;
  cookie?: string;
}

interface TrialStep {
  action: string;
  success: boolean;
  info?: string;
}

function CopyRow({ label, value }: { label: string; value: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="flex items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2.5">
      <div className="min-w-0 flex-1">
        <p className="text-[9px] font-bold uppercase text-muted-foreground">{label}</p>
        <p className="truncate text-xs font-semibold">{value}</p>
      </div>
      <button
        onClick={async () => {
          try {
            await navigator.clipboard.writeText(value);
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
          } catch {
            /* ignore */
          }
        }}
        className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors ${
          copied ? "bg-emerald-500/20 text-emerald-300" : "bg-secondary text-muted-foreground hover:text-foreground"
        }`}
      >
        {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
      </button>
    </div>
  );
}

export default function CapcutView() {
  const [step, setStep] = useState<Step>(1);
  const [busy, setBusy] = useState(false);
  const [account, setAccount] = useState<Account | null>(null);
  const [otp, setOtp] = useState("");
  const [customEmail, setCustomEmail] = useState("");
  const [useCustom, setUseCustom] = useState(false);
  const [trialResult, setTrialResult] = useState<{ success: boolean; steps: TrialStep[] } | null>(null);
  const [error, setError] = useState("");
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const { toast } = useToast();

  /* ---------- LANGKAH 1: bikin email + kirim OTP ---------- */
  const createAccount = async () => {
    if (busy) return;
    setBusy(true);
    setError("");
    setAccount(null);
    setOtp("");
    setTrialResult(null);
    try {
      const r = await fetch("/api/capcut", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          ...(useCustom && customEmail.includes("@") ? { email: customEmail.trim() } : {}),
        }),
      });
      const d = await r.json();
      if (!r.ok || !d?.ok) throw new Error(d?.error || "Gagal mulai bikin akun");
      setAccount({ email: d.email, password: d.password });
      setStep(2);

      // auto-poll OTP dari inbox (khusus email sementara FanzzTools)
      if (!useCustom) startOtpPoll(d.email);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal bikin akun");
    } finally {
      setBusy(false);
    }
  };

  const startOtpPoll = (email: string) => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(async () => {
      try {
        const r = await fetch(`/api/email/messages?email=${encodeURIComponent(email)}`);
        const d = await r.json();
        if (d?.ok && d.messages?.length) {
          const otpMsg = d.messages.find((m: { otp?: string }) => m.otp);
          if (otpMsg?.otp) {
            setOtp(otpMsg.otp);
            if (pollRef.current) clearInterval(pollRef.current);
          }
        }
      } catch {
        /* keep polling */
      }
    }, 5000);
  };

  /* ---------- LANGKAH 2: verifikasi OTP → daftar akun ---------- */
  const verifyOtp = async () => {
    if (!account || busy || !/^\d{4,8}$/.test(otp)) return;
    setBusy(true);
    setError("");
    try {
      const r = await fetch("/api/capcut", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "register", email: account.email, password: account.password, code: otp }),
      });
      const d = await r.json();
      if (!r.ok || !d?.ok) throw new Error(d?.error || "Verifikasi gagal — cek kembali kode OTP");
      setAccount({ email: d.email, password: d.password, userId: d.userId, cookie: d.cookie });
      setStep(3);
      toast({ title: "Akun CapCut aktif! 🎉", description: "Sekarang tinggal klaim Pro trial 7 hari di langkah terakhir." });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Verifikasi gagal");
    } finally {
      setBusy(false);
    }
  };

  /* ---------- LANGKAH 3: klaim Pro trial ---------- */
  const claimTrial = async () => {
    if (!account?.cookie || busy) return;
    setBusy(true);
    setError("");
    setTrialResult(null);
    try {
      const r = await fetch("/api/capcut", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "trial", cookie: account.cookie }),
      });
      const d = await r.json();
      if (!r.ok || !d?.ok) throw new Error(d?.error || "Klaim trial gagal");
      setTrialResult({ success: d.success, steps: d.steps || [] });
      if (d.success) {
        toast({ title: "CapCut Pro aktif! ✨", description: "Trial 7 hari udah diklaim ke akun ini." });
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Klaim gagal");
    } finally {
      setBusy(false);
    }
  };

  const restart = () => {
    if (pollRef.current) clearInterval(pollRef.current);
    setStep(1);
    setAccount(null);
    setOtp("");
    setTrialResult(null);
    setError("");
  };

  const stepTitles: Record<Step, string> = {
    1: "Bikin Akun",
    2: "Verifikasi OTP",
    3: "Klaim Pro Trial",
  };

  return (
    <div>
      <ToolHeader icon={<Scissors className="h-5.5 w-5.5" />} title="CapCut Pro Generator" subtitle="Akun aktif + Pro trial 7 hari" accent="sky" />

      {/* stepper */}
      <div className="mb-5 flex items-center gap-2">
        {([1, 2, 3] as Step[]).map((s, i) => (
          <div key={s} className="flex flex-1 items-center gap-2">
            <div className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-xs font-extrabold transition-all ${
              step === s
                ? "bg-gradient-to-br from-sky-500 to-blue-600 text-white shadow-lg shadow-sky-500/25"
                : step > s
                  ? "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40"
                  : "bg-secondary/60 text-muted-foreground"
            }`}>
              {step > s ? <Check className="h-4 w-4" /> : s}
            </div>
            <span className={`hidden text-[10px] font-bold sm:block ${step === s ? "text-foreground" : "text-muted-foreground"}`}>{stepTitles[s]}</span>
            {i < 2 && <div className={`h-0.5 flex-1 rounded-full ${step > s ? "bg-emerald-400/60" : "bg-secondary"}`} />}
          </div>
        ))}
        <button onClick={restart} className="ml-1 shrink-0 rounded-xl bg-secondary/70 p-2 text-muted-foreground transition-colors hover:text-foreground" title="Mulai ulang">
          <RefreshCw className="h-3.5 w-3.5" />
        </button>
      </div>

      {error && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          ⚠️ {error}
        </motion.p>
      )}

      {/* ============ STEP 1 ============ */}
      {step === 1 && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-6 text-center">
          <motion.div
            animate={{ rotate: [0, -8, 8, 0] }}
            transition={{ repeat: Infinity, duration: 3 }}
            className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-sky-500 to-blue-600 shadow-xl shadow-sky-500/25"
          >
            <Scissors className="h-8 w-8 text-white" />
          </motion.div>
          <p className="text-base font-extrabold">Bikin Akun CapCut Aktif</p>
          <p className="mx-auto mt-2 max-w-xs text-xs leading-relaxed text-muted-foreground">
            Generator bakal bikin email sementara → daftar akun CapCut beneran → terus bisa langsung
            klaim <b className="text-sky-300">Pro trial 7 hari</b>. Semua otomatis dari sini.
          </p>

          {/* opsi email sendiri */}
          <button
            onClick={() => setUseCustom(!useCustom)}
            className="mt-4 flex w-full items-center justify-center gap-1.5 text-[11px] font-bold text-muted-foreground transition-colors hover:text-foreground"
          >
            {useCustom ? "☐" : "☑"} Pakai email sendiri (Gmail dll — OTP ke inbox kamu)
          </button>
          {useCustom && (
            <input
              value={customEmail}
              onChange={(e) => setCustomEmail(e.target.value)}
              placeholder="emailkamu@gmail.com"
              inputMode="email"
              className="mt-2 w-full rounded-xl border border-border/60 bg-secondary/50 px-3.5 py-3 text-sm outline-none focus:border-sky-400/60"
            />
          )}

          <Button
            onClick={createAccount}
            disabled={busy || (useCustom && !customEmail.includes("@"))}
            className="mt-5 w-full rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 py-5 text-sm font-bold shadow-lg shadow-sky-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
          >
            {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Zap className="mr-2 h-4.5 w-4.5" />}
            {busy ? "Lagi bikin akun..." : "Mulai Generate"}
          </Button>
        </motion.div>
      )}

      {/* ============ STEP 2 ============ */}
      {step === 2 && account && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-5">
          <p className="mb-1 text-xs font-bold text-muted-foreground">Kode OTP dikirim ke:</p>
          <CopyRow label="Email akun" value={account.email} />
          <CopyRow label="Password akun" value={account.password} />

          <div className="mt-4">
            <label className="mb-1.5 block text-xs font-bold text-muted-foreground">Kode OTP (6 angka)</label>
            <Input
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 8))}
              placeholder="______"
              inputMode="numeric"
              className="rounded-xl border-border/60 bg-secondary/50 py-5 text-center text-2xl font-extrabold tracking-[0.4em]"
            />
            <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground">
              {otp
                ? useCustom
                  ? "Isi kode OTP yang masuk ke email kamu."
                  : "OTP kedeteksi otomatis dari inbox — tinggal pencet Verifikasi."
                : useCustom
                  ? "Masukkan kode OTP yang dikirim CapCut ke email kamu (cek folder Spam juga)."
                  : "Nunggu OTP masuk ke inbox (otomatis, biasanya 1-3 menit)... kalau lama, cek ulang pakai tombol segarkan."}
            </p>
          </div>

          <div className="mt-4 flex gap-2">
            <Button
              onClick={verifyOtp}
              disabled={busy || !/^\d{4,8}$/.test(otp)}
              className="flex-1 rounded-xl bg-gradient-to-r from-sky-500 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-sky-500/25"
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />}
              {busy ? "Verifikasi..." : "Verifikasi & Daftar"}
            </Button>
            <button
              onClick={() => account && startOtpPoll(account.email)}
              className="flex items-center justify-center rounded-xl bg-secondary/70 px-4 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
              title="Cek ulang inbox"
            >
              <RefreshCw className="h-4 w-4" />
            </button>
          </div>

          <a
            href={`https://temp-mail.io/id/`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 flex items-center justify-center gap-1 text-[10px] font-semibold text-muted-foreground hover:text-foreground"
          >
            Buka inbox manual <ExternalLink className="h-2.5 w-2.5" />
          </a>
        </motion.div>
      )}

      {/* ============ STEP 3 ============ */}
      {step === 3 && account && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="glass rounded-3xl p-5">
            <div className="mb-3 flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-sky-400" />
              <p className="text-sm font-extrabold">Akun siap 🎉</p>
              <span className="ml-auto rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-extrabold text-emerald-300">AKTIF</span>
            </div>
            <div className="space-y-2">
              <CopyRow label="Email" value={account.email} />
              <CopyRow label="Password" value={account.password} />
              {account.userId && <CopyRow label="User ID" value={account.userId} />}
            </div>
          </div>

          {!trialResult ? (
            <div className="glass rounded-3xl p-5">
              <p className="text-sm font-extrabold">Klaim Pro Trial 7 Hari</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Langkah terakhir — aktifin Pro trial (semua fitur premium) ke akun ini. Gratis, tanpa kartu kredit.
              </p>
              <Button
                onClick={claimTrial}
                disabled={busy || !account.cookie}
                className="mt-4 w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 py-4 text-sm font-bold shadow-lg shadow-amber-500/25"
              >
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Zap className="mr-2 h-4 w-4" />}
                {busy ? "Lagi diklaim..." : "Aktifkan Pro 7 Hari"}
              </Button>
            </div>
          ) : (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`rounded-3xl glass p-5 ${trialResult.success ? "ring-1 ring-emerald-400/40" : ""}`}>
              <div className="mb-3 flex items-center gap-2">
                {trialResult.success ? (
                  <>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white"><Check className="h-4.5 w-4.5" /></span>
                    <div>
                      <p className="text-sm font-extrabold">CapCut Pro Aktif! ✨</p>
                      <p className="text-[10px] text-muted-foreground">Trial 7 hari terpasang di akun di atas</p>
                    </div>
                  </>
                ) : (
                  <>
                    <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-white"><Zap className="h-4.5 w-4.5" /></span>
                    <div>
                      <p className="text-sm font-extrabold">Akun aktif, trial belum nyangkut</p>
                      <p className="text-[10px] text-muted-foreground">Klaim web bisa dicoba ulang — akunnya tetap bisa dipakai login.</p>
                    </div>
                  </>
                )}
              </div>
              <div className="space-y-1.5">
                {trialResult.steps.map((s, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${s.success ? "bg-emerald-400" : "bg-red-400"}`} />
                    <span className="text-[11px] font-bold">{s.action}</span>
                    {s.info && <span className="ml-auto text-[9px] text-muted-foreground">{s.info}</span>}
                  </div>
                ))}
              </div>
              {!trialResult.success && (
                <Button onClick={claimTrial} disabled={busy} variant="secondary" className="mt-3 w-full rounded-xl py-3 text-xs font-bold">
                  <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Coba klaim lagi
                </Button>
              )}
            </motion.div>
          )}

          {/* login info */}
          <div className="flex items-start gap-2.5 rounded-2xl glass p-4 text-[11px] leading-relaxed text-muted-foreground">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-sky-400" />
            <p>
              Buat pakai akunnya: buka <b>CapCut → Masuk → pakai email</b> (salin password di atas).
              Akun dibuat melalui server FanzzTools — simpan kredensialnya sekarang karena tidak disimpan permanen.
            </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
