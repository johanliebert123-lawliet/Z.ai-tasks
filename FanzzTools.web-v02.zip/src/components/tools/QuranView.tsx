"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  BookOpen, Search, Loader2, ChevronLeft, Play, Pause, SkipBack, SkipForward,
  Copy, Check, Volume2, Users, Repeat, Square, Sparkles, Gauge,
} from "lucide-react";

/**
 * Qur'an Digital (V2 Modern-UpdSec).
 *  - 114 surah lengkap (Arab Utsmani + latin + terjemahan Kemenag + tafsir)
 *  - 15 imam tersedia (6 imam mati dihapus — permintaan #3 zuperupdt)
 *  - 6 qari audio full surah (equran.id)
 *  - putar per-ayat berurutan otomatis + skip ayat + waktu berjalan
 *  - PERBARUAN #3 zuperupdt: kecepatan putar (0.75x–2x) + progress bar
 *    yang bisa DISEDRAG (mode per-ayat = geser dalam ayat, full surah =
 *    geser ke posisi mana pun), semua bacaan bisa disalin
 */

interface SurahItem {
  nomor: number;
  nama: string;
  namaLatin: string;
  jumlahAyat: number;
  tempatTurun: string;
  arti: string;
  deskripsi: string | null;
  audioFull?: Record<string, string> | null;
}

interface AyatItem {
  nomorAyat: number;
  globalAyah: number;
  teksArab: string;
  teksLatin: string;
  teksIndonesia: string;
  tafsir: string | null;
  audio?: Record<string, string> | null;
}

interface Imam {
  id: string;
  name: string;
}

interface AudioFullImam {
  key: string;
  name: string;
}

/** PERBAIKAN audio (#1 — "imam lagi bermasalah, coba imam yang lain"):
 *  audio kini di-STREAM lewat /api/quran/audio (same-origin — bebas CORS),
 *  dengan rantai sumber berikut; bila satu gagal otomatis pindah ke berikutnya:
 *    per-ayat: cdn.islamic.network → everyayah.com → cdn.equran.id (audio-partial)
 *    full-surah: cdn.equran.id (audio-full) → cdn.islamic.network (audio-surah)
 *  View TIDAK lagi memanggil CDN eksternal langsung. */
const AUDIO_PROXY = (imam: string, surah: number, ayat: number) =>
  `/api/quran/audio?imam=${encodeURIComponent(imam)}&surah=${surah}&ayat=${ayat}`;

const AUDIO_PROXY_FULL = (url: string, imam: string, surah: number) =>
  `/api/quran/audio?full=1&url=${encodeURIComponent(url)}&imam=${encodeURIComponent(imam)}&surah=${surah}`;

function fmtTime(t: number) {
  if (!Number.isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function QuranView() {
  const [query, setQuery] = useState("");
  const [surahs, setSurahs] = useState<SurahItem[] | null>(null);
  const [imams, setImams] = useState<Imam[]>([]);
  const [imamFull, setImamFull] = useState<AudioFullImam[]>([]);
  const [detail, setDetail] = useState<{ surah: SurahItem; ayat: AyatItem[] } | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [tafsirMode, setTafsirMode] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  // pemutar
  const [imamIdx, setImamIdx] = useState(0);
  const [imamFullIdx, setImamFullIdx] = useState(2); // default: Sudais (03)
  const [mode, setMode] = useState<"perAyat" | "fullSurah">("perAyat");
  const [playing, setPlaying] = useState(false);
  const [currentAyat, setCurrentAyat] = useState(0); // index 0-based di detail.ayat
  const [elapsed, setElapsed] = useState(0);
  const [durasi, setDurasi] = useState(0);
  const [loop, setLoop] = useState(false);
  /** PERBARUAN #3: kecepatan putar audio — 0.75x s/d 2x (default 1x) */
  const [speed, setSpeed] = useState(1);
  const SPEEDS = [0.75, 1, 1.25, 1.5, 2] as const;
  const audioRef = useRef<HTMLAudioElement | null>(null);
  /** PERBARUAN #3: elemen progress bar yang bisa disedrag */
  const barRef = useRef<HTMLDivElement | null>(null);
  const [dragging, setDragging] = useState(false);
  const { toast } = useToast();

  /* ---------- daftar surah ---------- */
  useEffect(() => {
    fetch("/api/quran?list=1")
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok) {
          setSurahs(d.surahs);
          setImams(d.imamPerAyat);
          setImamFull(d.imamAudioFull);
        } else {
          setSurahs([]);
        }
      })
      .catch(() => setSurahs([]));
  }, []);

  /* ---------- buka surah ---------- */
  const openSurah = useCallback(async (nomor: number, withTafsir = false) => {
    setDetailLoading(true);
    setDetail(null);
    setPlaying(false);
    setCurrentAyat(0);
    setElapsed(0);
    try {
      const r = await fetch(`/api/quran?surah=${nomor}${withTafsir ? "&tafsir=1" : ""}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memuat surah");
      setDetail({ surah: d.surah, ayat: d.ayat });
      if (withTafsir !== tafsirMode) setTafsirMode(withTafsir);
      pushHistory("quran", { id: String(nomor), title: d.surah.namaLatin, subtitle: `${d.surah.jumlahAyat} ayat • ${d.surah.tempatTurun}` });
      window.scrollTo({ top: 0 });
    } catch (e) {
      toast({ title: "Gagal memuat surah", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setDetailLoading(false);
    }
  }, [tafsirMode, toast]);

  /* ---------- audio engine (via proxy same-origin — fix #1) ---------- */
  const audioUrl = useMemo(() => {
    if (!detail) return null;
    if (mode === "fullSurah") {
      const key = imamFull[imamFullIdx]?.key;
      const url = key ? detail.surah.audioFull?.[key] : null;
      if (!url) return null;
      return AUDIO_PROXY_FULL(url, imams[Math.min(imamIdx, imams.length - 1)]?.id || "ar.alafasy", detail.surah.nomor);
    }
    const imam = imams[imamIdx]?.id;
    const ay = detail.ayat[currentAyat];
    if (!imam || !ay) return null;
    return AUDIO_PROXY(imam, detail.surah.nomor, ay.nomorAyat);
  }, [detail, mode, imamIdx, imamFullIdx, imams, imamFull, currentAyat]);

  useEffect(() => {
    const a = audioRef.current;
    if (!a || !audioUrl) return;
    // PERBAIKAN #1: tanpa crossOrigin — src same-origin (proxy), tak butuh CORS
    a.removeAttribute("crossorigin");
    a.src = audioUrl;
    a.playbackRate = speed; // kecepatan dipertahankan antar ayat/surah
    if (playing) a.play().catch(() => setPlaying(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioUrl]);

  // terapkan kecepatan kapan pun diubah
  useEffect(() => {
    const a = audioRef.current;
    if (a) a.playbackRate = speed;
  }, [speed]);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    const onTime = () => setElapsed(a.currentTime);
    const onMeta = () => setDurasi(Number.isFinite(a.duration) ? a.duration : 0);
    const onEnd = () => {
      if (mode === "perAyat" && detail) {
        const next = currentAyat + 1;
        if (next < detail.ayat.length) {
          setCurrentAyat(next);
        } else if (loop) {
          setCurrentAyat(0);
        } else {
          setPlaying(false);
          toast({ title: "Selesai 🕋", description: `Surah ${detail.surah.namaLatin} selesai dibaca.` });
        }
      }
    };
    a.addEventListener("timeupdate", onTime);
    a.addEventListener("loadedmetadata", onMeta);
    a.addEventListener("ended", onEnd);
    return () => {
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("loadedmetadata", onMeta);
      a.removeEventListener("ended", onEnd);
    };
  }, [mode, detail, currentAyat, loop, toast]);

  const togglePlay = () => {
    const a = audioRef.current;
    if (!a || !audioUrl) {
      toast({ title: "Audio belum siap", description: "Pilih surah dulu." });
      return;
    }
    if (playing) {
      a.pause();
      setPlaying(false);
    } else {
      a.play().then(() => setPlaying(true)).catch(() => {
        toast({ title: "Gagal memutar audio", description: "Sumber audio sedang gangguan — sistem otomatis mencoba sumber cadangan; coba imam lain bila tetap gagal.", variant: "destructive" });
        setPlaying(false);
      });
    }
  };

  const skip = (delta: number) => {
    if (!detail) return;
    if (mode === "fullSurah") {
      const a = audioRef.current;
      if (a) a.currentTime = Math.max(0, a.currentTime + delta * 10);
      return;
    }
    const next = Math.min(Math.max(currentAyat + delta, 0), detail.ayat.length - 1);
    setCurrentAyat(next);
  };

  /* ---------- PERBARUAN #3: progress bar yang bisa di-DRAG ----------
   * Pointer events (mouse + sentuh): hitung rasio posisi jari terhadap
   * lebar bar, lalu set currentTime audio (mode full surah = bebas,
   * mode per-ayat = geser dalam ayat yang sedang diputar). */
  const seekToRatio = (ratio: number) => {
    const a = audioRef.current;
    if (!a || !Number.isFinite(a.duration) || a.duration <= 0) return;
    const r = Math.max(0, Math.min(1, ratio));
    a.currentTime = r * a.duration;
    setElapsed(a.currentTime);
  };

  const ratioFromEvent = (e: PointerEvent | React.PointerEvent): number => {
    const bar = barRef.current;
    if (!bar) return 0;
    const rect = bar.getBoundingClientRect();
    return Math.max(0, Math.min(1, (e.clientX - rect.left) / Math.max(1, rect.width)));
  };

  // drag berkelanjutan: pasang listener global saat pointer ditekan di bar
  useEffect(() => {
    if (!dragging) return;
    const move = (ev: PointerEvent) => seekToRatio(ratioFromEvent(ev));
    const up = () => setDragging(false);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dragging]);

  const salin = (ay: AyatItem) => {
    const teks = `QS. ${detail?.surah.namaLatin} [${detail?.surah.nomor}]:${ay.nomorAyat}\n\n${ay.teksArab}\n\n${ay.teksLatin}\n\n"${ay.teksIndonesia}"`;
    try {
      navigator.clipboard.writeText(teks);
      setCopied(String(ay.nomorAyat));
      setTimeout(() => setCopied(null), 1600);
      toast({ title: `Ayat ${ay.nomorAyat} tersalin!` });
    } catch {
      toast({ title: "Gagal menyalin", variant: "destructive" });
    }
  };

  const filtered = useMemo(() => {
    if (!surahs) return null;
    const q = query.trim().toLowerCase();
    if (!q) return surahs;
    return surahs.filter(
      (s) => s.namaLatin.toLowerCase().includes(q) || s.arti.toLowerCase().includes(q) || String(s.nomor) === q || s.nama.includes(q)
    );
  }, [surahs, query]);

  /* ================= DETAIL SURAH ================= */
  if (detail || detailLoading) {
    return (
      <div>
        <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Qur'an Digital" subtitle="114 surah • 15 imam • audio per ayat & full" accent="emerald" />
        <button onClick={() => { setPlaying(false); setDetail(null); }} className="mb-3 flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3 py-2 text-[11px] font-bold text-muted-foreground">
          <ChevronLeft className="h-3.5 w-3.5" /> Daftar surah
        </button>

        {detailLoading && <div className="h-48 rounded-2xl shimmer" />}

        {detail && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            {/* info surah */}
            <div className="glass rounded-2xl p-4 text-center">
              <p className="text-[10px] font-bold text-muted-foreground">Surah ke-{detail.surah.nomor} • {detail.surah.tempatTurun} • {detail.surah.jumlahAyat} ayat</p>
              <h2 className="mt-1 text-xl font-extrabold text-emerald-300">{detail.surah.namaLatin}</h2>
              <p className="text-[11px] text-muted-foreground">({detail.surah.arti})</p>
              <p className="mt-1.5 text-2xl text-white/90" dir="rtl">{detail.surah.nama}</p>
              {detail.surah.deskripsi && (
                <p className="mt-2.5 text-left text-[10.5px] leading-relaxed text-muted-foreground">{detail.surah.deskripsi.slice(0, 280)}…</p>
              )}
            </div>

            {/* pemutar audio */}
            <div className="glass rounded-2xl p-4">
              <div className="mb-3 flex items-center justify-between gap-2">
                <div className="flex gap-1.5">
                  {(["perAyat", "fullSurah"] as const).map((m) => (
                    <button
                      key={m}
                      onClick={() => { setMode(m); setPlaying(false); setElapsed(0); }}
                      className={`rounded-full px-3 py-1.5 text-[10px] font-bold transition ${
                        mode === m ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {m === "perAyat" ? "Per Ayat" : "Full Surah"}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => openSurah(detail.surah.nomor, !tafsirMode)}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-bold transition ${
                    tafsirMode ? "bg-amber-500/20 text-amber-300" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  <Sparkles className="h-3 w-3" /> Tafsir {tafsirMode ? "ON" : "OFF"}
                </button>
              </div>

              {/* pilih imam */}
              <div className="mb-3 grid grid-cols-2 gap-2">
                {mode === "perAyat" ? (
                  <label className="col-span-2">
                    <span className="mb-1 flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-emerald-400">
                      <Users className="h-3 w-3" /> Pilih imam / qari ({imams.length})
                    </span>
                    <select
                      value={imamIdx}
                      onChange={(e) => setImamIdx(Number(e.target.value))}
                      className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none"
                    >
                      {imams.map((im, i) => (
                        <option key={im.id} value={i}>{im.name}</option>
                      ))}
                    </select>
                  </label>
                ) : (
                  <label className="col-span-2">
                    <span className="mb-1 flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-emerald-400">
                      <Users className="h-3 w-3" /> Qari full surah
                    </span>
                    <select
                      value={imamFullIdx}
                      onChange={(e) => setImamFullIdx(Number(e.target.value))}
                      className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none"
                    >
                      {imamFull.map((im) => (
                        <option key={im.key} value={Number(im.key) - 1}>{im.name}</option>
                      ))}
                    </select>
                    {!detail.surah.audioFull && (
                      <p className="mt-1 text-[9.5px] text-amber-300">Surah ini belum punya audio full — pakai mode Per Ayat.</p>
                    )}
                  </label>
                )}
              </div>

              {/* PERBARUAN #3: progress bar draggable + waktu */}
              <div className="mt-3">
                <div
                  ref={barRef}
                  onPointerDown={(e) => {
                    e.preventDefault();
                    setDragging(true);
                    seekToRatio(ratioFromEvent(e));
                  }}
                  role="slider"
                  aria-label="Posisi audio"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={durasi > 0 ? Math.round((elapsed / durasi) * 100) : 0}
                  className="group relative h-6 cursor-pointer touch-none select-none"
                >
                  <div className="absolute inset-x-0 top-1/2 h-1.5 -translate-y-1/2 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500"
                      style={{ width: `${durasi > 0 ? (elapsed / durasi) * 100 : 0}%` }}
                    />
                  </div>
                  <div
                    className={`absolute top-1/2 h-3.5 w-3.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-md ring-2 ring-emerald-400 transition-transform ${
                      dragging ? "scale-125" : "group-hover:scale-110"
                    }`}
                    style={{ left: `${durasi > 0 ? (elapsed / durasi) * 100 : 0}%` }}
                  />
                </div>
                <div className="mt-1 flex justify-between text-[9px] font-bold tabular-nums text-muted-foreground">
                  <span>{fmtTime(elapsed)}</span>
                  <span>{durasi ? fmtTime(durasi) : "--:--"}</span>
                </div>
              </div>

              {/* kontrol */}
              <div className="flex items-center gap-2.5">
                <button onClick={() => skip(-1)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground active:scale-90">
                  <SkipBack className="h-4 w-4" />
                </button>
                <button
                  onClick={togglePlay}
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/30 active:scale-90"
                >
                  {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5 translate-x-px" />}
                </button>
                <button onClick={() => skip(1)} className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-secondary text-muted-foreground active:scale-90">
                  <SkipForward className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setLoop((v) => !v)}
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full active:scale-90 ${
                    loop ? "bg-emerald-500/20 text-emerald-300" : "bg-secondary text-muted-foreground"
                  }`}
                  title="Ulangi otomatis"
                >
                  <Repeat className="h-4 w-4" />
                </button>
                {/* PERBARUAN #3: pemilih kecepatan putar */}
                <button
                  onClick={() => {
                    const idx = SPEEDS.indexOf(speed as (typeof SPEEDS)[number]);
                    setSpeed(SPEEDS[(idx + 1) % SPEEDS.length]);
                  }}
                  className={`flex h-10 shrink-0 items-center gap-1 rounded-full px-2.5 text-[10px] font-black tabular-nums active:scale-90 ${
                    speed !== 1 ? "bg-emerald-500/20 text-emerald-300" : "bg-secondary text-muted-foreground"
                  }`}
                  title="Kecepatan putar (kecepatan putar)"
                >
                  <Gauge className="h-3.5 w-3.5" /> {speed}x
                </button>
                <div className="min-w-0 flex-1 text-right">
                  {mode === "perAyat" ? (
                    <>
                      <p className="text-[10px] font-bold text-muted-foreground">
                        Ayat <b className="text-emerald-300">{detail.ayat[currentAyat]?.nomorAyat}</b> / {detail.surah.jumlahAyat}
                      </p>
                      <p className="text-[11px] font-extrabold tabular-nums text-emerald-300">{fmtTime(elapsed)} {durasi ? `/ ${fmtTime(durasi)}` : ""}</p>
                    </>
                  ) : (
                    <>
                      <p className="text-[10px] font-bold text-muted-foreground">Full surah · {imamFull[imamFullIdx]?.name.split(" ")[0]}</p>
                      <p className="text-[11px] font-extrabold tabular-nums text-emerald-300">{fmtTime(elapsed)} {durasi ? `/ ${fmtTime(durasi)}` : ""}</p>
                    </>
                  )}
                </div>
              </div>
              {/* NOTE: tanpa crossOrigin — audio di-stream same-origin via /api/quran/audio */}
              <audio ref={audioRef} preload="auto" />
            </div>

            {/* daftar ayat */}
            <div className="space-y-3">
              {detail.ayat.map((ay, i) => (
                <div
                  key={ay.nomorAyat}
                  onClick={() => { if (mode === "perAyat") setCurrentAyat(i); }}
                  className={`glass cursor-pointer rounded-2xl p-4 transition-all ${
                    mode === "perAyat" && currentAyat === i ? "ring-2 ring-emerald-400/60 bg-emerald-500/10" : ""
                  }`}
                >
                  <div className="mb-2 flex items-center justify-between gap-2">
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-[11px] font-black text-white">
                      {ay.nomorAyat}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {mode === "perAyat" && currentAyat === i && (
                        <span className="flex items-center gap-1 rounded-full bg-emerald-500/20 px-2 py-1 text-[9px] font-black text-emerald-300">
                          <Volume2 className="h-3 w-3" /> {playing ? "DIBACAKAN" : "DIPILIH"}
                        </span>
                      )}
                      <button
                        onClick={(e) => { e.stopPropagation(); salin(ay); }}
                        className="flex items-center gap-1 rounded-lg bg-secondary px-2 py-1 text-[9px] font-bold text-muted-foreground"
                      >
                        {copied === String(ay.nomorAyat) ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />} Salin
                      </button>
                    </div>
                  </div>
                  <p dir="rtl" className="text-right text-[20px] leading-[2.2] text-emerald-50" data-fanzz-selectable="1">{ay.teksArab}</p>
                  <p className="mt-2.5 text-[12px] italic leading-relaxed text-teal-200/90" data-fanzz-selectable="1">{ay.teksLatin}</p>
                  <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground" data-fanzz-selectable="1">"{ay.teksIndonesia}"</p>
                  {tafsirMode && ay.tafsir && (
                    <div className="mt-3 rounded-xl bg-amber-500/10 p-3" data-fanzz-selectable="1">
                      <p className="mb-1 text-[9px] font-black uppercase tracking-wider text-amber-400">Tafsir Kemenag</p>
                      <p className="text-[11px] leading-relaxed text-amber-100/80">{ay.tafsir}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    );
  }

  /* ================= DAFTAR SURAH ================= */
  return (
    <div>
      <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Qur'an Digital" subtitle="114 surah • 15 imam • Arab, latin, terjemahan, tafsir" accent="emerald" />

      <div className="relative">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Cari nama surah / arti / nomor…"
          className="rounded-xl pl-10"
        />
      </div>

      {!surahs && (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="h-24 rounded-2xl shimmer" />
          ))}
        </div>
      )}

      {surahs && !filtered?.length && (
        <div className="mt-4">
          <EmptyState icon={<Search className="h-8 w-8" />} title="Tidak ketemu" desc={`Tidak ada surah untuk "${query}" — coba nama lain (mis. Al-Kautsar / 108).`} />
        </div>
      )}

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
        {(filtered || []).map((s, i) => (
          <motion.button
            key={s.nomor}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(i * 0.02, 0.3) }}
            onClick={() => openSurah(s.nomor)}
            className="glass rounded-2xl p-3.5 text-left transition-transform active:scale-95"
          >
            <div className="flex items-center justify-between gap-1.5">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-[10px] font-black text-white">
                {s.nomor}
              </span>
              <span className="truncate text-[12px] font-extrabold">{s.namaLatin}</span>
              <span className="shrink-0 text-[15px] text-emerald-300/90" dir="rtl">{s.nama}</span>
            </div>
            <p className="mt-1 truncate text-[9.5px] text-muted-foreground">{s.arti} • {s.jumlahAyat} ayat</p>
            <p className="text-[9px] font-bold text-emerald-400/80">{s.tempatTurun}</p>
          </motion.button>
        ))}
      </div>
    </div>
  );
}
