"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Download, Link2, Loader2, DownloadCloud, ShieldCheck, Music4,
  Image as ImageIcon, Film, Headphones, RotateCcw, X, AlertTriangle,
} from "lucide-react";

interface MediaItem {
  quality: string;
  type: "video" | "audio" | "image";
  size?: string;
  url: string;
  format?: "mp4" | "mp3" | "other";
}

interface DlState {
  title: string;
  thumbnail: string;
  author?: string;
  source: string;
  medias: MediaItem[];
}

/** Unduhan yang lagi jalan — buat progress bar per file. */
interface ActiveDl {
  url: string;
  pct: number;
  totalMB: number | null;
  doneMB: number;
}

/** Tombol play bulat SVG custom dengan animasi pulse — sesuai permintaan
 *  "kasih petunjuk buat preview/dengerin nya kayak tombol play gitu tapi pake SVG". */
function PlayButton({ playing, onClick }: { playing: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      aria-label={playing ? "Jeda" : "Putar preview"}
      className="group relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg shadow-red-500/30 transition-transform active:scale-90"
    >
      {!playing && (
        <span className="absolute inset-0 animate-ping rounded-full bg-red-500/40 [animation-duration:2s]" />
      )}
      <svg viewBox="0 0 24 24" className="relative h-5 w-5 fill-white">
        {playing ? (
          <>
            <rect x="6" y="5" width="4" height="14" rx="1.5" />
            <rect x="14" y="5" width="4" height="14" rx="1.5" />
          </>
        ) : (
          <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.88l11-6.86a1.04 1.04 0 0 0 0-1.76l-11-6.86A1.04 1.04 0 0 0 8 5.14z" />
        )}
      </svg>
    </button>
  );
}

/** Ikon platform SVG inline (menggantikan emoji) — ringan & konsisten. */
function PlatformIcon({ kind, className = "h-3.5 w-3.5" }: { kind: string; className?: string }) {
  const paths: Record<string, string> = {
    tiktok: "M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 1 1-2.59-2.59c.27 0 .53.04.77.12V9.77a5.96 5.96 0 0 0-.77-.05 5.96 5.96 0 1 0 5.96 5.96V9.01a7.05 7.05 0 0 0 4.18 1.37V7.29a4.28 4.28 0 0 1-3.4-1.47z",
    youtube: "M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81zM9.55 15.57V8.43L15.82 12l-6.27 3.57z",
    instagram: "M12 2.16c3.2 0 3.58.01 4.85.07 1.17.05 1.8.25 2.23.41.56.22.96.48 1.38.9.42.42.68.82.9 1.38.16.42.36 1.06.41 2.23.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.05 1.17-.25 1.8-.41 2.23a3.7 3.7 0 0 1-.9 1.38c-.42.42-.82.68-1.38.9-.42.16-1.06.36-2.23.41-1.27.06-1.65.07-4.85.07s-3.58-.01-4.85-.07c-1.17-.05-1.8-.25-2.23-.41a3.7 3.7 0 0 1-1.38-.9 3.7 3.7 0 0 1-.9-1.38c-.16-.42-.36-1.06-.41-2.23C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85c.05-1.17.25-1.8.41-2.23.22-.56.48-.96.9-1.38.42-.42.82-.68 1.38-.9.42-.16 1.06-.36 2.23-.41 1.27-.06 1.65-.07 4.85-.07M12 0C8.74 0 8.33.01 7.05.07 5.78.13 4.9.33 4.14.63a5.9 5.9 0 0 0-2.13 1.38A5.9 5.9 0 0 0 .63 4.14C.33 4.9.13 5.78.07 7.05.01 8.33 0 8.74 0 12s.01 3.67.07 4.95c.06 1.27.26 2.15.56 2.91.3.79.72 1.46 1.38 2.13a5.9 5.9 0 0 0 2.13 1.38c.76.3 1.64.5 2.91.56C8.33 23.99 8.74 24 12 24s3.67-.01 4.95-.07c1.27-.06 2.15-.26 2.91-.56a5.9 5.9 0 0 0 2.13-1.38 5.9 5.9 0 0 0 1.38-2.13c.3-.76.5-1.64.56-2.91.06-1.28.07-1.69.07-4.95s-.01-3.67-.07-4.95c-.06-1.27-.26-2.15-.56-2.91a5.9 5.9 0 0 0-1.38-2.13A5.9 5.9 0 0 0 19.86.63C19.1.33 18.22.13 16.95.07 15.67.01 15.26 0 12 0zm0 5.84A6.16 6.16 0 1 0 12 18.16 6.16 6.16 0 0 0 12 5.84zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm7.85-10.4a1.44 1.44 0 1 1-2.88 0 1.44 1.44 0 0 1 2.88 0z",
    facebook: "M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.09 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.79-4.7 4.53-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.51c-1.49 0-1.95.93-1.95 1.89v2.26h3.32l-.53 3.5h-2.8V24C19.61 23.09 24 18.1 24 12.07z",
    twitter: "M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.41l-5.8-7.58-6.64 7.58H.47l8.6-9.83L0 1.15h7.6l5.24 6.93 6.06-6.93zm-1.29 19.5h2.04L6.49 3.24H4.3l13.31 17.41z",
    pinterest: "M12 0C5.37 0 0 5.37 0 12c0 5.08 3.16 9.43 7.63 11.17-.11-.95-.2-2.4.04-3.44.22-.93 1.4-5.94 1.4-5.94s-.36-.71-.36-1.77c0-1.66.96-2.9 2.16-2.9 1.02 0 1.51.76 1.51 1.68 0 1.02-.65 2.55-.99 3.97-.28 1.19.6 2.16 1.77 2.16 2.12 0 3.76-2.24 3.76-5.47 0-2.86-2.06-4.86-5-4.86-3.4 0-5.39 2.55-5.39 5.18 0 1.03.4 2.13.89 2.73.1.12.11.22.08.34l-.33 1.36c-.05.22-.17.27-.4.16-1.5-.7-2.43-2.89-2.43-4.65 0-3.78 2.75-7.26 7.93-7.26 4.16 0 7.4 2.97 7.4 6.93 0 4.14-2.61 7.47-6.23 7.47-1.22 0-2.36-.63-2.75-1.38l-.75 2.85c-.27 1.04-1 2.35-1.49 3.15C9.57 23.8 10.76 24 12 24c6.63 0 12-5.37 12-12S18.63 0 12 0z",
    capcut: "M12 2a10 10 0 1 0 10 10h-2.5A7.5 7.5 0 1 1 12 4.5V2zM12 7v10l8-5-8-5zM2 12A10 10 0 0 1 12 2v2.5A7.5 7.5 0 1 0 19.5 12H22a10 10 0 0 1-20 0z",
    threads: "M16.5 11.2c-.1 0-.2 0-.3-.1-.06-2.2-1.3-3.5-3.4-3.5-1.2 0-2.3.5-2.9 1.5l1.2.8c.4-.7 1.1-.8 1.7-.8.7 0 1.4.2 1.6 1.1-.5-.1-1-.1-1.5-.1-1.7 0-3.6.8-3.6 2.8 0 1.6 1.3 2.5 2.9 2.5 1.4 0 2.3-.6 2.8-1.5.3.6.5 1.4.5 2.3 0 2.9-2.3 4.6-5.2 4.6-3.4 0-5.6-2.3-5.6-5.7 0-3.5 2.3-5.9 5.6-5.9v-1.4C7.9 6.9 4.5 9.9 4.5 14.3c0 4.1 2.9 7.2 7.3 7.2 4.1 0 7.1-2.8 7.1-6.5 0-.9-.2-1.7-.4-2.4.5.1 1 .2 1.5.2v-1.6zM12 16.2c-.8 0-1.5-.4-1.5-1.1 0-.9 1-1.2 1.9-1.2.4 0 .8 0 1.2.1-.2 1.3-1 2.2-1.6 2.2z",
    reddit: "M24 12c0-1.1-.9-2-2-2-.5 0-1 .2-1.4.5-1.4-.9-3.2-1.5-5.2-1.6l1-3.2 2.7.6c0 .9.7 1.6 1.6 1.6s1.6-.7 1.6-1.6-.7-1.6-1.6-1.6c-.6 0-1.1.3-1.4.9l-3.7-.8-1.4 4.4c-2 .1-3.9.7-5.3 1.6-.4-.3-.9-.5-1.4-.5-1.1 0-2 .9-2 2 0 .8.5 1.5 1.1 1.8v.7c0 2.6 3 4.7 6.7 4.7s6.7-2.1 6.7-4.7v-.7c.7-.3 1.1-1 1.1-1.8zM8.5 13.5c0-.6.5-1.1 1.1-1.1s1.1.5 1.1 1.1-.5 1.1-1.1 1.1-1.1-.5-1.1-1.1zm7.2 3.3c-.9.9-2.6 1-2.7 1s-1.8-.1-2.7-1l.7-.7c.5.5 1.5.7 2 .7s1.5-.2 2-.7l.7.7zm.7-2.2c-.6 0-1.1-.5-1.1-1.1s.5-1.1 1.1-1.1 1.1.5 1.1 1.1-.5 1.1-1.1 1.1z",
    soundcloud: "M1.2 13.5c-.1 0-.2.1-.2.2l-.2 1.7.2 1.6c0 .1.1.2.2.2s.2-.1.2-.2l.2-1.6-.2-1.7c0-.1-.1-.2-.2-.2zm1.8-1c-.1 0-.2.1-.2.2l-.2 2.7.2 2.6c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-2.6-.2-2.7c0-.1-.1-.2-.2-.2zm1.8-.4c-.1 0-.2.1-.2.2l-.2 3.1.2 3c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3-.2-3.1c0-.1-.1-.2-.2-.2zm1.9-.5c-.1 0-.2.1-.2.2l-.2 3.5.2 3.3c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.3-.2-3.5c0-.1-.1-.2-.2-.2zm2.5-1.3c-.1 0-.2.1-.2.2l-.1 4.7.1 3.4c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.4-.2-4.7c0-.1-.1-.2-.2-.2zm1.8-.7c-.1 0-.2.1-.2.2l-.1 5.4.1 3.5c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.5-.2-5.4c0-.1-.1-.2-.2-.2zm1.9-.1c-.1 0-.2.1-.2.2l-.1 5.5.1 3.5c0 .1.1.2.2.2s.2-.1.2-.2l.2-3.5-.2-5.5c0-.1-.1-.2-.2-.2zm2.4 0c-.1 0-.2.1-.2.2l-.1 5.5.1 3.4c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.4-.2-5.5c0-.1-.1-.2-.2-.2zm1.8.4c-.1 0-.2.1-.2.2l-.1 5.1.1 3.3c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.3-.2-5.1c0-.1-.1-.2-.2-.2zm1.9-1.3c-.1 0-.2.1-.2.2l-.1 6.4.1 3.2c0 .1.1.2.2.2.1 0 .2-.1.2-.2l.2-3.2-.2-6.4c0-.1-.1-.2-.2-.2zm2-2c-.1 0-.2.1-.2.2l-.1 8.4.1 3.1c0 .1.1.2.2.2s.2-.1.2-.2l.2-3.1-.2-8.4c0-.1-.1-.2-.2-.2zm1.9-1c-.1 0-.2.1-.2.2l-.1 9.4.1 3.1c0 .1.1.2.2.2s.2-.1.2-.2l.2-3.1-.2-9.4c0-.1-.1-.2-.2-.2z",
    generic: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z",
  };
  const key =
    kind === "TikTok" ? "tiktok" :
    kind === "YouTube" ? "youtube" :
    kind === "Instagram" ? "instagram" :
    kind === "Facebook" ? "facebook" :
    kind === "Twitter/X" ? "twitter" :
    kind === "Pinterest" ? "pinterest" :
    kind === "CapCut" ? "capcut" :
    kind === "Threads" ? "threads" :
    kind === "Reddit" ? "reddit" :
    kind === "SoundCloud" ? "soundcloud" : "generic";
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden="true">
      <path d={paths[key]} />
    </svg>
  );
}

const PLATFORMS = ["TikTok", "YouTube", "Instagram", "Facebook", "Twitter/X", "Pinterest", "CapCut", "Threads", "Reddit", "SoundCloud", "Likee", "Vidio", "Streamable", "Dailymotion"];

/** Ekstensi dari mime / URL — biar nama file unduhan selalu bener. */
function extFor(m: MediaItem): string {
  const u = m.url.toLowerCase();
  const extMatch = u.match(/\.(mp4|mkv|webm|mov|mp3|m4a|opus|aac|wav|jpg|jpeg|png|webp|gif)(?:\?|$)/);
  if (extMatch) return extMatch[1] === "jpeg" ? "jpg" : extMatch[1];
  return m.type === "audio" ? (m.url.includes("aceimg") ? "mp3" : "m4a") : m.type === "image" ? "jpg" : "mp4";
}

export default function DownloaderView() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DlState | null>(null);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<"all" | "mp4" | "mp3">("all");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewType, setPreviewType] = useState<"video" | "audio" | "image">("video");
  const [activeDl, setActiveDl] = useState<ActiveDl | null>(null);
  const { toast } = useToast();

  /** URL proxy buat PREVIEW — lewat server biar gak kena CORS/Referer block.
   *  FIX (#2): URL dari InnerTube SUDAH berupa proxy relatif (/api/download/file?url=…)
   *  — jangan dibungkus dua kali (dulu double-encode bikin preview gagal 400
   *  "Tautan file tidak valid" dan unduhan YT ter-redirect ke halaman sendiri). */
  const previewProxy = (m: MediaItem) =>
    m.url.startsWith("/api/download/file")
      ? `${m.url}${m.url.includes("?") ? "&" : "?"}inline=1`
      : `/api/download/file?inline=1&url=${encodeURIComponent(m.url)}`;

  const fileName = (m: MediaItem) =>
    `${(result?.title || "fanzz")
      .replace(/[\\/:*?"<>|]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80) || "fanzz"} - ${m.quality.replace(/[\\/:*?"<>|]/g, " ").trim()}.${extFor(m)}`;

  /** FIX (#2): bila URL sudah proxy relatif → pakai apa adanya (tambah name);
   *  bila absolut → bungkus lewat proxy. */
  const downloadApiUrl = (m: MediaItem) =>
    m.url.startsWith("/api/download/file")
      ? `${m.url}${m.url.includes("?") ? "&" : "?"}name=${encodeURIComponent(fileName(m))}`
      : `/api/download/file?url=${encodeURIComponent(m.url)}&name=${encodeURIComponent(fileName(m))}`;

  /** UNDUH BLOB dengan progress — cek content-type dulu, kalau json/html = error toast
   *  (bukan lagi nyimpen file json — bug lama fix). File >300MB dibuka langsung (streaming anchor).
   *  V0.01 (#1): bila proxy ditolak sumber (error http), otomatis jatuh ke mode
   *  unduh LANGSUNG (browser mengambil dari CDN sumber sendiri). */
  const doDownload = async (m: MediaItem) => {
    const apiUrl = downloadApiUrl(m);
    try {
      const res = await fetch(apiUrl);
      const ct = (res.headers.get("content-type") || "").toLowerCase();

      if (!res.ok || /json|javascript|text\/html|text\/plain/.test(ct)) {
        let msg = "File gagal diambil dari server sumber";
        let directUrl: string | undefined;
        try {
          const d = await res.json();
          msg = d?.error || msg;
          directUrl = d?.directUrl;
        } catch {
          /* ignore */
        }
        // fallback: unduh langsung dari sumber HANYA bila punya URL absolut http(s).
        // FIX (#2): URL relatif (proxy milik sendiri) TIDAK boleh dipakai navigasi
        // anchor — dulu inilah penyebab "YT downloader ke-redirect ke halaman FanzzTools sendiri".
        const direct = directUrl && /^https?:\/\//i.test(directUrl) ? directUrl : /^https?:\/\//i.test(m.url) ? m.url : null;
        if (direct) {
          const a = document.createElement("a");
          a.href = direct;
          a.download = fileName(m);
          a.target = "_blank";
          a.rel = "noopener";
          document.body.appendChild(a);
          a.click();
          a.remove();
          toast({
            title: "Beralih ke unduh langsung ⬇️",
            description: "Server sumber menolak mode proxy — browser kamu mengambil file langsung dari CDN sumber.",
          });
          return;
        }
        toast({
          title: "Unduhan gagal",
          description: `${msg} — coba muat ulang tautannya atau pilih kualitas lain.`,
        });
        return;
      }

      const total = Number(res.headers.get("content-length")) || 0;

      // file gede banget → biarin browser yang stream (jangan blob di RAM)
      if (total > 300 * 1024 * 1024) {
        const a = document.createElement("a");
        a.href = apiUrl;
        a.download = fileName(m);
        a.click();
        toast({ title: "Unduhan besar dimulai ⬇️", description: "File >300MB — browser yang ngatur sisa unduhannya." });
        return;
      }

      // progress via stream
      const reader = res.body?.getReader();
      if (!reader) throw new Error("no body");
      const chunks: BlobPart[] = [];
      let done = 0;
      setActiveDl({ url: m.url, pct: 0, totalMB: total ? total / 1024 / 1024 : null, doneMB: 0 });

      while (true) {
        const { done: finished, value } = await reader.read();
        if (finished) break;
        chunks.push(value as BlobPart);
        done += value.byteLength;
        setActiveDl({
          url: m.url,
          pct: total ? Math.min(99, Math.round((done / total) * 100)) : -1,
          totalMB: total ? total / 1024 / 1024 : null,
          doneMB: done / 1024 / 1024,
        });
      }

      const blob = new Blob(chunks, { type: ct.split(";")[0] || "application/octet-stream" });
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objUrl;
      a.download = fileName(m);
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(objUrl), 8000);

      setActiveDl((d) => (d?.url === m.url ? { ...d!, pct: 100 } : d));
      toast({
        title: "Unduhan tersimpan ✅",
        description: `"${fileName(m)}" masuk folder Download / galeri kamu`,
      });
      setTimeout(() => setActiveDl((d) => (d?.url === m.url ? null : d)), 2500);
    } catch {
      setActiveDl(null);
      toast({
        title: "Unduhan gagal ⚠️",
        description: "Koneksi ke sumbernya putus — coba lagi atau pilih kualitas lain.",
      });
    }
  };

  const go = async () => {
    const u = url.trim();
    if (!u || loading) return;
    if (!/^https?:\/\//i.test(u)) {
      setError("Link harus mulai dengan http:// atau https://");
      return;
    }
    setLoading(true);
    setError("");
    setResult(null);
    setPreviewUrl(null);
    try {
      const res = await fetch(`/api/download?url=${encodeURIComponent(u)}`);
      const d = await res.json();
      if (!res.ok || !d?.ok) throw new Error(d?.error || "Gagal memproses link");
      setResult({ title: d.title, thumbnail: d.thumbnail, author: d.author, source: d.source, medias: d.medias });
      setFilter("all");
      // V0.01 (#7): catat riwayat unduhan
      pushHistory("downloader", {
        id: u,
        title: d.title || u.slice(0, 60),
        subtitle: `${d.medias?.length || 0} format tersedia`,
        poster: d.thumbnail || null,
        url: u,
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memproses");
    } finally {
      setLoading(false);
    }
  };

  const filtered = useMemo(() => {
    if (!result) return [];
    if (filter === "mp4") return result.medias.filter((m) => m.type === "video");
    if (filter === "mp3") return result.medias.filter((m) => m.type === "audio");
    return result.medias;
  }, [result, filter]);

  const hasMp4 = result?.medias.some((m) => m.type === "video");
  const hasMp3 = result?.medias.some((m) => m.type === "audio");
  const hasImage = result?.medias.some((m) => m.type === "image");

  return (
    <div>
      <ToolHeader icon={<Download className="h-5.5 w-5.5" />} title="All-in-One Downloader" subtitle="TikTok • YT • IG • FB • Twitter • dll" accent="emerald" />

      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-5">
        <div className="relative">
          <Link2 className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={url}
            onChange={(e) => { setUrl(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            placeholder="Tempel link di sini..."
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 text-sm"
          />
        </div>
        <Button
          onClick={go}
          disabled={loading || !url.trim()}
          className="mt-3 w-full rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 py-5 text-sm font-bold shadow-lg shadow-emerald-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
        >
          {loading ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <DownloadCloud className="mr-2 h-4.5 w-4.5" />}
          {loading ? "Memproses link..." : "Proses Sekarang"}
        </Button>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {PLATFORMS.map((p) => (
            <span key={p} className="flex items-center gap-1 rounded-full bg-secondary/60 px-2.5 py-1 text-[10px] font-semibold text-muted-foreground">
              <PlatformIcon kind={p} className="h-3 w-3" /> {p}
            </span>
          ))}
        </div>
      </motion.div>

      {error && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          {error}
        </motion.p>
      )}

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-4 overflow-hidden rounded-3xl glass"
          >
            {/* header hasil */}
            <div className="flex items-center gap-3.5 p-4">
              {result.thumbnail ? (
                <img src={result.thumbnail} alt="" className="h-16 w-16 shrink-0 rounded-xl object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-secondary text-muted-foreground"><Film className="h-7 w-7" /></div>
              )}
              <div className="min-w-0 flex-1">
                <p className="clamp-2 text-sm font-bold">{result.title}</p>
                <div className="mt-1 flex items-center gap-2 text-[11px] text-muted-foreground">
                  {result.author && <span className="truncate">by {result.author}</span>}
                  <span className="rounded-full bg-emerald-500/15 px-1.5 py-px font-bold text-emerald-300">{result.source}</span>
                </div>
              </div>
              <button
                onClick={go}
                className="shrink-0 rounded-xl bg-secondary/70 p-2.5 text-muted-foreground transition-colors hover:text-foreground"
                title="Muat ulang link ini"
              >
                <RotateCcw className="h-4 w-4" />
              </button>
            </div>

            {/* pilihan format: MP4 / MP3 */}
            {(hasMp4 || hasMp3) && (
              <div className="flex items-center gap-2 px-4 pb-2">
                <span className="text-[10px] font-bold text-muted-foreground">PILIH FORMAT:</span>
                {(["all", "mp4", "mp3"] as const).map((f) => {
                  const disabled = (f === "mp4" && !hasMp4) || (f === "mp3" && !hasMp3);
                  const count = f === "all" ? result.medias.length : f === "mp4" ? result.medias.filter((m) => m.type === "video").length : result.medias.filter((m) => m.type === "audio").length;
                  if (f !== "all" && count === 0) return null;
                  return (
                    <button
                      key={f}
                      disabled={disabled}
                      onClick={() => setFilter(f)}
                      className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold transition-all ${
                        filter === f
                          ? f === "mp3"
                            ? "bg-cyan-500/20 text-cyan-300 ring-1 ring-cyan-400/40"
                            : "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40"
                          : "bg-secondary/60 text-muted-foreground"
                      }`}
                    >
                      {f === "mp4" && <Film className="h-3 w-3" />}
                      {f === "mp3" && <Headphones className="h-3 w-3" />}
                      {f === "all" ? `Semua (${count})` : f.toUpperCase()}
                      {f !== "all" ? ` (${count})` : ""}
                    </button>
                  );
                })}
              </div>
            )}

            {/* area preview — LEWAT PROXY biar selalu jalan (Range/206 + referer diurus server) */}
            <AnimatePresence mode="wait">
              {previewUrl && (
                <motion.div
                  key={previewUrl}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="px-4"
                >
                  <div className="relative overflow-hidden rounded-2xl bg-black/50 ring-1 ring-white/10">
                    {previewType === "video" && (
                      <video src={previewUrl} controls autoPlay playsInline className="max-h-[46vh] w-full bg-black" />
                    )}
                    {previewType === "audio" && (
                      <div className="flex items-center gap-3 p-4">
                        <img src={result.thumbnail} alt="" className="h-14 w-14 rounded-xl object-cover" referrerPolicy="no-referrer" />
                        <audio src={previewUrl} controls autoPlay className="h-10 w-full" />
                      </div>
                    )}
                    {previewType === "image" && (
                      <img src={previewUrl} alt="preview" className="max-h-[46vh] w-full object-contain bg-black" />
                    )}
                    <button
                      onClick={() => setPreviewUrl(null)}
                      className="absolute right-2 top-2 rounded-full bg-black/60 p-1.5 text-white/80 backdrop-blur-md transition-colors hover:text-white"
                      aria-label="Tutup preview"
                    >
                      <X className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <p className="mt-1.5 pb-1 text-center text-[10px] text-muted-foreground">
                    ▶ Preview jalan langsung di sini — dengerin/lihat dulu, baru unduh
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* daftar media */}
            <div className="space-y-2 px-4 pb-4 pt-2">
              {filtered.map((m, i) => (
                <div
                  key={i}
                  className="rounded-2xl bg-secondary/50 px-3 py-3 transition-all hover:bg-secondary"
                >
                  <div className="flex items-center gap-3">
                    {/* tombol play SVG — preview lewat proxy */}
                    <PlayButton
                      playing={previewUrl === previewProxy(m)}
                      onClick={() => {
                        if (previewUrl === previewProxy(m)) {
                          setPreviewUrl(null);
                        } else {
                          setPreviewUrl(previewProxy(m));
                          setPreviewType(m.type);
                        }
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-1.5 text-sm font-bold">
                        {m.type === "audio" ? <Music4 className="h-3.5 w-3.5 shrink-0 text-cyan-400" /> : m.type === "image" ? <ImageIcon className="h-3.5 w-3.5 shrink-0 text-blue-600" /> : <Film className="h-3.5 w-3.5 shrink-0 text-emerald-400" />}
                        <span className="truncate">{m.quality}</span>
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        {m.size ? `Ukuran: ${m.size} • ` : ""}
                        {m.type === "audio" ? "Audio siap diputar" : m.type === "image" ? "Gambar" : "Video"}
                      </p>
                    </div>
                    <button
                      onClick={() => doDownload(m)}
                      disabled={activeDl?.url === m.url && activeDl.pct !== 100}
                      className="flex shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-3.5 py-2.5 text-xs font-bold text-white shadow-lg shadow-emerald-500/20 transition-transform active:scale-95 disabled:opacity-60"
                    >
                      <Download className="h-4 w-4" />
                      Unduh
                    </button>
                  </div>

                  {/* progress bar unduhan per-file */}
                  {activeDl?.url === m.url && (
                    <div className="mt-2.5">
                      <div className="h-2 overflow-hidden rounded-full bg-secondary">
                        <motion.div
                          className={`h-full rounded-full ${activeDl.pct === 100 ? "bg-gradient-to-r from-emerald-400 to-teal-400" : "bg-gradient-to-r from-red-500 to-red-600"}`}
                          animate={{ width: `${activeDl.pct < 0 ? 45 : activeDl.pct}%` }}
                          transition={{ ease: "easeOut", duration: 0.3 }}
                          style={activeDl.pct < 0 ? { animation: "shimmer 1.4s linear infinite" } : undefined}
                        />
                      </div>
                      <p className="mt-1 text-center text-[10px] font-semibold text-muted-foreground">
                        {activeDl.pct === 100
                          ? "Selesai — tersimpan di folder Unduhan"
                          : activeDl.pct < 0
                            ? `Mengunduh... ${activeDl.doneMB.toFixed(1)} MB`
                            : `Mengunduh... ${activeDl.pct}%${activeDl.totalMB ? ` dari ${activeDl.totalMB.toFixed(1)} MB` : ""}`}
                      </p>
                    </div>
                  )}
                </div>
              ))}
              {filtered.length === 0 && (
                <p className="py-4 text-center text-xs text-muted-foreground">Tidak ada format {filter.toUpperCase()} untuk tautan ini</p>
              )}
            </div>

            {hasImage && filter === "all" && result.medias.some((m) => m.type === "image") && (
              <p className="px-4 pb-4 text-[10px] text-muted-foreground">
                💡 Foto slideshow bisa dipreview satu-satu lewat tombol play, atau langsung diunduh.
              </p>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* petunjuk */}
      <div className="mt-4 rounded-2xl glass p-4 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1.5 font-bold text-foreground">Cara penggunaan:</p>
        <p>1. Tempel tautan video/foto (TikTok, YouTube, Instagram, dll) lalu tekan <b>Proses Sekarang</b></p>
        <p>2. Tekan tombol <b>putar bulat ungu</b> untuk pratinjau sebelum mengunduh</p>
        <p>3. Pilih format <b>MP4</b> (video) atau <b>MP3</b> (audio) apabila tersedia</p>
        <p>4. Tekan <b>Unduh</b> — pantau progresnya, file <b>langsung tersimpan</b> ke folder Unduhan / galeri tanpa berpindah halaman</p>
      </div>

      <div className="mt-3 flex items-start gap-2.5 rounded-2xl glass p-4 text-[11px] leading-relaxed text-muted-foreground">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
        <p>
          Tautan Anda diproses langsung tanpa disimpan di server. Sistem kini menggunakan beberapa penyedia
          sekaligus dengan deteksi halaman-error otomatis — bila satu penyedia sedang terproteksi, sistem
          otomatis beralih ke penyedia berikutnya tanpa menampilkan galat teknis.
        </p>
      </div>
    </div>
  );
}
