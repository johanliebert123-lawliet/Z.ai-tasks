"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import { useApp } from "@/lib/app-store";
import {
  Wifi, Radio, Loader2, MapPin, Globe, ShieldCheck, ShieldAlert, QrCode, RefreshCw,
  Signal, Lock, Unlock, Search, Eye, Camera, Fingerprint,
} from "lucide-react";

/**
 * Check WiFi Sekitar (zuperupdt #15) — analyzer jaringan milik sendiri.
 *
 *  Panel 1 — DETEKSI PRECISE: region via GPS (reverse geocode), tipe koneksi
 *  (Network Information API: 4g/downlink/rtt), IP publik + ISP (via /api/wifi),
 *  deteksi DNS resolver (percobaan DoH dari sisi klien, gagal = jujur ditulis).
 *
 *  Panel 2 — QR WiFi: pindai QR WiFi (format standang WIFI:T:WPA;S:ssid;P:pass;;)
 *  pakai kamera — SSID + password + keamanan terisi otomatis.
 *
 *  Panel 3 — TEBAK PASSWORD (maks 10): audit password jaringan SENDIRI terhadap
 *  10 pola default paling umum. Gagal semua → "Password tidak ditemukan"
 *  (berarti kuat). Cocok → peringatan ganti segera. Tidak pernah mencoba
 *  jaringan orang lain — itu ilegal.
 */

interface IpInfo {
  ip: string; isp: string; org: string; negara: string; region: string; kota: string;
  reverse: string; mobile: boolean; proxy: boolean;
}

/** Parse payload QR WiFi standang: WIFI:T:WPA;S:MySSID;P:rahasia;H:true;; */
function parseWifiQr(text: string): { ssid: string; pass: string; keamanan: string; hidden: boolean } | null {
  const t = text.trim();
  if (!/^WIFI:/i.test(t)) return null;
  const ambil = (k: string): string => {
    const m = new RegExp(`(?:^|;)${k}:([^;]*)`, "i").exec(t);
    return m ? m[1].replace(/\\(.)/g, "$1") : "";
  };
  const ssid = ambil("S");
  if (!ssid) return null;
  return {
    ssid,
    pass: ambil("P"),
    keamanan: (ambil("T") || "nopass").toUpperCase(),
    hidden: /^true$/i.test(ambil("H")),
  };
}

export default function WifiView() {
  const { toast } = useToast();
  const { geo } = useApp();

  /* ---- panel deteksi ---- */
  const [netInfo, setNetInfo] = useState<NetworkInformationLike | null>(null);
  const [ipInfo, setIpInfo] = useState<IpInfo | null>(null);
  const [ipLoading, setIpLoading] = useState(false);
  const [dnsInfo, setDnsInfo] = useState<string>("(belum dicek)");
  const [dnsCek, setDnsCek] = useState(false);
  const [online, setOnline] = useState(true);

  /* ---- panel QR ---- */
  const [qrScanning, setQrScanning] = useState(false);
  const [qrHasil, setQrHasil] = useState<{ ssid: string; pass: string; keamanan: string; hidden: boolean } | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  /* ---- panel tebak password ---- */
  const [ssid, setSsid] = useState("");
  const [brand, setBrand] = useState("");
  const [pw, setPw] = useState("");
  const [auditLoading, setAuditLoading] = useState(false);
  const [audit, setAudit] = useState<{ status: string; lemah: boolean; pesan: string; kandidat: string[]; totalTebakan: number; cocokPada?: number } | null>(null);
  const [kandidatPreview, setKandidatPreview] = useState<string[] | null>(null);

  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  /* Network Information API */
  useEffect(() => {
    const c = (navigator as Navigator & { connection?: NetworkInformationLike }).connection;
    if (c) {
      setNetInfo(c);
      const change = () => setNetInfo({ ...c });
      c.addEventListener?.("change", change);
      return () => c.removeEventListener?.("change", change);
    }
  }, []);

  const muatIp = useCallback(async () => {
    setIpLoading(true);
    try {
      const r = await fetch("/api/wifi?ip=1");
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "gagal");
      setIpInfo(d as IpInfo);
    } catch {
      toast({ title: "Gagal membaca info IP", variant: "destructive" });
    } finally {
      setIpLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    void muatIp();
    pushHistory("wifi", { id: "wifi-analyzer", title: "Check WiFi Sekitar", subtitle: "Analisis jaringan milik sendiri" });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Deteksi resolver DNS pengguna — dicoba dari sisi KLIEN (server tidak bisa
   *  melihat resolver pengguna). Endpoint edns mengembalikan subnet resolver
   *  lewat resolusi DNS nama domain itu sendiri. Bila CORS memblokir → jujur. */
  const cekDns = async () => {
    setDnsCek(true);
    setDnsInfo("memeriksa…");
    try {
      const r = await fetch("https://edns.ip-api.com/json", { signal: AbortSignal.timeout(8000) });
      const d = await r.json();
      if (d?.dns?.geo) setDnsInfo(`Resolver: ${d.dns.geo}${d.dns.ip ? ` (${d.dns.ip})` : ""}`);
      else if (d?.ip) setDnsInfo(`Resolver egress: ${d.ip}`);
      else setDnsInfo("Resolver tidak terdeteksi (browser memblokir)");
    } catch {
      setDnsInfo("Tidak terdeteksi — browser/KORS memblokir cek resolver");
    } finally {
      setDnsCek(false);
    }
  };

  /* ---------- pemindai QR WiFi ---------- */
  const mulaiScanQr = async () => {
    if (!("BarcodeDetector" in window)) {
      toast({ title: "Perangkat tidak mendukung pemindai QR bawaan", description: "Masukkan SSID & password secara manual di bawah (hasilnya sama)." });
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
      streamRef.current = stream;
      setQrScanning(true);
      await new Promise((r) => setTimeout(r, 250)); // tunggu video terpasang
      const v = videoRef.current;
      if (!v) throw new Error("video hilang");
      v.srcObject = stream;
      await v.play();
      const det = new (window as unknown as { BarcodeDetector: new (o: { formats: string[] }) => { detect: (s: HTMLVideoElement) => Promise<Array<{ rawValue: string }>> } }).BarcodeDetector({ formats: ["qr_code"] });
      const tick = async () => {
        if (!streamRef.current) return;
        try {
          const codes = await det.detect(v);
          if (codes && codes.length) {
            const hasil = parseWifiQr(String(codes[0].rawValue || ""));
            streamRef.current?.getTracks().forEach((t) => t.stop());
            streamRef.current = null;
            setQrScanning(false);
            if (hasil) {
              setQrHasil(hasil);
              setSsid(hasil.ssid);
              setPw(hasil.pass);
              toast({ title: "QR WiFi terbaca! 📶", description: `SSID "${hasil.ssid}" terisi otomatis di panel audit.` });
            } else {
              toast({ title: "QR bukan QR WiFi", description: "Format standang WiFi (WIFI:T:...;S:...;P:...) tidak ditemukan.", variant: "destructive" });
            }
            return;
          }
        } catch { /* lanjut frame berikutnya */ }
        requestAnimationFrame(() => void tick());
      };
      void tick();
    } catch {
      setQrScanning(false);
      toast({ title: "Kamera tidak diizinkan", description: "Masukkan SSID & password manual di panel audit (hasilnya sama).", variant: "destructive" });
    }
  };

  const stopScanQr = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setQrScanning(false);
  };

  /* ---------- audit password ---------- */
  const jalanAudit = async () => {
    if (!pw.trim()) {
      toast({ title: "Masukkan password WiFi kamu dulu", description: "Audit hanya untuk jaringan milik sendiri." });
      return;
    }
    setAuditLoading(true);
    setAudit(null);
    try {
      const r = await fetch(`/api/wifi?check=1&pw=${encodeURIComponent(pw)}&ssid=${encodeURIComponent(ssid)}&brand=${encodeURIComponent(brand)}`);
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "gagal");
      setAudit({ status: d.status, lemah: d.lemah, pesan: d.pesan, kandidat: d.kandidat || [], totalTebakan: d.totalTebakan, cocokPada: d.cocokPada });
    } catch (e) {
      toast({ title: "Audit gagal", description: e instanceof Error ? e.message : "coba lagi", variant: "destructive" });
    } finally {
      setAuditLoading(false);
    }
  };

  const lihatKandidat = async () => {
    try {
      const r = await fetch(`/api/wifi?guess=1&ssid=${encodeURIComponent(ssid)}&brand=${encodeURIComponent(brand)}`);
      const d = await r.json();
      if (d?.ok) setKandidatPreview(d.kandidat);
    } catch { /* diam */ }
  };

  return (
    <div>
      <ToolHeader icon={<Wifi className="h-5.5 w-5.5" />} title="Check WiFi Sekitar" subtitle="Analisis jaringan milikmu — region, IP, DNS, QR & audit password" accent="cyan" />

      {/* peringatan penggunaan */}
      <div className="glass rounded-2xl border border-amber-500/20 p-3.5">
        <p className="flex items-start gap-2 text-[10.5px] leading-relaxed text-amber-200/90">
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
          <span>
            Tools ini untuk <b>mengecek jaringan WiFi MILIK SENDIRI</b> (audit keamanan router/smartphone kamu).
            Menebak password jaringan orang lain tanpa izin itu <b>ilegal</b> (UU ITE). Tebakan pola dibatasi <b>maksimal 10</b> percobaan.
          </span>
        </p>
      </div>

      {/* ====== PANEL 1: DETEKSI ====== */}
      <div className="glass mt-4 rounded-2xl p-4">
        <div className="mb-3 flex items-center justify-between">
          <p className="flex items-center gap-1.5 text-sm font-extrabold">
            <Radio className="h-4 w-4 text-cyan-400" /> Deteksi Jaringan
          </p>
          <span className={`rounded-full px-2 py-0.5 text-[9px] font-black ${online ? "bg-emerald-500/15 text-emerald-300" : "bg-red-500/15 text-red-300"}`}>
            {online ? "ONLINE" : "OFFLINE"}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {/* region via GPS */}
          <div className="rounded-xl bg-secondary/50 p-3">
            <p className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wide text-muted-foreground">
              <MapPin className="h-3 w-3 text-cyan-400" /> Region (GPS)
            </p>
            <p className="mt-1 truncate text-[11px] font-extrabold">
              {geo && geo.mode !== "loading" ? geo.display || `${geo.lat.toFixed(3)}, ${geo.lon.toFixed(3)}` : geo?.mode === "loading" ? "mencari…" : "izinkan lokasi"}
            </p>
            {geo?.accuracy ? <p className="text-[9px] text-muted-foreground">±{Math.round(geo.accuracy)} m</p> : null}
          </div>
          {/* tipe koneksi */}
          <div className="rounded-xl bg-secondary/50 p-3">
            <p className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wide text-muted-foreground">
              <Signal className="h-3 w-3 text-cyan-400" /> Koneksi
            </p>
            <p className="mt-1 text-[11px] font-extrabold">{netInfo?.effectiveType?.toUpperCase() || "tidak terbaca"}</p>
            <p className="text-[9px] text-muted-foreground">
              {netInfo?.downlink ? `${netInfo.downlink} Mb/s • rtt ${netInfo.rtt ?? "?"} ms` : "Network Information API terbatas"}
            </p>
          </div>
          {/* IP publik */}
          <div className="rounded-xl bg-secondary/50 p-3">
            <p className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wide text-muted-foreground">
              <Globe className="h-3 w-3 text-cyan-400" /> IP Publik
            </p>
            {ipLoading ? (
              <Loader2 className="mt-1 h-4 w-4 animate-spin text-muted-foreground" />
            ) : ipInfo ? (
              <>
                <p className="mt-1 truncate font-mono text-[11px] font-extrabold">{ipInfo.ip}</p>
                <p className="truncate text-[9px] text-muted-foreground">{ipInfo.isp}{ipInfo.mobile ? " • seluler" : ""}{ipInfo.proxy ? " • proxy" : ""}</p>
              </>
            ) : (
              <p className="mt-1 text-[11px] text-muted-foreground">tidak terbaca</p>
            )}
          </div>
        </div>

        {/* DNS */}
        <div className="mt-2 flex items-center justify-between gap-2 rounded-xl bg-secondary/50 p-3">
          <div className="min-w-0">
            <p className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wide text-muted-foreground">
              <Fingerprint className="h-3 w-3 text-cyan-400" /> Resolver DNS
            </p>
            <p className="mt-1 truncate text-[11px] font-bold">{dnsInfo}</p>
          </div>
          <button onClick={cekDns} disabled={dnsCek} className="flex shrink-0 items-center gap-1.5 rounded-xl bg-secondary px-3 py-2 text-[10px] font-extrabold text-muted-foreground disabled:opacity-60">
            {dnsCek ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Search className="h-3.5 w-3.5" />} Cek DNS
          </button>
        </div>

        <button onClick={muatIp} disabled={ipLoading} className="mt-2 flex items-center gap-1.5 rounded-xl bg-secondary px-3 py-2 text-[10px] font-extrabold text-muted-foreground disabled:opacity-60">
          <RefreshCw className={`h-3.5 w-3.5 ${ipLoading ? "animate-spin" : ""}`} /> Segarkan deteksi
        </button>
      </div>

      {/* ====== PANEL 2: QR WIFI ====== */}
      <div className="glass mt-4 rounded-2xl p-4">
        <p className="mb-2 flex items-center gap-1.5 text-sm font-extrabold">
          <QrCode className="h-4 w-4 text-cyan-400" /> Pindai QR WiFi
        </p>
        <p className="mb-3 text-[10.5px] leading-relaxed text-muted-foreground">
          QR WiFi standang (format <span className="font-mono">WIFI:T:WPA;S:nama;P:sandi;;</span>) — biasanya tertempel di bawah router
          atau di bagian berbagi WiFi Android. Hasil pindai otomatis mengisi panel audit di bawah.
        </p>
        {qrScanning ? (
          <div className="space-y-2">
            <div className="relative overflow-hidden rounded-2xl bg-black">
              <video ref={videoRef} playsInline muted className="h-56 w-full object-cover" />
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="h-40 w-40 rounded-2xl border-2 border-cyan-400/80 shadow-[0_0_30px_rgba(34,211,238,0.4)]" />
              </div>
            </div>
            <button onClick={stopScanQr} className="w-full rounded-xl bg-red-500/15 px-4 py-2.5 text-xs font-extrabold text-red-300">
              Berhenti memindai
            </button>
          </div>
        ) : (
          <button onClick={mulaiScanQr} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 px-4 py-3 text-xs font-extrabold text-white">
            <Camera className="h-4 w-4" /> Pindai QR dengan Kamera
          </button>
        )}
        {qrHasil && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mt-3 rounded-xl bg-cyan-500/10 p-3">
            <p className="flex items-center gap-2 text-xs font-extrabold text-cyan-300">
              <Unlock className="h-3.5 w-3.5" /> QR terbaca
            </p>
            <div className="mt-2 space-y-1 text-[11px]">
              <p>SSID: <b className="font-mono">{qrHasil.ssid}</b></p>
              <p>Keamanan: <b>{qrHasil.keamanan}</b>{qrHasil.hidden ? " • tersembunyi" : ""}</p>
              {qrHasil.pass && <p>Password: <b className="font-mono">{qrHasil.pass}</b></p>}
              {!qrHasil.pass && <p className="text-muted-foreground">QR ini tidak memuat password (open network).</p>}
            </div>
          </motion.div>
        )}
      </div>

      {/* ====== PANEL 3: AUDIT PASSWORD ====== */}
      <div className="glass mt-4 rounded-2xl p-4">
        <p className="mb-1 flex items-center gap-1.5 text-sm font-extrabold">
          <Lock className="h-4 w-4 text-cyan-400" /> Audit Password (Maks 10 Tebakan)
        </p>
        <p className="mb-3 text-[10.5px] leading-relaxed text-muted-foreground">
          Password WiFi kamu diuji terhadap <b>maksimal 10 pola default paling umum</b> (admin, 12345678, nama-ssid+1234, dsb.).
          Jika tidak ada yang cocok → <b>&ldquo;Password tidak ditemukan&rdquo;</b> — artinya password-mu kuat. Jika cocok → ganti segera!
        </p>

        <div className="grid gap-2 sm:grid-cols-2">
          <div>
            <p className="mb-1 text-[9.5px] font-black uppercase tracking-wide text-muted-foreground">Nama WiFi (SSID)</p>
            <Input value={ssid} onChange={(e) => setSsid(e.target.value)} placeholder="mis. IndiHome-9A2C" className="rounded-xl" />
          </div>
          <div>
            <p className="mb-1 text-[9.5px] font-black uppercase tracking-wide text-muted-foreground">Merk Router (opsional)</p>
            <Input value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="mis. ZTE / TP-Link / Huawei" className="rounded-xl" />
          </div>
        </div>
        <div className="mt-2">
          <p className="mb-1 text-[9.5px] font-black uppercase tracking-wide text-muted-foreground">Password WiFi kamu (audit)</p>
          <Input value={pw} onChange={(e) => setPw(e.target.value)} placeholder="password WiFi milikmu" type="text" className="rounded-xl font-mono" />
        </div>

        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          <button onClick={jalanAudit} disabled={auditLoading} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-600 px-4 py-3 text-xs font-extrabold text-white disabled:opacity-60">
            {auditLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />} Uji Sekarang
          </button>
          <button onClick={lihatKandidat} className="flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold text-muted-foreground">
            <Eye className="h-4 w-4" /> Lihat 10 pola tebakan
          </button>
        </div>

        {kandidatPreview && (
          <div className="mt-3 rounded-xl bg-secondary/50 p-3">
            <p className="mb-1.5 text-[10px] font-black uppercase tracking-wide text-muted-foreground">10 pola tebakan paling umum</p>
            <div className="flex flex-wrap gap-1.5">
              {kandidatPreview.map((k) => (
                <span key={k} className="rounded-lg bg-secondary px-2 py-1 font-mono text-[10px] font-bold">{k}</span>
              ))}
            </div>
            <p className="mt-2 text-[9.5px] text-muted-foreground">Tebakan dibatasi 10 — lebih dari itu selalu &ldquo;tidak ditemukan&rdquo; (desain anti-penyalahgunaan).</p>
          </div>
        )}

        {audit && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`mt-3 rounded-xl p-4 ${audit.lemah ? "bg-red-500/10" : "bg-emerald-500/10"}`}
          >
            <p className={`flex items-center gap-2 text-sm font-extrabold ${audit.lemah ? "text-red-300" : "text-emerald-300"}`}>
              {audit.lemah ? <ShieldAlert className="h-4 w-4" /> : <ShieldCheck className="h-4 w-4" />}
              {audit.lemah ? `LEMAH — cocok pola #${audit.cocokPada}` : "Password tidak ditemukan"}
            </p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{audit.pesan}</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {audit.kandidat.slice(0, audit.lemah ? (audit.cocokPada || 0) : audit.totalTebakan).map((k) => (
                <span key={k} className={`rounded-lg px-2 py-0.5 font-mono text-[10px] font-bold ${audit.lemah ? "bg-red-500/15 text-red-300" : "bg-secondary text-muted-foreground"}`}>{k}</span>
              ))}
              {!audit.lemah && <span className="rounded-lg bg-emerald-500/15 px-2 py-0.5 text-[10px] font-black text-emerald-300">semua gagal ✓</span>}
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

interface NetworkInformationLike {
  effectiveType?: string;
  type?: string;
  downlink?: number;
  rtt?: number;
  saveData?: boolean;
  addEventListener?: (t: string, l: () => void) => void;
  removeEventListener?: (t: string, l: () => void) => void;
}
