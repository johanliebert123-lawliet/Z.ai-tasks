"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { Button } from "@/components/ui/button";
import {
  detectProfanity, LANGS, levelLabel, levelColor, type LangCode, type DetectResult,
} from "@/lib/profanity";
import {
  ShieldAlert, ScanSearch, Trash2, Sparkles, Languages, Gauge,
} from "lucide-react";

const SAMPLE = "Dasar anjing! Kamu ini goblok banget sih, dasar bodo amat. stupid idiot. Scheiße! baka kusoyarou!";

export default function ProfanityView() {
  const [text, setText] = useState("");
  const [selected, setSelected] = useState<LangCode[]>(["id", "en", "de", "ja", "su", "jv"]);
  const [result, setResult] = useState<DetectResult | null>(null);

  const toggleLang = (c: LangCode) => {
    setSelected((prev) => (prev.includes(c) ? prev.filter((x) => x !== c) : [...prev, c]));
  };

  const scan = () => {
    if (!text.trim()) {
      setResult(null);
      return;
    }
    setResult(detectProfanity(text, selected));
  };

  const totalWords = useMemo(() => (text.trim() ? text.trim().split(/\s+/).length : 0), [text]);

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<ShieldAlert className="h-5 w-5" />}
        title="Deteksi Kata Sensitif"
        desc="Pemeriksa kata kasar/sensitif multi-bahasa: Indonesia, Inggris (US/UK), Jerman, Jepang, Sunda, dan Jawa — lengkap dengan tingkat keparahan."
      />

      {/* pilih bahasa */}
      <section className="rounded-2xl glass p-3.5">
        <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
          <Languages className="h-3.5 w-3.5" /> Bahasa yang diperiksa
        </p>
        <div className="flex flex-wrap gap-2">
          {LANGS.map((l) => (
            <button
              key={l.code}
              onClick={() => toggleLang(l.code)}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-colors ${
                selected.includes(l.code)
                  ? "bg-gradient-to-r from-orange-500 to-red-600 text-white"
                  : "bg-secondary/60 text-muted-foreground hover:text-foreground"
              }`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </section>

      {/* input teks */}
      <section>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Tempel teks di sini — chat, caption, komentar, apa pun yang ingin diperiksa…"
          rows={6}
          className="w-full resize-y rounded-2xl border border-[var(--surface-line)] bg-[var(--surface-glass)] p-3.5 text-xs leading-relaxed outline-none placeholder:text-muted-foreground/60 focus:border-orange-400/50"
        />
        <div className="mt-2 flex flex-wrap items-center gap-2">
          <Button
            onClick={scan}
            disabled={!text.trim() || !selected.length}
            className="rounded-xl bg-gradient-to-r from-orange-500 to-red-600 text-white"
          >
            <ScanSearch className="mr-1.5 h-4 w-4" /> Periksa sekarang
          </Button>
          <Button
            variant="secondary"
            onClick={() => setText(SAMPLE)}
            className="rounded-xl text-[11px]"
          >
            <Sparkles className="mr-1.5 h-3.5 w-3.5" /> Coba contoh teks
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              setText("");
              setResult(null);
            }}
            className="rounded-xl text-[11px]"
          >
            <Trash2 className="mr-1.5 h-3.5 w-3.5" /> Bersihkan
          </Button>
          <span className="ml-auto text-[10px] font-bold text-muted-foreground">{totalWords} kata</span>
        </div>
      </section>

      {/* hasil */}
      <AnimatePresence>
        {result && (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="space-y-3"
          >
            {/* ringkasan */}
            <div className="grid grid-cols-4 gap-2">
              <div className="rounded-2xl glass p-3 text-center">
                <Gauge className={`mx-auto h-4 w-4 ${levelColor(result.levelMax)}`} />
                <p className={`mt-1 text-xs font-extrabold ${levelColor(result.levelMax)}`}>{levelLabel(result.levelMax)}</p>
                <p className="text-[9px] text-muted-foreground">Tingkat</p>
              </div>
              <div className="rounded-2xl glass p-3 text-center">
                <p className="text-lg font-extrabold text-orange-400">{result.total}</p>
                <p className="text-[9px] font-bold text-muted-foreground">Kata terdeteksi</p>
              </div>
              <div className="rounded-2xl glass p-3 text-center">
                <p className="text-lg font-extrabold text-cyan-400">{Object.values(result.perLang).filter(Boolean).length}</p>
                <p className="text-[9px] font-bold text-muted-foreground">Bahasa terlibat</p>
              </div>
              <div className="rounded-2xl glass p-3 text-center">
                <p className="text-lg font-extrabold text-emerald-400">{totalWords - result.total}</p>
                <p className="text-[9px] font-bold text-muted-foreground">Kata bersih</p>
              </div>
            </div>

            {/* daftar temuan */}
            {result.hits.length > 0 ? (
              <div className="overflow-hidden rounded-2xl glass">
                <p className="border-b border-[var(--surface-line)] px-4 py-2.5 text-[11px] font-bold text-muted-foreground">
                  Kata sensitif yang terdeteksi
                </p>
                <div className="divide-y divide-[var(--surface-line)]">
                  {result.hits.map((h, i) => (
                    <div key={`${h.index}-${i}`} className="flex items-center gap-3 px-4 py-2.5">
                      <span className={`rounded-lg px-2 py-1 text-[9px] font-extrabold ${levelColor(h.level)} bg-secondary`}>
                        {levelLabel(h.level)}
                      </span>
                      <p className="font-mono text-xs font-bold">"{h.word}"</p>
                      <span className="ml-auto rounded-full bg-secondary px-2 py-0.5 text-[9px] font-bold text-muted-foreground">
                        {LANGS.find((l) => l.code === h.lang)?.label}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="rounded-2xl bg-emerald-500/10 p-4 text-center">
                <p className="text-xs font-bold text-emerald-300">Teks bersih — tidak ada kata sensitif terdeteksi.</p>
              </div>
            )}

            {/* teks tersensor */}
            {result.hits.length > 0 && (
              <div className="overflow-hidden rounded-2xl glass">
                <p className="border-b border-[var(--surface-line)] px-4 py-2.5 text-[11px] font-bold text-muted-foreground">
                  Versi tersensor (siap dipakai)
                </p>
                <p className="whitespace-pre-wrap p-4 text-xs leading-relaxed">{result.cleaned}</p>
              </div>
            )}
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}
