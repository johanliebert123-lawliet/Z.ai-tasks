"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useApp, getFavSongs, toggleFavSong, type PlayingSong } from "@/lib/app-store";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import {
  Music4, Search, Play, Pause, Download, Heart, Loader2, Mic2,
  Music2, ListMusic, AudioLines, TrendingUp,
} from "lucide-react";

/** Cache lagu lokal (V0.01 #13a) — replay instan tanpa konversi ulang.
 *  V2 UpdSec FIX "gagal memuat lagu": TTL cache kini PER-SUMBER —
 *  URL googlevideo (~6 jam) vs CDN publik (~80 menit). Dulu TTL 24 jam
 *  untuk semuanya, jadi link kedaluwarsa sering terpasang lalu gagal bunyi. */
const SONG_CACHE_KEY = "fanzz_song_cache_v2";

function cacheTtlFor(mp3: string): number {
  // proxy googlevideo (presigned ~6 jam) → amankan jadi 5 jam
  if (mp3.includes("googlevideo") || mp3.startsWith("/api/stream/proxy")) {
    return 5 * 3600 * 1000;
  }
  // URL presigned CDN publik (savetube/faa/puruboy ~90 menit) → amankan 70 menit
  return 70 * 60 * 1000;
}

interface CachedSong {
  title: string;
  thumbnail: string;
  mp3: string;
  at: number;
  exp: number;
}

function readSongCache(videoId: string): { title: string; thumbnail: string; mp3: string } | null {
  try {
    const raw = localStorage.getItem(SONG_CACHE_KEY);
    if (!raw) return null;
    const map = JSON.parse(raw) as Record<string, CachedSong>;
    const hit = map[videoId];
    // cek kedaluwarsa per-sumber (fallback ke TTL lama untuk entry tanpa exp)
    const ttl = hit?.exp ? hit.exp - hit.at : 24 * 3600 * 1000;
    if (!hit || Date.now() - hit.at > ttl) return null;
    return { title: hit.title, thumbnail: hit.thumbnail, mp3: hit.mp3 };
  } catch {
    return null;
  }
}

function writeSongCache(videoId: string, song: { title: string; thumbnail: string; mp3: string }) {
  try {
    const raw = localStorage.getItem(SONG_CACHE_KEY);
    const map = raw ? (JSON.parse(raw) as Record<string, CachedSong>) : {};
    const at = Date.now();
    map[videoId] = { ...song, at, exp: at + cacheTtlFor(song.mp3) };
    // jaga ukuran: maksimal 120 lagu
    const keys = Object.keys(map);
    if (keys.length > 120) {
      for (const k of keys.slice(0, keys.length - 120)) delete map[k];
    }
    localStorage.setItem(SONG_CACHE_KEY, JSON.stringify(map));
    // bersihkan cache format lama sekali lewat
    localStorage.removeItem("fanzz_song_cache_v1");
  } catch {
    /* penuh — abaikan */
  }
}

interface Song {
  videoId: string;
  title: string;
  artist: string;
  album?: string;
  duration: string;
  plays?: string;
  thumbnail: string;
}

export default function MusicView() {
  const [query, setQuery] = useState("");
  const [songs, setSongs] = useState<Song[] | null>(null);
  /** V2-new (#1): daftar lagu sedang populer — tampil otomatis di awal */
  const [popular, setPopular] = useState<Song[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [lyrics, setLyrics] = useState<{ track: string; artist: string; lines: Array<{ time: string; text: string }> } | null>(null);
  const [lyricsFor, setLyricsFor] = useState<string | null>(null);
  const [lyricsLoading, setLyricsLoading] = useState(false);
  /** V2.11 (#31): lirik tebal real-time + mode teka-lirik dengan clue berbatas */
  const [lyricMode, setLyricMode] = useState<"tebal" | "teka">("tebal");
  const [tekaDipakai, setTekaDipakai] = useState(0);
  const [tekaLevel, setTekaLevel] = useState(0);
  const [posDetik, setPosDetik] = useState(0);
  const MAX_CLUE = 5;
  const [tab, setTab] = useState<"search" | "fav">("search");
  const [favs, setFavs] = useState<PlayingSong[]>([]);
  const { playSong, currentSong, isPlaying } = useApp();
  const { toast } = useToast();
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeLineRef = useRef<HTMLParagraphElement | null>(null);
  // V2.11 (#31): saat lagu berganti dan panel lirik terbuka, muat lirik lagu yang sedang diputar
  useEffect(() => {
    if (!currentSong || !lyrics || lyricsFor === currentSong.videoId) return;
    // panel lirik terbuka tapi lagu beda → muat ulang otomatis untuk lagu aktif
    if (lyricsFor) {
      showLyrics({ videoId: currentSong.videoId, title: currentSong.title, artist: currentSong.artist, duration: "", thumbnail: currentSong.thumbnail || "" });
    }
  }, [currentSong?.videoId]);

  // V2.11 (#31): pantau posisi audio untuk lirik tebal real-time
  useEffect(() => {
    if (!lyrics || !currentSong) return;
    const t = setInterval(() => {
      const a = useApp.getState().audioEl;
      if (a && !a.paused) setPosDetik(a.currentTime);
    }, 250);
    return () => clearInterval(t);
  }, [lyrics, currentSong]);

  /** Hitung baris aktif dari waktu lagu (lirik tersinkron saja). */
  const detikDari = (t: string): number => {
    const m = t.match(/^(\d+):(\d{2})/);
    if (!m) return -1;
    return Number(m[1]) * 60 + Number(m[2]);
  };
  const lirikSynced = Boolean(lyrics?.lines.some((l) => l.time));
  const barisAktif = useMemoIdx();
  function useMemoIdx(): number {
    if (!lirikSynced || !lyrics || !currentSong) return -1;
    let idx = -1;
    for (let i = 0; i < lyrics.lines.length; i++) {
      const d = detikDari(lyrics.lines[i].time);
      if (d >= 0 && d <= posDetik + 0.4) idx = i;
    }
    return idx;
  }

  // gulir otomatis ke baris aktif
  useEffect(() => {
    if (barisAktif >= 0 && lyricMode === "tebal") {
      activeLineRef.current?.scrollIntoView({ block: "center", behavior: "smooth" });
    }
  }, [barisAktif, lyricMode]);

  /** Teka-lirik: tutup kata-kata baris aktif, buka bertahap lewat clue berbatas. */
  const maskTeks = (teks: string, level: number): string => {
    if (level >= 3) return teks;
    const kata = teks.split(/\s+/);
    return kata
      .map((k, i) => {
        const bersih = k.replace(/[^a-zA-Z0-9À-ÿ]/g, "");
        if (!bersih) return k;
        if (level === 0) return "＿".repeat(Math.min(bersih.length, 8));
        if (level === 1) return bersih[0] + "＿".repeat(Math.max(0, bersih.length - 1)) + k.slice(bersih.length);
        return i % 2 === 0 ? k : "＿".repeat(Math.min(bersih.length, 8));
  })
      .join(" ");
  };

  const pakaiClue = () => {
    if (tekaDipakai >= MAX_CLUE) {
      toast({ title: "Batas clue habis!", description: `Maksimal ${MAX_CLUE} clue per lagu — dengarkan lagunya baik-baik.`, variant: "destructive" });
      return;
    }
    setTekaLevel((l) => Math.min(3, l + 1));
    setTekaDipakai((d) => d + 1);
  };

  useEffect(() => {
    setFavs(getFavSongs());
  }, [tab]);

  // V2-new: muat daftar "Sedang Populer" sekali saat view dibuka
  useEffect(() => {
    if (popular !== null) return;
    fetch("/api/music/popular")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setPopular(d?.ok ? d.songs : []))
      .catch(() => setPopular([]));
     
  }, []);

  const doSearch = (q: string) => {
    setQuery(q);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (q.trim().length < 1) {
      setSongs(null);
      return;
    }
    debounceRef.current = setTimeout(() => {
      setLoading(true);
      setLyrics(null);
      fetch(`/api/music/search?q=${encodeURIComponent(q.trim())}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => setSongs(d?.ok ? d.songs : []))
        .catch(() => setSongs([]))
        .finally(() => setLoading(false));
    }, 450);
  };

  const getMp3 = async (song: Song) => {
    // V2-new: cek cache lokal dulu — lagu yang pernah diputar langsung bunyi.
    const cached = readSongCache(song.videoId);
    if (cached) {
      playSong({ videoId: song.videoId, title: cached.title || song.title, artist: song.artist, thumbnail: cached.thumbnail || song.thumbnail, mp3: cached.mp3 });
      pushHistory("music", {
        id: song.videoId,
        title: cached.title || song.title,
        subtitle: song.artist,
        poster: cached.thumbnail || song.thumbnail,
      });
      return;
    }
    setLoadingId(song.videoId);
    try {
      // V2-new: /api/music/ytmp3 kini InnerTube dulu → instan, semua lagu bisa diputar
      const res = await fetch(`/api/music/ytmp3?url=https://www.youtube.com/watch?v=${song.videoId}`);
      const d = await res.json();
      if (!d?.ok || !d.result?.mp3) throw new Error(d?.error || "Gagal ambil audio");
      const playing: PlayingSong = {
        videoId: song.videoId,
        title: d.result.title || song.title,
        artist: song.artist,
        thumbnail: d.result.thumbnail || song.thumbnail,
        mp3: d.result.mp3,
      };
      // simpan ke cache lokal (TTL 1 hari — link mp3 CDN umurnya panjang)
      writeSongCache(song.videoId, { title: playing.title, thumbnail: playing.thumbnail, mp3: playing.mp3 });
      playSong(playing);
      pushHistory("music", {
        id: song.videoId,
        title: playing.title,
        subtitle: song.artist,
        poster: playing.thumbnail,
      });
    } catch (e) {
      toast({
        title: "Gagal diputar",
        description: e instanceof Error ? e.message : "Coba lagu lain",
        variant: "destructive",
      });
    } finally {
      setLoadingId(null);
    }
  };

  const downloadMp3 = async (song: Song) => {
    setLoadingId(song.videoId);
    try {
      const res = await fetch(`/api/music/ytmp3?url=https://www.youtube.com/watch?v=${song.videoId}`);
      const d = await res.json();
      if (!d?.ok || !d.result?.mp3) throw new Error(d?.error || "Gagal proses");
      // pakai URL asli (bukan proxy) — /api/download/file mengurus unduhan + nama file
      const dlUrl = (d.result.mp3Direct || d.result.mp3) as string;
      // unduh via proxy → langsung tersimpan ke folder Download tanpa buka tab baru
      const name = `${(d.result.title || song.title).replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80) || "lagu"}.mp3`;
      const a = document.createElement("a");
      a.href = `/api/download/file?url=${encodeURIComponent(dlUrl)}&name=${encodeURIComponent(name)}`;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast({ title: "Download dimulai! 🎵", description: `${d.result.title || song.title} — langsung masuk folder Download kamu` });
    } catch (e) {
      toast({
        title: "Gagal download 😢",
        description: e instanceof Error ? e.message : "Coba lagi ya",
        variant: "destructive",
      });
    } finally {
      setLoadingId(null);
    }
  };

  const showLyrics = async (song: Song) => {
    setLyricsLoading(true);
    setLyricsFor(song.videoId);
    setLyrics(null);
    setTekaLevel(0);
    setTekaDipakai(0);
    try {
      const res = await fetch(
        `/api/music/lyrics?title=${encodeURIComponent(song.title)}&artist=${encodeURIComponent(song.artist)}`
      );
      const d = await res.json();
      if (d?.ok && d.lyrics) {
        setLyrics({ track: d.track, artist: d.artist, lines: d.lyrics.lines });
      } else {
        setLyrics({ track: song.title, artist: song.artist, lines: [{ time: "", text: d?.message || "Lirik tidak ditemukan untuk lagu ini." }] });
      }
    } catch {
      setLyrics({ track: song.title, artist: song.artist, lines: [{ time: "", text: "Gagal memuat lirik." }] });
    } finally {
      setLyricsLoading(false);
    }
  };

  const list: Song[] = tab === "search"
    ? (songs || [])
    : favs.map((f) => ({ videoId: f.videoId, title: f.title, artist: f.artist, duration: "", thumbnail: f.thumbnail }));

  return (
    <div>
      <ToolHeader icon={<Music4 className="h-5.5 w-5.5" />} title="Musik" subtitle="Cari • Preview • Download MP3" accent="cyan" />

      {tab === "search" ? (
        <div className="relative mb-3">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => doSearch(e.target.value)}
            placeholder="Cari judul lagu / artis..."
            className="rounded-xl border-border/60 bg-secondary/50 pl-10"
          />
          {loading && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-cyan-400" />}
        </div>
      ) : null}

      {/* tab */}
      <div className="mb-4 flex gap-2">
        {([["search", "Cari Lagu", Music2], ["fav", "Favorit", ListMusic]] as const).map(([id, label, Icon]) => (
          <button
            key={id}
            onClick={() => { setTab(id); setFavs(getFavSongs()); }}
            className={`relative flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              tab === id ? "text-white" : "bg-secondary/60 text-muted-foreground"
            }`}
          >
            {tab === id && <motion.span layoutId="music-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-500 to-teal-600" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <Icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{label}</span>
          </button>
        ))}
      </div>

      {/* lirik */}
      <AnimatePresence>
        {(lyricsLoading || lyrics) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-4 overflow-hidden rounded-2xl glass"
          >
            <div className="max-h-64 overflow-y-auto p-4">
              <div className="mb-2 flex flex-wrap items-center gap-1.5">
                <p className="flex min-w-0 flex-1 items-center gap-1.5 truncate text-xs font-bold text-cyan-300">
                  <AudioLines className="h-3.5 w-3.5 shrink-0" /> {lyrics?.track || "Memuat..."} — {lyrics?.artist}
                </p>
                {lirikSynced && currentSong && lyricsFor === currentSong.videoId && (
                  <div className="flex gap-1">
                    {(["tebal", "teka"] as const).map((m) => (
                      <button
                        key={m}
                        onClick={() => {
                          setLyricMode(m);
                          if (m === "teka") {
                            setTekaLevel(0);
                          }
                        }}
                        className={`rounded-full px-2.5 py-1 text-[9px] font-extrabold transition ${
                          lyricMode === m ? "bg-cyan-500 text-white" : "bg-secondary/70 text-muted-foreground"
                        }`}
                      >
                        {m === "tebal" ? "TEBAL REAL-TIME" : "TEKA-LIRIK"}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {lyricsLoading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => <div key={i} className="h-3.5 w-full rounded shimmer" />)}
                </div>
              ) : lirikSynced && currentSong && lyricsFor === currentSong.videoId && lyricMode === "tebal" ? (
                <div className="space-y-1.5">
                  {lyrics?.lines.map((l, i) => {
                    const aktif = i === barisAktif;
                    const lewat = i < barisAktif;
                    return (
                      <p
                        key={i}
                        ref={aktif ? activeLineRef : undefined}
                        className={`transition-all duration-300 ${
                          aktif
                            ? "text-base font-extrabold text-cyan-300 drop-shadow-[0_0_8px_rgba(34,211,238,0.35)]"
                            : lewat
                              ? "text-xs text-muted-foreground/40"
                              : "text-xs text-muted-foreground"
                        }`}
                      >
                        {aktif && <span className="mr-1.5 inline-block h-2 w-2 animate-pulse rounded-full bg-cyan-400 align-middle" />}
                        {l.text}
                      </p>
                    );
                  })}
                  <p className="pt-1 text-center text-[9px] text-muted-foreground/60">Lirik mengikuti posisi lagu secara real-time.</p>
                </div>
              ) : lirikSynced && currentSong && lyricsFor === currentSong.videoId && lyricMode === "teka" ? (
                <div className="space-y-1.5">
                  {lyrics?.lines.map((l, i) => {
                    const aktif = i === barisAktif;
                    if (aktif) {
                      return (
                        <div key={i} className="rounded-xl bg-cyan-500/10 px-3 py-2.5">
                          <p className="text-sm font-extrabold tracking-wide text-cyan-200">{maskTeks(l.text, tekaLevel)}</p>
                        </div>
                      );
                    }
                    return (
                      <p key={i} className={`text-xs ${i < barisAktif ? "text-muted-foreground/35" : "text-muted-foreground/70"}`}>
                        {i > barisAktif ? l.text : l.text}
                      </p>
                    );
                  })}
                  <div className="flex items-center justify-between gap-2 pt-1">
                    <p className="text-[9px] text-muted-foreground">Clue terpakai: {tekaDipakai}/{MAX_CLUE}</p>
                    <button
                      onClick={pakaiClue}
                      disabled={tekaLevel >= 3 || tekaDipakai >= MAX_CLUE}
                      className="rounded-full bg-cyan-500/20 px-3 py-1.5 text-[9.5px] font-extrabold text-cyan-300 disabled:opacity-40"
                    >
                      {tekaLevel === 0 ? "Kasih clue (huruf awal)" : tekaLevel === 1 ? "Buka beberapa kata" : "Buka baris penuh"}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-1">
                  {lyrics?.lines.map((l, i) => (
                    <p key={i} className="text-xs leading-relaxed text-muted-foreground">
                      {l.time && <span className="mr-2 font-mono text-[10px] text-cyan-400/70">{l.time}</span>}
                      {l.text}
                    </p>
                  ))}
                  {currentSong && lyricsFor === currentSong.videoId && (
                    <p className="pt-1 text-center text-[9px] text-muted-foreground/60">Lirik lagu ini tidak tersinkron — tebal real-time tidak tersedia.</p>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* V2-new (#1): seksi lagu sedang populer — tampil saat belum mencari */}
      {tab === "search" && !query.trim() && popular && popular.length > 0 && (
        <section className="mb-5">
          <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
            <TrendingUp className="h-4 w-4 text-cyan-400" /> Sedang Populer
            <span className="rounded-full bg-cyan-500/15 px-1.5 py-px text-[8.5px] font-extrabold text-cyan-300">TRENDING</span>
          </h3>
          <div className="space-y-2">
            {popular.slice(0, 12).map((song, i) => {
              const active = currentSong?.videoId === song.videoId;
              return (
                <motion.button
                  key={`pop-${song.videoId}`}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.03, 0.3) }}
                  onClick={() => getMp3(song)}
                  className={`flex w-full items-center gap-3 rounded-2xl p-2.5 text-left transition-colors ${
                    active ? "bg-cyan-500/10 ring-1 ring-cyan-400/30" : "glass hover:bg-secondary/60"
                  }`}
                >
                  <span className="w-6 shrink-0 text-center text-xs font-extrabold text-muted-foreground">{i + 1}</span>
                  <div className="relative h-11 w-11 shrink-0 overflow-hidden rounded-xl">
                    {song.thumbnail ? (
                      <img src={song.thumbnail} alt="" className="h-full w-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="h-full w-full bg-secondary" />
                    )}
                    {loadingId === song.videoId ? (
                      <span className="absolute inset-0 flex items-center justify-center bg-black/50">
                        <Loader2 className="h-4 w-4 animate-spin text-cyan-300" />
                      </span>
                    ) : active && isPlaying ? (
                      <span className="absolute inset-0 flex items-end justify-center gap-[3px] bg-black/40 pb-1.5">
                        {[0, 1, 2].map((d) => (
                          <motion.span
                            key={d}
                            animate={{ height: [4, 10, 6, 12, 4] }}
                            transition={{ repeat: Infinity, duration: 0.9, delay: d * 0.12 }}
                            className="w-[3px] rounded-full bg-cyan-300"
                          />
                        ))}
                      </span>
                    ) : null}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className={`truncate text-sm font-semibold ${active ? "text-cyan-300" : ""}`}>{song.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {song.artist}
                      {song.duration ? ` • ${song.duration}` : ""}
                    </p>
                  </div>
                  <Play className="h-4 w-4 shrink-0 text-cyan-400" />
                </motion.button>
              );
            })}
          </div>
        </section>
      )}

      {/* hint preview */}
      {tab === "search" && (
        <div className="mb-3 flex items-center gap-2.5 rounded-2xl bg-cyan-500/10 px-3.5 py-2.5 text-[11px] leading-snug text-cyan-200">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-cyan-500/25">
            <svg viewBox="0 0 24 24" className="h-3.5 w-3.5 translate-x-[1px] fill-white">
              <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.88l11-6.86a1.04 1.04 0 0 0 0-1.76l-11-6.86A1.04 1.04 0 0 0 8 5.14z" />
            </svg>
          </span>
          <p><b>Petunjuk:</b> tekan tombol <b>play bulat</b> di cover lagu buat <b>preview / dengerin dulu</b> sebelum download. Lagu muter di player bawah, tetap jalan walau pindah menu.</p>
        </div>
      )}

      {/* daftar lagu */}
      {tab === "search" && !songs && !loading ? (
        <EmptyState
          icon={<Music4 className="h-6 w-6" />}
          title="Cari lagu apa nih?"
          desc="Ketik judul lagu / artis. Tekan tombol play (▶) di cover buat preview & dengerin dulu, ikon ⬇ untuk download MP3."
        />
      ) : tab === "fav" && favs.length === 0 ? (
        <EmptyState icon={<Heart className="h-6 w-6" />} title="Belum ada lagu favorit" desc="Tekan ikon hati di lagu buat simpan di sini." />
      ) : (
        <div className="space-y-2">
          {loading && !songs ? (
            Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-16 rounded-2xl shimmer" />)
          ) : (
            list.map((song, i) => {
              const active = currentSong?.videoId === song.videoId;
              return (
                <motion.div
                  key={`${song.videoId}-${i}`}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(i * 0.04, 0.4) }}
                  className={`flex items-center gap-3 rounded-2xl p-2.5 transition-colors ${active ? "bg-cyan-500/10 ring-1 ring-cyan-400/30" : "glass hover:bg-secondary/60"}`}
                >
                  <button onClick={() => getMp3(song)} className="group relative h-14 w-14 shrink-0 overflow-hidden rounded-xl">
                    {song.thumbnail ? (
                      <img src={song.thumbnail} alt="" className="h-full w-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="h-full w-full bg-secondary" />
                    )}
                    {/* tombol play SVG selalu terlihat — petunjuk preview */}
                    <span className="absolute inset-0 flex items-center justify-center transition-colors group-active:bg-black/60">
                      {loadingId === song.videoId ? (
                        <Loader2 className="h-5 w-5 animate-spin text-cyan-300" />
                      ) : active && isPlaying ? (
                        <span className="flex items-end gap-[3px]">
                          {[0, 1, 2, 3].map((d) => (
                            <motion.span
                              key={d}
                              animate={{ height: [6, 16, 9, 14, 6] }}
                              transition={{ repeat: Infinity, duration: 0.9, delay: d * 0.12, ease: "easeInOut" }}
                              className="w-[3px] rounded-full bg-cyan-300"
                            />
                          ))}
                        </span>
                      ) : (
                        <span className="flex h-10 w-10 items-center justify-center rounded-full bg-black/45 backdrop-blur-[2px] ring-1 ring-white/25">
                          <svg viewBox="0 0 24 24" className="h-5 w-5 translate-x-[1px] fill-white drop-shadow">
                            <path d="M8 5.14v13.72c0 .8.87 1.3 1.56.88l11-6.86a1.04 1.04 0 0 0 0-1.76l-11-6.86A1.04 1.04 0 0 0 8 5.14z" />
                          </svg>
                        </span>
                      )}
                    </span>
                    {/* samar biar tetap kelihatan thumbnail */}
                    <span className={`pointer-events-none absolute inset-0 bg-black/25 transition-opacity ${active ? "opacity-100" : "opacity-0 group-hover:opacity-0"}`} />
                  </button>

                  <button onClick={() => showLyrics(song)} className="min-w-0 flex-1 text-left">
                    <p className={`truncate text-sm font-semibold ${active ? "text-cyan-300" : ""}`}>{song.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      {song.artist}
                      {song.duration ? ` • ${song.duration}` : ""}
                      {song.plays ? ` • ▶ ${song.plays}` : ""}
                    </p>
                  </button>

                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      onClick={() => {
                        const nowFav = toggleFavSong({
                          videoId: song.videoId,
                          title: song.title,
                          artist: song.artist,
                          thumbnail: song.thumbnail,
                          mp3: "",
                        });
                        setFavs(getFavSongs());
                        toast({ title: nowFav ? "Ditambahkan ke favorit ❤️" : "Dihapus dari favorit" });
                        // sync favorit ke profil sosial (muncul di pencarian pengguna)
                        if (nowFav) {
                          fetch("/api/social/profile", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                              favSong: { title: song.title, artist: song.artist, thumb: song.thumbnail },
                            }),
                          }).catch(() => {});
                        }
                      }}
                      className={`rounded-xl p-2 transition-colors ${favs.some((f) => f.videoId === song.videoId) ? "text-rose-400" : "text-muted-foreground hover:text-rose-400"}`}
                    >
                      <Heart className={`h-4 w-4 ${favs.some((f) => f.videoId === song.videoId) ? "fill-current" : ""}`} />
                    </button>
                    <button
                      onClick={() => downloadMp3(song)}
                      disabled={loadingId === song.videoId}
                      className="rounded-xl p-2 text-muted-foreground transition-colors hover:text-cyan-300 disabled:opacity-50"
                      title="Download MP3"
                    >
                      {loadingId === song.videoId ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
