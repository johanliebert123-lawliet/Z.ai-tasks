"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AtSign, Loader2, Search, ExternalLink, CheckCircle2, XCircle, HelpCircle, Sparkles, RefreshCw,
} from "lucide-react";

type Status = "registered" | "absent" | "unknown";

interface PlatformResult {
  platform: string;
  url: string;
  status: Status;
}

interface Suggestion {
  username: string;
  results: PlatformResult[];
  foundCount: number;
}

const STATUS_META: Record<Status, { icon: React.ComponentType<{ className?: string }>; label: string; cls: string }> = {
  registered: { icon: CheckCircle2, label: "Terdaftar & aktif", cls: "text-emerald-400 bg-emerald-500/10" },
  absent: { icon: XCircle, label: "Tidak ditemukan", cls: "text-red-400 bg-red-500/10" },
  unknown: { icon: HelpCircle, label: "Tidak terverifikasi", cls: "text-muted-foreground bg-secondary/60" },
};

export default function UsernameCheckView() {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [deep, setDeep] = useState(true);
  const [error, setError] = useState("");
  const [username, setUsername] = useState("");
  const [results, setResults] = useState<PlatformResult[] | null>(null);
  const [foundCount, setFoundCount] = useState(0);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);

  const doCheck = async (u?: string) => {
    const target = (u ?? q).trim().replace(/^@+/, "");
    if (!target) return;
    setLoading(true);
    setError("");
    setResults(null);
    setSuggestions([]);
    try {
      const res = await fetch(`/api/username-check?u=${encodeURIComponent(target)}${deep && !u ? "&deep=1" : ""}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Pemeriksaan gagal");
      setUsername(d.username);
      setResults(d.results || []);
      setFoundCount(d.foundCount || 0);
      setSuggestions(d.suggestions || []);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Pemeriksaan gagal");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<AtSign className="h-5 w-5" />}
        title="Cek Profil Username"
        desc="Masukkan username (tanpa @) — sistem mendeteksi di platform mana saja akun itu terdaftar, real-time, lengkap dengan variasi username populer."
      />

      {/* input */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-muted-foreground">@</span>
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value.replace(/^@+/, ""))}
            onKeyDown={(e) => e.key === "Enter" && doCheck()}
            placeholder="username (mis. billy)"
            className="rounded-xl pl-8"
          />
        </div>
        <Button
          onClick={() => doCheck()}
          disabled={loading || !q.trim()}
          className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 text-white"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
        </Button>
      </div>

      {/* toggle variasi */}
      <button
        onClick={() => setDeep(!deep)}
        className={`flex w-full items-center gap-2.5 rounded-2xl p-3 text-left transition-colors ${
          deep ? "bg-blue-600/10 ring-1 ring-blue-500/30" : "glass"
        }`}
      >
        <Sparkles className={`h-4 w-4 shrink-0 ${deep ? "text-blue-300" : "text-muted-foreground"}`} />
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold">Cari variasi username sekaligus</p>
          <p className="text-[10px] text-muted-foreground">
            {deep ? "Aktif — variasi seperti @billy123, @billy.id ikut diperiksa di platform inti" : "Nonaktif — hanya periksa username persis"}
          </p>
        </div>
        <span className={`h-5 w-9 shrink-0 rounded-full p-0.5 transition-colors ${deep ? "bg-blue-600" : "bg-secondary"}`}>
          <span className={`block h-4 w-4 rounded-full bg-white transition-transform ${deep ? "translate-x-4" : ""}`} />
        </span>
      </button>

      {loading && (
        <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin text-blue-500" />
          <span className="text-xs">Memeriksa {q ? `@${q.replace(/^@+/, "")}` : ""} di 12 platform secara real-time…</span>
        </div>
      )}

      {error && !loading && <EmptyState icon={<AtSign className="h-8 w-8" />} title={error} desc="Coba username lain." />}

      <AnimatePresence>
        {results && !loading && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
            {/* ringkasan */}
            <div className="rounded-2xl glass p-4 text-center">
              <p className="font-mono text-lg font-black">@{username}</p>
              <p className="mt-1 text-xs font-bold text-muted-foreground">
                Terdeteksi aktif di <span className="text-emerald-400">{foundCount}</span> dari {results.length} platform
              </p>
            </div>

            {/* matriks platform */}
            <section>
              <h3 className="mb-2.5 text-sm font-bold">Hasil per platform</h3>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {results.map((r) => {
                  const meta = STATUS_META[r.status];
                  return (
                    <a
                      key={r.platform}
                      href={r.url}
                      target="_blank"
                      rel="noopener noreferrer nofollow"
                      className={`flex items-center gap-2.5 rounded-2xl p-3 transition-transform active:scale-95 ${meta.cls}`}
                    >
                      <meta.icon className="h-4 w-4 shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-bold">{r.platform}</p>
                        <p className="truncate text-[9px] opacity-80">{meta.label}</p>
                      </div>
                      <ExternalLink className="h-3 w-3 shrink-0 opacity-60" />
                    </a>
                  );
                })}
              </div>
              <p className="mt-2 text-[9.5px] leading-relaxed text-muted-foreground">
                Klik kartu untuk membuka profil langsung di platform-nya. Status "Tidak terverifikasi" berarti platform
                membatasi pemeriksaan otomatis (mis. halaman login) — kunjungi manual untuk memastikan.
              </p>
            </section>

            {/* variasi username */}
            {suggestions.length > 0 && (
              <section>
                <h3 className="mb-2.5 text-sm font-bold">Variasi username lain yang mirip</h3>
                <div className="space-y-2">
                  {suggestions.map((s) => (
                    <button
                      key={s.username}
                      onClick={() => {
                        setQ(s.username);
                        doCheck(s.username);
                      }}
                      className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-colors hover:bg-secondary"
                    >
                      <p className="min-w-0 flex-1 truncate font-mono text-xs font-bold">@{s.username}</p>
                      <div className="flex shrink-0 items-center gap-1">
                        {s.results.slice(0, 5).map((r) => {
                          const M = STATUS_META[r.status].icon;
                          return (
                            <span key={r.platform} title={`${r.platform}: ${STATUS_META[r.status].label}`} className="flex items-center">
                              <M className={`h-3.5 w-3.5 ${
                                r.status === "registered" ? "text-emerald-400" : r.status === "absent" ? "text-red-400/60" : "text-muted-foreground/40"
                              }`} />
                            </span>
                          );
                        })}
                        <span className="ml-1 rounded-full bg-secondary px-2 py-0.5 text-[9px] font-bold text-muted-foreground">
                          {s.foundCount} platform
                        </span>
                      </div>
                      <RefreshCw className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-[9.5px] text-muted-foreground">Ketuk variasi untuk memeriksanya secara lengkap.</p>
              </section>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
