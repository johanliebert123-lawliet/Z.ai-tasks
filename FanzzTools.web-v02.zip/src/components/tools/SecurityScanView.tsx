"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  ShieldCheck, ShieldAlert, Search, Loader2, CheckCircle2, AlertTriangle,
  XCircle, Info, Lightbulb, Lock, Globe, Camera, Download,
} from "lucide-react";

/**
 * Cek Keamanan Website (V2 Modern-UpdSec).
 * Pemindaian pasif super ketat: 18+ pemeriksaan header/konfigurasi
 * — skor berbobot 0-100, grade A+ sampai F, plus rekomendasi per temuan.
 * Tidak melakukan eksploitasi apa pun terhadap target.
 */

interface Finding {
  id: string;
  name: string;
  status: "pass" | "warn" | "fail" | "info";
  weight: number;
  score: number;
  detail: string;
  fix?: string;
}

interface ScanResult {
  ok: boolean;
  error?: string;
  target: string;
  scannedAt: number;
  httpStatus: number;
  title: string | null;
  score: number;
  grade: string;
  summary: { pass: number; warn: number; fail: number; total: number };
  findings: Finding[];
  serverHeader: string | null;
  poweredBy: string | null;
}

const GRADE_COLOR: Record<string, string> = {
  "A+": "from-emerald-500 to-green-600",
  A: "from-emerald-500 to-teal-600",
  B: "from-lime-500 to-emerald-600",
  C: "from-amber-500 to-yellow-600",
  D: "from-orange-500 to-amber-600",
  E: "from-red-500 to-orange-600",
  F: "from-red-600 to-rose-700",
};

const STATUS_UI = {
  pass: { icon: CheckCircle2, color: "text-emerald-400", bg: "bg-emerald-500/10", label: "AMAN" },
  warn: { icon: AlertTriangle, color: "text-amber-400", bg: "bg-amber-500/10", label: "PERHATIAN" },
  fail: { icon: XCircle, color: "text-red-400", bg: "bg-red-500/10", label: "RAWAN" },
  info: { icon: Info, color: "text-sky-400", bg: "bg-sky-500/10", label: "INFO" },
} as const;

export default function SecurityScanView() {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [res, setRes] = useState<ScanResult | null>(null);
  const [filter, setFilter] = useState<"semua" | "fail" | "warn" | "pass">("semua");
  /** Tangkapan layar situs (ScreenshotOne, lewat proxy server — lihat SCREENSHOTONE-SETUP.md) */
  const [shot, setShot] = useState<{ url: string; state: "loading" | "error" | "ready"; msg?: string } | null>(null);
  const { toast } = useToast();

  const scan = async () => {
    const u = url.trim();
    if (!u || loading) return;
    setLoading(true);
    setRes(null);
    setShot(null);
    try {
      const r = await fetch(`/api/security/scan?url=${encodeURIComponent(u)}`);
      const d = (await r.json()) as ScanResult;
      if (!d.ok) throw new Error(d.error || "Gagal memindai");
      setRes(d);
      pushHistory("secscan", { id: d.target, title: `Scan: ${d.title || d.target}`, subtitle: `Skor ${d.score}/100 (${d.grade})` });
    } catch (e) {
      toast({ title: "Pemindaian gagal", description: e instanceof Error ? e.message : "Cek URL-nya lagi", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  /** Ambil tangkapan layar target lewat /api/security/screenshot (proxy server-side). */
  const takeShot = async () => {
    const u = url.trim();
    if (!u || shot?.state === "loading") return;
    setShot({ url: u, state: "loading" });
    try {
      const r = await fetch(`/api/security/screenshot?url=${encodeURIComponent(u)}`);
      if (!r.ok) {
        const d = (await r.json().catch(() => null)) as { error?: string; message?: string } | null;
        throw new Error(d?.message || d?.error || `Gagal (HTTP ${r.status})`);
      }
      if (!(r.headers.get("content-type") || "").startsWith("image/")) {
        throw new Error("Respons bukan gambar");
      }
      const blobUrl = URL.createObjectURL(await r.blob());
      setShot((s) => (s ? { ...s, url: blobUrl, state: "ready" } : s));
    } catch (e) {
      setShot((s) => (s ? { ...s, state: "error", msg: e instanceof Error ? e.message : "Gagal mengambil tangkapan layar" } : s));
    }
  };

  const filtered = res?.findings.filter((f) =>
    filter === "semua" ? true : filter === "fail" ? f.status === "fail" : filter === "warn" ? f.status === "warn" : f.status === "pass"
  ) || [];

  return (
    <div>
      <ToolHeader icon={<ShieldCheck className="h-5.5 w-5.5" />} title="Cek Keamanan Website" subtitle="18+ pemeriksaan ketat • skor akurat • saran perbaikan" accent="emerald" />

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Globe className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && scan()}
            placeholder="https://web-yang-mau-dicek.com"
            className="rounded-xl pl-10"
            inputMode="url"
          />
        </div>
        <button
          onClick={scan}
          disabled={loading || !url.trim()}
          className="flex h-10 items-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 text-xs font-extrabold text-white disabled:opacity-50"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Pindai
        </button>
      </div>

      {loading && (
        <div className="mt-4 space-y-2">
          <div className="h-28 rounded-2xl shimmer" />
          <div className="h-10 rounded-2xl shimmer" />
          <div className="h-56 rounded-2xl shimmer" />
        </div>
      )}

      {!res && !loading && (
        <div className="mt-4">
          <EmptyState
            icon={<Lock className="h-10 w-10" />}
            title="Pindai keamanan web mana pun"
            desc="Cek HTTPS/HSTS, CSP, cookie flags, clickjacking, mixed content, CORS, banner versi, dan 12+ pemeriksaan lain. Skor 0-100 dengan grade A+ s/d F. 100% pasif — hanya membaca respons HTTP publik."
          />
        </div>
      )}

      {res && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mt-4 space-y-4">
          {/* kartu skor */}
          <div className="glass rounded-2xl p-5">
            <div className="flex items-center gap-4">
              <div className={`flex h-20 w-20 shrink-0 flex-col items-center justify-center rounded-2xl bg-gradient-to-br ${GRADE_COLOR[res.grade] || GRADE_COLOR.F} text-white shadow-lg`}>
                <span className="text-2xl font-black leading-none">{res.grade}</span>
                <span className="text-[10px] font-bold opacity-90">{res.score}/100</span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-extrabold">{res.title || res.target}</p>
                <a href={res.target} target="_blank" rel="noopener noreferrer" className="block truncate text-[11px] text-emerald-300">{res.target}</a>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-[10px] font-bold text-emerald-300">{res.summary.pass} aman</span>
                  <span className="rounded-full bg-amber-500/15 px-2.5 py-1 text-[10px] font-bold text-amber-300">{res.summary.warn} perhatian</span>
                  <span className="rounded-full bg-red-500/15 px-2.5 py-1 text-[10px] font-bold text-red-300">{res.summary.fail} rawan</span>
                </div>
              </div>
            </div>
            {/* bar skor */}
            <div className="mt-4 h-2.5 overflow-hidden rounded-full bg-secondary">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${res.score}%` }}
                transition={{ duration: 0.8, ease: "easeOut" }}
                className={`h-full rounded-full bg-gradient-to-r ${GRADE_COLOR[res.grade] || GRADE_COLOR.F}`}
              />
            </div>
          </div>

          {/* tombol tangkapan layar (ScreenshotOne — proxy server) */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={takeShot}
              disabled={shot?.state === "loading"}
              className="flex items-center gap-2 rounded-xl bg-secondary/70 px-4 py-2.5 text-[11px] font-bold transition hover:bg-secondary disabled:opacity-50"
            >
              {shot?.state === "loading" ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Camera className="h-3.5 w-3.5" />}
              Tangkapan Layar Situs
            </button>
            <span className="text-[10px] text-muted-foreground">Bukti visual kondisi situs saat dipindai (ScreenshotOne)</span>
          </div>

          {/* hasil tangkapan layar */}
          <AnimatePresence>
              {shot && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="overflow-hidden rounded-2xl bg-secondary/40 ring-1 ring-border/50">
                  {shot.state === "loading" && (
                    <div className="flex h-56 items-center justify-center gap-2 text-[11px] font-bold text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin" /> Memotret situs (bisa sampai 20 detik)…
                    </div>
                  )}
                  {shot.state === "error" && (
                    <div className="flex items-start gap-2.5 p-4 text-[11px] leading-relaxed text-amber-300">
                      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                      <div>
                        <p className="font-bold">Tangkapan layar tidak tersedia</p>
                        <p className="mt-0.5 text-muted-foreground">{shot.msg}</p>
                      </div>
                    </div>
                  )}
                  {shot.state === "ready" && (
                    <div>
                      <div className="flex items-center justify-between px-4 py-2.5">
                        <p className="text-[11px] font-bold">{res?.target || url}</p>
                        <a
                          href={shot.url}
                          download={`fanzz-scan-${(res?.target || "site").replace(/[^a-z0-9]+/gi, "-").slice(0, 40)}.jpg`}
                          className="flex items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5 text-[10px] font-bold transition hover:bg-secondary/70"
                        >
                          <Download className="h-3 w-3" /> Unduh JPG
                        </a>
                      </div>
                      <img src={shot.url} alt={`Tangkapan layar ${res?.target || url}`} className="w-full" />
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

          {/* filter */}
          <div className="flex gap-2">
            {([
              { id: "semua", label: `Semua (${res.summary.total})` },
              { id: "fail", label: `Rawan (${res.summary.fail})` },
              { id: "warn", label: `Perhatian (${res.summary.warn})` },
              { id: "pass", label: `Aman (${res.summary.pass})` },
            ] as const).map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={`rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
                  filter === f.id ? "bg-gradient-to-r from-emerald-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* daftar temuan */}
          <div className="space-y-2.5">
            {filtered.map((f) => {
              const ui = STATUS_UI[f.status];
              return (
                <div key={f.id} className={`rounded-2xl ${ui.bg} p-4`}>
                  <div className="flex items-start gap-3">
                    <ui.icon className={`mt-0.5 h-5 w-5 shrink-0 ${ui.color}`} />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-xs font-extrabold">{f.name}</p>
                        <span className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] font-black ${ui.color} ${ui.bg}`}>{ui.label}</span>
                      </div>
                      <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{f.detail}</p>
                      {f.fix && (
                        <p className="mt-2 flex items-start gap-1.5 rounded-xl bg-black/30 p-2.5 text-[10.5px] leading-relaxed text-emerald-200">
                          <Lightbulb className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                          <span><b>Cara perbaiki:</b> {f.fix}</span>
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
            </div>
        </motion.div>
      )}
    </div>
  );
}
