"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { Button } from "@/components/ui/button";
import {
  Dices, Loader2, KeyRound, Trash2, Clock3, Smartphone, Globe2, BadgeCheck, Copy, Check,
} from "lucide-react";
import {
  gachaNumber, generateOtp, formatOtp, loadNumbers, saveNumbers, loadOtps, saveOtps,
  loadStats, bumpStats, DAILY_LIMIT, RARITY_STYLE, COUNTRY_PREFIXES, e164Plain,
  type NokosNumber, type NokosOtp,
} from "@/lib/nokos";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

export default function GachaNokosView() {
  const [numbers, setNumbers] = useState<NokosNumber[]>([]);
  const [otps, setOtps] = useState<NokosOtp[]>([]);
  const [usedToday, setUsedToday] = useState(0);
  const [total, setTotal] = useState(0);
  const [rolling, setRolling] = useState(false);
  const [lastNumber, setLastNumber] = useState<NokosNumber | null>(null);
  const [revealed, setRevealed] = useState(false);
  const [copied, setCopied] = useState("");
  /** V2-new (#15): negara pilihan — "acak" atau iso negara tertentu */
  const [countryPick, setCountryPick] = useState("acak");
  const { toast } = useToast();

  useEffect(() => {
    setNumbers(loadNumbers());
    setOtps(loadOtps());
    const s = loadStats();
    setUsedToday(s.usedToday);
    setTotal(s.totalGacha);
  }, []);

  /** efek angka berputar saat mengocok */
  const [spinDigits, setSpinDigits] = useState("____________");

  const doGacha = () => {
    if (rolling) return;
    if (usedToday >= DAILY_LIMIT) {
      toast({
        title: "Limit gacha harian tercapai",
        description: `Maksimal ${DAILY_LIMIT} gacha per hari — kembali besok.`,
        variant: "destructive",
      });
      return;
    }
    setRolling(true);
    setRevealed(false);
    setLastNumber(null);

    // animasi angka acak berputar
    const iv = setInterval(() => {
      let s = "";
      for (let i = 0; i < 13; i++) s += Math.floor(Math.random() * 10);
      setSpinDigits(s);
    }, 70);

    setTimeout(() => {
      clearInterval(iv);
      // V2-new (#15): gacha mengikuti pilihan negara + rencana penomoran valid
      const n = gachaNumber(countryPick === "acak" ? undefined : countryPick);
      setSpinDigits(n.number);
      setLastNumber(n);
      setRevealed(true);
      setRolling(false);

      const list = [n, ...loadNumbers()].slice(0, 50);
      saveNumbers(list);
      setNumbers(list);

      const stats = bumpStats();
      setUsedToday(stats.usedToday);
      setTotal(stats.totalGacha);

      pushHistory("nokos", {
        id: n.number,
        title: n.display,
        subtitle: `${n.flag} ${n.country} • ${RARITY_STYLE[n.rarity].label}`,
        extra: { rarity: n.rarity, waType: n.waType },
      });

      toast({
        title: `Gacha berhasil — ${RARITY_STYLE[n.rarity].label}!`,
        description: `Nomor ${n.display} (${n.country}) siap dipakai.`,
      });
    }, 1600);
  };

  const requestOtp = (n: NokosNumber) => {
    const otp = generateOtp(n.number);
    const list = [otp, ...loadOtps()].slice(0, 60);
    saveOtps(list);
    setOtps(list);
    setCopied("");
    toast({
      title: "Kode OTP diterima",
      description: `OTP ${formatOtp(otp.otp)} berlaku 5 menit untuk nomor ${n.display}.`,
    });
  };

  const copy = (text: string, label: string) => {
    try {
      navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(""), 1500);
    } catch {
      toast({ title: "Gagal menyalin", variant: "destructive" });
    }
  };

  /** daftar negara unik untuk pemilih (V2-new #15) */
  const countryOptions = useMemo(() => {
    const seen = new Set<string>();
    return COUNTRY_PREFIXES.filter((c) => {
      if (seen.has(c.iso)) return false;
      seen.add(c.iso);
      return true;
    }).map((c) => ({ iso: c.iso, label: `${c.flag} ${c.country}`, prefix: `+${c.prefix}` }));
  }, []);

  const rar = lastNumber ? RARITY_STYLE[lastNumber.rarity] : null;

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<Dices className="h-5 w-5" />}
        title="Gacha Nokos"
        desc="Gacha nomor virtual untuk OTP WhatsApp — lengkap dengan asal negara dan jenis WhatsApp (Business / App biasa)."
      />

      {/* statistik */}
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-2xl glass p-3 text-center">
          <p className="text-lg font-extrabold text-red-400">{DAILY_LIMIT - usedToday}</p>
          <p className="text-[9px] font-bold text-muted-foreground">Sisa gacha hari ini</p>
        </div>
        <div className="rounded-2xl glass p-3 text-center">
          <p className="text-lg font-extrabold text-cyan-400">{total}</p>
          <p className="text-[9px] font-bold text-muted-foreground">Total gacha</p>
        </div>
        <div className="rounded-2xl glass p-3 text-center">
          <p className="text-lg font-extrabold text-amber-400">{numbers.length}</p>
          <p className="text-[9px] font-bold text-muted-foreground">Nomor tersimpan</p>
        </div>
      </div>

      {/* area gacha */}
      <div className={`relative overflow-hidden rounded-3xl glass-strong p-5 ${rar ? `ring-2 ${rar.ring}` : ""}`}>
        <div className="pointer-events-none absolute -top-10 -right-10 h-40 w-40 rounded-full bg-red-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-cyan-500/10 blur-3xl" />

        <div className="relative text-center">
          <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Nomor Anda</p>

          {/* tampilan angka (berputar / hasil) */}
          <div className="mt-2 font-mono text-2xl font-black tracking-wider sm:text-3xl">
            {rolling ? (
              <span className="text-muted-foreground">
                +{spinDigits.slice(0, 2)} {spinDigits.slice(2)}
              </span>
            ) : lastNumber ? (
              <span className={rar?.text}>{lastNumber.display}</span>
            ) : (
              <span className="text-muted-foreground/50">+-- --- ---- ----</span>
            )}
          </div>

          {/* hasil detail */}
          <AnimatePresence>
            {revealed && lastNumber && rar && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 space-y-2"
              >
                <span className={`inline-block rounded-full px-3 py-1 text-[10px] font-extrabold ${rar.text} bg-secondary`}>
                  {rar.label}
                </span>
                <div className="grid grid-cols-2 gap-2 text-left">
                  <div className="rounded-xl bg-secondary/60 p-2.5">
                    <p className="flex items-center gap-1 text-[9px] font-bold text-muted-foreground">
                      <Globe2 className="h-3 w-3" /> Negara
                    </p>
                    <p className="mt-0.5 text-xs font-bold">{lastNumber.flag} {lastNumber.country}</p>
                  </div>
                  <div className="rounded-xl bg-secondary/60 p-2.5">
                    <p className="flex items-center gap-1 text-[9px] font-bold text-muted-foreground">
                      <Smartphone className="h-3 w-3" /> Jenis WhatsApp
                    </p>
                    <p className="mt-0.5 flex items-center gap-1 text-xs font-bold">
                      {lastNumber.waType === "business" ? (
                        <>
                          <BadgeCheck className="h-3.5 w-3.5 text-emerald-400" /> WhatsApp Business
                        </>
                      ) : (
                        <>
                          <Smartphone className="h-3.5 w-3.5 text-cyan-400" /> WhatsApp App biasa
                        </>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => requestOtp(lastNumber)}
                    className="flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-red-600 text-white"
                  >
                    <KeyRound className="mr-1.5 h-4 w-4" /> Minta kode OTP
                  </Button>
                  {/* V2-new (#15): salin format E.164 polos — siap tempel ke WhatsApp */}
                  <Button
                    variant="secondary"
                    onClick={() => copy(e164Plain(lastNumber.number), "num")}
                    className="rounded-xl"
                    title="Salin nomor format polos (siap tempel ke WhatsApp)"
                  >
                    {copied === "num" ? <Check className="h-4 w-4 text-emerald-400" /> : <Copy className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="secondary"
                    onClick={() => copy(lastNumber.display, "numfmt")}
                    className="rounded-xl"
                    title="Salin nomor format tampilan"
                  >
                    {copied === "numfmt" ? <Check className="h-4 w-4 text-emerald-400" /> : <Globe2 className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="mt-1.5 text-center text-[9.5px] leading-relaxed text-muted-foreground">
                  Tombol kiri: salin nomor polos (mis. 62812…) — paling aman buat WhatsApp.
                  Nomor mengikuti rencana penomoran negaranya supaya formatnya diterima.
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          {/* V2-new (#15): pemilih negara — nomor mengikuti rencana penomoran negara terpilih */}
          <div className="mt-3 rounded-2xl glass p-3">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
              <Globe2 className="h-3.5 w-3.5 text-cyan-400" /> Negara nomor
            </p>
            <div className="flex flex-wrap gap-1.5">
              <button
                onClick={() => setCountryPick("acak")}
                className={`rounded-full px-2.5 py-1.5 text-[10px] font-bold transition-colors ${
                  countryPick === "acak" ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary/70 text-muted-foreground hover:text-foreground"
                }`}
              >
                🌍 Acak
              </button>
              {countryOptions.map((c) => (
                <button
                  key={c.iso}
                  onClick={() => setCountryPick(c.iso)}
                  title={`${c.label} (${c.prefix})`}
                  className={`rounded-full px-2.5 py-1.5 text-[10px] font-bold transition-colors ${
                    countryPick === c.iso ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary/70 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {c.label.split(" ")[0]} {c.iso}
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={doGacha}
            disabled={rolling}
            size="lg"
            className={`mt-4 w-full rounded-2xl text-sm font-extrabold text-white ${
              rolling ? "" : "bg-gradient-to-r from-red-500 to-red-700 shadow-lg shadow-red-500/25"
            }`}
          >
            {rolling ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Mengocok nomor…
              </>
            ) : (
              <>
                <Dices className="mr-2 h-4 w-4" /> GACHA NOMOR
              </>
            )}
          </Button>
        </div>
      </div>

      {/* OTP aktif */}
      {otps.length > 0 && (
        <section>
          <h3 className="mb-2.5 flex items-center gap-2 text-sm font-bold">
            <KeyRound className="h-4 w-4 text-emerald-400" /> OTP Aktif ({otps.length})
          </h3>
          <div className="space-y-2">
            {otps.slice(0, 8).map((o) => {
              const num = numbers.find((n) => n.number === o.number);
              const remain = Math.max(0, Math.floor((o.expiresAt - Date.now()) / 1000));
              return (
                <div key={o.createdAt} className="flex items-center gap-3 rounded-2xl glass p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-xs font-bold">{o.number.replace(/^(\d{2,5})(\d{3})(\d{4})/, "+$1 $2 $3")}</p>
                    <p className="flex items-center gap-1 text-[9px] text-muted-foreground">
                      <Clock3 className="h-2.5 w-2.5" /> berlaku {Math.floor(remain / 60)}:{String(remain % 60).padStart(2, "0")}
                      {num ? ` • ${num.flag} ${num.country}` : ""}
                    </p>
                  </div>
                  <button
                    onClick={() => copy(formatOtp(o.otp), `otp-${o.createdAt}`)}
                    className="rounded-xl bg-emerald-500/15 px-3 py-2 font-mono text-sm font-black tracking-wider text-emerald-300 transition-transform active:scale-95"
                  >
                    {copied === `otp-${o.createdAt}` ? "TERSALIN" : formatOtp(o.otp)}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* riwayat nomor */}
      <section>
        <div className="mb-2.5 flex items-center justify-between">
          <h3 className="flex items-center gap-2 text-sm font-bold">Nomor Tersimpan ({numbers.length})</h3>
          {numbers.length > 0 && (
            <button
              onClick={() => {
                saveNumbers([]);
                saveOtps([]);
                setNumbers([]);
                setOtps([]);
              }}
              className="flex items-center gap-1 rounded-xl px-2 py-1 text-[10px] font-bold text-muted-foreground transition-colors hover:text-red-400"
            >
              <Trash2 className="h-3 w-3" /> Bersihkan
            </button>
          )}
        </div>
        {numbers.length === 0 ? (
          <EmptyState icon={<Dices className="h-8 w-8" />} title="Belum ada nomor" desc="Tekan GACHA NOMOR untuk mulai mengocok." />
        ) : (
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {numbers.slice(0, 16).map((n) => (
              <button
                key={n.number}
                onClick={() => {
                  setLastNumber(n);
                  setRevealed(true);
                }}
                className="flex items-center gap-3 rounded-2xl glass p-2.5 text-left transition-colors hover:bg-secondary"
              >
                <div className="min-w-0 flex-1">
                  <p className="truncate font-mono text-[11px] font-bold">{n.display}</p>
                  <p className="truncate text-[9px] text-muted-foreground">
                    {n.flag} {n.country} • {RARITY_STYLE[n.rarity].label} • {n.waType === "business" ? "WA Business" : "WA App"}
                  </p>
                </div>
                <span className={`shrink-0 rounded-full px-2 py-0.5 text-[8px] font-extrabold ${RARITY_STYLE[n.rarity].text} bg-secondary`}>
                  {n.rarity.charAt(0)}
                </span>
              </button>
            ))}
          </div>
        )}
      </section>

      <p className="rounded-2xl bg-amber-500/10 px-3.5 py-3 text-[10px] leading-relaxed text-amber-300/90">
        Catatan: nomor nokos bersifat virtual (seperti layanan penerima OTP pada umumnya) — cocok untuk keperluan
        verifikasi yang tidak mengikat nomor pribadi Anda. Gunakan dengan bijak dan patuhi ketentuan layanan
        platform terkait.
      </p>
    </div>
  );
}
