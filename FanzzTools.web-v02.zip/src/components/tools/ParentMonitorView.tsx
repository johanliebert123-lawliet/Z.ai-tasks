"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import qrcode from "qrcode-generator";
import { useApp } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import {
  ShieldCheck, Smartphone, QrCode, Loader2, Plus, X, Check, Trash2, Pause, Play,
  Ban, RefreshCw, Copy, Activity, Bell, ScrollText, Eye, BatteryFull,
  MapPin, ImageIcon as ImageIconLucide, AlertTriangle, Package, Users, Baby,
  FileCheck2, Clock3, ChevronRight,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts";

/**
 * Parent Monitor / Family Cyber Safety — dashboard orang tua (V2.12).
 *
 * Fitur: onboarding + pernyataan wali resmi, profil anak (maks usia 35),
 * perangkat + QR enrollment (satu-kali-pakai, 10 menit, bertanda-tangan),
 * pemantauan pemakaian aplikasi (Today/7d/30d), status perangkat ( baterai/
 * jaringan/permission), lokasi & media opsional, alerts, audit log,
 * Privacy Center (hapus data), integrasi APK Builder (companion).
 *
 * DESAIN TRANSPARAN: tidak ada mode tersembunyi — anak selalu bisa melihat
 * status monitoring di companion dan memutus koneksi sendiri.
 */

interface PmDevicePub {
  id: string;
  childId: string;
  label: string;
  model: string | null;
  androidVersion: string | null;
  appVersion: string | null;
  battery: number | null;
  charging: boolean | null;
  network: string | null;
  lastSeen: number | null;
  lastSync: number | null;
  status: "waiting" | "connected" | "paused" | "revoked";
  online: boolean;
  features: { usage: boolean; status: boolean; location: boolean; media: boolean };
  permissions: Record<string, string> | null;
  createdAt: number;
}

interface PmChildPub {
  id: string;
  nickname: string;
  birthYear?: number;
  avatar?: string;
  notes?: string;
  createdAt: number;
  disabled: boolean;
  age: number | null;
  devices: PmDevicePub[];
  deviceCount: number;
  connectedCount: number;
}

interface PmOverview {
  household: { id: string; name: string; attested: boolean; attestation: { confirmedAt: number; parentBirthYear?: number } | null; createdAt: number };
  children: PmChildPub[];
  devices: PmDevicePub[];
  alerts: Array<{ id: string; type: string; msg: string; ts: number; childId?: string; deviceId?: string }>;
  audit: Array<{ id: string; actor: string; action: string; detail?: string; ts: number }>;
  retention: { usageDays: number; locationDays: number; mediaMetaDays: number; thumbDays: number };
  limits: { childMaxAge: number; adultAge: number; enrollTtlMin: number };
  serverTime: number;
}

interface EnrollmentInfo {
  id: string;
  code: string;
  qrPayload: string;
  expiresAt: number;
  status: string;
}

const PERM_LABEL: Record<string, string> = {
  usage: "Akses Usage",
  location: "Lokasi",
  media: "Media (Foto Picker)",
  notifications: "Notifikasi",
};

function waktuLalu(ts: number | null): string {
  if (!ts) return "belum pernah";
  const s = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return `${s} detik lalu`;
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  return `${Math.floor(s / 86400)} hari lalu`;
}

function fmtDurasi(ms: number): string {
  const m = Math.floor(ms / 60000);
  if (m < 60) return `${m} mnt`;
  const j = Math.floor(m / 60);
  return `${j} jam ${m % 60} mnt`;
}

/* ============ QR sebagai SVG ringan ============ */
function QrSvg({ text, size = 220 }: { text: string; size?: number }) {
  const path = useMemo(() => {
    try {
      const qr = qrcode(0, "M");
      qr.addData(text);
      qr.make();
      const n = qr.getModuleCount();
      const cell = size / (n + 8);
      const off = 4 * cell;
      let d = "";
      for (let r = 0; r < n; r++) {
        for (let c = 0; c < n; c++) {
          if (qr.isDark(r, c)) {
            d += `M${(off + c * cell).toFixed(2)},${(off + r * cell).toFixed(2)}h${cell.toFixed(2)}v${cell.toFixed(2)}h-${cell.toFixed(2)}z`;
          }
        }
      }
      return d;
    } catch {
      return "";
    }
  }, [text, size]);
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="rounded-xl bg-white p-1" role="img" aria-label="QR enrollment">
      <rect width={size} height={size} fill="#fff" />
      <path d={path} fill="#000" />
    </svg>
  );
}

const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  /* status perangkat */
  waiting: { label: "MENUNGGU ENROLLMENT", cls: "bg-amber-500/15 text-amber-300" },
  pending_consent: { label: "MENUNGGU PERSETUJUAN ANAK", cls: "bg-sky-500/15 text-sky-300" },
  rejected: { label: "DITOLAK ANAK", cls: "bg-red-500/15 text-red-300" },
  connected: { label: "TERHUBUNG", cls: "bg-emerald-500/15 text-emerald-300" },
  paused: { label: "DIJEDA", cls: "bg-amber-500/15 text-amber-300" },
  revoked: { label: "DIPUTUS", cls: "bg-zinc-500/15 text-zinc-300" },
  /* status enrollment (mesin status zuperupdt #7) */
  created: { label: "MENUNGGU PEMINDAIAN", cls: "bg-amber-500/15 text-amber-300" },
  pending: { label: "PERANGKAT MEMINDAI — MENUNGGU PERSETUJUAN ANAK", cls: "bg-sky-500/15 text-sky-300" },
  consent_required: { label: "MENUNGGU JAWABAN ANAK", cls: "bg-sky-500/15 text-sky-300" },
  expired: { label: "KEDALUWARSA", cls: "bg-red-500/15 text-red-300" },
  cancelled: { label: "DIBATALKAN", cls: "bg-zinc-500/15 text-zinc-300" },
  scanned: { label: "PERANGKAT MEMINDAI", cls: "bg-sky-500/15 text-sky-300" },
  confirming: { label: "MENUNGGU JAWABAN ANAK", cls: "bg-sky-500/15 text-sky-300" },
  failed: { label: "DITOLAK ANAK", cls: "bg-red-500/15 text-red-300" },
};

export default function ParentMonitorView() {
  const { setView } = useApp();
  const { toast } = useToast();
  const [data, setData] = useState<PmOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"keluarga" | "perangkat" | "aktivitas" | "privasi">("keluarga");

  /* onboarding */
  const [attestCheck, setAttestCheck] = useState(false);
  const [attestYear, setAttestYear] = useState("");
  const [attestBusy, setAttestBusy] = useState(false);

  /* anak */
  const [childModal, setChildModal] = useState<{ mode: "add" } | { mode: "edit"; child: PmChildPub } | null>(null);
  const [childForm, setChildForm] = useState({ nickname: "", birthYear: "", notes: "" });
  const [childBusy, setChildBusy] = useState(false);

  /* perangkat + QR */
  const [devModal, setDevModal] = useState<{ child: PmChildPub } | null>(null);
  const [devForm, setDevForm] = useState({ label: "", usage: true, status: true, location: false, media: false });
  const [qr, setQr] = useState<EnrollmentInfo | null>(null);
  const [qrCountdown, setQrCountdown] = useState(0);
  const [qrBusy, setQrBusy] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  /* aktivitas */
  const [usageChild, setUsageChild] = useState<string>("");
  const [usageDays, setUsageDays] = useState<1 | 7 | 30>(1);
  const [usage, setUsage] = useState<{ topApps: Array<{ pkg: string; app: string; usageMs: number; launches: number }>; daily: Array<{ date: string; usageMs: number }>; totalMs: number } | null>(null);
  const [usageLoading, setUsageLoading] = useState(false);

  /* privasi */
  const [privacy, setPrivacy] = useState<{ counts: Record<string, number>; retention: Record<string, number>; enabledFeatures: Array<{ deviceId: string; label: string; features: { usage: boolean; status: boolean; location: boolean; media: boolean } }> } | null>(null);

  /* detail perangkat (media/lokasi) */
  const [detailDev, setDetailDev] = useState<PmDevicePub | null>(null);
  const [mediaList, setMediaList] = useState<Array<{ id: string; kind: string; thumb?: string; ts: number; size?: number }>>([]);
  const [locList, setLocList] = useState<Array<{ lat: number; lon: number; accuracy?: number; ts: number }>>([]);

  const muat = useCallback(async () => {
    try {
      const r = await fetch("/api/pm/overview");
      const d = await r.json();
      if (d?.ok) {
        setData(d);
        return d as PmOverview;
      }
    } catch {
      /* diam */
    }
    return null;
  }, []);

  useEffect(() => {
    void muat().finally(() => setLoading(false));
    // V2.12: catat riwayat tools (muncul di halaman Riwayat)
    pushHistory("pm", { id: "dashboard", title: "Parent Monitor", subtitle: "Family Cyber Safety — dashboard keluarga" });
  }, [muat]);

  // Cyber-Update #10c: auto-refresh tiap 60 dtk selama dashboard terbuka —
  // status online/offline & last-seen (jendela server 35 dtk × heartbeat
  // 15 dtk) selalu segar tanpa perlu menekan reload manual.
  useEffect(() => {
    const t = setInterval(() => { void muat(); }, 60_000);
    return () => clearInterval(t);
  }, [muat]);

  /* ---------- onboarding ---------- */
  const kirimAttest = async () => {
    if (!attestCheck || attestBusy) return;
    setAttestBusy(true);
    try {
      const r = await fetch("/api/pm/attest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ confirm: true, parentBirthYear: attestYear ? Number(attestYear) : undefined }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal konfirmasi");
      toast({ title: "Pernyataan tersimpan", description: "Parent Monitor siap dipakai untuk keluarga kamu." });
      await muat();
    } catch (e) {
      toast({ title: "Gagal", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setAttestBusy(false);
    }
  };

  /* ---------- anak ---------- */
  const simpanAnak = async () => {
    if (childBusy) return;
    setChildBusy(true);
    try {
      const isEdit = childModal?.mode === "edit";
      const r = await fetch(isEdit ? `/api/pm/children?id=${childModal!.child.id}` : "/api/pm/children", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nickname: childForm.nickname.trim(),
          birthYear: childForm.birthYear ? Number(childForm.birthYear) : undefined,
          notes: childForm.notes.trim() || undefined,
        }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal menyimpan");
      if (d.warning) toast({ title: "Anak tersimpan (catatan)", description: d.warning });
      else toast({ title: isEdit ? "Profil anak diperbarui" : "Profil anak ditambahkan" });
      setChildModal(null);
      setChildForm({ nickname: "", birthYear: "", notes: "" });
      await muat();
    } catch (e) {
      toast({ title: "Gagal menyimpan", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setChildBusy(false);
    }
  };

  const hapusAnak = async (c: PmChildPub) => {
    if (!confirm(`Hapus profil "${c.nickname}"? Semua perangkat & data monitoringnya juga dihapus.`)) return;
    try {
      const r = await fetch(`/api/pm/children?id=${c.id}`, { method: "DELETE" });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      toast({ title: "Profil anak dihapus" });
      await muat();
    } catch (e) {
      toast({ title: "Gagal menghapus", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  const toggleAnak = async (c: PmChildPub) => {
    try {
      const r = await fetch(`/api/pm/children?id=${c.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ disabled: !c.disabled }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      await muat();
    } catch (e) {
      toast({ title: "Gagal", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  /* ---------- perangkat ---------- */
  const buatPerangkat = async () => {
    if (!devModal || !devForm.label.trim()) {
      toast({ title: "Nama perangkat kosong" });
      return;
    }
    setQrBusy(true);
    try {
      // mode A: buat APK + QR — QR enrollment membawa fitur pilihan orang tua (V2.12)
      const r = await fetch("/api/pm/enrollment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "generate",
          childId: devModal.child.id,
          deviceLabel: devForm.label.trim(),
          features: { usage: devForm.usage, status: devForm.status, location: devForm.location, media: devForm.media },
        }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal membuat QR");
      setQr(d.enrollment);
      setQrCountdown(Math.max(0, Math.floor((d.enrollment.expiresAt - Date.now()) / 1000)));
      toast({ title: "QR pairing dibuat", description: "Berlaku 10 menit, satu kali pakai — fitur yang kamu pilih aktif saat HP anak terhubung." });
    } catch (e) {
      toast({ title: "Gagal membuat QR", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setQrBusy(false);
    }
  };

  const refreshQr = async () => {
    if (!qr) return;
    setQrBusy(true);
    try {
      await fetch("/api/pm/enrollment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "cancel", enrollmentId: qr.id }),
      }).catch(() => {});
      const r = await fetch("/api/pm/enrollment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "generate",
          childId: devModal!.child.id,
          deviceLabel: devForm.label.trim() || qr.code,
          features: { usage: devForm.usage, status: devForm.status, location: devForm.location, media: devForm.media },
        }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      setQr(d.enrollment);
      setQrCountdown(Math.floor((d.enrollment.expiresAt - Date.now()) / 1000));
    } catch (e) {
      toast({ title: "Gagal memperbarui QR", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setQrBusy(false);
    }
  };

  const batalkanQr = async () => {
    if (!qr) return;
    await fetch("/api/pm/enrollment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "cancel", enrollmentId: qr.id }),
    }).catch(() => {});
    setQr(null);
  };

  /* polling status QR tiap 3 detik (zuperupdt #7: semua status mesin baru
   *  CREATED → PENDING → CONSENT_REQUIRED → CONNECTED/REJECTED/EXPIRED/REVOKED
   *  ditampilkan live — tidak ada lagi "macet" di satu status tanpa info) */
  useEffect(() => {
    if (!qr) {
      if (pollRef.current) clearInterval(pollRef.current);
      return;
    }
    pollRef.current = setInterval(async () => {
      setQrCountdown((c) => Math.max(0, c - 3));
      try {
        const r = await fetch(`/api/pm/enrollment?id=${qr.id}`);
        const d = await r.json();
        if (d?.ok) {
          setQr((prev) => (prev ? { ...prev, status: d.status } : prev));
          if (d.status === "connected") {
            toast({ title: "Perangkat terhubung! 🎉", description: "Anak telah menyetujui — enrollment selesai. Pantau statusnya di tab Perangkat." });
            setQr(null);
            await muat();
            setDevModal(null);
          } else if (d.status === "rejected") {
            toast({ title: "Koneksi ditolak anak", description: "Perangkat menekan \u201cBatalkan\u201d. Minta kode pairing baru bila ingin mencoba lagi.", variant: "destructive" });
            setQr(null);
            await muat();
            setDevModal(null);
          } else if (d.status === "expired" || d.status === "revoked" || d.status === "cancelled" || d.status === "failed") {
            setQr((prev) => (prev ? { ...prev, status: d.status } : prev));
          }
        }
      } catch {
        /* diam */
      }
    }, 3000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [qr?.id, qr, muat, toast]);

  const aksiPerangkat = async (d: PmDevicePub, action: "pause" | "resume" | "revoke" | "delete") => {
    const konfirmasi =
      action === "delete"
        ? confirm(`Hapus perangkat "${d.label}"? Semua data monitoring perangkat ini ikut terhapus.`)
        : action === "revoke"
          ? confirm(`Cabut akses perangkat "${d.label}"? Kredensialnya langsung tidak valid.`)
          : true;
    if (!konfirmasi) return;
    try {
      if (action === "delete") {
        const r = await fetch(`/api/pm/devices?id=${d.id}`, { method: "DELETE" });
        const j = await r.json();
        if (!j?.ok) throw new Error(j?.error);
      } else {
        const r = await fetch(`/api/pm/devices?id=${d.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: action === "revoke" ? "revoke" : undefined,
            status: action === "pause" ? "paused" : action === "resume" ? "connected" : undefined,
          }),
        });
        const j = await r.json();
        if (!j?.ok) throw new Error(j?.error);
      }
      toast({ title: "Berhasil" });
      await muat();
    } catch (e) {
      toast({ title: "Gagal", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  const aturFitur = async (d: PmDevicePub, fitur: "location" | "media", nilai: boolean) => {
    try {
      const r = await fetch(`/api/pm/devices?id=${d.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ features: { [fitur]: nilai } }),
      });
      const j = await r.json();
      if (!j?.ok) throw new Error(j?.error);
      toast({
        title: nilai ? `${fitur === "location" ? "Lokasi" : "Media"} diaktifkan` : `${fitur === "location" ? "Lokasi" : "Media"} dimatikan`,
        description: nilai
          ? "Perangkat akan meminta izin Android resmi — tidak ada akses diam-diam."
          : "Perubahan berlaku pada sinkronisasi berikutnya.",
      });
      await muat();
    } catch (e) {
      toast({ title: "Gagal", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  const bukaDetail = async (d: PmDevicePub) => {
    setDetailDev(d);
    setMediaList([]);
    setLocList([]);
    if (d.features.media) {
      fetch(`/api/pm/media?deviceId=${d.id}`).then((r) => r.json()).then((j) => j?.ok && setMediaList(j.media || [])).catch(() => {});
    }
    if (d.features.location) {
      fetch(`/api/pm/location?deviceId=${d.id}`).then((r) => r.json()).then((j) => j?.ok && setLocList(j.locations || [])).catch(() => {});
    }
  };

  /* ---------- aktivitas ---------- */
  const muatUsage = useCallback(async (childId: string, days: 1 | 7 | 30) => {
    if (!childId) return;
    setUsageLoading(true);
    try {
      const r = await fetch(`/api/pm/usage?childId=${childId}&days=${days}`);
      const d = await r.json();
      if (d?.ok) setUsage({ topApps: d.topApps || [], daily: d.daily || [], totalMs: d.totalMs || 0 });
      else setUsage(null);
    } catch {
      setUsage(null);
    } finally {
      setUsageLoading(false);
    }
  }, []);

  useEffect(() => {
    if (tab !== "aktivitas") return;
    const cid = usageChild || data?.children.find((c) => !c.disabled)?.id || "";
    if (cid && cid !== usageChild) setUsageChild(cid);
    if (cid) void muatUsage(cid, usageDays);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, usageChild, usageDays, data]);

  /* ---------- privasi ---------- */
  useEffect(() => {
    if (tab !== "privasi") return;
    fetch("/api/pm/privacy").then((r) => r.json()).then((d) => d?.ok && setPrivacy(d)).catch(() => {});
  }, [tab, data]);

  const purge = async (what: string) => {
    const label: Record<string, string> = { usage: "riwayat pemakaian", location: "riwayat lokasi", media: "media", alerts: "alerts", all: "SEMUA data monitoring" };
    if (!confirm(`Hapus ${label[what]} milik keluarga kamu? Tidak bisa dibatalkan.`)) return;
    try {
      const r = await fetch("/api/pm/privacy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ what }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      toast({ title: "Data dihapus", description: Object.entries(d.deleted || {}).map(([k, v]) => `${k}: ${v}`).join(", ") || "tidak ada data" });
      await muat();
    } catch (e) {
      toast({ title: "Gagal menghapus", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  /* ---------- APK builder integration ---------- */
  const bukaApkBuilder = (child: PmChildPub) => {
    window.dispatchEvent(new CustomEvent("fanzz-pm-open-apk", { detail: { childId: child.id, childNickname: child.nickname } }));
    setView("apk");
  };

  /* ================= LOADING ================= */
  if (loading) {
    return (
      <div>
        <ToolHeader icon={<ShieldCheck className="h-5.5 w-5.5" />} title="Parent Monitor" subtitle="Family Cyber Safety — pantau anak secara legal & transparan" accent="indigo" />
        <div className="mt-4 space-y-3">
          <div className="h-40 rounded-2xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div>
        <ToolHeader icon={<ShieldCheck className="h-5.5 w-5.5" />} title="Parent Monitor" subtitle="Family Cyber Safety" accent="indigo" />
        <EmptyState icon={<AlertTriangle className="h-8 w-8" />} title="Gagal memuat" desc="Coba muat ulang halaman." />
      </div>
    );
  }

  /* ================= ONBOARDING (belum attestation) ================= */
  if (!data.household.attested) {
    return (
      <div>
        <ToolHeader icon={<ShieldCheck className="h-5.5 w-5.5" />} title="Parent Monitor" subtitle="Family Cyber Safety — pantau anak secara legal & transparan" accent="indigo" />

        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass mt-4 rounded-3xl p-6">
          <div className="mb-4 flex items-center gap-3">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-blue-600 text-white shadow-lg">
              <ShieldCheck className="h-6 w-6" />
            </span>
            <div>
              <h2 className="text-lg font-extrabold">Selamat datang di Parent Monitor</h2>
              <p className="text-[11px] text-muted-foreground">Kendali orang tua untuk keamanan anak di dunia digital — legal & transparan.</p>
            </div>
          </div>

          <div className="space-y-2.5 text-[11.5px] leading-relaxed text-muted-foreground">
            <p className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> <span><b className="text-foreground">Enrollment terbuka</b> — perangkat anak dimasukkan lewat QR/kode yang <b>hanya berlaku 10 menit & sekali pakai</b>; anak harus mengonfirmasi di perangkatnya sendiri.</span></p>
            <p className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> <span><b className="text-foreground">Transparan</b> — aplikasi companion di HP anak selalu menampilkan apa saja yang dipantau, dan anak bisa memutus koneksi sendiri.</span></p>
            <p className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> <span><b className="text-foreground">Tanpa spyware</b> — tidak ada keylogger, rekam diam-diam, intersep OTP, atau akses galeri tersembunyi. Izin Android resmi diminta terbuka.</span></p>
            <p className="flex gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" /> <span><b className="text-foreground">Privasi keluarga</b> — data antar keluarga terisolasi penuh; orang tua bisa menghapus semua data kapan pun.</span></p>
            <p className="flex gap-2"><Clock3 className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" /> <span>Retensi bawaan: pemakaian 90 hari, lokasi 30 hari, thumbnail media 30 hari.</span></p>
          </div>

          <div className="mt-5 rounded-2xl border border-blue-500/30 bg-blue-600/10 p-4">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-blue-300">
              <FileCheck2 className="h-3.5 w-3.5" /> Pernyataan wali resmi (wajib)
            </p>
            <label className="flex cursor-pointer items-start gap-2.5 text-[11.5px] leading-relaxed">
              <input
                type="checkbox"
                checked={attestCheck}
                onChange={(e) => setAttestCheck(e.target.checked)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-blue-600"
              />
              <span>
                Saya menyatakan bahwa saya adalah <b>orang tua / wali resmi</b> dari anak-anak yang akan dipantau,
                anak yang dipantau <b>di bawah 18 tahun</b> (atau sudah dewasa maks <b>35 tahun</b> dan mengetahui serta menyetujui pemantauan),
                dan saya <b>tidak akan</b> memakai tool ini untuk memantau pasangan, pekerja, atau orang lain.
                Saya paham UU ITE & UU PDP berlaku, dan pemantauan anak dewasa tanpa persetujuannya melanggar hukum.
              </span>
            </label>
            <div className="mt-3 flex flex-wrap items-end gap-3">
              <label className="text-[10px] font-bold text-muted-foreground">
                Tahun lahir kamu (opsional — tidak dipakai untuk keamanan/otorisasi)
                <input
                  value={attestYear}
                  onChange={(e) => setAttestYear(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  placeholder="mis. 1995"
                  className="mt-1 w-32 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs outline-none"
                />
              </label>
              <button
                onClick={kirimAttest}
                disabled={!attestCheck || attestBusy}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 px-5 py-2.5 text-xs font-extrabold text-white disabled:opacity-50"
              >
                {attestBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
                Konfirmasi & Mulai
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  /* ================= DASHBOARD ================= */
  return (
    <div className="pb-6">
      <ToolHeader icon={<ShieldCheck className="h-5.5 w-5.5" />} title="Parent Monitor" subtitle={`Keluarga ${data.household.name} • ${data.children.length} anak • ${data.devices.filter((d) => d.status === "connected").length} perangkat aktif`} accent="indigo" />

      {/* ringkasan cepat */}
      <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
        {[
          { icon: Users, label: "Anak", value: String(data.children.length), cls: "from-blue-600 to-blue-600" },
          { icon: Smartphone, label: "Perangkat", value: String(data.devices.length), cls: "from-red-500 to-red-700" },
          { icon: Activity, label: "Online", value: String(data.devices.filter((d) => d.online).length), cls: "from-emerald-500 to-teal-600" },
          { icon: Bell, label: "Alerts", value: String(data.alerts.length), cls: "from-amber-500 to-orange-600" },
        ].map((s) => (
          <div key={s.label} className="glass rounded-2xl p-3.5">
            <span className={`mb-2 flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br ${s.cls} text-white`}>
              <s.icon className="h-4 w-4" />
            </span>
            <p className="text-lg font-extrabold leading-none">{s.value}</p>
            <p className="text-[9.5px] font-bold uppercase tracking-wider text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      {/* tab */}
      <div className="mt-4 flex gap-2 overflow-x-auto pb-1">
        {([
          { id: "keluarga", label: "Anak & Pairing", icon: Baby },
          { id: "perangkat", label: "Perangkat & Status", icon: Smartphone },
          { id: "aktivitas", label: "Aktivitas", icon: Activity },
          { id: "privasi", label: "Alerts, Audit & Privasi", icon: Eye },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[11px] font-bold transition ${
              tab === t.id ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white" : "bg-secondary text-muted-foreground"
            }`}
          >
            <t.icon className="h-3.5 w-3.5" /> {t.label}
          </button>
        ))}
      </div>

      {/* ================= TAB: KELUARGA ================= */}
      {tab === "keluarga" && (
        <div className="mt-4 space-y-4">
          {data.children.length === 0 && (
            <div className="glass rounded-2xl p-8 text-center">
              <p className="text-sm font-extrabold">Belum ada profil anak</p>
              <p className="mt-1 text-[11px] text-muted-foreground">Buat profil anak dulu untuk mulai memasangkan perangkat.</p>
              <button
                onClick={() => { setChildForm({ nickname: "", birthYear: "", notes: "" }); setChildModal({ mode: "add" }); }}
                className="mt-4 rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 px-4 py-2.5 text-xs font-extrabold text-white"
              >
                <Plus className="mr-1.5 inline h-4 w-4" /> Tambah Anak
              </button>
            </div>
          )}

          {data.children.map((c) => (
            <motion.div key={c.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-4">
              <div className="flex items-center gap-3">
                {c.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.avatar} alt={c.nickname} className="h-11 w-11 rounded-2xl object-cover" />
                ) : (
                  <span className={`flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-br ${c.disabled ? "from-zinc-500 to-zinc-600" : "from-blue-600 to-blue-600"} text-lg font-extrabold text-white`}>
                    {c.nickname.charAt(0).toUpperCase()}
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-2 text-sm font-extrabold">
                    {c.nickname}
                    {c.age != null && <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-bold text-muted-foreground">{c.age} thn</span>}
                    {c.age != null && c.age >= data.limits.adultAge && (
                      <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[9px] font-bold text-amber-300">DEWASA — perlu persetujuan</span>
                    )}
                    {c.disabled && <span className="rounded-full bg-zinc-500/15 px-2 py-0.5 text-[9px] font-bold text-zinc-300">NONAKTIF</span>}
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {c.deviceCount} perangkat • {c.connectedCount} online {c.notes ? `• ${c.notes.slice(0, 60)}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 gap-1.5">
                  <button onClick={() => { setChildForm({ nickname: c.nickname, birthYear: c.birthYear ? String(c.birthYear) : "", notes: c.notes || "" }); setChildModal({ mode: "edit", child: c }); }} className="rounded-xl bg-secondary p-2 text-muted-foreground" title="Edit">
                    <FileCheck2 className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => toggleAnak(c)} className="rounded-xl bg-secondary p-2 text-muted-foreground" title={c.disabled ? "Aktifkan" : "Nonaktifkan"}>
                    {c.disabled ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
                  </button>
                  <button onClick={() => hapusAnak(c)} className="rounded-xl bg-red-500/10 p-2 text-red-300" title="Hapus">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* perangkat anak ini */}
              {c.devices.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  {c.devices.map((d) => (
                    <div key={d.id} className="flex items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2">
                      <span className={`h-2 w-2 shrink-0 rounded-full ${d.online ? "bg-emerald-400" : d.status === "paused" ? "bg-amber-400" : d.status === "revoked" ? "bg-zinc-500" : "bg-sky-400"}`} />
                      <p className="min-w-0 flex-1 truncate text-[11px] font-bold">{d.label}</p>
                      {d.battery != null && (
                        <span className="flex items-center gap-1 text-[9.5px] font-bold text-muted-foreground">
                          <BatteryFull className="h-3 w-3" /> {d.battery}%{d.charging ? "⚡" : ""}
                        </span>
                      )}
                      <span className={`rounded-full px-2 py-0.5 text-[8.5px] font-black ${STATUS_BADGE[d.status]?.cls || ""}`}>
                        {STATUS_BADGE[d.status]?.label || d.status.toUpperCase()}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* aksi pairing */}
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  onClick={() => { setDevForm({ label: `HP ${c.nickname}`, usage: true, status: true, location: false, media: false }); setDevModal({ child: c }); setQr(null); }}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3.5 py-2 text-[10.5px] font-extrabold text-white"
                >
                  <QrCode className="h-3.5 w-3.5" /> Hubungkan Perangkat (QR)
                </button>
                <button
                  onClick={() => bukaApkBuilder(c)}
                  className="flex items-center gap-1.5 rounded-xl bg-secondary px-3.5 py-2 text-[10.5px] font-extrabold text-muted-foreground"
                >
                  <Package className="h-3.5 w-3.5" /> Buat APK Companion
                </button>
              </div>
            </motion.div>
          ))}

          {data.children.length > 0 && (
            <button
              onClick={() => { setChildForm({ nickname: "", birthYear: "", notes: "" }); setChildModal({ mode: "add" }); }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-blue-500/40 bg-secondary/30 px-4 py-3.5 text-xs font-extrabold text-muted-foreground transition-colors hover:bg-secondary/60"
            >
              <Plus className="h-4 w-4" /> Tambah Anak (usia maks {data.limits.childMaxAge} tahun)
            </button>
          )}
        </div>
      )}

      {/* ================= TAB: PERANGKAT ================= */}
      {tab === "perangkat" && (
        <div className="mt-4 space-y-3">
          {data.devices.length === 0 && (
            <EmptyState icon={<Smartphone className="h-8 w-8" />} title="Belum ada perangkat terpasang" desc="Tambahkan anak dulu di tab Anak & Pairing, lalu hubungkan perangkat lewat QR." />
          )}
          {data.devices.map((d) => {
            const child = data.children.find((c) => c.id === d.childId);
            return (
              <motion.div key={d.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-4">
                <div className="flex items-center gap-3">
                  <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${d.online ? "bg-emerald-500/15 text-emerald-300" : "bg-secondary text-muted-foreground"}`}>
                    <Smartphone className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="flex flex-wrap items-center gap-1.5 text-sm font-extrabold">
                      {d.label}
                      <span className={`rounded-full px-2 py-0.5 text-[8.5px] font-black ${STATUS_BADGE[d.status]?.cls}`}>{STATUS_BADGE[d.status]?.label}</span>
                    </p>
                    <p className="text-[10px] text-muted-foreground">
                      {child ? `Milik: ${child.nickname} • ` : ""}{d.model || "model belum dilaporkan"}{d.androidVersion ? ` • Android ${d.androidVersion}` : ""}
                    </p>
                  </div>
                  <button onClick={() => bukaDetail(d)} className="shrink-0 rounded-xl bg-secondary p-2 text-muted-foreground" title="Detail (media/lokasi)">
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] sm:grid-cols-4">
                  <div className="rounded-xl bg-secondary/50 px-2.5 py-2">
                    <p className="font-black uppercase tracking-wider text-muted-foreground">Baterai</p>
                    <p className="mt-0.5 font-extrabold">{d.battery != null ? `${d.battery}%${d.charging ? " ⚡" : ""}` : "—"}</p>
                  </div>
                  <div className="rounded-xl bg-secondary/50 px-2.5 py-2">
                    <p className="font-black uppercase tracking-wider text-muted-foreground">Jaringan</p>
                    <p className="mt-0.5 truncate font-extrabold">{d.network || "—"}</p>
                  </div>
                  <div className="rounded-xl bg-secondary/50 px-2.5 py-2">
                    <p className="font-black uppercase tracking-wider text-muted-foreground">Terakhir aktif</p>
                    <p className="mt-0.5 font-extrabold">{waktuLalu(d.lastSeen)}</p>
                  </div>
                  <div className="rounded-xl bg-secondary/50 px-2.5 py-2">
                    <p className="font-black uppercase tracking-wider text-muted-foreground">Sinkron terakhir</p>
                    <p className="mt-0.5 font-extrabold">{waktuLalu(d.lastSync)}</p>
                  </div>
                </div>

                {/* permission center */}
                {d.permissions && (
                  <div className="mt-3">
                    <p className="mb-1.5 text-[9px] font-black uppercase tracking-wider text-muted-foreground">Pusat Izin (dilaporkan perangkat)</p>
                    <div className="flex flex-wrap gap-1.5">
                      {Object.entries(d.permissions).slice(0, 6).map(([k, v]) => (
                        <span key={k} className={`rounded-full px-2.5 py-1 text-[9px] font-bold ${
                          v === "granted" ? "bg-emerald-500/15 text-emerald-300" : v === "not_requested" ? "bg-zinc-500/15 text-zinc-300" : "bg-red-500/15 text-red-300"
                        }`}>
                          {PERM_LABEL[k] || k}: {v === "granted" ? "GRANTED" : v === "denied" ? "DENIED" : v === "not_requested" ? "BELUM DIMINTA" : v === "revoked" ? "DICABUT" : v.toUpperCase()}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* fitur opsional */}
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => aturFitur(d, "location", !d.features.location)}
                    className={`rounded-xl px-3 py-1.5 text-[10px] font-extrabold ${d.features.location ? "bg-emerald-500/20 text-emerald-300" : "bg-secondary text-muted-foreground"}`}
                  >
                    <MapPin className="mr-1 inline h-3 w-3" /> Lokasi {d.features.location ? "ON" : "OFF"}
                  </button>
                  <button
                    onClick={() => aturFitur(d, "media", !d.features.media)}
                    className={`rounded-xl px-3 py-1.5 text-[10px] font-extrabold ${d.features.media ? "bg-red-500/20 text-red-300" : "bg-secondary text-muted-foreground"}`}
                  >
                    <ImageIconLucide className="mr-1 inline h-3 w-3" /> Media {d.features.media ? "ON" : "OFF"}
                  </button>
                </div>

                {/* aksi */}
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {d.status === "connected" && (
                    <button onClick={() => aksiPerangkat(d, "pause")} className="rounded-xl bg-amber-500/10 px-3 py-1.5 text-[10px] font-bold text-amber-300">
                      <Pause className="mr-1 inline h-3 w-3" /> Jeda
                    </button>
                  )}
                  {d.status === "paused" && (
                    <button onClick={() => aksiPerangkat(d, "resume")} className="rounded-xl bg-emerald-500/10 px-3 py-1.5 text-[10px] font-bold text-emerald-300">
                      <Play className="mr-1 inline h-3 w-3" /> Lanjutkan
                    </button>
                  )}
                  {d.status !== "revoked" && (
                    <button onClick={() => aksiPerangkat(d, "revoke")} className="rounded-xl bg-orange-500/10 px-3 py-1.5 text-[10px] font-bold text-orange-300">
                      <Ban className="mr-1 inline h-3 w-3" /> Cabut Akses
                    </button>
                  )}
                  <button onClick={() => aksiPerangkat(d, "delete")} className="rounded-xl bg-red-500/10 px-3 py-1.5 text-[10px] font-bold text-red-300">
                    <Trash2 className="mr-1 inline h-3 w-3" /> Hapus
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ================= TAB: AKTIVITAS ================= */}
      {tab === "aktivitas" && (
        <div className="mt-4 space-y-3">
          {data.children.length === 0 && <EmptyState icon={<Baby className="h-8 w-8" />} title="Belum ada anak" desc="Tambahkan profil anak dulu." />}
          {data.children.length > 0 && (
            <>
              <div className="glass flex flex-wrap items-center gap-2 rounded-2xl p-3">
                <select
                  value={usageChild}
                  onChange={(e) => setUsageChild(e.target.value)}
                  className="rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs font-bold outline-none"
                >
                  {data.children.map((c) => (
                    <option key={c.id} value={c.id}>{c.nickname}</option>
                  ))}
                </select>
                <div className="flex gap-1.5">
                  {([1, 7, 30] as const).map((d) => (
                    <button
                      key={d}
                      onClick={() => setUsageDays(d)}
                      className={`rounded-full px-3 py-2 text-[10.5px] font-extrabold ${usageDays === d ? "bg-gradient-to-r from-blue-600 to-blue-600 text-white" : "bg-secondary text-muted-foreground"}`}
                    >
                      {d === 1 ? "Hari ini" : d === 7 ? "7 hari" : "30 hari"}
                    </button>
                  ))}
                </div>
                {usage && (
                  <p className="ml-auto text-[10px] font-bold text-muted-foreground">
                    Total: <b className="text-foreground">{fmtDurasi(usage.totalMs)}</b>
                  </p>
                )}
              </div>

              {usageLoading && <div className="h-48 rounded-2xl shimmer" />}

              {!usageLoading && usage && usage.topApps.length === 0 && (
                <EmptyState icon={<Activity className="h-8 w-8" />} title="Belum ada data pemakaian" desc="Data muncul setelah perangkat anak terhubung & sinkron (setiap ±15 menit saat aktif)." />
              )}

              {!usageLoading && usage && usage.topApps.length > 0 && (
                <>
                  <div className="glass rounded-2xl p-4">
                    <p className="mb-3 text-[11px] font-black uppercase tracking-wider text-muted-foreground">Aplikasi teratas</p>
                    <div className="space-y-2">
                      {usage.topApps.slice(0, 10).map((a) => (
                        <div key={a.pkg} className="flex items-center gap-3">
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-xs font-bold">{a.app}</p>
                            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-secondary">
                              <div
                                className="h-full rounded-full bg-gradient-to-r from-blue-600 to-blue-500"
                                style={{ width: `${Math.max(4, (a.usageMs / (usage.topApps[0]?.usageMs || 1)) * 100)}%` }}
                              />
                            </div>
                            <p className="mt-0.5 text-[9px] text-muted-foreground">{a.pkg} • {a.launches}x dibuka</p>
                          </div>
                          <p className="shrink-0 text-[11px] font-extrabold tabular-nums">{fmtDurasi(a.usageMs)}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {usage.daily.length > 1 && (
                    <div className="glass rounded-2xl p-4">
                      <p className="mb-3 text-[11px] font-black uppercase tracking-wider text-muted-foreground">Pemakaian per hari</p>
                      <div className="h-40">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={usage.daily.map((x) => ({ ...x, menit: Math.round(x.usageMs / 60000) }))}>
                            <XAxis dataKey="date" tick={{ fontSize: 9, fill: "var(--muted)" }} tickLine={false} axisLine={false} />
                            <YAxis tick={{ fontSize: 9, fill: "var(--muted)" }} tickLine={false} axisLine={false} width={30} />
                            <Tooltip
                              contentStyle={{ background: "var(--popover, #1c1c22)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 12, fontSize: 11 }}
                              formatter={(v: number) => [`${v} menit`, "Pemakaian"]}
                            />
                            <Bar dataKey="menit" fill="url(#pmGrad)" radius={[6, 6, 0, 0]} />
                            <defs>
                              <linearGradient id="pmGrad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#6366f1" />
                                <stop offset="100%" stopColor="#2563eb" />
                              </linearGradient>
                            </defs>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* ================= TAB: PRIVASI (alerts+audit+privacy) ================= */}
      {tab === "privasi" && (
        <div className="mt-4 space-y-3">
          {/* alerts */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-2.5 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
              <Bell className="h-3.5 w-3.5 text-amber-400" /> Alerts ({data.alerts.length})
            </p>
            {data.alerts.length === 0 && <p className="py-3 text-center text-[11px] text-muted-foreground">Belum ada alert — semua sehat ✨</p>}
            <div className="max-h-64 space-y-1.5 overflow-y-auto">
              {data.alerts.map((a) => (
                <div key={a.id} className="flex items-start gap-2.5 rounded-xl bg-secondary/50 px-3 py-2">
                  <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
                  <div className="min-w-0 flex-1">
                    <p className="text-[11px] font-bold leading-snug">{a.msg}</p>
                    <p className="text-[9px] text-muted-foreground">{waktuLalu(a.ts)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* audit log */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-2.5 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
              <ScrollText className="h-3.5 w-3.5 text-blue-500" /> Audit Log
            </p>
            {data.audit.length === 0 && <p className="py-3 text-center text-[11px] text-muted-foreground">Belum ada aktivitas tercatat.</p>}
            <div className="max-h-64 space-y-1 overflow-y-auto">
              {data.audit.map((a) => (
                <div key={a.id} className="flex items-center gap-2.5 rounded-xl bg-secondary/50 px-3 py-1.5 text-[10.5px]">
                  <span className="rounded-md bg-blue-600/15 px-1.5 py-0.5 font-mono text-[8.5px] font-bold text-blue-300">{a.action}</span>
                  <p className="min-w-0 flex-1 truncate text-muted-foreground">{a.detail || "—"}</p>
                  <p className="shrink-0 text-[9px] text-muted-foreground">{new Date(a.ts).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}</p>
                </div>
              ))}
            </div>
          </div>

          {/* privacy center */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-1 flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
              <Eye className="h-3.5 w-3.5 text-emerald-400" /> Privacy Center
            </p>
            <p className="mb-3 text-[10.5px] leading-relaxed text-muted-foreground">
              Semua data monitoring hanya milik keluarga kamu dan bisa dihapus kapan pun.
              Retensi otomatis: pemakaian {data.retention.usageDays} hari, lokasi {data.retention.locationDays} hari, thumbnail {data.retention.thumbDays} hari.
            </p>
            {privacy && (
              <div className="mb-3 grid grid-cols-2 gap-2 text-[10px] sm:grid-cols-4">
                {Object.entries(privacy.counts).map(([k, v]) => (
                  <div key={k} className="rounded-xl bg-secondary/50 px-2.5 py-2">
                    <p className="font-black uppercase tracking-wider text-muted-foreground">{k}</p>
                    <p className="mt-0.5 font-extrabold">{v} entri</p>
                  </div>
                ))}
              </div>
            )}
            <div className="flex flex-wrap gap-1.5">
              {[
                { what: "usage", label: "Hapus Pemakaian", cls: "bg-red-500/10 text-red-300" },
                { what: "location", label: "Hapus Lokasi", cls: "bg-red-500/10 text-red-300" },
                { what: "media", label: "Hapus Media", cls: "bg-red-500/10 text-red-300" },
                { what: "alerts", label: "Hapus Alerts", cls: "bg-red-500/10 text-red-300" },
                { what: "all", label: "HAPUS SEMUA DATA", cls: "bg-gradient-to-r from-red-600 to-rose-700 text-white" },
              ].map((b) => (
                <button key={b.what} onClick={() => purge(b.what)} className={`rounded-xl px-3 py-2 text-[10px] font-extrabold ${b.cls}`}>
                  <Trash2 className="mr-1 inline h-3 w-3" /> {b.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= MODAL: ANAK ================= */}
      <AnimatePresence>
        {childModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center" onClick={() => setChildModal(null)}>
            <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-t-3xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] p-5 sm:rounded-3xl">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-base font-extrabold">{childModal.mode === "add" ? "Tambah Anak" : `Edit ${childModal.child.nickname}`}</h3>
                <button onClick={() => setChildModal(null)} className="rounded-xl bg-secondary p-2 text-muted-foreground"><X className="h-4 w-4" /></button>
              </div>
              <label className="block text-[10px] font-bold text-muted-foreground">
                Nama panggilan
                <input value={childForm.nickname} onChange={(e) => setChildForm((f) => ({ ...f, nickname: e.target.value.slice(0, 30) }))} placeholder="mis. Anak 1 / Dimas" className="mt-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none" />
              </label>
              <label className="mt-3 block text-[10px] font-bold text-muted-foreground">
                Tahun lahir (opsional — batas usia {data.limits.childMaxAge} tahun)
                <input value={childForm.birthYear} onChange={(e) => setChildForm((f) => ({ ...f, birthYear: e.target.value.replace(/\D/g, "").slice(0, 4) }))} placeholder="mis. 2012" className="mt-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none" />
              </label>
              <label className="mt-3 block text-[10px] font-bold text-muted-foreground">
                Catatan (opsional)
                <textarea value={childForm.notes} onChange={(e) => setChildForm((f) => ({ ...f, notes: e.target.value.slice(0, 200) }))} rows={2} placeholder="mis. HP sekolah, tablet rumah…" className="mt-1 w-full resize-none rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none" />
              </label>
              <button onClick={simpanAnak} disabled={childBusy || !childForm.nickname.trim()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 px-4 py-3.5 text-xs font-extrabold text-white disabled:opacity-60">
                {childBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />} Simpan
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: HUBUNGKAN PERANGKAT (QR) ================= */}
      <AnimatePresence>
        {devModal && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center" onClick={() => { setDevModal(null); setQr(null); }}>
            <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] p-5 sm:rounded-3xl">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-extrabold">Hubungkan Perangkat</h3>
                  <p className="text-[10px] text-muted-foreground">Untuk anak: {devModal.child.nickname}</p>
                </div>
                <button onClick={() => { setDevModal(null); setQr(null); }} className="rounded-xl bg-secondary p-2 text-muted-foreground"><X className="h-4 w-4" /></button>
              </div>

              {!qr ? (
                <>
                  <label className="block text-[10px] font-bold text-muted-foreground">
                    Nama / label perangkat
                    <input value={devForm.label} onChange={(e) => setDevForm((f) => ({ ...f, label: e.target.value.slice(0, 40) }))} placeholder="mis. Samsung A55" className="mt-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none" />
                  </label>

                  <p className="mb-1.5 mt-4 text-[10px] font-black uppercase tracking-wider text-muted-foreground">Fitur yang diminta saat pairing</p>
                  <div className="space-y-1.5">
                    {([
                      { k: "usage", label: "Statistik pemakaian aplikasi", desc: "agregat jam & jumlah buka per aplikasi" },
                      { k: "status", label: "Status perangkat", desc: "baterai, jaringan, izin" },
                      { k: "location", label: "Lokasi (opsional)", desc: "posisi saat fitur diaktifkan + izin Android" },
                      { k: "media", label: "Media terpilih (opsional)", desc: "metadata + thumbnail via Photo Picker" },
                    ] as const).map((f) => (
                      <label key={f.k} className="flex cursor-pointer items-start gap-2.5 rounded-xl bg-secondary/50 px-3 py-2.5">
                        <input
                          type="checkbox"
                          checked={(devForm as Record<string, boolean>)[f.k]}
                          onChange={(e) => setDevForm((prev) => ({ ...prev, [f.k]: e.target.checked }))}
                          className="mt-0.5 h-4 w-4 shrink-0 accent-blue-600"
                        />
                        <span>
                          <span className="block text-[11px] font-bold">{f.label}</span>
                          <span className="block text-[9.5px] text-muted-foreground">{f.desc}</span>
                        </span>
                      </label>
                    ))}
                  </div>

                  <div className="mt-4 rounded-xl bg-blue-600/10 p-3 text-[10px] leading-relaxed text-blue-200">
                    Alur: <b>Buat APK Companion</b> (atau pakai companion yang sudah terinstall) → install di HP anak → buka →
                    scan QR / masukkan kode → <b>anak konfirmasi</b> di HP → izin Android resmi diminta → terhubung.
                  </div>

                  <div className="mt-4 grid grid-cols-2 gap-2">
                    <button onClick={buatPerangkat} disabled={qrBusy || !devForm.label.trim()} className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-4 py-3 text-xs font-extrabold text-white disabled:opacity-60">
                      {qrBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <QrCode className="h-4 w-4" />} Buat QR Pairing
                    </button>
                    <button onClick={() => bukaApkBuilder(devModal.child)} className="flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold text-muted-foreground">
                      <Package className="h-4 w-4" /> Buat APK Companion
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center">
                  <div className="mx-auto w-fit">
                    {qr.status === "created" || qr.status === "pending" || qr.status === "consent_required" || qr.status === "waiting" || qr.status === "scanned" || qr.status === "confirming" ? (
                      qr.status === "created" || qr.status === "waiting" ? (
                        <QrSvg text={qr.qrPayload} size={230} />
                      ) : (
                        <div className="flex h-[230px] w-[230px] flex-col items-center justify-center rounded-2xl bg-sky-500/10 text-sky-300">
                          <Loader2 className="h-10 w-10 animate-spin" />
                          <p className="mt-2 px-4 text-xs font-extrabold">{STATUS_BADGE[qr.status]?.label}</p>
                        </div>
                      )
                    ) : (
                      <div className={`flex h-[230px] w-[230px] flex-col items-center justify-center rounded-2xl ${qr.status === "connected" ? "bg-emerald-500/10 text-emerald-300" : "bg-red-500/10 text-red-300"}`}>
                        {qr.status === "connected" ? <Check className="h-10 w-10" /> : <AlertTriangle className="h-10 w-10" />}
                        <p className="mt-2 text-xs font-extrabold">{STATUS_BADGE[qr.status]?.label}</p>
                      </div>
                    )}
                  </div>

                  <p className="mt-3 text-[10px] font-bold text-muted-foreground">
                    Kode manual: <b className="font-mono text-foreground">{qr.code}</b>
                  </p>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    {(qr.status === "created" || qr.status === "waiting") ? `Kedaluwarsa dalam ${Math.floor(qrCountdown / 60)}:${String(qrCountdown % 60).padStart(2, "0")}` : STATUS_BADGE[qr.status]?.label}
                  </p>

                  <div className="mt-3 rounded-xl bg-secondary/60 p-3 text-left text-[10px] leading-relaxed text-muted-foreground">
                    Status pairing: <b className={qr.status === "connected" ? "text-emerald-300" : qr.status === "rejected" || qr.status === "expired" ? "text-red-300" : qr.status === "created" || qr.status === "waiting" ? "text-amber-300" : "text-sky-300"}>{STATUS_BADGE[qr.status]?.label}</b> —
                    halaman ini memantau otomatis tiap 3 detik. Perangkat baru terhubung SETELAH anak menekan “Saya Setuju” di perangkatnya. QR ini <b>satu kali pakai</b> dan tidak berisi rahasia apa pun.
                  </div>

                  <div className="mt-4 grid grid-cols-3 gap-2">
                    <button
                      onClick={() => { navigator.clipboard?.writeText(qr.code).then(() => toast({ title: "Kode tersalin" })).catch(() => {}); }}
                      className="flex items-center justify-center gap-1.5 rounded-xl bg-secondary px-3 py-2.5 text-[10px] font-extrabold text-muted-foreground"
                    >
                      <Copy className="h-3.5 w-3.5" /> Salin Kode
                    </button>
                    <button onClick={refreshQr} disabled={qrBusy} className="flex items-center justify-center gap-1.5 rounded-xl bg-secondary px-3 py-2.5 text-[10px] font-extrabold text-muted-foreground">
                      <RefreshCw className={`h-3.5 w-3.5 ${qrBusy ? "animate-spin" : ""}`} /> QR Baru
                    </button>
                    <button onClick={batalkanQr} className="flex items-center justify-center gap-1.5 rounded-xl bg-red-500/10 px-3 py-2.5 text-[10px] font-extrabold text-red-300">
                      <X className="h-3.5 w-3.5" /> Batal
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ================= MODAL: DETAIL PERANGKAT ================= */}
      <AnimatePresence>
        {detailDev && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center" onClick={() => setDetailDev(null)}>
            <motion.div initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }} onClick={(e) => e.stopPropagation()} className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] p-5 sm:rounded-3xl">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-base font-extrabold">{detailDev.label}</h3>
                <button onClick={() => setDetailDev(null)} className="rounded-xl bg-secondary p-2 text-muted-foreground"><X className="h-4 w-4" /></button>
              </div>

              {/* media */}
              <p className="mb-2 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-muted-foreground">
                <ImageIconLucide className="h-3.5 w-3.5 text-red-400" /> Media terpilih
              </p>
              {detailDev.features.media ? (
                mediaList.length ? (
                  <div className="grid grid-cols-3 gap-2">
                    {mediaList.slice(0, 18).map((m) => (
                      <div key={m.id} className="relative aspect-square overflow-hidden rounded-xl bg-secondary">
                        {m.thumb ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={m.thumb} alt={m.kind} className="h-full w-full object-cover" />
                        ) : (
                          <span className="flex h-full w-full items-center justify-center text-[9px] font-bold text-muted-foreground">{m.kind}</span>
                        )}
                        <button
                          onClick={async () => {
                            await fetch(`/api/pm/media?id=${m.id}`, { method: "DELETE" });
                            setMediaList((l) => l.filter((x) => x.id !== m.id));
                          }}
                          className="absolute right-1 top-1 rounded-full bg-black/60 p-1 text-red-300"
                          aria-label="hapus"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="rounded-xl bg-secondary/50 px-3 py-3 text-center text-[10.5px] text-muted-foreground">Belum ada media yang dipilih pengguna perangkat.</p>
                )
              ) : (
                <p className="rounded-xl bg-secondary/50 px-3 py-3 text-center text-[10.5px] text-muted-foreground">MEDIA ACCESS UNAVAILABLE — fitur media tidak aktif untuk perangkat ini.</p>
              )}
              {detailDev.features.media && mediaList.length > 0 && (
                <button
                  onClick={async () => {
                    if (!confirm("Hapus semua media perangkat ini?")) return;
                    await fetch(`/api/pm/media?deviceId=${detailDev.id}&all=1`, { method: "DELETE" });
                    setMediaList([]);
                    toast({ title: "Semua media dihapus" });
                  }}
                  className="mt-2 w-full rounded-xl bg-red-500/10 px-3 py-2 text-[10px] font-extrabold text-red-300"
                >
                  <Trash2 className="mr-1 inline h-3 w-3" /> Hapus Semua Media
                </button>
              )}

              {/* lokasi */}
              <p className="mb-2 mt-5 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 text-emerald-400" /> Lokasi terakhir
              </p>
              {detailDev.features.location ? (
                locList.length ? (
                  <div className="space-y-1.5">
                    {locList.slice(0, 5).map((l, i) => (
                      <a
                        key={i}
                        href={`https://www.openstreetmap.org/?mlat=${l.lat}&mlon=${l.lon}#map=16/${l.lat}/${l.lon}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2 text-[11px] font-bold"
                      >
                        <MapPin className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
                        <span className="min-w-0 flex-1">{l.lat.toFixed(5)}, {l.lon.toFixed(5)}{l.accuracy ? ` ±${Math.round(l.accuracy)}m` : ""}</span>
                        <span className="shrink-0 text-[9px] text-muted-foreground">{waktuLalu(l.ts)}</span>
                      </a>
                    ))}
                  </div>
                ) : (
                  <p className="rounded-xl bg-secondary/50 px-3 py-3 text-center text-[10.5px] text-muted-foreground">Belum ada laporan lokasi (fitur aktif, menunggu sinkronisasi perangkat).</p>
                )
              ) : (
                <p className="rounded-xl bg-secondary/50 px-3 py-3 text-center text-[10.5px] text-muted-foreground">Lokasi tidak diaktifkan (default OFF).</p>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
