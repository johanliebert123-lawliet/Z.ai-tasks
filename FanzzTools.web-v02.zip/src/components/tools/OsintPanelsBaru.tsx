"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import {
  Search, Loader2, Mail, ShieldCheck, AlertTriangle, XCircle, CheckCircle2,
  MessageCircle, Copy, ExternalLink, FileSpreadsheet, ListChecks, Info,
} from "lucide-react";

/** Panel-panel OSINT baru V2.11: Email Checker (#25), WA Info/Unban (#27/#28), NIK Massal (#16). */

/* ==================== EMAIL CHECKER (#25) ==================== */

interface HasilEmail {
  email: string;
  formatValid: boolean;
  domain: string;
  mx: { ada: boolean; catatan: string[] } | null;
  disposable: boolean;
  gravatar: boolean;
  reputasi: { reputasi: string; mencurigakan: boolean; bocor: boolean; malicious: boolean; firstSeen: string | null } | null;
  verdict: "baik" | "perhatian" | "buruk" | "tidak-valid";
  catatan: string[];
}

const TIPS_EMAIL = [
  "Aktifkan verifikasi dua langkah (2FA) di setiap layanan — mulai dari email utama Anda.",
  "Gunakan kata sandi unik per layanan; kelola dengan pengelola kata sandi.",
  "Kalau email ini muncul di kebocoran data, segera ganti kata sandi layanan terkait.",
  "Email sekali pakai (disposable) cocok untuk registrasi uji coba, jangan untuk akun penting.",
  "Periksa email utama Anda di haveibeenpwned.com (layanan resmi) untuk melihat riwayat kebocoran.",
];

export function EmailPanel() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [hasil, setHasil] = useState<HasilEmail | null>(null);
  const [error, setError] = useState("");

  const cek = async () => {
    const e = email.trim();
    if (!e || busy) return;
    setBusy(true);
    setError("");
    setHasil(null);
    try {
      const res = await fetch(`/api/osint/email?email=${encodeURIComponent(e)}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memeriksa");
      setHasil(d.hasil as HasilEmail);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal memeriksa email");
    } finally {
      setBusy(false);
    }
  };

  const verdictMeta = (v: HasilEmail["verdict"]) => {
    switch (v) {
      case "baik":
        return { ikon: <CheckCircle2 className="h-6 w-6 text-emerald-400" />, judul: "Baik", warna: "text-emerald-300 bg-emerald-500/10" };
      case "perhatian":
        return { ikon: <AlertTriangle className="h-6 w-6 text-amber-400" />, judul: "Perlu Perhatian", warna: "text-amber-300 bg-amber-500/10" };
      case "buruk":
        return { ikon: <XCircle className="h-6 w-6 text-red-400" />, judul: "Bermasalah", warna: "text-red-300 bg-red-500/10" };
      default:
        return { ikon: <XCircle className="h-6 w-6 text-muted-foreground" />, judul: "Tidak Valid", warna: "text-muted-foreground bg-secondary" };
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && cek()}
          placeholder="nama@contoh.com"
          className="rounded-xl"
          inputMode="email"
        />
        <Button onClick={cek} disabled={busy || !email.trim()} className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 text-white">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
        </Button>
      </div>

      <p className="rounded-xl bg-secondary/50 px-3.5 py-2.5 text-[10.5px] leading-relaxed text-muted-foreground">
        Pemeriksa yang <b>jujur</b>: format, MX domain (nyata via DNS), domain sekali-pakai, profil Gravatar, dan reputasi bila tersedia.
        Yang <b>tidak mungkin</b> dicek alat publik mana pun — daftar situs tempat email terdaftar, kata sandi bocor per-email, tanggal buat akun, nomor WA terkait — kami tulis terus terang, bukan dipalsukan.
      </p>

      <AnimatePresence>
        {hasil && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            <div className={`flex items-center gap-3 rounded-2xl px-4 py-3.5 ${verdictMeta(hasil.verdict).warna}`}>
              {verdictMeta(hasil.verdict).ikon}
              <div>
                <p className="text-sm font-extrabold">{verdictMeta(hasil.verdict).judul}</p>
                <p className="text-[11px] opacity-80">{hasil.email}</p>
              </div>
            </div>

            <div className="space-y-2">
              {hasil.mx && (
                <div className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5">
                  <ShieldCheck className={`h-4 w-4 ${hasil.mx.ada ? "text-emerald-400" : "text-red-400"}`} />
                  <span className="w-28 shrink-0 text-[10.5px] font-semibold text-muted-foreground">Server MX</span>
                  <span className="min-w-0 flex-1 truncate text-right text-xs font-bold">
                    {hasil.mx.ada ? hasil.mx.catatan.join(", ") : "Tidak ada — domain tidak bisa terima email"}
                  </span>
                </div>
              )}
              {hasil.domain && (
                <div className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5">
                  <Mail className="h-4 w-4 text-blue-500" />
                  <span className="w-28 shrink-0 text-[10.5px] font-semibold text-muted-foreground">Domain</span>
                  <span className="min-w-0 flex-1 truncate text-right text-xs font-bold">
                    {hasil.domain}
                    {hasil.disposable ? " — sekali pakai" : ""}
                  </span>
                </div>
              )}
              <div className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5">
                <ShieldCheck className={`h-4 w-4 ${hasil.gravatar ? "text-emerald-400" : "text-muted-foreground"}`} />
                <span className="w-28 shrink-0 text-[10.5px] font-semibold text-muted-foreground">Gravatar</span>
                <span className="min-w-0 flex-1 text-right text-xs font-bold">
                  {hasil.gravatar ? "Ada profil publik" : "Tidak ada (wajar)"}
                </span>
              </div>
              {hasil.reputasi && (
                <div className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5">
                  <AlertTriangle className={`h-4 w-4 ${hasil.reputasi.mencurigakan || hasil.reputasi.malicious ? "text-amber-400" : "text-emerald-400"}`} />
                  <span className="w-28 shrink-0 text-[10.5px] font-semibold text-muted-foreground">Reputasi</span>
                  <span className="min-w-0 flex-1 text-right text-xs font-bold">
                    {hasil.reputasi.reputasi}
                    {hasil.reputasi.bocor ? " • pernah bocor" : ""}
                    {hasil.reputasi.firstSeen ? ` • terlihat sejak ${hasil.reputasi.firstSeen}` : ""}
                  </span>
                </div>
              )}
            </div>

            <div className="rounded-2xl glass p-3.5">
              <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-extrabold text-blue-300">
                <Info className="h-3.5 w-3.5" /> Catatan
              </p>
              <ul className="space-y-1">
                {hasil.catatan.map((c, i) => (
                  <li key={i} className="text-[11px] leading-relaxed text-muted-foreground">• {c}</li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl bg-emerald-500/10 p-3.5">
              <p className="mb-2 flex items-center gap-1.5 text-[11px] font-extrabold text-emerald-300">
                <ShieldCheck className="h-3.5 w-3.5" /> Tips mengamankan & memulihkan
              </p>
              <ul className="space-y-1.5">
                {TIPS_EMAIL.map((t, i) => (
                  <li key={i} className="text-[11px] leading-relaxed text-emerald-100/80">• {t}</li>
                ))}
              </ul>
              <a
                href="https://haveibeenpwned.com"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2.5 inline-flex items-center gap-1.5 rounded-xl bg-emerald-500/20 px-3 py-2 text-[11px] font-bold text-emerald-200"
              >
                <ExternalLink className="h-3.5 w-3.5" /> Cek kebocoran resmi di haveibeenpwned.com
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {error && !busy && <EmptyState icon={<XCircle className="h-8 w-8" />} title="Gagal" desc={error} />}
    </div>
  );
}

/* ==================== WHATSAPP INFO + UNBAN (#27/#28) ==================== */

interface HasilWa {
  valid: boolean;
  e164: string;
  negara: { nama: string; iso: string; bendera: string; prefix: string } | null;
  operator: string | null;
  jenisIndikasi: "business" | "regular" | null;
  waMe: string;
  catatan: string[];
}

export function WaPanel() {
  const [nomor, setNomor] = useState("+62 ");
  const [busy, setBusy] = useState(false);
  const [hasil, setHasil] = useState<HasilWa | null>(null);
  const [error, setError] = useState("");
  const { toast } = useToast();

  // V2 Modern-UpdSec: fitur "Buka Blokir (Unban)" DIHAPUS sesuai permintaan
  // pemilik — hanya pemeriksaan info nomor WA yang tetap tersedia.

  const cek = async () => {
    const n = nomor.trim();
    if (!n || busy) return;
    setBusy(true);
    setError("");
    setHasil(null);
    try {
      const res = await fetch(`/api/osint/wa?number=${encodeURIComponent(n)}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memeriksa");
      setHasil(d.hasil as HasilWa);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal memeriksa nomor");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          value={nomor}
          onChange={(e) => setNomor(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && cek()}
          placeholder="+62 812…"
          className="rounded-xl"
          inputMode="tel"
        />
        <Button onClick={cek} disabled={busy || !nomor.trim()} className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 text-white">
          {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
        </Button>
      </div>

      <p className="rounded-xl bg-secondary/50 px-3.5 py-2.5 text-[10.5px] leading-relaxed text-muted-foreground">
        Info yang bisa dipercaya: validitas format, negara, indikasi operator (ID), dan tautan chat resmi wa.me.
        Nama profil/foto/tanggal buat akun <b>tidak bisa</b> ditarik alat publik mana pun — itu hanya terlihat sesama kontak atau via WhatsApp Business API resmi. Alat yang mengaku bisa = tidak jujur.
      </p>

      <AnimatePresence>
        {hasil && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            <div className="flex items-center gap-3 rounded-2xl bg-secondary/50 px-4 py-3.5">
              <MessageCircle className={`h-6 w-6 ${hasil.valid ? "text-emerald-400" : "text-amber-400"}`} />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-extrabold">{hasil.negara ? `${hasil.negara.bendera} ${hasil.negara.nama}` : "Negara tak dikenal"}</p>
                <p className="font-mono text-xs text-muted-foreground">{hasil.e164}</p>
              </div>
              {hasil.operator && (
                <span className="rounded-full bg-blue-600/15 px-2.5 py-1 text-[10px] font-bold text-blue-300">{hasil.operator}</span>
              )}
            </div>

            <a
              href={hasil.waMe}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 px-4 py-3 text-xs font-extrabold text-white"
            >
              <ExternalLink className="h-4 w-4" /> Buka chat resmi wa.me
            </a>

            <div className="rounded-2xl glass p-3.5">
              <p className="mb-1.5 flex items-center gap-1.5 text-[11px] font-extrabold text-blue-300">
                <Info className="h-3.5 w-3.5" /> Catatan
              </p>
              <ul className="space-y-1">
                {hasil.catatan.map((c, i) => (
                  <li key={i} className="text-[11px] leading-relaxed text-muted-foreground">• {c}</li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {error && !busy && <EmptyState icon={<XCircle className="h-8 w-8" />} title="Gagal" desc={error} />}
    </div>
  );
}

/* ==================== NIK MASSAL (versi legal #16) ==================== */

interface BarisMassal {
  input: string;
  nik: string;
  valid: boolean;
  anomali: string[];
  wilayah: { provinsi: string; kabupatenKota: string; kecamatan: string; kodePos?: string };
  pribadi: { jenisKelamin: string; tanggalLahir: string; umur: string };
}

export function NikMassPanel() {
  const [daftar, setDaftar] = useState("");
  const [busy, setBusy] = useState(false);
  const [baris, setBaris] = useState<BarisMassal[] | null>(null);
  const [ringkas, setRingkas] = useState<{ total: number; valid: number; tidakValid: number; anomali: number } | null>(null);
  const [error, setError] = useState("");
  const { toast } = useToast();

  const proses = async () => {
    if (!daftar.trim() || busy) return;
    setBusy(true);
    setError("");
    setBaris(null);
    try {
      const res = await fetch("/api/osint/nik/mass", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ daftar }),
      });
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal memproses");
      setBaris(d.baris);
      setRingkas(d.ringkas);
      pushHistoryNikMass(d.ringkas.total);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal memproses");
    } finally {
      setBusy(false);
    }
  };

  const pushHistoryNikMass = (total: number) => {
    import("@/lib/history").then(({ pushHistory }) =>
      pushHistory("osint", { id: `nikmass-${Date.now()}`, title: "Validasi NIK massal", subtitle: `${total} NIK diperiksa` }),
    );
  };

  const salinCsv = () => {
    if (!baris) return;
    const csv = [
      "nik,valid,provinsi,kabupaten,kecamatan,tanggal_lahir,jenis_kelamin,umur,anomali",
      ...baris.map((b) =>
        [
          b.nik,
          b.valid ? "YA" : "TIDAK",
          b.wilayah.provinsi,
          b.wilayah.kabupatenKota,
          b.wilayah.kecamatan,
          b.pribadi.tanggalLahir,
          b.pribadi.jenisKelamin,
          b.pribadi.umur,
          b.anomali.join("; "),
        ]
          .map((x) => `"${String(x).replace(/"/g, '""')}"`)
          .join(","),
      ),
    ].join("\n");
    navigator.clipboard?.writeText(csv);
    toast({ title: "Tabel CSV tersalin", description: "Tempel di Google Sheets / Excel." });
  };

  return (
    <div className="space-y-4">
      <p className="rounded-xl bg-secondary/50 px-3.5 py-2.5 text-[10.5px] leading-relaxed text-muted-foreground">
        <b>Validasi massal versi legal:</b> tempel banyak NIK (satu per baris atau dipisah koma, maks 100) — sistem membaca
        struktur angkanya (wilayah + tanggal lahir + gender) dan menandai anomali format. Nama pemilik <b>hanya bisa
        diverifikasi Dukcapil</b> — tidak diambil dari sumber mana pun di sini.
      </p>

      <textarea
        value={daftar}
        onChange={(e) => setDaftar(e.target.value.slice(0, 8000))}
        rows={5}
        placeholder={"3325010101970001\n3174060503900002\n5271011234567003"}
        className="w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 font-mono text-xs outline-none focus:border-blue-500/50"
      />

      <button
        onClick={proses}
        disabled={busy || !daftar.trim()}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 px-4 py-3 text-xs font-extrabold text-white transition-transform active:scale-95 disabled:opacity-60"
      >
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ListChecks className="h-4 w-4" />}
        {busy ? "Memeriksa…" : "Periksa Semua"}
      </button>

      {error && !busy && <EmptyState icon={<XCircle className="h-8 w-8" />} title="Gagal" desc={error} />}

      <AnimatePresence>
        {baris && ringkas && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-3">
            <div className="grid grid-cols-4 gap-2">
              {[
                { label: "Total", nilai: ringkas.total, warna: "text-foreground" },
                { label: "Valid", nilai: ringkas.valid, warna: "text-emerald-400" },
                { label: "Tidak valid", nilai: ringkas.tidakValid, warna: "text-red-400" },
                { label: "Anomali", nilai: ringkas.anomali, warna: "text-amber-400" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl bg-secondary/50 px-2 py-2.5 text-center">
                  <p className={`text-lg font-extrabold ${s.warna}`}>{s.nilai}</p>
                  <p className="text-[9px] font-bold uppercase tracking-wide text-muted-foreground">{s.label}</p>
                </div>
              ))}
            </div>

            <button onClick={salinCsv} className="flex w-full items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-2.5 text-xs font-bold">
              <FileSpreadsheet className="h-4 w-4 text-blue-500" /> Salin sebagai CSV (untuk Sheets/Excel)
            </button>

            <div className="max-h-[420px] overflow-y-auto rounded-2xl glass">
              <table className="w-full text-left text-[11px]">
                <thead className="sticky top-0 bg-secondary/90 backdrop-blur-sm">
                  <tr className="text-[9.5px] uppercase tracking-wide text-muted-foreground">
                    <th className="px-3 py-2.5 font-bold">NIK</th>
                    <th className="px-2 py-2.5 font-bold">Status</th>
                    <th className="px-2 py-2.5 font-bold">Wilayah</th>
                    <th className="px-2 py-2.5 font-bold">Lahir</th>
                  </tr>
                </thead>
                <tbody>
                  {baris.map((b, i) => (
                    <tr key={i} className="border-t border-border/30 align-top">
                      <td className="px-3 py-2.5 font-mono">{b.nik}</td>
                      <td className="px-2 py-2.5">
                        {b.valid ? (
                          <span className="rounded-md bg-emerald-500/15 px-1.5 py-0.5 text-[9px] font-extrabold text-emerald-300">VALID</span>
                        ) : (
                          <span className="rounded-md bg-red-500/15 px-1.5 py-0.5 text-[9px] font-extrabold text-red-300">SALAH</span>
                        )}
                        {b.anomali.length > 0 && (
                          <p className="mt-1 max-w-[160px] text-[9px] leading-tight text-amber-300">{b.anomali[0]}{b.anomali.length > 1 ? ` +${b.anomali.length - 1}` : ""}</p>
                        )}
                      </td>
                      <td className="px-2 py-2.5 text-muted-foreground">
                        {b.wilayah.provinsi}
                        <span className="block text-[9px] opacity-70">{b.wilayah.kabupatenKota} • {b.wilayah.kecamatan}</span>
                      </td>
                      <td className="px-2 py-2.5 text-muted-foreground">
                        {b.pribadi.tanggalLahir}
                        <span className="block text-[9px] opacity-70">{b.pribadi.jenisKelamin} • {b.pribadi.umur}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
