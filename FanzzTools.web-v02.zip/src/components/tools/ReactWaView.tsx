"use client";

import { useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Heart, Zap, Loader2, StopCircle, CheckCircle2, XCircle, Timer,
  ThumbsUp, ShieldCheck, Plus, Minus, Info,
} from "lucide-react";

/** Kumpulan emoji yang umum dipakai buat react — sesuai permintaan "bisa pilih emoji apa aja". */
const EMOJIS = [
  "❤️", "🔥", "😂", "👍", "😍", "😮", "😢", "🙏", "👏", "💯",
  "🎉", "🥰", "🤔", "😱", "🤯", "✨", "💙", "💚", "💛", "🧡",
  "💜", "🖤", "🤍", "🫡", "😎", "🥳", "🚀", "⭐", "🎁", "⚡",
  "🌈", "🌸", "🍀", "🎯", "💎", "👑", "❗", "✅", "❌", "💀",
];

const QUICK_AMOUNTS = [5, 10, 25, 50];

interface LogItem {
  n: number;
  ok: boolean;
  emoji: string;
}

type ReactResult =
  | { kind: "ok"; reaction?: string }
  | { kind: "wait"; waitSec: number; error: string }
  | { kind: "fail"; error: string };

export default function ReactWaView() {
  const [link, setLink] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [jumlah, setJumlah] = useState(10);
  const [running, setRunning] = useState(false);
  const [progress, setProgress] = useState({ done: 0, ok: 0, fail: 0 });
  const [logs, setLogs] = useState<LogItem[]>([]);
  /** info jeda server yang sedang berjalan (countdown) */
  const [waitInfo, setWaitInfo] = useState<{ sec: number; label: string } | null>(null);
  const stopRef = useRef(false);
  const { toast } = useToast();

  const toggleEmoji = (e: string) => {
    setPicked((p) => {
      if (p.includes(e)) return p.filter((x) => x !== e);
      if (p.length >= 2) return [p[1], e]; // geser — max 2 emoji gabungan
      return [...p, e];
    });
  };

  const reactOnce = async (): Promise<ReactResult> => {
    try {
      const r = await fetch("/api/react-wa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "react", url: link.trim(), reactions: picked }),
      });
      const d = await r.json().catch(() => null);
      if (d?.ok) return { kind: "ok", reaction: d.reaction };
      if (d?.retry && Number(d.waitSec) > 0) return { kind: "wait", waitSec: Number(d.waitSec), error: d.error };
      return { kind: "fail", error: String(d?.error || "React gagal") };
    } catch {
      return { kind: "fail", error: "Koneksi ke server react gagal" };
    }
  };

  /** Tunggu N detik dengan countdown jujur di UI; bisa dibatalkan lewat stopRef. */
  const waitWithCountdown = async (sec: number, reason: string) => {
    for (let s = sec; s > 0; s--) {
      if (stopRef.current) return;
      setWaitInfo({ sec: s, label: reason });
      await new Promise((r2) => setTimeout(r2, 1000));
    }
    setWaitInfo(null);
  };

  const start = async () => {
    const u = link.trim();
    if (!u.includes("whatsapp.com")) {
      toast({ title: "Tautan belum tepat", description: "Silakan tempel tautan pesan saluran WhatsApp yang valid." });
      return;
    }
    if (picked.length === 0) {
      toast({ title: "Pilih emoji terlebih dahulu", description: "Pilih minimal 1 emoji (maksimal 2 gabungan)." });
      return;
    }
    if (running) return;

    setRunning(true);
    stopRef.current = false;
    setProgress({ done: 0, ok: 0, fail: 0 });
    setLogs([]);
    setWaitInfo(null);

    let okCount = 0;
    let failCount = 0;
    let lastError = "";

    try {
      let i = 0;
      let consecutiveFails = 0;

      while (i < jumlah) {
        if (stopRef.current) break;

        const res = await reactOnce();

        if (res.kind === "wait") {
          // 429 dari upstream: postingan yang sama baru saja masuk antrean.
          // Auto-tunggu sisa detik yang diberitahu server, lalu ulangi react yang sama.
          await waitWithCountdown(res.waitSec, "Jeda server react (antrean postingan yang sama)");
          continue; // ulangi react ke-i, jangan dihitung gagal
        }

        if (res.kind === "ok") {
          okCount++;
          consecutiveFails = 0;
          setLogs((l) => [{ n: i + 1, ok: true, emoji: picked.join("") }, ...l].slice(0, 40));
        } else {
          failCount++;
          consecutiveFails++;
          lastError = res.error;
          setLogs((l) => [{ n: i + 1, ok: false, emoji: picked.join("") }, ...l].slice(0, 40));
          // 3x gagal berurutan (bukan jeda) → berhenti, jangan paksakan
          if (consecutiveFails >= 3) {
            toast({
              title: "React dihentikan",
              description: `3x gagal berurutan: ${lastError}`,
            });
            break;
          }
        }

        i++;
        setProgress({ done: i, ok: okCount, fail: failCount });

        // jeda antar-react agar tidak menge-spam server (kecil, karena rate-limit
        // per postingan yang sama sudah diatur server + auto-tunggu di atas)
        if (i < jumlah) await new Promise((r2) => setTimeout(r2, 900));
      }

      // laporan status yang JUJUR: bila semua gagal, jangan klaim berhasil
      if (okCount === 0) {
        toast({
          title: "Tidak ada react yang terkirim",
          description: `${lastError || "Semua percobaan gagal"} — reaksi tidak sampai ke pesan. Coba lagi nanti.`,
        });
      } else {
        toast({
          title: stopRef.current ? "React dihentikan" : "React selesai",
          description: `${okCount} react masuk antrean${failCount > 0 ? `, ${failCount} gagal` : ""} ke pesan saluran tersebut.`,
        });
      }
    } catch (e) {
      toast({
        title: "React gagal",
        description: e instanceof Error ? e.message : "Server react bermasalah — coba lagi nanti.",
      });
    } finally {
      setRunning(false);
      setWaitInfo(null);
    }
  };

  const stop = () => {
    stopRef.current = true;
    setWaitInfo(null);
  };

  return (
    <div>
      <ToolHeader icon={<Heart className="h-5.5 w-5.5" />} title="React Saluran WA" subtitle="reactChWa • emoji ke pesan saluran WhatsApp" accent="red" />

      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-5">
        {/* link pesan */}
        <label className="mb-1.5 block text-xs font-bold text-muted-foreground">Tautan pesan saluran WA</label>
        <Input
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="https://whatsapp.com/channel/.../pesan"
          className="rounded-xl border-border/60 bg-secondary/50 py-4 text-sm"
        />
        <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground">
          Cara pakai: buka saluran WA → tekan-tahan / ketuk titik tiga pada pesan → <b>Salin tautan</b> → tempel di sini.
        </p>

        {/* pilih emoji */}
        <label className="mb-2 mt-4 block text-xs font-bold text-muted-foreground">
          Pilih emoji ({picked.length}/2 gabungan)
        </label>
        <div className="grid grid-cols-8 gap-1.5 sm:grid-cols-10">
          {EMOJIS.map((e, i) => {
            const idx = picked.indexOf(e);
            const active = idx >= 0;
            return (
              <button
                key={e + i}
                onClick={() => toggleEmoji(e)}
                aria-label={`Pilih emoji ${e}`}
                className={`relative flex aspect-square items-center justify-center rounded-xl text-lg transition-all active:scale-90 ${
                  active ? "bg-gradient-to-br from-red-500/40 to-blue-700/40 ring-2 ring-red-400" : "bg-secondary/60 hover:bg-secondary"
                }`}
              >
                {e}
                {active && (
                  <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-extrabold text-white">
                    {idx + 1}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* combo preview */}
        {picked.length > 0 && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mt-3 flex items-center gap-2.5 rounded-2xl bg-red-500/10 px-4 py-3 ring-1 ring-red-400/30">
            <span className="text-2xl">{picked.join("")}</span>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-bold text-red-300">Kombinasi react Anda</p>
              <p className="text-[10px] text-muted-foreground">Maksimal 2 emoji digabung per react</p>
            </div>
            <button onClick={() => setPicked([])} aria-label="Hapus pilihan emoji" className="rounded-lg p-1.5 text-muted-foreground hover:text-foreground">
              <XCircle className="h-4 w-4" />
            </button>
          </motion.div>
        )}

        {/* jumlah */}
        <div className="mt-4">
          <label className="mb-1.5 block text-xs font-bold text-muted-foreground">Jumlah react: <span className="text-red-400">{jumlah}</span></label>
          <div className="flex items-center gap-2">
            <button onClick={() => setJumlah((j) => Math.max(1, j - 5))} aria-label="Kurangi jumlah" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary/70 transition-transform active:scale-90">
              <Minus className="h-4 w-4" />
            </button>
            <div className="relative h-10 flex-1">
              <Input
                type="number"
                value={jumlah}
                onChange={(e) => setJumlah(Math.max(1, Math.min(500, Number(e.target.value) || 1)))}
                className="h-10 rounded-xl border-border/60 bg-secondary/50 text-center text-sm font-bold"
              />
            </div>
            <button onClick={() => setJumlah((j) => Math.min(500, j + 5))} aria-label="Tambah jumlah" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-secondary/70 transition-transform active:scale-90">
              <Plus className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {QUICK_AMOUNTS.map((a) => (
              <button
                key={a}
                onClick={() => setJumlah(a)}
                className={`rounded-full px-3 py-1.5 text-[11px] font-extrabold transition-all ${
                  jumlah === a ? "bg-red-500 text-white shadow-lg shadow-red-500/25" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
                }`}
              >
                {a}x
              </button>
            ))}
            <span className="self-center text-[10px] text-muted-foreground">hingga 500 — dapat ditambah terus</span>
          </div>
        </div>

        {/* tombol mulai/stop */}
        {!running ? (
          <Button
            onClick={start}
            disabled={!link.trim() || picked.length === 0}
            className="mt-5 w-full rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-5 text-sm font-bold shadow-lg shadow-red-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
          >
            <Zap className="mr-2 h-4.5 w-4.5" /> Kirim {jumlah}x {picked.join("")}
          </Button>
        ) : (
          <Button
            onClick={stop}
            variant="destructive"
            className="mt-5 w-full rounded-xl py-5 text-sm font-bold"
          >
            <StopCircle className="mr-2 h-4.5 w-4.5" /> Stop ({progress.done}/{jumlah})
          </Button>
        )}
      </motion.div>

      {/* progress live */}
      <AnimatePresence>
        {(running || progress.done > 0) && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4 rounded-3xl glass p-5">
            <div className="mb-3 flex items-center justify-between text-xs font-bold">
              <span className="flex items-center gap-1.5">
                {running ? <Loader2 className="h-3.5 w-3.5 animate-spin text-red-400" /> : <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />}
                {running ? "Mengirim react..." : "Selesai"}
              </span>
              <span className="text-muted-foreground">
                <span className="text-emerald-400">{progress.ok} sukses</span>
                {progress.fail > 0 && <> • <span className="text-red-400">{progress.fail} gagal</span></>}
              </span>
            </div>
            <div className="h-2.5 overflow-hidden rounded-full bg-secondary">
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-red-500 to-blue-700"
                animate={{ width: `${jumlah ? Math.min(100, (progress.done / jumlah) * 100) : 0}%` }}
                transition={{ ease: "easeOut", duration: 0.3 }}
              />
            </div>
            <p className="mt-1.5 text-center text-[10px] font-bold text-muted-foreground">{progress.done}/{jumlah} react terkirim</p>

            {/* status jeda server (countdown jujur — bukan progress palsu) */}
            {waitInfo && (
              <div className="mt-3 flex items-center gap-2.5 rounded-xl bg-amber-500/10 px-3 py-2.5 ring-1 ring-amber-400/30">
                <Timer className="h-4 w-4 shrink-0 animate-pulse text-amber-400" />
                <div className="min-w-0 flex-1">
                  <p className="text-[11px] font-bold text-amber-300">
                    Menunggu {waitInfo.sec}s — {waitInfo.label}
                  </p>
                  <p className="text-[10px] text-amber-200/70">Server react membatasi antrean per postingan yang sama (±15 detik)</p>
                </div>
              </div>
            )}

            {/* log emoji */}
            {logs.length > 0 && (
              <div className="mt-3 max-h-32 space-y-1 overflow-y-auto">
                {logs.map((l, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} className="flex items-center gap-2 rounded-lg bg-secondary/40 px-2.5 py-1.5">
                    <span className="text-sm">{l.emoji}</span>
                    <span className="text-[10px] font-bold text-muted-foreground">react #{l.n}</span>
                    {l.ok ? <CheckCircle2 className="ml-auto h-3 w-3 text-emerald-400" /> : <XCircle className="ml-auto h-3 w-3 text-red-400" />}
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* info */}
      <div className="mt-4 flex items-start gap-2.5 rounded-2xl glass p-4 text-[11px] leading-relaxed text-muted-foreground">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
        <div>
          <p className="mb-1 font-bold text-foreground">Catatan reactChWa:</p>
          <p>• Maksimal <b>2 emoji digabung</b> per react</p>
          <p>• Server react membatasi antrean <b>±15 detik per postingan yang sama</b> — FanzzTools menunggu otomatis (lihat countdown)</p>
          <p>• Jumlah bebas — dapat <b>100 ke atas</b>, tinggal tambahkan di penghitung</p>
          <p>• Status laporan jujur: bila tidak ada react yang masuk antrean, sistem memberi tahu secara jelas</p>
        </div>
      </div>
    </div>
  );
}
