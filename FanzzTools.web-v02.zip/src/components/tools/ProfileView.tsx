"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ToolHeader } from "@/components/tools/shared";
import { useApp, getWatchHistory, getFavSongs, clearVault } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import {
  User, LogOut, Film, Heart, Bot, Palette, Pencil, Check, ShieldCheck, Clock,
  Camera, Loader2,
} from "lucide-react";

/** V2 UpdSec: kompres foto di client jadi data URL kecil (maks 256px). */
async function kompresAvatar(file: File): Promise<string> {
  const img = await new Promise<HTMLImageElement>((ok, no) => {
    const i = new Image();
    i.onload = () => ok(i);
    i.onerror = no;
    i.src = URL.createObjectURL(file);
  });
  const ukuran = 256;
  const canvas = document.createElement("canvas");
  canvas.width = ukuran;
  canvas.height = ukuran;
  const ctx = canvas.getContext("2d")!;
  const s = Math.max(ukuran / img.width, ukuran / img.height);
  const dw = img.width * s;
  const dh = img.height * s;
  ctx.drawImage(img, (ukuran - dw) / 2, (ukuran - dh) / 2, dw, dh);
  URL.revokeObjectURL(img.src);
  return canvas.toDataURL("image/jpeg", 0.85);
}

export default function ProfileView() {
  const { user, setPhase, setUser, stopSong, setView } = useApp();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.username || "");
  const [stats, setStats] = useState({ watched: 0, songs: 0 });
  /** ID publik FanzzTools (LT-XXXXXX) — V0.01 #15 */
  const [fanzzId, setFanzzId] = useState<string>("");
  const [idCopied, setIdCopied] = useState(false);
  /** V2 UpdSec: foto profil — upload, tampil di chat/story/sidebar */
  const [avatar, setAvatar] = useState<string | null>(null);
  const [avatarBusy, setAvatarBusy] = useState(false);
  const { toast } = useToast();

  const simpanAvatar = async (file: File | undefined) => {
    if (!file) return;
    if (!/^image\/(png|jpe?g|webp)$/i.test(file.type)) {
      toast({ title: "Format tidak didukung", description: "PNG / JPG / WebP saja.", variant: "destructive" });
      return;
    }
    setAvatarBusy(true);
    try {
      const dataUrl = await kompresAvatar(file);
      const r = await fetch("/api/social/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatar: dataUrl }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Server menolak foto (coba ukuran lebih kecil)");
      setAvatar(d.profile?.avatar || dataUrl);
      window.dispatchEvent(new Event("fanzz-avatar-updated"));
      toast({ title: "Foto profil diperbarui! 📸", description: "Langsung terlihat di chat, story, dan sidebar." });
    } catch {
      toast({ title: "Gagal mengunggah foto", description: "Coba foto lain (maks ±2 MB sebelum kompres).", variant: "destructive" });
    } finally {
      setAvatarBusy(false);
    }
  };

  const hapusAvatar = async () => {
    setAvatarBusy(true);
    try {
      await fetch("/api/social/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatar: null }),
      });
      setAvatar(null);
      window.dispatchEvent(new Event("fanzz-avatar-updated"));
      toast({ title: "Foto profil dihapus" });
    } catch {
      toast({ title: "Gagal menghapus", variant: "destructive" });
    } finally {
      setAvatarBusy(false);
    }
  };

  useEffect(() => {
    queueMicrotask(() =>
      setStats({
        watched: getWatchHistory().length,
        songs: getFavSongs().length,
      })
    );
  }, []);

  // ambil ID publik + avatar dari profil sosial dalam SATU fetch (fix: avatar dulunya tidak pernah dimuat di halaman profil)
  useEffect(() => {
    fetch("/api/social/profile")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.ok) {
          if (d.profile?.fanzzId) setFanzzId(d.profile.fanzzId);
          setAvatar(d.profile?.avatar || null);
        }
      })
      .catch(() => {});
  }, []);

  const saveName = () => {
    // nama display disimpan di cookie session via update sederhana (client-side cache)
    if (name.trim().length >= 3 && name.trim().length <= 24) {
      const updated = { ...user!, username: name.trim() };
      setUser(updated);
      try {
        const v = JSON.parse(localStorage.getItem("fanzz_vault_v2") || "null");
        if (v) {
          localStorage.setItem("fanzz_vault_v2", JSON.stringify({ ...v, username: name.trim() }));
        }
        localStorage.setItem("fanzz_display_name", name.trim());
      } catch {
        /* ignore */
      }
    }
    setEditing(false);
    toast({ title: "Nama tampilan di-update! ✨" });
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
    stopSong();
    clearVault();
    setUser(null);
    setPhase("auth");
    toast({ title: "Sampai jumpa! 👋" });
  };

  const initial = (user?.username || "L").trim().charAt(0).toUpperCase();

  return (
    <div>
      <ToolHeader icon={<User className="h-5.5 w-5.5" />} title="Profil" subtitle="Akun & pengaturan lo" />

      {/* kartu profil */}
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass relative overflow-hidden rounded-3xl p-6 text-center">
        <div className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full bg-red-500/20 blur-3xl" />
        {/* V2 UpdSec: foto profil — bisa diganti, terlihat user lain di chat/story */}
        <div className="relative mx-auto h-24 w-24">
          {avatar ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={avatar} alt="foto profil" className="h-24 w-24 rounded-full border-2 border-red-400/50 object-cover shadow-lg" />
          ) : (
            <>
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-red-500 to-red-700 animate-pulse-glow" />
              <span className="absolute inset-0 flex items-center justify-center rounded-full text-3xl font-extrabold text-white">{initial}</span>
            </>
          )}
          {avatarBusy && (
            <span className="absolute inset-0 flex items-center justify-center rounded-full bg-black/60">
              <Loader2 className="h-6 w-6 animate-spin text-white" />
            </span>
          )}
          <label
            className="absolute -bottom-1 -right-1 flex h-9 w-9 cursor-pointer items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg ring-2 ring-background transition-transform active:scale-90"
            title="Ganti foto profil"
          >
            <Camera className="h-4 w-4" />
            <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => simpanAvatar(e.target.files?.[0])} />
          </label>
        </div>
        {avatar && (
          <button onClick={hapusAvatar} disabled={avatarBusy} className="mt-2 rounded-full bg-red-500/10 px-3 py-1.5 text-[10px] font-bold text-red-300">
            Hapus foto
          </button>
        )}
        <div className="relative mt-4">
          {editing ? (
            <div className="mx-auto flex max-w-[240px] items-center gap-2">
              <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={24} className="rounded-xl bg-secondary/50 text-center text-base font-bold" />
              <Button size="icon" onClick={saveName} className="h-9 w-9 shrink-0 rounded-xl bg-emerald-500 hover:bg-emerald-600">
                <Check className="h-4 w-4" />
              </Button>
            </div>
          ) : (
            <button onClick={() => setEditing(true)} className="group inline-flex items-center gap-2">
              <h2 className="text-xl font-extrabold">{user?.username}</h2>
              <Pencil className="h-3.5 w-3.5 text-muted-foreground transition-colors group-hover:text-red-400" />
            </button>
          )}
          <p className="mt-1 flex items-center justify-center gap-1.5 text-xs text-muted-foreground">
            {user?.email}
          </p>
          {/* V0.01 (#15): ID publik FanzzTools — bisa dicari di chat */}
          {fanzzId && (
            <button
              onClick={() => {
                try {
                  navigator.clipboard.writeText(fanzzId);
                  setIdCopied(true);
                  setTimeout(() => setIdCopied(false), 1500);
                  toast({ title: "ID tersalin", description: `${fanzzId} — bagikan supaya bisa dicari di chat.` });
                } catch {
                  /* abaikan */
                }
              }}
              className="mx-auto mt-2 flex items-center gap-1.5 rounded-full bg-red-500/15 px-3 py-1.5 font-mono text-[11px] font-bold text-red-300 transition-transform active:scale-95"
              title="Ketuk untuk menyalin ID Anda"
            >
              ID: {fanzzId}
              <Check className={`h-3 w-3 transition-opacity ${idCopied ? "opacity-100" : "opacity-0"}`} />
            </button>
          )}
        </div>

        {/* stats */}
        <div className="relative mt-5 grid grid-cols-3 gap-2.5">
          {[
            { icon: Film, label: "Ditonton", value: stats.watched, action: () => setView("film") },
            { icon: Heart, label: "Lagu Suka", value: stats.songs, action: () => setView("music") },
            { icon: Bot, label: "Tools", value: 7, action: () => setView("home") },
          ].map((s) => (
            <button key={s.label} onClick={s.action} className="rounded-2xl bg-secondary/50 p-3 transition-colors hover:bg-secondary">
              <s.icon className="mx-auto h-4 w-4 text-red-400" />
              <p className="mt-1.5 text-lg font-extrabold">{s.value}</p>
              <p className="text-[10px] font-semibold text-muted-foreground">{s.label}</p>
            </button>
          ))}
        </div>
      </motion.div>

      {/* info akun */}
      <section className="mt-4 space-y-2.5">
        <h3 className="px-1 text-sm font-bold">Info Akun</h3>
        <div className="glass flex items-center gap-3 rounded-2xl p-4">
          <ShieldCheck className="h-5 w-5 shrink-0 text-emerald-400" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold">Session Aman</p>
            <p className="text-[11px] text-muted-foreground">Login lo terenkripsi via cookie httpOnly — bukan cuma localStorage</p>
          </div>
        </div>
        <div className="glass flex items-center gap-3 rounded-2xl p-4">
          <Palette className="h-5 w-5 shrink-0 text-red-400" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold">Tema FanzzTools</p>
            <p className="text-[11px] text-muted-foreground">Gelap • Terang • Charcoal-Blood (gagak) — ketuk ikon bulan/matahari di atas</p>
          </div>
        </div>
        <div className="glass flex items-center gap-3 rounded-2xl p-4">
          <Clock className="h-5 w-5 shrink-0 text-cyan-400" />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-bold">Login otomatis 30 hari</p>
            <p className="text-[11px] text-muted-foreground">Session lo awet sebulan, nggak perlu login berkali-kali</p>
          </div>
        </div>
      </section>

      {/* logout */}
      <Button
        onClick={logout}
        variant="secondary"
        className="mt-5 w-full rounded-2xl glass py-4.5 text-sm font-bold text-red-300 transition-colors hover:bg-red-500/10"
      >
        <LogOut className="mr-2 h-4.5 w-4.5" /> Keluar (Logout)
      </Button>
    </div>
  );
}
