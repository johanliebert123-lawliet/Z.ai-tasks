"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import NativePlayer from "@/components/NativePlayer";
import {
  Flame, Search, Loader2, ArrowLeft, Play, ShieldAlert, Lock, X, ExternalLink, Clock3, Maximize, Download as DownloadIcon, Server,
} from "lucide-react";

interface NkpItem {
  title: string;
  url: string;
  thumbnail?: string | null;
}

interface NkpDetail {
  url: string;
  title: string;
  thumbnail?: string | null;
  info: string[];
  genres: string[];
  synopsis?: string | null;
  streamLinks: Array<{ name: string; url: string }>;
  downloadLinks?: Array<{ text: string; url: string }>;
  m3u8: string | null;
  /** V0.01 (#5): daftar m3u8 dari dixzz-neko-api */
  m3u8s?: string[];
  mp4: string | null;
  source?: string;
}

const LS_AGE = "fanzz_nkp_21_ok";
/** Sandbox ketat: popup & window.open diblokir total supaya iklan spam tidak dapat muncul. */
const PLAYER_SANDBOX = "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

/** Gerbang usia 21+ — wajib dikonfirmasi tiap sesi baru (simpen flag per 7 hari). */
function AgeGate({ onPass }: { onPass: () => void }) {
  const [checked, setChecked] = useState(false);
  const [year, setYear] = useState("");
  const [err, setErr] = useState("");

  const submit = () => {
    const y = parseInt(year, 10);
    if (!y || y < 1900 || y > 2020) {
      setErr("Isi tahun lahir Anda dengan benar (1900–2020)");
      return;
    }
    const age = new Date().getFullYear() - y;
    if (age < 21) {
      setErr(`Usia Anda ${age} tahun — fitur ini khusus 21+. Silakan kembali saat cukup umur.`);
      return;
    }
    try {
      localStorage.setItem(LS_AGE, String(Date.now()));
    } catch {
      /* ignore */
    }
    onPass();
  };

  return (
    <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }}>
      <ToolHeader icon={<Flame className="h-5.5 w-5.5" />} title="Nekopoi 21+" subtitle="Konten dewasa — gerbang verifikasi usia" accent="rose" />

      <div className="relative overflow-hidden rounded-3xl glass p-6 text-center">
        <motion.div
          animate={{ scale: [1, 1.06, 1] }}
          transition={{ repeat: Infinity, duration: 2.6, ease: "easeInOut" }}
          className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-rose-500 to-red-600 shadow-xl shadow-rose-500/25"
        >
          <Lock className="h-8 w-8 text-white" />
        </motion.div>
        <p className="text-lg font-extrabold">Verifikasi Usia Diperlukan</p>
        <p className="mx-auto mt-2 max-w-sm text-xs leading-relaxed text-muted-foreground">
          Fitur ini berisi konten dewasa (hentai / 18+) yang hanya boleh diakses penonton berusia
          <b className="text-rose-400"> 21 tahun ke atas</b>. Dengan melanjutkan, Anda menyatakan bahwa Anda
          cukup umur dan melihat konten semacam ini sesuai hukum yang berlaku di wilayah Anda.
        </p>

        <div className="mx-auto mt-5 max-w-[220px] text-left">
          <label className="mb-1.5 block text-xs font-bold text-muted-foreground">Tahun lahir Anda</label>
          <input
            value={year}
            onChange={(e) => { setYear(e.target.value.replace(/\D/g, "").slice(0, 4)); setErr(""); }}
            inputMode="numeric"
            placeholder="misal: 2003"
            className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3.5 py-3 text-center text-lg font-extrabold tracking-widest outline-none focus:border-rose-400/60"
            onKeyDown={(e) => e.key === "Enter" && submit()}
          />
        </div>

        <label className="mx-auto mt-3.5 flex max-w-xs cursor-pointer items-start gap-2.5 text-left text-[11px] leading-relaxed text-muted-foreground">
          <input type="checkbox" checked={checked} onChange={(e) => setChecked(e.target.checked)} className="mt-0.5 h-4 w-4 shrink-0 accent-rose-500" />
          <span>Saya sudah berusia 21+ dan memahami bahwa konten di sini dewasa, serta saya mengaksesnya atas tanggung jawab sendiri.</span>
        </label>

        {err && (
          <p className="mx-auto mt-3 max-w-xs rounded-xl bg-red-500/10 px-3.5 py-2.5 text-[11px] font-semibold text-red-300">
            {err}
          </p>
        )}

        <button
          onClick={submit}
          disabled={!checked || year.length < 4}
          className="mt-5 w-full rounded-xl bg-gradient-to-r from-rose-500 to-red-600 py-4 text-sm font-extrabold text-white shadow-lg shadow-rose-500/25 transition-all active:scale-[0.98] disabled:opacity-40"
        >
          Saya 21+ — Buka Fitur
        </button>

        <p className="mt-3 flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground">
          <ShieldAlert className="h-3 w-3" /> Pilihan tersimpan 7 hari di perangkat ini
        </p>
      </div>
    </motion.div>
  );
}

export default function NekopoiView() {
  const [gateOk, setGateOk] = useState(false);
  const [gateChecked, setGateChecked] = useState(false);
  const [items, setItems] = useState<NkpItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<NkpDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [playerUrl, setPlayerUrl] = useState<string | null>(null);
  /** V2-new: stream native hasil resolve (m3u8/mp4 via proxy) */
  const [nativeSrc, setNativeSrc] = useState<string | null>(null);
  const [nativeName, setNativeName] = useState<string>("");
  const [resolving, setResolving] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const playerWrapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  /** Layar penuh + kunci orientasi landscape (Android/Chrome). */
  const goFullscreenLandscape = async () => {
    const el = playerWrapRef.current;
    if (!el) return;
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return;
      }
      await el.requestFullscreen();
      const orientation = screen.orientation as (ScreenOrientation & { lock?: (o: string) => Promise<void> }) | undefined;
      await orientation?.lock?.("landscape").catch(() => {});
    } catch {
      toast({
        title: "Layar penuh tidak dapat dibuka",
        description: "Browser memblokir layar penuh — silakan gunakan tombol layar penuh di dalam pemutar.",
      });
    }
  };

  // cek gerbang usia yang tersimpan (berlaku 7 hari)
  useEffect(() => {
    try {
      const t = Number(localStorage.getItem(LS_AGE) || 0);
      if (t && Date.now() - t < 7 * 24 * 3600 * 1000) setGateOk(true);
    } catch {
      /* ignore */
    }
    setGateChecked(true);
  }, []);

  const loadLatest = useCallback(async () => {
    setItems(null);
    try {
      const r = await fetch("/api/nekopoi?latest=1");
      const d = await r.json();
      setItems(d?.ok ? (d.items || []) : []);
    } catch {
      setItems([]);
    }
  }, []);

  useEffect(() => {
    if (gateOk && items === null) loadLatest();
  }, [gateOk, items, loadLatest]);

  const doSearch = (q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      loadLatest();
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/nekopoi?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        setItems(d?.ok ? (d.items || []) : []);
      } catch {
        setItems([]);
      } finally {
        setSearching(false);
      }
    }, 500);
  };

  const openDetail = async (url: string) => {
    setDetailLoading(true);
    setDetail(null);
    setPlayerUrl(null);
    setNativeSrc(null);
    try {
      const r = await fetch(`/api/nekopoi?url=${encodeURIComponent(url)}`);
      const d = await r.json();
      if (d?.ok) {
        setDetail(d);
        // V0.01 (#7): catat riwayat nekopoi
        pushHistory("nekopoi", {
          id: url,
          title: d.title || url,
          poster: d.thumbnail || null,
          extra: { source: d.source },
        });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal membuka halaman", description: d?.error || "Silakan coba lagi." });
      }
    } catch {
      toast({ title: "Gagal membuka halaman", description: "Koneksi bermasalah." });
    } finally {
      setDetailLoading(false);
    }
  };

  /** V2-new: putar URL m3u8/mp4 LANGSUNG di pemutar native (via proxy + Referer nekopoi). */
  const playNative = (name: string, url: string, kind: "hls" | "mp4" = "hls") => {
    setNativeName(name);
    setPlayerUrl(null);
    const p = new URLSearchParams({ url });
    // Referer asal — sebagian CDN (streamruby family) menolak tanpa ini
    if (/nekopoi/i.test(detail?.url || "")) p.set("referer", String(detail?.url));
    else p.set("referer", "https://nekopoi.care/");
    setNativeSrc(`/api/stream/proxy?${p.toString()}${kind === "mp4" ? "" : ""}`);
  };

  /** V2.11 (#5b): pilih mirror — coba resolve jadi stream native. Mirror yang
   *  terproteksi Cloudflare (Playmogo dll. — server tidak bisa membacanya)
   *  OTOMATIS beralih ke mirror lain yang bisa dibaca, jadi video tetap jalan
   *  walau user menekan Playmogo. Bila semua mirror terkunci, pemutar embed
   *  ditampilkan (browser asli melewati verifikasi Cloudflare sendiri). */
  const playMirror = async (s: { name: string; url: string }) => {
    setNativeName(s.name);
    setNativeSrc(null);
    setResolving(true);
    setPlayerUrl(null);
    const referer = /nekopoi/i.test(detail?.url || "") ? String(detail?.url) : "https://nekopoi.care/";
    const tryResolve = async (url: string): Promise<string | null> => {
      try {
        const r = await fetch(`/api/nekopoi?resolve=${encodeURIComponent(url)}&referer=${encodeURIComponent(referer)}`);
        const d = await r.json();
        if (d?.ok && d.stream?.playUrl) return d.stream.playUrl as string;
      } catch {
        /* mirror ini tidak terbaca */
      }
      return null;
    };

    // 1) mirror yang diklik
    let playUrl = await tryResolve(s.url);
    if (playUrl) {
      setNativeSrc(playUrl);
      setResolving(false);
      return;
    }

    // 2) mirror terproteksi → beralih otomatis ke mirror lain yang bisa dibaca
    const others = (detail?.streamLinks || []).filter((x) => x.url !== s.url);
    for (const alt of others) {
      playUrl = await tryResolve(alt.url);
      if (playUrl) {
        setNativeName(alt.name);
        setNativeSrc(playUrl);
        setResolving(false);
        toast({
          title: `Server ${s.name} sedang terproteksi Cloudflare`,
          description: `Otomatis memutar lewat server ${alt.name} yang dapat dibaca — video tetap jalan.`,
        });
        return;
      }
    }

    // 3) semua mirror terkunci → pemutar embed (verifikasi CF di browser, ±5 detik)
    setPlayerUrl(s.url);
    setResolving(false);
    toast({
      title: `Server ${s.name} memakai pemutar embed`,
      description: "Proteksi Cloudflare sedang aktif — tunggu beberapa detik di dalam pemutar, atau coba server lain.",
    });
  };

  if (!gateChecked) return null;

  /* ---------- GERBANG USIA ---------- */
  if (!gateOk) {
    return <AgeGate onPass={() => setGateOk(true)} />;
  }

  /* ---------- DETAIL ---------- */
  if (detailLoading) {
    return (
      <div>
        <ToolHeader icon={<Flame className="h-5.5 w-5.5" />} title="Nekopoi 21+" subtitle="Konten dewasa 21+" accent="rose" />
        <div className="space-y-3">
          <div className="h-48 rounded-3xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (detail) {
    return (
      <div>
        <ButtonGhost onBack={() => { setDetail(null); setPlayerUrl(null); setNativeSrc(null); }} />
        <div className="overflow-hidden rounded-3xl glass p-5">
          <div className="flex gap-4">
            {detail.thumbnail && (
              <img src={detail.thumbnail} alt="" className="h-36 w-24 shrink-0 rounded-2xl object-cover shadow-xl" referrerPolicy="no-referrer" />
            )}
            <div className="min-w-0 flex-1">
              <h2 className="clamp-3 text-sm font-extrabold leading-snug">{detail.title}</h2>
              {detail.genres.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {detail.genres.slice(0, 6).map((g) => (
                    <span key={g} className="rounded-full bg-rose-500/15 px-2 py-0.5 text-[10px] font-bold text-rose-300">{g}</span>
                  ))}
                </div>
              )}
              {detail.info.length > 0 && (
                <div className="mt-2 space-y-0.5">
                  {detail.info.slice(0, 5).map((s, i) => (
                    <p key={i} className="text-[10.5px] text-muted-foreground">{s}</p>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* player stream */}
        {(detail.m3u8 || detail.streamLinks.length > 0 || detail.mp4) && (
          <section className="mt-4">
            <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
              <Server className="h-4 w-4 text-rose-400" /> Tonton di sini
            </h3>
            {nativeSrc ? (
              /* V2-new: pemutar native — bebas iklan, bisa diskip / diputar ulang */
              <div className="relative">
                <NativePlayer src={nativeSrc} title={`${detail.title}${nativeName ? ` — server ${nativeName}` : ""}`} poster={detail.thumbnail || undefined} />
                <button
                  onClick={() => { setNativeSrc(null); setPlayerUrl(null); }}
                  className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-xl bg-secondary/70 px-3 py-2.5 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
                >
                  <X className="h-3.5 w-3.5" /> Ganti server
                </button>
              </div>
            ) : playerUrl ? (
              <div ref={playerWrapRef} className="relative overflow-hidden rounded-2xl bg-black shadow-2xl">
                {resolving && (
                  <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 bg-black/70">
                    <Loader2 className="h-7 w-7 animate-spin text-rose-400" />
                    <p className="text-[11px] font-bold text-white/80">Membaca server {nativeName || ""}…</p>
                  </div>
                )}
                {playerUrl.includes(".m3u8") ? (
                  <video src={playerUrl} controls autoPlay playsInline className="aspect-video w-full bg-black" />
                ) : (
                  <iframe
                    src={playerUrl}
                    title="Fanzz Nekopoi Player"
                    className="aspect-video w-full border-0"
                    allow="autoplay; fullscreen; encrypted-media"
                    allowFullScreen
                    referrerPolicy="no-referrer"
                    sandbox={PLAYER_SANDBOX}
                  />
                )}
                {/* tombol layar penuh + landscape (khusus mode embed) */}
                <button
                  onClick={goFullscreenLandscape}
                  className="absolute left-2 top-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
                  title="Layar penuh mode landscape"
                >
                  <Maximize className="h-3.5 w-3.5" />
                  Layar Penuh
                </button>
                <button
                  onClick={() => setPlayerUrl(null)}
                  className="absolute right-2 top-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
                >
                  <X className="h-3.5 w-3.5" />
                  Ganti Mirror
                </button>
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {/* V2-new: server dipilih otomatis — Streampoi/native dulu, lalu mirror lain */}
                {detail.m3u8 && (
                  <button
                    onClick={() => playNative("Streampoi", detail.m3u8!)}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-red-600 px-3.5 py-2.5 text-xs font-bold text-white shadow-lg shadow-rose-500/20 active:scale-95"
                  >
                    <Play className="h-3.5 w-3.5" /> Stream Utama (Native)
                  </button>
                )}
                {detail.mp4 && (
                  <button
                    onClick={() => playNative("MP4", detail.mp4!, "mp4")}
                    className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-rose-500 to-red-600 px-3.5 py-2.5 text-xs font-bold text-white shadow-lg shadow-rose-500/20 active:scale-95"
                  >
                    <Play className="h-3.5 w-3.5" /> MP4 Langsung (Native)
                  </button>
                )}
                {/* V0.01 (#5): daftar m3u8 tambahan — diputar native via proxy */}
                {(detail.m3u8s || []).filter((u) => u !== detail.m3u8).map((u, i) => (
                  <button
                    key={`m3u8-${i}`}
                    onClick={() => playNative(`M3U8 #${i + 2}`, u)}
                    className="flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3.5 py-2.5 text-xs font-bold transition-colors hover:bg-secondary"
                    title="Diputar di pemutar native FanzzTools"
                  >
                    <Play className="h-3.5 w-3.5 text-rose-400" /> M3U8 #{i + 2}
                  </button>
                ))}
                {/* mirror yang bisa dibaca server di depan; yang terproteksi CF (playmogo) belakang */}
                {[...detail.streamLinks]
                  .sort((a, b) => Number(/playmogo|filelions|megacloud/i.test(a.name) || /playmogo/i.test(a.url)) - Number(/playmogo|filelions|megacloud/i.test(b.name) || /playmogo/i.test(b.url)))
                  .map((s, i) => (
                  <button
                    key={i}
                    onClick={() => playMirror(s)}
                    className="flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3.5 py-2.5 text-xs font-bold capitalize transition-colors hover:bg-secondary"
                    title={/playmogo/i.test(s.name) ? "Terproteksi Cloudflare — bila tidak terbaca, otomatis pindah ke server lain" : "Diputar di pemutar internal bila server dapat dibaca"}
                  >
                    <Play className="h-3.5 w-3.5 text-rose-400" /> {s.name}
                    {/playmogo/i.test(s.name) && (
                      <span className="rounded-md bg-amber-500/15 px-1 py-px text-[8px] font-extrabold uppercase text-amber-300">cf</span>
                    )}
                  </button>
                ))}
              </div>
            )}
            <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">
              Server dengan tanda <b className="text-emerald-300">Native</b> diputar di pemutar internal FanzzTools — bebas iklan, bisa diskip & diputar ulang.
              Bila server gagal dibaca (diblokir sumbernya), pemutar cadangan embed dipakai otomatis — pindah server bila tetap bermasalah.
            </p>
          </section>
        )}

        {/* tautan unduhan */}
        {detail.downloadLinks && detail.downloadLinks.length > 0 && (
          <section className="mt-4">
            <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
              <DownloadIcon className="h-4 w-4 text-rose-400" /> Tautan Unduhan
            </h3>
            <div className="flex flex-wrap gap-2">
              {detail.downloadLinks.slice(0, 10).map((dl, i) => (
                <a
                  key={i}
                  href={dl.url}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  className="flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3.5 py-2.5 text-[11px] font-bold text-muted-foreground transition-colors hover:text-foreground"
                >
                  <DownloadIcon className="h-3.5 w-3.5" /> {dl.text.slice(0, 24) || `Host ${i + 1}`}
                </a>
              ))}
            </div>
          </section>
        )}

        {detail.synopsis && (
          <section className="mt-4 rounded-2xl glass p-4">
            <h3 className="mb-1.5 text-sm font-bold">Sinopsis</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">{detail.synopsis}</p>
          </section>
        )}

        <p className="mt-3 flex items-start gap-2.5 rounded-2xl glass p-3.5 text-[10.5px] leading-relaxed text-muted-foreground">
          <ShieldAlert className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" />
          Konten 21+. Apabila stream tidak berjalan, silakan pindah ke mirror lain atau buka tautan aslinya. Tetap bijak dalam mengakses konten.
        </p>
      </div>
    );
  }

  /* ---------- LIST ---------- */
  return (
    <div>
      <ToolHeader icon={<Flame className="h-5.5 w-5.5" />} title="Nekopoi 21+" subtitle="Konten dewasa • verifikasi usia aktif" accent="rose" />

      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => { setQuery(e.target.value); doSearch(e.target.value); }}
          placeholder="Cari judul hentai..."
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-3.5 pl-10 pr-10 text-sm outline-none focus:border-rose-400/50"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-rose-400" />}
        {query && (
          <button onClick={() => { setQuery(""); loadLatest(); }} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {items === null ? (
        <div className="space-y-2">
          {[0, 1, 2, 3, 4].map((i) => <div key={i} className="h-20 rounded-2xl shimmer" />)}
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={<Flame className="h-6 w-6" />} title="Tidak ada hasil" desc="Silakan coba kata kunci lain, atau sumber sedang bermasalah." />
      ) : (
        <div className="space-y-2">
          {items.map((it, i) => (
            <motion.button
              key={it.url + i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.3) }}
              onClick={() => openDetail(it.url)}
              className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
            >
              {it.thumbnail ? (
                <img src={it.thumbnail} alt="" loading="lazy" className="h-16 w-12 shrink-0 rounded-lg object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-16 w-12 shrink-0 items-center justify-center rounded-lg bg-secondary"><Flame className="h-5 w-5 text-muted-foreground" /></div>
              )}
              <div className="min-w-0 flex-1">
                <p className="clamp-2 text-sm font-bold leading-tight">{it.title}</p>
                <p className="mt-0.5 flex items-center gap-1 text-[10px] text-muted-foreground">
                  <Clock3 className="h-2.5 w-2.5" /> 21+ • ketuk untuk detail &amp; stream
                </p>
              </div>
              <ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground" />
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}

function ButtonGhost({ onBack }: { onBack: () => void }) {
  return (
    <button onClick={onBack} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
      <ArrowLeft className="h-4 w-4" /> Kembali
    </button>
  );
}
