"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { useApp, type ViewId } from "@/lib/app-store";
import { Input } from "@/components/ui/input";
import {
  Home, Clapperboard, Bot, Music4, Download, MailPlus, Zap, User, Tv, Tv2,
  MessageCircle, Newspaper, BookOpen, Library, Flame, Swords, ImageIcon, Heart,
  Scissors, Dices, History as HistoryIcon, Music2, ShieldAlert, AtSign, Droplets,
  Book, Palette, Sparkles, QrCode, Calculator, Brain, Grid3X3, Search, Code2,
  ShieldCheck, Blocks, Moon, BookOpen as BookIcon, Clock3, Wand2, FileArchive,
  Skull, Radio, Gamepad2, Hourglass, ShieldCheck as ShieldPm,
  CloudSun, Wifi, Dices as DicesIcon, Type,
} from "lucide-react";

/**
 * Beranda The All-Tools (V2 Modern-UpdSec).
 * SEMUA tools FanzzTools dalam satu halaman + pencarian (khusus halaman ini)
 * + daftar tools yang akan datang (Coming Soon).
 */

interface ToolEntry {
  view: ViewId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  desc: string;
  gradient: string;
  badge?: string;
  kategori: string;
  kata: string[]; // kata kunci pencarian
}

const ALL_TOOLS: ToolEntry[] = [
  // FanzSec-Update — Security Center & AI Security Assistant
  { view: "security", label: "FanzzSecurity", icon: ShieldCheck, desc: "Security Center — pindai file, web, metadata gambar, hash/IOC, device advisor", gradient: "from-cyan-500 to-blue-800", badge: "BARU", kategori: "Keamanan", kata: ["security", "keamanan", "scan", "virus", "malware", "exif", "hash", "jwt", "file", "apk", "fanzsecurity"] },
  { view: "fanzsec", label: "FanzSec.Ai", icon: ShieldAlert, desc: "AI Security Assistant — white-hat, defensive security, lampiran 49 MB", gradient: "from-red-500 to-cyan-600", badge: "BARU", kategori: "Keamanan", kata: ["ai security", "fanzsec", "asisten keamanan", "chat ai", "security assistant", "whitehat"] },
  // V2.13 zuperupdt — tools baru
  { view: "cuaca", label: "Cuaca Live", icon: CloudSun, desc: "GPS real-time + animasi kondisi + prakiraan besok", gradient: "from-sky-500 to-blue-600", badge: "BARU", kategori: "Informasi", kata: ["cuaca", "weather", "hujan", "suhu", "panas", "prakiraan", "besok", "gps"] },
  { view: "wifi", label: "Check WiFi Sekitar", icon: Wifi, desc: "Region, IP, DNS, QR WiFi & audit password milikmu", gradient: "from-teal-500 to-cyan-600", badge: "BARU", kategori: "Keamanan", kata: ["wifi", "password", "ssid", "ip", "dns", "qr", "jaringan", "router"] },
  { view: "roda", label: "Roda Nama", icon: DicesIcon, desc: "56 nama • multi-pemenang • ranking • animasi warna", gradient: "from-red-500 to-red-700", badge: "BARU", kategori: "Kreator", kata: ["roda", "nama", "undian", "spin", "acak", "pemenang", "doorprize"] },
  { view: "ascii", label: "ASCII Art", icon: Type, desc: "Multi-varian + logo Kali dragon — 100% lokal", gradient: "from-emerald-500 to-teal-600", badge: "BARU", kategori: "Kreator", kata: ["ascii", "art", "teks", "logo", "kali", "dragon", "font"] },
  // keluarga — V2.12 Security-Updt: Parent Monitor kini AKTIF (bukan coming-soon)
  { view: "pm", label: "Parent Monitor", icon: ShieldPm, desc: "Family Cyber Safety — pantau HP anak legal, transparan, anti-salah-pakai", gradient: "from-blue-600 to-blue-600", badge: "BARU", kategori: "Keluarga", kata: ["parent", "monitor", "anak", "keluarga", "family", "cyber", "safety", "kontrol", "ortu", "wali", "pengawasan"] },
  // hiburan streaming
  { view: "film", label: "Nonton Film", icon: Clapperboard, desc: "Streaming movie & series + 30 server", gradient: "from-red-500 to-red-700", kategori: "Hiburan", kata: ["film", "movie", "nonton", "bioskop", "series"] },
  { view: "anime", label: "Nonton Anime", icon: Tv, desc: "Sub indo, jadwal, pemutar native bebas iklan", gradient: "from-amber-500 to-orange-600", kategori: "Hiburan", kata: ["anime", "otaku", "sub indo", "jepang"] },
  { view: "dracin", label: "Nonton Dracin", icon: Tv2, desc: "Drama Asia sub Indonesia", gradient: "from-rose-500 to-red-600", kategori: "Hiburan", kata: ["drama", "china", "korea", "asia", "dracin"] },
  { view: "donghua", label: "Nonton Donghua", icon: Swords, desc: "Anime China sub indo", gradient: "from-blue-600 to-blue-600", kategori: "Hiburan", kata: ["donghua", "china", "cultivation"] },
  { view: "manhwa", label: "Baca Manhwa", icon: BookIcon, desc: "Komik full color + search", gradient: "from-cyan-500 to-teal-600", kategori: "Hiburan", kata: ["manhwa", "komik", "baca", "webtoon"] },
  { view: "komik", label: "Baca Komik", icon: Book, desc: "Manhwa • Manhua • Comic", gradient: "from-orange-500 to-amber-600", kategori: "Hiburan", kata: ["komik", "manhua", "comic", "manga"] },
  { view: "nekopoi", label: "Nekopoi 21+", icon: Flame, desc: "Konten dewasa (verifikasi usia)", gradient: "from-rose-500 to-red-600", badge: "21+", kategori: "Hiburan", kata: ["nekopoi", "18", "dewasa"] },
  { view: "music", label: "Musik", icon: Music4, desc: "Cari, populer, preview, download MP3", gradient: "from-red-500 to-rose-600", kategori: "Hiburan", kata: ["musik", "lagu", "mp3", "audio", "nyanyi"] },
  { view: "lyrics", label: "Lyrics Music", icon: Music2, desc: "Lirik lagu full + tersinkron", gradient: "from-teal-500 to-emerald-600", kategori: "Hiburan", kata: ["lirik", "lyrics", "karaoke"] },
  // AI
  { view: "ai", label: "AI Chat", icon: Bot, desc: "Multi-model + tugas latar belakang", gradient: "from-blue-700 to-cyan-600", kategori: "AI", kata: ["ai", "chat", "gpt", "tanya"] },
  { view: "aiimage", label: "AI Image Gen", icon: ImageIcon, desc: "Bikin gambar cuma dari teks", gradient: "from-cyan-500 to-red-700", kategori: "AI", kata: ["gambar", "image", "ai", "generatif"] },
  { view: "debat", label: "Debat Filosofis AI", icon: Sparkles, desc: "Test psikologi + 8 level + skor & unduh hasil", gradient: "from-amber-500 to-red-600", badge: "BARU", kategori: "AI", kata: ["debat", "filsafat", "ateis", "agnostik", "psikologi"] },
  // ibadah
  { view: "ibadah", label: "Ruang Ibadah", icon: Moon, desc: "Jadwal sholat, kiblat, bacaan, semua agama", gradient: "from-emerald-500 to-teal-600", badge: "BARU", kategori: "Ibadah", kata: ["sholat", "salat", "kiblat", "agama", "doa", "kristen", "buddha", "hindu", "konghucu"] },
  { view: "quran", label: "Qur'an Digital", icon: BookOpen, desc: "114 surah, 21 imam, tafsir & terjemahan", gradient: "from-green-600 to-emerald-600", badge: "BARU", kategori: "Ibadah", kata: ["quran", "alquran", "surah", "ayat", "islam", "imam", "tafsir"] },
  // sosial
  { view: "chat", label: "Chat Sosial", icon: MessageCircle, desc: "Chat realtime, grup, VN, follow", gradient: "from-red-500 to-red-700", kategori: "Sosial", kata: ["chat", "pesan", "grup", "teman"] },
  { view: "story", label: "FanzzStory", icon: Clock3, desc: "Status 22 jam — teks/foto+musik/video, like & komentar", gradient: "from-rose-500 to-red-600", badge: "BARU", kategori: "Sosial", kata: ["story", "status", "cerita", "24 jam", "22 jam", "foto", "musik"] },
  { view: "profile", label: "Profil", icon: User, desc: "Akun, foto profil & pengaturan", gradient: "from-slate-500 to-gray-600", kategori: "Sosial", kata: ["profil", "akun", "avatar", "saya"] },
  // keamanan & developer
  { view: "sourcecode", label: "Ambil Source Code", icon: Code2, desc: "HTML/CSS/JS web lain — legal & rapi", gradient: "from-cyan-500 to-sky-600", badge: "BARU", kategori: "Developer", kata: ["source", "kode", "html", "css", "js", "scrape"] },
  { view: "secscan", label: "Cek Keamanan Web", icon: ShieldCheck, desc: "18+ pemeriksaan ketat, skor A+ s/d F", gradient: "from-emerald-600 to-cyan-600", badge: "BARU", kategori: "Developer", kata: ["keamanan", "security", "scan", "header", "https", "cek"] },
  // game & download
  { view: "minecraft", label: "Download Minecraft", icon: Gamepad2, desc: "APK, mods, maps, shaders, versi lengkap", gradient: "from-green-600 to-lime-600", badge: "BARU", kategori: "Game", kata: ["minecraft", "mcpe", "mod", "map", "shader", "apk", "game"] },
  { view: "downloader", label: "Downloader", icon: Download, desc: "All-in-one 20+ platform + preview", gradient: "from-emerald-500 to-teal-600", kategori: "Download", kata: ["download", "unduh", "video", "sosmed", "tiktok"] },
  { view: "apk", label: "APK Builder", icon: Grid3X3, desc: "HTML/ZIP atau link jadi app Android", gradient: "from-orange-500 to-red-600", kategori: "Download", kata: ["apk", "android", "app", "builder"] },
  { view: "gacha", label: "Gacha Nokos", icon: Dices, desc: "Nomor virtual OTP + negara", gradient: "from-cyan-500 to-red-700", kategori: "Download", kata: ["nokos", "otp", "nomor", "wa"] },
  // tool harian
  { view: "studio", label: "Studio Gambar", icon: Palette, desc: "13 generator: brat, chat palsu, KTP dummy…", gradient: "from-red-500 to-cyan-600", kategori: "Kreator", kata: ["gambar", "brat", "chat", "ktp", "generator", "meme", "wallpaper"] },
  { view: "hdimage", label: "Image HD", icon: Sparkles, desc: "HD-kan foto sampai 8K + rasio blur", gradient: "from-cyan-500 to-sky-600", kategori: "Kreator", kata: ["hd", "foto", "upscale", "resolusi"] },
  { view: "qr", label: "QR Studio", icon: QrCode, desc: "Buat QR bergaya + pindai QR", gradient: "from-emerald-500 to-teal-600", kategori: "Kreator", kata: ["qr", "barcode", "scan"] },
  { view: "kalkulator", label: "Kalkulator", icon: Calculator, desc: "Matematika lengkap + rumus fisika", gradient: "from-red-500 to-red-700", kategori: "Produktivitas", kata: ["kalkulator", "hitung", "matematika", "fisika"] },
  { view: "iqtest", label: "Tes IQ", icon: Brain, desc: "75 soal berbobot, hasil jujur + kartu PNG", gradient: "from-blue-700 to-blue-700", kategori: "Produktivitas", kata: ["iq", "tes", "kecerdasan", "otak"] },
  { view: "profanity", label: "Deteksi Kata Sensitif", icon: ShieldAlert, desc: "Multi-bahasa + tingkat kasar", gradient: "from-red-500 to-rose-600", kategori: "Produktivitas", kata: ["kata", "kasar", "toxic", "sensor"] },
  { view: "email", label: "Email Trial", icon: MailPlus, desc: "Email sementara + auto deteksi OTP", gradient: "from-amber-500 to-orange-600", kategori: "Produktivitas", kata: ["email", "sementara", "otp", "trial"] },
  { view: "am", label: "AM Active", icon: Zap, desc: "Premium Alight Motion", gradient: "from-cyan-500 to-teal-600", badge: "PRO", kategori: "Produktivitas", kata: ["alight", "motion", "am", "premium"] },
  { view: "capcut", label: "CapCut Pro Gen", icon: Scissors, desc: "Akun aktif + Pro trial 7 hari", gradient: "from-sky-500 to-blue-600", kategori: "Produktivitas", kata: ["capcut", "edit", "pro"] },
  { view: "reactwa", label: "React Saluran WA", icon: Heart, desc: "React emoji ke pesan saluran", gradient: "from-red-500 to-rose-600", kategori: "Produktivitas", kata: ["wa", "whatsapp", "react", "saluran"] },
  // informasi
  { view: "news", label: "Berita + BMKG", icon: Newspaper, desc: "Update tiap menit + info gempa", gradient: "from-emerald-500 to-teal-600", kategori: "Informasi", kata: ["berita", "news", "gempa", "bmkg"] },
  { view: "wiki", label: "Pencarian Wiki", icon: BookOpen, desc: "Indonesia & English", gradient: "from-amber-500 to-orange-600", kategori: "Informasi", kata: ["wiki", "wikipedia", "ensiklopedia"] },
  { view: "books", label: "Baca Buku/PDF", icon: Library, desc: "Pustaka arsip + PDF lokal", gradient: "from-cyan-500 to-teal-600", kategori: "Informasi", kata: ["buku", "pdf", "baca", "arsip"] },
  { view: "osint", label: "OSINT", icon: AtSign, desc: "NIK, IP, WA, domain, WHOIS, username", gradient: "from-blue-600 to-blue-600", kategori: "Informasi", kata: ["osint", "nik", "ip", "domain", "whois", "cek"] },
  { view: "usercheck", label: "Cek Profil Username", icon: AtSign, desc: "Ada di dalam tools OSINT", gradient: "from-blue-500 to-cyan-600", kategori: "Informasi", kata: ["username", "profil", "cek"] },
  { view: "history", label: "Riwayat", icon: HistoryIcon, desc: "Riwayat per tools, rapi terpisah", gradient: "from-slate-500 to-gray-600", kategori: "Informasi", kata: ["riwayat", "history", "log"] },
  { view: "home", label: "Beranda Utama", icon: Home, desc: "Kembali ke beranda rekomendasi", gradient: "from-red-500 to-red-700", kategori: "Informasi", kata: ["beranda", "home", "utama"] },
];

/** Tools yang akan datang (Coming Soon) — sesuai permintaan pemilik.
 *  CATATAN V2.13 zuperupdt: "Check WiFi Sekitar" SUDAH JADI tools AKTIF
 *  (dipindah ke daftar atas) — kartu coming-soon-nya dihapus. */
const COMING_SOON = [
  { label: "Generator Prompt AI", desc: "Bikin prompt profesional untuk AI apa pun dalam sekali klik", icon: Wand2, gradient: "from-cyan-500 to-red-600" },
  { label: "URL to ZIP", desc: "Simpan seluruh isi sebuah website jadi 1 file ZIP", icon: FileArchive, gradient: "from-cyan-500 to-blue-600" },
  { label: "Jailbreak Prompt AI", desc: "Kumpulan teknik prompt tingkat lanjut untuk riset AI", icon: Skull, gradient: "from-red-600 to-rose-700" },
  { label: "Stream Live & Playlist Olahraga", desc: "Jadwal sepakbola, basket & olahraga lain — pilih negara & tim favoritmu", icon: Radio, gradient: "from-emerald-500 to-green-700" },
];

export default function AllToolsView() {
  const { setView } = useApp();
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ALL_TOOLS;
    return ALL_TOOLS.filter(
      (t) =>
        t.label.toLowerCase().includes(q) ||
        t.desc.toLowerCase().includes(q) ||
        t.kategori.toLowerCase().includes(q) ||
        t.kata.some((k) => k.includes(q) || q.includes(k))
    );
  }, [query]);

  const soonFiltered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return COMING_SOON;
    return COMING_SOON.filter((t) => t.label.toLowerCase().includes(q) || t.desc.toLowerCase().includes(q));
  }, [query]);

  // kelompokkan per kategori (pertahankan urutan kemunculan)
  const kategori = useMemo(() => {
    const map = new Map<string, ToolEntry[]>();
    for (const t of filtered) {
      const arr = map.get(t.kategori) || [];
      arr.push(t);
      map.set(t.kategori, arr);
    }
    return [...map.entries()];
  }, [filtered]);

  return (
    <div className="space-y-5 pb-4">
      {/* header + search */}
      <div>
        <h2 className="flex items-center gap-2 text-xl font-extrabold">
          <Grid3X3 className="h-5.5 w-5.5 text-red-400" /> The All-Tools
        </h2>
        <p className="mt-0.5 text-[11.5px] text-muted-foreground">
          {ALL_TOOLS.length} tools aktif + {COMING_SOON.length} akan datang — semua di satu halaman
        </p>
        <div className="relative mt-3">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari tools apa pun… (mis. sholat, minecraft, keamanan, chat)"
            className="rounded-xl pl-10"
          />
        </div>
      </div>

      {/* hasil */}
      {filtered.length === 0 && soonFiltered.length === 0 && (
        <div className="glass rounded-2xl p-8 text-center">
          <p className="text-sm font-extrabold">Tools tidak ketemu</p>
          <p className="mt-1 text-[11px] text-muted-foreground">Coba kata lain — mis. "gambar", "film", "quran", "scan".</p>
        </div>
      )}

      {kategori.map(([kat, tools]) => (
        <section key={kat}>
          <h3 className="mb-2.5 text-sm font-bold text-muted-foreground">{kat} <span className="text-[10px] font-bold">({tools.length})</span></h3>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {tools.map((t, i) => (
              <motion.button
                key={t.view + t.label}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.025, 0.35) }}
                whileTap={{ scale: 0.96 }}
                onClick={() => setView(t.view)}
                className="group glass relative overflow-hidden rounded-2xl p-4 text-left"
              >
                <div className={`absolute -right-6 -top-6 h-20 w-20 rounded-full bg-gradient-to-br ${t.gradient} opacity-20 blur-xl transition-opacity group-hover:opacity-40`} />
                <div className={`relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${t.gradient} text-white shadow-md`}>
                  <t.icon className="h-5 w-5" />
                </div>
                <div className="relative mt-2.5 flex items-center gap-1.5">
                  <p className="text-[13px] font-bold">{t.label}</p>
                  {t.badge && (
                    <span className={`rounded-full px-1.5 py-px text-[8px] font-extrabold ${t.badge === "21+" ? "bg-red-500/20 text-red-300" : "bg-amber-500/20 text-amber-300"}`}>
                      {t.badge}
                    </span>
                  )}
                </div>
                <p className="relative mt-0.5 text-[10.5px] leading-snug text-muted-foreground clamp-2">{t.desc}</p>
              </motion.button>
            ))}
          </div>
        </section>
      ))}

      {/* coming soon */}
      {soonFiltered.length > 0 && (
        <section>
          <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
            <Hourglass className="h-4 w-4 text-amber-400" /> Akan Datang (Coming Soon) <span className="text-[10px] font-bold text-muted-foreground">— dikerjakan saat diminta pemilik</span>
          </h3>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {soonFiltered.map((t, i) => (
              <motion.div
                key={t.label}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
                className="relative overflow-hidden rounded-2xl border border-dashed border-amber-400/30 bg-amber-500/5 p-4"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-secondary to-secondary/60 text-amber-400/70">
                  <t.icon className="h-5 w-5" />
                </div>
                <div className="mt-2.5 flex items-center gap-1.5">
                  <p className="text-[13px] font-bold text-amber-200/80">{t.label}</p>
                  <span className="rounded-full bg-amber-500/20 px-1.5 py-px text-[8px] font-extrabold text-amber-300">SOON</span>
                </div>
                <p className="mt-0.5 text-[10.5px] leading-snug text-muted-foreground clamp-2">{t.desc}</p>
              </motion.div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
