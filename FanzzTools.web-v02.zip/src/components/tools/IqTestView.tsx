"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import { Brain, Timer, Download, ChevronRight, RefreshCw, Info, CheckCircle2 } from "lucide-react";

/**
 * Tes IQ (V2.11 #30) — bank 75 soal asli (deret angka, analogi verbal, logika,
 * aritmetika, deret huruf, beda-satu). Pilihan jumlah soal (20/40/60/75),
 * waktu proporsional (30 detik/soal), skor berbobot tingkat kesulitan, hasil
 * JUJUR (tidak disembunyikan bila rendah) + kartu hasil PNG berborder.
 *
 * Disclaimer wajib: perkiraan statistik terkalibrasi kasar — BUKAN diagnosis
 * resmi. IQ resmi hanya lewat psikolog berlisensi (WAIS/WISC/SB).
 */

interface Soal {
  k: "Deret Angka" | "Analogi" | "Logika" | "Aritmetika" | "Deret Huruf" | "Beda-Satu";
  tingkat: 1 | 2 | 3;
  teks: string;
  opsi: [string, string, string, string];
  benar: 0 | 1 | 2 | 3;
}

const BANK: Soal[] = [
  // ============ TINGKAT 1 (25 soal) ============
  { k: "Deret Angka", tingkat: 1, teks: "2, 4, 6, 8, … ?", opsi: ["9", "10", "11", "12"], benar: 1 },
  { k: "Deret Angka", tingkat: 1, teks: "3, 6, 9, 12, … ?", opsi: ["14", "15", "16", "18"], benar: 1 },
  { k: "Deret Angka", tingkat: 1, teks: "1, 3, 5, 7, … ?", opsi: ["8", "9", "10", "11"], benar: 1 },
  { k: "Analogi", tingkat: 1, teks: "Dokter : Rumah Sakit = Guru : …", opsi: ["Kantor", "Sekolah", "Perpustakaan", "Taman"], benar: 1 },
  { k: "Analogi", tingkat: 1, teks: "Panas : Es = Terang : …", opsi: ["Lampu", "Gelap", "Matahari", "Bintang"], benar: 1 },
  { k: "Beda-Satu", tingkat: 1, teks: "Manakah yang TIDAK sejenis?", opsi: ["Apel", "Jeruk", "Wortel", "Pisang"], benar: 2 },
  { k: "Beda-Satu", tingkat: 1, teks: "Manakah yang TIDAK sejenis?", opsi: ["Merah", "Biru", "Bulat", "Hijau"], benar: 2 },
  { k: "Aritmetika", tingkat: 1, teks: "5 + 3 × 2 = ?", opsi: ["16", "13", "11", "10"], benar: 2 },
  { k: "Aritmetika", tingkat: 1, teks: "12 adalah berapa persen dari 48?", opsi: ["20%", "25%", "30%", "35%"], benar: 1 },
  { k: "Logika", tingkat: 1, teks: "Semua burung punya sayap. Kenari adalah burung. Maka Kenari …", opsi: ["tidak punya sayap", "pasti bisa terbang", "punya sayap", "seekor mamalia"], benar: 2 },
  { k: "Deret Huruf", tingkat: 1, teks: "A, C, E, G, … ?", opsi: ["H", "I", "J", "K"], benar: 1 },
  { k: "Deret Angka", tingkat: 1, teks: "10, 20, 30, … ?", opsi: ["35", "40", "45", "50"], benar: 1 },
  { k: "Analogi", tingkat: 1, teks: "Penulis : Buku = Pelukis : …", opsi: ["Kuas", "Lukisan", "Galeri", "Warna"], benar: 1 },
  { k: "Aritmetika", tingkat: 1, teks: "Jika x = 4, maka 3x − 2 = ?", opsi: ["8", "9", "10", "12"], benar: 2 },
  { k: "Beda-Satu", tingkat: 1, teks: "Manakah yang TIDAK sejenis?", opsi: ["Senin", "Selasa", "Januari", "Rabu"], benar: 2 },
  { k: "Deret Angka", tingkat: 1, teks: "100, 90, 80, … ?", opsi: ["60", "65", "70", "75"], benar: 2 },
  { k: "Logika", tingkat: 1, teks: "Semua mawar adalah bunga. Sebagian bunga berwarna merah. Maka sebagian mawar …", opsi: ["pasti merah", "mungkin merah, mungkin tidak", "tidak mungkin merah", "semua merah"], benar: 1 },
  { k: "Aritmetika", tingkat: 1, teks: "15 − 6 ÷ 3 = ?", opsi: ["3", "13", "9", "12"], benar: 1 },
  { k: "Analogi", tingkat: 1, teks: "Sepatu : Kaki = Topi : …", opsi: ["Rambut", "Kepala", "Wajah", "Tangan"], benar: 1 },
  { k: "Deret Angka", tingkat: 1, teks: "1, 2, 4, 8, … ?", opsi: ["12", "14", "16", "10"], benar: 2 },
  { k: "Beda-Satu", tingkat: 1, teks: "Manakah yang BUKAN kuadrat sempurna?", opsi: ["4", "9", "20", "25"], benar: 2 },
  { k: "Aritmetika", tingkat: 1, teks: "Separuh dari 86 adalah …", opsi: ["41", "42", "43", "44"], benar: 2 },
  { k: "Deret Angka", tingkat: 1, teks: "5, 10, 15, 20, … ?", opsi: ["22", "23", "24", "25"], benar: 3 },
  { k: "Logika", tingkat: 1, teks: "Ayah Budi lebih tua dari Budi. Siapa yang lebih muda?", opsi: ["Ayah Budi", "Budi", "Sama tua", "Tidak bisa ditentukan"], benar: 1 },
  { k: "Aritmetika", tingkat: 1, teks: "7 × 8 = ?", opsi: ["54", "55", "56", "64"], benar: 2 },
  // ============ TINGKAT 2 (25 soal) ============
  { k: "Deret Angka", tingkat: 2, teks: "2, 3, 5, 8, 12, … ?", opsi: ["15", "16", "17", "18"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "1, 4, 9, 16, … ?", opsi: ["20", "24", "25", "36"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "2, 6, 18, 54, … ?", opsi: ["108", "152", "162", "216"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "1, 1, 2, 3, 5, 8, … ?", opsi: ["11", "12", "13", "14"], benar: 2 },
  { k: "Analogi", tingkat: 2, teks: "Kapten : Kapal = Pilot : …", opsi: ["Pelabuhan", "Pesawat", "Langit", "Bandara"], benar: 1 },
  { k: "Analogi", tingkat: 2, teks: "Haus : Air = Lelah : …", opsi: ["Makan", "Istirahat", "Olahraga", "Minum"], benar: 1 },
  { k: "Logika", tingkat: 2, teks: "Semua A adalah B. Semua B adalah C. Maka semua A …", opsi: ["adalah C", "bukan C", "sebagian C", "tidak berhubungan dengan C"], benar: 0 },
  { k: "Aritmetika", tingkat: 2, teks: "3 mesin membuat 3 barang dalam 3 menit. Berapa menit 100 mesin membuat 100 barang?", opsi: ["100", "33", "3", "300"], benar: 2 },
  { k: "Aritmetika", tingkat: 2, teks: "Setelah diskon 20%, harga barang Rp80.000. Harga aslinya?", opsi: ["Rp84.000", "Rp96.000", "Rp100.000", "Rp104.000"], benar: 2 },
  { k: "Beda-Satu", tingkat: 2, teks: "Manakah yang TIDAK mengapung di air secara umum?", opsi: ["Kapal", "Perahu", "Sepeda", "Rakit"], benar: 2 },
  { k: "Deret Huruf", tingkat: 2, teks: "Z, X, V, T, … ?", opsi: ["S", "R", "Q", "P"], benar: 1 },
  { k: "Deret Angka", tingkat: 2, teks: "3, 7, 15, 31, … ?", opsi: ["47", "55", "63", "62"], benar: 2 },
  { k: "Aritmetika", tingkat: 2, teks: "Umur Ana 5 tahun lalu adalah 12. Berapa umurnya 7 tahun lagi?", opsi: ["22", "23", "24", "25"], benar: 2 },
  { k: "Logika", tingkat: 2, teks: "Di kelas itu semua siswa membawa buku. Rani tidak membawa buku. Kesimpulan paling tepat?", opsi: ["Rani pelupa", "Rani bukan siswa kelas itu", "Rani siswa malas", "Buku Rani hilang"], benar: 1 },
  { k: "Analogi", tingkat: 2, teks: "Termometer : Suhu = Barometer : …", opsi: ["Kelembapan", "Angin", "Tekanan udara", "Curah hujan"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "8, 27, 64, 125, … ?", opsi: ["196", "216", "225", "343"], benar: 1 },
  { k: "Aritmetika", tingkat: 2, teks: "(15 − 3) × (4 + 1) ÷ 6 = ?", opsi: ["8", "10", "12", "15"], benar: 1 },
  { k: "Beda-Satu", tingkat: 2, teks: "Manakah yang BUKAN poligon?", opsi: ["Segitiga", "Persegi", "Lingkaran", "Jajar genjang"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "2, 3, 5, 7, 11, … ?", opsi: ["12", "13", "14", "15"], benar: 1 },
  { k: "Analogi", tingkat: 2, teks: "Peta : Wilayah = Kamus : …", opsi: ["Bahasa", "Kata", "Gambar", "Daftar isi"], benar: 1 },
  { k: "Aritmetika", tingkat: 2, teks: "Kereta melaju 60 km/jam. Waktu menempuh 30 km?", opsi: ["15 menit", "20 menit", "30 menit", "45 menit"], benar: 2 },
  { k: "Logika", tingkat: 2, teks: "Sebagian besar siswa suka matematika. Rani seorang siswa. Kesimpulan paling tepat?", opsi: ["Rani pasti suka matematika", "Rani pasti benci matematika", "Rani mungkin suka matematika", "Rani guru matematika"], benar: 2 },
  { k: "Deret Angka", tingkat: 2, teks: "4, 5, 8, 9, 12, 13, … ?", opsi: ["15", "16", "17", "18"], benar: 1 },
  { k: "Aritmetika", tingkat: 2, teks: "Jika 2x + 5 = 17, maka x = ?", opsi: ["5", "6", "7", "8"], benar: 1 },
  { k: "Analogi", tingkat: 2, teks: "Air : Banjir = Api : …", opsi: ["Asap", "Kebakaran", "Panas", "Api unggun"], benar: 1 },
  // ============ TINGKAT 3 (25 soal) ============
  { k: "Deret Angka", tingkat: 3, teks: "1, 2, 6, 24, 120, … ?", opsi: ["240", "360", "600", "720"], benar: 3 },
  { k: "Deret Angka", tingkat: 3, teks: "2, 5, 11, 23, 47, … ?", opsi: ["59", "85", "94", "95"], benar: 3 },
  { k: "Deret Angka", tingkat: 3, teks: "1, 3, 6, 10, 15, … ?", opsi: ["18", "20", "21", "24"], benar: 2 },
  { k: "Deret Angka", tingkat: 3, teks: "8, 4, 2, 1, 0,5, … ?", opsi: ["0,2", "0,25", "0,3", "0,125"], benar: 1 },
  { k: "Logika", tingkat: 3, teks: "Semua pelukis adalah seniman. Sebagian seniman kaya. Tono seorang pelukis. Kesimpulan PASTI?", opsi: ["Tono kaya", "Tono seniman", "Tono miskin", "Tono bukan seniman"], benar: 1 },
  { k: "Aritmetika", tingkat: 3, teks: "x adalah 25% dari y. Jika y = 200, maka x/2 = ?", opsi: ["20", "25", "30", "50"], benar: 1 },
  { k: "Aritmetika", tingkat: 3, teks: "5 orang bertemu dan semuanya saling bersalaman tepat sekali. Banyak salaman?", opsi: ["8", "9", "10", "25"], benar: 2 },
  { k: "Deret Huruf", tingkat: 3, teks: "B, D, G, K, P, … ?", opsi: ["T", "U", "V", "W"], benar: 2 },
  { k: "Analogi", tingkat: 3, teks: "Mitokondria : Sel = Pembangkit listrik : …", opsi: ["Baterai", "Kota", "Kabel", "Pembangkit nuklir"], benar: 1 },
  { k: "Aritmetika", tingkat: 3, teks: "Jarak A–B 120 km. Pergi 40 km/jam, kembali 60 km/jam. Rata-rata kecepatan?", opsi: ["48 km/jam", "50 km/jam", "45 km/jam", "52 km/jam"], benar: 0 },
  { k: "Deret Angka", tingkat: 3, teks: "3, 8, 15, 24, 35, … ?", opsi: ["46", "47", "48", "50"], benar: 2 },
  { k: "Logika", tingkat: 3, teks: "A lebih tinggi dari B. B lebih tinggi dari C. D lebih tinggi dari A. Siapa tertinggi?", opsi: ["A", "B", "D", "C"], benar: 2 },
  { k: "Aritmetika", tingkat: 3, teks: "Bak diisi keran A (penuh 6 jam) dan keran B (penuh 3 jam). Bersama-sama penuh dalam?", opsi: ["1,5 jam", "2 jam", "2,5 jam", "4,5 jam"], benar: 1 },
  { k: "Deret Angka", tingkat: 3, teks: "1, 1, 2, 3, 5, 8, 13, … ?", opsi: ["19", "20", "21", "26"], benar: 2 },
  { k: "Aritmetika", tingkat: 3, teks: "1 + 2 + 3 + … + 20 = ?", opsi: ["190", "200", "210", "220"], benar: 2 },
  { k: "Beda-Satu", tingkat: 3, teks: "Manakah yang BUKAN kuadrat sempurna?", opsi: ["121", "144", "180", "196"], benar: 2 },
  { k: "Analogi", tingkat: 3, teks: "Sintesis : Menggabungkan = Analisis : …", opsi: ["Menyimpulkan", "Memisah / membedah", "Menghafal", "Menerjemahkan"], benar: 1 },
  { k: "Deret Angka", tingkat: 3, teks: "31, 29, 24, 22, 17, … ?", opsi: ["15", "14", "13", "12"], benar: 0 },
  { k: "Aritmetika", tingkat: 3, teks: "Hari ini Rabu. 100 hari lagi hari apa?", opsi: ["Kamis", "Jumat", "Sabtu", "Senin"], benar: 1 },
  { k: "Logika", tingkat: 3, teks: "Semua Z bukan Y. Sebagian Y adalah X. Hubungan Z dan X?", opsi: ["Z pasti bukan X", "Z mungkin X", "Z pasti X", "Tidak dapat ditentukan"], benar: 3 },
  { k: "Deret Angka", tingkat: 3, teks: "6, 12, 21, 33, … ?", opsi: ["45", "46", "48", "51"], benar: 2 },
  { k: "Aritmetika", tingkat: 3, teks: "Rata-rata 5 siswa 80. Satu siswa keluar, rata-rata sisanya 78. Nilai siswa yang keluar?", opsi: ["82", "84", "86", "88"], benar: 3 },
  { k: "Analogi", tingkat: 3, teks: "Kalori : Energi = Hertz : …", opsi: ["Daya", "Frekuensi", "Amplitudo", "Tegangan"], benar: 1 },
  { k: "Deret Angka", tingkat: 3, teks: "1, 4, 13, 40, … ?", opsi: ["81", "100", "121", "160"], benar: 2 },
  { k: "Aritmetika", tingkat: 3, teks: "Dua dadu dilempar bersama. Peluang muncul total 7?", opsi: ["1/6", "1/8", "5/36", "7/36"], benar: 0 },
];

const PILIHAN_JUMLAH = [20, 40, 60, 75];
const BOBOT: Record<1 | 2 | 3, number> = { 1: 1, 2: 1.5, 3: 2 };

/** Acak dengan seed supaya komposisi tingkat stabil per sesi (tIDak sekuensial membosankan). */
function acakSoal(jumlah: number): Soal[] {
  // komposisi proporsional dari bank
  const tingkat1 = BANK.filter((s) => s.tingkat === 1);
  const tingkat2 = BANK.filter((s) => s.tingkat === 2);
  const tingkat3 = BANK.filter((s) => s.tingkat === 3);
  const p1 = Math.round((tingkat1.length / BANK.length) * jumlah);
  const p3 = Math.round((tingkat3.length / BANK.length) * jumlah);
  const p2 = jumlah - p1 - p3;
  const ambil = (arr: Soal[], n: number) => [...arr].sort(() => Math.random() - 0.5).slice(0, n);
  return [...ambil(tingkat1, p1), ...ambil(tingkat2, p2), ...ambil(tingkat3, p3)].sort(() => Math.random() - 0.5);
}

function kategoriIq(iq: number): { label: string; warna: string } {
  if (iq < 70) return { label: "Sangat Rendah", warna: "#ef4444" };
  if (iq < 85) return { label: "Rendah", warna: "#f97316" };
  if (iq < 115) return { label: "Rata-rata", warna: "#22c55e" };
  if (iq < 130) return { label: "Tinggi", warna: "#06b6d4" };
  return { label: "Sangat Tinggi", warna: "#ef4444" };
}

interface HasilIq {
  iq: number;
  persentil: number;
  benar: number;
  total: number;
  skorTertimbang: number;
  maksTertimbang: number;
  perKategori: Array<{ nama: string; benar: number; total: number }>;
  durasiDetik: number;
}

export default function IqTestView() {
  const [fase, setFase] = useState<"intro" | "tes" | "hasil">("intro");
  const [jumlah, setJumlah] = useState(20);
  const [soal, setSoal] = useState<Soal[]>([]);
  const [idx, setIdx] = useState(0);
  const [jawab, setJawab] = useState<Array<number | null>>([]);
  const [sisaDetik, setSisaDetik] = useState(0);
  const [mulaiPada, setMulaiPada] = useState(0);
  const [hasil, setHasil] = useState<HasilIq | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const totalDetik = jumlah * 30;
  const soalAktif = soal[idx];

  const selesai = useCallback((waktuHabis = false) => {
    if (fase !== "tes") return;
    const benarArr = jawab.map((j, i) => (j === soal[i]?.benar ? 1 : 0));
    const benar = benarArr.reduce((a, b) => a + b, 0);
    const skorTertimbang = soal.reduce((a, s, i) => a + (jawab[i] === s.benar ? BOBOT[s.tingkat] : 0), 0);
    const maksTertimbang = soal.reduce((a, s) => a + BOBOT[s.tingkat], 0);
    const persen = maksTertimbang > 0 ? skorTertimbang / maksTertimbang : 0;
    // perkiraan jujur: asumsi kalibrasi kasar — 50% benar ≈ IQ 100, SD ≈ 22 poin persen
    const z = (persen - 0.5) / 0.22;
    const iq = Math.max(55, Math.min(145, Math.round(100 + 15 * z)));
    // persentil dari IQ (distribusi normal)
    const persentil = Math.max(0.1, Math.min(99.9, 50 * (1 + Math.tanh((iq - 100) / 30))));
    const kategoriSet = new Set(soal.map((s) => s.k));
    const perKategori = [...kategoriSet].map((nama) => {
      const indeks = soal.map((s, i) => (s.k === nama ? i : -1)).filter((i) => i >= 0);
      return { nama, benar: indeks.filter((i) => jawab[i] === soal[i].benar).length, total: indeks.length };
    });
    const durasiDetik = Math.round((Date.now() - mulaiPada) / 1000);
    const h: HasilIq = { iq, persentil, benar, total: soal.length, skorTertimbang, maksTertimbang, perKategori, durasiDetik };
    setHasil(h);
    setFase("hasil");
    if (waktuHabis) toast({ title: "Waktu habis!", description: "Jawaban kosong dihitung salah — hasil tetap dihitung jujur." });
    pushHistory("iqtest", {
      id: `iq-${Date.now()}`,
      title: `Tes IQ selesai — perkiraan ${iq}`,
      subtitle: `${benar}/${soal.length} benar • ${Math.floor(durasiDetik / 60)}m ${durasiDetik % 60}d`,
    });
  }, [fase, jawab, soal, mulaiPada, toast]);

  const mulai = () => {
    const s = acakSoal(jumlah);
    setSoal(s);
    setJawab(new Array(s.length).fill(null));
    setIdx(0);
    setSisaDetik(totalDetik);
    setMulaiPada(Date.now());
    setHasil(null);
    setFase("tes");
  };

  // salin referensi terbaru selesai lewat efek (bukan saat render)
  const selesaiRef = useRef(selesai);
  useEffect(() => {
    selesaiRef.current = selesai;
  }, [selesai]);

  // timer — memakai ref supaya tidak bergantung pada deklarasi ulang
  useEffect(() => {
    if (fase !== "tes") return;
    const t = setInterval(() => {
      setSisaDetik((s) => {
        if (s <= 1) {
          clearInterval(t);
          selesaiRef.current(true);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [fase]);

  /* ---------- kartu hasil PNG ---------- */
  useEffect(() => {
    if (fase !== "hasil" || !hasil) return;
    // AnimatePresence mode="wait": kanvas baru dipasang setelah animasi keluar selesai —
    // coba ulang sampai elemen muncul (maks ±1,2 detik).
    let percobaan = 0;
    let timer: ReturnType<typeof setTimeout>;
    const gambar = () => {
      const canvas = canvasRef.current;
      if (!canvas) {
        if (percobaan++ < 30) timer = setTimeout(gambar, 40);
        return;
      }
      timer = setTimeout(() => gambarKartu(canvas), 0);
    };
    gambar();
    return () => clearTimeout(timer);
  }, [fase, hasil]);

  const gambarKartu = (canvas: HTMLCanvasElement) => {
    const hasilKini = hasil;
    if (!hasilKini) return;
    const W = 1080;
    const H = 1440;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d")!;
    // latar gradien gelap
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#141428");
    g.addColorStop(0.5, "#131318");
    g.addColorStop(1, "#0c0a1f");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    // bingkai ganda
    ctx.strokeStyle = "#ef4444";
    ctx.lineWidth = 6;
    ctx.strokeRect(30, 30, W - 60, H - 60);
    ctx.strokeStyle = "rgba(168,85,247,0.35)";
    ctx.lineWidth = 2;
    ctx.strokeRect(50, 50, W - 100, H - 100);

    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    // kepala
    ctx.fillStyle = "#ffffff";
    ctx.font = "800 44px Inter, sans-serif";
    ctx.fillText("HASIL TES IQ", W / 2, 130);
    ctx.fillStyle = "rgba(255,255,255,0.5)";
    ctx.font = "500 24px 'Archivo Narrow', sans-serif";
    ctx.fillText("FanzzTools V2 • Tes IQ • Gunakan dengan bijak", W / 2, 175);

    // angka IQ besar
    const kat = kategoriIq(hasil.iq);
    ctx.fillStyle = kat.warna;
    ctx.font = "900 200px Inter, sans-serif";
    ctx.fillText(String(hasil.iq), W / 2, 400);
    ctx.font = "700 40px Inter, sans-serif";
    ctx.fillText(kat.label.toUpperCase(), W / 2, 530);
    // persentil
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "600 30px Inter, sans-serif";
    ctx.fillText(`Perkiraan persentil: ${hasil.persentil.toFixed(1)}  •  lebih tinggi dari ~${hasil.persentil.toFixed(0)}% populasi`, W / 2, 590);

    // statistik baris
    ctx.font = "500 26px Inter, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.75)";
    const benarPersen = ((hasil.skorTertimbang / hasil.maksTertimbang) * 100).toFixed(1);
    ctx.fillText(`Benar: ${hasil.benar}/${hasil.total}  •  Skor berbobot: ${benarPersen}%`, W / 2, 660);
    ctx.fillText(`Durasi: ${Math.floor(hasil.durasiDetik / 60)}m ${hasil.durasiDetik % 60}d  •  ${hasil.total} soal`, W / 2, 705);

    // rincian kategori
    ctx.fillStyle = "#ffffff";
    ctx.font = "700 30px Inter, sans-serif";
    ctx.fillText("RINCIAN PER KATEGORI", W / 2, 790);
    let y = 850;
    for (const k of hasil.perKategori) {
      ctx.textAlign = "left";
      ctx.fillStyle = "rgba(255,255,255,0.8)";
      ctx.font = "500 26px Inter, sans-serif";
      ctx.fillText(k.nama, 140, y);
      // bar
      const bw = 520;
      const bx = 420;
      ctx.fillStyle = "rgba(255,255,255,0.12)";
      ctx.fillRect(bx, y - 12, bw, 24);
      const pct = k.total ? k.benar / k.total : 0;
      const bg = ctx.createLinearGradient(bx, 0, bx + bw, 0);
      bg.addColorStop(0, "#ef4444");
      bg.addColorStop(1, "#22d3ee");
      ctx.fillStyle = bg;
      ctx.fillRect(bx, y - 12, bw * pct, 24);
      ctx.textAlign = "right";
      ctx.fillStyle = "#ffffff";
      ctx.font = "600 24px Inter, sans-serif";
      ctx.fillText(`${k.benar}/${k.total}`, W - 140, y);
      y += 62;
    }

    // disclaimer
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.font = "500 21px 'Archivo Narrow', sans-serif";
    const disk = [
      "DISCLAIMER: hasil ini adalah perkiraan berbasis statistik terkalibrasi kasar —",
      "BUKAN diagnosis resmi. Penilaian IQ resmi hanya dapat dilakukan",
      "psikolog berlisensi (WAIS, WISC, Stanford-Binet).",
    ];
    disk.forEach((l, i) => ctx.fillText(l, W / 2, H - 180 + i * 32));
    ctx.fillStyle = "rgba(168,85,247,0.9)";
    ctx.font = "700 24px 'Archivo Narrow', sans-serif";
    ctx.fillText("By : Fanzz-Dev. © FanzzProject — Gunakan dengan bijak!", W / 2, H - 80);
  };

  const unduhKartu = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "fanzz-tes-iq.png";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 800);
    }, "image/png");
    toast({ title: "Kartu hasil terunduh!", description: "PNG 1080×1440 dengan bingkai." });
  };

  const fmtMenit = (d: number) => `${Math.floor(d / 60)}:${String(d % 60).padStart(2, "0")}`;

  return (
    <div>
      <ToolHeader
        icon={<Brain className="h-6 w-6" />}
        title="Tes IQ"
        subtitle="75 soal berbobot (deret, logika, analogi, aritmetika) — hasil jujur & kartu PNG"
        accent="purple"
      />

      <AnimatePresence mode="wait">
        {fase === "intro" && (
          <motion.div key="intro" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mx-auto max-w-lg space-y-4">
            <div className="glass rounded-2xl p-5">
              <h3 className="text-sm font-extrabold">Sebelum mulai</h3>
              <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-muted-foreground">
                <li>• Bank soal: 75 item (deret angka, analogi verbal, logika, aritmetika, deret huruf, beda-satu) dengan 3 tingkat kesulitan berbobot.</li>
                <li>• Pilih jumlah soal — waktu 30 detik per soal, berjalan otomatis.</li>
                <li>• Soal yang tidak dijawab (termasuk saat waktu habis) dihitung salah — tidak ada yang disembunyikan.</li>
                <li>• Kerjakan sendiri tanpa bantuan mesin/agar hasil bermakna.</li>
              </ul>
              <p className="mb-1.5 mt-4 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Jumlah soal</p>
              <div className="flex gap-2">
                {PILIHAN_JUMLAH.map((n) => (
                  <button
                    key={n}
                    onClick={() => setJumlah(n)}
                    className={`flex-1 rounded-xl px-3 py-2.5 text-center text-xs font-bold transition ${
                      jumlah === n ? "bg-gradient-to-r from-blue-700 to-red-600 text-white" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {n}
                    <span className="block text-[9px] font-semibold opacity-70">{fmtMenit(n * 30)}</span>
                  </button>
                ))}
              </div>
              <button
                onClick={mulai}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-700 to-red-600 px-4 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-blue-700/25 transition-transform active:scale-95"
              >
                Mulai Tes <ChevronRight className="h-4 w-4" />
              </button>
            </div>
            <div className="flex items-start gap-2.5 rounded-2xl bg-amber-500/10 px-3.5 py-3 text-[10.5px] leading-relaxed text-amber-200">
              <Info className="mt-0.5 h-4 w-4 shrink-0" />
              <p>
                Hasil adalah <b>perkiraan statistik terkalibrasi kasar — bukan diagnosis resmi</b>. Penilaian IQ resmi hanya oleh
                psikolog berlisensi (WAIS/WISC/SB). Angka rendah tidak menentukan masa depan Anda — banyak kecerdasan lain
                yang tidak diukur tes seperti ini.
              </p>
            </div>
          </motion.div>
        )}

        {fase === "tes" && soalAktif && (
          <motion.div key="tes" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mx-auto max-w-lg space-y-4">
            {/* bar progres + timer */}
            <div className="flex items-center gap-3">
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-secondary">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-blue-700 to-red-600 transition-all"
                  style={{ width: `${((idx + 1) / soal.length) * 100}%` }}
                />
              </div>
              <span className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-xs font-extrabold tabular-nums ${sisaDetik < 60 ? "bg-red-500/15 text-red-300" : "bg-secondary text-muted-foreground"}`}>
                <Timer className="h-3.5 w-3.5" /> {fmtMenit(sisaDetik)}
              </span>
            </div>
            <p className="text-center text-[10px] font-bold text-muted-foreground">Soal {idx + 1} dari {soal.length} • {soalAktif.k} • Tingkat {soalAktif.tingkat}</p>

            {/* kartu soal */}
            <div className="glass-strong rounded-2xl p-5">
              <p className="text-center text-lg font-bold leading-relaxed">{soalAktif.teks}</p>
              <div className="mt-5 grid grid-cols-2 gap-2.5">
                {soalAktif.opsi.map((o, i) => {
                  const dipilih = jawab[idx] === i;
                  return (
                    <button
                      key={i}
                      onClick={() => setJawab((j) => j.map((x, k) => (k === idx ? i : x)))}
                      className={`rounded-xl px-3 py-3.5 text-sm font-bold transition ${
                        dipilih
                          ? "bg-gradient-to-r from-blue-700 to-red-600 text-white shadow-lg shadow-blue-700/25"
                          : "bg-secondary/70 hover:bg-secondary"
                      }`}
                    >
                      {o}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setIdx((i) => Math.max(0, i - 1))}
                disabled={idx === 0}
                className="flex-1 rounded-xl bg-secondary px-4 py-3 text-xs font-bold disabled:opacity-40"
              >
                ← Sebelumnya
              </button>
              {idx === soal.length - 1 ? (
                <button
                  onClick={() => selesai()}
                  disabled={jawab.every((j) => j === null)}
                  className="flex-[1.4] rounded-xl bg-gradient-to-r from-blue-700 to-red-600 px-4 py-3 text-xs font-extrabold text-white disabled:opacity-50"
                >
                  <span className="flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5" /> Selesai & Lihat Hasil
                  </span>
                </button>
              ) : (
                <button
                  onClick={() => setIdx((i) => Math.min(soal.length - 1, i + 1))}
                  className="flex-[1.4] rounded-xl bg-secondary px-4 py-3 text-xs font-bold"
                >
                  Berikutnya →
                </button>
              )}
            </div>
            <p className="text-center text-[10px] text-muted-foreground">Bisa dilewati — jawaban kosong dihitung salah saat waktu habis.</p>
          </motion.div>
        )}

        {fase === "hasil" && hasil && (
          <motion.div key="hasil" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mx-auto max-w-lg space-y-4">
            <div className="flex flex-col items-center gap-1 rounded-2xl glass-strong p-6 text-center">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Perkiraan IQ Anda</p>
              <p className="text-7xl font-black" style={{ color: kategoriIq(hasil.iq).warna }}>
                {hasil.iq}
              </p>
              <p className="text-sm font-extrabold" style={{ color: kategoriIq(hasil.iq).warna }}>
                {kategoriIq(hasil.iq).label}
              </p>
              <p className="text-[11px] text-muted-foreground">
                {hasil.benar}/{hasil.total} benar • skor berbobot {((hasil.skorTertimbang / hasil.maksTertimbang) * 100).toFixed(1)}% • persentil ~{hasil.persentil.toFixed(0)}
              </p>
              <p className="text-[11px] text-muted-foreground">Durasi {Math.floor(hasil.durasiDetik / 60)}m {hasil.durasiDetik % 60}d</p>
            </div>

            {/* rincian kategori */}
            <div className="glass rounded-2xl p-4">
              <p className="mb-2.5 text-[11px] font-extrabold text-blue-500">Rincian per kategori</p>
              <div className="space-y-2.5">
                {hasil.perKategori.map((k) => (
                  <div key={k.nama}>
                    <div className="mb-1 flex items-center justify-between text-[10.5px] font-bold">
                      <span>{k.nama}</span>
                      <span className="text-muted-foreground">{k.benar}/{k.total}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-secondary">
                      <div className="h-full rounded-full bg-gradient-to-r from-blue-700 to-red-600" style={{ width: `${k.total ? (k.benar / k.total) * 100 : 0}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* kartu + aksi */}
            <div className="flex items-center justify-center">
              <canvas ref={canvasRef} className="max-h-[420px] w-auto rounded-xl shadow-2xl ring-1 ring-border/40" />
            </div>
            <div className="flex gap-2">
              <button
                onClick={unduhKartu}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-700 to-red-600 px-4 py-3 text-xs font-extrabold text-white"
              >
                <Download className="h-4 w-4" /> Unduh Kartu Hasil PNG
              </button>
              <button onClick={() => setFase("intro")} className="flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-bold">
                <RefreshCw className="h-4 w-4" /> Ulangi
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
