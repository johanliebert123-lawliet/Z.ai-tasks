"use client";

import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Activity, ChevronDown, RefreshCw, Loader2, Waves, MapPin, AlertTriangle,
} from "lucide-react";

/**
 * Kartu info BMKG — permintaan #12.
 * Gempa autogempa (terbaru signifikan), gempa dirasakan, gempa terkini,
 * dan potensi peringatan (tsunami) di Indonesia — real-time dari BMKG.
 */

interface Quake {
  tanggal: string;
  jam: string;
  magnitudo: string;
  kedalaman: string;
  lintang: string;
  bujur: string;
  wilayah: string;
  potensi: string;
  dirasakan?: string;
  shakemap?: string;
}

interface BmkgData {
  auto: Quake | null;
  felt: Quake[];
  recent: Quake[];
  updatedAt: number;
}

function magColor(m: number): string {
  if (m >= 6) return "text-red-400";
  if (m >= 5) return "text-orange-400";
  if (m >= 4) return "text-amber-400";
  return "text-emerald-400";
}

function QuakeRow({ q }: { q: Quake }) {
  const m = Number(q.magnitudo) || 0;
  const isWarning = /tsunami/i.test(q.potensi || "");
  return (
    <div className="flex items-center gap-3 rounded-xl bg-secondary/40 px-3 py-2.5">
      <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-xl bg-secondary">
        <span className={`text-sm font-black leading-none ${magColor(m)}`}>{q.magnitudo}</span>
        <span className="text-[7px] font-bold text-muted-foreground">SR</span>
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-[11px] font-bold leading-tight">{q.wilayah}</p>
        <p className="mt-0.5 flex items-center gap-1.5 text-[9px] text-muted-foreground">
          <MapPin className="h-2.5 w-2.5 shrink-0" />
          {q.tanggal} {q.jam} • {q.kedalaman}
          {q.dirasakan ? ` • dirasakan: ${q.dirasakan}` : ""}
        </p>
        {isWarning && (
          <p className="mt-0.5 flex items-center gap-1 text-[9px] font-bold text-red-400">
            <Waves className="h-2.5 w-2.5" /> {q.potensi}
          </p>
        )}
      </div>
    </div>
  );
}

export default function BmkgCard() {
  const [open, setOpen] = useState(false);
  const [data, setData] = useState<BmkgData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const r = await fetch("/api/bmkg");
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Data BMKG tidak dapat diambil");
      setData({ auto: d.auto || null, felt: d.felt || [], recent: d.recent || [], updatedAt: d.updatedAt });
      setError("");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat BMKG");
    } finally {
      setLoading(false);
    }
  }, []);

  // muat saat pertama dibuka + refresh otomatis tiap 2 menit
  useEffect(() => {
    if (!open || data) return;
    load();
     
  }, [open]);

  useEffect(() => {
    const t = setInterval(() => {
      if (open) load(true);
    }, 120 * 1000);
    return () => clearInterval(t);
  }, [open, load]);

  const auto = data?.auto;
  const bigQuake = auto && (Number(auto.magnitudo) || 0) >= 5.5;
  const tsunamiWarn = auto && /tsunami/i.test(auto.potensi || "");

  return (
    <div className="mb-4 overflow-hidden rounded-2xl glass">
      <button
        onClick={() => setOpen(!open)}
        className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left"
      >
        <span className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-white ${
          tsunamiWarn || bigQuake
            ? "bg-gradient-to-br from-red-500 to-red-700 animate-pulse"
            : "bg-gradient-to-br from-teal-500 to-emerald-600"
        }`}>
          <Activity className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="flex items-center gap-1.5 text-xs font-extrabold">
            Info BMKG & Tanda Bahaya
            {(tsunamiWarn || bigQuake) && (
              <span className="flex items-center gap-0.5 rounded-full bg-red-500/20 px-1.5 py-px text-[8px] font-extrabold text-red-300">
                <AlertTriangle className="h-2.5 w-2.5" /> WASPADA
              </span>
            )}
          </p>
          <p className="truncate text-[10px] text-muted-foreground">
            {auto
              ? `Gempa terbaru: M${auto.magnitudo} — ${auto.wilayah.slice(0, 48)}`
              : "Gempa real-time, dirasakan & potensi tsunami Indonesia"}
          </p>
        </div>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-t border-[var(--surface-line)]"
          >
            <div className="space-y-3 p-3.5">
              {/* tombol refresh */}
              <div className="flex items-center justify-between">
                <p className="text-[10px] font-bold text-muted-foreground">
                  {data ? `Diperbarui ${new Date(data.updatedAt).toLocaleTimeString("id-ID")} • sumber resmi BMKG` : "Memuat…"}
                </p>
                <button
                  onClick={() => load()}
                  className="flex items-center gap-1 rounded-lg px-2 py-1 text-[10px] font-bold text-muted-foreground transition-colors hover:text-emerald-300"
                >
                  {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />} Muat ulang
                </button>
              </div>

              {error && (
                <p className="rounded-xl bg-amber-500/10 px-3 py-2.5 text-[11px] leading-relaxed text-amber-300">{error}</p>
              )}

              {/* gempa signifikan terbaru */}
              {auto && (
                <div className={`rounded-xl p-3.5 ${bigQuake ? "bg-red-500/10 ring-1 ring-red-400/30" : "bg-secondary/40"}`}>
                  <p className="mb-1 text-[9px] font-extrabold uppercase tracking-wider text-muted-foreground">
                    Gempa terbaru (signifikan)
                  </p>
                  <div className="flex items-baseline gap-2">
                    <span className={`text-2xl font-black ${magColor(Number(auto.magnitudo))}`}>M{auto.magnitudo}</span>
                    <span className="text-[10px] text-muted-foreground">{auto.tanggal} • {auto.jam} WIB</span>
                  </div>
                  <p className="mt-1 text-[11px] font-bold leading-tight">{auto.wilayah}</p>
                  <p className="mt-0.5 text-[10px] text-muted-foreground">
                    Kedalaman {auto.kedalaman} • {auto.lintang}, {auto.bujur}
                  </p>
                  <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{auto.potensi}</p>
                  {auto.shakemap && (
                    <img
                      src={auto.shakemap}
                      alt="Peta guncangan"
                      className="mt-2 w-full max-w-sm rounded-xl"
                      referrerPolicy="no-referrer"
                    />
                  )}
                </div>
              )}

              {/* gempa dirasakan */}
              {data?.felt?.length ? (
                <div>
                  <p className="mb-1.5 text-[9px] font-extrabold uppercase tracking-wider text-muted-foreground">
                    Gempa dirasakan ({data.felt.length})
                  </p>
                  <div className="space-y-1.5">
                    {data.felt.slice(0, 5).map((q, i) => <QuakeRow key={i} q={q} />)}
                  </div>
                </div>
              ) : null}

              {/* gempa terkini */}
              {data?.recent?.length ? (
                <div>
                  <p className="mb-1.5 text-[9px] font-extrabold uppercase tracking-wider text-muted-foreground">
                    Gempa terkini ({data.recent.length})
                  </p>
                  <div className="space-y-1.5">
                    {data.recent.slice(0, 6).map((q, i) => <QuakeRow key={i} q={q} />)}
                  </div>
                </div>
              ) : null}

              <p className="text-[9px] leading-relaxed text-muted-foreground">
                Data resmi Meteorologi, Klimatologi, dan Geofisika (BMKG) — diperbarui otomatis.
                Untuk peringatan tsunami resmi selalu ikuti kanal BMKG / BNPB.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
