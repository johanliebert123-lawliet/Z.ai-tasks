"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import { loadImageFromFile } from "@/components/tools/image-studio/lib";
import {
  Sparkles, Upload, Loader2, Download, Columns2, Ratio, SlidersHorizontal,
  Images, ArrowLeftRight, Wand2, Info,
} from "lucide-react";

/**
 * Image HD (V2.11 #23) — prosesor gambar ala aplikasi HD:
 *  - peningkatan resolusi bertahap sampai 8K + penajaman (unsharp mask)
 *  - konversi rasio dengan sisi blur (9:16 ↔ 16:9 dll)
 *  - gabungan 2-4 foto dalam satu gambar
 *  - slider banding sebelum/sesudah
 *  - ekspor PNG / JPG / WebP
 *
 * JUJUR (bukan pembodohan): ini penajaman + peningkatan resolusi piksel di
 * perangkat — bukan AI generatif yang "menebak" detail baru. Teks asli tidak
 * dijamin lebih jelas seperti sihir; hasilnya tergantung kualitas foto asal.
 */

type TabId = "hd" | "ratio" | "collage";

const RESOLUSI: Array<{ label: string; sisiPanjang: number }> = [
  { label: "Asli", sisiPanjang: 0 },
  { label: "2K", sisiPanjang: 2560 },
  { label: "3K", sisiPanjang: 3072 },
  { label: "4K", sisiPanjang: 4096 },
  { label: "5K", sisiPanjang: 5120 },
  { label: "6K", sisiPanjang: 6144 },
  { label: "8K", sisiPanjang: 7680 },
];

const RASIO: Array<{ label: string; w: number; h: number }> = [
  { label: "9:16", w: 9, h: 16 },
  { label: "16:9", w: 16, h: 9 },
  { label: "1:1", w: 1, h: 1 },
  { label: "4:5", w: 4, h: 5 },
  { label: "3:4", w: 3, h: 4 },
  { label: "4:3", w: 4, h: 3 },
  { label: "21:9", w: 21, h: 9 },
];

const FORMAT: Array<{ label: string; tipe: string; ekst: string }> = [
  { label: "PNG", tipe: "image/png", ekst: "png" },
  { label: "JPG", tipe: "image/jpeg", ekst: "jpg" },
  { label: "WebP", tipe: "image/webp", ekst: "webp" },
];

/** Penajaman unsharp-mask berbasis blur kanvas (cepat di perangkat). */
function unsharp(canvas: HTMLCanvasElement, jumlah: number) {
  if (jumlah <= 0) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  // salinan blur
  const blur = document.createElement("canvas");
  blur.width = W;
  blur.height = H;
  const bctx = blur.getContext("2d");
  if (!bctx) return;
  try {
    bctx.filter = `blur(${Math.max(1, Math.round(Math.min(W, H) / 500))}px)`;
    bctx.drawImage(canvas, 0, 0);
  } catch {
    return; // peramban tanpa filter — lewati penajaman
  }
  const asli = ctx.getImageData(0, 0, W, H);
  const buram = bctx.getImageData(0, 0, W, H);
  const a = asli.data;
  const b = buram.data;
  const k = jumlah * 1.5; // kekuatan
  for (let i = 0; i < a.length; i += 4) {
    a[i] = Math.max(0, Math.min(255, a[i] + (a[i] - b[i]) * k));
    a[i + 1] = Math.max(0, Math.min(255, a[i + 1] + (a[i + 1] - b[i + 1]) * k));
    a[i + 2] = Math.max(0, Math.min(255, a[i + 2] + (a[i + 2] - b[i + 2]) * k));
  }
  ctx.putImageData(asli, 0, 0);
}

/** Naikkan resolusi bertahap (2x per langkah) — hasil lebih halus daripada sekali tarik. */
function upscaleBertahap(src: CanvasImageSource, sw: number, sh: number, targetW: number, targetH: number): HTMLCanvasElement {
  let curW = sw;
  let curH = sh;
  let cur = document.createElement("canvas");
  cur.width = curW;
  cur.height = curH;
  const cctx = cur.getContext("2d")!;
  cctx.imageSmoothingEnabled = true;
  cctx.imageSmoothingQuality = "high";
  cctx.drawImage(src, 0, 0);

  while (curW * 2 <= targetW) {
    const next = document.createElement("canvas");
    next.width = curW * 2;
    next.height = curH * 2;
    const nctx = next.getContext("2d")!;
    nctx.imageSmoothingEnabled = true;
    nctx.imageSmoothingQuality = "high";
    nctx.drawImage(cur, 0, 0, next.width, next.height);
    cur = next;
    curW = next.width;
    curH = next.height;
  }
  // langkah akhir ke ukuran tepat
  const final = document.createElement("canvas");
  final.width = targetW;
  final.height = targetH;
  const fctx = final.getContext("2d")!;
  fctx.imageSmoothingEnabled = true;
  fctx.imageSmoothingQuality = "high";
  fctx.drawImage(cur, 0, 0, targetW, targetH);
  return final;
}

export default function HdImageView() {
  const [tab, setTab] = useState<TabId>("hd");
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [namaFile, setNamaFile] = useState("");
  const [resolusi, setResolusi] = useState(3); // default 4K
  const [penajaman, setPenajaman] = useState(0.6);
  const [kontras, setKontras] = useState(1.06);
  const [saturasi, setSaturasi] = useState(1.08);
  const [proses, setProses] = useState(false);
  const [siapUnduh, setSiapUnduh] = useState<Blob | null>(null);
  const [infoHasil, setInfoHasil] = useState("");
  const [formatIdx, setFormatIdx] = useState(1); // JPG

  // rasio
  const [rasioIdx, setRasioIdx] = useState(1); // 16:9
  const [blurKuat, setBlurKuat] = useState(40);

  // collage
  const [fotoTambahan, setFotoTambahan] = useState<Array<{ img: HTMLImageElement; nama: string }>>([]);
  const [tataLetak, setTataLetak] = useState<"2samping" | "3baris" | "4grid">("4grid");

  // banding sebelum/sesudah
  const [bandingPos, setBandingPos] = useState(50);
  const bandingRef = useRef<HTMLDivElement | null>(null);
  const dragBanding = useRef(false);

  const [canvasHasil] = useState<HTMLCanvasElement>(() => typeof document === "undefined" ? ({} as HTMLCanvasElement) : document.createElement("canvas"));
  const pratinjauRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const onFile = async (f: File | null) => {
    if (!f) return;
    try {
      const im = await loadImageFromFile(f);
      setImg(im);
      setNamaFile(f.name.replace(/\.[^.]+$/, ""));
      setSiapUnduh(null);
      setInfoHasil("");
    } catch {
      toast({ title: "Gambar gagal dimuat", variant: "destructive" });
    }
  };

  const onFotoTambahan = async (f: File | null) => {
    if (!f) return;
    if (fotoTambahan.length >= 3) {
      toast({ title: "Maksimal 4 foto (1 utama + 3 tambahan)", variant: "destructive" });
      return;
    }
    try {
      const im = await loadImageFromFile(f);
      setFotoTambahan((arr) => [...arr, { img: im, nama: f.name.replace(/\.[^.]+$/, "") }]);
    } catch {
      toast({ title: "Foto tambahan gagal dimuat", variant: "destructive" });
    }
  };

  /* ---------- jalankan pemrosesan ---------- */
  const prosesGambar = useCallback(async () => {
    if (!img || proses) return;
    setProses(true);
    setSiapUnduh(null);
    await new Promise((r) => setTimeout(r, 30)); // beri kesempatan UI memperbarui
    try {
      let out = canvasHasil;
      if (tab === "collage") {
        const semua = [img, ...fotoTambahan.map((f) => f.img)].slice(0, 4);
        const n = semua.length;
        const tinggi = 1600;
        let kolom = 2;
        let baris = 2;
        if (tataLetak === "2samping" || n === 2) {
          kolom = n;
          baris = 1;
        } else if (tataLetak === "3baris") {
          kolom = 1;
          baris = n;
        } else {
          kolom = 2;
          baris = Math.ceil(n / 2);
        }
        const cw = 1200;
        const ch = tinggi;
        const celW = Math.floor(cw / kolom);
        const celH = Math.floor(ch / baris);
        out.width = cw;
        out.height = ch;
        const ctx = out.getContext("2d")!;
        ctx.fillStyle = "#101014";
        ctx.fillRect(0, 0, cw, ch);
        semua.forEach((im, i) => {
          const cx = (i % kolom) * celW;
          const cy = Math.floor(i / kolom) * celH;
          // cover ke sel
          const skala = Math.max(celW / im.width, celH / im.height);
          const dw = im.width * skala;
          const dh = im.height * skala;
          ctx.drawImage(im, cx + (celW - dw) / 2, cy + (celH - dh) / 2, dw, dh);
        });
        // pemisah tipis
        ctx.strokeStyle = "rgba(255,255,255,0.25)";
        ctx.lineWidth = 6;
        for (let i = 1; i < kolom; i++) {
          ctx.beginPath();
          ctx.moveTo(i * celW, 0);
          ctx.lineTo(i * celW, ch);
          ctx.stroke();
        }
        for (let i = 1; i < baris; i++) {
          ctx.beginPath();
          ctx.moveTo(0, i * celH);
          ctx.lineTo(cw, i * celH);
          ctx.stroke();
        }
        setInfoHasil(`${n} foto digabung — 1200×${ch}`);
      } else {
        // rasio target (tab rasio) atau rasio asli (tab hd)
        let targetW: number;
        let targetH: number;
        if (tab === "ratio") {
          const r = RASIO[rasioIdx];
          const panjang = 2400;
          targetW = r.w >= r.h ? panjang : Math.round((panjang * r.w) / r.h);
          targetH = r.h >= r.w ? panjang : Math.round((panjang * r.h) / r.w);
        } else {
          targetW = img.width;
          targetH = img.height;
          const target = RESOLUSI[resolusi].sisiPanjang;
          if (target > 0) {
            const faktor = target / Math.max(img.width, img.height);
            targetW = Math.round(img.width * faktor);
            targetH = Math.round(img.height * faktor);
          }
        }

        const target = RESOLUSI[resolusi].sisiPanjang;
        if (tab === "hd" && target > 0) {
          out = upscaleBertahap(img, img.width, img.height, targetW, targetH);
        } else {
          out.width = targetW;
          out.height = targetH;
          const ctx = out.getContext("2d")!;
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high";
          if (tab === "ratio") {
            // latar: versi blur + zoom (fill penuh)
            const blurCv = document.createElement("canvas");
            blurCv.width = targetW;
            blurCv.height = targetH;
            const bctx = blurCv.getContext("2d")!;
            try {
              bctx.filter = `blur(${blurKuat}px) saturate(1.25)`;
            } catch {
              bctx.filter = "none";
            }
            const skalaBlur = Math.max(targetW / img.width, targetH / img.height) * 1.15;
            const bdw = img.width * skalaBlur;
            const bdh = img.height * skalaBlur;
            bctx.drawImage(img, (targetW - bdw) / 2, (targetH - bdh) / 2, bdw, bdh);
            ctx.drawImage(blurCv, 0, 0);
            // foto asli rasio tetap di tengah
            const skala = Math.min(targetW / img.width, targetH / img.height) * 0.97;
            const dw = img.width * skala;
            const dh = img.height * skala;
            ctx.drawImage(img, (targetW - dw) / 2, (targetH - dh) / 2, dw, dh);
          } else {
            ctx.drawImage(img, 0, 0, targetW, targetH);
          }
        }

        // penajaman + penyetelan warna
        unsharp(out, penajaman);
        const fctx = out.getContext("2d")!;
        if (kontras !== 1 || saturasi !== 1) {
          try {
            fctx.filter = `contrast(${kontras}) saturate(${saturasi})`;
            // terapkan ke salinan sendiri
            const salin = document.createElement("canvas");
            salin.width = out.width;
            salin.height = out.height;
            salin.getContext("2d")!.drawImage(out, 0, 0);
            fctx.filter = "none";
            fctx.clearRect(0, 0, out.width, out.height);
            fctx.filter = `contrast(${kontras}) saturasi(${saturasi})`.replace("saturasi", "saturate");
            fctx.drawImage(salin, 0, 0);
            fctx.filter = "none";
          } catch {
            /* filter tidak didukung — biarkan tanpa penyetelan */
          }
        }
        setInfoHasil(`${out.width}×${out.height} piksel — ${((out.width * out.height) / 1e6).toFixed(1)} MP`);
      }

      // pratinjau di layar (maks 720px panjang supaya ringan)
      const pv = pratinjauRef.current;
      if (pv) {
        const pScale = Math.min(1, 720 / Math.max(out.width, out.height));
        pv.width = Math.max(1, Math.round(out.width * pScale));
        pv.height = Math.max(1, Math.round(out.height * pScale));
        const pctx = pv.getContext("2d")!;
        pctx.imageSmoothingQuality = "high";
        pctx.drawImage(out, 0, 0, pv.width, pv.height);
      }

      // siapkan blob ekspor
      const fmt = FORMAT[formatIdx];
      const blob = await new Promise<Blob | null>((resolve) =>
        out.toBlob((b) => resolve(b), fmt.tipe, fmt.tipe === "image/png" ? undefined : 0.92),
      );
      if (!blob) throw new Error("Gagal membuat berkas");
      setSiapUnduh(blob);
      pushHistory("hdimage", {
        id: `hd-${Date.now()}`,
        title: "Image HD",
        subtitle: infoHasil || `${out.width}×${out.height}`,
      });
      toast({ title: "Gambar siap!", description: `${out.width}×${out.height} — tinggal unduh.` });
    } catch (e) {
      toast({
        title: "Pemrosesan gagal",
        description: e instanceof Error ? e.message : "Coba resolusi lebih kecil (perangkat mungkin kehabisan memori).",
        variant: "destructive",
      });
    } finally {
      setProses(false);
    }
  }, [img, fotoTambahan, tataLetak, resolusi, penajaman, kontras, saturasi, rasioIdx, blurKuat, formatIdx, proses, infoHasil, canvasHasil]);

  const unduh = () => {
    if (!siapUnduh) return;
    const fmt = FORMAT[formatIdx];
    const url = URL.createObjectURL(siapUnduh);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${namaFile || "fanzz"}-hd.${fmt.ekst}`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 800);
  };

  /* ---------- pembanding: geser pembatas ---------- */
  useEffect(() => {
    const gerak = (e: PointerEvent) => {
      if (!dragBanding.current || !bandingRef.current) return;
      const rect = bandingRef.current.getBoundingClientRect();
      setBandingPos(Math.max(2, Math.min(98, ((e.clientX - rect.left) / rect.width) * 100)));
    };
    const lepas = () => {
      dragBanding.current = false;
    };
    window.addEventListener("pointermove", gerak);
    window.addEventListener("pointerup", lepas);
    return () => {
      window.removeEventListener("pointermove", gerak);
      window.removeEventListener("pointerup", lepas);
    };
  }, []);

  return (
    <div>
      <ToolHeader
        icon={<Sparkles className="h-6 w-6" />}
        title="Image HD"
        subtitle="HD-kan foto: resolusi sampai 8K, rasio blur ala Wink, gabung 2-4 foto — diproses di perangkat"
        accent="cyan"
      />

      {/* info jujur */}
      <div className="mb-4 flex items-start gap-2.5 rounded-2xl bg-cyan-500/10 px-3.5 py-2.5 text-[11px] leading-snug text-cyan-200">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        <p>
          <b>Jujur soal cara kerjanya:</b> peningkatan resolusi piksel + penajaman (unsharp) di perangkat Anda —
          bukan AI yang mencipta detail baru. Foto yang sudah sangat buram tetap ada batasnya.
        </p>
      </div>

      {/* tab */}
      <div className="mb-4 flex gap-2">
        {([
          { id: "hd", label: "HD / Resolusi", icon: Wand2 },
          { id: "ratio", label: "Rasio Blur", icon: Ratio },
          { id: "collage", label: "Gabung Foto", icon: Images },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => {
              setTab(t.id);
              setSiapUnduh(null);
            }}
            className={`relative flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === t.id && <motion.span layoutId="hd-tab" className="absolute inset-0 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      {/* unggah */}
      {!img ? (
        <label className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-border/70 bg-secondary/30 py-14 text-center transition hover:border-cyan-400/50">
          <Upload className="h-9 w-9 text-cyan-400" />
          <div>
            <p className="text-sm font-bold">Unggah foto yang mau di-HD-kan</p>
            <p className="mt-1 text-xs text-muted-foreground">JPG / PNG / WebP — diproses langsung di perangkat Anda</p>
          </div>
          <input type="file" accept="image/*" className="hidden" onChange={(e) => onFile(e.target.files?.[0] || null)} />
        </label>
      ) : (
        <div className="grid gap-5 lg:grid-cols-[330px_1fr]">
          {/* panel kontrol */}
          <div className="glass rounded-2xl p-4">
            <div className="mb-2 flex items-center gap-2">
              <img src={img.src} alt="" className="h-10 w-10 rounded-lg object-cover" />
              <div className="min-w-0">
                <p className="truncate text-xs font-bold">{namaFile || "foto"}</p>
                <p className="text-[10px] text-muted-foreground">asli: {img.width}×{img.height}</p>
              </div>
              <button onClick={() => { setImg(null); setFotoTambahan([]); setSiapUnduh(null); }} className="ml-auto rounded-lg bg-secondary p-1.5 text-muted-foreground hover:text-foreground" title="Ganti foto">
                <ArrowLeftRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {tab === "hd" && (
              <>
                <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Resolusi target</p>
                <div className="flex flex-wrap gap-1.5">
                  {RESOLUSI.map((r, i) => (
                    <button
                      key={r.label}
                      onClick={() => setResolusi(i)}
                      className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                        resolusi === i ? "bg-gradient-to-r from-cyan-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
                <p className="mb-1 mt-4 flex items-center gap-1.5 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">
                  <SlidersHorizontal className="h-3 w-3" /> Penajaman: {penajaman.toFixed(1)}x
                </p>
                <input type="range" min={0} max={1.5} step={0.1} value={penajaman} onChange={(e) => setPenajaman(Number(e.target.value))} className="w-full" />
                <p className="mb-1 mt-2 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Kontras: {kontras.toFixed(2)}</p>
                <input type="range" min={0.9} max={1.4} step={0.01} value={kontras} onChange={(e) => setKontras(Number(e.target.value))} className="w-full" />
                <p className="mb-1 mt-2 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Saturasi: {saturasi.toFixed(2)}</p>
                <input type="range" min={0.8} max={1.6} step={0.01} value={saturasi} onChange={(e) => setSaturasi(Number(e.target.value))} className="w-full" />
              </>
            )}

            {tab === "ratio" && (
              <>
                <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Rasio tujuan</p>
                <div className="flex flex-wrap gap-1.5">
                  {RASIO.map((r, i) => (
                    <button
                      key={r.label}
                      onClick={() => setRasioIdx(i)}
                      className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                        rasioIdx === i ? "bg-gradient-to-r from-cyan-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {r.label}
                    </button>
                  ))}
                </div>
                <p className="mt-3 rounded-xl bg-secondary/60 px-3 py-2 text-[10px] leading-snug text-muted-foreground">
                  Foto asli tetap di tengah dengan rasio aslinya; sisi yang kosong diisi versi blur — persis gaya aplikasi HD.
                </p>
                <p className="mb-1 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Kekuatan blur: {blurKuat}px</p>
                <input type="range" min={10} max={90} step={5} value={blurKuat} onChange={(e) => setBlurKuat(Number(e.target.value))} className="w-full" />
              </>
            )}

            {tab === "collage" && (
              <>
                <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Tata letak ({fotoTambahan.length + 1} foto)</p>
                <div className="flex flex-wrap gap-1.5">
                  {([
                    { id: "2samping", label: "Bersebelahan" },
                    { id: "3baris", label: "Susun Vertikal" },
                    { id: "4grid", label: "Kotak 2×2" },
                  ] as const).map((l) => (
                    <button
                      key={l.id}
                      onClick={() => setTataLetak(l.id)}
                      className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                        tataLetak === l.id ? "bg-gradient-to-r from-cyan-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {l.label}
                    </button>
                  ))}
                </div>
                {fotoTambahan.length < 3 && (
                  <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border/70 bg-secondary/30 px-3 py-3 text-[11px] font-bold text-muted-foreground transition hover:border-cyan-400/50 hover:text-foreground">
                    <Columns2 className="h-4 w-4" /> Tambah foto ({fotoTambahan.length + 1}/4)
                    <input type="file" accept="image/*" className="hidden" onChange={(e) => onFotoTambahan(e.target.files?.[0] || null)} />
                  </label>
                )}
                {fotoTambahan.length > 0 && (
                  <div className="mt-2 flex gap-2">
                    {fotoTambahan.map((f, i) => (
                      <button
                        key={i}
                        onClick={() => setFotoTambahan((arr) => arr.filter((_, j) => j !== i))}
                        className="group relative h-14 w-14 overflow-hidden rounded-lg"
                        title="Hapus foto ini"
                      >
                        <img src={f.img.src} alt="" className="h-full w-full object-cover" />
                        <span className="absolute inset-0 flex items-center justify-center bg-black/60 text-xs font-bold text-white opacity-0 transition group-hover:opacity-100">×</span>
                      </button>
                    ))}
                  </div>
                )}
              </>
            )}

            {/* format ekspor */}
            <p className="mb-1.5 mt-4 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">Format unduhan</p>
            <div className="flex gap-1.5">
              {FORMAT.map((f, i) => (
                <button
                  key={f.label}
                  onClick={() => setFormatIdx(i)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                    formatIdx === i ? "bg-gradient-to-r from-cyan-500 to-teal-600 text-white" : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <button
              onClick={prosesGambar}
              disabled={proses}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-4 py-3 text-xs font-extrabold text-white shadow-lg shadow-cyan-500/20 transition-transform active:scale-95 disabled:opacity-60"
            >
              {proses ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {proses ? "Memproses…" : "Proses Sekarang"}
            </button>
            {siapUnduh && (
              <button
                onClick={unduh}
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold transition-colors hover:bg-secondary/70"
              >
                <Download className="h-4 w-4 text-cyan-400" /> Unduh {FORMAT[formatIdx].label} {infoHasil ? `(${infoHasil.split(" — ")[0]})` : ""}
              </button>
            )}
          </div>

          {/* area hasil */}
          <div className="flex flex-col items-center gap-3">
            {siapUnduh ? (
              /* pembanding sebelum/sesudah — digeser */
              <div
                ref={bandingRef}
                className="relative w-full max-w-[560px] select-none overflow-hidden rounded-2xl ring-1 ring-border/40"
                onPointerDown={(e) => {
                  dragBanding.current = true;
                  const rect = e.currentTarget.getBoundingClientRect();
                  setBandingPos(Math.max(2, Math.min(98, ((e.clientX - rect.left) / rect.width) * 100)));
                }}
              >
                {/* hasil (dasar) */}
                <canvas ref={pratinjauRef} className="block h-auto w-full" />
                {/* asli (klip kiri) */}
                <div className="absolute inset-0 overflow-hidden" style={{ width: `${bandingPos}%` }}>
                  <img src={img.src} alt="asli" className="h-full w-full object-cover" style={{ width: bandingRef.current ? `${bandingRef.current.clientWidth}px` : "100%" }} />
                </div>
                {/* garis pembanding */}
                <div className="absolute inset-y-0" style={{ left: `${bandingPos}%` }}>
                  <div className="h-full w-0.5 bg-white shadow-[0_0_10px_rgba(0,0,0,0.5)]" />
                  <div className="absolute top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white px-2 py-1 text-[9px] font-extrabold text-black shadow-lg">
                    ↔ geser
                  </div>
                </div>
                <span className="absolute left-2 top-2 rounded-md bg-black/60 px-1.5 py-0.5 text-[9px] font-bold text-white">ASLI</span>
                <span className="absolute right-2 top-2 rounded-md bg-cyan-500/80 px-1.5 py-0.5 text-[9px] font-bold text-white">HASIL HD</span>
              </div>
            ) : (
              <div className="flex w-full max-w-[420px] flex-col items-center gap-3 rounded-2xl border border-dashed border-border/60 bg-secondary/20 py-14 text-center">
                <Wand2 className="h-8 w-8 text-cyan-400/60" />
                <p className="text-xs font-bold text-muted-foreground">Atur pengaturan lalu tekan “Proses Sekarang”</p>
                <p className="text-[10px] text-muted-foreground/70">Hasil akan muncul di sini dengan pembanding geser</p>
              </div>
            )}
            {siapUnduh && infoHasil && (
              <p className="text-[11px] font-bold text-cyan-300">{infoHasil} — geser garis pembanding untuk membandingkan</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
