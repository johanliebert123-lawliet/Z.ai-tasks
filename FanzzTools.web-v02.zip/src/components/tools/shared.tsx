"use client";

import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";

/** Logo resmi FanzzTools — SVG buatan sendiri (bukan emoji):
 *  huruf "F" tegas dalam perisai heksagonal miring dengan aksen
 *  sinyal cyan — identitas gradient lava-red → deep-blue (tema FanzzTools). */
export function FanzzLogo({ className = "h-9 w-9", mark = false }: { className?: string; mark?: boolean }) {
  const gid = mark ? "fanzz-lg" : "fanzz-lg2";
  return (
    <svg viewBox="0 0 48 48" className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={gid} x1="8" y1="4" x2="40" y2="44" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#ef4444" />
          <stop offset="0.55" stopColor="#b91c1c" />
          <stop offset="1" stopColor="#1e3a8a" />
        </linearGradient>
      </defs>
      {/* perisai heksagonal miring — karakter cyber/security */}
      <path d="M23.2 4.6 38.4 12a4.6 4.6 0 0 1 2.6 4.2v15.6a4.6 4.6 0 0 1-2.6 4.2l-15.2 7.4a4.4 4.4 0 0 1-3.9 0L4.9 36A4.6 4.6 0 0 1 2.3 31.8V16.2A4.6 4.6 0 0 1 4.9 12l14.4-7.4a4.4 4.4 0 0 1 3.9 0Z" fill={`url(#${gid})`} />
      {/* huruf F tegas */}
      <path d="M18.6 13.2h13.4M18.6 13.2v21.6M18.6 23.6h9.8" stroke="#fff" strokeWidth="3.6" strokeLinecap="round" strokeLinejoin="round" />
      {/* aksen sinyal cyan — pulsa kecil di kanan atas */}
      <path d="M36.2 10.4a3.4 3.4 0 0 1 1.9 1.9" stroke="#22d3ee" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M35.1 6.7a7 7 0 0 1 3.9 3.9" stroke="#22d3ee" strokeWidth="2.2" strokeLinecap="round" opacity="0.7" />
      {/* titik terminal cyan di pangkal F */}
      <circle cx="18.6" cy="36.2" r="2.1" fill="#22d3ee" />
    </svg>
  );
}

export function ToolHeader({
  icon,
  title,
  subtitle,
  accent = "fuchsia",
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  accent?: "fuchsia" | "emerald" | "amber" | "cyan" | "indigo" | "red" | "blue";
}) {
  const colors: Record<string, string> = {
    fuchsia: "from-red-500 to-red-700 shadow-red-500/25",
    red: "from-red-500 to-red-700 shadow-red-500/25",
    blue: "from-blue-600 to-blue-800 shadow-blue-500/25",
    emerald: "from-emerald-500 to-teal-600 shadow-emerald-500/25",
    amber: "from-amber-500 to-orange-600 shadow-amber-500/25",
    cyan: "from-cyan-500 to-teal-600 shadow-cyan-500/25",
    indigo: "from-blue-600 to-blue-600 shadow-blue-600/25",
  };
  return (
    <div className="mb-5 flex items-center gap-3.5">
      <div
        className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br text-white shadow-lg ${colors[accent]}`}
      >
        {icon}
      </div>
      <div className="min-w-0">
        <h1 className="truncate text-xl font-extrabold tracking-tight sm:text-2xl">{title}</h1>
        {subtitle && <p className="truncate text-xs text-muted-foreground sm:text-sm">{subtitle}</p>}
      </div>
    </div>
  );
}

export function MovieCard({
  title,
  poster,
  rating,
  year,
  type,
  onClick,
  index = 0,
}: {
  title: string;
  poster: string | null;
  rating?: number;
  year?: string;
  type?: string;
  onClick?: () => void;
  index?: number;
}) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: Math.min(index * 0.03, 0.5), duration: 0.35 }}
      whileHover={{ y: -5, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      onClick={onClick}
      className="group relative w-full overflow-hidden rounded-2xl text-left shadow-lg"
    >
      <div className="aspect-[2/3] w-full bg-secondary shimmer relative">
        {poster ? (
          <img
            src={poster}
            alt={title}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-muted-foreground text-xs p-2 text-center">
            {title}
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent opacity-90" />
      </div>

      {rating ? (
        <span className="absolute right-1.5 top-1.5 rounded-full bg-black/65 px-1.5 py-0.5 text-[10px] font-bold text-amber-300 backdrop-blur-sm flex items-center gap-0.5">
          ★ {rating.toFixed(1)}
        </span>
      ) : null}
      {type === "tv" ? (
        <span className="absolute left-1.5 top-1.5 rounded-md bg-red-500/90 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-white">
          Series
        </span>
      ) : null}

      <div className="absolute bottom-0 left-0 right-0 p-2.5">
        <p className="clamp-2 text-[12px] font-semibold leading-tight text-white">{title}</p>
        {year ? <p className="mt-0.5 text-[10px] text-white/60">{year}</p> : null}
      </div>
    </motion.button>
  );
}

export function CardSkeleton() {
  return (
    <div className="w-full overflow-hidden rounded-2xl">
      <Skeleton className="aspect-[2/3] w-full rounded-2xl" />
    </div>
  );
}

export function RowScroller({ children }: { children: React.ReactNode }) {
  return (
    <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-2">
      {children}
    </div>
  );
}

export function EmptyState({ icon, title, desc }: { icon: React.ReactNode; title: string; desc?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-border/60 py-14 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-secondary/60 text-muted-foreground">
        {icon}
      </div>
      <p className="text-sm font-semibold">{title}</p>
      {desc ? <p className="max-w-[280px] text-xs text-muted-foreground">{desc}</p> : null}
    </div>
  );
}
