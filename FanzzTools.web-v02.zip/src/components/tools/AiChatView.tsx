"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { getSettings, saveSettings, useApp, type AiTask } from "@/lib/app-store";
import Markdown from "@/lib/markdown";
import {
  loadSessions, newSession, upsertSession, deleteSession, loadMemory, saveMemory, memoryContext,
  type ChatSession,
} from "@/lib/ai-sessions";
import {
  Bot, Send, Globe, ImagePlus, FileText, X, Loader2, User as UserIcon,
  RefreshCw, Cpu, ChevronDown, Sparkles, Search as SearchIcon, Code2, GraduationCap, MessageSquare,
  History as HistoryIcon, Brain, Trash2, PlayCircle, ListChecks, CheckCircle2, AlertTriangle,
} from "lucide-react";

interface Msg {
  role: "user" | "assistant";
  content: string;
  model?: string;
  image?: string;
  fileName?: string;
  searched?: boolean;
}

interface ModelDef {
  id: string;
  label: string;
  badge: string;
  desc: string;
}

type AiMode = "normal" | "coding" | "learning";

const MODES: Array<{ id: AiMode; label: string; icon: React.ComponentType<{ className?: string }>; desc: string }> = [
  { id: "normal", label: "Normal", icon: MessageSquare, desc: "Chat santai, tanya apa aja" },
  { id: "coding", label: "Ngoding", icon: Code2, desc: "Engineer senior — kode lengkap siap jalan" },
  { id: "learning", label: "Belajar", icon: GraduationCap, desc: "Guru sabar — step by step + latihan" },
];

const QUICK_PROMPTS_BY_MODE: Record<AiMode, string[]> = {
  normal: [
    "Jelaskan fitur apa aja yang ada di FanzzTools",
    "Rekomendasiin film seru buat nonton malem ini",
    "Bikinin caption IG yang aesthetic",
    "Berita teknologi terbaru hari ini",
  ],
  coding: [
    "Bikinin landing page HTML+CSS keren buat portofolio",
    "Fungsi JS buat format rupiah + contoh unit test",
    "Jelaskan beda let/const/var + kapan dipakai",
    "Bikin bot Discord sederhana pakai Node.js",
  ],
  learning: [
    "Ajari aku dasar JavaScript dari nol",
    "Jelaskan cara kerja internet ke anak SMP",
    "Belajar operasi hitung pecahan step by step",
    "Kenapa langit biru? Jelasin santai",
  ],
};

export default function AiChatView() {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [models, setModels] = useState<ModelDef[]>([]);
  const [model, setModel] = useState("gpt-4.1-nano");
  const [modelOpen, setModelOpen] = useState(false);
  const [webMode, setWebMode] = useState(false);
  const [mode, setMode] = useState<AiMode>("normal");
  const [modeOpen, setModeOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [pendingImage, setPendingImage] = useState<string | null>(null);
  const [pendingFile, setPendingFile] = useState<{ name: string; content: string } | null>(null);

  /* ===== V2-new (#21): riwayat chat + ingatan + tugas latar belakang ===== */
  /** sesi aktif — null berarti belum dibuat (dibuat saat pesan pertama) */
  const [session, setSession] = useState<ChatSession | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [memoryOpen, setMemoryOpen] = useState(false);
  const [memoryText, setMemoryText] = useState("");
  /** jalankan di latar belakang — pengguna bisa pindah menu, AI tetap kerja */
  const [bgMode, setBgMode] = useState(false);
  const { aiTasks } = useApp();
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);
  const imgInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const s = getSettings();
    setModel(s.defaultModel || "gpt-4.1-nano");
    setMemoryText(loadMemory());
    setSessions(loadSessions());
    try {
      const m = localStorage.getItem("fanzz_ai_mode");
      if (m === "coding" || m === "learning") setMode(m);
    } catch {
      /* ignore */
    }
    fetch("/api/ai/chat")
      .then((r) => r.json())
      .then((d) => d?.ok && setModels(d.models))
      .catch(() => {});
    // V2 UpdSec: pertanyaan praset dari tools lain (Ruang Ibadah, dll.) — auto-isi
    try {
      const pre = localStorage.getItem("fanzz_ai_preask");
      if (pre) {
        localStorage.removeItem("fanzz_ai_preask");
        setInput(pre);
      }
    } catch {
      /* ignore */
    }
  }, []);

  /** V2-new (#21): simpan pesan ke sesi aktif (persist). */
  const persistToSession = (history: Msg[]) => {
    let s = session;
    if (!s) {
      s = newSession(model, mode);
      setSession(s);
    }
    const updated: ChatSession = { ...s, messages: history, model, mode };
    upsertSession(updated);
    setSession(updated);
    setSessions(loadSessions());
  };

  /** V2-new (#21): buka kembali sesi lama — percakapan dipulihkan & bisa dilanjutkan. */
  const openSession = (s: ChatSession) => {
    setSession(s);
    setMessages(s.messages || []);
    if (s.model) setModel(s.model);
    if (s.mode === "coding" || s.mode === "learning" || s.mode === "normal") setMode(s.mode);
    setHistoryOpen(false);
    window.scrollTo({ top: 0 });
  };

  const startNewChat = () => {
    setSession(null);
    setMessages([]);
    setHistoryOpen(false);
  };

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, busy]);

  const pickImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 4 * 1024 * 1024) {
      toast({ title: "Ukuran gambar melebihi batas", description: "Maksimal ukuran 4MB", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setPendingImage(String(reader.result));
    reader.readAsDataURL(f);
    e.target.value = "";
  };

  const pickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 512 * 1024) {
      toast({ title: "Ukuran file melebihi batas", description: "Maksimal 512KB untuk file teks", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setPendingFile({ name: f.name, content: String(reader.result).slice(0, 60000) });
    reader.readAsText(f);
    e.target.value = "";
  };

  /**
   * V2-new (#21): tugas latar belakang — request dipegang di app-store,
   * bukan di komponen. Pengguna bebas pindah menu; tugas tetap berjalan dan
   * hasilnya masuk ke riwayat sesi. (Jujur: berjalan selama web tetap terbuka.)
   */
  const runBackgroundTask = async (text: string, history: Msg[]) => {
    const store = useApp.getState();
    const task: AiTask = {
      id: `t_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      prompt: text,
      model,
      mode,
      status: "running",
      startedAt: Date.now(),
    };
    store.setAiTasks([...store.aiTasks, task]);
    setInput("");
    toast({
      title: "Tugas AI berjalan di latar belakang",
      description: "Silakan pindah menu — tugas tetap dikerjakan. Hasilnya tersimpan di Riwayat Chat.",
    });

    try {
      const memCtx = memoryContext();
      const historyPayload = [...history.slice(-12)].map((m) => ({ role: m.role, content: m.content }));
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: [...(memCtx ? [{ role: "user", content: memCtx }, { role: "assistant", content: "Baik, aku akan mengingat hal itu." }] : []), ...historyPayload],
          mode,
        }),
      });
      const data = await res.json();
      if (!data?.ok || !data.text) throw new Error(data?.error || "AI gagal menjawab");

      // simpan hasil ke sesi (lanjut sesi aktif / buat baru)
      const finalMessages: Msg[] = [
        ...history,
        { role: "assistant", content: data.text, model: data.model, at: Date.now() },
      ];
      let s = session;
      if (!s) {
        s = newSession(model, mode);
        setSession(s);
      }
      const updated = { ...s, messages: finalMessages, model, mode };
      upsertSession(updated);
      setSessions(loadSessions());

      useApp.getState().updateAiTask(task.id, {
        status: "done",
        finishedAt: Date.now(),
        answer: data.text,
        sessionId: updated.id,
      });
      toast({ title: "Tugas AI selesai", description: `${text.slice(0, 60)}… — buka Riwayat Chat untuk membaca hasilnya.` });
    } catch (e) {
      useApp.getState().updateAiTask(task.id, {
        status: "error",
        finishedAt: Date.now(),
        error: e instanceof Error ? e.message : "Tugas gagal",
      });
      toast({ title: "Tugas AI gagal", description: e instanceof Error ? e.message : "Coba lagi nanti.", variant: "destructive" });
    }
  };

  const send = async (overrideText?: string) => {
    const text = (overrideText ?? input).trim();
    if ((!text && !pendingImage && !pendingFile) || busy) return;

    // susun pesan user
    let userContent = text;
    if (pendingFile) {
      userContent += `\n\n[file: ${pendingFile.name}]\n${pendingFile.content}`;
      setPendingFile(null);
    }
    const userMsg: Msg = { role: "user", content: userContent, image: pendingImage || undefined };
    const nextHistory = [...messages, userMsg];
    setMessages(nextHistory);
    persistToSession(nextHistory);

    const image = pendingImage;
    setPendingImage(null);

    // V2-new (#21): mode latar belakang — tidak menunggu di layar
    if (bgMode && text) {
      setMessages((m) => m.slice(0, -1)); // pesan dipegang tugas, bukan chat utama
      await runBackgroundTask(text, nextHistory);
      return;
    }

    setBusy(true);
    setInput("");

    try {
      let searchContext = "";
      // mode web: cari dulu
      if (webMode && text) {
        try {
          const sr = await fetch(`/api/ai/search?q=${encodeURIComponent(text.slice(0, 100))}`);
          const sd = await sr.json();
          if (sd?.ok) {
            searchContext = sd.results
              .slice(0, 5)
              .map((r: { title: string; url: string; snippet: string }) => `[${r.title}](${r.url}) — ${r.snippet}`)
              .join("\n");
          }
        } catch {
          /* search optional */
        }
      }

      let data: { ok: boolean; text?: string; error?: string; model?: string; searched?: boolean };
      if (image) {
        // analisis gambar
        const res = await fetch("/api/ai/vision", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image, question: text || undefined }),
        });
        data = await res.json();
      } else {
        // V2-new (#21): ingatan jangka panjang disuntikkan sebagai konteks awal
        const memCtx = memoryContext();
        const memMsgs = memCtx
          ? [
              { role: "user", content: memCtx },
              { role: "assistant", content: "Baik, aku akan mengingat hal itu." },
            ]
          : [];
        const history = [...memMsgs, ...nextHistory.slice(-12)].map((m) => ({ role: m.role, content: m.content }));
        const res = await fetch("/api/ai/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model, messages: history, searchContext, mode }),
        });
        data = await res.json();
      }

      if (!data?.ok || !data.text) throw new Error(data?.error || "AI gagal menjawab");
      const finalMessages: Msg[] = [...nextHistory, { role: "assistant", content: data.text!, model: data.model, searched: !!data.searched }];
      setMessages(finalMessages);
      persistToSession(finalMessages);
    } catch (err) {
      const errMessages: Msg[] = [
        ...nextHistory,
        { role: "assistant", content: `⚠️ ${err instanceof Error ? err.message : "AI-nya error, coba kirim ulang ya"}` },
      ];
      setMessages(errMessages);
      persistToSession(errMessages);
    } finally {
      setBusy(false);
    }
  };

  const currentModel = models.find((m) => m.id === model);

  return (
    <div className="flex h-full flex-col">
      <ToolHeader icon={<Bot className="h-5.5 w-5.5" />} title="AI Chat" subtitle="3 mode • multi-model • vision • auto web" />

      {/* bar kontrol model + mode */}
      <div className="mb-3 flex items-center gap-2">
        {/* dropdown mode */}
        <div className="relative flex-1">
          <button
            onClick={() => setModeOpen(!modeOpen)}
            className="flex w-full items-center gap-2 rounded-xl glass px-3 py-2 text-left transition-colors hover:bg-secondary/70"
          >
            <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-lg ${
              mode === "coding" ? "bg-gradient-to-br from-emerald-500 to-teal-600" : mode === "learning" ? "bg-gradient-to-br from-amber-500 to-orange-600" : "bg-gradient-to-br from-red-500 to-red-700"
            } text-white`}>
              {mode === "coding" ? <Code2 className="h-3.5 w-3.5" /> : mode === "learning" ? <GraduationCap className="h-3.5 w-3.5" /> : <MessageSquare className="h-3.5 w-3.5" />}
            </span>
            <span className="min-w-0 flex-1 truncate text-xs font-bold">
              {mode === "coding" ? "Mode Ngoding" : mode === "learning" ? "Mode Belajar" : "Mode Normal"}
            </span>
            <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform ${modeOpen ? "rotate-180" : ""}`} />
          </button>
          <AnimatePresence>
            {modeOpen && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.98 }}
                className="glass-strong absolute z-40 mt-1.5 w-full overflow-hidden rounded-2xl p-1.5 shadow-2xl"
              >
                {MODES.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      setMode(m.id);
                      setModeOpen(false);
                      try {
                        localStorage.setItem("fanzz_ai_mode", m.id);
                      } catch {
                        /* ignore */
                      }
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition-colors ${
                      mode === m.id ? "bg-red-500/20" : "hover:bg-secondary/70"
                    }`}
                  >
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white">
                      <m.icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold">{m.label}</p>
                      <p className="truncate text-[10px] text-muted-foreground">{m.desc}</p>
                    </div>
                    {mode === m.id && <Sparkles className="h-3.5 w-3.5 shrink-0 text-red-400" />}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* toggle web */}
        <button
          onClick={() => setWebMode(!webMode)}
          className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
            webMode ? "bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/40" : "glass text-muted-foreground"
          }`}
        >
          <Globe className={`h-3.5 w-3.5 ${webMode ? "text-emerald-400" : ""}`} />
          Web
        </button>

        {/* V2-new (#21): toggle tugas latar belakang */}
        <button
          onClick={() => setBgMode(!bgMode)}
          title="Tugas dikirim ke latar belakang — Anda bisa pindah menu, AI tetap mengerjakan"
          className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
            bgMode ? "bg-amber-500/20 text-amber-300 ring-1 ring-amber-400/40" : "glass text-muted-foreground"
          }`}
        >
          <PlayCircle className={`h-3.5 w-3.5 ${bgMode ? "text-amber-400" : ""}`} />
          Latar
        </button>
      </div>

      {/* baris 2: dropdown model + reset */}
      <div className="mb-3 flex items-center gap-2">
        <div className="relative flex-1">
          <button
            onClick={() => setModelOpen(!modelOpen)}
            className="flex w-full items-center gap-2 rounded-xl glass px-3 py-2 text-left transition-colors hover:bg-secondary/70"
          >
            <Cpu className="h-4 w-4 shrink-0 text-red-400" />
            <span className="min-w-0 flex-1 truncate text-xs font-bold">{currentModel?.label || "GPT-4.1 Nano"}</span>
            <span className="shrink-0 rounded-full bg-red-500/15 px-1.5 py-px text-[9px] font-extrabold text-red-300">
              {currentModel?.badge || "OpenAI"}
            </span>
            <ChevronDown className={`h-3.5 w-3.5 shrink-0 text-muted-foreground transition-transform ${modelOpen ? "rotate-180" : ""}`} />
          </button>
          <AnimatePresence>
            {modelOpen && (
              <motion.div
                initial={{ opacity: 0, y: -6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -6, scale: 0.98 }}
                className="glass-strong absolute z-40 mt-1.5 w-full overflow-hidden rounded-2xl p-1.5 shadow-2xl"
              >
                {models.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      setModel(m.id);
                      saveSettings({ defaultModel: m.id });
                      setModelOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition-colors ${
                      model === m.id ? "bg-red-500/20" : "hover:bg-secondary/70"
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <p className="flex items-center gap-1.5 text-xs font-bold">
                        {m.label}
                        <span className="rounded-full bg-white/10 px-1.5 py-px text-[8.5px] font-extrabold text-white/70">{m.badge}</span>
                      </p>
                      <p className="truncate text-[10px] text-muted-foreground">{m.desc}</p>
                    </div>
                    {model === m.id && <Sparkles className="h-3.5 w-3.5 shrink-0 text-red-400" />}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* V2-new (#21): riwayat chat + ingatan */}
        <button
          onClick={() => setHistoryOpen((o) => !o)}
          title="Riwayat percakapan — buka kembali & lanjutkan"
          className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
            historyOpen ? "bg-red-500/20 text-red-300 ring-1 ring-red-400/40" : "glass text-muted-foreground"
          }`}
        >
          <HistoryIcon className="h-3.5 w-3.5" />
          Riwayat
          {sessions.length > 0 && (
            <span className="rounded-full bg-red-500/25 px-1.5 py-px text-[9px] font-extrabold text-red-300">{sessions.length}</span>
          )}
        </button>
        <button
          onClick={() => setMemoryOpen((o) => !o)}
          title="Ingatan jangka panjang AI — hal yang harus selalu diingat"
          className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold transition-all ${
            memoryOpen ? "bg-cyan-500/20 text-cyan-300 ring-1 ring-cyan-400/40" : "glass text-muted-foreground"
          }`}
        >
          <Brain className="h-3.5 w-3.5" />
          Ingatan
          {memoryText.trim() && <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />}
        </button>

        {messages.length > 0 && (
          <button
            onClick={startNewChat}
            className="shrink-0 rounded-xl glass p-2 text-muted-foreground transition-colors hover:text-foreground"
            title="Chat baru"
          >
            <RefreshCw className="h-3.5 w-3.5" />
          </button>
        )}
      </div>

      {/* V2-new (#21): panel riwayat sesi */}
      <AnimatePresence>
        {historyOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-3 overflow-hidden">
            <div className="glass rounded-2xl p-3">
              <div className="mb-2 flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-xs font-bold">
                  <HistoryIcon className="h-3.5 w-3.5 text-red-400" /> Riwayat Percakapan
                </p>
                <button onClick={() => setHistoryOpen(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              {/* tugas latar belakang aktif */}
              {aiTasks.length > 0 && (
                <div className="mb-2 space-y-1.5">
                  {aiTasks.slice(0, 4).map((t) => (
                    <div key={t.id} className="flex items-center gap-2 rounded-xl bg-secondary/60 px-3 py-2 text-[11px]">
                      {t.status === "running" ? (
                        <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-amber-400" />
                      ) : t.status === "done" ? (
                        <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
                      ) : (
                        <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-red-400" />
                      )}
                      <span className="min-w-0 flex-1 truncate">{t.prompt}</span>
                      {t.status === "running" && <span className="shrink-0 text-[10px] font-bold text-amber-300">berjalan…</span>}
                      {t.status === "done" && t.sessionId && (
                        <button
                          onClick={() => {
                            const s = sessions.find((x) => x.id === t.sessionId) || loadSessions().find((x) => x.id === t.sessionId);
                            if (s) openSession(s);
                          }}
                          className="shrink-0 rounded-lg bg-emerald-500/20 px-2 py-1 text-[9.5px] font-bold text-emerald-300"
                        >
                          Buka hasil
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {sessions.length === 0 ? (
                <p className="rounded-xl bg-secondary/40 px-3 py-3 text-center text-[11px] text-muted-foreground">
                  Belum ada percakapan tersimpan — chat pertama Anda otomatis tercatat di sini.
                </p>
              ) : (
                <div className="max-h-64 space-y-1.5 overflow-y-auto pr-1">
                  {sessions.map((s) => (
                    <div key={s.id} className="group flex items-center gap-2 rounded-xl bg-secondary/50 px-3 py-2">
                      <MessageSquare className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <button onClick={() => openSession(s)} className="min-w-0 flex-1 text-left">
                        <p className="truncate text-[11.5px] font-bold">{s.title}</p>
                        <p className="text-[9.5px] text-muted-foreground">
                          {s.messages.length} pesan • {s.model || "-"} • {new Date(s.updatedAt).toLocaleString("id-ID", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </button>
                      <button
                        onClick={() => {
                          deleteSession(s.id);
                          setSessions(loadSessions());
                          if (session?.id === s.id) startNewChat();
                        }}
                        className="shrink-0 text-muted-foreground opacity-60 transition-opacity hover:text-red-400 group-hover:opacity-100"
                        title="Hapus"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* V2-new (#21): panel ingatan jangka panjang */}
      <AnimatePresence>
        {memoryOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="mb-3 overflow-hidden">
            <div className="glass rounded-2xl p-3">
              <div className="mb-1.5 flex items-center justify-between">
                <p className="flex items-center gap-1.5 text-xs font-bold">
                  <Brain className="h-3.5 w-3.5 text-cyan-400" /> Ingatan Jangka Panjang AI
                </p>
                <button onClick={() => setMemoryOpen(false)} className="text-muted-foreground hover:text-foreground">
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              <p className="mb-2 text-[10px] leading-relaxed text-muted-foreground">
                Tulis hal-hal yang Anda ingin AI selalu ingat (nama Anda, pekerjaan, preferensi, proyek…).
                Ingatan ini dipakai di SEMUA percakapan, termasuk tugas latar belakang.
              </p>
              <textarea
                value={memoryText}
                onChange={(e) => setMemoryText(e.target.value)}
                placeholder="Contoh: Panggil aku Fendi. Aku suka jawaban singkat. Aku lagi belajar JavaScript. Nama project-ku FanzzTools…"
                rows={4}
                className="w-full resize-none rounded-xl border border-border/60 bg-secondary/50 p-3 text-xs outline-none focus:border-cyan-400/50"
              />
              <button
                onClick={() => {
                  saveMemory(memoryText);
                  toast({ title: "Ingatan tersimpan", description: "AI akan mengingat hal ini di semua percakapan berikutnya." });
                }}
                className="mt-2 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-red-700 py-2.5 text-xs font-bold text-white"
              >
                Simpan ingatan
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* area chat */}
      <div ref={scrollRef} className="min-h-[300px] flex-1 space-y-3 overflow-y-auto pb-3 pr-1" style={{ maxHeight: "calc(100dvh - 380px)" }}>
        {messages.length === 0 && (
          <div className="flex flex-col items-center gap-5 py-6">
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              className="flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-blue-700 to-red-600 shadow-xl shadow-red-500/20"
            >
              <Bot className="h-8 w-8 text-white" />
            </motion.div>
            <div className="text-center">
              <p className="text-lg font-extrabold">Mau nanya apa hari ini? 🤖</p>
              <p className="mt-1 text-xs text-muted-foreground">Aku Fanzz AI — kenal semua fitur web ini, bisa baca gambar & file, cari info terbaru</p>
            </div>
            <div className="grid w-full max-w-sm grid-cols-1 gap-2">
              {QUICK_PROMPTS_BY_MODE[mode].map((q) => (
                <button
                  key={q}
                  onClick={() => send(q)}
                  className="rounded-xl glass px-3.5 py-2.5 text-left text-xs font-medium text-muted-foreground transition-all hover:scale-[1.01] hover:text-foreground"
                >
                  {mode === "coding" ? "💻" : mode === "learning" ? "📚" : "✨"} {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex gap-2.5 ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {m.role === "assistant" && (
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-700 to-red-600 text-white shadow-md">
                <Bot className="h-4 w-4" />
              </div>
            )}
            <div className={`max-w-[82%] rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed ${
              m.role === "user"
                ? "bg-gradient-to-br from-red-500 to-red-700 text-white shadow-lg shadow-red-500/15"
                : "glass text-foreground"
            }`}>
              {m.image && (
                <img src={m.image} alt="upload" className="mb-2 max-h-44 w-full rounded-xl object-cover" />
              )}
              {m.fileName && (
                <span className="mb-1.5 flex items-center gap-1.5 rounded-lg bg-black/25 px-2 py-1 text-[10px] font-bold">
                  <FileText className="h-3 w-3" /> {m.fileName}
                </span>
              )}
              {m.role === "assistant" ? <Markdown text={m.content} /> : <div className="whitespace-pre-wrap break-words">{m.content}</div>}
              {m.searched && (
                <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-emerald-500/10 px-2 py-1 text-[9.5px] font-bold text-emerald-400">
                  <SearchIcon className="h-3 w-3" /> Data terbaru dari web
                </p>
              )}
              {m.model && !m.searched && <p className="mt-1.5 text-[9px] font-bold opacity-50">via {m.model}</p>}
            </div>
            {m.role === "user" && (
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl glass text-red-300">
                <UserIcon className="h-4 w-4" />
              </div>
            )}
          </motion.div>
        ))}

        {busy && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-blue-700 to-red-600 text-white">
              <Bot className="h-4 w-4" />
            </div>
            <div className="glass flex items-center gap-2 rounded-2xl px-4 py-3">
              <span className="flex gap-1">
                {[0, 1, 2].map((d) => (
                  <motion.span
                    key={d}
                    animate={{ y: [0, -5, 0] }}
                    transition={{ repeat: Infinity, duration: 0.9, delay: d * 0.15 }}
                    className="h-1.5 w-1.5 rounded-full bg-red-400"
                  />
                ))}
              </span>
              <span className="text-xs text-muted-foreground">{webMode ? "Nyari di web..." : "Fanzz AI mikir..."}</span>
            </div>
          </motion.div>
        )}
      </div>

      {/* preview attachment */}
      <AnimatePresence>
        {(pendingImage || pendingFile) && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mb-2 flex items-center gap-2">
            {pendingImage ? (
              <div className="relative">
                <img src={pendingImage} alt="preview" className="h-14 w-14 rounded-xl object-cover" />
                <button onClick={() => setPendingImage(null)} className="absolute -right-1.5 -top-1.5 rounded-full bg-red-500 p-0.5 text-white shadow-lg">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ) : (
              <div className="relative flex items-center gap-1.5 rounded-xl glass px-3 py-2 text-xs font-bold">
                <FileText className="h-3.5 w-3.5 text-red-400" /> {pendingFile?.name}
                <button onClick={() => setPendingFile(null)} className="text-red-400"><X className="h-3.5 w-3.5" /></button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* input */}
      <div className="glass-strong sticky bottom-0 flex items-end gap-2 rounded-2xl p-2">
        <input ref={imgInputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={pickImage} />
        <input ref={fileInputRef} type="file" accept=".txt,.json,.js,.ts,.py,.csv,.md,.xml,.html,.css,.log,.yml,.yaml" className="hidden" onChange={pickFile} />
        <button onClick={() => imgInputRef.current?.click()} className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-red-400" title="Upload gambar (AI analisis)">
          <ImagePlus className="h-4.5 w-4.5" />
        </button>
        <button onClick={() => fileInputRef.current?.click()} className="rounded-xl p-2.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-red-400" title="Upload file teks/kode">
          <FileText className="h-4.5 w-4.5" />
        </button>
        <Textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send();
            }
          }}
          placeholder={
            mode === "coding"
              ? "Jelaskan program yang mau dibikin / paste kode yang mau dibenerin…"
              : mode === "learning"
                ? "Mau belajar apa hari ini? (Enter kirim)"
                : bgMode
                  ? "Tulis tugasnya — dikirim ke latar belakang, Anda bebas pindah menu…"
                  : webMode
                    ? "Tanya apa aja — aku cariin data terbaru..."
                    : "Ketik pesan... (Enter kirim)"
          }
          className="max-h-28 min-h-[42px] flex-1 resize-none border-0 bg-transparent px-1 text-sm focus-visible:ring-0"
          rows={1}
        />
        <Button
          onClick={() => send()}
          disabled={busy || (!input.trim() && !pendingImage && !pendingFile)}
          size="icon"
          className="h-11 w-11 shrink-0 rounded-xl bg-gradient-to-br from-red-500 to-red-700 shadow-lg shadow-red-500/25 transition-transform hover:scale-105 active:scale-95"
        >
          {busy ? <Loader2 className="h-4.5 w-4.5 animate-spin" /> : <Send className="h-4.5 w-4.5" />}
        </Button>
      </div>
    </div>
  );
}
