"use client";

import { useCallback, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import {
  BookOpen, Search, Loader2, ArrowLeft, ExternalLink, Sparkles,
} from "lucide-react";

interface WikiResult {
  title: string;
  desc: string;
  thumb: string | null;
  lang: string;
}

const SUGGESTIONS = [
  "Sejarah Indonesia",
  "Kecerdasan buatan",
  "Tata Surya",
  "Albert Einstein",
  "Pramoedya Ananta Toer",
  "Liga Champions UEFA",
];

export default function WikiView() {
  const [query, setQuery] = useState("");
  /** V0.01 (#11): pilih bahasa Wikipedia — Indonesia atau English. */
  const [lang, setLang] = useState<"id" | "en">("id");
  const [results, setResults] = useState<WikiResult[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [article, setArticle] = useState<{ title: string; html: string; lang: string } | null>(null);
  const [loadingArticle, setLoadingArticle] = useState(false);
  const [error, setError] = useState("");

  /** Fetch dengan timeout — supaya tidak ngestuck saat "baca selengkapnya". */
  const fetchWithTimeout = async (url: string, ms = 25000): Promise<Response> => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms);
    try {
      return await fetch(url, { signal: ctrl.signal });
    } finally {
      clearTimeout(t);
    }
  };

  const doSearch = useCallback((q: string, useLang?: "id" | "en") => {
    const t = q.trim();
    if (t.length < 2) {
      setResults(null);
      return;
    }
    setSearching(true);
    setError("");
    fetchWithTimeout(`/api/wiki?q=${encodeURIComponent(t)}&lang=${useLang || lang}`)
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok) setResults(d.results);
        else throw new Error(d?.error || "Pencarian gagal");
      })
      .catch((e) => setError(e instanceof Error ? (e.name === "AbortError" ? "Pencarian memakan waktu terlalu lama — coba lagi." : e.message) : "Pencarian gagal"))
      .finally(() => setSearching(false));
  }, [lang]);

  const openArticle = (title: string, lang: string) => {
    setLoadingArticle(true);
    setError("");
    fetchWithTimeout(`/api/wiki?title=${encodeURIComponent(title)}&lang=${lang}`, 35000)
      .then((r) => r.json())
      .then((d) => {
        if (d?.ok) setArticle({ title: d.title, html: d.html, lang: d.lang });
        else throw new Error(d?.error || "Artikel gagal dimuat");
      })
      .catch((e) =>
        setError(
          e instanceof Error
            ? e.name === "AbortError"
              ? "Memuat artikel terlalu lama — silakan coba lagi."
              : e.message
            : "Artikel gagal dimuat"
        )
      )
      .finally(() => setLoadingArticle(false));
  };

  /** Ganti bahasa — ulangi pencarian/artikel dengan bahasa yang dipilih. */
  const switchLang = (next: "id" | "en") => {
    if (next === lang) return;
    setLang(next);
    if (article) {
      openArticle(article.title, next);
    } else if (query.trim().length >= 2) {
      doSearch(query, next);
    }
  };

  // bersihin state pas artikel ditutup
  useEffect(() => {
    if (article) window.scrollTo({ top: 0 });
  }, [article]);

  /* ============ TAMPILAN ARTIKEL ============ */
  if (article || loadingArticle) {
    return (
      <div>
        <button
          onClick={() => setArticle(null)}
          className="mb-3 flex items-center gap-1.5 rounded-xl glass px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Kembali ke pencarian
        </button>
        {loadingArticle ? (
          <div className="space-y-3">
            <div className="h-8 w-2/3 rounded shimmer" />
            <div className="h-4 w-full rounded shimmer" />
            <div className="h-4 w-11/12 rounded shimmer" />
            <div className="h-4 w-4/5 rounded shimmer" />
            <div className="h-40 w-full rounded-2xl shimmer" />
            {/* V2-new: tombol batal — artikel panjang kadang lambat, jangan biarkan ngestuck */}
            <button
              onClick={() => setLoadingArticle(false)}
              className="mx-auto flex items-center gap-1.5 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground"
            >
              Berhenti memuat — kembali ke pencarian
            </button>
          </div>
        ) : article ? (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="overflow-hidden rounded-3xl glass">
            <div className="flex items-start gap-3 border-b border-[var(--surface-line)] p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-lg shadow-amber-500/20">
                <BookOpen className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <h1 className="text-lg font-extrabold">{article.title}</h1>
                <p className="text-[10px] text-muted-foreground">
                  Wikipedia {article.lang === "id" ? "Indonesia" : "English"} • dibaca langsung di FanzzTools
                </p>
              </div>
              <a
                href={`https://${article.lang}.wikipedia.org/wiki/${encodeURIComponent(article.title.replace(/ /g, "_"))}`}
                target="_blank"
                rel="noreferrer"
                className="shrink-0 rounded-xl bg-secondary/70 p-2 text-muted-foreground transition-colors hover:text-foreground"
                title="Buka di Wikipedia"
              >
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
            <div
              className="wiki-article p-4 text-sm leading-relaxed"
              dangerouslySetInnerHTML={{ __html: article.html }}
            />
          </motion.div>
        ) : null}
      </div>
    );
  }

  /* ============ TAMPILAN PENCARIAN ============ */
  return (
    <div>
      <ToolHeader icon={<BookOpen className="h-5.5 w-5.5" />} title="Pencarian Wiki" subtitle="Ensiklopedia lengkap ala Wikipedia — langsung dibaca di sini" accent="amber" />

      {/* pilih bahasa: Indonesia / English */}
      <div className="mb-4 flex items-center gap-2">
        <div className="flex items-center gap-1.5 rounded-xl glass p-1">
          {(["id", "en"] as const).map((l) => (
            <button
              key={l}
              onClick={() => switchLang(l)}
              className={`rounded-lg px-3 py-1.5 text-[11px] font-bold transition-colors ${
                lang === l ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {l === "id" ? "Wikipedia Indonesia" : "Wikipedia English"}
            </button>
          ))}
        </div>
      </div>

      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            doSearch(e.target.value);
          }}
          onKeyDown={(e) => e.key === "Enter" && doSearch(query)}
          placeholder={lang === "id" ? "Cari apa aja: orang, tempat, sejarah, sains..." : "Search anything: people, places, history, science..."}
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-4 pl-10 pr-3 text-sm outline-none focus:border-amber-400/50"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-amber-400" />}
      </div>

      {error && (
        <p className="mb-3 rounded-xl bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300">⚠️ {error}</p>
      )}

      {results === null ? (
        <div>
          <p className="mb-2.5 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-amber-400" /> Coba topik populer:
          </p>
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => {
                  setQuery(s);
                  doSearch(s);
                }}
                className="rounded-full glass px-3.5 py-2 text-xs font-semibold text-muted-foreground transition-all hover:scale-105 hover:text-foreground"
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      ) : results.length === 0 ? (
        <EmptyState icon={<Search className="h-6 w-6" />} title="Gak ketemu nih" desc="Coba kata kunci lain atau ejaan yang lebih simpel." />
      ) : (
        <div className="space-y-2">
          {results.map((r, i) => (
            <motion.button
              key={r.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
              onClick={() => openArticle(r.title, r.lang)}
              className="flex w-full items-start gap-3 rounded-2xl glass p-3.5 text-left transition-all hover:scale-[1.01]"
            >
              {r.thumb ? (
                <img src={r.thumb} alt="" className="h-16 w-16 shrink-0 rounded-xl object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-300">
                  <BookOpen className="h-6 w-6" />
                </div>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold">{r.title}</p>
                <p className="clamp-2 text-[11px] leading-relaxed text-muted-foreground">
                  {r.desc || "Buka buat baca artikel lengkapnya"}
                </p>
              </div>
            </motion.button>
          ))}
        </div>
      )}
    </div>
  );
}
