"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import BmkgCard from "@/components/tools/BmkgCard";
import { useApp } from "@/lib/app-store";
import {
  Newspaper, Loader2, ExternalLink, ShieldCheck, ShieldAlert, RefreshCw,
  Clock3, Globe2, ImageOff,
} from "lucide-react";

interface NewsItem {
  title: string;
  url: string;
  source: string;
  image: string | null;
  pubDate: string;
  summary: string;
  cred: "tinggi" | "sedang";
}

interface FactHit {
  title: string;
  url: string;
  source: string;
}

const CATEGORIES = [
  { id: "utama", label: "Utama", icon: Globe2 },
  { id: "nasional", label: "Nasional", icon: Newspaper },
  { id: "internasional", label: "Internasional", icon: Globe2 },
  { id: "teknologi", label: "Teknologi", icon: Newspaper },
  { id: "olahraga", label: "Olahraga", icon: Newspaper },
  { id: "ekonomi", label: "Ekonomi", icon: Newspaper },
  { id: "hiburan", label: "Hiburan", icon: Newspaper },
  { id: "sains", label: "Sains", icon: Newspaper },
];

function timeAgo(dateStr: string): string {
  const t = new Date(dateStr).getTime();
  if (!Number.isFinite(t)) return "";
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return "baru saja";
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`;
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`;
  return new Date(t).toLocaleDateString("id-ID", { day: "numeric", month: "short" });
}

export default function NewsView() {
  const { geo } = useApp();
  const [cat, setCat] = useState("utama");
  const [items, setItems] = useState<NewsItem[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [updatedAt, setUpdatedAt] = useState(0);
  const [countdown, setCountdown] = useState(60);
  // cek fakta per judul
  const [checking, setChecking] = useState<string | null>(null);
  const [facts, setFacts] = useState<Record<string, { verdict: string; hits: FactHit[] }>>({});
  const catRef = useRef(cat);
  const ccRef = useRef("");

  catRef.current = cat;

  const cc = geo?.countryCode || "ID";
  ccRef.current = cc;

  const load = useCallback(
    async (showLoading = true) => {
      if (showLoading) setLoading(true);
      try {
        const r = await fetch(`/api/news?cat=${catRef.current}&cc=${ccRef.current || "ID"}`);
        const d = await r.json();
        if (!d?.ok) throw new Error(d?.error || "Gagal memuat berita");
        setItems(d.items);
        setUpdatedAt(Date.now());
        setError("");
      } catch (e) {
        setError(e instanceof Error ? e.message : "Gagal memuat berita");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  // muat pas kategori/negara berubah
  useEffect(() => {
    setItems(null);
    load();
  }, [cat, cc, load]);

  // auto-refresh tiap 60 detik (update tiap menit)
  useEffect(() => {
    const tick = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          load(false);
          return 60;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(tick);
  }, [load]);

  const checkFact = async (item: NewsItem) => {
    if (checking || facts[item.url]) return;
    setChecking(item.url);
    try {
      const r = await fetch(`/api/news/factcheck?q=${encodeURIComponent(item.title)}`);
      const d = await r.json();
      if (d?.ok) {
        setFacts((f) => ({ ...f, [item.url]: { verdict: d.verdict, hits: d.hits || [] } }));
      }
    } catch {
      /* abaikan */
    } finally {
      setChecking(null);
    }
  };

  const currentCat = CATEGORIES.find((c) => c.id === cat) || CATEGORIES[0];

  return (
    <div>
      <ToolHeader icon={<Newspaper className="h-5.5 w-5.5" />} title="Berita Terkini" subtitle={`Update tiap menit • utama sesuai lokasi kamu (${geo?.negara || "Indonesia"})`} accent="emerald" />

      {/* V0.01 (#12): info BMKG / tanda bahaya real-time */}
      <BmkgCard />

      {/* bar status + refresh */}
      <div className="mb-3 flex items-center gap-2 text-[10px] text-muted-foreground">
        <span className="flex items-center gap-1.5 rounded-full glass px-2.5 py-1 font-bold">
          <Clock3 className="h-3 w-3 text-emerald-400" />
          Auto-update {countdown}s
        </span>
        <button
          onClick={() => {
            setCountdown(60);
            load();
          }}
          className="flex items-center gap-1.5 rounded-full glass px-2.5 py-1 font-bold transition-colors hover:text-foreground"
        >
          <RefreshCw className="h-3 w-3" /> Refresh
        </button>
        {updatedAt > 0 && <span>• terakhir {timeAgo(new Date(updatedAt).toISOString())}</span>}
      </div>

      {/* kategori */}
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            onClick={() => setCat(c.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              cat === c.id ? "text-white" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
            }`}
          >
            {cat === c.id && <motion.span layoutId="news-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <c.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{c.label}</span>
          </button>
        ))}
      </div>

      {error && (
        <p className="mb-3 rounded-xl bg-red-500/10 px-3.5 py-2.5 text-xs text-red-300">⚠️ {error}</p>
      )}

      {loading || items === null ? (
        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => <div key={i} className="h-28 rounded-2xl shimmer" />)}
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={<Newspaper className="h-6 w-6" />} title="Berita belum masuk" desc="Coba refresh atau ganti kategori dulu ya." />
      ) : (
        <div className="space-y-3">
          {items.map((n, i) => (
            <motion.article
              key={`${n.url}-${i}`}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.03, 0.3) }}
              className="overflow-hidden rounded-2xl glass"
            >
              <a href={n.url} target="_blank" rel="noreferrer" className="flex gap-3 p-3">
                {n.image ? (
                  <img
                    src={n.image}
                    alt=""
                    className="h-20 w-24 shrink-0 rounded-xl object-cover"
                    referrerPolicy="no-referrer"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : (
                  <div className="flex h-20 w-24 shrink-0 items-center justify-center rounded-xl bg-secondary">
                    <ImageOff className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <h3 className="clamp-2 text-[13px] font-bold leading-snug">{n.title}</h3>
                  <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[9.5px] text-muted-foreground">
                    <span className="rounded-full bg-emerald-500/15 px-1.5 py-px font-bold text-emerald-300">{n.source}</span>
                    {n.pubDate && <span>{timeAgo(n.pubDate)}</span>}
                    {n.cred === "tinggi" && (
                      <span className="flex items-center gap-0.5 font-bold text-sky-400">
                        <ShieldCheck className="h-2.5 w-2.5" /> kredibel
                      </span>
                    )}
                  </div>
                  {n.summary && (
                    <p className="clamp-2 mt-1 text-[10.5px] leading-relaxed text-muted-foreground">{n.summary}</p>
                  )}
                </div>
                <ExternalLink className="h-3.5 w-3.5 shrink-0 self-start text-muted-foreground" />
              </a>

              {/* tombol cek fakta */}
              <div className="border-t border-[var(--surface-line)] px-3 py-2">
                {facts[n.url] ? (
                  facts[n.url].verdict === "clear" ? (
                    <p className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-400">
                      <ShieldCheck className="h-3.5 w-3.5" /> Gak ketemu laporan hoaks buat berita ini
                    </p>
                  ) : (
                    <div>
                      <p className="flex items-center gap-1.5 text-[10px] font-bold text-amber-400">
                        <ShieldAlert className="h-3.5 w-3.5" /> Ada laporan terkait — cek sebelum share:
                      </p>
                      <div className="mt-1 space-y-1">
                        {facts[n.url].hits.slice(0, 2).map((h, j) => (
                          <a key={j} href={h.url} target="_blank" rel="noreferrer" className="block truncate rounded-lg bg-amber-500/10 px-2 py-1 text-[9.5px] font-semibold text-amber-200 hover:bg-amber-500/20">
                            {h.source}: {h.title}
                          </a>
                        ))}
                      </div>
                    </div>
                  )
                ) : (
                  <button
                    onClick={() => checkFact(n)}
                    disabled={checking === n.url}
                    className="flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground transition-colors hover:text-emerald-400 disabled:opacity-50"
                  >
                    {checking === n.url ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ShieldCheck className="h-3.5 w-3.5" />}
                    Cek fakta / hoaks
                  </button>
                )}
              </div>
            </motion.article>
          ))}
        </div>
      )}
    </div>
  );
}
