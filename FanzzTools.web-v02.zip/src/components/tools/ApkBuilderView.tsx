"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import qrcode from "qrcode-generator";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import {
  buildApk, readUserFiles, resizeIcons, buildPackageName, buildUrlWrapperHtml,
  buildPmPackageName,
} from "@/lib/apk-builder";
import { buildPmCompanionHtml, isForbiddenAppName } from "@/lib/pm-companion";
import {
  Package, Upload, Smartphone, Loader2, Download, FileCode2, ImageIcon,
  Rocket, CheckCircle2, Info, Trash2, FolderArchive, Link2, FileBox,
  ShieldCheck as ShieldPm, Baby,
} from "lucide-react";

const MAX_SIZE = 45 * 1024 * 1024; // 45 MB — sesuai permintaan
const PM_COMPANION_VERSION = "2.12.0";

interface BuildLog {
  msg: string;
  done?: boolean;
}

/** QR mini (mode Parent Monitor) — SVG ringan via qrcode-generator. */
function QrMini({ payload, size = 180 }: { payload: string; size?: number }) {
  let path = "";
  try {
    const qr = qrcode(0, "M");
    qr.addData(payload);
    qr.make();
    const n = qr.getModuleCount();
    const cell = size / (n + 8);
    const off = 4 * cell;
    for (let r = 0; r < n; r++) {
      for (let c = 0; c < n; c++) {
        if (qr.isDark(r, c)) {
          path += `M${(off + c * cell).toFixed(2)},${(off + r * cell).toFixed(2)}h${cell.toFixed(2)}v${cell.toFixed(2)}h-${cell.toFixed(2)}z`;
        }
      }
    }
  } catch {
    /* ignore */
  }
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="rounded-xl bg-white p-1" role="img" aria-label="QR pairing">
      <rect width={size} height={size} fill="#fff" />
      <path d={path} fill="#000" />
    </svg>
  );
}

/** Mode sumber APK — V0.01 (#16): dari FILE atau dari LINK (pilih salah satu).
 *  V2.12 Security-Updt: + PARENT MONITOR (companion HP anak). */
type BuildMode = "file" | "url" | "pm";

export default function ApkBuilderView() {
  const [mode, setMode] = useState<BuildMode>("file");
  const [file, setFile] = useState<File | null>(null);
  const [appUrl, setAppUrl] = useState("");
  const [iconFile, setIconFile] = useState<File | null>(null);
  const [iconPreview, setIconPreview] = useState<string | null>(null);
  const [appName, setAppName] = useState("");
  const [busy, setBusy] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [progress, setProgress] = useState(0);
  const [apkUrl, setApkUrl] = useState<string | null>(null);
  const [apkInfo, setApkInfo] = useState<{ size: string; pkg: string } | null>(null);
  const [error, setError] = useState("");

  /* ===== V2.12 Security-Updt: mode PARENT MONITOR ===== */
  const [pmChild, setPmChild] = useState<{ childId: string; childNickname: string } | null>(null);
  const [pmFeatures, setPmFeatures] = useState({ usage: true, status: true, location: false, media: false });
  const [apkSha, setApkSha] = useState<string | null>(null);
  const [pmQr, setPmQr] = useState<{ qrPayload: string; code: string; expiresAt: number } | null>(null);

  // buka dari dashboard Parent Monitor (event fanzz-pm-open-apk)
  useEffect(() => {
    const handler = (ev: Event) => {
      const detail = (ev as CustomEvent<{ childId: string; childNickname: string }>).detail;
      if (!detail?.childId) return;
      setPmChild({ childId: detail.childId, childNickname: detail.childNickname });
      setMode("pm");
      setAppName((a) => a || `Safety ${detail.childNickname}`.slice(0, 30));
      setApkUrl(null);
    };
    window.addEventListener("fanzz-pm-open-apk", handler);
    return () => window.removeEventListener("fanzz-pm-open-apk", handler);
  }, []);

  const fileRef = useRef<HTMLInputElement>(null);
  const iconRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const pickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    const name = f.name.toLowerCase();
    const isOk = name.endsWith(".html") || name.endsWith(".htm") || name.endsWith(".zip");
    if (!isOk) {
      toast({ title: "Format tidak didukung", description: "Harus file .html atau .zip ya", variant: "destructive" });
      return;
    }
    if (f.size > MAX_SIZE) {
      toast({ title: "File kegedean", description: `Maksimal 45MB — ukuran file Anda ${(f.size / 1048576).toFixed(1)}MB`, variant: "destructive" });
      return;
    }
    setFile(f);
    setApkUrl(null);
    setError("");
    if (!appName) {
      const base = f.name.replace(/\.(html?|zip)$/i, "").replace(/[-_]+/g, " ").trim();
      if (base) setAppName(base.slice(0, 30));
    }
  };

  const pickIcon = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (!f.type.startsWith("image/")) {
      toast({ title: "Bukan gambar", description: "Icon harus jpg/png/webp/gif atau gambar lain", variant: "destructive" });
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      toast({ title: "Icon kegedean", description: "Maksimal 10MB (akan diubah ukurannya otomatis)", variant: "destructive" });
      return;
    }
    setIconFile(f);
    setIconPreview(URL.createObjectURL(f));
    setApkUrl(null);
  };

  const generate = async () => {
    const urlReady = mode === "url" && /^https?:\/\/[a-zA-Z0-9.-]+\.[a-z]{2,}/i.test(appUrl.trim());
    if (mode === "pm" && isForbiddenAppName(appName.trim())) {
      toast({
        title: "Nama aplikasi tidak diizinkan",
        description: "Dilarang menyamarkan sebagai aplikasi sistem (mis. \"Android System\", \"Google Play Services\") — transparansi adalah syarat fitur ini.",
        variant: "destructive",
      });
      return;
    }
    if (busy || !appName.trim() || (mode === "file" && !file) || (mode === "url" && !urlReady)) return;
    setBusy(true);
    setError("");
    setApkUrl(null);
    setApkSha(null);
    setPmQr(null);
    setLogs([]);
    setProgress(0);

    const log = (m: string) => setLogs((l) => [...l, m]);

    try {
      let files: Array<{ path: string; data: Uint8Array }>;

      if (mode === "pm") {
        // MODE PARENT MONITOR (V2.12): companion transparan untuk HP anak
        log("🛡️ Menyiapkan companion Family Cyber Safety…");
        setProgress(8);
        const html = buildPmCompanionHtml({
          appName: appName.trim(),
          serverUrl: window.location.origin,
          childNickname: pmChild?.childNickname,
          features: pmFeatures,
          version: PM_COMPANION_VERSION,
        });
        files = [{ path: "index.html", data: new TextEncoder().encode(html) }];
        log(`   → companion v${PM_COMPANION_VERSION}: pairing kode/QR + status transparan + disconnect`);
        log(`   → fitur: ${Object.entries(pmFeatures).filter(([, v]) => v).map(([k]) => k).join(", ") || "status saja"}`);
      } else if (mode === "url") {
        // MODE LINK (V0.01 #16): APK membuka URL yang ditempel — pembungkus
        // halaman dibuat otomatis (tidak bergantung pada HTML milik pengguna).
        log("🔗 Menyiapkan pembungkus tautan…");
        setProgress(8);
        const html = buildUrlWrapperHtml(appUrl.trim(), appName.trim());
        files = [{ path: "index.html", data: new TextEncoder().encode(html) }];
        log("   → aplikasi akan membuka tautan yang Anda pilih");
      } else {
        log("📦 Membaca file kamu…");
        setProgress(8);
        files = await readUserFiles(file!);
        log(`   → ${files.length} file siap (index.html + aset)`);
      }

      log("🎨 Memproses icon…");
      setProgress(18);
      let icons;
      if (iconFile) {
        icons = await resizeIcons(iconFile);
        log("   → icon di-resize ke 5 ukuran (48–192px)");
      } else {
        throw new Error("Icon wajib di-upload dulu (jpg/png/gambar apa pun)");
      }

      log("⬇️ Mengunduh template resmi dari server…");
      setProgress(30);
      // FanzSec-Update: key.pem/cert.pem TIDAK lagi diunduh browser — private key
      // lama di public/ sudah dianggap TERKOMPROMI dan dihapus. APK ditandatangani
      // SERVER-SIDE lewat /api/apk/sign (autentikasi sesi + rate-limit + validasi).
      const templateRes = await fetch("/apk/template.apk");
      if (!templateRes.ok) throw new Error("Template tidak bisa diunduh dari server");
      const template = new Uint8Array(await templateRes.arrayBuffer());
      log(`   → template ${template.length.toLocaleString("id-ID")} byte ✓`);

      const unsignedApk = await buildApk({
        files,
        appName: appName.trim(),
        icons,
        template,
        onProgress: (m) => log(m),
      });

      log("🔐 Meminta tanda tangan dari server (kunci tidak pernah keluar server)…");
      setProgress(80);
      const signRes = await fetch("/api/apk/sign", {
        method: "POST",
        body: (() => {
          const fd = new FormData();
          fd.append("apk", new Blob([unsignedApk as unknown as BlobPart], { type: "application/vnd.android.package-archive" }), "unsigned.apk");
          return fd;
        })(),
      });
      if (!signRes.ok) {
        let errText = `Server signing menolak (HTTP ${signRes.status})`;
        try {
          const d = await signRes.json();
          if (d?.error) errText = String(d.error);
        } catch { /* respons biner/body kosong */ }
        throw new Error(errText);
      }
      const apk = new Uint8Array(await signRes.arrayBuffer());
      const certFp = signRes.headers.get("X-Cert-Fingerprint") || "";
      log(`   → ditandatangani server ✓${certFp ? ` (fingerprint ${certFp.slice(0, 16)}…)` : ""}`);
      setProgress(92);

      // V2.12: SHA-256 dari APK (verifikasi integritas — spesifikasi build PM)
      let sha256 = "";
      try {
        const digest = await crypto.subtle.digest("SHA-256", apk.buffer as ArrayBuffer || new Uint8Array(apk).buffer);
        sha256 = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
      } catch {
        /* browser tanpa crypto.subtle — lewati */
      }

      const blob = new Blob([apk as unknown as BlobPart], {
        type: "application/vnd.android.package-archive",
      });
      const url = URL.createObjectURL(blob);
      const safeName = (appName.trim().replace(/[^a-zA-Z0-9 _-]/g, "").trim() || "app").replace(/\s+/g, "_");
      const fileName = `${safeName}.apk`;

      setApkUrl(url);
      setApkSha(sha256 || null);
      setApkInfo({
        size: `${(blob.size / 1048576).toFixed(2)} MB`,
        pkg: mode === "pm" ? buildPmPackageName(appName.trim()) : buildPackageName(appName.trim()),
      });
      // simpan nama file di anchor dataset
      setApkFileName(fileName);
      setProgress(100);

      if (mode === "pm") {
        log(`🎉 Companion APK jadi & ditandatangani! SHA-256: ${sha256.slice(0, 16)}…`);
        log("📲 Install di HP anak → buka → masukkan kode pairing PM-XXXX-XXXX dari dashboard.");
        // spesifikasi: setelah build, QR pairing otomatis dibuat (bila dibuka dari dashboard)
        if (pmChild?.childId) {
          try {
            const r = await fetch("/api/pm/enrollment", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "generate",
                childId: pmChild.childId,
                deviceLabel: `Companion ${pmChild.childNickname}`,
                features: pmFeatures,
              }),
            });
            const d = await r.json();
            if (d?.ok) {
              setPmQr({ qrPayload: d.enrollment.qrPayload, code: d.enrollment.code, expiresAt: d.enrollment.expiresAt });
              log(`🔑 Kode pairing aktif 10 menit: ${d.enrollment.code}`);
            }
          } catch {
            /* QR opsional — biarkan dashboard yang jadi sumber utama */
          }
        }
      } else {
        log("🎉 APK berhasil dibuat & sudah ditandatangani!");
      }
      toast({ title: "APK jadi! 🚀", description: `${fileName} siap di-install di HP Android` });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Gagal membuat APK";
      setError(msg);
      log(`❌ ${msg}`);
      toast({ title: "Gagal membuat APK", description: msg, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  // nama file APK untuk unduhan
  const [apkFileName, setApkFileName] = useState("app.apk");

  return (
    <div>
      <ToolHeader
        icon={<Package className="h-5.5 w-5.5" />}
        title="APK Builder"
        subtitle="HTML/ZIP → aplikasi Android .apk (siap install)"
        accent="amber"
      />

      <div className="glass space-y-4 rounded-3xl p-5">
        {/* 0. pilih mode sumber — V0.01 (#16) + V2.12 (Parent Monitor) */}
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] text-amber-400">0</span>
            Sumber aplikasi — pilih salah satu
          </p>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => { setMode("file"); setApkUrl(null); }}
              className={`flex items-center gap-2 rounded-2xl p-3 text-left transition-all ${
                mode === "file"
                  ? "bg-gradient-to-r from-amber-500/20 to-orange-500/10 ring-2 ring-amber-400/40"
                  : "bg-secondary/40 ring-1 ring-[var(--surface-line)] hover:bg-secondary/60"
              }`}
            >
              <FileBox className={`h-5 w-5 shrink-0 ${mode === "file" ? "text-amber-400" : "text-muted-foreground"}`} />
              <div className="min-w-0">
                <p className="text-[11px] font-bold">File HTML/ZIP</p>
                <p className="text-[9px] text-muted-foreground">web di HP kamu</p>
              </div>
            </button>
            <button
              onClick={() => { setMode("url"); setApkUrl(null); }}
              className={`flex items-center gap-2 rounded-2xl p-3 text-left transition-all ${
                mode === "url"
                  ? "bg-gradient-to-r from-amber-500/20 to-orange-500/10 ring-2 ring-amber-400/40"
                  : "bg-secondary/40 ring-1 ring-[var(--surface-line)] hover:bg-secondary/60"
              }`}
            >
              <Link2 className={`h-5 w-5 shrink-0 ${mode === "url" ? "text-amber-400" : "text-muted-foreground"}`} />
              <div className="min-w-0">
                <p className="text-[11px] font-bold">Dari Link/URL</p>
                <p className="text-[9px] text-muted-foreground">tautan → APK</p>
              </div>
            </button>
            <button
              onClick={() => { setMode("pm"); setApkUrl(null); setAppName((a) => a || "Family Safety"); }}
              className={`flex items-center gap-2 rounded-2xl p-3 text-left transition-all ${
                mode === "pm"
                  ? "bg-gradient-to-r from-blue-600/20 to-blue-500/10 ring-2 ring-blue-500/40"
                  : "bg-secondary/40 ring-1 ring-[var(--surface-line)] hover:bg-secondary/60"
              }`}
            >
              <ShieldPm className={`h-5 w-5 shrink-0 ${mode === "pm" ? "text-blue-500" : "text-muted-foreground"}`} />
              <div className="min-w-0">
                <p className="flex items-center gap-1 text-[11px] font-bold">Parent Monitor<span className="rounded-full bg-blue-600/20 px-1 py-px text-[8px] font-extrabold text-blue-300">BARU</span></p>
                <p className="text-[9px] text-muted-foreground">companion HP anak</p>
              </div>
            </button>
          </div>
        </div>

        {/* 1. sumber aplikasi sesuai mode */}
        {mode === "pm" ? (
          <div className="space-y-3 rounded-2xl bg-blue-600/10 p-4">
            <div className="flex items-start gap-2.5">
              <Baby className="mt-0.5 h-4 w-4 shrink-0 text-blue-300" />
              <div className="min-w-0 flex-1 text-[11px] leading-relaxed">
                {pmChild ? (
                  <p>Companion untuk profil anak <b className="text-blue-200">{pmChild.childNickname}</b> — dibuka dari dashboard Parent Monitor.</p>
                ) : (
                  <p>Companion <b>Family Cyber Safety</b> untuk HP anak: pairing kode/QR, layar status transparan, dan tombol putus koneksi untuk anak. Tip: buka lewat <b>Parent Monitor → perangkat anak → "Buat APK Companion"</b> agar terhubung otomatis ke profil anak.</p>
                )}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-[10px] font-black uppercase tracking-wider text-blue-300">Fitur monitoring companion</p>
              <div className="grid grid-cols-2 gap-2">
                {([
                  ["status", "Status perangkat", "baterai, jaringan, sinkron"],
                  ["usage", "Statistik pemakaian", "agregat — butuh companion native (Kotlin) untuk data UsageStatsManager; WebView companion mengirim ringkasan terbatas"],
                  ["location", "Lokasi opsional", "GPS — hanya saat anak menekan tombol kirim"],
                  ["media", "Media opsional", "foto yang anak pilih sendiri (Photo Picker)"],
                ] as const).map(([key, label, desc]) => (
                  <button
                    key={key}
                    onClick={() => setPmFeatures((f) => ({ ...f, [key]: !f[key as keyof typeof f] }))}
                    className={`rounded-xl p-2.5 text-left transition ${
                      pmFeatures[key as keyof typeof pmFeatures]
                        ? "bg-blue-600/20 ring-1 ring-blue-500/40"
                        : "bg-secondary/50 ring-1 ring-[var(--surface-line)]"
                    }`}
                  >
                    <p className="flex items-center gap-1.5 text-[10.5px] font-bold">
                      <span className={`h-2 w-2 rounded-full ${pmFeatures[key as keyof typeof pmFeatures] ? "bg-emerald-400" : "bg-red-400"}`} />
                      {label}
                    </p>
                    <p className="mt-0.5 text-[9px] leading-snug text-muted-foreground">{desc}</p>
                  </button>
                ))}
              </div>
            </div>
            <p className="rounded-xl bg-emerald-500/10 p-2.5 text-[9.5px] leading-relaxed text-emerald-200">
              🛡️ Transparan by design: companion selalu menampilkan fitur aktif, anak bisa memutus koneksi sendiri, tanpa keylogger/pembacaan chat/rekaman diam-diam. Nama aplikasi tidak boleh menyamar sebagai aplikasi sistem.
            </p>
          </div>
        ) : mode === "url" ? (
          <div>
            <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] text-amber-400">1</span>
              Tautan website/aplikasi
            </p>
            <Input
              value={appUrl}
              onChange={(e) => { setAppUrl(e.target.value.slice(0, 300)); setApkUrl(null); }}
              placeholder="https://contoh-web-anda.com"
              className="rounded-xl border-border/60 bg-secondary/50 py-4 text-sm"
              inputMode="url"
            />
            <p className="mt-1 text-[10px] text-muted-foreground">
              APK yang dihasilkan akan membuka tautan ini langsung saat dibuka.
            </p>
          </div>
        ) : (
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] text-amber-400">1</span>
            File web kamu (.html / .zip, maks 45MB)
          </p>
          <input ref={fileRef} type="file" accept=".html,.htm,.zip" className="hidden" onChange={pickFile} />
          <button
            onClick={() => fileRef.current?.click()}
            className={`flex w-full items-center gap-3 rounded-2xl border-2 border-dashed p-4 text-left transition-colors ${
              file ? "border-emerald-500/40 bg-emerald-500/10" : "border-border/60 bg-secondary/40 hover:border-amber-500/40"
            }`}
          >
            <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${file ? "bg-emerald-500/20 text-emerald-400" : "bg-secondary text-muted-foreground"}`}>
              {file?.name.toLowerCase().endsWith(".zip") ? <FolderArchive className="h-5.5 w-5.5" /> : <FileCode2 className="h-5.5 w-5.5" />}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">
                {file ? file.name : "Pilih file HTML atau ZIP"}
              </p>
              <p className="text-[10.5px] text-muted-foreground">
                {file
                  ? `${(file.size / 1048576).toFixed(2)} MB • ${file.name.toLowerCase().endsWith(".zip") ? "proyek web multi-file" : "satu file HTML"}`
                  : "ZIP bisa berisi index.html + css/js/gambar"}
              </p>
            </div>
            {file && (
              <span
                role="button"
                tabIndex={0}
                onClick={(e) => { e.stopPropagation(); setFile(null); }}
                className="shrink-0 rounded-xl bg-secondary p-2 text-muted-foreground hover:text-red-400"
              >
                <Trash2 className="h-4 w-4" />
              </span>
            )}
          </button>
        </div>
        )}

        {/* 2. nama */}
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] text-amber-400">2</span>
            Nama aplikasi (muncul di layar HP)
          </p>
          <Input
            value={appName}
            onChange={(e) => { setAppName(e.target.value.slice(0, 30)); setApkUrl(null); }}
            placeholder="misal: AplikasiKu"
            className="rounded-xl border-border/60 bg-secondary/50 py-4 text-sm"
          />
          <p className="mt-1 text-[10px] text-muted-foreground">
            Package otomatis: <span className="font-mono">{appName ? (mode === "pm" ? buildPmPackageName(appName) : buildPackageName(appName)) : mode === "pm" ? "com.fanzz.familysafety.…" : "com.fanzz.webapp.…"}</span>
          </p>
        </div>

        {/* 3. icon */}
        <div>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-amber-500/20 text-[10px] text-amber-400">3</span>
            Icon aplikasi (jpg / png / gambar apa pun)
          </p>
          <input ref={iconRef} type="file" accept="image/*" className="hidden" onChange={pickIcon} />
          <button
            onClick={() => iconRef.current?.click()}
            className="flex w-full items-center gap-3 rounded-2xl border-2 border-dashed border-border/60 bg-secondary/40 p-4 text-left transition-colors hover:border-amber-500/40"
          >
            <span className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-secondary text-muted-foreground">
              {iconPreview ? (
                <img src={iconPreview} alt="icon" className="h-full w-full object-cover" />
              ) : (
                <ImageIcon className="h-5.5 w-5.5" />
              )}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-bold">{iconFile ? iconFile.name : "Pilih icon"}</p>
              <p className="text-[10.5px] text-muted-foreground">Otomatis di-resize jadi icon launcher Android</p>
            </div>
          </button>
        </div>

        <Button
          onClick={generate}
          disabled={busy || !appName.trim() || !iconFile || (mode === "file" ? !file : mode === "url" ? !/^https?:\/\/[a-zA-Z0-9.-]+\.[a-z]{2,}/i.test(appUrl.trim()) : false)}
          className="w-full rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 py-5 text-sm font-bold shadow-lg shadow-amber-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
        >
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Rocket className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Sedang membangun APK…" : mode === "pm" ? "Generate Companion APK" : "Generate APK Sekarang"}
        </Button>
      </div>

      {/* progress */}
      {(busy || logs.length > 0) && (
        <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass mt-4 rounded-3xl p-4">
          <div className="mb-2 h-2 overflow-hidden rounded-full bg-secondary">
            <motion.div
              animate={{ width: `${progress}%` }}
              className="h-full rounded-full bg-gradient-to-r from-amber-400 to-orange-500"
            />
          </div>
          <div className="max-h-44 space-y-1 overflow-y-auto font-mono text-[10.5px] leading-relaxed text-muted-foreground">
            {logs.map((l, i) => (
              <motion.p key={i} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}>
                <span className="text-emerald-400">$</span> {l}
              </motion.p>
            ))}
          </div>
        </motion.div>
      )}

      {error && (
        <p className="mt-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">⚠️ {error}</p>
      )}

      {/* hasil */}
      <AnimatePresence>
        {apkUrl && apkInfo && (
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass mt-4 overflow-hidden rounded-3xl"
          >
            <div className="bg-gradient-to-br from-amber-500/20 to-orange-500/20 p-5 text-center">
              <motion.div
                initial={{ scale: 0, rotate: -20 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 18 }}
                className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-xl shadow-amber-500/30"
              >
                <CheckCircle2 className="h-8 w-8" />
              </motion.div>
              <p className="text-base font-extrabold">{mode === "pm" ? "Companion APK udah jadi! 🎉" : "APK kamu udah jadi! 🎉"}</p>
              <p className="mt-1 text-xs text-muted-foreground">{apkInfo.size} • {apkInfo.pkg} • v{mode === "pm" ? PM_COMPANION_VERSION : "1.0"}</p>
              {apkSha && (
                <p className="mt-1.5 break-all rounded-xl bg-black/30 p-2 font-mono text-[9px] leading-relaxed text-muted-foreground">
                  SHA-256: {apkSha}
                </p>
              )}
            </div>
            <div className="p-4">
              <a
                href={apkUrl}
                download={apkFileName}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 py-4 text-sm font-extrabold text-white shadow-lg shadow-emerald-500/25 transition-transform active:scale-95"
              >
                <Download className="h-4.5 w-4.5" /> Download {apkFileName}
              </a>

              {/* QR pairing otomatis (mode Parent Monitor, dibuka dari dashboard) */}
              {mode === "pm" && pmQr && (
                <div className="mt-4 rounded-2xl bg-blue-600/10 p-4 text-center">
                  <p className="text-xs font-extrabold text-blue-200">Kode pairing aktif 10 menit</p>
                  <p className="font-mono text-sm font-black tracking-wider text-blue-100">{pmQr.code}</p>
                  <div className="mt-2 flex justify-center">
                    <QrMini payload={pmQr.qrPayload} size={180} />
                  </div>
                  <p className="mt-2 text-[9.5px] leading-relaxed text-muted-foreground">
                    Buka companion di HP anak → <b>Masukkan kode</b> di atas (atau pindai QR). Kode sekali pakai.
                  </p>
                </div>
              )}

              <div className="mt-3 space-y-1.5 rounded-2xl bg-secondary/50 p-3.5 text-[10.5px] leading-relaxed text-muted-foreground">
                <p className="font-bold text-foreground">Cara install di HP Android:</p>
                <p>1. Download file .apk di atas</p>
                <p>2. Buka file-nya → kalau muncul "Install dari sumber tidak dikenal", izinkan dari Pengaturan</p>
                <p>3. Tekan Install → selesai! App kamu muncul di menu dengan nama &amp; icon yang kamu pilih</p>
                {mode === "pm" && (
                  <p className="pt-1.5 text-blue-200/80">4. Buka companion → hubungkan dengan kode pairing → dashboard Parent Monitor langsung ter-update</p>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-4 flex items-start gap-2.5 rounded-2xl glass p-4 text-[10.5px] leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
        <p>
          APK di-bikin langsung di HP kamu dari template resmi server (classes.dex WebView asli + classes sesuai file) lalu
          ditandatangani otomatis — sehingga file besar (hingga 45MB) aman diproses. Seluruh isi file Anda tetap di perangkat, tidak diunggah ke mana pun.
        </p>
      </div>
    </div>
  );
}
