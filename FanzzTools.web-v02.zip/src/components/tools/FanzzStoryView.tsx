"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useApp } from "@/lib/app-store";
import { useToast } from "@/hooks/use-toast";
import {
  Plus, Loader2, X, Heart, MessageCircle, Send, Trash2, Eye, Play, Pause,
  ChevronLeft, Camera, Type, Users, Check, Image as ImageIcon, Music, VolumeX,
  Clock3 as ClockIcon, Search,
} from "lucide-react";

/**
 * FanzzStory (V2 Modern-UpdSec) — status/story ala WhatsApp:
 *  - teks (pilih gradasi), video + caption, atau FOTO + musik latar
 *    (PERBARUAN #4: foto tampil TETAP 14 detik; musik dipotong 14 detik)
 *  - bertahan 22 JAM lalu otomatis hilang
 *  - maksimal 5 status aktif per user
 *  - terkirim GLOBAL — semua user bisa melihat
 *  - bisa di-like & dikomentari; pemilik melihat siapa saja menonton
 *  - tombol komentar kecil di pojok kanan atas (tidak menghalangi)
 *  - PERBAIKAN #5: data video/foto/musik diambil dari /api/story/view
 *    saat ditonton (dulu src-nya undefined → video cuma layar hitam).
 */

interface StoryComment {
  uid: string;
  username: string;
  text: string;
  ts: number;
}

interface Story {
  id: string;
  uid: string;
  username: string;
  avatar: string | null;
  avatarColor: string;
  type: "text" | "video" | "photo";
  text: string;
  bg: number;
  hasVideo: boolean;
  hasPhoto?: boolean;
  hasMusic?: boolean;
  /** durasi tampil foto+musik (ms) — selalu 14.000 */
  photoDuration?: number;
  createdAt: number;
  expiresAt: number;
  likes: number;
  likedByMe: boolean;
  viewers?: number;
  viewersList?: Array<{ uid: string; username: string; avatar: string | null; avatarColor: string }>;
  comments: StoryComment[];
  canDelete: boolean;
  data?: string;
  /** musik latar (mode foto) — data URL 14 dtk ATAU URL proxy library musik situs */
  music?: string;
  /** videoId lagu library — untuk menyegarkan URL audio kedaluwarsa */
  musicVideo?: string;
}

interface StoryGroup {
  uid: string;
  username: string;
  avatar: string | null;
  avatarColor: string;
  fanzzId?: string;
  isMe: boolean;
  stories: Story[];
}

const BG_GRADIENTS = [
  "linear-gradient(135deg,#0f172a,#3b0764,#831843)",
  "linear-gradient(135deg,#052e16,#065f46,#0d9488)",
  "linear-gradient(135deg,#131318,#4338ca,#ef4444)",
  "linear-gradient(135deg,#431407,#9a3412,#f59e0b)",
  "linear-gradient(135deg,#164e63,#0e7490,#22d3ee)",
  "linear-gradient(135deg,#4c0519,#be123c,#fb7185)",
  "linear-gradient(135deg,#14532d,#166534,#84cc16)",
  "linear-gradient(135deg,#111827,#374151,#9ca3af)",
  "linear-gradient(135deg,#581c87,#7e22ce,#22d3ee)",
  "linear-gradient(135deg,#0c0a09,#292524,#f5f5f4)",
];

const STORY_MS = 22 * 3600 * 1000;
const TEXT_DURASI = 7000; // teks 7 detik
const FOTO_DURASI = 14000; // PERBARUAN #4: foto+musik 14 detik (musik dipotong 14 dtk)

/** Batas caption sebelum dipotong + tombol "Selengkapnya.." (permintaan #1). */
const CAPTION_POTONG = 90;

/** PERMINTAAN #3: potong musik jadi TEPAT 14 detik (WAV mono 22kHz — kecil).
 * Dijalankan di browser pakai Web Audio API; gagal decode → lempar (fallback asli). */
async function potongMusik14Detik(dataUrl: string): Promise<string> {
  const res = await fetch(dataUrl);
  const buf = await res.arrayBuffer();
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  const decoded = await ctx.decodeAudioData(buf);
  const durasi = Math.min(14, decoded.duration);
  const rate = 22050; // mono 22kHz — cukup untuk musik latar, file jadi kecil
  const offline = new OfflineAudioContext(1, Math.ceil(durasi * rate), rate);
  const src = offline.createBufferSource();
  src.buffer = decoded;
  src.connect(offline.destination);
  src.start(0);
  const rendered = await offline.startRendering();
  const samples = rendered.getChannelData(0);
  // encode WAV 16-bit PCM
  const bytes = new DataView(new ArrayBuffer(44 + samples.length * 2));
  const wr = (off: number, s: string) => { for (let i = 0; i < s.length; i++) bytes.setUint8(off + i, s.charCodeAt(i)); };
  wr(0, "RIFF"); bytes.setUint32(4, 36 + samples.length * 2, true); wr(8, "WAVE");
  wr(12, "fmt "); bytes.setUint32(16, 16, true); bytes.setUint16(20, 1, true); bytes.setUint16(22, 1, true);
  bytes.setUint32(24, rate, true); bytes.setUint32(28, rate * 2, true); bytes.setUint16(32, 2, true); bytes.setUint16(34, 16, true);
  wr(36, "data"); bytes.setUint32(40, samples.length * 2, true);
  let off = 44;
  for (let i = 0; i < samples.length; i++, off += 2) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    bytes.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  await ctx.close().catch(() => {});
  // → base64 data URL
  return new Promise<string>((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error("encode gagal"));
    fr.readAsDataURL(new Blob([bytes.buffer], { type: "audio/wav" }));
  });
}

function sisaWaktu(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const j = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return j > 0 ? `${j}j ${m}m lagi` : `${m}m ${s % 60}d lagi`;
}

/** Cyber-Update #5: deteksi MIME audio dari byte header (ID3/MPG/OggS/RIFF/ftyp)
 * supaya data URL hasil fetch CDN punya mime audio/* yang diterima story-store. */
function sniffAudioMime(buf: ArrayBuffer): string {
  const b = new Uint8Array(buf.slice(0, 16));
  if (b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) return "audio/mpeg"; // ID3
  if (b[0] === 0xff && (b[1] & 0xe0) === 0xe0) return "audio/mpeg"; // frame sync MP3
  if (b[0] === 0x4f && b[1] === 0x67 && b[2] === 0x67 && b[3] === 0x53) return "audio/ogg";
  if (b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46) return "audio/wav"; // RIFF
  if (b[4] === 0x66 && b[5] === 0x74 && b[6] === 0x79 && b[7] === 0x70) return "audio/mp4"; // ftyp
  return "audio/mpeg";
}

export default function FanzzStoryView() {
  const { user } = useApp();
  const { toast } = useToast();
  const [groups, setGroups] = useState<StoryGroup[] | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  // pembuat story
  const [buatOpen, setBuatOpen] = useState(false);
  const [tipe, setTipe] = useState<"text" | "photo" | "video">("text");
  const [teks, setTeks] = useState("");
  const [bgIdx, setBgIdx] = useState(0);
  const [videoData, setVideoData] = useState<string | null>(null);
  const [videoName, setVideoName] = useState("");
  // PERBARUAN #4: foto + musik
  const [fotoData, setFotoData] = useState<string | null>(null);
  const [fotoName, setFotoName] = useState("");
  const [musikData, setMusikData] = useState<string | null>(null);
  const [musikName, setMusikName] = useState("");
  const [uploading, setUploading] = useState(false);

  // pemutar
  const [playGroup, setPlayGroup] = useState<StoryGroup | null>(null);
  const [playIdx, setPlayIdx] = useState(0);
  const [paused, setPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [komentarOpen, setKomentarOpen] = useState(false);
  const [komentarTeks, setKomentarTeks] = useState("");
  const [lihatPenonton, setLihatPenonton] = useState(false);
  /** PERMINTAAN #1: caption panjang dipotong + tombol "Selengkapnya.." */
  const [captionExpanded, setCaptionExpanded] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const rafRef = useRef<number>(0);

  const muat = useCallback(async () => {
    setRefreshing(true);
    try {
      const r = await fetch("/api/story/list");
      const d = await r.json();
      if (d?.ok) setGroups(d.groups);
      else setGroups([]);
    } catch {
      setGroups([]);
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    void muat();
  }, [muat]);

  /* ---------- unggah story ---------- */
  const pilihVideo = (file: File | undefined) => {
    if (!file) return;
    if (!/^video\/(mp4|webm|quicktime)/.test(file.type)) {
      toast({ title: "Format video tidak didukung", description: "Gunakan MP4 / WebM.", variant: "destructive" });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast({ title: "Video terlalu besar", description: "Maksimal ±10 MB agar story cepat dimuat.", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setVideoData(String(reader.result));
      setVideoName(file.name);
    };
    reader.readAsDataURL(file);
  };

  /* PERBARUAN #4: pilih foto */
  const pilihFoto = (file: File | undefined) => {
    if (!file) return;
    if (!/^image\/(png|jpe?g|webp)/.test(file.type)) {
      toast({ title: "Format foto tidak didukung", description: "Gunakan PNG / JPG / WebP.", variant: "destructive" });
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      toast({ title: "Foto terlalu besar", description: "Maksimal ±7 MB — kompres dulu ya.", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setFotoData(String(reader.result));
      setFotoName(file.name);
    };
    reader.readAsDataURL(file);
  };

  /* PERBARUAN #4: pilih musik latar (opsional, dipotong 14 dtk saat diputar) */
  const pilihMusik = (file: File | undefined) => {
    if (!file) return;
    if (!/^audio\//.test(file.type)) {
      toast({ title: "Format musik tidak didukung", description: "Gunakan MP3 / M4A / OGG / WAV.", variant: "destructive" });
      return;
    }
    if (file.size > 6 * 1024 * 1024) {
      toast({ title: "Musik terlalu besar", description: "Maksimal ±6 MB.", variant: "destructive" });
      return;
    }
    setMusikLoading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        /* PERMINTAAN #3 ("jangan sampai semua lagunya!"): musik upload langsung
         * DIPOTONG 14 detik di sisi klien (decode → render 14 dtk → WAV mono 22kHz).
         * Yang disimpan & diputar HANYA potongan 14 detik pertama. */
        const potongan = await potongMusik14Detik(String(reader.result));
        setMusikData(potongan);
        setMusikName(`${file.name.replace(/\.[^.]+$/, "")} (14 dtk)`);
        setMusikVideoId(null);
      } catch {
        // gagal decode (format aneh) → pakai asli, pemutar tetap memotong 14 dtk
        setMusikData(String(reader.result));
        setMusikName(`${file.name} (dipotong 14 dtk)`);
        setMusikVideoId(null);
      } finally {
        setMusikLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  /* ===== PERMINTAAN #3: musik dari LIBRARY situs (hasil scrape — bukan file user).
   * Lagu diambil dari pencarian musik FanzzTools lalu disimpan sebagai URL
   * proxy audio + videoId (penyegaran otomatis bila tautan kedaluwarsa). ===== */
  const [musikLoading, setMusikLoading] = useState(false);
  const [musikLibraryOpen, setMusikLibraryOpen] = useState(false);
  const [musikQuery, setMusikQuery] = useState("");
  const [musikHasil, setMusikHasil] = useState<Array<{ videoId: string; title: string; artist: string; thumb?: string }> | null>(null);
  const [musikCariLoading, setMusikCariLoading] = useState(false);
  const [musikVideoId, setMusikVideoId] = useState<string | null>(null);

  const cariMusik = async () => {
    const q = musikQuery.trim();
    if (!q) return;
    setMusikCariLoading(true);
    try {
      const r = await fetch(`/api/music/search?q=${encodeURIComponent(q)}`);
      const d = await r.json();
      setMusikHasil(d?.ok && Array.isArray(d.songs) ? d.songs.slice(0, 20) : []);
    } catch {
      setMusikHasil([]);
    } finally {
      setMusikCariLoading(false);
    }
  };

  const pakaiMusikLibrary = async (lagu: { videoId: string; title: string; artist: string }) => {
    setMusikLoading(true);
    try {
      const r = await fetch(`/api/music/ytmp3?id=${encodeURIComponent(lagu.videoId)}`);
      const d = await r.json();
      if (!d?.ok || !d.result?.mp3) throw new Error(d?.error || "Gagal memuat lagu");
      const mp3Url = String(d.result.mp3);
      /* Cyber-Update #5b: jalur library kini SETARA dengan jalur upload manual —
       * audio diambil penuh (lewat proxy same-origin agar bebas CORS) → dipotong
       * TEPAT 14 detik (WAV mono 22kHz) → disimpan sebagai data URL mandiri
       * yang tidak bisa kedaluwarsa. Dulu: link mentah disimpan apa adanya
       * (beda durasi + bisa kedaluwarsa/ditolak story-store). */
      const sumber = mp3Url.startsWith("/") ? mp3Url : `/api/stream/proxy?url=${encodeURIComponent(mp3Url)}`;
      let dataUrl: string | null = null;
      try {
        const res = await fetch(sumber);
        if (res.ok) {
          const raw = await res.arrayBuffer();
          const blob = new Blob([raw], { type: sniffAudioMime(raw) });
          dataUrl = await new Promise<string>((resolve, reject) => {
            const fr = new FileReader();
            fr.onload = () => resolve(String(fr.result));
            fr.onerror = () => reject(new Error("baca audio gagal"));
            fr.readAsDataURL(blob);
          });
        }
      } catch {
        dataUrl = null;
      }
      if (!dataUrl) throw new Error("Audio tidak terbaca dari sumber — coba lagu lain");
      try {
        const potongan = await potongMusik14Detik(dataUrl);
        setMusikData(potongan);
        setMusikName(`${lagu.title} — ${lagu.artist} (14 dtk)`);
        setMusikVideoId(null);
      } catch {
        // gagal decode → simpan data URL utuh (tetap mandiri & tidak kedaluwarsa);
        // pemutar tetap memotong 14 detik saat diputar
        setMusikData(dataUrl);
        setMusikName(`${lagu.title} — ${lagu.artist} (dipotong 14 dtk)`);
        setMusikVideoId(null);
      }
      hentikanPreview();
      setMusikLibraryOpen(false);
    } catch (e) {
      toast({ title: "Gagal memuat lagu", description: e instanceof Error ? e.message : "Coba lagu lain", variant: "destructive" });
    } finally {
      setMusikLoading(false);
    }
  };

  /* Cyber-Update #5a: PREVIEW lagu library — dengar dulu (play/pause) lewat
   * /api/music/ytmp3?id=... SEBELUM menekan "pakai". Satu <audio> tersembunyi
   * dipakai bergantian (hanya satu lagu bersuara pada satu waktu). */
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [previewPlaying, setPreviewPlaying] = useState(false);
  const [previewLoading, setPreviewLoading] = useState<string | null>(null);
  const previewAudioRef = useRef<HTMLAudioElement | null>(null);
  const previewRetryRef = useRef(false);

  /** hentikan preview — dipanggil saat lagu dipakai / modal ditutup
   * (elemen <audio> ikut ter-unmount bersama modal, jadi pemutaran pasti berhenti). */
  const hentikanPreview = () => {
    const a = previewAudioRef.current;
    if (a) {
      a.pause();
      a.removeAttribute("src");
    }
    setPreviewId(null);
    setPreviewPlaying(false);
    setPreviewLoading(null);
  };

  const togglePreview = async (videoId: string) => {
    const a = previewAudioRef.current;
    if (!a) return;
    if (previewId === videoId && previewPlaying) {
      a.pause();
      setPreviewPlaying(false);
      return;
    }
    if (previewId === videoId) {
      // sudah dimuat — lanjutkan dari posisi jeda
      previewRetryRef.current = false;
      a.play().then(() => setPreviewPlaying(true)).catch(() => setPreviewPlaying(false));
      return;
    }
    setPreviewLoading(videoId);
    try {
      const r = await fetch(`/api/music/ytmp3?id=${encodeURIComponent(videoId)}`);
      const d = await r.json();
      if (!d?.ok || !d.result?.mp3) throw new Error(d?.error || "Gagal memuat audio");
      a.src = String(d.result.mp3);
      a.currentTime = 0;
      previewRetryRef.current = false;
      setPreviewId(videoId);
      a.play().then(() => setPreviewPlaying(true)).catch(() => setPreviewPlaying(false));
    } catch (e) {
      toast({ title: "Preview gagal", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
      setPreviewId(null);
      setPreviewPlaying(false);
    } finally {
      setPreviewLoading(null);
    }
  };

  const kirimStory = async () => {
    if (uploading) return;
    if (tipe === "text" && !teks.trim()) {
      toast({ title: "Teks status kosong" });
      return;
    }
    if (tipe === "video" && !videoData) {
      toast({ title: "Belum ada video", description: "Pilih video dulu." });
      return;
    }
    if (tipe === "photo" && !fotoData) {
      toast({ title: "Belum ada foto", description: "Pilih foto dulu." });
      return;
    }
    setUploading(true);
    try {
      const r = await fetch("/api/story/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: tipe,
          text: teks.trim(),
          bg: bgIdx,
          data: tipe === "video" ? videoData : tipe === "photo" ? fotoData : undefined,
          music: tipe === "photo" ? (musikData || undefined) : undefined,
          musicVideo: tipe === "photo" ? (musikVideoId || undefined) : undefined,
        }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal mengunggah");
      toast({
        title: "Story terkirim! 🎉",
        description: tipe === "photo"
          ? `Foto tampil 14 detik${musikData ? " dengan musik latar (dipotong 14 dtk)" : ""} — aktif ${sisaWaktu(STORY_MS)}.`
          : `Aktif ${sisaWaktu(STORY_MS)} — semua user bisa melihat.`,
      });
      setBuatOpen(false);
      setTeks("");
      setVideoData(null);
      setVideoName("");
      setFotoData(null);
      setFotoName("");
      setMusikData(null);
      setMusikName("");
      await muat();
    } catch (e) {
      toast({ title: "Gagal mengunggah story", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  /* ---------- pemutar ---------- */
  const bukaGroup = async (g: StoryGroup, idx = 0) => {
    setPlayGroup(g);
    setPlayIdx(idx);
    setProgress(0);
    setPaused(false);
    setKomentarOpen(false);
    setLihatPenonton(false);
    await tandaiTonton(g.stories[idx]?.id);
  };

  const tandaiTonton = async (id?: string) => {
    if (!id) return;
    try {
      // PERBAIKAN #5: respons /api/story/view berisi data video/foto/musik —
      // dulu diabaikan, jadi src pemutar undefined → video layar hitam.
      const r = await fetch("/api/story/view", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      const d = await r.json();
      if (d?.ok && d.story) {
        setPlayGroup((g) =>
          g
            ? {
                ...g,
                stories: g.stories.map((s) =>
                  s.id === id ? { ...s, data: d.story.data, music: d.story.music } : s
                ),
              }
            : g
        );
      }
    } catch {
      /* diam */
    }
  };

  const storyAktif = playGroup?.stories[playIdx] || null;

  // reset ekspansi caption tiap pindah story (permintaan #1)
  useEffect(() => {
    setCaptionExpanded(false);
  }, [storyAktif?.id]);

  /* Caption terpusat + potongan "Selengkapnya.." (permintaan #1 —
   * caption TIDAK lagi berjalan marquee; teks rata tengah, panjang dipotong
   * dengan gaya "... Ya karena aku tuh... Selengkapnya.." yang bisa dibuka). */
  const CaptionTengah = ({ teks }: { teks: string }) => {
    const panjang = teks.length > CAPTION_POTONG;
    const tampil = panjang && !captionExpanded ? `${teks.slice(0, CAPTION_POTONG).trimEnd()}... ` : teks;
    return (
      <div className={`px-5 py-4 pb-8 text-center ${captionExpanded && panjang ? "max-h-[46%] overflow-y-auto" : ""}`}>
        <p className="mx-auto max-w-md whitespace-pre-wrap text-[13.5px] font-semibold leading-relaxed text-white drop-shadow-md" data-fanzz-selectable="1">
          {tampil}
          {panjang && !captionExpanded && (
            <button
              onClick={(e) => { e.stopPropagation(); setCaptionExpanded(true); }}
              className="ml-0.5 whitespace-nowrap font-extrabold text-cyan-300 underline decoration-cyan-400/60 underline-offset-2"
            >
              Selengkapnya..
            </button>
          )}
        </p>
        {panjang && captionExpanded && (
          <button
            onClick={(e) => { e.stopPropagation(); setCaptionExpanded(false); }}
            className="mt-1.5 text-[10px] font-extrabold text-white/60"
          >
            Tutup
          </button>
        )}
      </div>
    );
  };

  /* ===== PERBARUAN #4: kontrol musik latar (foto+musik, dipotong 14 dtk) ===== */
  const musicRef = useRef<HTMLAudioElement | null>(null);

  // mulai / hentikan musik mengikuti story aktif
  useEffect(() => {
    const a = musicRef.current;
    if (!a) return;
    if (storyAktif?.type === "photo" && storyAktif.music && !paused && !komentarOpen && !lihatPenonton) {
      a.currentTime = 0;
      a.play().catch(() => {});
    } else {
      a.pause();
    }
  }, [storyAktif?.id, storyAktif?.type, storyAktif?.music, paused, komentarOpen, lihatPenonton]);

  // musik dipotong tepat 14 detik (sinkron dengan durasi tampil foto)
  const potongMusik = () => {
    const a = musicRef.current;
    if (!a) return;
    if (a.currentTime >= 13.9) a.pause(); // 14 dtk — dipotong
  };

  /* PERMINTAAN #3: URL audio library kedaluwarsa → minta URL segar lewat
   * /api/music/ytmp3?fresh=1 (videoId tersimpan di story), lalu tukar src. */
  const segarkanMusikLibrary = useCallback(async (storyId: string) => {
    const grup = playGroup;
    const st = grup?.stories.find((s) => s.id === storyId);
    if (!st?.musicVideo || !st.music || !grup) return;
    try {
      const r = await fetch(`/api/music/ytmp3?fresh=1&id=${encodeURIComponent(st.musicVideo)}`);
      const d = await r.json();
      if (!d?.ok || !d.result?.mp3 || d.result.mp3 === st.music) return;
      setPlayGroup((g) =>
        g
          ? { ...g, stories: g.stories.map((s) => (s.id === storyId ? { ...s, music: d.result.mp3 } : s)) }
          : g
      );
    } catch {
      /* diam — musik opsional */
    }
  }, [playGroup]);

  // progres bar teks & foto (video pakai timeupdate)
  useEffect(() => {
    if (!storyAktif || paused || komentarOpen || lihatPenonton) return;
    if (storyAktif.type === "video") return;
    // PERBARUAN #4: foto+musik tampil 14 detik; teks 7 detik
    const durasi = storyAktif.type === "photo" ? (storyAktif.photoDuration || FOTO_DURASI) : TEXT_DURASI;
    const mulai = performance.now() - (progress / 100) * durasi;
    const tick = () => {
      const p = Math.min(100, ((performance.now() - mulai) / durasi) * 100);
      setProgress(p);
      if (p >= 100) lanjutStory();
      else rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playGroup, playIdx, paused, komentarOpen, lihatPenonton]);

  const lanjutStory = async () => {
    if (!playGroup) return;
    if (playIdx < playGroup.stories.length - 1) {
      const next = playIdx + 1;
      setPlayIdx(next);
      setProgress(0);
      await tandaiTonton(playGroup.stories[next].id);
    } else {
      tutupPlayer();
    }
  };

  const balikStory = async () => {
    if (!playGroup) return;
    if (playIdx > 0) {
      const prev = playIdx - 1;
      setPlayIdx(prev);
      setProgress(0);
      await tandaiTonton(playGroup.stories[prev].id);
    }
  };

  const tutupPlayer = () => {
    // hentikan musik latar juga
    if (musicRef.current) {
      musicRef.current.pause();
      musicRef.current.removeAttribute("src");
    }
    setPlayGroup(null);
    setKomentarOpen(false);
    setLihatPenonton(false);
    void muat(); // refresh likes/viewers terbaru
  };

  const toggleLike = async () => {
    if (!storyAktif) return;
    try {
      const r = await fetch("/api/story/like", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: storyAktif.id }),
      });
      const d = await r.json();
      if (d?.ok && playGroup) {
        const gs = { ...playGroup };
        gs.stories = gs.stories.map((s) =>
          s.id === storyAktif.id ? { ...s, likedByMe: d.liked, likes: d.likes } : s
        );
        setPlayGroup(gs);
      }
    } catch {
      toast({ title: "Gagal like", variant: "destructive" });
    }
  };

  const kirimKomentar = async () => {
    if (!storyAktif || !komentarTeks.trim()) return;
    try {
      const r = await fetch("/api/story/comment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: storyAktif.id, text: komentarTeks.trim() }),
      });
      const d = await r.json();
      if (d?.ok && playGroup) {
        const gs = { ...playGroup };
        gs.stories = gs.stories.map((s) =>
          s.id === storyAktif.id ? { ...s, comments: [...s.comments, d.comment] } : s
        );
        setPlayGroup(gs);
        setKomentarTeks("");
        toast({ title: "Komentar terkirim!" });
      } else throw new Error(d?.error);
    } catch {
      toast({ title: "Gagal mengirim komentar", variant: "destructive" });
    }
  };

  const hapusStory = async (id: string) => {
    try {
      const r = await fetch(`/api/story/delete?id=${encodeURIComponent(id)}`, { method: "DELETE" });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error);
      toast({ title: "Status dihapus" });
      if (playGroup) {
        const sisa = playGroup.stories.filter((s) => s.id !== id);
        if (!sisa.length) tutupPlayer();
        else setPlayGroup({ ...playGroup, stories: sisa });
      }
      void muat();
    } catch (e) {
      toast({ title: "Gagal menghapus", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  };

  const totalStorySaya = groups?.find((g) => g.isMe)?.stories.length || 0;

  return (
    <div className="pb-4">
      {/* header ringkas */}
      <div className="glass mb-4 flex items-center justify-between rounded-2xl p-4">
        <div>
          <h2 className="text-base font-extrabold">FanzzStory</h2>
          <p className="text-[10.5px] text-muted-foreground">Status 22 jam • maks 5 aktif • global untuk semua user</p>
        </div>
        <button
          onClick={() => setBuatOpen(true)}
          disabled={totalStorySaya >= 5}
          className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-3.5 py-2.5 text-[11px] font-extrabold text-white disabled:opacity-50"
        >
          <Plus className="h-4 w-4" /> Buat Story
        </button>
      </div>

      {groups === null && (
        <div className="no-scrollbar flex gap-3 overflow-hidden">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="w-16 shrink-0 space-y-1.5">
              <div className="h-16 w-16 rounded-full shimmer" />
              <div className="mx-auto h-2 w-10 rounded shimmer" />
            </div>
          ))}
        </div>
      )}

      {groups && groups.length === 0 && (
        <div className="glass rounded-2xl p-8 text-center">
          <p className="text-sm font-extrabold">Belum ada story</p>
          <p className="mt-1 text-[11px] text-muted-foreground">Jadilah yang pertama membuat FanzzStory — tekan tombol Buat Story.</p>
        </div>
      )}

      {/* baris avatar story */}
      {groups && groups.length > 0 && (
        <div className="no-scrollbar flex gap-3.5 overflow-x-auto pb-2">
          {/* tombol buat (cepat) */}
          <button onClick={() => setBuatOpen(true)} disabled={totalStorySaya >= 5} className="w-16 shrink-0 space-y-1.5 text-center disabled:opacity-50">
            <span className="relative flex h-16 w-16 items-center justify-center rounded-full border-2 border-dashed border-red-400/50 bg-secondary/50">
              <Plus className="h-6 w-6 text-red-400" />
            </span>
            <p className="truncate text-[9px] font-bold text-muted-foreground">Buat ({totalStorySaya}/5)</p>
          </button>
          {groups.map((g) => (
            <button key={g.uid} onClick={() => bukaGroup(g, 0)} className="w-16 shrink-0 space-y-1.5 text-center">
              <span className={`relative block h-16 w-16 rounded-full p-[3px] ${g.isMe ? "bg-gradient-to-br from-emerald-400 to-teal-500" : "bg-gradient-to-br from-red-500 to-red-700"}`}>
                {g.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={g.avatar} alt={g.username} className="h-full w-full rounded-full border-2 border-background object-cover" />
                ) : (
                  <span className={`flex h-full w-full items-center justify-center rounded-full border-2 border-background bg-gradient-to-br ${g.avatarColor} text-lg font-extrabold text-white`}>
                    {g.username.charAt(0).toUpperCase()}
                  </span>
                )}
                {g.isMe && (
                  <span className="absolute -bottom-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-[9px] font-black text-white ring-2 ring-background">
                    {g.stories.length}
                  </span>
                )}
              </span>
              <p className={`truncate text-[9px] font-bold ${g.isMe ? "text-emerald-400" : ""}`}>{g.isMe ? "Kamu" : g.username}</p>
            </button>
          ))}
        </div>
      )}

      {/* daftar terbaru */}
      {groups && groups.filter((g) => !g.isMe).length > 0 && (
        <section className="mt-5">
          <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
            <Users className="h-4 w-4 text-red-400" /> Story Terbaru
          </h3>
          <div className="space-y-2">
            {groups
              .filter((g) => !g.isMe)
              .flatMap((g) => g.stories.map((s) => ({ ...s, groupUsername: g.username, groupAvatar: g.avatar, groupColor: g.avatarColor })))
              .sort((a, b) => b.createdAt - a.createdAt)
              .slice(0, 15)
              .map((s) => (
                <button
                  key={s.id}
                  onClick={() => bukaGroup(groups.find((g) => g.uid === s.uid)!, groups.find((g) => g.uid === s.uid)!.stories.findIndex((x) => x.id === s.id))}
                  className="glass flex w-full items-center gap-3 rounded-2xl p-3 text-left transition-colors hover:bg-secondary/70"
                >
                  {s.groupAvatar || s.avatar ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={s.groupAvatar || s.avatar || ""} alt="" className="h-10 w-10 shrink-0 rounded-full object-cover" />
                  ) : (
                    <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${s.groupColor} text-sm font-extrabold text-white`}>
                      {(s.username || s.groupUsername).charAt(0).toUpperCase()}
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-extrabold">{s.username}</p>
                    <p className="truncate text-[10px] text-muted-foreground">
                      {s.type === "text"
                        ? s.text.slice(0, 60)
                        : s.type === "photo"
                          ? `🖼️ foto${s.hasMusic ? " + musik" : ""} • 14 dtk${s.text ? ` • ${s.text.slice(0, 30)}` : ""}`
                          : `🎬 video • ${s.text ? s.text.slice(0, 40) : "tanpa caption"}`}
                    </p>
                  </div>
                  <div className="shrink-0 text-right">
                    <p className="text-[9px] font-bold text-muted-foreground">{sisaWaktu(s.expiresAt - Date.now())}</p>
                    <p className="text-[9px] font-bold text-red-400">❤ {s.likes} 💬 {s.comments.length}</p>
                  </div>
                </button>
              ))}
          </div>
        </section>
      )}

      {/* ==================== MODAL BUAT STORY ==================== */}
      <AnimatePresence>
        {buatOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center"
            onClick={() => setBuatOpen(false)}
          >
            <motion.div
              initial={{ y: 60, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 60, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="max-h-[88dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] p-5 sm:rounded-3xl"
            >
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-base font-extrabold">Buat FanzzStory</h3>
                <button onClick={() => setBuatOpen(false)} className="rounded-xl bg-secondary p-2 text-muted-foreground">
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* pilih tipe — PERBARUAN #4: teks / foto+musik / video */}
              <div className="mb-4 grid grid-cols-3 gap-2">
                {([
                  { id: "text", label: "Status Teks", icon: Type },
                  { id: "photo", label: "Foto + Musik", icon: ImageIcon },
                  { id: "video", label: "Video + Caption", icon: Camera },
                ] as const).map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setTipe(t.id)}
                    className={`flex flex-col items-center justify-center gap-1.5 rounded-xl px-2 py-3 text-[10.5px] font-extrabold transition ${
                      tipe === t.id ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    <t.icon className="h-4 w-4" /> {t.label}
                  </button>
                ))}
              </div>

              {tipe === "photo" ? (
                <>
                  {/* PERBARUAN #4: foto + musik latar — tampil 14 detik */}
                  <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-red-400/40 bg-secondary/30 p-5 text-center transition-colors hover:bg-secondary/60">
                    {fotoData ? (
                      <>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={fotoData} alt="pratinjau" className="max-h-40 rounded-xl object-contain" />
                        <p className="text-[10.5px] font-bold text-emerald-400">✓ {fotoName} — ketuk untuk ganti</p>
                      </>
                    ) : (
                      <>
                        <ImageIcon className="h-7 w-7 text-red-400" />
                        <p className="text-xs font-bold">Pilih foto (PNG/JPG/WebP, maks ±7 MB)</p>
                        <p className="text-[10px] text-muted-foreground">Foto tampil TETAP 14 detik</p>
                      </>
                    )}
                    <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => pilihFoto(e.target.files?.[0])} />
                  </label>

                  {/* musik latar opsional — file ATAU dari library musik situs */}
                  <label className="mt-2.5 flex cursor-pointer items-center gap-3 rounded-2xl border-2 border-dashed border-cyan-400/30 bg-secondary/30 p-3.5 transition-colors hover:bg-secondary/60">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white">
                      {musikLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Music className="h-5 w-5" />}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-xs font-bold">{musikData ? `🎵 ${musikName}` : "Tambah musik latar (opsional)"}</p>
                      <p className="truncate text-[10px] text-muted-foreground">
                        {musikData ? "Dipotong 14 detik — ketuk untuk ganti file" : "MP3/M4A/OGG/WAV maks ±6 MB — otomatis dipotong 14 dtk"}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); setMusikLibraryOpen(true); }}
                      className="flex h-9 shrink-0 items-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-3 text-[10px] font-extrabold text-white"
                    >
      <Search className="h-3.5 w-3.5" /> Library
                    </button>
                    {musikData && (
                      <button
                        type="button"
                        onClick={(e) => { e.preventDefault(); e.stopPropagation(); setMusikData(null); setMusikName(""); setMusikVideoId(null); }}
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-500/15 text-red-300"
                        aria-label="Hapus musik"
                      >
                        <VolumeX className="h-4 w-4" />
                      </button>
                    )}
                    <input type="file" accept="audio/mpeg,audio/mp3,audio/mp4,audio/aac,audio/ogg,audio/wav,audio/x-m4a,audio/webm" className="hidden" onChange={(e) => pilihMusik(e.target.files?.[0])} />
                  </label>

                  {/* modal library musik situs (permintaan #3 — lagu dari sc situs) */}
                  <AnimatePresence>
                    {musikLibraryOpen && (
                      <motion.div
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                        className="fixed inset-0 z-[80] flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center"
                        onClick={() => { hentikanPreview(); setMusikLibraryOpen(false); }}
                      >
                        <motion.div
                          initial={{ y: 60 }} animate={{ y: 0 }} exit={{ y: 60 }}
                          onClick={(e) => e.stopPropagation()}
                          className="max-h-[76dvh] w-full max-w-md overflow-hidden rounded-t-3xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] sm:rounded-3xl"
                        >
                          <div className="border-b border-border/50 p-4">
                            <p className="mb-2 text-sm font-extrabold">🎵 Cari musik dari library FanzzTools</p>
                            <div className="flex gap-2">
                              <input
                                value={musikQuery}
                                onChange={(e) => setMusikQuery(e.target.value)}
                                onKeyDown={(e) => e.key === "Enter" && cariMusik()}
                                placeholder="Judul lagu / artis…"
                                className="min-w-0 flex-1 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-cyan-400/50"
                              />
                              <button onClick={cariMusik} className="rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 px-3.5 text-xs font-extrabold text-white">
                                Cari
                              </button>
                            </div>
                            <p className="mt-1.5 text-[9.5px] text-muted-foreground">Ketuk ▶ untuk dengar preview — lagu diputar hanya 14 detik pertama, sesuai durasi foto.</p>
                          </div>
                          <div className="max-h-[52dvh] overflow-y-auto p-3">
                            {/* audio preview tersembunyi — sumbernya /api/music/ytmp3?id=... (per tombol play) */}
                            <audio
                              ref={previewAudioRef}
                              hidden
                              preload="none"
                              onEnded={() => { setPreviewPlaying(false); setPreviewId(null); }}
                              onError={() => {
                                // URL audio kedaluwarsa → coba segarkan SEKALI via fresh=1
                                const vid = previewId;
                                if (!vid || previewRetryRef.current) {
                                  setPreviewPlaying(false);
                                  setPreviewId(null);
                                  return;
                                }
                                previewRetryRef.current = true;
                                void (async () => {
                                  try {
                                    const r = await fetch(`/api/music/ytmp3?fresh=1&id=${encodeURIComponent(vid)}`);
                                    const d = await r.json();
                                    const a = previewAudioRef.current;
                                    if (d?.ok && d.result?.mp3 && a) {
                                      a.src = String(d.result.mp3);
                                      a.play().then(() => setPreviewPlaying(true)).catch(() => setPreviewPlaying(false));
                                      return;
                                    }
                                  } catch {
                                    /* diam */
                                  }
                                  setPreviewPlaying(false);
                                  setPreviewId(null);
                                })();
                              }}
                            />
                            {musikCariLoading && <p className="py-6 text-center text-xs font-bold text-muted-foreground">Mencari…</p>}
                            {!musikCariLoading && musikHasil && musikHasil.length === 0 && (
                              <p className="py-6 text-center text-xs font-bold text-muted-foreground">Tidak ketemu — coba kata kunci lain.</p>
                            )}
                            {!musikCariLoading && musikHasil?.map((s) => {
                              const isThisLoading = previewLoading === s.videoId;
                              const isPlaying = previewId === s.videoId && previewPlaying;
                              return (
                                <div
                                  key={s.videoId}
                                  className="mb-1.5 flex w-full items-center gap-2 rounded-xl bg-secondary/40 p-2.5 transition hover:bg-secondary/70"
                                >
                                  {/* tombol preview (Cyber-Update #5a): dengar dulu sebelum "pakai" */}
                                  <button
                                    type="button"
                                    onClick={() => togglePreview(s.videoId)}
                                    disabled={isThisLoading}
                                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-cyan-500/15 text-cyan-300 transition active:scale-90 disabled:opacity-50"
                                    aria-label={isPlaying ? `Jeda preview ${s.title}` : `Putar preview ${s.title}`}
                                    title={isPlaying ? "Jeda preview" : "Putar preview (14 dtk pertama)"}
                                  >
                                    {isThisLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => pakaiMusikLibrary(s)}
                                    className="flex min-w-0 flex-1 items-center gap-3 text-left"
                                    title="Pakai lagu ini (otomatis dipotong 14 detik)"
                                  >
                                    {s.thumb ? (
                                      // eslint-disable-next-line @next/next/no-img-element
                                      <img src={s.thumb} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-300"><Music className="h-4 w-4" /></span>
                                    )}
                                    <span className="min-w-0 flex-1 block">
                                      <span className="block truncate text-xs font-bold">{s.title}</span>
                                      <span className="block truncate text-[10px] text-muted-foreground">{s.artist}</span>
                                    </span>
                                    <span className="shrink-0 rounded-full bg-cyan-500/15 px-2 py-1 text-[9px] font-extrabold text-cyan-300">14 dtk</span>
                                  </button>
                                </div>
                              );
                            })}
                            {!musikHasil && !musikCariLoading && (
                              <p className="py-8 text-center text-[11px] leading-relaxed text-muted-foreground">Ketik judul lagu lalu tekan Cari.<br />Sumber: library musik FanzzTools.</p>
                            )}
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <p className="mb-1.5 mt-3 text-[10px] font-bold text-muted-foreground">Caption di bawah foto (opsional)</p>
                  <textarea
                    value={teks}
                    onChange={(e) => setTeks(e.target.value.slice(0, 300))}
                    rows={2}
                    placeholder="Caption…"
                    className="w-full resize-none rounded-xl border border-border/60 bg-secondary/50 p-3 text-sm outline-none focus:border-red-400/50"
                  />

                  <div className="mt-2.5 flex items-center gap-2 rounded-xl bg-cyan-500/10 p-3 text-[10px] leading-relaxed text-cyan-200">
                    <ClockIcon className="h-4 w-4 shrink-0" />
                    <span>Foto + musik ditampilkan selama <b>14 detik</b> — musik otomatis <b>dipotong 14 detik</b> (lebih panjang dari itu dipotong, lebih pendek berhenti mengikuti lagu).</span>
                  </div>
                </>
              ) : tipe === "video" ? (
                <>
                  <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-red-400/40 bg-secondary/30 p-6 text-center transition-colors hover:bg-secondary/60">
                    {videoData ? (
                      <>
                        <video src={videoData} className="max-h-40 rounded-xl" controls />
                        <p className="text-[10.5px] font-bold text-emerald-400">✓ {videoName} — ketuk untuk ganti</p>
                      </>
                    ) : (
                      <>
                        <Camera className="h-8 w-8 text-red-400" />
                        <p className="text-xs font-bold">Pilih video (MP4/WebM, maks ±10 MB)</p>
                        <p className="text-[10px] text-muted-foreground">Video diproses langsung di HP kamu, lalu dikirim ke server FanzzStory</p>
                      </>
                    )}
                    <input type="file" accept="video/mp4,video/webm,video/quicktime" className="hidden" onChange={(e) => pilihVideo(e.target.files?.[0])} />
                  </label>
                  <p className="mb-1.5 mt-3 text-[10px] font-bold text-muted-foreground">Caption di bawah video (opsional)</p>
                  <textarea
                    value={teks}
                    onChange={(e) => setTeks(e.target.value.slice(0, 300))}
                    rows={2}
                    placeholder="Caption…"
                    className="w-full resize-none rounded-xl border border-border/60 bg-secondary/50 p-3 text-sm outline-none focus:border-red-400/50"
                  />
                </>
              ) : (
                <>
                  <textarea
                    value={teks}
                    onChange={(e) => setTeks(e.target.value.slice(0, 700))}
                    rows={4}
                    placeholder="Tulis statusmu… (maks 700 karakter)"
                    className="w-full resize-none rounded-xl border border-border/60 bg-secondary/50 p-3 text-sm outline-none focus:border-red-400/50"
                    style={{ background: BG_GRADIENTS[bgIdx], color: "#fff" }}
                  />
                  <p className="mt-1 flex justify-between text-[9.5px] font-bold text-muted-foreground">
                    <span>pilih latar di bawah</span>
                    <span>{teks.length}/700</span>
                  </p>
                  <div className="mt-2 grid grid-cols-5 gap-2">
                    {BG_GRADIENTS.map((bg, i) => (
                      <button
                        key={i}
                        onClick={() => setBgIdx(i)}
                        className={`h-10 rounded-xl transition ${bgIdx === i ? "ring-2 ring-red-400" : "opacity-70"}`}
                        style={{ background: bg }}
                        aria-label={`latar ${i + 1}`}
                      />
                    ))}
                  </div>
                </>
              )}

              <div className="mt-3 rounded-xl bg-red-500/10 p-3 text-[10px] leading-relaxed text-red-200">
                Status aktif <b>{totalStorySaya}/5</b> • bertahan <b>22 jam</b> lalu hilang otomatis • terlihat <b>semua user FanzzTools</b> (global).
              </div>

              <button
                onClick={kirimStory}
                disabled={uploading}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-4 py-3.5 text-xs font-extrabold text-white disabled:opacity-60"
              >
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {uploading ? "Mengunggah…" : "Kirim Story"}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ==================== PEMUTAR STORY ==================== */}
      <AnimatePresence>
        {playGroup && storyAktif && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[80] flex items-center justify-center bg-black">
            <div className="relative h-full w-full max-w-md">
              {/* progress bars */}
              <div className="absolute inset-x-2 top-2 z-20 flex gap-1">
                {playGroup.stories.map((s, i) => (
                  <div key={s.id} className="h-[3px] flex-1 overflow-hidden rounded-full bg-white/25">
                    <div
                      className="h-full rounded-full bg-white transition-[width] duration-100"
                      style={{ width: i < playIdx ? "100%" : i === playIdx ? `${progress}%` : "0%" }}
                    />
                  </div>
                ))}
              </div>

              {/* header */}
              <div className="absolute inset-x-0 top-0 z-20 flex items-center gap-2.5 bg-gradient-to-b from-black/70 to-transparent px-3 pb-8 pt-7">
                <button onClick={tutupPlayer} className="rounded-full p-1.5 text-white/90">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                {storyAktif.avatar || playGroup.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={storyAktif.avatar || playGroup.avatar || ""} alt="" className="h-9 w-9 rounded-full object-cover" />
                ) : (
                  <span className={`flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br ${playGroup.avatarColor} text-sm font-extrabold text-white`}>
                    {playGroup.username.charAt(0).toUpperCase()}
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-extrabold text-white">{playGroup.isMe ? "Status kamu" : playGroup.username}</p>
                  <p className="text-[9px] font-bold text-white/60">
                    {new Date(storyAktif.createdAt).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })} • {sisaWaktu(storyAktif.expiresAt - Date.now())}
                  </p>
                </div>

                {/* tombol komentar — pojok kanan atas, kecil, tidak menghalangi */}
                <button
                  onClick={() => setKomentarOpen((v) => !v)}
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full backdrop-blur-md transition ${
                    komentarOpen ? "bg-red-500 text-white" : "bg-black/45 text-white/90"
                  }`}
                  title="Komentar"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                </button>
                {storyAktif.canDelete && (
                  <button onClick={() => hapusStory(storyAktif.id)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-black/45 text-red-300" title="Hapus status">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                )}
                {!storyAktif.canDelete && (
                  <button onClick={() => setPaused((p) => !p)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-black/45 text-white/90" title="Jeda">
                    {paused ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
                  </button>
                )}
              </div>

              {/* isi story */}
              <div className="absolute inset-0" onClick={() => lanjutStory()}>
                {storyAktif.type === "text" ? (
                  <div className="flex h-full w-full items-center justify-center p-8" style={{ background: BG_GRADIENTS[storyAktif.bg % BG_GRADIENTS.length] }}>
                    <p className="max-h-full select-none overflow-hidden whitespace-pre-wrap text-center text-lg font-extrabold leading-relaxed text-white drop-shadow-lg" data-fanzz-selectable="1">
                      {storyAktif.text}
                    </p>
                  </div>
                ) : storyAktif.type === "photo" ? (
                  /* PERBARUAN #4: foto + musik latar — tampil 14 detik, musik dipotong 14 dtk */
                  <div className="flex h-full w-full flex-col">
                    <div className="relative flex min-h-0 w-full flex-1 items-center justify-center bg-black">
                      {storyAktif.data ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={storyAktif.data} alt="foto status" className="max-h-full max-w-full object-contain" />
                      ) : (
                        <div className="flex flex-col items-center gap-2 text-white/50">
                          <Loader2 className="h-7 w-7 animate-spin" />
                          <p className="text-[10px] font-bold">Memuat foto…</p>
                        </div>
                      )}
                      {storyAktif.hasMusic && (
                        <span className="absolute bottom-3 left-3 flex items-center gap-1.5 rounded-full bg-black/55 px-2.5 py-1 text-[10px] font-extrabold text-white backdrop-blur-md">
                          <Music className="h-3 w-3 text-cyan-300" /> Musik latar · dipotong 14 dtk
                        </span>
                      )}
                      {/* sisa waktu foto (14 dtk) */}
                      <span className="absolute bottom-3 right-3 rounded-full bg-black/55 px-2.5 py-1 text-[10px] font-extrabold tabular-nums text-white backdrop-blur-md">
                        {Math.max(0, Math.ceil(((storyAktif.photoDuration || FOTO_DURASI) * (1 - progress / 100)) / 1000))}s
                      </span>
                    </div>
                    {storyAktif.text && (
                      <div className="max-h-[34%] overflow-hidden bg-gradient-to-t from-black/90 to-black/40">
                        <CaptionTengah teks={storyAktif.text} />
                      </div>
                    )}
                    {/* elemen musik latar — dipotong otomatis 14 dtk; URL library
                        bisa kedaluwarsa → auto-segar lewat videoId (permintaan #3) */}
                    {storyAktif.music && (
                      <audio
                        ref={musicRef}
                        src={storyAktif.music}
                        onTimeUpdate={potongMusik}
                        onError={() => { void segarkanMusikLibrary(storyAktif.id); }}
                        onEnded={() => { /* musik lebih pendek → berhenti natural */ }}
                      />
                    )}
                  </div>
                ) : (
                  <div className="flex h-full w-full flex-col">
                    {/* PERBAIKAN #5: video src kini diisi dari /api/story/view (dulu undefined → layar hitam) */}
                    {storyAktif.data ? (
                      <video
                        ref={videoRef}
                        src={storyAktif.data}
                        className="min-h-0 w-full flex-1 bg-black object-contain"
                        autoPlay
                        playsInline
                        onTimeUpdate={(e) => {
                          const v = e.currentTarget;
                          if (v.duration) setProgress((v.currentTime / v.duration) * 100);
                        }}
                        onEnded={lanjutStory}
                        controls={false}
                      />
                    ) : (
                      <div className="flex min-h-0 w-full flex-1 flex-col items-center justify-center gap-2 text-white/50">
                        <Loader2 className="h-8 w-8 animate-spin" />
                        <p className="text-[11px] font-bold">Memuat video…</p>
                      </div>
                    )}
                    {storyAktif.text && (
                      <div className="max-h-[34%] overflow-hidden bg-gradient-to-t from-black/90 to-black/40">
                        <CaptionTengah teks={storyAktif.text} />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* area ketuk kiri untuk mundur */}
              <button onClick={balikStory} className="absolute bottom-16 left-0 top-16 w-1/4 opacity-0" aria-label="sebelumnya" />

              {/* aksi bawah */}
              <div className="absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/80 to-transparent p-3 pb-5">
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleLike}
                    className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[11px] font-extrabold backdrop-blur-md transition ${
                      storyAktif.likedByMe ? "bg-rose-500 text-white" : "bg-white/15 text-white"
                    }`}
                  >
                    <Heart className={`h-4 w-4 ${storyAktif.likedByMe ? "fill-current" : ""}`} /> {storyAktif.likes}
                  </button>
                  <button
                    onClick={() => setKomentarOpen(true)}
                    className="flex items-center gap-1.5 rounded-full bg-white/15 px-3.5 py-2 text-[11px] font-extrabold text-white backdrop-blur-md"
                  >
                    <MessageCircle className="h-4 w-4" /> {storyAktif.comments.length}
                  </button>
                  {storyAktif.canDelete && storyAktif.viewers !== undefined && (
                    <button
                      onClick={() => setLihatPenonton(true)}
                      className="ml-auto flex items-center gap-1.5 rounded-full bg-white/15 px-3.5 py-2 text-[11px] font-extrabold text-white backdrop-blur-md"
                    >
                      <Eye className="h-4 w-4" /> {storyAktif.viewers} penonton
                    </button>
                  )}
                </div>
              </div>

              {/* panel komentar */}
              <AnimatePresence>
                {komentarOpen && (
                  <motion.div
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 28, stiffness: 300 }}
                    className="absolute inset-x-0 bottom-0 z-30 max-h-[62%] rounded-t-3xl border-t border-white/10 bg-[#141419] p-4"
                  >
                    <div className="mb-3 flex items-center justify-between">
                      <p className="text-sm font-extrabold text-white">Komentar ({storyAktif.comments.length})</p>
                      <button onClick={() => setKomentarOpen(false)} className="rounded-lg bg-white/10 p-1.5 text-white/70">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="max-h-56 space-y-2.5 overflow-y-auto">
                      {storyAktif.comments.length === 0 && (
                        <p className="py-6 text-center text-[11px] text-white/40">Belum ada komentar — jadilah yang pertama!</p>
                      )}
                      {storyAktif.comments.map((c, i) => (
                        <div key={i} className="flex gap-2.5">
                          <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 text-[11px] font-extrabold text-white">
                            {c.username.charAt(0).toUpperCase()}
                          </span>
                          <div className="min-w-0 rounded-2xl rounded-tl-sm bg-white/8 px-3 py-2">
                            <p className="text-[10px] font-extrabold text-red-300">{c.username}</p>
                            <p className="text-[12px] leading-snug text-white/90">{c.text}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 flex gap-2">
                      <input
                        value={komentarTeks}
                        onChange={(e) => setKomentarTeks(e.target.value.slice(0, 240))}
                        onKeyDown={(e) => e.key === "Enter" && kirimKomentar()}
                        placeholder="Tulis komentar…"
                        className="flex-1 rounded-xl bg-white/10 px-3.5 py-2.5 text-[12px] text-white outline-none placeholder:text-white/40"
                      />
                      <button
                        onClick={kirimKomentar}
                        disabled={!komentarTeks.trim()}
                        className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-r from-red-500 to-red-700 text-white disabled:opacity-50"
                      >
                        <Send className="h-4 w-4" />
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* panel penonton (khusus story sendiri) */}
              <AnimatePresence>
                {lihatPenonton && storyAktif.viewersList && (
                  <motion.div
                    initial={{ y: "100%" }}
                    animate={{ y: 0 }}
                    exit={{ y: "100%" }}
                    transition={{ type: "spring", damping: 28, stiffness: 300 }}
                    className="absolute inset-x-0 bottom-0 z-30 max-h-[62%] rounded-t-3xl border-t border-white/10 bg-[#141419] p-4"
                  >
                    <div className="mb-3 flex items-center justify-between">
                      <p className="flex items-center gap-1.5 text-sm font-extrabold text-white">
                        <Eye className="h-4 w-4 text-emerald-400" /> Dilihat {storyAktif.viewers} orang
                      </p>
                      <button onClick={() => setLihatPenonton(false)} className="rounded-lg bg-white/10 p-1.5 text-white/70">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <div className="max-h-64 space-y-2 overflow-y-auto">
                      {storyAktif.viewersList.length === 0 && (
                        <p className="py-6 text-center text-[11px] text-white/40">Belum ada yang menonton status ini.</p>
                      )}
                      {storyAktif.viewersList.map((v) => (
                        <div key={v.uid} className="flex items-center gap-2.5">
                          {v.avatar ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img src={v.avatar} alt="" className="h-8 w-8 rounded-full object-cover" />
                          ) : (
                            <span className={`flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br ${v.avatarColor} text-[11px] font-extrabold text-white`}>
                              {v.username.charAt(0).toUpperCase()}
                            </span>
                          )}
                          <p className="text-[12px] font-bold text-white/90">{v.username}</p>
                          <Check className="ml-auto h-3.5 w-3.5 text-emerald-400" />
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
