"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import {
  Zap, Mail, Send, Loader2, PartyPopper, Crown, ClipboardPaste,
  ShieldCheck, AlertTriangle, Sparkles, CheckCircle2, ExternalLink, MailPlus, RefreshCw,
} from "lucide-react";

interface AmData {
  uid: string;
  email: string;
  status: string;
  membershipStatus: string;
  planName: string;
  subscriptionType: string;
  orderId: string | null;
  activatedAt: string;
  validUntil: string;
  isNewUser: boolean;
  premiumError?: string | null;
}

type Step = 1 | 2 | 3;

export default function AmView() {
  const [step, setStep] = useState<Step>(1);
  const [email, setEmail] = useState("");
  const [magicLink, setMagicLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ message: string; data: AmData | null } | null>(null);
  const { toast } = useToast();

  // mode email trial — magic link dideteksi otomatis dari inbox web
  const [trialMode, setTrialMode] = useState(false);
  const [trialBusy, setTrialBusy] = useState(false);
  const [trialStatus, setTrialStatus] = useState("");
  const [trialSecs, setTrialSecs] = useState(0);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  const STEPS = [
    { n: 1, label: "Email" },
    { n: 2, label: "Verifikasi" },
    { n: 3, label: "Premium!" },
  ];

  const sendLink = async (targetEmail?: string) => {
    if (busy) return;
    const em = (targetEmail || email).trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) {
      toast({ title: "Email tidak valid", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/am/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: em }),
      });
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal mengirim magic link");
      setStep(2);
      toast({
        title: "Magic link terkirim! 🚀",
        description: trialMode ? "Ngedeteksi link otomatis dari inbox…" : `Cek inbox & folder spam ${em}`,
      });
      return true;
    } catch (e) {
      toast({
        title: "Gagal kirim link 😢",
        description: e instanceof Error ? e.message : "Coba lagi nanti",
        variant: "destructive",
      });
      return false;
    } finally {
      setBusy(false);
    }
  };

  /** ====== MODE EMAIL TRIAL: bikin email sementara → kirim AM → deteksi link otomatis ====== */
  const startTrial = async () => {
    if (trialBusy) return;
    setTrialBusy(true);
    setTrialStatus("Membuat email trial…");
    setTrialMode(true);
    setMagicLink("");
    setTrialSecs(0);
    try {
      const cr = await fetch("/api/email/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const cd = await cr.json();
      if (!cd?.ok || !cd?.email) throw new Error(cd?.error || "Gagal bikin email trial");
      setEmail(cd.email);

      setTrialStatus("Kirim magic link ke email trial…");
      const sent = await sendLink(cd.email);
      if (!sent) throw new Error("Gagal kirim link ke email trial");

      setTrialStatus("Nunggu email masuk… (biasanya < 1 menit)");
      setStep(2);

      // polling inbox deteksi magic link
      const startedAt = Date.now();
      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        setTrialSecs(Math.floor((Date.now() - startedAt) / 1000));
        try {
          const r = await fetch(`/api/email/messages?email=${encodeURIComponent(cd.email)}`);
          const d = await r.json();
          if (d?.ok && d.messages?.length) {
            // cari pesan dari alight motion / firebase berisi link verifikasi
            for (const m of d.messages as Array<{ from: string; subject: string; verifyLink: string | null }>) {
              const looksAm = /alight|firebase|motion|sign.?in/i.test(m.from) || /alight|magic|sign|verif/i.test(m.subject) || Boolean(m.verifyLink);
              if (looksAm && m.verifyLink) {
                if (pollRef.current) clearInterval(pollRef.current);
                pollRef.current = null;
                setMagicLink(m.verifyLink);
                setTrialStatus(`Magic link ketemu! 🎉 Link udah terisi otomatis — tinggal tekan tombol Verifikasi.`);
                toast({
                  title: "Magic link ketemu! 🎉",
                  description: "Udah terisi otomatis — tinggal verifikasi",
                });
                return;
              }
            }
          }
        } catch {
          /* lanjut polling */
        }
        const secs = Math.floor((Date.now() - startedAt) / 1000);
        if (secs > 180) {
          if (pollRef.current) clearInterval(pollRef.current);
          pollRef.current = null;
          setTrialStatus("Email sementara tidak terkirim — Google memblokir domain email sementara. Solusi: gunakan email asli Anda (Gmail dll), magic link dijamin masuk (periksa juga folder Spam).");
        } else if (secs > 60) {
          setTrialStatus(`Menunggu… ${secs}s. Apabila lebih dari 1 menit belum masuk, gunakan email Gmail asli Anda — Google sering memblokir email ke domain sementara.`);
        } else {
          setTrialStatus(`Nunggu email masuk… ${secs}s (biasanya < 1 menit)`);
        }
      }, 5000);
    } catch (e) {
      setTrialStatus(e instanceof Error ? e.message : "Gagal mode email trial");
      toast({
        title: "Email trial gagal 😢",
        description: e instanceof Error ? e.message : "Coba lagi atau pakai email biasa",
        variant: "destructive",
      });
    } finally {
      setTrialBusy(false);
    }
  };

  const verify = async () => {
    if (busy) return;
    if (magicLink.trim().length < 10) {
      toast({
        title: "Magic link belum lengkap",
        description: "Salin utuh link dari email lo",
        variant: "destructive",
      });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/am/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim().toLowerCase(), link: magicLink.trim() }),
      });
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Verifikasi gagal");
      setResult({ message: d.message, data: d.data });
      setStep(3);
    } catch (e) {
      toast({
        title: "Verifikasi gagal 😢",
        description: e instanceof Error ? e.message : "Cek lagi magic link lo",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <ToolHeader
        icon={<Zap className="h-5.5 w-5.5" />}
        title="AM Active"
        subtitle="Aktivasi premium Alight Motion via magic link — semua email bisa"
        accent="cyan"
      />

      {/* stepper */}
      <div className="mb-5 flex items-center justify-between px-1">
        {STEPS.map((s, i) => (
          <div key={s.n} className="flex flex-1 items-center">
            <div className="flex flex-col items-center gap-1.5">
              <motion.div
                animate={step > s.n ? { scale: [1, 1.15, 1] } : step === s.n ? { scale: 1 } : {}}
                className={`flex h-8 w-8 items-center justify-center rounded-full text-[11px] font-extrabold transition-all ${
                  step > s.n
                    ? "bg-gradient-to-br from-emerald-400 to-teal-500 text-white shadow-lg shadow-emerald-500/25"
                    : step === s.n
                      ? "bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/25 ring-4 ring-cyan-500/20"
                      : "bg-secondary text-muted-foreground"
                }`}
              >
                {step > s.n ? <CheckCircle2 className="h-4 w-4" /> : s.n}
              </motion.div>
              <span className={`text-[9px] font-bold ${step >= s.n ? "text-cyan-400" : "text-muted-foreground"}`}>
                {s.label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div className="mx-1 -mt-5 h-0.5 flex-1 rounded-full bg-secondary">
                <motion.div
                  initial={false}
                  animate={{ width: step > s.n ? "100%" : "0%" }}
                  transition={{ duration: 0.4 }}
                  className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-teal-500"
                />
              </div>
            )}
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 1 && (
          <motion.div key="s1" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="glass rounded-3xl p-5">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/25">
                <Mail className="h-6 w-6" />
              </span>
              <div>
                <p className="text-sm font-extrabold">Masukin email lo</p>
                <p className="text-[11px] text-muted-foreground">Gmail, Yahoo, Outlook, apa pun bisa ✨</p>
              </div>
            </div>
            <Input
              type="email"
              inputMode="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && sendLink()}
              placeholder="nama@email.com"
              className="rounded-xl border-border/60 bg-secondary/50 py-4 text-sm"
            />
            <Button
              onClick={() => sendLink()}
              disabled={busy || !email.trim()}
              className="mt-3 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 py-4 text-sm font-bold shadow-lg shadow-cyan-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
            >
              {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Send className="mr-2 h-4.5 w-4.5" />}
              {busy ? "Mengirim magic link..." : "Kirim Magic Link"}
            </Button>

            {/* divider "atau" */}
            <div className="my-4 flex items-center gap-3">
              <span className="h-px flex-1 bg-[var(--surface-line)]" />
              <span className="text-[10px] font-bold text-muted-foreground">ATAU</span>
              <span className="h-px flex-1 bg-[var(--surface-line)]" />
            </div>

            {/* tombol mode email trial */}
            <Button
              onClick={startTrial}
              disabled={trialBusy}
              className="w-full rounded-xl bg-gradient-to-r from-red-500 to-red-700 py-4 text-sm font-bold shadow-lg shadow-red-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
            >
              {trialBusy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <MailPlus className="mr-2 h-4.5 w-4.5" />}
              {trialBusy ? "Menyiapkan email trial…" : "Coba Email Trial (Experimental)"}
            </Button>
            <p className="mt-2 text-center text-[10px] leading-relaxed text-muted-foreground">
              Eksperimental: email sementara dibuat di web, magic link dideteksi otomatis. <b>Sering diblokir Google</b> — apabila tidak masuk dalam 2 menit, gunakan email Gmail asli Anda (lebih aman).
            </p>

            <div className="mt-3 flex items-start gap-2 text-[11px] leading-relaxed text-muted-foreground">
              <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" />
              <p>
                Lo bakal terima email berisi <b>magic link</b> dari Alight Motion. Jangan dibuka di browser — cukup <b>salin link-nya</b>, nanti dipaste di langkah berikutnya.
              </p>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div key="s2" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="glass rounded-3xl p-5">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-lg shadow-cyan-500/25">
                <ClipboardPaste className="h-6 w-6" />
              </span>
              <div>
                <p className="text-sm font-extrabold">Paste magic link-nya</p>
                <p className="text-[11px] text-muted-foreground">Link udah dikirim ke {email}</p>
              </div>
            </div>

            {/* status mode trial */}
            {trialMode && (
              <AnimatePresence>
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  className="mb-3 overflow-hidden rounded-2xl bg-red-500/10 p-3.5 text-[11px] leading-relaxed text-red-200"
                >
                  {magicLink ? (
                    <p className="flex items-center gap-2 font-bold">
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                      Link udah terisi otomatis dari inbox trial — langsung tekan tombol di bawah!
                    </p>
                  ) : (
                    <p className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 shrink-0 animate-spin text-red-300" />
                      {trialStatus}
                    </p>
                  )}
                </motion.div>
              </AnimatePresence>
            )}

            <Input
              value={magicLink}
              onChange={(e) => setMagicLink(e.target.value)}
              placeholder="Paste magic link di sini (boleh juga seluruh isi emailnya)"
              className="rounded-xl border-border/60 bg-secondary/50 py-4 text-[11px]"
            />
            <Button
              onClick={verify}
              disabled={busy || magicLink.trim().length < 10}
              className="mt-3 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-teal-600 py-4 text-sm font-bold shadow-lg shadow-cyan-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
            >
              {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Sparkles className="mr-2 h-4.5 w-4.5" />}
              {busy ? "Memverifikasi & mengaktifkan..." : "Verifikasi & Aktifkan Premium"}
            </Button>
            <div className="mt-3 flex gap-2">
              <button
                onClick={() => { setStep(1); setMagicLink(""); if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; } }}
                className="flex-1 rounded-xl bg-secondary/60 py-2.5 text-center text-[11px] font-semibold text-muted-foreground transition-colors hover:text-foreground"
              >
                Ganti email
              </button>
              <button
                onClick={() => sendLink()}
                disabled={busy}
                className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-secondary/60 py-2.5 text-center text-[11px] font-semibold text-muted-foreground transition-colors hover:text-foreground disabled:opacity-50"
              >
                <RefreshCw className="h-3 w-3" /> Kirim ulang link
              </button>
            </div>
            {!trialMode && (
              <div className="mt-3 rounded-2xl bg-cyan-500/10 p-3.5 text-[11px] leading-relaxed text-cyan-200">
                <p className="mb-1 font-bold">Cara ambil magic link dari Gmail:</p>
                <p>1. Buka Gmail → cari email dari <b>Alight Motion</b> (pengirim <b>noreply@alight-creative.firebaseapp.com</b>) — cek folder <b>Spam</b> juga ya</p>
                <p>2. Tekan &amp; tahan link/tombol di email itu → <b>Salin tautan</b></p>
                <p>3. Paste di kolom atas → tekan Verifikasi</p>
                <p className="mt-2 text-cyan-300/80">Bingung copy link di HP? Buka emailnya → <b>salin seluruh isi pesan</b> (select all) → paste di kolom atas — link-nya otomatis kita ambilin kok ✨</p>
                <p className="mt-2 text-cyan-300/80">Belum masuk-masuk? Tunggu 1–2 menit, cek <b>Spam</b> &amp; <b>Promosi</b>, atau tekan <b>Kirim ulang link</b>.</p>
              </div>
            )}
          </motion.div>
        )}

        {step === 3 && result && (
          <motion.div key="s3" initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="glass overflow-hidden rounded-3xl">
            <div className={`p-5 text-center ${result.data?.status === "ACTIVE" ? "bg-gradient-to-br from-cyan-500/20 to-teal-500/20" : "bg-amber-500/10"}`}>
              <motion.div
                initial={{ scale: 0, rotate: -30 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", stiffness: 260, damping: 18 }}
                className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-3xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white shadow-xl shadow-cyan-500/30"
              >
                {result.data?.status === "ACTIVE" ? <PartyPopper className="h-8 w-8" /> : <AlertTriangle className="h-8 w-8 text-amber-300" />}
              </motion.div>
              <p className="text-base font-extrabold">
                {result.data?.status === "ACTIVE" ? "Premium Aktif! 🎉" : "Login Berhasil"}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{result.message}</p>
            </div>

            {result.data && (
              <div className="space-y-2 p-4">
                {[
                  ["Email", result.data.email],
                  ["Status", result.data.membershipStatus === "PREMIUM_ACTIVE" ? "PREMIUM ✅" : "Login saja"],
                  ["Paket", result.data.planName],
                  ["Tipe", result.data.subscriptionType],
                  ["Order ID", result.data.orderId || "-"],
                  ["Berlaku sampai", result.data.validUntil],
                ].map(([k, v]) => (
                  <div key={String(k)} className="flex items-center justify-between gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5 text-xs">
                    <span className="text-muted-foreground">{k}</span>
                    <span className="truncate font-bold">{v}</span>
                  </div>
                ))}
                <div className="mt-3 flex items-start gap-2 rounded-2xl bg-gradient-to-r from-amber-500/10 to-transparent p-3.5 text-[11px] leading-relaxed">
                  <Crown className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" />
                  <p>
                    Buka app <b>Alight Motion</b> di HP lo → login pake email yang sama → premium bakal nempel otomatis di akun itu. Kalau belum kebaca, tunggu 1–2 menit lalu refresh app.
                  </p>
                </div>
                {result.data.premiumError && (
                  <p className="text-[10px] text-amber-400">Detail: {result.data.premiumError}</p>
                )}
              </div>
            )}

            <div className="px-4 pb-4">
              <Button
                onClick={() => { setStep(1); setResult(null); setEmail(""); setMagicLink(""); setTrialMode(false); setTrialStatus(""); }}
                variant="outline"
                className="w-full rounded-xl py-3.5 text-xs font-bold"
              >
                <ExternalLink className="mr-2 h-3.5 w-3.5" /> Aktivasi email lain
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
