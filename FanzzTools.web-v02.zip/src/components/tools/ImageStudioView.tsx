"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import SpiralTool from "@/components/tools/image-studio/SpiralTool";
import BratTool from "@/components/tools/image-studio/BratTool";
import IphoneQuoteTool from "@/components/tools/image-studio/IphoneQuoteTool";
import MemeTool from "@/components/tools/image-studio/MemeTool";
import PhotocardTool from "@/components/tools/image-studio/PhotocardTool";
import NulisTool from "@/components/tools/image-studio/NulisTool";
import StoryCardTool from "@/components/tools/image-studio/StoryCardTool";
import PrankTool from "@/components/tools/image-studio/PrankTool";
import ChatFakeTool from "@/components/tools/image-studio/ChatFakeTool";
import KtpTool from "@/components/tools/image-studio/KtpTool";
import WallpaperTool from "@/components/tools/image-studio/WallpaperTool";
import TiktokQuoteTool from "@/components/tools/image-studio/TiktokQuoteTool";
import NotifTool from "@/components/tools/image-studio/NotifTool";
import HackerTerminalTool from "@/components/tools/image-studio/HackerTerminalTool";
import {
  Palette, Shell, Smartphone, Type, Smile, IdCard, PenLine, LayoutTemplate, ShieldCheck,
  AlertTriangle, MessageSquare, Wallpaper, Music2, Bell, Binary,
} from "lucide-react";

/**
 * Studio Gambar — kumpulan generator gambar seru yang berjalan sepenuhnya di perangkat.
 * V2.11 (#22): 13 generator — Spiral PFP, Brat, iPhone Quote, Meme, Photocard,
 * Nulis, Story Card, Prank (Error PC/Virus/Terminal), Chat Palsu (WA/TikTok/iMessage),
 * KTP Dummy, Wallpaper, TikTok Quote, dan Notifikasi.
 * Cyber-Update #8: +1 generator — Hacker Prank (video terminal fake animatif).
 */

type TabId =
  | "spiral" | "brat" | "iphone" | "meme" | "pc" | "nulis" | "story"
  | "prank" | "chat" | "ktp" | "wallpaper" | "tiktokquote" | "hackerprank" | "notif";

const TABS: Array<{
  id: TabId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  judul: string;
  deskripsi: string;
}> = [
  {
    id: "spiral",
    label: "Spiral PFP",
    icon: Shell,
    judul: "Foto Profil Spiral",
    deskripsi: "Ubah foto menjadi seni garis spiral — hitam-putih, abu-abu, atau warna asli.",
  },
  {
    id: "brat",
    label: "Brat",
    icon: Type,
    judul: "Brat Generator",
    deskripsi: "Teks huruf kecil khas sampul album brat — pilih warna, unduh PNG atau video mengetik.",
  },
  {
    id: "iphone",
    label: "iPhone Quote",
    icon: Smartphone,
    judul: "iPhone Quote (IQC)",
    deskripsi: "Kartu pesan layar kunci iPhone & tiruan obrolan iMessage lengkap dengan status bar.",
  },
  {
    id: "meme",
    label: "Meme",
    icon: Smile,
    judul: "Meme Generator",
    deskripsi: "Teks tebal beroutline di atas dan bawah gambar Anda sendiri — atau meme teks tanpa gambar.",
  },
  {
    id: "pc",
    label: "Meme PC",
    icon: IdCard,
    judul: "Photocard / Meme PC",
    deskripsi: "Kartu foto dengan bingkai klasik hingga holografik, plus mode meme dengan caption.",
  },
  {
    id: "nulis",
    label: "Nulis",
    icon: PenLine,
    judul: "Nulis (Tulisan Tangan)",
    deskripsi: "Teks menjadi tulisan tangan di atas kertas buku tulis bergaris lengkap dengan nama dan kelas.",
  },
  {
    id: "story",
    label: "Story Card",
    icon: LayoutTemplate,
    judul: "Story Card (ISC)",
    deskripsi: "Kartu kutipan vertikal dengan latar gradien — pas untuk status dan cerita.",
  },
  {
    id: "prank",
    label: "Prank",
    icon: AlertTriangle,
    judul: "Prank Generator",
    deskripsi: "Error PC (BSOD), dialog klasik, peringatan virus, dan terminal hacker — teks bisa diubah.",
  },
  {
    id: "chat",
    label: "Chat",
    icon: MessageSquare,
    judul: "Generator Obrolan Palsu",
    deskripsi: "Obrolan WhatsApp / TikTok DM / iMessage — nama, foto, dan isi chat bisa diubah.",
  },
  {
    id: "ktp",
    label: "KTP Dummy",
    icon: IdCard,
    judul: "KTP Dummy Generator",
    deskripsi: "Kartu identitas dummy lengkap dengan watermark DUMMY permanen — khusus keperluan kreator.",
  },
  {
    id: "wallpaper",
    label: "Wallpaper",
    icon: Wallpaper,
    judul: "Wallpaper Generator",
    deskripsi: "Gradien estetik siap pakai untuk wallpaper HP atau desktop.",
  },
  {
    id: "tiktokquote",
    label: "TikTok Quote",
    icon: Music2,
    judul: "TikTok Quote",
    deskripsi: "Kartu kutipan gaya TikTok dengan handle dan bar musik.",
  },
  {
    id: "hackerprank",
    label: "Hacker Prank",
    icon: Binary,
    judul: "Hacker Prank (Video Terminal)",
    deskripsi: "Terminal palsu menjalankan kode bergaya hacker — ketik, scroll, matrix, lalu AKSES DIBERIKAN. Murni animasi, tanpa command nyata.",
  },
  {
    id: "notif",
    label: "Notifikasi",
    icon: Bell,
    judul: "Notifikasi Generator",
    deskripsi: "Banner notifikasi layar kunci gaya WhatsApp / iPhone / Android.",
  },
];

export default function ImageStudioView() {
  const [tab, setTab] = useState<TabId>("spiral");
  const aktif = TABS.find((t) => t.id === tab) ?? TABS[0];

  return (
    <div>
      <ToolHeader
        icon={<Palette className="h-6 w-6" />}
        title="Studio Gambar"
        subtitle="14 generator gambar & video seru — semuanya diproses langsung di perangkat Anda"
        accent="fuchsia"
      />

      {/* tab pilihan generator */}
      <div className="mb-4 -mx-4 overflow-x-auto px-4 pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <div className="flex w-max gap-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold transition ${
                tab === t.id
                  ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                  : "bg-secondary hover:bg-secondary/70"
              }`}
            >
              <t.icon className="h-3.5 w-3.5" />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* judul generator aktif */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
        >
          <div className="mb-4">
            <h2 className="text-base font-extrabold tracking-tight">{aktif.judul}</h2>
            <p className="text-xs text-muted-foreground">{aktif.deskripsi}</p>
          </div>

          {tab === "spiral" && <SpiralTool />}
          {tab === "brat" && <BratTool />}
          {tab === "iphone" && <IphoneQuoteTool />}
          {tab === "meme" && <MemeTool />}
          {tab === "pc" && <PhotocardTool />}
          {tab === "nulis" && <NulisTool />}
          {tab === "story" && <StoryCardTool />}
          {tab === "prank" && <PrankTool />}
          {tab === "chat" && <ChatFakeTool />}
          {tab === "ktp" && <KtpTool />}
          {tab === "wallpaper" && <WallpaperTool />}
          {tab === "tiktokquote" && <TiktokQuoteTool />}
          {tab === "hackerprank" && <HackerTerminalTool />}
          {tab === "notif" && <NotifTool />}
        </motion.div>
      </AnimatePresence>

      <p className="mt-6 flex items-center justify-center gap-1.5 text-center text-[10px] text-muted-foreground">
        <ShieldCheck className="h-3 w-3 text-emerald-400" />
        Semua generator Studio Gambar bekerja luring di peramban Anda — tidak ada foto yang diunggah ke server.
      </p>
    </div>
  );
}
