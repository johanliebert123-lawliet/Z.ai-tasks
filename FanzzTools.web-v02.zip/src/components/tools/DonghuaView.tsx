"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import WatchChat from "@/components/chat/WatchChat";
import { DONGHUA_MAINTENANCE } from "@/lib/constants";
import {
  Swords, Search, Loader2, ArrowLeft, Play, ChevronRight, MessageCircle, Lock, RefreshCw, Wrench,
} from "lucide-react";

interface DhCard {
  judul: string;
  url: string;
}

interface DhSections {
  hot: DhCard[];
  update: DhCard[];
  ongoing: DhCard[];
  upcoming: DhCard[];
  completed: DhCard[];
}

interface DhDetail {
  judul: string;
  sinopsis?: string | null;
  genres: string[];
  totalEpisodes: number;
  episodes: DhCard[];
}

interface DhWatch {
  judul: string;
  locked: boolean;
  video: { platform: string; videoId?: string; embedUrl: string; altEmbeds?: string[] } | null;
  /** V2-new: pemutar cadangan dari route (geo player asli → www embed) */
  altEmbeds?: string[];
  episodeLinks: DhCard[];
}

type Tab = "hot" | "update" | "ongoing" | "upcoming" | "completed" | "search";

const PLAYER_SANDBOX = "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

/** zuperupdt #16 LAYAR 3 (localStorage): flag pemeliharaan bertahan di
 *  perangkat pengguna — dipasang sekali, dibaca tiap mount. Kunci ganda
 *  (konstanta bundle + flag lokal) memastikan layar pemeliharaan tampil
 *  bahkan untuk bundle lama yang masih ter-cache. */
const LS_MAINT = "fanzz_donghua_maintenance";

function isMaintenanceLocal(): boolean {
  if (typeof window === "undefined") return DONGHUA_MAINTENANCE;
  if (DONGHUA_MAINTENANCE) {
    try { localStorage.setItem(LS_MAINT, "1"); } catch { /* ignore */ }
    return true;
  }
  try { return localStorage.getItem(LS_MAINT) === "1"; } catch { return false; }
}

/** Layar pemeliharaan (zuperupdt #16) — sistem dipertahankan, fitur dikunci. */
function MaintenanceScreen({ onRetry }: { onRetry: () => void }) {
  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl px-6 py-14 text-center">
      <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-500/20 to-orange-600/20">
        <Wrench className="h-9 w-9 text-amber-300" />
      </div>
      <h2 className="mt-5 text-lg font-extrabold">Sedang Dalam Pemeliharaan</h2>
      <p className="mx-auto mt-2 max-w-sm text-xs leading-relaxed text-muted-foreground">
        Fitur <b>Nonton Donghua</b> sedang kami perbaiki dan sementara dinonaktifkan.
        Katalog, pemutar, dan semua sistemnya tetap utuh dan akan kembali setelah
        pemeliharaan selesai. Silakan jelajahi tools lain di <b>The All-Tools</b> ya.
      </p>
      <button onClick={onRetry} className="mx-auto mt-6 flex items-center gap-2 rounded-xl bg-secondary px-4 py-2.5 text-[11px] font-extrabold text-muted-foreground">
        <RefreshCw className="h-3.5 w-3.5" /> Coba lagi
      </button>
    </motion.div>
  );
}

export default function DonghuaView() {
  /** zuperupdt #16: kunci pemeliharaan ganda — konstanta bundle + localStorage.
   *  Selama terkunci, SELURUH view menampilkan layar pemeliharaan. */
  const [maintenance, setMaintenance] = useState(false);
  useEffect(() => {
    setMaintenance(isMaintenanceLocal());
  }, []);

  const [tab, setTab] = useState<Tab>("hot");
  const [sections, setSections] = useState<DhSections | null>(null);
  const [query, setQuery] = useState("");
  const [searchRes, setSearchRes] = useState<DhCard[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<DhDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [watch, setWatch] = useState<DhWatch | null>(null);
  const [watchLoading, setWatchLoading] = useState(false);
  /** V2-new: indeks pemutar cadangan bila pemutar utama gagal dimuat */
  const [altIdx, setAltIdx] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();

  const loadHome = useCallback(async () => {
    setSections(null);
    try {
      const r = await fetch("/api/donghua?home=1");
      const d = await r.json();
      setSections(d?.ok ? d.sections : null);
    } catch {
      setSections({ hot: [], update: [], ongoing: [], upcoming: [], completed: [] });
    }
  }, []);

  useEffect(() => {
    loadHome();
  }, [loadHome]);

  const doSearch = (q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      setSearchRes(null);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/donghua?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        setSearchRes(d?.ok ? (d.results || []) : []);
      } catch {
        setSearchRes([]);
      } finally {
        setSearching(false);
      }
    }, 500);
  };

  const openDetail = async (url: string) => {
    setDetailLoading(true);
    setDetail(null);
    setWatch(null);
    try {
      const r = await fetch(`/api/donghua?url=${encodeURIComponent(url)}`);
      const d = await r.json();
      if (d?.ok) {
        setDetail({ judul: d.judul, sinopsis: d.sinopsis, genres: d.genres, totalEpisodes: d.totalEpisodes, episodes: d.episodes });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal buka donghua", description: d?.error || "Coba lagi" });
      }
    } catch {
      toast({ title: "Gagal buka donghua", description: "Koneksi bermasalah" });
    } finally {
      setDetailLoading(false);
    }
  };

  const openWatch = async (url: string) => {
    setWatchLoading(true);
    setWatch(null);
    setAltIdx(0);
    try {
      const r = await fetch(`/api/donghua?watch=${encodeURIComponent(url)}`);
      const d = await r.json();
      if (d?.ok) {
        setWatch({ judul: d.judul, locked: d.locked, video: d.video, altEmbeds: (d.video?.altEmbeds || []) as string[], episodeLinks: d.episodeLinks });
        // V0.01 (#7): catat riwayat donghua
        pushHistory("donghua", {
          id: url,
          title: d.judul || "Donghua",
          subtitle: "Episode ditonton",
        });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal buka episode", description: d?.error || "Coba lagi" });
      }
    } catch {
      toast({ title: "Gagal buka episode", description: "Koneksi bermasalah" });
    } finally {
      setWatchLoading(false);
    }
  };

  /* ---------- zuperupdt #16: gerbang pemeliharaan (sebelum semua layar) ---------- */
  if (maintenance) {
    return (
      <div>
        <ToolHeader icon={<Swords className="h-5.5 w-5.5" />} title="Nonton Donghua" subtitle="Anime China • sub indo" accent="indigo" />
        <MaintenanceScreen onRetry={() => setMaintenance(isMaintenanceLocal())} />
      </div>
    );
  }

  /* ---------- WATCH ---------- */
  if (watchLoading) {
    return (
      <div>
        <ToolHeader icon={<Swords className="h-5.5 w-5.5" />} title="Nonton Donghua" subtitle="Anime China • sub indo" accent="indigo" />
        <div className="flex h-[50vh] flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
          <p className="text-xs text-muted-foreground">Nyiapin video episode...</p>
        </div>
      </div>
    );
  }

  if (watch) {
    return (
      <div>
        <button onClick={() => setWatch(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Kembali ke daftar episode
        </button>

        <h2 className="mb-3 clamp-2 text-base font-extrabold">{watch.judul}</h2>

        <div className="relative overflow-hidden rounded-2xl bg-black shadow-2xl">
          <div className="aspect-video w-full">
            {watch.video ? (
              <iframe
                key={`dh-${altIdx}`}
                src={altIdx > 0 && watch.altEmbeds && watch.altEmbeds[altIdx - 1] ? watch.altEmbeds[altIdx - 1] : watch.video.embedUrl}
                title="Fanzz Donghua Player"
                className="h-full w-full border-0"
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture; clipboard-write"
                allowFullScreen
                referrerPolicy="no-referrer"
                sandbox={PLAYER_SANDBOX}
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center gap-2 p-6 text-center">
                <Lock className="h-8 w-8 text-amber-400" />
                <p className="text-sm font-bold text-white">Video tidak tersedia</p>
                <p className="text-[11px] text-white/60">Episode ini mungkin dikunci sumbernya — coba episode lain.</p>
              </div>
            )}
          </div>
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`absolute right-2 top-2 z-10 flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-[10px] font-bold backdrop-blur-md transition-all active:scale-90 ${
              chatOpen ? "bg-blue-600 text-white" : "bg-black/55 text-white/85 hover:bg-black/75"
            }`}
          >
            <MessageCircle className="h-3.5 w-3.5" />
            {chatOpen ? "Tutup" : "Chat"}
          </button>
          {/* V2-new: ganti pemutar cadangan (geo player asli ↔ embed www) —
              jawaban keluhan "nonton donghua gagal terus" */}
          {watch.video && watch.altEmbeds && watch.altEmbeds.length > 0 && (
            <button
              onClick={() => setAltIdx((i) => (i + 1) % (watch.altEmbeds!.length + 1))}
              className="absolute bottom-2 right-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
              title="Video tidak jalan? Ganti pemutar cadangan"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              {altIdx === 0 ? "Ganti Pemutar" : `Pemutar ${altIdx + 1}`}
            </button>
          )}
          {watch.locked && (
            <span className="absolute left-2 top-2 z-10 flex items-center gap-1 rounded-xl bg-amber-500/85 px-2 py-1.5 text-[10px] font-bold text-white">
              <Lock className="h-3 w-3" /> Sumber utama episode ini — apabila tidak berjalan, silakan coba mirror lain
            </span>
          )}
        </div>

        <AnimatePresence>
          {chatOpen && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="mt-3 rounded-2xl glass p-3">
                <WatchChat />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* episode lain */}
        {watch.episodeLinks.length > 0 && (
          <section className="mt-4">
            <h3 className="mb-2.5 text-sm font-bold">Episode lain</h3>
            <div className="space-y-1.5">
              {watch.episodeLinks.slice(0, 30).map((ep, i) => (
                <button
                  key={ep.url + i}
                  onClick={() => openWatch(ep.url)}
                  className="flex w-full items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-3 text-left transition-colors hover:bg-secondary"
                >
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-blue-600 text-[11px] font-extrabold text-white">
                    <Play className="h-3.5 w-3.5" />
                  </div>
                  <span className="min-w-0 flex-1 truncate text-xs font-bold">{ep.judul}</span>
                  <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                </button>
              ))}
            </div>
          </section>
        )}
      </div>
    );
  }

  /* ---------- DETAIL ---------- */
  if (detailLoading) {
    return (
      <div>
        <ToolHeader icon={<Swords className="h-5.5 w-5.5" />} title="Nonton Donghua" subtitle="Anime China • sub indo" accent="indigo" />
        <div className="space-y-3">
          <div className="h-40 rounded-3xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (detail) {
    return (
      <div>
        <button onClick={() => setDetail(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Kembali
        </button>

        <div className="overflow-hidden rounded-3xl glass p-5">
          <h2 className="clamp-2 text-base font-extrabold leading-snug">{detail.judul}</h2>
          {detail.genres.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {detail.genres.slice(0, 8).map((g) => (
                <span key={g} className="rounded-full bg-blue-600/15 px-2 py-0.5 text-[10px] font-bold text-blue-300">{g}</span>
              ))}
            </div>
          )}
          <p className="mt-2 text-xs font-bold text-muted-foreground">{detail.totalEpisodes} episode tersedia</p>
        </div>

        {detail.sinopsis && (
          <section className="mt-4 rounded-2xl glass p-4">
            <h3 className="mb-1.5 text-sm font-bold">Sinopsis</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">{detail.sinopsis}</p>
          </section>
        )}

        <section className="mt-4">
          <h3 className="mb-2.5 text-sm font-bold">Daftar Episode</h3>
          <div className="space-y-1.5">
            {detail.episodes.map((ep, i) => (
              <button
                key={ep.url + i}
                onClick={() => openWatch(ep.url)}
                className="flex w-full items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-3 text-left transition-colors hover:bg-secondary"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-600 to-blue-600 text-xs font-extrabold text-white">
                  {i + 1}
                </div>
                <span className="min-w-0 flex-1 truncate text-xs font-bold">{ep.judul}</span>
                <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              </button>
            ))}
            {detail.episodes.length === 0 && (
              <EmptyState icon={<Swords className="h-6 w-6" />} title="Belum ada episode" desc="Donghua ini mungkin belum rilis episodenya." />
            )}
          </div>
        </section>
      </div>
    );
  }

  /* ---------- HOME / SEARCH ---------- */
  const cardRow = (label: string, list: DhCard[]) => {
    if (!list?.length) return null;
    return (
      <section className="mb-5">
        <h3 className="mb-2.5 text-sm font-bold">{label}</h3>
        <div className="space-y-1.5">
          {list.slice(0, 12).map((c, i) => (
            <button
              key={c.url + i}
              onClick={() => openWatch(c.url)}
              className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
            >
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-600 text-white shadow-lg shadow-blue-600/20">
                <Play className="h-4 w-4" />
              </div>
              <span className="min-w-0 flex-1 truncate text-sm font-bold">{c.judul}</span>
              <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
            </button>
          ))}
        </div>
      </section>
    );
  };

  return (
    <div>
      <ToolHeader icon={<Swords className="h-5.5 w-5.5" />} title="Nonton Donghua" subtitle="Anime China • hot • ongoing • akan tayang" accent="indigo" />

      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => { setQuery(e.target.value); doSearch(e.target.value); }}
          placeholder="Cari judul donghua... (misal: against the sky)"
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-3.5 pl-10 pr-10 text-sm outline-none focus:border-blue-500/50"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-blue-500" />}
      </div>

      <AnimatePresence mode="wait">
        {tab === "search" || searchRes !== null ? (
          <motion.div key="search" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            {searchRes === null ? (
              <p className="py-6 text-center text-xs text-muted-foreground">Ketik judul donghua buat mulai nyari…</p>
            ) : searchRes.length === 0 ? (
              <EmptyState icon={<Swords className="h-6 w-6" />} title="Gak ketemu" desc="Coba kata kunci lain." />
            ) : (
              <div className="space-y-1.5">
                {searchRes.map((c, i) => (
                  <button
                    key={c.url + i}
                    onClick={() => openWatch(c.url)}
                    className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
                  >
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-600 text-white">
                      <Play className="h-4 w-4" />
                    </div>
                    <span className="min-w-0 flex-1 truncate text-sm font-bold">{c.judul}</span>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        ) : sections === null ? (
          <motion.div key="loading" className="space-y-2">
            {[0, 1, 2, 3, 4, 5].map((i) => <div key={i} className="h-14 rounded-2xl shimmer" />)}
          </motion.div>
        ) : (
          <motion.div key="sections" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            {cardRow("🔥 Hot / Populer", sections.hot)}
            {cardRow("🆕 Baru di-update", sections.update)}
            {cardRow("▶ Sedang Tayang (Ongoing)", sections.ongoing)}
            {cardRow("⏳ Akan Tayang", sections.upcoming)}
            {cardRow("✅ Tamat (Completed)", sections.completed)}
            {Object.values(sections).every((s) => !s?.length) && (
              <EmptyState icon={<Swords className="h-6 w-6" />} title="Sumber lagi bermasalah" desc="Tarik lagi nanti ya." />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
