"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Book, Search, Loader2, ArrowLeft, Star, ChevronRight, List, Image as ImageIcon, BookOpen,
} from "lucide-react";

/**
 * Baca Komik (V2-new, permintaan #20) — manhwa + manhua + comic.
 * Sumber: ComicVerse (Bacakomik) — item punya field `type`
 * (Manhwa / Manhua / Manga) yang dipakai untuk tiga kategori + tab Semua.
 */

interface ComicItem {
  title: string;
  slug: string;
  cover: string;
  rating?: string;
  type?: string;
  chapter?: string;
  genre?: string;
}

interface Chapter {
  slug: string;
  title: string;
  date?: string;
}

interface ComicDetail {
  title: string;
  otherTitle?: string;
  cover: string;
  rating?: string;
  type?: string;
  status?: string;
  author?: string;
  release?: string;
  reader?: string;
  synopsis?: string;
  genres?: Array<{ title: string }>;
  chapters?: Chapter[];
}

type Tab = "semua" | "manhwa" | "manhua" | "comic";

/** Normalisasi jenis komik → kategori tampilan. */
function kategori(type?: string): Tab | null {
  const t = (type || "").toLowerCase();
  if (t.includes("manhwa")) return "manhwa";
  if (t.includes("manhua")) return "manhua";
  if (t.includes("manga") || t.includes("comic")) return "comic";
  return null;
}

export default function ComicView() {
  const [tab, setTab] = useState<Tab>("semua");
  const [items, setItems] = useState<ComicItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [searchRes, setSearchRes] = useState<ComicItem[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<ComicDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [chaptersOpen, setChaptersOpen] = useState(false);
  /** reader: chapter yang sedang dibaca */
  const [reader, setReader] = useState<{ title: string; images: string[]; slug: string; chapters: Chapter[] } | null>(null);
  const [readerLoading, setReaderLoading] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();

  const loadList = useCallback(async () => {
    setItems(null);
    try {
      const r = await fetch("/api/comic?list=latest");
      const d = await r.json();
      setItems(d?.ok ? d.items : []);
    } catch {
      setItems([]);
    }
  }, []);

  useEffect(() => {
    loadList();
  }, [loadList]);

  const doSearch = (q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      setSearchRes(null);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/comic?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        setSearchRes(d?.ok ? d.items : []);
      } catch {
        setSearchRes([]);
      } finally {
        setSearching(false);
      }
    }, 450);
  };

  const openDetail = async (slug: string) => {
    setDetailLoading(true);
    setDetail(null);
    setReader(null);
    try {
      const r = await fetch(`/api/comic?detail=${encodeURIComponent(slug)}`);
      const d = await r.json();
      if (d?.ok) {
        setDetail(d.detail);
        pushHistory("komik", {
          id: slug,
          title: d.detail.title || slug,
          subtitle: "Komik (ComicVerse)",
          poster: d.detail.cover || null,
          extra: { source: "comicverse" },
        });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal membuka komik", description: d?.error || "Silakan coba lagi." });
      }
    } catch {
      toast({ title: "Gagal membuka komik", description: "Koneksi bermasalah." });
    } finally {
      setDetailLoading(false);
    }
  };

  const openChapter = async (ch: Chapter) => {
    if (!detail) return;
    setReaderLoading(true);
    setReader(null);
    try {
      const r = await fetch(`/api/comic?chapter=${encodeURIComponent(ch.slug)}`);
      const d = await r.json();
      if (d?.ok) {
        setReader({ title: d.title || ch.title, images: d.images, slug: ch.slug, chapters: detail.chapters || [] });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal membuka chapter", description: d?.error || "Coba chapter lain." });
      }
    } catch {
      toast({ title: "Gagal membuka chapter", description: "Koneksi bermasalah." });
    } finally {
      setReaderLoading(false);
    }
  };

  /** Chapter berikutnya/sebelumnya (slug berakhiran angka). */
  const jumpChapter = (dir: 1 | -1) => {
    if (!reader || !reader.chapters.length) return;
    const idx = reader.chapters.findIndex((c) => c.slug === reader.slug);
    if (idx === -1) return;
    const next = reader.chapters[idx + dir];
    if (next) openChapter(next);
    else toast({ title: dir === 1 ? "Sudah chapter terbaru" : "Sudah chapter pertama" });
  };

  /* ---------- READER ---------- */
  if (readerLoading) {
    return (
      <div>
        <ToolHeader icon={<Book className="h-5.5 w-5.5" />} title="Baca Komik" subtitle="Manhwa • Manhua • Comic" accent="orange" />
        <div className="flex h-[50vh] flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-orange-400" />
          <p className="text-xs text-muted-foreground">Memuat halaman chapter...</p>
        </div>
      </div>
    );
  }

  if (reader) {
    return (
      <div>
        <button onClick={() => setReader(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Kembali ke detail
        </button>

        <div className="mb-3 flex items-center justify-between gap-2">
          <h2 className="clamp-1 min-w-0 flex-1 text-base font-extrabold">{reader.title}</h2>
          <button onClick={() => jumpChapter(-1)} className="shrink-0 rounded-xl bg-secondary/70 px-3 py-2 text-[11px] font-bold text-muted-foreground hover:text-foreground">
            ‹ Sebelumnya
          </button>
          <button onClick={() => jumpChapter(1)} className="shrink-0 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 px-3 py-2 text-[11px] font-bold text-white">
            Berikutnya ›
          </button>
        </div>

        <div className="space-y-1.5 overflow-hidden rounded-2xl bg-black/20">
          {reader.images.map((img, i) => (
            <img
              key={`${reader.slug}-${i}`}
              src={img}
              alt={`Halaman ${i + 1}`}
              loading="lazy"
              referrerPolicy="no-referrer"
              className="w-full select-none"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
          ))}
        </div>

        <button onClick={() => jumpChapter(1)} className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-orange-500 to-amber-500 py-3 text-xs font-bold text-white">
          <ChevronRight className="h-4 w-4" /> Lanjut ke chapter berikutnya
        </button>
      </div>
    );
  }

  /* ---------- DETAIL ---------- */
  if (detailLoading) {
    return (
      <div>
        <ToolHeader icon={<Book className="h-5.5 w-5.5" />} title="Baca Komik" subtitle="Manhwa • Manhua • Comic" accent="orange" />
        <div className="space-y-3">
          <div className="h-48 rounded-3xl shimmer" />
          <div className="h-6 w-2/3 rounded-xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (detail) {
    return (
      <div>
        <button onClick={() => setDetail(null)} className="mb-3 flex items-center gap-1 rounded-xl bg-secondary/70 px-3 py-2 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Kembali ke daftar
        </button>

        <div className="overflow-hidden rounded-3xl glass p-5">
          <div className="flex gap-4">
            {detail.cover && (
              <img src={detail.cover} alt="" className="h-40 w-28 shrink-0 rounded-2xl object-cover shadow-xl" referrerPolicy="no-referrer" />
            )}
            <div className="min-w-0 flex-1">
              <h2 className="clamp-3 text-sm font-extrabold leading-snug">{detail.title}</h2>
              {detail.otherTitle && <p className="mt-0.5 text-[10px] text-muted-foreground">{detail.otherTitle}</p>}
              <div className="mt-2 flex flex-wrap gap-1.5">
                {detail.rating && (
                  <span className="flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-300">
                    <Star className="h-3 w-3 fill-current" /> {detail.rating}
                  </span>
                )}
                {detail.type && <span className="rounded-full bg-orange-500/15 px-2 py-0.5 text-[10px] font-bold text-orange-300">{detail.type}</span>}
                {detail.status && <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">{detail.status}</span>}
              </div>
              <div className="mt-2 space-y-0.5 text-[10.5px] text-muted-foreground">
                {detail.author && <p>Pengarang: {detail.author}</p>}
                {detail.release && <p>Rilis: {detail.release}</p>}
                {detail.reader && <p>Pembaca: {detail.reader}</p>}
              </div>
            </div>
          </div>
          {detail.synopsis && (
            <p className="mt-3 line-clamp-4 text-xs leading-relaxed text-muted-foreground">{detail.synopsis}</p>
          )}
        </div>

        {/* daftar chapter */}
        <section className="mt-4">
          <div className="mb-2.5 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-sm font-bold">
              <BookOpen className="h-4 w-4 text-orange-400" /> Daftar Chapter
              <span className="rounded-full bg-secondary/70 px-1.5 py-px text-[9px] font-bold text-muted-foreground">{(detail.chapters || []).length}</span>
            </h3>
            <button
              onClick={() => setChaptersOpen((o) => !o)}
              className="flex items-center gap-1 rounded-xl bg-secondary/70 px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground hover:text-foreground"
            >
              <List className="h-3.5 w-3.5" /> {chaptersOpen ? "Sembunyikan" : "Tampilkan semua"}
            </button>
          </div>
          <div className="space-y-1.5">
            {(chaptersOpen ? detail.chapters || [] : (detail.chapters || []).slice(0, 8)).map((ch, i) => (
              <button
                key={ch.slug + i}
                onClick={() => openChapter(ch)}
                className="flex w-full items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-3 text-left transition-colors hover:bg-secondary"
              >
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-amber-500 text-white">
                  <ImageIcon className="h-3.5 w-3.5" />
                </div>
                <span className="min-w-0 flex-1 truncate text-xs font-bold">{ch.title}</span>
                {ch.date && <span className="shrink-0 text-[10px] text-muted-foreground">{ch.date}</span>}
                <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        </section>
      </div>
    );
  }

  /* ---------- DAFTAR + SEARCH ---------- */
  const shown = searchRes ?? items ?? [];
  const filtered = tab === "semua" ? shown : shown.filter((c) => kategori(c.type) === tab);

  return (
    <div>
      <ToolHeader icon={<Book className="h-5.5 w-5.5" />} title="Baca Komik" subtitle="Manhwa • Manhua • Comic — ComicVerse" accent="orange" />

      {/* pencarian */}
      <div className="relative mb-3">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            doSearch(e.target.value);
          }}
          placeholder="Cari judul komik / manhwa / manhua..."
          className="w-full rounded-xl border border-border/60 bg-secondary/50 py-4 pl-10 pr-3 text-sm outline-none focus:border-orange-400/50"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-orange-400" />}
      </div>

      {/* tab kategori */}
      <div className="mb-4 flex gap-2 overflow-x-auto no-scrollbar">
        {([
          ["semua", "Semua", Book],
          ["manhwa", "Manhwa", BookOpen],
          ["manhua", "Manhua", BookOpen],
          ["comic", "Comic", List],
        ] as const).map(([id, label, Icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              tab === id ? "text-white" : "bg-secondary/60 text-muted-foreground"
            }`}
          >
            {tab === id && <motion.span layoutId="comic-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-500 to-amber-500" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <Icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{label}</span>
          </button>
        ))}
      </div>

      {/* daftar komik */}
      {items === null && !searchRes ? (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="space-y-2">
              <div className="aspect-[2/3] rounded-2xl shimmer" />
              <div className="h-3.5 w-4/5 rounded shimmer" />
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon={<Book className="h-6 w-6" />}
          title={tab === "semua" ? "Belum ada komik" : `Belum ada ${tab === "comic" ? "comic/manga" : tab}`}
          desc={searchRes ? "Coba judul lain — pencarian mencakup semua jenis." : "Tarik ke bawah untuk memuat ulang, atau coba lagi beberapa saat."}
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          <AnimatePresence>
            {filtered.map((c, i) => (
              <motion.button
                key={c.slug}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.97 }}
                transition={{ delay: Math.min(i * 0.03, 0.3) }}
                onClick={() => openDetail(c.slug)}
                className="group text-left"
              >
                <div className="relative aspect-[2/3] overflow-hidden rounded-2xl bg-secondary shadow-lg">
                  {c.cover ? (
                    <img src={c.cover} alt={c.title} loading="lazy" referrerPolicy="no-referrer" className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-orange-500/20 to-amber-500/10 text-orange-300">
                      <Book className="h-8 w-8" />
                    </div>
                  )}
                  {c.type && (
                    <span className="absolute left-1.5 top-1.5 rounded-full bg-black/65 px-1.5 py-0.5 text-[8.5px] font-extrabold text-white/90 backdrop-blur-sm">{c.type}</span>
                  )}
                  {c.rating && (
                    <span className="absolute bottom-1.5 left-1.5 flex items-center gap-0.5 rounded-full bg-black/65 px-1.5 py-0.5 text-[8.5px] font-bold text-amber-300 backdrop-blur-sm">
                      <Star className="h-2.5 w-2.5 fill-current" /> {c.rating}
                    </span>
                  )}
                  {c.chapter && (
                    <span className="absolute bottom-1.5 right-1.5 rounded-full bg-orange-500/85 px-1.5 py-0.5 text-[8px] font-extrabold text-white">{c.chapter}</span>
                  )}
                </div>
                <p className="mt-1.5 clamp-2 text-[11px] font-bold leading-snug">{c.title}</p>
              </motion.button>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
