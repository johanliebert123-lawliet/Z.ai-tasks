"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  ImageIcon, Sparkles, Loader2, Download, RefreshCw, Wand2, Lightbulb,
} from "lucide-react";

const IDEAS = [
  "kucing astronot melayang di luar angkasa, sinar neon ungu, sinematik",
  "kota futuristik Jakarta tahun 2100, gedung hologram, senja emas",
  "naga es raksasa tidur di gunung bersalju, kabut biru, epik",
  "anime girl with silver hair, cyberpunk city background, rain, neon lights",
  "mekanik robot kopi sederhana, hangat, gaya studio ghibli",
  "samurai berdiri di ladang bunga sakura, angin bawa kelopak, dramatis",
];

interface GenResult {
  imageUrl: string;
  shareUrl: string | null;
  prompt: string;
}

export default function AiImageView() {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenResult | null>(null);
  const [error, setError] = useState("");
  const { toast } = useToast();

  const generate = async (p?: string) => {
    const text = (p ?? prompt).trim();
    if (!text || loading) return;
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch("/api/ai/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: text }),
      });
      const d = await res.json();
      if (!res.ok || !d?.ok) throw new Error(d?.error || "Generator gagal");
      setResult({ imageUrl: d.imageUrl, shareUrl: d.shareUrl, prompt: text });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Generator gagal");
    } finally {
      setLoading(false);
    }
  };

  const downloadImage = async () => {
    if (!result) return;
    try {
      const res = await fetch(result.imageUrl);
      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objUrl;
      a.download = `fanzz-ai-${Date.now()}.jpg`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(objUrl), 5000);
      toast({ title: "Gambar tersimpan ✅", description: "Masuk folder Download / galeri kamu" });
    } catch {
      toast({ title: "Gagal simpan", description: "Coba lagi ya — atau tekan-lama gambarnya di browser." });
    }
  };

  return (
    <div>
      <ToolHeader icon={<ImageIcon className="h-5.5 w-5.5" />} title="AI Image Gen" subtitle="Bikin gambar dari teks • deepAi" accent="violet" />

      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-5">
        <div className="flex items-start gap-2.5">
          <Wand2 className="mt-1 h-4 w-4 shrink-0 text-cyan-400" />
          <textarea
            value={prompt}
            onChange={(e) => { setPrompt(e.target.value); setError(""); }}
            placeholder="Deskripsikan gambar yang mau dibikin... (makin detail, makin bagus)"
            rows={3}
            className="w-full resize-none rounded-xl border border-border/60 bg-secondary/50 px-3.5 py-3 text-sm outline-none placeholder:text-muted-foreground focus:border-cyan-400/50"
          />
        </div>
        <Button
          onClick={() => generate()}
          disabled={loading || prompt.trim().length < 3}
          className="mt-3 w-full rounded-xl bg-gradient-to-r from-cyan-500 to-red-700 py-5 text-sm font-bold shadow-lg shadow-cyan-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
        >
          {loading ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Sparkles className="mr-2 h-4.5 w-4.5" />}
          {loading ? "Lagi ngetung pixel... (±30 detik)" : "Generate Gambar"}
        </Button>

        {/* ide prompt */}
        <div className="mt-3">
          <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-bold text-muted-foreground">
            <Lightbulb className="h-3 w-3 text-amber-400" /> BUTUH IDE? COBA INI:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {IDEAS.map((idea) => (
              <button
                key={idea}
                onClick={() => { setPrompt(idea); generate(idea); }}
                disabled={loading}
                className="rounded-full bg-secondary/60 px-2.5 py-1 text-[10px] font-semibold text-muted-foreground transition-colors hover:bg-cyan-500/20 hover:text-cyan-300 disabled:opacity-50"
              >
                {idea.slice(0, 38)}…
              </button>
            ))}
          </div>
        </div>
      </motion.div>

      {error && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 rounded-xl bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          ⚠️ {error}
        </motion.p>
      )}

      <AnimatePresence>
        {loading && (
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4 rounded-3xl glass p-6">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="h-20 w-20 animate-spin rounded-full bg-[conic-gradient(from_0deg,transparent_0deg,transparent_240deg,#ef4444_360deg)]" />
                <div className="absolute inset-1.5 rounded-full bg-[var(--surface-glass)]" />
                <Sparkles className="absolute inset-0 m-auto h-6 w-6 text-cyan-400" />
              </div>
              <p className="text-xs font-bold text-muted-foreground">AI lagi menggambar untukmu...</p>
              <div className="w-full max-w-xs space-y-1.5">
                <div className="h-2 overflow-hidden rounded-full bg-secondary">
                  <div className="h-full w-1/3 animate-[shimmer_1.4s_linear_infinite] rounded-full bg-gradient-to-r from-cyan-500 to-blue-700" />
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 18, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0 }}
            className="mt-4 overflow-hidden rounded-3xl glass"
          >
            <div className="relative">
              <img src={result.imageUrl} alt={result.prompt} className="w-full" referrerPolicy="no-referrer" />
              <div className="absolute right-2 top-2 flex gap-1.5">
                <button
                  onClick={() => generate(result.prompt)}
                  className="rounded-xl bg-black/60 p-2.5 text-white/85 backdrop-blur-md transition-colors hover:text-white"
                  title="Generate ulang prompt ini"
                >
                  <RefreshCw className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="p-4">
              <p className="text-[11px] leading-relaxed text-muted-foreground">"{result.prompt}"</p>
              <div className="mt-3 flex gap-2">
                <button
                  onClick={downloadImage}
                  className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-red-700 py-3 text-xs font-bold text-white shadow-lg shadow-cyan-500/20 transition-transform active:scale-95"
                >
                  <Download className="h-4 w-4" /> Simpan Gambar
                </button>
                <a
                  href={result.imageUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center rounded-xl bg-secondary/70 px-4 py-3 text-xs font-bold text-muted-foreground transition-colors hover:text-foreground"
                >
                  Buka full size
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="mt-4 rounded-2xl glass p-4 text-[11px] leading-relaxed text-muted-foreground">
        <p className="mb-1.5 font-bold text-foreground">Tentang AI Image Gen:</p>
        <p>• Tulis prompt sedetail mungkin — gaya, cahaya, suasana, warna</p>
        <p>• Bahasa Indonesia atau Inggris dua-duanya bisa</p>
        <p>• Rate limit: maksimal 8 gambar per menit agar server tidak terbebani</p>
        <p>• Hasil bisa langsung disimpan ke galeri / folder Download</p>
      </div>
    </div>
  );
}
