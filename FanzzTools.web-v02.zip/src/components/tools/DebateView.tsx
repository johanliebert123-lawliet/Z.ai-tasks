"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Swords, Brain, Loader2, Send, Trophy, Timer, Download, ChevronRight,
  CheckCircle2, XCircle, Scale, Sparkles, RotateCcw,
} from "lucide-react";

/**
 * Debat Filosofis AI (V2 Modern-UpdSec) — untuk Atheis, Agnostik,
 * dan siapa pun yang suka berdebat.
 *
 * Alur: (1) TEST PSIKOLOGI 5 pertanyaan wajib → hasil profil psikologi
 * ditampilkan; (2) pilih level kesulitan (8 jenjang); (3) pilih topik;
 * (4) debat real-time vs AI yang gayanya menyesuaikan profil + level;
 * (5) hasil lengkap: pemenang, skor, durasi jam/menit/detik, pihak
 * unggul/melemah, bisa diunduh PNG / JPG / PDF dengan border.
 */

/* =================== data test psikologi =================== */

interface SoalPsiko {
  q: string;
  opsi: Array<{ teks: string; skor: number }>;
}

const SOAL_PSIKO: SoalPsiko[] = [
  {
    q: "Ketika pendapatmu dibantah keras, reaksi PERTAMAmu biasanya?",
    opsi: [
      { teks: "Diam, kupikirkan dulu apakah bantahannya valid", skor: 4 },
      { teks: "Langsung balas dengan argumen tandingan", skor: 3 },
      { teks: "Terasa kesal, tapi kubuat argumen sambil emosi", skor: 2 },
      { teks: "Kubalas dengan candaan atau mengalihkan topik", skor: 1 },
    ],
  },
  {
    q: "Gaya argumenmu paling dekat ke mana?",
    opsi: [
      { teks: "Logika & data — angka, bukti, riset", skor: 4 },
      { teks: "Pengalaman pribadi & contoh nyata", skor: 3 },
      { teks: "Nilai, moral, dan perasaan", skor: 2 },
      { teks: "Intuisi — 'rasanya sih gitu'", skor: 1 },
    ],
  },
  {
    q: "Seberapa sering kamu berubah pendapat SETELAH debat selesai?",
    opsi: [
      { teks: "Sering — kalau argumennya memang kuat aku mengaku", skor: 4 },
      { teks: "Kadang, tergantung topiknya", skor: 3 },
      { teks: "Jarang — aku biasanya punya pegangan", skor: 2 },
      { teks: "Hampir tidak pernah", skor: 1 },
    ],
  },
  {
    q: "Bidang mana yang paling kamu KUASAI untuk berdebat?",
    opsi: [
      { teks: "Sains, teknologi, matematika", skor: 4 },
      { teks: "Filsafat, agama, makna hidup", skor: 3 },
      { teks: "Sosial, politik, ekonomi", skor: 2 },
      { teks: "Kehidupan sehari-hari & pengalaman", skor: 1 },
    ],
  },
  {
    q: "Lawan debatmu mulai naik nada dan menyerang pribadi. Kamu…",
    opsi: [
      { teks: "Tetap tenang, fokus ke isi argumennya", skor: 4 },
      { teks: "Ikut emosi sedikit tapi tetap berargumen", skor: 3 },
      { teks: "Serang balik perkataannya", skor: 2 },
      { teks: "Diam / mengalah agar cepat selesai", skor: 1 },
    ],
  },
];

function profilPsiko(total: number) {
  if (total >= 17)
    return {
      nama: "Sang Analitis Tenang",
      desc: "Kamu berpikir dingin dan sistematis. Argumenmu berpijak pada logika dan bukti, dan kamu jarang terpancing emosi. Dalam debat, kamu menunggu lawan selesai lalu membongkar titik lemahnya satu per satu.",
      gaya: "AI akan melawanmu dengan struktur argumen formal (premis–konklusi), data, dan logical fallacy detector.",
    };
  if (total >= 13)
    return {
      nama: "Penyerang Terstruktur",
      desc: "Kamu agresif tapi tetap terarah. Kamu suka mengambil inisiatif serangan sambil menjaga argumenmu tetap masuk akal. Emosi ada, tapi jadi bahan bakar, bukan pengganggu.",
      gaya: "AI akan bertukar serangan cepat — siap-siap kontra-argumen bertubi-tubi.",
    };
  if (total >= 9)
    return {
      nama: "Pembela Nilai",
      desc: "Kamu berdebat dari hati — moral, keadilan, dan pengalaman hidup adalah senjatamu. Kamu kuat saat topik menyentuh kemanusiaan, meski kadang kurang nyaman dengan angka dan statistik.",
      gaya: "AI akan menantangmu dengan studi kasus dan menuntut bukti empiris di balik nilai yang kamu pegang.",
    };
  return {
    nama: "Pengamat Santai",
    desc: "Kamu menghindari konflik dan lebih suka menonton dari pinggir. Kamu terbuka dan jujur soal batas pengetahuanmu — itu juga kekuatan: kamu sulit terjebak gengsi intelektual.",
    gaya: "AI akan ramah dan membangun argumen perlahan, sambil terus mendorongmu keluar dari zona nyaman.",
  };
}

/* =================== level debat =================== */

const LEVELS = [
  { id: "awam", label: "Awam", desc: "AI santai, argumen sederhana, banyak contoh sehari-hari" },
  { id: "m-pertama", label: "Menengah Pertama", desc: "AI mulai serius, argumen dasar filsafat & logika" },
  { id: "menengah", label: "Menengah", desc: "AI kontra dengan premis-premis kuat & tuntut bukti" },
  { id: "m-atas", label: "Menengah Atas", desc: "AI mengutip pemikir, menyerang celah logika kecil" },
  { id: "atas", label: "Atas", desc: "AI agresif: deduksi ketat, statistik, fallacy hunting" },
  { id: "hard", label: "Hard", desc: "AI kejam secara intelektual — setiap kalimatmu disikat" },
  { id: "penghafal", label: "Penghafal", desc: "AI seperti ensiklopedia berjalan: kutipan filsuf & paper" },
  { id: "superhard", label: "SuperHard", desc: "Level maksimal — AI tanpa ampun, debat level akademik" },
] as const;

/* =================== hasil =================== */

interface Verdict {
  winner: "user" | "ai" | "seri";
  skorUser: number;
  skorAi: number;
  unggul: string;
  melemah: string;
  topik: string;
  komentar: string;
}

interface PesanDebat {
  role: "user" | "assistant";
  content: string;
}

function fmtDurasi(ms: number) {
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h} jam ${m} menit ${sec} detik`;
}

/* =================== PDF minimal dengan JPEG embed =================== */

function buatPdfDariJpeg(jpegBytes: Uint8Array, lebar: number, tinggi: number): Blob {
  // PDF 1 halaman berisi gambar JPEG (DCTDecode) — dibangun manual.
  const enc = new TextEncoder();
  const parts: Uint8Array[] = [];
  const offsets: number[] = [];
  let pos = 0;

  const push = (chunk: string | Uint8Array) => {
    const b = typeof chunk === "string" ? enc.encode(chunk) : chunk;
    parts.push(b);
    pos += b.length;
  };
  const markOffset = () => offsets.push(pos);

  push("%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n");

  // Objek 1: Katalog
  markOffset();
  push("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");

  // Objek 2: Pages
  markOffset();
  push(`2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n`);

  // Objek 3: Page — ukuran halaman = ukuran gambar (pt = px di sini)
  markOffset();
  push(`3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${lebar} ${tinggi}] /Resources << /XObject << /Im0 5 0 R >> >> /Contents 4 0 R >>\nendobj\n`);

  // Objek 4: Content stream (gambar dipasang penuh halaman)
  markOffset();
  const content = `q\n${lebar} 0 0 ${tinggi} 0 0 cm\n/Im0 Do\nQ\n`;
  push(`4 0 obj\n<< /Length ${content.length} >>\nstream\n${content}endstream\nendobj\n`);

  // Objek 5: Gambar JPEG
  markOffset();
  push(`5 0 obj\n<< /Type /XObject /Subtype /Image /Width ${lebar} /Height ${tinggi} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n`);
  push(jpegBytes);
  push("\nendstream\nendobj\n");

  // Objek 6: Info
  markOffset();
  push("6 0 obj\n<< /Producer (FanzzTools V2) /Title (Hasil Debat AI) >>\nendobj\n");

  // XREF
  const xrefPos = pos;
  let xref = `xref\n0 ${offsets.length + 1}\n0000000000 65535 f \n`;
  for (const off of offsets) {
    xref += `${String(off).padStart(10, "0")} 00000 n \n`;
  }
  push(xref);
  push(`trailer\n<< /Size ${offsets.length + 1} /Root 1 0 R /Info 6 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`);

  return new Blob(parts as BlobPart[], { type: "application/pdf" });
}

/* =================== komponen =================== */

const TOPIK_SARAN = [
  "Keberadaan Tuhan",
  "Agama vs Sains",
  "Makna hidup tanpa agama",
  "Moralitas tanpa Tuhan",
  "Ateisme vs teisme",
  "Keadilan dunia",
  "Kesadaran & jiwa",
  "Takdir vs free will",
];

export default function DebateView() {
  const { toast } = useToast();
  // fase: psiko → profil → topik → debat → hasil
  const [fase, setFase] = useState<"psiko" | "profil" | "topik" | "debat" | "hasil">("psiko");
  const [soalIdx, setSoalIdx] = useState(0);
  const [jawaban, setJawaban] = useState<number[]>([]);
  const [profil, setProfil] = useState<ReturnType<typeof profilPsiko> | null>(null);
  const [level, setLevel] = useState<string>("menengah");
  const [topik, setTopik] = useState("");
  const [pesan, setPesan] = useState<PesanDebat[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [mulaiDi, setMulaiDi] = useState(0);
  const [selesaiDi, setSelesaiDi] = useState(0);
  const [ronde, setRonde] = useState(0);
  const MAX_RONDE = 5;
  const [verdict, setVerdict] = useState<Verdict | null>(null);
  const [menilai, setMenilai] = useState(false);
  const [now, setNow] = useState(Date.now());
  const cardRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // jam berjalan saat debat
  useEffect(() => {
    if (fase !== "debat") return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [fase]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [pesan]);

  const jawab = (idx: number) => {
    const next = [...jawaban, idx];
    setJawaban(next);
    if (soalIdx < SOAL_PSIKO.length - 1) {
      setSoalIdx(soalIdx + 1);
    } else {
      const total = next.reduce((n, optIdx, k) => n + (SOAL_PSIKO[k]?.opsi[optIdx]?.skor || 0), 0);
      setProfil(profilPsiko(total));
      setFase("profil");
    }
  };

  const mulaiDebat = async () => {
    const t = topik.trim();
    if (!t) {
      toast({ title: "Pilih topik dulu", description: "Ketik topik atau pilih dari saranan." });
      return;
    }
    setFase("debat");
    setPesan([]);
    setRonde(0);
    setVerdict(null);
    setMulaiDi(Date.now());
    setNow(Date.now());
    pushHistory("debat", { id: `debat-${Date.now()}`, title: `Debat: ${t}`, subtitle: `Level ${LEVELS.find((l) => l.id === level)?.label}` });
    // pembukaan dari AI
    await kirimArgumen(`[PEMBUKAAN] Topik debat: "${t}". Buka debat dengan posisi tegas (kamu bisa pro atau kontra, pilih yang paling menantang).`, true);
  };

  const systemDebat = useCallback(() => {
    const lvl = LEVELS.find((l) => l.id === level)!;
    return ` kamu adalah LAWAN DEBAT filsafat tingkat "${lvl.label}" (${lvl.desc}).

Profil psikologi lawan (user): ${profil?.nama} — ${profil?.desc} ${profil?.gaya}

Aturan debat:
- Gaya bicara: ${level === "awam" || level === "m-pertama" ? "santai & ramah" : "tajam dan tanpa basa-basi"}. ${level === "superhard" || level === "hard" || level === "penghafal" ? "Serang setiap celah logika dengan brutal tapi tetap sopan (tanpa hinaan pribadi)." : ""}
- Balas dengan 1 argumen utama + maksimal 2 paragraf. Ringkas, padat, beracun secara intelektual (sesuai level).
- ${level === "penghafal" || level === "superhard" ? "Kutip filsuf/science kapan relevan (Nietzsche, Kant, Hume, Dawkins, dsb)." : "Gunakan contoh sehari-hari bila level rendah."}
- JANGAN menyerah atau terlalu mengalah — lawan user sepenuhnya sampai debat berakhir.
- JANGAN gunakan format heading besar; cukup paragraf + poin pendek.
- Balas dalam Bahasa Indonesia.`;
  }, [level, profil]);

  const kirimArgumen = async (teks: string, pembukaan = false) => {
    if (busy) return;
    if (!pembukaan) {
      if (!teks.trim()) return;
      setPesan((p) => [...p, { role: "user", content: teks.trim() }]);
      setInput("");
      setRonde((r) => r + 1);
    }
    setBusy(true);
    try {
      const messages: Array<{ role: "user" | "assistant"; content: string }> = [
        { role: "user", content: systemDebat() },
        { role: "assistant", content: "Siap. Aku lawan debatmu — mulai!" },
        ...pesan.slice(-10),
        { role: "user", content: teks },
      ];
      const r = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages, model: "gpt-4.1-mini", mode: "normal" }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "AI tidak merespons");
      setPesan((p) => [...p, { role: "assistant", content: d.text }]);
    } catch (e) {
      toast({ title: "Debat terputus", description: e instanceof Error ? e.message : "Coba lagi", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const akhiriDanNilai = async () => {
    if (pesan.length < 2) {
      toast({ title: "Debat belum cukup", description: "Kirim minimal 1 argumen dulu." });
      return;
    }
    setMenilai(true);
    setSelesaiDi(Date.now());
    try {
      const transkrip = pesan
        .map((m) => `${m.role === "user" ? "USER" : "AI"}: ${m.content}`)
        .join("\n\n");
      const juriPrompt = `Kamu adalah JURI debat netral dan ketat. Nilai debat berikut ini secara objektif.

Topik: "${topik}"
Profil user: ${profil?.nama}
Level lawan AI: ${LEVELS.find((l) => l.id === level)?.label}

TRANSKRIP DEBAT:
${transkrip}

Nilai berdasarkan: kualitas logika, bukti, konsistensi, menjawab bantahan, dan kejatuhan fallacy.

WAJIB jawab HANYA dengan JSON valid (tanpa teks lain):
{"winner":"user|ai|seri","skorUser":0-100,"skorAi":0-100,"unggul":"siapa/apa yang paling unggul dan alasannya (1 kalimat)","melemah":"titik terlemah masing-masing pihak (1 kalimat)","topik":"ringkasan topik debat (pendek)","komentar":"komentar juri 2-3 kalimat"}`;

      const r = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [{ role: "user", content: juriPrompt }],
          model: "gpt-4.1-mini",
          mode: "normal",
        }),
      });
      const d = await r.json();
      if (!d?.ok) throw new Error(d?.error || "Juri gagal menilai");
      const m = /\{[\s\S]*\}/.exec(String(d.text));
      if (!m) throw new Error("Format penilaian tidak terbaca");
      const v = JSON.parse(m[0]) as Verdict;
      setVerdict(v);
      setFase("hasil");
    } catch (e) {
      toast({ title: "Gagal menilai debat", description: e instanceof Error ? e.message : "Coba akhiri lagi", variant: "destructive" });
    } finally {
      setMenilai(false);
    }
  };

  /* ---------- render kartu hasil (untuk unduhan) ---------- */
  const renderKartu = async (tipe: "png" | "jpg" | "pdf") => {
    const W = 1080;
    const H = 1500;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx || !verdict) return;

    // latar + border tebal (sesuai permintaan)
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#0f0b1e");
    g.addColorStop(0.5, "#1a1030");
    g.addColorStop(1, "#0d1b1e");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    // border ganda
    ctx.strokeStyle = "#22d3ee";
    ctx.lineWidth = 14;
    ctx.strokeRect(28, 28, W - 56, H - 56);
    ctx.strokeStyle = "rgba(232,121,249,0.35)";
    ctx.lineWidth = 3;
    ctx.strokeRect(54, 54, W - 108, H - 108);

    ctx.textAlign = "center";
    ctx.fillStyle = "#22d3ee";
    ctx.font = "800 40px Inter, sans-serif";
    ctx.fillText("⚔ HASIL DEBAT AI — FANZZTOOLS V2", W / 2, 130);

    ctx.fillStyle = "rgba(255,255,255,0.75)";
    ctx.font = "600 30px Inter, sans-serif";
    ctx.fillText(`Topik: ${verdict.topik || topik}`.slice(0, 60), W / 2, 190);
    ctx.fillText(`Level: ${LEVELS.find((l) => l.id === level)?.label} • Profil: ${profil?.nama}`, W / 2, 235);

    // pemenang besar
    const menang = verdict.winner === "user" ? "KAMU MENANG! 🏆" : verdict.winner === "ai" ? "AI MENANG 🤖" : "SERI ⚖";
    ctx.fillStyle = verdict.winner === "user" ? "#34d399" : verdict.winner === "ai" ? "#f87171" : "#fbbf24";
    ctx.font = "900 86px Inter, sans-serif";
    ctx.fillText(menang, W / 2, 380);

    // skor
    ctx.font = "800 44px Inter, sans-serif";
    ctx.fillStyle = "#34d399";
    ctx.textAlign = "right";
    ctx.fillText(`${verdict.skorUser}`, W / 2 - 30, 470);
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.textAlign = "center";
    ctx.font = "700 30px Inter, sans-serif";
    ctx.fillText("SKOR", W / 2, 445);
    ctx.textAlign = "left";
    ctx.fillStyle = "#f87171";
    ctx.font = "800 44px Inter, sans-serif";
    ctx.fillText(`${verdict.skorAi}`, W / 2 + 30, 470);
    ctx.font = "600 26px Inter, sans-serif";
    ctx.fillStyle = "#34d399";
    ctx.textAlign = "right";
    ctx.fillText("KAMU", W / 2 - 30, 505);
    ctx.fillStyle = "#f87171";
    ctx.textAlign = "left";
    ctx.fillText("AI", W / 2 + 30, 505);

    // detail
    ctx.textAlign = "left";
    const baris: Array<[string, string]> = [
      ["⏱ Durasi", fmtDurasi(selesaiDi - mulaiDi)],
      ["🔁 Ronde", `${ronde} kali giliranmu`],
      ["📈 Paling unggul", verdict.unggul.slice(0, 90)],
      ["📉 Paling melemah", verdict.melemah.slice(0, 90)],
      ["🧠 Psikologi", `${profil?.nama}`],
    ];
    let y = 590;
    for (const [k, v] of baris) {
      ctx.fillStyle = "rgba(232,121,249,0.9)";
      ctx.font = "700 28px Inter, sans-serif";
      ctx.fillText(k, 110, y);
      ctx.fillStyle = "rgba(255,255,255,0.88)";
      ctx.font = "600 28px Inter, sans-serif";
      const kata = v.split(" ");
      let line = "";
      let yy = y + 44;
      for (const kata2 of kata) {
        const coba = line ? `${line} ${kata2}` : kata2;
        if (ctx.measureText(coba).width > W - 260) {
          ctx.fillText(line, 110, yy);
          yy += 38;
          line = kata2;
        } else line = coba;
      }
      ctx.fillText(line, 110, yy);
      y = Math.max(y + 44, yy) + 46;
    }

    // komentar juri
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.font = "600 24px Inter, sans-serif";
    ctx.fillText("KOMENTAR JURI:", 110, y);
    ctx.fillStyle = "rgba(255,255,255,0.85)";
    ctx.font = "500 26px Inter, sans-serif";
    const kata = verdict.komentar.split(" ");
    let line = "";
    let yy = y + 42;
    for (const k2 of kata) {
      const coba = line ? `${line} ${k2}` : k2;
      if (ctx.measureText(coba).width > W - 220) {
        ctx.fillText(line, 110, yy);
        yy += 38;
        line = k2;
      } else line = coba;
    }
    ctx.fillText(line, 110, yy);

    // footer
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.font = "600 22px Inter, sans-serif";
    ctx.fillText("©FanzzProject — By: Fanzz-Dev. 2026 • FanzzTools V2", W / 2, H - 76);

    // unduh
    const nama = `fanzz-debat-${Date.now()}`;
    if (tipe === "png") {
      const a = document.createElement("a");
      a.href = canvas.toDataURL("image/png");
      a.download = `${nama}.png`;
      a.click();
    } else if (tipe === "jpg") {
      const a = document.createElement("a");
      a.href = canvas.toDataURL("image/jpeg", 0.92);
      a.download = `${nama}.jpg`;
      a.click();
    } else {
      // PDF: embed JPEG
      const dataUrl = canvas.toDataURL("image/jpeg", 0.9);
      const b64 = dataUrl.split(",")[1];
      const bin = atob(b64);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      const pdf = buatPdfDariJpeg(bytes, W, H);
      const a = document.createElement("a");
      a.href = URL.createObjectURL(pdf);
      a.download = `${nama}.pdf`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    }
    toast({ title: `Hasil debat terunduh (${tipe.toUpperCase()})!`, description: "Lengkap dengan border FanzzTools." });
  };

  /* =================== render =================== */

  return (
    <div>
      <ToolHeader icon={<Swords className="h-5.5 w-5.5" />} title="Debat Filosofis AI" subtitle="Test psikologi dulu • 8 level • skor & unduh hasil" accent="amber" />

      {/* FASE 1: TEST PSIKOLOGI */}
      {fase === "psiko" && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl p-5">
          <div className="mb-3 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-sm font-extrabold">
              <Brain className="h-4 w-4 text-amber-400" /> Test Psikologi — {soalIdx + 1}/{SOAL_PSIKO.length}
            </p>
            <span className="text-[10px] font-bold text-muted-foreground">wajib sebelum debat</span>
          </div>
          {/* progres */}
          <div className="mb-4 h-1.5 overflow-hidden rounded-full bg-secondary">
            <motion.div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500" animate={{ width: `${((soalIdx + 1) / SOAL_PSIKO.length) * 100}%` }} />
          </div>
          <p className="text-sm font-bold leading-relaxed">{SOAL_PSIKO[soalIdx].q}</p>
          <div className="mt-4 space-y-2">
            {SOAL_PSIKO[soalIdx].opsi.map((o, i) => (
              <button
                key={i}
                onClick={() => jawab(i)}
                className="flex w-full items-center justify-between gap-2 rounded-xl bg-secondary/60 p-3.5 text-left text-xs font-bold transition-colors hover:bg-amber-500/15"
              >
                {o.teks}
                <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
              </button>
            ))}
          </div>
        </motion.div>
      )}

      {/* FASE 2: HASIL PSIKOLOGI */}
      {fase === "profil" && profil && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="glass rounded-2xl p-5">
            <p className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-amber-400">Hasil test psikologi kamu</p>
            <h3 className="mt-1.5 text-lg font-extrabold text-amber-300">{profil.nama}</h3>
            <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">{profil.desc}</p>
            <p className="mt-2.5 rounded-xl bg-amber-500/10 p-3 text-[11px] leading-relaxed text-amber-200">
              <Sparkles className="mr-1 inline h-3.5 w-3.5" /> {profil.gaya}
            </p>
          </div>

          {/* pilih level */}
          <div className="glass rounded-2xl p-5">
            <p className="mb-3 flex items-center gap-1.5 text-sm font-extrabold">
              <Swords className="h-4 w-4 text-amber-400" /> Pilih level lawan AI
            </p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {LEVELS.map((l) => (
                <button
                  key={l.id}
                  onClick={() => setLevel(l.id)}
                  className={`rounded-xl p-2.5 text-center transition ${
                    level === l.id ? "bg-gradient-to-r from-amber-500 to-orange-600 text-white shadow-lg" : "bg-secondary/60 text-muted-foreground"
                  }`}
                  title={l.desc}
                >
                  <p className="text-[11px] font-extrabold">{l.label}</p>
                </button>
              ))}
            </div>
            <p className="mt-2 text-[10.5px] leading-relaxed text-muted-foreground">📋 {LEVELS.find((l) => l.id === level)?.desc}</p>
          </div>

          {/* pilih topik */}
          <div className="glass rounded-2xl p-5">
            <p className="mb-2 text-sm font-extrabold">Topik debat</p>
            <Input
              value={topik}
              onChange={(e) => setTopik(e.target.value)}
              placeholder="Tulis topik debatmu…"
              className="rounded-xl"
              maxLength={120}
            />
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {TOPIK_SARAN.map((t) => (
                <button
                  key={t}
                  onClick={() => setTopik(t)}
                  className="rounded-full bg-amber-500/10 px-3 py-1.5 text-[10px] font-bold text-amber-300 transition-colors hover:bg-amber-500/20"
                >
                  {t}
                </button>
              ))}
            </div>
            <button
              onClick={mulaiDebat}
              disabled={!topik.trim()}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-4 py-3.5 text-xs font-extrabold text-white transition-transform active:scale-95 disabled:opacity-50"
            >
              <Swords className="h-4 w-4" /> Mulai Debat vs AI
            </button>
          </div>
        </motion.div>
      )}

      {/* FASE 3: DEBAT */}
      {fase === "debat" && (
        <div className="space-y-3">
          <div className="glass flex items-center justify-between rounded-2xl p-3.5">
            <div className="min-w-0">
              <p className="truncate text-xs font-extrabold">⚔ {topik}</p>
              <p className="text-[10px] text-muted-foreground">
                Level {LEVELS.find((l) => l.id === level)?.label} • Ronde {ronde}/{MAX_RONDE}
              </p>
            </div>
            <div className="flex shrink-0 items-center gap-1.5 rounded-xl bg-black/40 px-3 py-2">
              <Timer className="h-3.5 w-3.5 text-amber-400" />
              <span className="text-[11px] font-extrabold tabular-nums text-amber-300">{fmtDurasi(now - mulaiDi)}</span>
            </div>
          </div>

          {/* transkrip */}
          <div ref={scrollRef} className="max-h-[46vh] space-y-3 overflow-y-auto rounded-2xl bg-black/25 p-3">
            {pesan.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-[11.5px] leading-relaxed ${
                    m.role === "user" ? "bg-gradient-to-br from-amber-500/80 to-orange-600/80 text-white" : "bg-secondary text-foreground"
                  }`}
                >
                  <p className="mb-1 text-[9px] font-black uppercase opacity-70">{m.role === "user" ? "KAMU" : "AI LAWAN"}</p>
                  {m.content}
                </div>
              </div>
            ))}
            {busy && (
              <div className="flex items-center gap-2 text-[11px] font-bold text-muted-foreground">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> AI menyusun serangan balasan…
              </div>
            )}
          </div>

          {/* input */}
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Tulis argumenmu…"
              className="min-h-[52px] resize-none rounded-xl"
              maxLength={1500}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  kirimArgumen(input);
                }
              }}
            />
            <button
              onClick={() => kirimArgumen(input)}
              disabled={busy || !input.trim()}
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white disabled:opacity-50"
            >
              {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-4.5 w-4.5" />}
            </button>
          </div>

          <div className="flex gap-2">
            <button
              onClick={akhiriDanNilai}
              disabled={menilai || pesan.length < 2}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-4 py-3 text-xs font-extrabold text-white disabled:opacity-50"
            >
              {menilai ? <Loader2 className="h-4 w-4 animate-spin" /> : <Scale className="h-4 w-4" />}
              {menilai ? "Juri sedang menilai…" : "Akhiri & Nilai Debat"}
            </button>
            <button
              onClick={() => { setFase("psiko"); setSoalIdx(0); setJawaban([]); setPesan([]); }}
              className="flex items-center justify-center gap-1.5 rounded-xl bg-secondary px-3.5 py-3 text-[11px] font-bold text-muted-foreground"
              title="Ulangi dari test psikologi"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* FASE 4: HASIL */}
      {fase === "hasil" && verdict && (
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} ref={cardRef} className="space-y-4">
          <div className="glass rounded-2xl p-5 text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Hasil akhir • {fmtDurasi(selesaiDi - mulaiDi)}</p>
            {verdict.winner === "user" ? (
              <p className="mt-2 flex items-center justify-center gap-2 text-2xl font-black text-emerald-400">
                <Trophy className="h-7 w-7" /> KAMU MENANG!
              </p>
            ) : verdict.winner === "ai" ? (
              <p className="mt-2 flex items-center justify-center gap-2 text-2xl font-black text-red-400">
                <XCircle className="h-7 w-7" /> AI MENANG
              </p>
            ) : (
              <p className="mt-2 flex items-center justify-center gap-2 text-2xl font-black text-amber-400">
                <Scale className="h-7 w-7" /> SERI
              </p>
            )}
            <div className="mt-3 flex items-center justify-center gap-4">
              <div className="text-center">
                <p className="text-3xl font-black text-emerald-400">{verdict.skorUser}</p>
                <p className="text-[10px] font-bold text-muted-foreground">KAMU</p>
              </div>
              <span className="text-xl text-muted-foreground">vs</span>
              <div className="text-center">
                <p className="text-3xl font-black text-red-400">{verdict.skorAi}</p>
                <p className="text-[10px] font-bold text-muted-foreground">AI</p>
              </div>
            </div>
          </div>

          <div className="glass space-y-3 rounded-2xl p-4">
            {[
              ["Topik debat", verdict.topik || topik],
              ["Paling unggul", verdict.unggul],
              ["Paling melemah", verdict.melemah],
              ["Durasi", fmtDurasi(selesaiDi - mulaiDi)],
              ["Ronde", `${ronde} kali giliranmu`],
              ["Profil psikologi", profil?.nama || "—"],
            ].map(([k, v]) => (
              <div key={k} className="border-b border-[var(--surface-line)] pb-2.5 last:border-0 last:pb-0">
                <p className="text-[9.5px] font-black uppercase tracking-wider text-amber-400">{k}</p>
                <p className="mt-0.5 text-[11.5px] leading-relaxed">{v}</p>
              </div>
            ))}
          </div>

          <div className="glass rounded-2xl p-4">
            <p className="mb-1.5 flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-amber-400">
              <CheckCircle2 className="h-3.5 w-3.5" /> Komentar juri
            </p>
            <p className="text-[12px] leading-relaxed text-muted-foreground">{verdict.komentar}</p>
          </div>

          {/* unduh */}
          <div className="glass rounded-2xl p-4">
            <p className="mb-2.5 flex items-center gap-1.5 text-sm font-extrabold">
              <Download className="h-4 w-4 text-amber-400" /> Unduh hasil (dengan border)
            </p>
            <div className="grid grid-cols-3 gap-2">
              {(["png", "jpg", "pdf"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => renderKartu(t)}
                  className="flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-3 py-3 text-[11px] font-extrabold text-white uppercase transition-transform active:scale-95"
                >
                  <Download className="h-3.5 w-3.5" /> {t}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => { setFase("psiko"); setSoalIdx(0); setJawaban([]); setPesan([]); setVerdict(null); }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-secondary px-4 py-3.5 text-xs font-extrabold text-muted-foreground"
          >
            <RotateCcw className="h-4 w-4" /> Debat Lagi (ulang test psikologi)
          </button>
        </motion.div>
      )}
    </div>
  );
}
