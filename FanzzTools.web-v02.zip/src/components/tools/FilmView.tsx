"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ToolHeader, MovieCard, CardSkeleton, EmptyState } from "@/components/tools/shared";
import { useApp, addWatchHistory, getSettings } from "@/lib/app-store";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import ChatThread, { type ChatPeer } from "@/components/chat/ChatThread";
import WatchChat from "@/components/chat/WatchChat";
import {
  Clapperboard, Search, Star, TrendingUp, Flame, CalendarDays, Tv, Film,
  ArrowLeft, Play, Loader2, RefreshCw, ShieldAlert, Captions, Server,
  ExternalLink, ChevronDown, ListVideo, Sparkle, Download, FolderDown, MessageCircle, X, Search as SearchIcon2,
  Smartphone, Sparkles, CheckCircle2, Languages,
} from "lucide-react";

interface MovieItem {
  id: number;
  title: string;
  type: string;
  poster: string | null;
  rating: number;
  year: string;
  overview?: string;
}

interface ServerOption {
  id: string;
  name: string;
  url: string;
  source: string;
  compat: boolean;
  subParam: boolean;
  subMode?: "file" | "cc";
  note?: string;
}

interface FilmDetailData {
  id: number;
  type: "movie" | "tv";
  title: string;
  tagline: string;
  overview: string;
  poster: string | null;
  backdrop: string | null;
  rating: number;
  voteCount: number;
  year: string;
  releaseDate: string;
  duration?: number | null;
  genres: string[];
  status: string;
  numberOfSeasons: number;
  seasons: Array<{ id: number; number: number; name: string; episodes: number; year: string; poster: string | null }>;
  cast: Array<{ id: number; name: string; character: string; photo: string | null }>;
  directors: string[];
  trailer: string | null;
}

type Tab = "trending" | "popular" | "top" | "upcoming" | "idlix";

export default function FilmView() {
  const { filmDeepLink, clearFilmLink } = useApp();
  const [mode, setMode] = useState<"browse" | "detail" | "watch">("browse");
  const [selected, setSelected] = useState<{ id: number; type: "movie" | "tv" } | null>(null);
  const [watchEp, setWatchEp] = useState<{ season?: number; episode?: number }>({});

  // deep link dari view lain
  useEffect(() => {
    if (filmDeepLink) {
      queueMicrotask(() => {
        setSelected(filmDeepLink);
        setMode("detail");
        clearFilmLink();
      });
    }
  }, [filmDeepLink, clearFilmLink]);

  const openDetail = (id: number, type: string) => {
    setSelected({ id, type: type === "tv" ? "tv" : "movie" });
    setMode("detail");
  };

  const back = () => {
    if (mode === "watch") setMode("detail");
    else if (mode === "detail") {
      setMode("browse");
      setSelected(null);
    }
  };

  return (
    <div className="pb-4">
      <AnimatePresence mode="wait">
        {mode === "browse" && (
          <motion.div key="browse" initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -14 }}>
            <BrowsePanel onOpen={openDetail} />
          </motion.div>
        )}
        {mode === "detail" && selected && (
          <motion.div key="detail" initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 24 }}>
            <DetailPanel
              id={selected.id}
              type={selected.type}
              onBack={back}
              onWatch={(season, episode) => {
                setWatchEp({ season, episode });
                setMode("watch");
              }}
            />
          </motion.div>
        )}
        {mode === "watch" && selected && (
          <motion.div key="watch" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }}>
            <PlayerPanel
              id={selected.id}
              type={selected.type}
              title=""
              season={watchEp.season}
              episode={watchEp.episode}
              onBack={back}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ================= BROWSE ================= */

function BrowsePanel({ onOpen }: { onOpen: (id: number, type: string) => void }) {
  const [tab, setTab] = useState<Tab>("trending");
  const [idlix, setIdlix] = useState<MovieItem[] | null>(null);
  const [idlixErr, setIdlixErr] = useState(false);
  const [data, setData] = useState<HomeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [searchResults, setSearchResults] = useState<MovieItem[] | null>(null);
  const [searching, setSearching] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    fetch("/api/movies/home")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setData(d?.ok ? d : null))
      .catch(() => setData(null))
      .finally(() => setLoading(false));
  }, []);

  const doSearch = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (q.trim().length < 2) {
      setSearchResults(null);
      return;
    }
    debounceRef.current = setTimeout(() => {
      setSearching(true);
      fetch(`/api/movies/search?q=${encodeURIComponent(q.trim())}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => setSearchResults(d?.ok ? d.results : []))
        .catch(() => setSearchResults([]))
        .finally(() => setSearching(false));
    }, 450);
  }, []);

  const tabs: Array<{ id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: "trending", label: "Trending", icon: TrendingUp },
    { id: "popular", label: "Populer", icon: Flame },
    { id: "top", label: "Top Rating", icon: Star },
    { id: "upcoming", label: "Akan Tayang", icon: CalendarDays },
    { id: "idlix", label: "IDLIX", icon: Sparkle },
  ];

  // fetch IDLIX cuma kalau tab-nya dipilih (hemat request — server cache 30 mnt)
  useEffect(() => {
    if (tab !== "idlix" || idlix) return;
    fetch("/api/movies/idlix")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.ok && d.items?.length) setIdlix(d.items);
        else setIdlixErr(true);
      })
      .catch(() => setIdlixErr(true));
  }, [tab, idlix]);

  const getList = (): MovieItem[] => {
    if (!data) return [];
    switch (tab) {
      case "trending": return data.trending;
      case "top": return [...data.topMovies, ...data.topSeries];
      case "upcoming": return data.upcoming;
      default: return data.trending;
    }
  };

  return (
    <div>
      <ToolHeader icon={<Clapperboard className="h-5.5 w-5.5" />} title="Nonton Film" subtitle="Streaming film & series — pilih server, embed, dan subtitle" />

      {/* search */}
      <div className="relative mb-4">
        <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            doSearch(e.target.value);
          }}
          placeholder="Cari film atau series..."
          className="rounded-xl border-border/60 bg-secondary/50 pl-10"
        />
        {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-red-400" />}
      </div>

      {searchResults ? (
        <section>
          <h3 className="mb-3 text-sm font-bold text-muted-foreground">
            Hasil pencarian &quot;{query}&quot; ({searchResults.length})
          </h3>
          {searchResults.length === 0 ? (
            <EmptyState icon={<Search className="h-6 w-6" />} title="Tidak ditemukan" desc="Silakan coba kata kunci lain, misalnya judul lengkapnya." />
          ) : (
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
              {searchResults.map((m, i) => (
                <MovieCard key={`${m.id}-${i}`} index={i} title={m.title} poster={m.poster} rating={m.rating} year={m.year} type={m.type} onClick={() => onOpen(m.id, m.type)} />
              ))}
            </div>
          )}
        </section>
      ) : (
        <>
          {/* tabs */}
          <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
                  tab === t.id ? "text-white" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab === t.id && <motion.span layoutId="film-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-red-500 to-red-700" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
                <t.icon className="relative z-10 h-3.5 w-3.5" />
                <span className="relative z-10">{t.label}</span>
              </button>
            ))}
          </div>

          {loading ? (
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
              {Array.from({ length: 12 }).map((_, i) => <CardSkeleton key={i} />)}
            </div>
          ) : tab === "idlix" ? (
            idlixErr ? (
              <EmptyState icon={<Sparkle className="h-6 w-6" />} title="IDLIX lagi sibuk" desc="Sumber-nya lagi kena proteksi Cloudflare. Coba lagi beberapa menit lagi atau pakai tab lain dulu ya." />
            ) : idlix ? (
              <>
                <p className="mb-3 flex items-center gap-1.5 text-[10.5px] text-muted-foreground">
                  <Sparkle className="h-3 w-3 text-red-400" /> Baru &amp; ramai di IDLIX — diklik langsung dibuka pakai player FanzzTools
                </p>
                <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
                  {idlix.map((m, i) => (
                    <MovieCard key={`${m.id}-${i}`} index={i} title={m.title} poster={m.poster} rating={m.rating} year={m.year} type={m.type} onClick={() => onOpen(m.id, m.type)} />
                  ))}
                </div>
              </>
            ) : (
              <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
                {Array.from({ length: 12 }).map((_, i) => <CardSkeleton key={i} />)}
              </div>
            )
          ) : (
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
              {getList().map((m, i) => (
                <MovieCard key={`${m.id}-${i}`} index={i} title={m.title} poster={m.poster} rating={m.rating} year={m.year} type={m.type} onClick={() => onOpen(m.id, m.type)} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

interface HomeData {
  trending: MovieItem[];
  topMovies: MovieItem[];
  topSeries: MovieItem[];
  upcoming: MovieItem[];
}

/* ================= DETAIL ================= */

function DetailPanel({ id, type, onBack, onWatch }: { id: number; type: "movie" | "tv"; onBack: () => void; onWatch: (season?: number, episode?: number) => void }) {
  const [detail, setDetail] = useState<FilmDetailData | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [season, setSeason] = useState<number>(1);
  const [episode, setEpisode] = useState<number>(1);
  const [epOpen, setEpOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetch(`/api/movies/detail?id=${id}&type=${type}`)
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (d?.ok) {
          setDetail(d);
          if (d.seasons?.length) {
            setSeason(d.seasons[0].number);
          }
        } else setErr(d?.error || "Gagal memuat detail");
      })
      .catch(() => setErr("Gagal memuat detail"))
      .finally(() => setLoading(false));
  }, [id, type]);

  const startWatch = () => {
    if (!detail) return;
    addWatchHistory({
      id: detail.id,
      type: detail.type,
      title: detail.title,
      poster: detail.poster,
      season: type === "tv" ? season : undefined,
      episode: type === "tv" ? episode : undefined,
    });
    // V0.01 (#7): catat juga ke riwayat per-tools
    pushHistory("film", {
      id: `${detail.type}-${detail.id}${type === "tv" ? `-s${season}e${episode}` : ""}`,
      title: detail.title,
      poster: detail.poster,
      subtitle: type === "tv" ? `Season ${season} • Episode ${episode}` : "Film",
    });
    // sync riwayat nonton ke profil sosial (muncul di pencarian pengguna)
    fetch("/api/social/profile", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        watched: { title: detail.title, poster: detail.poster, type: detail.type },
      }),
    }).catch(() => {});
    onWatch(type === "tv" ? season : undefined, type === "tv" ? episode : undefined);
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="relative aspect-video w-full overflow-hidden rounded-2xl shimmer" />
        <div className="h-7 w-2/3 rounded shimmer" />
        <div className="h-4 w-1/2 rounded shimmer" />
        <div className="h-20 rounded-2xl shimmer" />
      </div>
    );
  }

  if (err || !detail) {
    return (
      <div>
        <Button variant="ghost" onClick={onBack} className="mb-4 rounded-xl"><ArrowLeft className="mr-1 h-4 w-4" /> Kembali</Button>
        <EmptyState icon={<Film className="h-6 w-6" />} title={err || "Film tidak ditemukan"} />
      </div>
    );
  }

  const curSeason = detail.seasons?.find((s) => s.number === season);

  return (
    <div>
      <Button variant="ghost" onClick={onBack} className="mb-3 rounded-xl px-3"><ArrowLeft className="mr-1 h-4 w-4" /> Kembali</Button>

      {/* backdrop */}
      <div className="relative overflow-hidden rounded-2xl">
        <div className="aspect-video w-full bg-secondary">
          {detail.backdrop || detail.poster ? (
            <img src={detail.backdrop || detail.poster || ""} alt={detail.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
          ) : null}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5">
          <div className="flex items-end gap-3">
            <div className="hidden h-28 w-20 shrink-0 overflow-hidden rounded-xl shadow-xl sm:block">
              {detail.poster ? (
                <img src={detail.poster} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : null}
            </div>
            <div className="min-w-0">
              <h2 className="clamp-2 text-xl font-extrabold text-white sm:text-2xl">{detail.title}</h2>
              <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-white/70">
                <span className="rounded-full bg-amber-500/25 px-2 py-0.5 font-bold text-amber-300">★ {detail.rating.toFixed(1)}</span>
                {detail.year && <span>{detail.year}</span>}
                {detail.duration ? <span>• {Math.floor(detail.duration / 60)}j {detail.duration % 60}m</span> : null}
                {type === "tv" && detail.numberOfSeasons ? <span>• {detail.numberOfSeasons} season</span> : null}
              </div>
              {detail.genres?.length ? (
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {detail.genres.slice(0, 4).map((g) => (
                    <span key={g} className="rounded-full bg-white/10 px-2 py-0.5 text-[10px] font-medium text-white/80 backdrop-blur-sm">{g}</span>
                  ))}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      {/* tombol nonton */}
      <Button
        onClick={startWatch}
        size="lg"
        className="mt-4 w-full rounded-2xl bg-gradient-to-r from-red-500 to-red-700 py-6 text-base font-bold shadow-xl shadow-red-500/25 transition-transform hover:scale-[1.01] active:scale-[0.99]"
      >
        <Play className="mr-2 h-5 w-5" /> Nonton Sekarang
      </Button>

      {/* download via HDhub */}
      <HdhubDownloadSection title={detail.title} />

      {/* pemilih episode */}
      {type === "tv" && detail.seasons?.length ? (
        <div className="mt-4 space-y-2.5 rounded-2xl glass p-4">
          <div className="flex items-center gap-2 text-sm font-bold"><ListVideo className="h-4 w-4 text-red-400" /> Pilih Episode</div>
          <div className="flex gap-2">
            <Select value={String(season)} onValueChange={(v) => { setSeason(Number(v)); setEpisode(1); }}>
              <SelectTrigger className="w-full rounded-xl bg-secondary/50"><SelectValue placeholder="Season" /></SelectTrigger>
              <SelectContent>
                {detail.seasons.map((s) => (
                  <SelectItem key={s.number} value={String(s.number)}>Season {s.number} ({s.episodes} eps)</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative w-full">
              <Button variant="secondary" onClick={() => setEpOpen(!epOpen)} className="w-full justify-between rounded-xl bg-secondary/50 font-normal">
                Episode {episode}
                <ChevronDown className={`h-4 w-4 transition-transform ${epOpen ? "rotate-180" : ""}`} />
              </Button>
              {epOpen && curSeason && (
                <div className="glass-strong absolute z-30 mt-1 max-h-56 w-full overflow-y-auto rounded-xl p-1.5">
                  {Array.from({ length: curSeason.episodes }).map((_, i) => (
                    <button
                      key={i}
                      onClick={() => { setEpisode(i + 1); setEpOpen(false); }}
                      className={`w-full rounded-lg px-3 py-2 text-left text-xs font-medium transition-colors ${episode === i + 1 ? "bg-red-500 text-white" : "hover:bg-secondary"}`}
                    >
                      Episode {i + 1}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : null}

      {/* synopsis */}
      <section className="mt-4 rounded-2xl glass p-4">
        <h3 className="mb-1.5 text-sm font-bold">Sinopsis</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">{detail.overview || "Sinopsis belum tersedia untuk judul ini."}</p>
      </section>

      {/* cast */}
      {detail.cast?.length ? (
        <section className="mt-4">
          <h3 className="mb-2.5 text-sm font-bold">Pemain</h3>
          <div className="no-scrollbar -mx-1 flex gap-3 overflow-x-auto px-1 pb-1">
            {detail.cast.map((c) => (
              <div key={c.id} className="w-16 shrink-0 text-center">
                <div className="mx-auto h-16 w-16 overflow-hidden rounded-full bg-secondary ring-2 ring-border/50">
                  {c.photo ? (
                    <img src={c.photo} alt={c.name} className="h-full w-full object-cover" loading="lazy" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center text-lg font-bold text-muted-foreground">{c.name[0]}</div>
                  )}
                </div>
                <p className="mt-1.5 truncate text-[10px] font-semibold">{c.name}</p>
              </div>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

/* ================= PLAYER ================= */

const PLAYER_SANDBOX = "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

/** Daftar bahasa subtitle yang bisa dipilih (V0.01 — permintaan #8b: all language). */
const SUB_LANGS: Array<{ code: string; label: string }> = [
  { code: "id", label: "Indonesia" },
  { code: "en", label: "English" },
  { code: "ar", label: "Arabic" },
  { code: "es", label: "Spanish" },
  { code: "fr", label: "French" },
  { code: "de", label: "German" },
  { code: "it", label: "Italian" },
  { code: "pt", label: "Portuguese" },
  { code: "ru", label: "Russian" },
  { code: "ja", label: "Japanese" },
  { code: "ko", label: "Korean" },
  { code: "zh", label: "Chinese" },
  { code: "th", label: "Thai" },
  { code: "tr", label: "Turkish" },
  { code: "vi", label: "Vietnamese" },
  { code: "ms", label: "Malay" },
  { code: "tl", label: "Filipino" },
  { code: "hi", label: "Hindi" },
  { code: "nl", label: "Dutch" },
  { code: "pl", label: "Polish" },
  { code: "sv", label: "Swedish" },
  { code: "da", label: "Danish" },
  { code: "fi", label: "Finnish" },
  { code: "no", label: "Norwegian" },
  { code: "el", label: "Greek" },
  { code: "he", label: "Hebrew" },
  { code: "uk", label: "Ukrainian" },
  { code: "cs", label: "Czech" },
  { code: "ro", label: "Romanian" },
  { code: "hu", label: "Hungarian" },
];

function PlayerPanel({
  id, type, season, episode, onBack, title: _title,
}: {
  id: number;
  type: "movie" | "tv";
  season?: number;
  episode?: number;
  onBack: () => void;
  title: string;
}) {
  const [servers, setServers] = useState<ServerOption[]>([]);
  const [activeServer, setActiveServer] = useState<ServerOption | null>(null);
  /** V0.01: subtitle mendukung semua kode bahasa (default id — aktif otomatis, tidak dimatikan). */
  const [sub, setSub] = useState<string>("id");
  const [subMenuOpen, setSubMenuOpen] = useState(false);
  /** CC AI: bila aktif, subtitle yang tidak ditemukan akan diterjemahkan otomatis oleh AI. */
  const [aiSub, setAiSub] = useState(true);
  const [compatMode, setCompatMode] = useState(false);
  const [loadingServers, setLoadingServers] = useState(true);
  const [playerState, setPlayerState] = useState<"loading" | "ready" | "timeout" | "error">("loading");
  const [iframeKey, setIframeKey] = useState(0);
  const [chatOpen, setChatOpen] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const saved = getSettings().defaultSub;
    setSub(saved === "off" || saved === "en" ? saved : "id");
  }, []);

  const loadServers = useCallback(async (subLang: string) => {
    setLoadingServers(true);
    setPlayerState("loading");
    try {
      const params = new URLSearchParams({ id: String(id), type, sub: subLang });
      if (season) params.set("season", String(season));
      if (episode) params.set("episode", String(episode));
      if (aiSub) params.set("ai", "1");
      const res = await fetch(`/api/movies/servers?${params}`);
      const d = await res.json();
      if (d?.ok && d.servers?.length) {
        setServers(d.servers);
        const preferred = getSettings().defaultServer;
        // MovieZone = sumber utama (dipertahankan dari V2a). Preferensi tersimpan hanya
        // dipakai bila server non-VidLink (VidLink punya padanan di MovieZone
        // dengan sub_file yang sama — pilih versi MovieZone-nya).
        const first =
          (preferred && preferred !== "vidsrc-to" && preferred !== "vidlink"
            ? d.servers.find((s: ServerOption) => s.id === preferred)
            : undefined) ||
          d.servers.find((s: ServerOption) => s.source === "moviezone" && s.subMode === "file") ||
          d.servers.find((s: ServerOption) => s.source === "moviezone") ||
          d.servers.find((s: ServerOption) => s.subMode === "file") ||
          d.servers[0];
        setActiveServer(first);
        setCompatMode(Boolean(first.compat));
      } else {
        setServers([]);
        setPlayerState("error");
      }
    } catch {
      setPlayerState("error");
    } finally {
      setLoadingServers(false);
    }
  }, [id, type, season, episode, aiSub]);

  useEffect(() => {
    loadServers(sub);
  }, [loadServers, sub]);

  // iframe load/timeout handler
  useEffect(() => {
    setPlayerState("loading");
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    timeoutRef.current = setTimeout(() => {
      setPlayerState((s) => (s === "loading" ? "timeout" : s));
    }, 15000);
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [activeServer, iframeKey, sub]);

  const applyServer = (s: ServerOption) => {
    setActiveServer(s);
    setCompatMode(Boolean(s.compat));
  };

  const playerWrapRef = useRef<HTMLDivElement>(null);

  /** Fullscreen + kunci orientasi landscape (Android/Chrome) — sesuai permintaan "layar landscape". */
  const goFullscreenLandscape = async () => {
    const el = playerWrapRef.current;
    if (!el) return;
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return;
      }
      await el.requestFullscreen();
      // coba kunci landscape (hanya jalan di fullscreen Android)
      const orientation = screen.orientation as (ScreenOrientation & { lock?: (o: string) => Promise<void> }) | undefined;
      await orientation?.lock?.("landscape").catch(() => {});
    } catch {
      toast({
        title: "Layar penuh tidak dapat dibuka",
        description: "Browser kamu ngeblokir fullscreen — coba tombol fullscreen di pojok player.",
      });
    }
  };

  const switchSub = (lang: string) => {
    setSub(lang);
    setSubMenuOpen(false);
    const label = lang === "off" ? null : SUB_LANGS.find((l) => l.code === lang)?.label || lang;
    // server subMode "file" (VidLink & LK21 VIP): sub benar-benar dikontrol dari sini
    if (activeServer?.subMode === "file") {
      toast({
        title: lang === "off" ? "Subtitle dimatikan" : `Subtitle ${label} aktif`,
        description:
          lang === "off"
            ? "Server ini mengikuti pengaturan dari sini — subtitle langsung nonaktif."
            : lang !== "id" && lang !== "en" && aiSub
              ? "Subtitle bahasa ini diterjemahkan/cari otomatis bila belum tersedia di sumber (CC AI)."
              : "Subtitle langsung terpasang di pemutar — cadangan AI aktif bila sub sumber tidak ditemukan.",
      });
    } else {
      toast({
        title: lang === "off" ? "Subtitle dimatikan" : `Subtitle ${label}`,
        description:
          lang === "off"
            ? undefined
            : `Server ${activeServer?.name || "ini"} mengatur subtitle melalui menu CC/pengaturan di dalam pemutar (cari bahasa ${label}). Ingin subtitle yang dikontrol dari sini? Pilih server VidLink atau LK21 Premium VIP.`,
      });
    }
    loadServers(lang);
  };

  return (
    <div>
      <Button variant="ghost" onClick={onBack} className="mb-3 rounded-xl px-3"><ArrowLeft className="mr-1 h-4 w-4" /> Kembali</Button>

      {/* area player */}
      <div ref={playerWrapRef} className="relative overflow-hidden rounded-2xl bg-black shadow-2xl">
        <div className="aspect-video w-full">
          {activeServer ? (
            <iframe
              key={`${activeServer.id}-${iframeKey}-${sub}`}
              src={activeServer.url}
              title="Fanzz Player"
              className="h-full w-full border-0"
              allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
              allowFullScreen
              referrerPolicy={compatMode ? "unsafe-url" : "no-referrer"}
              sandbox={compatMode ? undefined : PLAYER_SANDBOX}
              onLoad={() => setPlayerState("ready")}
            />
          ) : (
            <div className="flex h-full items-center justify-center text-muted-foreground text-sm">Tidak ada server tersedia</div>
          )}
        </div>

        {/* tombol chat sambil nonton */}
        <button
          onClick={() => setChatOpen(!chatOpen)}
          className={`absolute right-2 top-2 z-10 flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-[10px] font-bold backdrop-blur-md transition-all active:scale-90 ${
            chatOpen ? "bg-red-500 text-white" : "bg-black/55 text-white/85 hover:bg-black/75"
          }`}
        >
          <MessageCircle className="h-3.5 w-3.5" />
          {chatOpen ? "Tutup" : "Chat"}
        </button>

        {/* tombol fullscreen landscape */}
        <button
          onClick={goFullscreenLandscape}
          className="absolute left-2 top-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
          title="Layar penuh mode landscape"
        >
          <Smartphone className="h-3.5 w-3.5 -rotate-90" />
          Landscape
        </button>

        {/* overlay loading */}
        <AnimatePresence>
          {playerState === "loading" && (
            <motion.div initial={{ opacity: 1 }} exit={{ opacity: 0 }} className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 backdrop-blur-sm">
              <Loader2 className="h-8 w-8 animate-spin text-red-400" />
              <p className="text-xs text-white/80">Memuat server <span className="font-bold">{activeServer?.name}</span>...</p>
            </motion.div>
          )}
          {playerState === "timeout" && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/85 p-6 text-center backdrop-blur-sm">
              <ShieldAlert className="h-8 w-8 text-amber-400" />
              <p className="text-sm font-bold text-white">Server lambat / macet</p>
              <p className="text-xs text-white/60">Coba muat ulang, ganti server, atau nyalakan mode kompatibel.</p>
              <div className="flex gap-2">
                <Button size="sm" onClick={() => { setIframeKey((k) => k + 1); setPlayerState("loading"); }} className="rounded-xl bg-red-500 hover:bg-red-600">
                  <RefreshCw className="mr-1 h-3.5 w-3.5" /> Muat ulang
                </Button>
              </div>
            </motion.div>
          )}
          {playerState === "error" && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/85 p-6 text-center">
              <ShieldAlert className="h-8 w-8 text-red-400" />
              <p className="text-sm font-bold text-white">Gagal memuat server</p>
              <Button size="sm" variant="secondary" onClick={() => loadServers(sub)} className="rounded-xl">
                <RefreshCw className="mr-1 h-3.5 w-3.5" /> Coba lagi
              </Button>
            </div>
          )}
        </AnimatePresence>
      </div>

      {/* drawer chat sambil nonton */}
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -10, height: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-3 rounded-2xl glass p-3">
              <WatchChat />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* baris kontrol: subtitle (semua bahasa) + compat + buka tab baru */}
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <div className="relative flex items-center gap-1.5 rounded-xl glass px-2.5 py-1.5">
          <Captions className="h-4 w-4 text-red-400" />
          <span className="text-xs font-semibold text-muted-foreground">Sub:</span>
          {(["id", "en", "off"] as const).map((l) => (
            <button
              key={l}
              onClick={() => switchSub(l)}
              className={`rounded-lg px-2 py-1 text-[11px] font-bold transition-colors ${
                sub === l ? "bg-red-500 text-white" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {l === "id" ? "ID" : l === "en" ? "EN" : "OFF"}
            </button>
          ))}
          {/* V0.01: dropdown semua bahasa */}
          <button
            onClick={() => setSubMenuOpen(!subMenuOpen)}
            className={`flex items-center gap-1 rounded-lg px-2 py-1 text-[11px] font-bold transition-colors ${
              !["id", "en", "off"].includes(sub) ? "bg-red-500 text-white" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Languages className="h-3.5 w-3.5" />
            {["id", "en", "off"].includes(sub) ? "Semua" : SUB_LANGS.find((l) => l.code === sub)?.label || sub}
            <ChevronDown className="h-3 w-3" />
          </button>
          {subMenuOpen && (
            <div className="absolute left-0 top-full z-30 mt-1.5 max-h-64 w-48 overflow-y-auto rounded-xl border border-[var(--surface-line)] bg-[var(--surface-sheet)] p-1.5 shadow-2xl">
              {SUB_LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => switchSub(l.code)}
                  className={`flex w-full items-center justify-between rounded-lg px-2.5 py-2 text-[11px] font-bold transition-colors ${
                    sub === l.code ? "bg-red-500/20 text-red-300" : "text-foreground hover:bg-secondary"
                  }`}
                >
                  {l.label}
                  <span className="text-[9px] font-extrabold text-muted-foreground">{l.code.toUpperCase()}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* indikator: server ini sub-nya dikontrol dari sini */}
        {activeServer?.subMode === "file" && sub !== "off" && (
          <span className="flex items-center gap-1 rounded-xl bg-emerald-500/15 px-2.5 py-1.5 text-[10px] font-bold text-emerald-300">
            <CheckCircle2 className="h-3 w-3" /> Sub aktif dari sini
          </span>
        )}

        {/* toggle CC AI — penerjemahan otomatis bila subtitle sumber tidak ada */}
        <button
          onClick={() => {
            const next = !aiSub;
            setAiSub(next);
            toast({
              title: next ? "CC AI aktif" : "CC AI nonaktif",
              description: next
                ? "Apabila subtitle Indonesia tidak tersedia, AI akan menerjemahkan subtitle English menjadi Indonesia secara otomatis."
                : "Subtitle hanya diambil dari sumber resmi tanpa terjemahan AI.",
            });
            loadServers(sub);
          }}
          className={`flex items-center gap-1.5 rounded-xl px-2.5 py-1.5 text-[11px] font-bold transition-colors ${
            aiSub
              ? "bg-gradient-to-r from-cyan-500 to-red-500 text-white shadow-lg shadow-cyan-500/25"
              : "glass text-muted-foreground hover:text-foreground"
          }`}
          title="Terjemahan subtitle otomatis oleh AI"
        >
          <Sparkles className="h-4 w-4" /> CC AI
        </button>

        <div className="flex items-center gap-2 rounded-xl glass px-3 py-1.5">
          <ShieldAlert className={`h-4 w-4 ${compatMode ? "text-amber-400" : "text-emerald-400"}`} />
          <span className="text-[11px] font-semibold text-muted-foreground">Anti-iklan</span>
          <Switch checked={!compatMode} onCheckedChange={(v) => setCompatMode(!v)} className="scale-90" />
        </div>

        {activeServer && (
          <a
            href={activeServer.url}
            target="_blank"
            rel="noopener noreferrer nofollow"
            className="flex items-center gap-1.5 rounded-xl glass px-3 py-2 text-[11px] font-semibold text-muted-foreground transition-colors hover:text-foreground"
          >
            <ExternalLink className="h-3.5 w-3.5" /> Buka di tab baru
          </a>
        )}
      </div>

      {/* pilih server */}
      <section className="mt-4">
        <h3 className="mb-2.5 flex items-center gap-2 text-sm font-bold">
          <Server className="h-4 w-4 text-red-400" /> Pilih Server ({servers.length})
        </h3>
        {loadingServers ? (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => <div key={i} className="h-11 rounded-xl shimmer" />)}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {servers.map((s) => (
              <button
                key={s.id}
                onClick={() => applyServer(s)}
                className={`relative rounded-xl px-3 py-2.5 text-left text-xs font-bold transition-all ${
                  activeServer?.id === s.id
                    ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-lg shadow-red-500/20"
                    : "glass text-foreground hover:scale-[1.02]"
                }`}
              >
                <span className="flex items-center justify-between gap-1">
                  <span className="truncate">{s.name}</span>
                  {s.subMode === "file" && (
                    <span className={`shrink-0 rounded-full px-1.5 py-px text-[8px] font-extrabold ${activeServer?.id === s.id ? "bg-white/20" : "bg-emerald-500/20 text-emerald-300"}`}>
                      SUB
                    </span>
                  )}
                  {s.source === "moviezone" && <span className="shrink-0 rounded-full bg-cyan-500/25 px-1.5 py-px text-[8px] font-extrabold text-cyan-300">MZ</span>}
                  {s.source === "lk21" && <span className="shrink-0 rounded-full bg-rose-500/25 px-1.5 py-px text-[8px] font-extrabold text-rose-300">LK21</span>}
                </span>
                <span className={`mt-0.5 block truncate text-[10px] font-medium ${activeServer?.id === s.id ? "text-white/70" : "text-muted-foreground"}`}>
                  {s.note || (s.source === "moviezone" ? "Sumber utama — MovieZone" : s.source === "lk21" ? "LK21 Stream Premium" : s.compat ? "Butuh mode kompatibel" : "Sandbox ketat (anti-iklan)")}
                </span>
              </button>
            ))}
          </div>
        )}
        {compatMode && (
          <p className="mt-2 rounded-xl bg-amber-500/10 px-3 py-2 text-[11px] leading-relaxed text-amber-300/90">
            Mode kompatibel aktif buat server ini (biar player jalan). Proteksi popup iklan dimatikan sementara — kalau muncul iklan, balik ke server lain atau matikan mode kompatibel.
          </p>
        )}
      </section>
    </div>
  );
}

/* ================= SECTION DOWNLOAD HDHUB ================= */

interface HdhubItem {
  title: string;
  url: string;
  year?: string;
  poster?: string;
  type?: string;
}

function HdhubDownloadSection({ title }: { title: string }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<HdhubItem[] | null>(null);
  const [error, setError] = useState("");

  const search = async () => {
    if (busy) return;
    setBusy(true);
    setError("");
    setResults(null);
    try {
      const res = await fetch(`/api/movies/hdhub?q=${encodeURIComponent(title)}`);
      const d = await res.json();
      if (!d?.ok || !d.results?.length) {
        throw new Error(d?.error || "Tidak ketemu link download untuk judul ini");
      }
      setResults(d.results);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal cari link");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mt-3 overflow-hidden rounded-2xl glass">
      <button
        onClick={() => {
          setOpen(!open);
          if (!open && !results && !busy) search();
        }}
        className="flex w-full items-center gap-2.5 px-4 py-3.5 text-left"
      >
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
          <FolderDown className="h-4 w-4" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-extrabold">Download Film (HDhub)</p>
          <p className="text-[10px] text-muted-foreground">Cari link unduh kualitas tinggi dari HDhub</p>
        </div>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="border-t border-[var(--surface-line)] p-3.5">
          {busy && (
            <div className="flex items-center gap-2 py-2 text-xs text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin text-emerald-400" /> Nyari link download…
            </div>
          )}
          {error && (
            <p className="rounded-xl bg-amber-500/10 px-3 py-2.5 text-[11px] leading-relaxed text-amber-300">
              {error}
            </p>
          )}
          {results && (
            <div className="space-y-2">
              {results.slice(0, 8).map((r, i) => (
                <a
                  key={i}
                  href={r.url}
                  target="_blank"
                  rel="noopener noreferrer nofollow"
                  className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5 transition-colors hover:bg-secondary"
                >
                  <Download className="h-4 w-4 shrink-0 text-emerald-400" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold">{r.title}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {r.type === "series" ? "Series" : "Film"}{r.year ? ` • ${r.year}` : ""} • via HDhub
                    </p>
                  </div>
                  <ExternalLink className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                </a>
              ))}
              <p className="text-[9.5px] text-muted-foreground">
                Link membuka halaman unduhan HDhub — pilih kualitas & host di sana. Selalu cek file yang kamu unduh ya.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
