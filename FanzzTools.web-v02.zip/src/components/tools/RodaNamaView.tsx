"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import {
  Dices, Play, Pause, Plus, Trash2, Shuffle, Trophy, RotateCcw, Users, Crown, Sparkles, Copy, Check,
} from "lucide-react";

/**
 * Roda Nama (zuperupdt — tools tambahan sesuai permintaan pemilik).
 *  - 56 NAMA bawaan (siap pakai)
 *  - EDIT daftar (tambah / hapus / reset)
 *  - ACAK urutan (shuffle Fisher-Yates)
 *  - MULTI-PEMENANG: pilih 1–10 pemenang sekaligus
 *  - RANKING: pemenang diberi peringkat 1, 2, 3… + daftar juara tersimpan
 *  - ANIMASI WARNAY: roda berputar dengan sektor pelangi + konfeti saat juara
 *    ditentukan + highlight berdenyut pada pemenang.
 */

const NAMA_BAWAAN = [
  "Aisyah", "Budi", "Citra", "Dimas", "Eka", "Fajar", "Gita", "Hendra", "Indah", "Joko",
  "Kirana", "Lukman", "Maya", "Nanda", "Oka", "Putri", "Qori", "Rizky", "Sari", "Taufik",
  "Umar", "Vina", "Wawan", "Xena", "Yoga", "Zahra", "Aldi", "Bella", "Candra", "Dewi",
  "Eko", "Farhan", "Gina", "Hafiz", "Ika", "Jefri", "Kiki", "Laila", "Miko", "Nia",
  "Okta", "Panji", "Queena", "Rani", "Sultan", "Tia", "Uzi", "Vero", "Wulan", "Yanti",
  "Zaki", "Abimanyu", "Bunga", "Cakrawala", "Damar", "Elang",
]; // 56 nama

const WARMA_SEKTOR = [
  "#f43f5e", "#f97316", "#f59e0b", "#84cc16", "#22c55e", "#14b8a6",
  "#06b6d4", "#3b82f6", "#6366f1", "#ef4444", "#ef4444", "#ec4899",
];

interface Pemenang {
  nama: string;
  peringkat: number;
  warna: string;
}

function acakFisherYates<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export default function RodaNamaView() {
  const [daftar, setDaftar] = useState<string[]>(NAMA_BAWAAN);
  const [inputNama, setInputNama] = useState("");
  const [jumlahPemenang, setJumlahPemenang] = useState(1);
  const [berputar, setBerputar] = useState(false);
  const [sudut, setSudut] = useState(0);
  const [pemenang, setPemenang] = useState<Pemenang[]>([]);
  const [riwayat, setRiwayat] = useState<Pemenang[]>([]);
  const [konfeti, setKonfeti] = useState(0);
  const [salinRiwayat, setSalinRiwayat] = useState(false);
  const kecepatanRef = useRef<number | null>(null);
  const rafRef = useRef<number>(0);
  const targetRef = useRef<number | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    pushHistory("roda", { id: "roda-nama", title: "Roda Nama", subtitle: `${NAMA_BAWAAN.length} nama • multi-pemenang • ranking` });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ============ geometri roda ============ */
  const ukuran = 340;
  const cx = ukuran / 2;
  const cy = ukuran / 2;
  const r = ukuran / 2 - 6;
  const n = Math.max(2, daftar.length);
  const sektor = (Math.PI * 2) / n;
  /** radius tempat label nama ditempatkan (harus selalu sama dengan posTeks) */
  const rr = r * 0.62;
  /** chord-width sektor pada radius label — batas aman agar teks tidak meluber ke sektor tetangga */
  const chordLabel = 2 * rr * Math.sin(Math.PI / n) * 0.85;
  /** ukuran font KONTINU berbasis jumlah sektor (dulu: 3 tingkat diskrit → overlap di rentang tengah) */
  const fontSize = Math.max(7, Math.min(13, 130 / n));

  /** posisi tengah teks tiap sektor (index → derajat) */
  const posTeks = useCallback((i: number) => {
    const a0 = sudut + i * (360 / n);
    const aRad = ((a0 + 360 / n / 2 - 90) * Math.PI) / 180;
    const rr = r * 0.62;
    return { x: cx + rr * Math.cos(aRad), y: cy + rr * Math.sin(aRad), rot: a0 + 360 / n / 2 };
  }, [sudut, n, r]);

  /* ============ animasi putar ============ */
  const mulaiPutar = () => {
    if (daftar.length < 2) {
      toast({ title: "Minimal 2 nama", description: "Tambahkan nama dulu sebelum memutar roda." });
      return;
    }
    if (jumlahPemenang > daftar.length) {
      toast({ title: "Pemenang melebihi jumlah nama", description: `Hanya ada ${daftar.length} nama — kurangi jumlah pemenang.` });
      return;
    }
    setBerputar(true);
    setPemenang([]);
    // percepat → melambat (easing manual lewat rAF)
    let v = 14 + Math.random() * 8; // derajat per frame awal
    const pilih = acakFisherYates(daftar).slice(0, jumlahPemenang); // pemenang ditentukan adil di awal
    const putaranEkstra = 6 + Math.random() * 4;
    const totalTarget = sudut + 360 * putaranEkstra + Math.random() * 360;
    targetRef.current = totalTarget;
    const mulai = performance.now();
    const durasi = 4200 + Math.random() * 1200;

    const langkah = (t: number) => {
      const p = Math.min(1, (t - mulai) / durasi);
      const ease = 1 - Math.pow(1 - p, 3); // cubic-out: cepat lalu melambat
      const next = sudut + (totalTarget - sudut) * ease;
      setSudut(next);
      if (p < 1) {
        rafRef.current = requestAnimationFrame(langkah);
      } else {
        // berhenti — tentukan pemenang dari posisi jarum (atas)
        selesaiPutar(pilih, totalTarget);
      }
    };
    rafRef.current = requestAnimationFrame(langkah);
    void v; // kecepatan awal hanya penanda
  };

  const selesaiPutar = (pilih: string[], totalSudut: number) => {
    setBerputar(false);
    kecepatanRef.current = null;
    // hitung nama yang ada di sektor jarum (posisi atas = -90°)
    const idx = Math.floor((((-totalSudut % 360) + 360) % 360) / (360 / n)) % n;
    // susun pemenang: sektor jarum = juara 1, sisanya dari hasil acak adil
    const juara1 = daftar[idx];
    const sisa = pilih.filter((p) => p !== juara1);
    const hasil: Pemenang[] = [];
    if (juara1 !== undefined) hasil.push({ nama: juara1, peringkat: 1, warna: WARMA_SEKTOR[idx % WARMA_SEKTOR.length] });
    for (let i = 0; hasil.length < pilih.length && i < sisa.length + daftar.length; i++) {
      const nm = sisa[i] ?? daftar[(idx + 1 + i) % n];
      if (nm !== undefined && !hasil.some((h) => h.nama === nm)) {
        hasil.push({ nama: nm, peringkat: hasil.length + 1, warna: WARMA_SEKTOR[(idx + hasil.length) % WARMA_SEKTOR.length] });
      }
    }
    setPemenang(hasil);
    setRiwayat((prev) => [...hasil, ...prev].slice(0, 50));
    setKonfeti((k) => k + 1);
    toast({
      title: hasil.length > 1 ? `Juara 1: ${hasil[0].nama} 🏆` : `Pemenang: ${hasil[0]?.nama} 🎉`,
      description: hasil.length > 1 ? `Total ${hasil.length} pemenang — lihat ranking di bawah.` : undefined,
    });
  };

  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  /* ============ kelola daftar ============ */
  const tambahNama = () => {
    const nm = inputNama.trim().slice(0, 24);
    if (!nm) return;
    if (daftar.includes(nm)) {
      toast({ title: "Nama sudah ada" });
      return;
    }
    if (daftar.length >= 80) {
      toast({ title: "Maksimal 80 nama", description: "Hapus beberapa nama dulu." });
      return;
    }
    setDaftar((d) => [...d, nm]);
    setInputNama("");
  };
  const hapusNama = (nm: string) => setDaftar((d) => d.filter((x) => x !== nm));
  const acakDaftar = () => {
    setDaftar((d) => acakFisherYates(d));
    toast({ title: "Urutan diacak 🔀", description: "Posisi nama sekarang acak total." });
  };
  const resetDaftar = () => {
    setDaftar(NAMA_BAWAAN);
    setPemenang([]);
    toast({ title: `Kembali ke ${NAMA_BAWAAN.length} nama bawaan` });
  };

  const salinHasil = () => {
    const teks = riwayat.map((r) => `#${r.peringkat} — ${r.nama}`).join("\n");
    navigator.clipboard?.writeText(`🏆 Hasil Roda Nama FanzzTools\n${new Date().toLocaleString("id-ID")}\n\n${teks}`).then(() => {
      setSalinRiwayat(true);
      setTimeout(() => setSalinRiwayat(false), 1600);
      toast({ title: "Hasil tersalin!" });
    }).catch(() => {});
  };

  return (
    <div>
      <ToolHeader icon={<Dices className="h-5.5 w-5.5" />} title="Roda Nama" subtitle={`${daftar.length} nama • acak • multi-pemenang • ranking • animasi warna`} accent="fuchsia" />

      <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
        {/* ===== RODA ===== */}
        <div className="glass rounded-2xl p-4">
          <div className="relative mx-auto w-fit">
            {/* jarum penunjuk */}
            <div className="absolute left-1/2 top-0 z-10 -translate-x-1/2 -translate-y-1">
              <div className="h-0 w-0 border-x-[12px] border-t-[22px] border-x-transparent border-t-red-400 drop-shadow-lg" />
            </div>
            <motion.div
              animate={{ rotate: 0 }}
              style={{ width: ukuran, height: ukuran }}
              className="relative rounded-full shadow-2xl"
            >
              <svg width={ukuran} height={ukuran} viewBox={`0 0 ${ukuran} ${ukuran}`} className="rounded-full">
                <circle cx={cx} cy={cy} r={r + 4} fill="#1a1025" />
                {daftar.map((nm, i) => {
                  const a0 = ((sudut + i * (360 / n)) * Math.PI) / 180;
                  const a1 = ((sudut + (i + 1) * (360 / n)) * Math.PI) / 180;
                  const p0 = `${cx + r * Math.cos(a0 - Math.PI / 2)} ${cy + r * Math.sin(a0 - Math.PI / 2)}`;
                  const p1 = `${cx + r * Math.cos(a1 - Math.PI / 2)} ${cy + r * Math.sin(a1 - Math.PI / 2)}`;
                  const menang = pemenang.some((pm) => pm.nama === nm);
                  return (
                    <path
                      key={`${nm}-${i}`}
                      d={`M ${cx} ${cy} L ${p0} A ${r} ${r} 0 ${n > 2 ? (360 / n > 180 ? 1 : 0) : 1} 1 ${p1} Z`}
                      fill={menang ? WARMA_SEKTOR[i % WARMA_SEKTOR.length] : `${WARMA_SEKTOR[i % WARMA_SEKTOR.length]}${i % 2 ? "cc" : "e6"}`}
                      stroke="rgba(255,255,255,0.18)"
                      strokeWidth="1"
                      opacity={pemenang.length && !menang ? 0.45 : 1}
                    />
                  );
                })}
                {/* teks nama */}
                {daftar.map((nm, i) => {
                  const p = posTeks(i);
                  const teks = nm.slice(0, 12);
                  /** estimasi lebar alami (bold sans ≈ 0.62em/karakter) — teks hanya DIKOMPRES bila melebihi chord sektor, tidak pernah direnggangkan */
                  const lebarAlami = teks.length * fontSize * 0.62;
                  return (
                    <text
                      key={`t-${nm}-${i}`}
                      x={p.x}
                      y={p.y}
                      fill="#ffffff"
                      fontSize={fontSize}
                      fontWeight={pemenang.some((pm) => pm.nama === nm) ? 900 : 700}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      transform={`rotate(${p.rot} ${p.x} ${p.y})`}
                      textLength={Math.min(chordLabel, lebarAlami)}
                      lengthAdjust="spacingAndGlyphs"
                      style={{ pointerEvents: "none" }}
                    >
                      {teks}
                    </text>
                  );
                })}
                <circle cx={cx} cy={cy} r="26" fill="#14101c" stroke="rgba(255,255,255,0.25)" strokeWidth="2" />
              </svg>
              {/* pusat berdenyut saat berputar */}
              <div className={`absolute left-1/2 top-1/2 z-10 flex h-12 w-12 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 shadow-lg ${berputar ? "animate-pulse" : ""}`}>
                <Dices className="h-5 w-5 text-white" />
              </div>
            </motion.div>

            {/* konfeti */}
            <AnimatePresence>
              {konfeti > 0 && (
                <div key={konfeti} className="pointer-events-none absolute inset-0 overflow-visible">
                  {Array.from({ length: 26 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="absolute left-1/2 top-1/2 h-2.5 w-1.5 rounded-sm"
                      style={{ background: WARMA_SEKTOR[i % WARMA_SEKTOR.length] }}
                      initial={{ x: 0, y: 0, opacity: 1, rotate: 0 }}
                      animate={{
                        x: Math.cos((i / 26) * Math.PI * 2) * (110 + (i % 5) * 30),
                        y: Math.sin((i / 26) * Math.PI * 2) * (110 + (i % 4) * 35) - 40,
                        rotate: 360 + i * 20,
                        opacity: 0,
                      }}
                      transition={{ duration: 1.6, ease: "easeOut" }}
                    />
                  ))}
                </div>
              )}
            </AnimatePresence>
          </div>

          {/* kontrol putar */}
          <div className="mt-4 flex flex-col items-center gap-3">
            <div className="flex w-full items-center gap-2">
              <button
                onClick={mulaiPutar}
                disabled={berputar}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-4 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-red-500/25 disabled:opacity-60"
              >
                {berputar ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                {berputar ? "Memutar…" : "PUTAR RODA!"}
              </button>
            </div>
            <div className="flex w-full items-center justify-center gap-2 rounded-xl bg-secondary/50 px-3 py-2.5">
              <Trophy className="h-4 w-4 shrink-0 text-amber-400" />
              <span className="text-[10px] font-black uppercase tracking-wide text-muted-foreground">Jumlah pemenang</span>
              <div className="ml-auto flex items-center gap-1">
                {[1, 2, 3, 5, 10].map((j) => (
                  <button
                    key={j}
                    onClick={() => setJumlahPemenang(j)}
                    className={`h-7 w-8 rounded-lg text-[11px] font-black transition ${
                      jumlahPemenang === j ? "bg-gradient-to-r from-amber-400 to-orange-500 text-white" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {j}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* hasil pemenang + ranking */}
          <AnimatePresence>
            {pemenang.length > 0 && (
              <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-4 rounded-2xl bg-gradient-to-br from-red-500/15 to-red-700/10 p-4">
                <p className="flex items-center gap-1.5 text-sm font-extrabold">
                  <Crown className="h-4 w-4 text-amber-400" /> {pemenang.length > 1 ? "Ranking Pemenang" : "Pemenang"}
                </p>
                <div className="mt-2.5 space-y-1.5">
                  {pemenang.map((pm, i) => (
                    <motion.div
                      key={`${pm.nama}-${i}`}
                      initial={{ opacity: 0, x: -14 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.12 }}
                      className="flex items-center gap-2.5 rounded-xl bg-black/25 px-3 py-2"
                    >
                      <span
                        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[11px] font-black text-white"
                        style={{ background: pm.warna }}
                      >
                        {pm.peringkat}
                      </span>
                      <span className={`text-sm ${pm.peringkat === 1 ? "font-black text-amber-300" : "font-bold"}`}>{pm.nama}</span>
                      {pm.peringkat === 1 && <Crown className="ml-auto h-4 w-4 text-amber-400" />}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* ===== KELOLA DAFTAR ===== */}
        <div className="glass rounded-2xl p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-sm font-extrabold">
              <Users className="h-4 w-4 text-red-400" /> Daftar Nama
            </p>
            <span className="rounded-full bg-secondary px-2 py-0.5 text-[9.5px] font-black text-muted-foreground">{daftar.length} nama</span>
          </div>

          <div className="flex gap-1.5">
            <input
              value={inputNama}
              onChange={(e) => setInputNama(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && tambahNama()}
              placeholder="Tambah nama…"
              maxLength={24}
              className="min-w-0 flex-1 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs outline-none focus:border-red-400/50"
            />
            <button onClick={tambahNama} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-r from-red-500 to-red-700 text-white active:scale-90">
              <Plus className="h-4 w-4" />
            </button>
          </div>

          <div className="mt-2 flex gap-1.5">
            <button onClick={acakDaftar} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-secondary px-2 py-2 text-[10px] font-extrabold text-muted-foreground active:scale-95">
              <Shuffle className="h-3.5 w-3.5" /> Acak Urutan
            </button>
            <button onClick={resetDaftar} className="flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-secondary px-2 py-2 text-[10px] font-extrabold text-muted-foreground active:scale-95">
              <RotateCcw className="h-3.5 w-3.5" /> Reset 56
            </button>
          </div>

          <div className="mt-3 max-h-[320px] space-y-1 overflow-y-auto pr-1">
            {daftar.length === 0 && <EmptyState icon={<Sparkles className="h-6 w-6" />} title="Daftar kosong" desc="Tambah minimal 2 nama untuk memutar roda." />}
            {daftar.map((nm, i) => (
              <div key={`${nm}-${i}`} className="group flex items-center gap-2 rounded-lg bg-secondary/40 px-2.5 py-1.5">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: WARMA_SEKTOR[i % WARMA_SEKTOR.length] }} />
                <span className="min-w-0 flex-1 truncate text-[11px] font-bold">{nm}</span>
                <button onClick={() => hapusNama(nm)} className="shrink-0 rounded-md p-1 text-muted-foreground opacity-0 transition group-hover:opacity-100 active:scale-90 hover:text-red-400" title="Hapus">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* riwayat juara */}
      {riwayat.length > 0 && (
        <div className="glass mt-4 rounded-2xl p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="flex items-center gap-1.5 text-sm font-extrabold">
              <Trophy className="h-4 w-4 text-amber-400" /> Riwayat Juara ({riwayat.length})
            </p>
            <button onClick={salinHasil} className="flex items-center gap-1.5 rounded-xl bg-secondary px-3 py-1.5 text-[10px] font-extrabold text-muted-foreground">
              {salinRiwayat ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />} Salin hasil
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {riwayat.map((r, i) => (
              <span key={i} className="flex items-center gap-1.5 rounded-full bg-secondary/60 px-2.5 py-1 text-[10.5px] font-bold">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: r.warna }} />
                #{r.peringkat} {r.nama}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
