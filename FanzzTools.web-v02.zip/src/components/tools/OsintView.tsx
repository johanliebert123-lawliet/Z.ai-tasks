"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import UsernameCheckView from "@/components/tools/UsernameCheckView";
import { EmailPanel, WaPanel, NikMassPanel } from "@/components/tools/OsintPanelsBaru";
import {
  Fingerprint, Search, Loader2, Globe2, Phone, AtSign, ShieldCheck,
  MapPin, Cake, User2, Hash, Building2, Server, CalendarDays,
  AlertTriangle, CheckCircle2, XCircle, Sparkles, UserSearch, Mail, MessageCircle, ListChecks,
} from "lucide-react";

type Tab = "nik" | "nikmass" | "email" | "wa" | "ip" | "phone" | "domain" | "whois" | "username";

/* ---------- sub-komponen hasil ---------- */

function InfoRow({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: React.ReactNode; accent?: boolean }) {
  return (
    <div className="flex items-center gap-3 rounded-xl bg-secondary/50 px-3.5 py-2.5">
      <span className="shrink-0 text-muted-foreground">{icon}</span>
      <span className="w-24 shrink-0 text-[10.5px] font-semibold text-muted-foreground">{label}</span>
      <span className={`min-w-0 flex-1 truncate text-right text-xs font-bold ${accent ? "text-blue-300" : ""}`}>{value}</span>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <p className="mb-1.5 mt-3 flex items-center gap-1.5 text-[11px] font-extrabold text-blue-300">{children}</p>;
}

/* ---------- NIK ---------- */

interface NikResult {
  valid: boolean;
  errors: string[];
  wilayah: { provinsi: string; kabupatenKota: string; kecamatan: string };
  pribadi: { jenisKelamin: string; tanggalLahir: string; umur: string; zodiak: string; ulangTahunBerikutnya: string };
  nomorUrut: string;
}

function NikPanel() {
  const [nik, setNik] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<NikResult | null>(null);

  const go = async () => {
    const n = nik.replace(/\D/g, "");
    if (n.length !== 16 || busy) return;
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch(`/api/osint/nik?nik=${n}`);
      const d = await res.json();
      if (d?.ok) setResult(d.result);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="glass rounded-3xl p-5">
        <div className="relative">
          <Fingerprint className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
          <Input
            value={nik}
            onChange={(e) => { setNik(e.target.value.replace(/[^\d]/g, "").slice(0, 16)); setResult(null); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            inputMode="numeric"
            placeholder="16 digit NIK (contoh: 3174010101900002)"
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 font-mono text-sm tracking-wider"
          />
        </div>
        <div className="mt-2 flex items-center justify-between text-[10px] text-muted-foreground">
          <span>{nik.length}/16 digit</span>
          {nik.length === 16 && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />}
        </div>
        <Button
          onClick={go}
          disabled={busy || nik.length !== 16}
          className="mt-3 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-blue-600/25"
        >
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Sparkles className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Membedah angka NIK..." : "Cek NIK Real-Time"}
        </Button>
      </div>

      {result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-4">
          {result.errors.length > 0 && (
            <div className="mb-3 rounded-2xl bg-amber-500/10 p-3 text-[11px] leading-relaxed text-amber-300">
              <p className="mb-1 flex items-center gap-1.5 font-bold"><AlertTriangle className="h-3.5 w-3.5" /> Catatan validitas:</p>
              {result.errors.map((e, i) => <p key={i}>• {e}</p>)}
            </div>
          )}

          <div className="mb-3 flex items-center gap-2.5">
            <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${result.valid ? "bg-emerald-500/15 text-emerald-400" : "bg-amber-500/15 text-amber-400"}`}>
              {result.valid ? <CheckCircle2 className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
            </span>
            <div>
              <p className="text-sm font-extrabold">{result.valid ? "NIK valid ✅" : "Sebagian data terbaca"}</p>
              <p className="font-mono text-[10px] text-muted-foreground">{nik}</p>
            </div>
          </div>

          <SectionTitle><Building2 className="h-3.5 w-3.5" /> Data Wilayah</SectionTitle>
          <div className="space-y-1.5">
            <InfoRow icon={<MapPin className="h-3.5 w-3.5" />} label="Provinsi" value={result.wilayah.provinsi} accent />
            <InfoRow icon={<Building2 className="h-3.5 w-3.5" />} label="Kab/Kota" value={result.wilayah.kabupatenKota} accent />
            <InfoRow icon={<MapPin className="h-3.5 w-3.5" />} label="Kecamatan" value={result.wilayah.kecamatan} accent />
          </div>

          <SectionTitle><User2 className="h-3.5 w-3.5" /> Data Lahir (dari struktur angka)</SectionTitle>
          <div className="space-y-1.5">
            <InfoRow icon={<User2 className="h-3.5 w-3.5" />} label="Jenis kelamin" value={result.pribadi.jenisKelamin} accent />
            <InfoRow icon={<Cake className="h-3.5 w-3.5" />} label="Tgl lahir" value={result.pribadi.tanggalLahir || "-"} accent />
            <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Umur" value={result.pribadi.umur || "-"} accent />
            <InfoRow icon={<Sparkles className="h-3.5 w-3.5" />} label="Zodiak" value={result.pribadi.zodiak || "-"} accent />
            <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Ulang tahun" value={result.pribadi.ulangTahunBerikutnya || "-"} accent />
            <InfoRow icon={<Hash className="h-3.5 w-3.5" />} label="Nomor urut" value={result.nomorUrut} accent />
          </div>

          <p className="mt-3 text-[9.5px] leading-relaxed text-muted-foreground">
            Alat ini membaca struktur angka NIK (kode wilayah + tanggal lahir + urut) persis seperti kartu — kecocokan nama & data pribadi pemiliknya hanya bisa lewat Dukcapil.
          </p>
        </motion.div>
      )}
    </div>
  );
}

/* ---------- IP ---------- */

interface IpResult {
  ip: string; negara: string; bendera: string; provinsi: string; kota: string; kodepos?: string;
  koordinat: number[]; timezone?: string; asn?: number; org?: string; isp?: string;
}

function IpPanel() {
  const [ip, setIp] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<IpResult | null>(null);
  const [error, setError] = useState("");

  const go = async (target?: string) => {
    if (busy) return;
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const t = target ?? ip.trim();
      const res = await fetch(`/api/osint/ip${t ? `?ip=${encodeURIComponent(t)}` : ""}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal lookup");
      setResult(d.result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal lookup");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="glass rounded-3xl p-5">
        <div className="relative">
          <Globe2 className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
          <Input
            value={ip}
            onChange={(e) => { setIp(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            placeholder="Kosongkan = IP kamu sendiri, atau isi IP tertentu"
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 text-sm"
          />
        </div>
        <Button onClick={() => go()} disabled={busy} className="mt-3 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-blue-600/25">
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Search className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Melacak..." : " Lacak IP"}
        </Button>
      </div>

      {error && <p className="rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300">⚠️ {error}</p>}

      {result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass space-y-1.5 rounded-3xl p-4">
          <div className="mb-2 flex items-center gap-2.5">
            <span className="text-2xl">{result.bendera}</span>
            <div>
              <p className="font-mono text-sm font-extrabold">{result.ip}</p>
              <p className="text-[10px] text-muted-foreground">Hasil lacak real-time via ipwho.is</p>
            </div>
          </div>
          <InfoRow icon={<MapPin className="h-3.5 w-3.5" />} label="Negara" value={result.negara} accent />
          <InfoRow icon={<MapPin className="h-3.5 w-3.5" />} label="Provinsi" value={result.provinsi || "-"} accent />
          <InfoRow icon={<Building2 className="h-3.5 w-3.5" />} label="Kota" value={result.kota || "-"} accent />
          <InfoRow icon={<Hash className="h-3.5 w-3.5" />} label="Kode pos" value={result.kodepos || "-"} accent />
          <InfoRow icon={<MapPin className="h-3.5 w-3.5" />} label="Koordinat" value={result.koordinat ? `${result.koordinat[0]}, ${result.koordinat[1]}` : "-"} accent />
          <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Timezone" value={result.timezone || "-"} accent />
          <InfoRow icon={<Server className="h-3.5 w-3.5" />} label="ASN / ISP" value={result.isp || result.org || "-"} accent />
        </motion.div>
      )}
    </div>
  );
}

/* ---------- Nomor HP ---------- */

interface PhoneResult {
  nomor: string; prefix?: string; operator: string; brand: string; jenis: string; warna?: string; catatan: string;
}

function PhonePanel() {
  const [num, setNum] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<PhoneResult | null>(null);
  const [error, setError] = useState("");

  const go = async () => {
    if (busy || !num.trim()) return;
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch(`/api/osint/phone?number=${encodeURIComponent(num.trim())}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal cek nomor");
      setResult(d.result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal cek");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="glass rounded-3xl p-5">
        <div className="relative">
          <Phone className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
          <Input
            value={num}
            onChange={(e) => { setNum(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            inputMode="tel"
            placeholder="08xxxxxxxxxx atau +62..."
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 text-sm"
          />
        </div>
        <Button onClick={go} disabled={busy || !num.trim()} className="mt-3 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-blue-600/25">
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Search className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Mengecek..." : "Cek Nomor"}
        </Button>
      </div>

      {error && <p className="rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300">⚠️ {error}</p>}

      {result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass space-y-1.5 rounded-3xl p-4">
          <div className="mb-2 flex items-center gap-2.5">
            <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${result.operator === "Tidak dikenal" ? "bg-amber-500/15 text-amber-400" : "bg-blue-600/15 text-blue-500"}`}>
              {result.operator === "Tidak dikenal" ? <XCircle className="h-5 w-5" /> : <Phone className="h-5 w-5" />}
            </span>
            <div>
              <p className="font-mono text-sm font-extrabold">{result.nomor}</p>
              <p className="text-[10px] text-muted-foreground">{result.prefix || "Prefix lokal"}</p>
            </div>
          </div>
          <InfoRow icon={<Phone className="h-3.5 w-3.5" />} label="Operator" value={result.operator} accent />
          <InfoRow icon={<Sparkles className="h-3.5 w-3.5" />} label="Merek kartu" value={result.brand} accent />
          <InfoRow icon={<User2 className="h-3.5 w-3.5" />} label="Jenis" value={result.jenis} accent />
          <InfoRow icon={<Server className="h-3.5 w-3.5" />} label="Catatan" value={result.catatan} accent />
          <p className="mt-2 text-[9.5px] text-muted-foreground">Pengecekan 100% lokal dari prefix nomor — nomor kamu tidak dikirim ke mana pun.</p>
        </motion.div>
      )}
    </div>
  );
}

/* ---------- Domain ---------- */

interface DomainResult {
  domain: string; registrar: string; pemilik: string; status: string[];
  didaftarkan: string; diubah: string; kedaluwarsa: string; nameservers: string[];
}

function DomainPanel() {
  const [dom, setDom] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<DomainResult | null>(null);
  const [error, setError] = useState("");

  const go = async () => {
    if (busy || !dom.trim()) return;
    setBusy(true);
    setError("");
    setResult(null);
    try {
      const res = await fetch(`/api/osint/domain?d=${encodeURIComponent(dom.trim())}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Gagal lookup domain");
      setResult(d.result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal lookup");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="glass rounded-3xl p-5">
        <div className="relative">
          <AtSign className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
          <Input
            value={dom}
            onChange={(e) => { setDom(e.target.value); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            placeholder="contoh.com"
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 text-sm"
          />
        </div>
        <Button onClick={go} disabled={busy || !dom.trim()} className="mt-3 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-blue-600/25">
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Search className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Menginterogasi..." : "Cek Domain"}
        </Button>
      </div>

      {error && <p className="rounded-xl bg-red-500/10 px-4 py-3 text-xs text-red-300">⚠️ {error}</p>}

      {result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass space-y-1.5 rounded-3xl p-4">
          <div className="mb-2">
            <p className="text-sm font-extrabold">{result.domain}</p>
            <p className="text-[10px] text-muted-foreground">via RDAP — data resmi registry internet</p>
          </div>
          <InfoRow icon={<Building2 className="h-3.5 w-3.5" />} label="Registrar" value={result.registrar} accent />
          <InfoRow icon={<User2 className="h-3.5 w-3.5" />} label="Pemilik" value={result.pemilik} accent />
          <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Terdaftar" value={result.didaftarkan} accent />
          <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Diubah" value={result.diubah} accent />
          <InfoRow icon={<CalendarDays className="h-3.5 w-3.5" />} label="Kedaluwarsa" value={result.kedaluwarsa} accent />
          <InfoRow icon={<Server className="h-3.5 w-3.5" />} label="Nameserver" value={result.nameservers.slice(0, 2).join(", ") || "-"} accent />
          {result.status.length > 0 && (
            <div className="flex flex-wrap gap-1.5 pt-1">
              {result.status.map((s, i) => (
                <span key={i} className="rounded-full bg-secondary/70 px-2 py-0.5 text-[9px] font-bold text-muted-foreground">{s}</span>
              ))}
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}

/* ---------- WHOIS (port 43) ---------- */

function WhoisPanel() {
  const [domain, setDomain] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ domain: string; raw: string; referred: string | null } | null>(null);
  const [error, setError] = useState("");

  const go = async () => {
    const d = domain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/$/, "");
    if (!d || busy) return;
    setBusy(true);
    setResult(null);
    setError("");
    try {
      const res = await fetch(`/api/osint/whois?d=${encodeURIComponent(d)}`);
      const j = await res.json();
      if (!res.ok || !j?.ok) throw new Error(j?.error || "Lookup gagal");
      setResult({ domain: j.domain, raw: j.raw, referred: j.referred });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Lookup gagal");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-3">
      <div className="glass rounded-3xl p-5">
        <div className="relative">
          <Server className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-500" />
          <Input
            value={domain}
            onChange={(e) => { setDomain(e.target.value); setResult(null); setError(""); }}
            onKeyDown={(e) => e.key === "Enter" && go()}
            placeholder="domain (contoh: google.com)"
            className="rounded-xl border-border/60 bg-secondary/50 py-5 pl-10 pr-3 text-sm"
          />
        </div>
        <Button
          onClick={go}
          disabled={busy || !domain.trim()}
          className="mt-3 w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-600 py-4 text-sm font-bold shadow-lg shadow-blue-600/25"
        >
          {busy ? <Loader2 className="mr-2 h-4.5 w-4.5 animate-spin" /> : <Search className="mr-2 h-4.5 w-4.5" />}
          {busy ? "Nanya ke server WHOIS..." : "WHOIS Lookup (port 43)"}
        </Button>
        <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">
          WHOIS klasik — data mentah registrar (registrar, tanggal daftar/expired, nameserver, kontak teknis). Komplemen dari tab Cek Domain (RDAP).
        </p>
      </div>

      {error && (
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="rounded-xl bg-red-500/10 px-4 py-3 text-xs font-medium text-red-300">
          ⚠️ {error}
        </motion.p>
      )}

      {result && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-3xl p-4">
          <div className="mb-3 flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-blue-600/15 text-blue-500">
              <Server className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-extrabold">{result.domain}</p>
              {result.referred && <p className="text-[10px] text-muted-foreground">via referral: {result.referred}</p>}
            </div>
          </div>
          <pre className="max-h-[46vh] overflow-auto rounded-2xl bg-[var(--code-block-bg)] p-3.5 font-mono text-[10.5px] leading-relaxed text-blue-200/90">{result.raw}</pre>
        </motion.div>
      )}
    </div>
  );
}

/* ---------- main ---------- */

const TABS: Array<{ id: Tab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: "nik", label: "Cek NIK", icon: Fingerprint },
  // V2.11 (#16): validasi NIK massal (versi legal)
  { id: "nikmass", label: "NIK Massal", icon: ListChecks },
  // V2.11 (#25): email checker
  { id: "email", label: "Email Checker", icon: Mail },
  // V2.11 (#27/#28): info nomor WA + composer unban
  { id: "wa", label: "WA Info", icon: MessageCircle },
  { id: "ip", label: "Lacak IP", icon: Globe2 },
  { id: "phone", label: "Cek Nomor", icon: Phone },
  { id: "domain", label: "Cek Domain", icon: AtSign },
  { id: "whois", label: "WHOIS", icon: Server },
  // V2-new (#7): cek username pindah ke tools OSINT
  { id: "username", label: "Cek Username", icon: UserSearch },
];

export default function OsintView() {
  const [tab, setTab] = useState<Tab>("nik");

  return (
    <div>
      <ToolHeader
        icon={<Fingerprint className="h-5.5 w-5.5" />}
        title="OSINT Toolkit"
        subtitle="Cek NIK (single & massal) • email • nomor WA • IP • domain • WHOIS • username"
        accent="indigo"
      />

      {/* tabs */}
      <div className="mb-4 flex gap-1.5 overflow-x-auto no-scrollbar">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "bg-secondary/60 text-muted-foreground"
            }`}
          >
            {tab === t.id && (
              <motion.span
                layoutId="osint-tab"
                className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-600 to-blue-600"
                transition={{ type: "spring", stiffness: 350, damping: 30 }}
              />
            )}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={tab} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
          {tab === "nik" && <NikPanel />}
          {tab === "nikmass" && <NikMassPanel />}
          {tab === "email" && <EmailPanel />}
          {tab === "wa" && <WaPanel />}
          {tab === "ip" && <IpPanel />}
          {tab === "phone" && <PhonePanel />}
          {tab === "domain" && <DomainPanel />}
          {tab === "whois" && <WhoisPanel />}
          {/* V2-new (#7): panel cek username — komponen penuh UsernameCheckView */}
          {tab === "username" && <UsernameCheckView />}
        </motion.div>
      </AnimatePresence>

      <div className="mt-4 flex items-start gap-2.5 rounded-2xl glass p-4 text-[10.5px] leading-relaxed text-muted-foreground">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-blue-500" />
        <p>
          Semua pengecekan diproses real-time: NIK dibaca struktur angkanya langsung di server (nama pemilik hanya bisa dicek Dukcapil),
          IP via ipwho.is, nomor HP dari prefix lokal, domain via RDAP resmi, WHOIS via port 43 klasik. Gunakan dengan bijak sesuai hukum yang berlaku.
        </p>
      </div>
    </div>
  );
}
