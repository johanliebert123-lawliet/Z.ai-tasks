"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ToolHeader, CardSkeleton, EmptyState } from "@/components/tools/shared";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import NativePlayer from "@/components/NativePlayer";
import {
  Tv, Search, Loader2, ArrowLeft, Play, RefreshCw, CalendarDays,
  CheckCircle2, Clock3, ChevronRight, Server, Captions, MonitorPlay, MessageCircle, Maximize, Download,
} from "lucide-react";
import { useApp } from "@/lib/app-store";
import WatchChat from "@/components/chat/WatchChat";

interface AnimeCard {
  title: string;
  animeId?: string;
  thumbnail?: string;
  episode?: string;
  day?: string;
  date?: string;
  status?: string;
  score?: string;
  href?: string;
  otakudesuUrl?: string;
}

interface Episode {
  title: string;
  link: string;
  date?: string;
}

interface StreamLink {
  name: string;
  embed: string;
}

interface StreamRes {
  resolution: string;
  links: StreamLink[];
}

type Tab = "ongoing" | "schedule" | "completed" | "search";
const DAYS = ["Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu"];

const PLAYER_SANDBOX = "allow-scripts allow-same-origin allow-presentation allow-orientation-lock";

export default function AnimeView() {
  const [tab, setTab] = useState<Tab>("ongoing");
  const [ongoing, setOngoing] = useState<AnimeCard[] | null>(null);
  const [schedule, setSchedule] = useState<Record<string, AnimeCard[]> | null>(null);
  const [dayPick, setDayPick] = useState(() => DAYS[(new Date().getDay() + 6) % 7]);
  const [completed, setCompleted] = useState<AnimeCard[] | null>(null);
  const [completedPage, setCompletedPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [query, setQuery] = useState("");
  const [searchRes, setSearchRes] = useState<AnimeCard[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [detail, setDetail] = useState<{
    animeId: string;
    title: string;
    thumbnail?: string;
    synopsis?: string;
    info?: Record<string, string>;
    genres?: Array<{ title: string }>;
    episodes: Episode[];
  } | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [watch, setWatch] = useState<{ title: string; streams: StreamRes[]; embedUrl?: string; episodeUrl?: string; downloads?: Array<{ resolution: string; links: Array<{ name: string; link: string }> }> } | null>(null);
  const [activeStream, setActiveStream] = useState<{ res: StreamRes; link: StreamLink } | null>(null);
  /** V2-new: stream native hasil resolve mirror (m3u8/mp4 lewat proxy) */
  const [nativeSrc, setNativeSrc] = useState<string | null>(null);
  const [resolving, setResolving] = useState(false);
  const [watchLoading, setWatchLoading] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const playerWrapRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const { user } = useApp();

  /** Layar penuh + kunci orientasi landscape (Android/Chrome). */
  const goFullscreenLandscape = async () => {
    const el = playerWrapRef.current;
    if (!el) return;
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return;
      }
      await el.requestFullscreen();
      const orientation = screen.orientation as (ScreenOrientation & { lock?: (o: string) => Promise<void> }) | undefined;
      await orientation?.lock?.("landscape").catch(() => {});
    } catch {
      toast({
        title: "Layar penuh tidak dapat dibuka",
        description: "Browser memblokir layar penuh — silakan gunakan tombol layar penuh di dalam pemutar.",
      });
    }
  };

  /* ---------- data loading ---------- */
  const loadOngoing = useCallback(async () => {
    setOngoing(null);
    try {
      const r = await fetch("/api/anime?home=1");
      const d = await r.json();
      setOngoing(d?.ok ? (d.data?.ongoing?.animeList || []) : []);
    } catch {
      setOngoing([]);
    }
  }, []);

  const loadSchedule = useCallback(async () => {
    setSchedule(null);
    try {
      const r = await fetch("/api/anime?schedule=1");
      const d = await r.json();
      setSchedule(d?.ok ? d.data : {});
    } catch {
      setSchedule({});
    }
  }, []);

  const loadCompleted = useCallback(async (page: number) => {
    setCompleted(null);
    try {
      const r = await fetch(`/api/anime?completed=1&page=${page}`);
      const d = await r.json();
      setCompleted(d?.ok ? (d.data?.animeList || []) : []);
      setTotalPages(d?.ok ? Number(d.data?.totalPages) || 1 : 1);
    } catch {
      setCompleted([]);
    }
  }, []);

  const doSearch = useCallback((q: string) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    if (!q.trim()) {
      setSearchRes(null);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await fetch(`/api/anime?q=${encodeURIComponent(q.trim())}`);
        const d = await r.json();
        setSearchRes(d?.ok ? (d.data?.animeList || []) : []);
      } catch {
        setSearchRes([]);
      } finally {
        setSearching(false);
      }
    }, 450);
  }, []);

  useEffect(() => {
    if (tab === "ongoing" && ongoing === null) loadOngoing();
    if (tab === "schedule" && schedule === null) loadSchedule();
    if (tab === "completed" && completed === null) loadCompleted(1);
  }, [tab, ongoing, schedule, completed, loadOngoing, loadSchedule, loadCompleted]);

  /* ---------- detail & watch ---------- */
  const openDetail = async (animeId: string) => {
    // V2-new: kartu hasil Jikan (MyAnimeList) — cari versi sub indo otomatis
    if (animeId.startsWith("jikan:")) {
      const rawTitle = animeId.slice(animeId.indexOf(":", 6) + 1);
      let jikanTitle = rawTitle;
      try {
        jikanTitle = decodeURIComponent(rawTitle);
      } catch {
        /* biarkan teks mentah */
      }
      setSearching(true);
      setSearchRes(null);
      try {
        const r = await fetch(`/api/anime?q=${encodeURIComponent(jikanTitle)}`);
        const d = await r.json();
        const list = d?.ok ? (d.data?.animeList || []) : [];
        if (list.length && !list[0].fromJikan) {
          toast({ title: "Versi sub indo ditemukan", description: `${jikanTitle} — membuka halaman anime…` });
          setSearching(false);
          openDetail(String(list[0].animeId || ""));
          return;
        }
        toast({
          title: "Belum ada versi sub indo di sumber utama",
          description: `${jikanTitle} terdata di MyAnimeList, tetapi sumber sub indo belum memilikinya. Coba judul atau ejaan lain.`,
        });
      } catch {
        toast({ title: "Gagal mencari versi sub indo", description: "Koneksi bermasalah." });
      } finally {
        setSearching(false);
      }
      return;
    }
    setDetailLoading(true);
    setDetail(null);
    setWatch(null);
    try {
      const r = await fetch(`/api/anime?id=${encodeURIComponent(animeId)}`);
      const d = await r.json();
      if (d?.ok) {
        const info = (d.data?.info || {}) as Record<string, string>;
        setDetail({
          animeId,
          title: d.data?.title || animeId,
          thumbnail: d.data?.thumbnail,
          synopsis: d.data?.synopsis,
          info,
          genres: d.data?.genreList || [],
          episodes: d.data?.episodes || [],
        });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Gagal membuka anime", description: d?.error || "Silakan coba lagi." });
      }
    } catch {
      toast({ title: "Gagal membuka anime", description: "Koneksi bermasalah." });
    } finally {
      setDetailLoading(false);
    }
  };

  const openWatch = async (ep: Episode, refresh = false) => {
    // PERBAIKAN V2a: kirim URL episode LENGKAP ke API — slug saja membuat
    // upstream mengembalikan daftar mirror kosong (akar masalah episode gagal).
    const epUrl = /^https?:\/\//.test(ep.link) ? ep.link : `https://otakudesu.blog/episode/${ep.link.replace(/^\/+/, "")}/`;
    setWatchLoading(true);
    setWatch(null);
    setActiveStream(null);
    setNativeSrc(null);
    try {
      const r = await fetch(`/api/anime?stream=${encodeURIComponent(epUrl)}${refresh ? "&refresh=1" : ""}`);
      const d = await r.json();
      if (d?.ok) {
        const streams = (d.data?.streams || []) as StreamRes[];
        const embedUrl = d.data?.embedUrl;
        setWatch({ title: d.data?.title || ep.title, streams, embedUrl, episodeUrl: epUrl, downloads: d.data?.downloads || [] });
        // V0.01 (#7): catat riwayat anime
        pushHistory("anime", {
          id: epUrl,
          title: detail?.title || d.data?.title || ep.title,
          subtitle: ep.title,
          poster: detail?.thumbnail || null,
        });
        // pilih resolusi dengan mirror terbanyak dulu
        const withLinks = streams.filter((s) => s.links?.length);
        const best = withLinks[0] || null;
        if (best) setActiveStream({ res: best, link: best.links[0] });
        else if (embedUrl) toast({ title: "Memakai pemutar embed sumber", description: "Mirror native tidak tersedia untuk episode ini — pemutar embed dipakai." });
        window.scrollTo({ top: 0 });
      } else {
        toast({ title: "Mirror tidak tersedia", description: d?.error || "Episode ini mungkin belum memiliki mirror. Silakan coba lagi nanti." });
      }
    } catch {
      toast({ title: "Gagal membuka episode", description: "Koneksi bermasalah — silakan coba lagi." });
    } finally {
      setWatchLoading(false);
    }
  };

  /** V2 UpdSec FIX "pindah server gak bisa dipencet":
   *  1. tiap klik punya AbortController + batas 25 detik — fetch gak bisa
   *     menggantung selamanya (dulu: resolve lambat = tombol kayak mati).
   *  2. token anti-race: respons lama (dari klik sebelumnya) diabaikan —
   *     stream gak "ke-reset" ke mirror yang salah.
   *  3. resolvingMirror: tombol yang sedang diproses kelihatan loading,
   *     jadi feedback selalu terasa.
   *  4. auto-resolve awal TIDAK menimpa pilihan manual user. */
  const pickTokenRef = useRef(0);
  const [resolvingMirror, setResolvingMirror] = useState<string | null>(null);
  const pickMirror = async (s: StreamRes, l: StreamLink, auto = false) => {
    const token = ++pickTokenRef.current;
    setActiveStream({ res: s, link: l });
    setNativeSrc(null);
    if (!watch?.episodeUrl) return;
    setResolving(true);
    if (!auto) setResolvingMirror(l.embed);
    const abort = new AbortController();
    const timeout = setTimeout(() => abort.abort(), 25000);
    try {
      const r = await fetch(
        `/api/anime/resolve?url=${encodeURIComponent(l.embed)}&referer=${encodeURIComponent(watch.episodeUrl)}`,
        { signal: abort.signal }
      );
      const d = await r.json();
      if (token !== pickTokenRef.current) return; // klik lebih baru menang
      if (d?.ok && d.stream?.playUrl) {
        setNativeSrc(d.stream.playUrl as string);
      } else {
        toast({ title: "Mirror ini memakai pemutar embed", description: "Sumber memblokir konversi native — tetap diputar, tetapi mungkin berisi iklan." });
      }
    } catch {
      if (token === pickTokenRef.current) {
        toast({ title: "Mirror lambat merespons", description: "Pemutar embed dipakai sementara — coba mirror lain bila tetap lambat." });
      }
    } finally {
      clearTimeout(timeout);
      if (token === pickTokenRef.current) {
        setResolving(false);
        setResolvingMirror(null);
      }
    }
  };

  // mirror pertama otomatis di-resolve saat watch terpasang (sekali saja)
  useEffect(() => {
    if (watch && activeStream && !nativeSrc && !resolving) {
      void pickMirror(activeStream.res, activeStream.link, true);
    }
  }, [watch, activeStream]);

  /* ---------- render: WATCH ---------- */
  if (watchLoading) {
    return (
      <div>
        <ToolHeader icon={<Tv className="h-5.5 w-5.5" />} title="Nonton Anime" subtitle="Sub Indonesia • langsung di sini" accent="amber" />
        <div className="flex h-[50vh] flex-col items-center justify-center gap-3">
          <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
          <p className="text-xs text-muted-foreground">Menyiapkan stream episode...</p>
        </div>
      </div>
    );
  }

  if (watch) {
    return (
      <div>
        <Button variant="ghost" onClick={() => setWatch(null)} className="mb-3 rounded-xl px-3">
          <ArrowLeft className="mr-1 h-4 w-4" /> Kembali ke daftar episode
        </Button>

        <h2 className="mb-3 clamp-2 text-base font-extrabold">{watch.title}</h2>

        <div ref={playerWrapRef} className="relative overflow-hidden rounded-2xl bg-black shadow-2xl">
          <div className="aspect-video w-full">
            {nativeSrc ? (
              /* V2-new: pemutar native — bebas iklan, bisa diskip & diputar ulang */
              <NativePlayer src={nativeSrc} title={`${watch.title} — ${activeStream?.res.resolution || ""} (${activeStream?.link.name || ""})`} poster={detail?.thumbnail} />
            ) : activeStream ? (
              <div className="relative h-full w-full">
                {resolving && (
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2 bg-black/70">
                    <Loader2 className="h-7 w-7 animate-spin text-amber-400" />
                    <p className="text-[11px] font-bold text-white/80">Mengubah mirror jadi pemutar native…</p>
                  </div>
                )}
                <iframe
                  key={activeStream.link.embed}
                  src={activeStream.link.embed}
                  title="Fanzz Anime Player"
                  className="h-full w-full border-0"
                  allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                  allowFullScreen
                  referrerPolicy="no-referrer"
                  sandbox={PLAYER_SANDBOX}
                />
              </div>
            ) : watch.embedUrl ? (
              /* fallback terakhir: embed utama dari sumber (sebelumnya tidak pernah dirender) */
              <iframe
                key={watch.embedUrl}
                src={watch.embedUrl}
                title="Fanzz Anime Player"
                className="h-full w-full border-0"
                allow="autoplay; fullscreen; encrypted-media; picture-in-picture"
                allowFullScreen
                referrerPolicy="no-referrer"
                sandbox={PLAYER_SANDBOX}
              />
            ) : (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Mirror tidak tersedia</div>
            )}
          </div>
          {/* tombol layar penuh — khusus mode embed (pemutar native punya tombol sendiri) */}
          {!nativeSrc && (
            <button
              onClick={goFullscreenLandscape}
              className="absolute left-2 top-2 z-10 flex items-center gap-1.5 rounded-xl bg-black/55 px-2.5 py-2 text-[10px] font-bold text-white/85 backdrop-blur-md transition-all hover:bg-black/75 active:scale-90"
              title="Layar penuh mode landscape"
            >
              <Maximize className="h-3.5 w-3.5" />
              Layar Penuh
            </button>
          )}
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`absolute right-2 top-2 z-10 flex items-center gap-1.5 rounded-xl px-2.5 py-2 text-[10px] font-bold backdrop-blur-md transition-all active:scale-90 ${
              chatOpen ? "bg-amber-500 text-white" : "bg-black/55 text-white/85 hover:bg-black/75"
            }`}
          >
            <MessageCircle className="h-3.5 w-3.5" />
            {chatOpen ? "Tutup" : "Chat"}
          </button>
          <span className="absolute left-2 bottom-2 z-10 flex items-center gap-1 rounded-xl bg-amber-500/85 px-2 py-1.5 text-[10px] font-bold text-white">
            <Captions className="h-3.5 w-3.5" /> Sub Indo
          </span>
        </div>

        {/* chat sambil nonton */}
        <AnimatePresence>
          {chatOpen && (
            <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
              <div className="mt-3 rounded-2xl glass p-3">
                <WatchChat />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* pilih resolusi + mirror */}
        <section className="mt-4">
          <div className="mb-2.5 flex items-center justify-between">
            <h3 className="flex items-center gap-1.5 text-sm font-bold">
              <Server className="h-4 w-4 text-amber-400" /> Pilih Resolusi &amp; Mirror
            </h3>
            {/* V2-new: muat ulang daftar mirror (bypass cache) */}
            <button
              onClick={() => {
                if (watch?.episodeUrl) openWatch({ title: watch.title, link: watch.episodeUrl }, true);
              }}
              className="flex items-center gap-1.5 rounded-xl bg-secondary/70 px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground transition-colors hover:text-foreground"
              title="Muat ulang daftar mirror (lewati cache)"
            >
              <RefreshCw className="h-3.5 w-3.5" /> Muat ulang
            </button>
          </div>
          <div className="space-y-2.5">
            {watch.streams.map((s) => (
              <div key={s.resolution} className="rounded-2xl glass p-3">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
                  <MonitorPlay className="h-3.5 w-3.5 text-amber-400" /> {s.resolution}
                </p>
                <div className="flex flex-wrap gap-2">
                  {s.links.map((l) => (
                    <button
                      key={l.embed}
                      onClick={() => void pickMirror(s, l)}
                      className={`flex items-center gap-1.5 rounded-xl px-3 py-2 text-[11px] font-bold capitalize transition-all active:scale-95 ${
                        activeStream?.link.embed === l.embed
                          ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/25"
                          : "bg-secondary/70 text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {resolvingMirror === l.embed && <Loader2 className="h-3 w-3 animate-spin" />}
                      {l.name}
                      {activeStream?.link.embed === l.embed && nativeSrc && (
                        <span className="ml-1.5 rounded-full bg-emerald-500/25 px-1.5 py-px text-[8px] font-extrabold text-emerald-300">NATIVE</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {(watch.streams.length === 0 || !watch.streams.some((s) => s.links?.length)) && (
              <p className="rounded-2xl glass p-4 text-center text-xs text-muted-foreground">
                {watch.embedUrl
                  ? "Episode ini hanya menyediakan pemutar embed utama (sudah dipasang di atas). Coba tombol Muat ulang bila kosong."
                  : "Episode ini belum memiliki mirror yang dapat dibaca — silakan coba episode lain atau muat ulang."}
              </p>
            )}
          </div>
        </section>

        {/* tautan unduh episode */}
        {watch.downloads && watch.downloads.length > 0 && (
          <section className="mt-4">
            <h3 className="mb-2.5 flex items-center gap-1.5 text-sm font-bold">
              <Download className="h-4 w-4 text-amber-400" /> Unduh Episode
            </h3>
            <div className="space-y-2.5">
              {watch.downloads.map((dl) => (
                <div key={dl.resolution} className="rounded-2xl glass p-3">
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-extrabold">
                    <Download className="h-3.5 w-3.5 text-amber-400" /> {dl.resolution}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {(dl.links || []).slice(0, 6).map((l) => (
                      <a
                        key={l.link}
                        href={l.link}
                        target="_blank"
                        rel="noopener noreferrer nofollow"
                        className="rounded-xl bg-secondary/70 px-3 py-2 text-[11px] font-bold capitalize text-muted-foreground transition-colors hover:text-foreground"
                      >
                        {l.name}
                      </a>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        <p className="mt-3 rounded-2xl glass p-3.5 text-[11px] leading-relaxed text-muted-foreground">
          Tandai <b className="text-emerald-300">NATIVE</b> = diputar di pemutar internal FanzzTools (bebas iklan, bisa diskip / diputar ulang / layar penuh).
          Mirror tanpa tanda memakai pemutar embed sumber. Apabila bermasalah, pindahkan ke mirror atau resolusi lain.
          Seluruh episode telah dilengkapi subtitle Indonesia dari sumbernya.
        </p>
      </div>
    );
  }

  /* ---------- render: WATCH LOADING fallback ---------- */

  /* ---------- render: DETAIL ---------- */
  if (detailLoading) {
    return (
      <div>
        <ToolHeader icon={<Tv className="h-5.5 w-5.5" />} title="Nonton Anime" subtitle="Sub Indonesia • langsung di sini" accent="amber" />
        <div className="space-y-3">
          <div className="h-48 rounded-3xl shimmer" />
          <div className="h-6 w-2/3 rounded-xl shimmer" />
          <div className="h-24 rounded-2xl shimmer" />
        </div>
      </div>
    );
  }

  if (detail) {
    const infoEntries = Object.entries(detail.info || {});
    return (
      <div>
        <Button variant="ghost" onClick={() => setDetail(null)} className="mb-3 rounded-xl px-3">
          <ArrowLeft className="mr-1 h-4 w-4" /> Kembali
        </Button>

        <div className="relative overflow-hidden rounded-3xl glass p-5">
          <div className="flex gap-4">
            {detail.thumbnail && (
              <img src={detail.thumbnail} alt="" className="h-36 w-24 shrink-0 rounded-2xl object-cover shadow-xl" referrerPolicy="no-referrer" />
            )}
            <div className="min-w-0 flex-1">
              <h2 className="clamp-3 text-base font-extrabold leading-snug">{detail.title}</h2>
              {detail.genres && detail.genres.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {detail.genres.slice(0, 6).map((g) => (
                    <span key={g.title} className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-bold text-amber-300">{g.title}</span>
                  ))}
                </div>
              )}
              {infoEntries.length > 0 && (
                <div className="mt-2.5 space-y-1">
                  {infoEntries.slice(0, 4).map(([k, v]) => (
                    <p key={k} className="text-[11px] text-muted-foreground">
                      <span className="font-bold text-foreground/80">{k}:</span> {String(v).slice(0, 60)}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {detail.synopsis && (
          <section className="mt-4 rounded-2xl glass p-4">
            <h3 className="mb-1.5 text-sm font-bold">Sinopsis</h3>
            <p className="text-sm leading-relaxed text-muted-foreground">{detail.synopsis}</p>
          </section>
        )}

        <section className="mt-4">
          <h3 className="mb-2.5 text-sm font-bold">Daftar Episode ({detail.episodes.length})</h3>
          <div className="space-y-2">
            {detail.episodes.map((ep, i) => (
              <button
                key={ep.link}
                onClick={() => openWatch(ep)}
                className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01] active:scale-[0.99]"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-500 to-orange-500 text-sm font-extrabold text-white shadow-lg shadow-amber-500/20">
                  {detail.episodes.length - i}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="clamp-1 text-sm font-bold">{ep.title}</p>
                  {ep.date && <p className="text-[10px] text-muted-foreground">{ep.date}</p>}
                </div>
                <div className="flex shrink-0 items-center gap-1 rounded-xl bg-amber-500/15 px-2.5 py-1.5 text-[10px] font-extrabold text-amber-300">
                  <Play className="h-3 w-3" /> Tonton
                </div>
              </button>
            ))}
            {detail.episodes.length === 0 && (
              <EmptyState icon={<Tv className="h-6 w-6" />} title="Episode belum tersedia" desc="Anime ini mungkin belum memiliki episode yang dirilis." />
            )}
          </div>
        </section>
      </div>
    );
  }

  /* ---------- render: BROWSE ---------- */
  const cardGrid = (list: AnimeCard[] | null, emptyText: string) => {
    if (list === null) {
      return (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {[0, 1, 2, 3, 4, 5].map((i) => <CardSkeleton key={i} />)}
        </div>
      );
    }
    if (list.length === 0) return <EmptyState icon={<Tv className="h-6 w-6" />} title="Tidak ada hasil" desc={emptyText} />;
    return (
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {list.map((a, i) => (
          <motion.button
            key={(a.animeId || a.title) + i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(i * 0.03, 0.3) }}
            onClick={() => a.animeId && openDetail(a.animeId)}
            className="group overflow-hidden rounded-2xl glass p-2 text-left transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-secondary">
              {a.thumbnail ? (
                <img src={a.thumbnail} alt="" loading="lazy" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <div className="flex h-full items-center justify-center"><Tv className="h-8 w-8 text-muted-foreground" /></div>
              )}
              <span className="absolute left-1.5 top-1.5 flex items-center gap-1 rounded-lg bg-amber-500/90 px-1.5 py-0.5 text-[9px] font-extrabold text-white">
                <Captions className="h-2.5 w-2.5" /> SUB INDO
              </span>
              {(a.episode || a.status) && (
                <span className="absolute inset-x-1.5 bottom-1.5 truncate rounded-lg bg-black/75 px-1.5 py-1 text-[9px] font-bold text-white backdrop-blur-sm">
                  {a.episode || a.status}
                </span>
              )}
            </div>
            <p className="clamp-2 mt-2 px-0.5 text-[11.5px] font-bold leading-tight">{a.title}</p>
          </motion.button>
        ))}
      </div>
    );
  };

  return (
    <div>
      <ToolHeader icon={<Tv className="h-5.5 w-5.5" />} title="Nonton Anime" subtitle="Sub Indonesia • populer • jadwal • langsung nonton" accent="amber" />

      {/* tabs */}
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        {([
          { id: "ongoing", label: "Sedang Tayang", icon: Play },
          { id: "schedule", label: "Jadwal", icon: CalendarDays },
          { id: "completed", label: "Tamat", icon: CheckCircle2 },
          { id: "search", label: "Cari", icon: Search },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`relative flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-bold transition-colors ${
              tab === t.id ? "text-white" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab === t.id && <motion.span layoutId="anime-tab" className="absolute inset-0 rounded-full bg-gradient-to-r from-amber-500 to-orange-500" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <t.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {/* TAB: SEDANG TAYANG */}
        {tab === "ongoing" && (
          <motion.div key="ongoing" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}>
            {ongoing === null ? (
              <div className="space-y-2">{[0, 1, 2, 3, 4].map((i) => <div key={i} className="h-24 rounded-2xl shimmer" />)}</div>
            ) : (
              <div className="space-y-2">
                {ongoing.map((a, i) => (
                  <motion.button
                    key={(a.animeId || a.title) + i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: Math.min(i * 0.04, 0.4) }}
                    onClick={() => a.animeId && openDetail(a.animeId)}
                    className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
                  >
                    {a.thumbnail ? (
                      <img src={a.thumbnail} alt="" loading="lazy" className="h-16 w-12 shrink-0 rounded-lg object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="flex h-16 w-12 shrink-0 items-center justify-center rounded-lg bg-secondary"><Tv className="h-5 w-5 text-muted-foreground" /></div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="clamp-2 text-sm font-bold leading-tight">{a.title}</p>
                      <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground">
                        {a.episode && <span className="rounded-full bg-amber-500/15 px-1.5 py-px font-bold text-amber-300">{a.episode}</span>}
                        {a.day && <span className="flex items-center gap-0.5"><Clock3 className="h-2.5 w-2.5" /> {a.day}</span>}
                        {a.date && <span>{a.date}</span>}
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </motion.button>
                ))}
                {ongoing.length === 0 && <EmptyState icon={<Tv className="h-6 w-6" />} title="Belum ada anime" desc="Sumber sedang bermasalah — silakan muat ulang beberapa saat lagi." />}
              </div>
            )}
          </motion.div>
        )}

        {/* TAB: JADWAL */}
        {tab === "schedule" && (
          <motion.div key="schedule" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto pb-1">
              {DAYS.map((d) => (
                <button
                  key={d}
                  onClick={() => setDayPick(d)}
                  className={`shrink-0 rounded-full px-3.5 py-2 text-xs font-bold transition-all ${
                    dayPick === d ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-lg shadow-amber-500/20" : "bg-secondary/60 text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
            {schedule === null ? (
              <div className="space-y-2">{[0, 1, 2, 3].map((i) => <div key={i} className="h-20 rounded-2xl shimmer" />)}</div>
            ) : (
              <div className="space-y-2">
                {(schedule[dayPick] || []).map((a, i) => (
                  <button
                    key={(a.animeId || a.title) + i}
                    onClick={() => a.animeId && openDetail(a.animeId)}
                    className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-all hover:scale-[1.01]"
                  >
                    {a.thumbnail ? (
                      <img src={a.thumbnail} alt="" loading="lazy" className="h-14 w-11 shrink-0 rounded-lg object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="flex h-14 w-11 shrink-0 items-center justify-center rounded-lg bg-secondary"><Tv className="h-4 w-4 text-muted-foreground" /></div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="clamp-2 text-sm font-bold leading-tight">{a.title}</p>
                    </div>
                    <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" />
                  </button>
                ))}
                {(schedule[dayPick] || []).length === 0 && (
                  <EmptyState icon={<CalendarDays className="h-6 w-6" />} title={`Tidak ada jadwal ${dayPick}`} desc="Silakan pilih hari lain pada tab di atas." />
                )}
              </div>
            )}
          </motion.div>
        )}

        {/* TAB: TAMAT */}
        {tab === "completed" && (
          <motion.div key="completed" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            {cardGrid(completed, "Halaman ini kosong atau sumber bermasalah.")}
            {completed !== null && completed.length > 0 && (
              <div className="mt-4 flex items-center justify-between">
                <Button size="sm" variant="secondary" disabled={completedPage <= 1} onClick={() => { const p = completedPage - 1; setCompletedPage(p); loadCompleted(p); }} className="rounded-xl">
                  ← Sebelumnya
                </Button>
                <span className="text-xs font-bold text-muted-foreground">{completedPage} / {totalPages}</span>
                <Button size="sm" variant="secondary" disabled={completedPage >= totalPages} onClick={() => { const p = completedPage + 1; setCompletedPage(p); loadCompleted(p); }} className="rounded-xl">
                  Selanjutnya →
                </Button>
              </div>
            )}
          </motion.div>
        )}

        {/* TAB: CARI */}
        {tab === "search" && (
          <motion.div key="search" initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}>
            <div className="relative mb-4">
              <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => { setQuery(e.target.value); doSearch(e.target.value); }}
                placeholder="Cari judul anime... (misal: naruto, one piece)"
                className="w-full rounded-xl border border-border/60 bg-secondary/50 py-3.5 pl-10 pr-10 text-sm outline-none focus:border-amber-400/50"
              />
              {searching && <Loader2 className="absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-amber-400" />}
            </div>
            {searchRes === null ? (
              <p className="py-6 text-center text-xs text-muted-foreground">Ketik judul anime untuk mulai mencari...</p>
            ) : (
              cardGrid(searchRes, "Anime tidak ditemukan — silakan coba kata kunci lain.")
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
