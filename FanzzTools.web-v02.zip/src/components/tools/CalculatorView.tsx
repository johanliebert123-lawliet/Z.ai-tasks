"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader } from "@/components/tools/shared";
import { pushHistory } from "@/lib/history";
import {
  Calculator, Sigma, Zap, Delete, History as HistoryIcon, X, Trash2, ArrowRight,
  Ruler, Flame, Magnet, Waves, Battery, Droplets, Gauge, Clock3,
} from "lucide-react";

/**
 * Kalkulator (V2.11 #29) — dua mode:
 *  - Matematika: parser ekspresi aman (recursive descent — tanpa eval), fungsi &
 *    konstanta, riwayat, presisi tinggi.
 *  - Fisika: pustaka rumus populer dengan solver — masukkan nilai yang diketahui,
 *    nilai yang dicari dihitung otomatis.
 */

/* ================= PARSER MATEMATIKA AMAN ================= */

type Token = { t: "num"; v: number } | { t: "op"; v: string } | { t: "fn"; v: string } | { t: "paren"; v: "(" | ")" } | { t: "comma" };

function lex(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/,/g, ",");
  while (i < s.length) {
    const c = s[i];
    if (/\s/.test(c)) {
      i++;
      continue;
    }
    if (/[0-9.]/.test(c)) {
      let j = i;
      while (j < s.length && /[0-9.]/.test(s[j])) j++;
      const num = Number(s.slice(i, j));
      if (!Number.isFinite(num)) throw new Error("Angka tidak valid");
      tokens.push({ t: "num", v: num });
      i = j;
      continue;
    }
    if (/[a-z]/i.test(c)) {
      let j = i;
      while (j < s.length && /[a-z]/i.test(s[j])) j++;
      const kata = s.slice(i, j).toLowerCase();
      if (kata === "pi" || kata === "e" || kata === "phi") {
        tokens.push({ t: "num", v: kata === "pi" ? Math.PI : kata === "e" ? Math.E : (1 + Math.sqrt(5)) / 2 });
      } else if (["sqrt", "sin", "cos", "tan", "asin", "acos", "atan", "log", "ln", "abs", "exp", "cbrt"].includes(kata)) {
        tokens.push({ t: "fn", v: kata });
      } else {
        throw new Error(`Istilah tidak dikenal: ${kata}`);
      }
      i = j;
      continue;
    }
    if ("+-*/^%".includes(c)) {
      tokens.push({ t: "op", v: c });
      i++;
      continue;
    }
    if (c === "(" || c === ")") {
      tokens.push({ t: "paren", v: c });
      i++;
      continue;
    }
    if (c === ",") {
      tokens.push({ t: "comma" });
      i++;
      continue;
    }
    if (c === "!") {
      tokens.push({ t: "op", v: "!" });
      i++;
      continue;
    }
    throw new Error(`Karakter tidak dikenal: ${c}`);
  }
  return tokens;
}

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) throw new Error("Faktorial hanya untuk bilangan bulat ≥ 0");
  if (n > 170) throw new Error("Angka terlalu besar untuk faktorial");
  let r = 1;
  for (let k = 2; k <= n; k++) r *= k;
  return r;
}

function parse(tokens: Token[]): number {
  let pos = 0;
  const peek = () => tokens[pos];
  const eat = () => tokens[pos++];

  function parseExpr(): number {
    let kiri = parseTerm();
    while (peek()?.t === "op" && "+-".includes((peek() as { v: string }).v)) {
      const op = (eat() as { v: string }).v;
      const kanan = parseTerm();
      kiri = op === "+" ? kiri + kanan : kiri - kanan;
    }
    return kiri;
  }
  function parseTerm(): number {
    let kiri = parseUnary();
    while (peek()?.t === "op" && "*/%".includes((peek() as { v: string }).v)) {
      const op = (eat() as { v: string }).v;
      const kanan = parseUnary();
      if ((op === "/" || op === "%") && kanan === 0) throw new Error("Tidak bisa dibagi nol");
      kiri = op === "*" ? kiri * kanan : op === "/" ? kiri / kanan : kiri % kanan;
    }
    return kiri;
  }
  function parseUnary(): number {
    if (peek()?.t === "op" && (peek() as { v: string }).v === "-") {
      eat();
      return -parseUnary();
    }
    if (peek()?.t === "op" && (peek() as { v: string }).v === "+") {
      eat();
      return parseUnary();
    }
    return parsePower();
  }
  function parsePower(): number {
    const basis = parsePostfix();
    if (peek()?.t === "op" && (peek() as { v: string }).v === "^") {
      eat();
      const pangkat = parseUnary(); // asosiatif kanan
      return Math.pow(basis, pangkat);
    }
    return basis;
  }
  function parsePostfix(): number {
    let nilai = parseAtom();
    while (peek()?.t === "op" && (peek() as { v: string }).v === "!") {
      eat();
      nilai = factorial(nilai);
    }
    return nilai;
  }
  function parseAtom(): number {
    const tk = peek();
    if (!tk) throw new Error("Ekspresi belum lengkap");
    if (tk.t === "num") {
      eat();
      return tk.v;
    }
    if (tk.t === "fn") {
      eat();
      const arg = parseAtom();
      switch (tk.v) {
        case "sqrt": return Math.sqrt(arg);
        case "cbrt": return Math.cbrt(arg);
        case "sin": return Math.sin(arg);
        case "cos": return Math.cos(arg);
        case "tan": return Math.tan(arg);
        case "asin": return Math.asin(arg);
        case "acos": return Math.acos(arg);
        case "atan": return Math.atan(arg);
        case "log": return Math.log10(arg);
        case "ln": return Math.log(arg);
        case "abs": return Math.abs(arg);
        case "exp": return Math.exp(arg);
        default: throw new Error("Fungsi tidak dikenal");
      }
    }
    if (tk.t === "paren" && tk.v === "(") {
      eat();
      const nilai = parseExpr();
      const tutup = peek();
      if (!tutup || tutup.t !== "paren" || tutup.v !== ")") throw new Error("Kurung tutup hilang");
      eat();
      return nilai;
    }
    throw new Error("Ekspresi tidak valid");
  }

  const hasil = parseExpr();
  if (pos !== tokens.length) throw new Error("Ada bagian yang tidak terbaca");
  return hasil;
}

function hitung(ekspresi: string): number {
  const bersih = ekspresi.trim();
  if (!bersih) throw new Error("Kosong");
  return parse(lex(bersih));
}

/* ================= PUSTAKA RUMUS FISIKA ================= */

interface RumusVar { simbol: string; nama: string; satuan: string }
interface Rumus {
  id: string;
  nama: string;
  ikon: React.ReactNode;
  kategori: string;
  vars: RumusVar[];
  /** indeks var yang bisa diselesaikan; fn menerima nilai2 (null = dicari) */
  solve: (nilai: Array<number | null>) => number | null;
  bentuk: string;
}

const RUMUS: Rumus[] = [
  {
    id: "v-v0-at",
    nama: "Kelajuan Akhir (GLBB)",
    ikon: <Gauge className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "v", nama: "Kelajuan akhir", satuan: "m/s" },
      { simbol: "v₀", nama: "Kelajuan awal", satuan: "m/s" },
      { simbol: "a", nama: "Percepatan", satuan: "m/s²" },
      { simbol: "t", nama: "Waktu", satuan: "s" },
    ],
    solve: ([v, v0, a, t]) => {
      if (v === null && v0 !== null && a !== null && t !== null) return v0 + a * t;
      if (v0 === null && v !== null && a !== null && t !== null) return (v - a * t) as number;
      if (a === null && v !== null && v0 !== null && t !== null) return (v - v0) / t;
      if (t === null && v !== null && v0 !== null && a !== null && a !== 0) return (v - v0) / a;
      return null;
    },
    bentuk: "v = v₀ + a·t",
  },
  {
    id: "s-v0t-at2",
    nama: "Jarak Tempuh (GLBB)",
    ikon: <Ruler className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "s", nama: "Jarak", satuan: "m" },
      { simbol: "v₀", nama: "Kelajuan awal", satuan: "m/s" },
      { simbol: "a", nama: "Percepatan", satuan: "m/s²" },
      { simbol: "t", nama: "Waktu", satuan: "s" },
    ],
    solve: ([s, v0, a, t]) => {
      if (s === null && v0 !== null && a !== null && t !== null) return v0 * t + 0.5 * a * t * t;
      if (t === null && s !== null && v0 !== null && a !== null) {
        // 0.5a t² + v0 t - s = 0
        const A = 0.5 * a;
        const B = v0;
        const C = -s;
        const D = B * B - 4 * A * C;
        if (D < 0 || A === 0) return null;
        return (-B + Math.sqrt(D)) / (2 * A);
      }
      return null;
    },
    bentuk: "s = v₀·t + ½·a·t²",
  },
  {
    id: "f-ma",
    nama: "Hukum II Newton",
    ikon: <Zap className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "F", nama: "Gaya", satuan: "N" },
      { simbol: "m", nama: "Massa", satuan: "kg" },
      { simbol: "a", nama: "Percepatan", satuan: "m/s²" },
    ],
    solve: ([F, m, a]) => {
      if (F === null && m !== null && a !== null) return m * a;
      if (m === null && F !== null && a !== null && a !== 0) return F / a;
      if (a === null && F !== null && m !== null && m !== 0) return F / m;
      return null;
    },
    bentuk: "F = m·a",
  },
  {
    id: "w-fs",
    nama: "Usaha",
    ikon: <ArrowRight className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "W", nama: "Usaha", satuan: "J" },
      { simbol: "F", nama: "Gaya", satuan: "N" },
      { simbol: "s", nama: "Perpindahan", satuan: "m" },
    ],
    solve: ([W, F, s]) => {
      if (W === null && F !== null && s !== null) return F * s;
      if (F === null && W !== null && s !== null && s !== 0) return W / s;
      if (s === null && W !== null && F !== null && F !== 0) return W / F;
      return null;
    },
    bentuk: "W = F·s",
  },
  {
    id: "ohm",
    nama: "Hukum Ohm",
    ikon: <Magnet className="h-4 w-4" />,
    kategori: "Listrik",
    vars: [
      { simbol: "V", nama: "Tegangan", satuan: "V" },
      { simbol: "I", nama: "Arus", satuan: "A" },
      { simbol: "R", nama: "Hambatan", satuan: "Ω" },
    ],
    solve: ([V, I, R]) => {
      if (V === null && I !== null && R !== null) return I * R;
      if (I === null && V !== null && R !== null && R !== 0) return V / R;
      if (R === null && V !== null && I !== null && I !== 0) return V / I;
      return null;
    },
    bentuk: "V = I·R",
  },
  {
    id: "daya",
    nama: "Daya Listrik",
    ikon: <Battery className="h-4 w-4" />,
    kategori: "Listrik",
    vars: [
      { simbol: "P", nama: "Daya", satuan: "W" },
      { simbol: "V", nama: "Tegangan", satuan: "V" },
      { simbol: "I", nama: "Arus", satuan: "A" },
    ],
    solve: ([P, V, I]) => {
      if (P === null && V !== null && I !== null) return V * I;
      if (V === null && P !== null && I !== null && I !== 0) return P / I;
      if (I === null && P !== null && V !== null && V !== 0) return P / V;
      return null;
    },
    bentuk: "P = V·I",
  },
  {
    id: "massa-jenis",
    nama: "Massa Jenis",
    ikon: <Droplets className="h-4 w-4" />,
    kategori: "Materi",
    vars: [
      { simbol: "ρ", nama: "Massa jenis", satuan: "kg/m³" },
      { simbol: "m", nama: "Massa", satuan: "kg" },
      { simbol: "V", nama: "Volume", satuan: "m³" },
    ],
    solve: ([rho, m, V]) => {
      if (rho === null && m !== null && V !== null && V !== 0) return m / V;
      if (m === null && rho !== null && V !== null) return rho * V;
      if (V === null && rho !== null && m !== null && rho !== 0) return m / rho;
      return null;
    },
    bentuk: "ρ = m / V",
  },
  {
    id: "tekanan",
    nama: "Tekanan",
    ikon: <Gauge className="h-4 w-4" />,
    kategori: "Materi",
    vars: [
      { simbol: "P", nama: "Tekanan", satuan: "Pa" },
      { simbol: "F", nama: "Gaya", satuan: "N" },
      { simbol: "A", nama: "Luas bidang", satuan: "m²" },
    ],
    solve: ([P, F, A]) => {
      if (P === null && F !== null && A !== null && A !== 0) return F / A;
      if (F === null && P !== null && A !== null) return P * A;
      if (A === null && P !== null && F !== null && P !== 0) return F / P;
      return null;
    },
    bentuk: "P = F / A",
  },
  {
    id: "kalor",
    nama: "Kalor (Q)",
    ikon: <Flame className="h-4 w-4" />,
    kategori: "Kalor",
    vars: [
      { simbol: "Q", nama: "Kalor", satuan: "J" },
      { simbol: "m", nama: "Massa", satuan: "kg" },
      { simbol: "c", nama: "Kalor jenis", satuan: "J/kg°C" },
      { simbol: "ΔT", nama: "Perubahan suhu", satuan: "°C" },
    ],
    solve: ([Q, m, c, dT]) => {
      if (Q === null && m !== null && c !== null && dT !== null) return m * c * dT;
      if (dT === null && Q !== null && m !== null && c !== null && m * c !== 0) return Q / (m * c);
      return null;
    },
    bentuk: "Q = m·c·ΔT",
  },
  {
    id: "frekuensi",
    nama: "Frekuensi & Periode",
    ikon: <Waves className="h-4 w-4" />,
    kategori: "Gelombang",
    vars: [
      { simbol: "f", nama: "Frekuensi", satuan: "Hz" },
      { simbol: "T", nama: "Periode", satuan: "s" },
    ],
    solve: ([f, T]) => {
      if (f === null && T !== null && T !== 0) return 1 / T;
      if (T === null && f !== null && f !== 0) return 1 / f;
      return null;
    },
    bentuk: "f = 1 / T",
  },
  {
    id: "ek",
    nama: "Energi Kinetik",
    ikon: <Zap className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "Ek", nama: "Energi kinetik", satuan: "J" },
      { simbol: "m", nama: "Massa", satuan: "kg" },
      { simbol: "v", nama: "Kelajuan", satuan: "m/s" },
    ],
    solve: ([Ek, m, v]) => {
      if (Ek === null && m !== null && v !== null) return 0.5 * m * v * v;
      if (m === null && Ek !== null && v !== null && v !== 0) return (2 * Ek) / (v * v);
      if (v === null && Ek !== null && m !== null && m !== 0) return Math.sqrt((2 * Ek) / m);
      return null;
    },
    bentuk: "Ek = ½·m·v²",
  },
  {
    id: "ep",
    nama: "Energi Potensial Gravitasi",
    ikon: <Clock3 className="h-4 w-4" />,
    kategori: "Mekanika",
    vars: [
      { simbol: "Ep", nama: "Energi potensial", satuan: "J" },
      { simbol: "m", nama: "Massa", satuan: "kg" },
      { simbol: "g", nama: "Gravitasi", satuan: "m/s²" },
      { simbol: "h", nama: "Ketinggian", satuan: "m" },
    ],
    solve: ([Ep, m, g, h]) => {
      if (Ep === null && m !== null && g !== null && h !== null) return m * g * h;
      if (h === null && Ep !== null && m !== null && g !== null && m * g !== 0) return Ep / (m * g);
      return null;
    },
    bentuk: "Ep = m·g·h",
  },
];

/* ================= TAMPILAN ================= */

function formatAngka(n: number): string {
  if (!Number.isFinite(n)) return "∞";
  if (Math.abs(n) >= 1e15 || (Math.abs(n) < 1e-9 && n !== 0)) return n.toExponential(6);
  const bulat = Math.round(n);
  if (Math.abs(n - bulat) < 1e-10) return bulat.toLocaleString("id-ID");
  return Number(n.toPrecision(12)).toLocaleString("id-ID", { maximumFractionDigits: 10 });
}

export default function CalculatorView() {
  const [mode, setMode] = useState<"mat" | "fisika">("mat");

  // matematika
  const [ekspresi, setEkspresi] = useState("");
  const [hasil, setHasil] = useState<number | null>(null);
  const [pesanError, setPesanError] = useState("");
  const [riwayat, setRiwayat] = useState<Array<{ e: string; h: number }>>([]);

  // fisika
  const [rumusIdx, setRumusIdx] = useState(0);
  const [nilai, setNilai] = useState<string[]>(() => new Array(RUMUS[0].vars.length).fill(""));

  const rumus = RUMUS[rumusIdx];

  /** Ganti rumus → kosongkan nilai lewat handler (bukan efek — hindari render berantai). */
  const gantiRumus = (i: number) => {
    setRumusIdx(i);
    setNilai(new Array(RUMUS[i].vars.length).fill(""));
  };

  const jalankan = useCallback(() => {
    try {
      const h = hitung(ekspresi);
      setHasil(h);
      setPesanError("");
      setRiwayat((r) => [{ e: ekspresi, h }, ...r].slice(0, 25));
    } catch (e) {
      setHasil(null);
      setPesanError(e instanceof Error ? e.message : "Ekspresi tidak valid");
    }
  }, [ekspresi]);

  const tekan = (t: string) => {
    setEkspresi((e) => e + t);
    setHasil(null);
    setPesanError("");
  };

  const selesaiFisika = useMemo(() => {
    if (mode !== "fisika") return null;
    const parsed = nilai.map((v) => {
      const t = v.trim();
      if (!t) return null;
      const n = Number(t.replace(",", "."));
      return Number.isFinite(n) ? n : NaN;
    });
    if (parsed.some((p) => Number.isNaN(p))) return { error: "Ada nilai yang bukan angka" };
    const terisi = parsed.filter((p) => p !== null).length;
    if (terisi < rumus.vars.length - 1) return null; // belum cukup
    const idxKosong = parsed.findIndex((p) => p === null);
    if (idxKosong === -1) return { error: "Kosongkan satu kolom yang ingin dicari" };
    const hasilNilai = rumus.solve(parsed);
    if (hasilNilai === null || !Number.isFinite(hasilNilai)) return { error: "Tidak bisa diselesaikan dengan nilai ini (cek pembagi nol / data)" };
    return { simbol: rumus.vars[idxKosong].simbol, nilai: hasilNilai, satuan: rumus.vars[idxKosong].satuan };
  }, [mode, nilai, rumus]);

  const tombolMat: Array<{ label: string; isi?: string; aksi?: "hapus" | "bersih" | "sama"; lebar?: string; warna?: string }> = [
    { label: "(", isi: "(" }, { label: ")", isi: ")" }, { label: "^", isi: "^" }, { label: "÷", isi: "/", aksi: undefined, warna: "text-red-300" },
    { label: "7", isi: "7" }, { label: "8", isi: "8" }, { label: "9", isi: "9" }, { label: "×", isi: "*", warna: "text-red-300" },
    { label: "4", isi: "4" }, { label: "5", isi: "5" }, { label: "6", isi: "6" }, { label: "−", isi: "-", warna: "text-red-300" },
    { label: "1", isi: "1" }, { label: "2", isi: "2" }, { label: "3", isi: "3" }, { label: "+", isi: "+", warna: "text-red-300" },
    { label: "0", isi: "0" }, { label: ".", isi: "." }, { label: "⌫", aksi: "hapus" }, { label: "=", aksi: "sama", warna: "bg-gradient-to-br from-red-500 to-red-700 text-white" },
    { label: "sqrt(", isi: "sqrt(" }, { label: "sin(", isi: "sin(" }, { label: "cos(", isi: "cos(" }, { label: "tan(", isi: "tan(" },
    { label: "π", isi: "pi" }, { label: "e", isi: "e" }, { label: "log(", isi: "log(" }, { label: "ln(", isi: "ln(" },
    { label: "abs(", isi: "abs(" }, { label: "!", isi: "!" }, { label: "%", isi: "%" }, { label: "C", aksi: "bersih", warna: "text-red-300" },
  ];

  return (
    <div>
      <ToolHeader
        icon={<Calculator className="h-6 w-6" />}
        title="Kalkulator"
        subtitle="Matematika lengkap (fungsi, konstanta, riwayat) + mode Fisika dengan solver rumus"
        accent="fuchsia"
      />

      <div className="mb-4 flex gap-2">
        {([
          { id: "mat", label: "Matematika", icon: Sigma },
          { id: "fisika", label: "Fisika", icon: Zap },
        ] as const).map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`relative flex flex-1 items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-xs font-bold transition-colors ${
              mode === m.id ? "text-white" : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {mode === m.id && <motion.span layoutId="kalkulator-tab" className="absolute inset-0 rounded-xl bg-gradient-to-r from-red-500 to-red-700" transition={{ type: "spring", stiffness: 350, damping: 30 }} />}
            <m.icon className="relative z-10 h-3.5 w-3.5" />
            <span className="relative z-10">{m.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={mode} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
          {mode === "mat" ? (
            <div className="mx-auto max-w-md space-y-3">
              {/* layar */}
              <div className="rounded-2xl glass-strong p-4">
                <input
                  value={ekspresi}
                  onChange={(e) => {
                    setEkspresi(e.target.value.slice(0, 120));
                    setHasil(null);
                    setPesanError("");
                  }}
                  onKeyDown={(e) => e.key === "Enter" && jalankan()}
                  placeholder="contoh: sqrt(144) + 2^10 × pi"
                  className="w-full bg-transparent text-right font-mono text-lg font-bold outline-none"
                  inputMode="text"
                />
                <div className="mt-2 min-h-8 text-right">
                  {pesanError ? (
                    <p className="text-xs font-bold text-red-400">{pesanError}</p>
                  ) : hasil !== null ? (
                    <p className="truncate text-2xl font-extrabold text-red-300">{formatAngka(hasil)}</p>
                  ) : (
                    <p className="font-mono text-xs text-muted-foreground">{ekspresi.length}/120</p>
                  )}
                </div>
              </div>

              {/* tombol */}
              <div className="grid grid-cols-4 gap-2">
                {tombolMat.map((t, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      if (t.aksi === "hapus") setEkspresi((e) => e.slice(0, -1));
                      else if (t.aksi === "bersih") {
                        setEkspresi("");
                        setHasil(null);
                        setPesanError("");
                      } else if (t.aksi === "sama") jalankan();
                      else tekan(t.isi || "");
                    }}
                    className={`h-12 rounded-xl text-sm font-bold transition active:scale-90 ${
                      t.warna || "bg-secondary/70 hover:bg-secondary"
                    } ${t.label === "=" ? "shadow-lg shadow-red-500/25" : ""}`}
                  >
                    {t.label === "⌫" ? <Delete className="mx-auto h-4 w-4" /> : t.label}
                  </button>
                ))}
              </div>

              {/* riwayat */}
              {riwayat.length > 0 && (
                <div className="rounded-2xl glass p-3.5">
                  <p className="mb-2 flex items-center gap-1.5 text-[11px] font-extrabold text-red-300">
                    <HistoryIcon className="h-3.5 w-3.5" /> Riwayat
                    <button onClick={() => setRiwayat([])} className="ml-auto text-muted-foreground hover:text-red-400" title="Bersihkan riwayat">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </p>
                  <div className="max-h-40 space-y-1 overflow-y-auto">
                    {riwayat.map((r, i) => (
                      <button
                        key={i}
                        onClick={() => {
                          setEkspresi(r.e);
                          setHasil(null);
                        }}
                        className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-[11px] hover:bg-secondary/60"
                      >
                        <span className="min-w-0 flex-1 truncate font-mono text-muted-foreground">{r.e}</span>
                        <span className="shrink-0 font-bold text-red-300">= {formatAngka(r.h)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <p className="text-center text-[10px] leading-relaxed text-muted-foreground">
                Mendukung: + − × ÷ ^ % ! , sqrt, cbrt, sin, cos, tan, asin, acos, atan, log, ln, abs, exp, π, e, phi.
                Parser aman bawaan sendiri (tanpa eval). Trigonometri memakai radian.
              </p>
            </div>
          ) : (
            <div className="mx-auto max-w-lg space-y-4">
              {/* daftar rumus */}
              <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1">
                {RUMUS.map((r, i) => (
                  <button
                    key={r.id}
                    onClick={() => gantiRumus(i)}
                    className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-[11px] font-bold transition ${
                      rumusIdx === i ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {r.ikon} {r.nama}
                  </button>
                ))}
              </div>

              {/* kartu rumus */}
              <div className="glass rounded-2xl p-4">
                <div className="mb-1 flex items-center gap-2">
                  {rumus.ikon}
                  <h3 className="text-sm font-extrabold">{rumus.nama}</h3>
                  <span className="rounded-full bg-secondary px-2 py-0.5 text-[9px] font-bold text-muted-foreground">{rumus.kategori}</span>
                </div>
                <p className="mb-4 rounded-xl bg-secondary/60 px-3 py-2 text-center font-mono text-sm font-bold text-red-300">{rumus.bentuk}</p>
                <p className="mb-2 text-[10.5px] text-muted-foreground">
                  Isi nilai yang <b>diketahui</b>, kosongkan <b>satu</b> kolom yang ingin dicari — dihitung otomatis.
                </p>
                <div className="space-y-2">
                  {rumus.vars.map((v, i) => (
                    <div key={v.simbol} className="flex items-center gap-3">
                      <span className="w-16 shrink-0 text-center font-mono text-sm font-extrabold text-red-300">{v.simbol}</span>
                      <input
                        value={nilai[i] ?? ""}
                        onChange={(e) => setNilai((arr) => arr.map((x, j) => (j === i ? e.target.value.slice(0, 20) : x)))}
                        placeholder={`${v.nama} (${v.satuan})`}
                        inputMode="decimal"
                        className="flex-1 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-red-400/50"
                      />
                      <span className="w-16 shrink-0 text-[10px] font-bold text-muted-foreground">{v.satuan}</span>
                    </div>
                  ))}
                </div>

                {selesaiFisika && "error" in selesaiFisika && selesaiFisika.error && (
                  <p className="mt-3 rounded-xl bg-amber-500/10 px-3 py-2 text-[11px] font-bold text-amber-300">{selesaiFisika.error}</p>
                )}

                <AnimatePresence>
                  {selesaiFisika && "nilai" in selesaiFisika && selesaiFisika.nilai !== undefined && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="mt-4 rounded-2xl bg-gradient-to-r from-red-500/15 to-red-700/15 p-4 text-center"
                    >
                      <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Hasil</p>
                      <p className="mt-1 text-2xl font-extrabold text-red-300">
                        {selesaiFisika.simbol} = {formatAngka(selesaiFisika.nilai)} <span className="text-sm text-muted-foreground">{selesaiFisika.satuan}</span>
                      </p>
                      <button
                        onClick={() =>
                          pushHistory("kalkulator", { id: `fisika-${Date.now()}`, title: `${rumus.nama} — ${selesaiFisika.simbol}`, subtitle: `${formatAngka(selesaiFisika.nilai)} ${selesaiFisika.satuan}` })
                        }
                        className="mt-1 text-[9px] text-muted-foreground/60"
                      >
                        disimpan ke riwayat aktivitas
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <p className="text-center text-[10px] leading-relaxed text-muted-foreground">
                {RUMUS.length} rumus inti Mekanika, Listrik, Materi, Kalor, dan Gelombang dengan solver dua arah.
                Trigonometri dalam radian; gravitasi bumi ≈ 9,8 m/s² bila diperlukan.
              </p>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
