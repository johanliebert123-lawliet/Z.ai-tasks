"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ToolHeader, EmptyState } from "@/components/tools/shared";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";
import {
  Music2, Search, Loader2, Mic2, Disc3, Clock3, FileText, Timer, Sparkles, Copy,
} from "lucide-react";

interface TrackHit {
  id: number;
  name: string;
  artistName: string;
  albumName?: string;
  duration?: number;
  instrumental?: boolean;
}

interface LyricDetail {
  track: TrackHit;
  plainLyrics: string;
  syncedLyrics: string;
}

function fmtDur(s?: number): string {
  if (!s || !Number.isFinite(s)) return "";
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${m}:${String(r).padStart(2, "0")}`;
}

/** Parse LRC "[mm:ss.xx] baris lirik" → daftar {t, text}. */
function parseLrc(lrc: string): Array<{ t: number; text: string }> {
  const out: Array<{ t: number; text: string }> = [];
  for (const m of lrc.matchAll(/\[(\d{1,2}):(\d{1,2})(?:[.:](\d{1,3}))?\]([^\n]*)/g)) {
    const min = Number(m[1]);
    const sec = Number(m[2]);
    const frac = m[3] ? Number(`0.${m[3]}`) : 0;
    const text = (m[4] || "").trim();
    if (Number.isFinite(min) && Number.isFinite(sec)) {
      out.push({ t: min * 60 + sec + frac, text });
    }
  }
  return out.filter((x) => x.text).sort((a, b) => a.t - b.t);
}

export default function LyricsToolView() {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [tracks, setTracks] = useState<TrackHit[] | null>(null);
  const [detail, setDetail] = useState<LyricDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [mode, setMode] = useState<"plain" | "synced">("plain");
  const { toast } = useToast();

  const doSearch = async () => {
    const t = q.trim();
    if (t.length < 2) return;
    setLoading(true);
    setError("");
    setTracks(null);
    setDetail(null);
    try {
      const res = await fetch(`/api/lyrics-tool?q=${encodeURIComponent(t)}`);
      const d = await res.json();
      if (d?.ok) {
        setTracks(d.tracks || []);
        if (!d.tracks?.length) setError("Lirik lagu tidak ditemukan — coba kata kunci lain (judul + artis).");
      } else throw new Error(d?.error || "Pencarian gagal");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Pencarian gagal");
    } finally {
      setLoading(false);
    }
  };

  const openLyrics = async (t: TrackHit) => {
    setDetailLoading(true);
    setDetail(null);
    setError("");
    try {
      const res = await fetch(`/api/lyrics-tool?id=${t.id}`);
      const d = await res.json();
      if (!d?.ok) throw new Error(d?.error || "Lirik tidak ditemukan");
      setDetail({ track: d.track, plainLyrics: d.plainLyrics || "", syncedLyrics: d.syncedLyrics || "" });
      setMode(d.syncedLyrics ? "synced" : "plain");
      pushHistory("lyrics", {
        id: String(t.id),
        title: t.name,
        subtitle: t.artistName,
        extra: { hasSynced: Boolean(d.syncedLyrics) },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Gagal memuat lirik");
    } finally {
      setDetailLoading(false);
    }
  };

  const synced = detail?.syncedLyrics ? parseLrc(detail.syncedLyrics) : [];

  const copyLyrics = () => {
    if (!detail) return;
    const text = mode === "synced" && synced.length ? synced.map((s) => `[${Math.floor(s.t / 60)}:${String(Math.floor(s.t % 60)).padStart(2, "0")}] ${s.text}`).join("\n") : detail.plainLyrics;
    try {
      navigator.clipboard.writeText(text);
      toast({ title: "Lirik tersalin", description: "Seluruh lirik telah disalin ke papan klip." });
    } catch {
      toast({ title: "Gagal menyalin", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-4">
      <ToolHeader
        icon={<Music2 className="h-5 w-5" />}
        title="Lyrics Music Python"
        desc="Cari lirik lagu lengkap sesuai nada dan panjang lagu — termasuk mode lirik tersinkron (karaoke per baris)."
      />

      {/* pencarian */}
      <div className="flex gap-2">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && doSearch()}
          placeholder="Judul lagu atau nama artis… (mis. Temanku Semua Pada Jahat)"
          className="rounded-xl"
        />
        <Button onClick={doSearch} disabled={loading || q.trim().length < 2} className="rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
        </Button>
      </div>

      {error && <EmptyState icon={<Music2 className="h-8 w-8" />} title={error} />}

      {/* hasil pencarian */}
      {tracks && tracks.length > 0 && (
        <section>
          <h3 className="mb-2.5 text-sm font-bold">Hasil pencarian ({tracks.length})</h3>
          <div className="space-y-2">
            {tracks.map((t) => (
              <button
                key={t.id}
                onClick={() => openLyrics(t)}
                className="flex w-full items-center gap-3 rounded-2xl glass p-3 text-left transition-colors hover:bg-secondary"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                  <Disc3 className="h-5 w-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-bold">{t.name}</p>
                  <p className="truncate text-[10px] text-muted-foreground">
                    <Mic2 className="mr-1 inline h-3 w-3" /> {t.artistName}
                    {t.albumName ? ` • ${t.albumName}` : ""}
                  </p>
                </div>
                {t.duration ? (
                  <span className="flex shrink-0 items-center gap-1 rounded-full bg-secondary px-2 py-1 text-[9px] font-bold text-muted-foreground">
                    <Timer className="h-3 w-3" /> {fmtDur(t.duration)}
                  </span>
                ) : null}
              </button>
            ))}
          </div>
        </section>
      )}

      {/* detail lirik */}
      {detailLoading && (
        <div className="flex items-center justify-center gap-2 py-10 text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin text-emerald-400" /> Memuat lirik lengkap…
        </div>
      )}

      <AnimatePresence>
        {detail && !detailLoading && (
          <motion.section
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="overflow-hidden rounded-2xl glass"
          >
            {/* header lagu */}
            <div className="border-b border-[var(--surface-line)] p-4">
              <p className="text-sm font-extrabold">{detail.track.name}</p>
              <p className="text-[11px] text-muted-foreground">
                {detail.track.artistName}
                {detail.track.albumName ? ` • ${detail.track.albumName}` : ""}
                {detail.track.duration ? ` • ${fmtDur(detail.track.duration)}` : ""}
              </p>

              <div className="mt-2.5 flex flex-wrap items-center gap-2">
                {/* pilih mode lirik */}
                <div className="flex items-center gap-1 rounded-xl bg-secondary/60 p-1">
                  <button
                    onClick={() => setMode("plain")}
                    className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition-colors ${
                      mode === "plain" ? "bg-emerald-500 text-white" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <FileText className="h-3 w-3" /> Teks penuh
                  </button>
                  <button
                    onClick={() => setMode("synced")}
                    disabled={!synced.length}
                    className={`flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition-colors disabled:opacity-40 ${
                      mode === "synced" ? "bg-emerald-500 text-white" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Clock3 className="h-3 w-3" /> Tersinkron
                  </button>
                </div>
                <button
                  onClick={copyLyrics}
                  className="flex items-center gap-1 rounded-xl glass px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Copy className="h-3 w-3" /> Salin lirik
                </button>
                {synced.length > 0 && mode === "synced" && (
                  <span className="flex items-center gap-1 rounded-xl bg-emerald-500/15 px-2.5 py-1.5 text-[10px] font-bold text-emerald-300">
                    <Sparkles className="h-3 w-3" /> Lirik mengikuti nada & durasi lagu
                  </span>
                )}
              </div>
            </div>

            {/* isi lirik */}
            <div className="max-h-[60vh] overflow-y-auto p-4">
              {mode === "plain" ? (
                <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed">{detail.plainLyrics || "Lirik teks penuh tidak tersedia untuk lagu ini."}</pre>
              ) : synced.length ? (
                <div className="space-y-1.5">
                  {synced.map((s, i) => (
                    <div key={i} className="flex items-baseline gap-3">
                      <span className="w-10 shrink-0 font-mono text-[9px] font-bold text-emerald-400/80">
                        {Math.floor(s.t / 60)}:{String(Math.floor(s.t % 60)).padStart(2, "0")}
                      </span>
                      <p className="text-xs leading-relaxed">{s.text}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">Lirik tersinkron tidak tersedia untuk lagu ini.</p>
              )}
            </div>

            <p className="border-t border-[var(--surface-line)] bg-secondary/30 px-4 py-2.5 text-[9px] text-muted-foreground">
              Sumber lirik: LRCLIB — lirik polos & lirik tersinkron per waktu nada. Untuk keperluan pembelajaran &
              referensi pribadi; hak cipta lirik milik pemiliknya.
            </p>
          </motion.section>
        )}
      </AnimatePresence>
    </div>
  );
}
