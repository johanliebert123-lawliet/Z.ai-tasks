"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/tools/shared";
import {
  downloadCanvas, recordCanvas, downloadBlob, canRecordCanvas, roundRectPath,
} from "@/components/tools/image-studio/lib";
import { Download, Film, Loader2, Binary, User, Sparkles } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * Cyber-Update #8: Generator video "Hacker Prank" (Studio Gambar).
 * Terminal PALSU yang menjalankan baris "kode hacker" secara animatif —
 * teks mengetik + scroll ala terminal, hujan matrix di latar, scanline CRT,
 * dan kartu akhir "AKSES DIBERIKAN".
 *
 * 100% hiburan: murni animasi kanvas — TIDAK ADA eksekusi command sungguhan,
 * tidak ada koneksi jaringan, dan watermark "prank" tercantum di status bar.
 */

const W = 1080;
const H = 1920;

const SKRIP_BAWAAN = `root@fanzz:~# ./prank_engine --target {TARGET} --mode fun
[*] Menghubungkan ke server utama ... OK
[*] Melewati firewall 127.0.0.1 ... OK
[+] Mengumpulkan data jaringan 0x4f 0x9a 0x2c 0x11
[+] Mendekripsi token sesi ............... OK
[+] Memindai 312 port terbuka
[########..............] 33%
[################......] 78%
[####################..] 96%
[####################] 100%
[-] Antivirus terdeteksi ... dipause sebentar
[+] Membuka pintu belakang port 1337 ... OK
[+] Akses root diperoleh di perangkat {TARGET}
[!] Mengunduh arsip meme rahasia (69.420 file)
[+] Mengunci layar target ... 3.. 2.. 1..`;

/** warna baris berdasarkan prefix terminal */
function warnaBaris(l: string): string {
  const s = l.trimStart();
  if (s.startsWith("[+]")) return "#22c55e";
  if (s.startsWith("[*]")) return "#38bdf8";
  if (s.startsWith("[-]") || s.startsWith("[!]")) return "#f87171";
  if (s.startsWith("root@") || s.startsWith("$") || s.startsWith("#")) return "#a3e635";
  return "#4ade80";
}

interface Baris {
  segs: string[];
  totalChar: number;
  mulaiMs: number;
  durasiMs: number;
  warna: string;
}

/** PRNG deterministik kecil — hujan matrix terlihat acak tapi stabil per waktu. */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function ukurMono(size: number): number {
  if (typeof document === "undefined") return size * 0.6;
  const c = document.createElement("canvas");
  const ctx = c.getContext("2d");
  if (!ctx) return size * 0.6;
  ctx.font = `${size}px "Courier New", monospace`;
  return ctx.measureText("0").width || size * 0.6;
}

const FONT_BODY = (s: number) => `${s}px "Courier New", monospace`;
const FONT_BOLD = (s: number) => `700 ${s}px "Courier New", monospace`;

export default function HackerTerminalTool() {
  const [namaTarget, setNamaTarget] = useState("korban-prank");
  const [pesanAkhir, setPesanAkhir] = useState("AKSES DIBERIKAN");
  const [skrip, setSkrip] = useState(SKRIP_BAWAAN);
  const [kecepatan, setKecepatan] = useState(1);
  const [merekam, setMerekam] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mulaiRef = useRef<number>(performance.now());
  const { toast } = useToast();
  const dukunganVideo = canRecordCanvas();

  /* ---------- pra-hitung layout & timing (deterministik) ---------- */
  const LAYOUT = useMemo(() => {
    const bodyFont = 40;
    const lineH = 58;
    const charW = ukurMono(bodyFont);
    const termX = 60, termY = 250, termW = W - 120, termH = 1330;
    const pad = 34;
    const bodyW = termW - pad * 2;
    const bodyH = termH - 70 - pad;
    const maxChars = Math.max(12, Math.floor(bodyW / charW));
    const kapasitas = Math.max(4, Math.floor(bodyH / lineH));
    return { bodyFont, lineH, charW, termX, termY, termW, termH, pad, bodyW, bodyH, maxChars, kapasitas };
  }, []);

  const barisCache = useMemo(() => {
    const charMs = 26 / kecepatan;
    const jedaMs = 200 / kecepatan;
    const baris: Baris[] = [];
    let t = 0;
    for (const mentah of skrip.split("\n")) {
      const isi = mentah.replaceAll("{TARGET}", namaTarget || "target");
      if (!isi.trim()) {
        t += jedaMs;
        continue;
      }
      // hard-wrap ala terminal per maxChars
      const segs: string[] = [];
      for (let i = 0; i < isi.length; i += LAYOUT.maxChars) segs.push(isi.slice(i, i + LAYOUT.maxChars));
      const totalChar = isi.length;
      const durasiMs = totalChar * charMs + jedaMs;
      baris.push({ segs, totalChar, mulaiMs: t, durasiMs, warna: warnaBaris(isi) });
      t += durasiMs;
    }
    return { baris, durasiKetik: t, charMs };
  }, [skrip, namaTarget, kecepatan, LAYOUT]);

  const durasiTahan = 2800; // kartu akhir ditahan di akhir video
  const durasiTotal = barisCache.durasiKetik + durasiTahan;

  /* ---------- render satu frame pada waktu t (ms) ---------- */
  const render = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      if (canvas.width !== W || canvas.height !== H) {
        canvas.width = W;
        canvas.height = H;
      }
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const { bodyFont, lineH, termX, termY, termW, termH, pad, kapasitas } = LAYOUT;
      const { baris, durasiKetik, charMs } = barisCache;

      // latar hitam + hujan matrix
      ctx.fillStyle = "#010402";
      ctx.fillRect(0, 0, W, H);
      const karakter = "01<>#$%&*+=ABCDEF0123456789";
      ctx.globalAlpha = 0.16;
      ctx.fillStyle = "#00ff66";
      ctx.font = FONT_BODY(30);
      const rng = mulberry32(1337);
      for (let kol = 0; kol < 26; kol++) {
        const x = 30 + kol * 41 + rng() * 12;
        const cepat = 260 + rng() * 520;
        const basis = rng() * (H + 500);
        const yHead = ((basis + t * cepat) % (H + 500)) - 250;
        for (let i = 0; i < 7; i++) {
          const ch = karakter[Math.floor((kol * 7 + i * 3 + Math.floor(t / 110)) % karakter.length)];
          ctx.globalAlpha = i === 0 ? 0.5 : 0.13;
          ctx.fillText(ch, x, yHead - i * 34);
        }
      }
      ctx.globalAlpha = 1;

      // HUD atas
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      ctx.font = FONT_BOLD(30);
      ctx.fillStyle = "#22c55e";
      ctx.fillText("FanzzOS 6.9 — root shell (prank mode)", 60, 70);
      ctx.font = FONT_BODY(28);
      ctx.fillStyle = "#4ade80";
      ctx.fillText(`TARGET: ${namaTarget || "target"}`, 60, 118);
      ctx.fillText("IP: 127.0.0.1  UPLINK: 98%  ENC: AES-256", 60, 156);

      // jendela terminal
      ctx.fillStyle = "rgba(2,12,4,0.94)";
      roundRectPath(ctx, termX, termY, termW, termH, 26);
      ctx.fill();
      ctx.strokeStyle = "rgba(74,222,128,0.45)";
      ctx.lineWidth = 3;
      roundRectPath(ctx, termX, termY, termW, termH, 26);
      ctx.stroke();

      // header jendela
      ctx.save();
      roundRectPath(ctx, termX, termY, termW, termH, 26);
      ctx.clip();
      ctx.fillStyle = "rgba(34,197,94,0.14)";
      ctx.fillRect(termX, termY, termW, 70);
      const titik = ["#ef4444", "#f59e0b", "#22c55e"];
      titik.forEach((c, i) => {
        ctx.beginPath();
        ctx.arc(termX + 40 + i * 38, termY + 35, 13, 0, Math.PI * 2);
        ctx.fillStyle = c;
        ctx.fill();
      });
      ctx.font = FONT_BOLD(28);
      ctx.fillStyle = "#86efac";
      ctx.textAlign = "center";
      ctx.fillText("bash — root@fanzz: ~/prank_engine", termX + termW / 2, termY + 22);

      // isi terminal (scroll mengikuti baris terakhir)
      ctx.textAlign = "left";
      const mulaiY = termY + 70 + pad;
      const mulai = baris.filter((b) => b.mulaiMs <= t);
      const parsial = mulai.length ? mulai[mulai.length - 1] : null;
      const tampung = mulai.slice(-kapasitas);
      let y = mulaiY;
      for (const b of tampung) {
        const penuh = t >= b.mulaiMs + b.durasiMs;
        const ketik = penuh
          ? b.totalChar
          : Math.max(0, Math.floor(Math.max(0, t - b.mulaiMs) / charMs));
        ctx.fillStyle = b.warna;
        ctx.font = FONT_BODY(bodyFont);
        let terpakai = 0;
        for (const seg of b.segs) {
          const sisa = ketik - terpakai;
          if (sisa <= 0) break;
          ctx.fillText(seg.slice(0, sisa), termX + pad, y);
          terpakai += seg.length;
          y += lineH;
        }
        if (ketik < b.totalChar) {
          // kursor blok berkedip di posisi ketik
          const segIdx = Math.min(b.segs.length - 1, Math.floor(terpakai / Math.max(1, b.segs[0].length)));
          const offset = terpakai - segIdx * Math.max(1, b.segs[0]?.length ?? 1);
          if (Math.floor(t / 450) % 2 === 0) {
            ctx.fillStyle = "#bbf7d0";
            ctx.fillRect(termX + pad + offset * LAYOUT.charW, y - 6, 24, bodyFont + 4);
          }
          y += lineH; // baris parsial selesai digambar
          break; // baris berikut belum mulai
        }
      }

      // baris prompt hidup saat menunggu
      if (parsial && t >= parsial.mulaiMs + parsial.durasiMs && t < durasiKetik) {
        if (Math.floor(t / 450) % 2 === 0) {
          ctx.fillStyle = "#bbf7d0";
          ctx.fillRect(termX + pad, y - 6, 24, bodyFont + 4);
        }
      }

      // scanline CRT
      ctx.fillStyle = "rgba(0,0,0,0.16)";
      for (let sy = termY; sy < termY + termH; sy += 5) ctx.fillRect(termX, sy, termW, 2);
      ctx.restore();

      // vignette
      const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.28, W / 2, H / 2, H * 0.75);
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(0,0,0,0.55)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, W, H);

      // status bar bawah
      const detik = Math.min(durasiKetik / 1000, t / 1000);
      const mm = String(Math.floor(detik / 60)).padStart(2, "0");
      const ss = String(Math.floor(detik % 60)).padStart(2, "0");
      ctx.font = FONT_BOLD(30);
      ctx.fillStyle = Math.floor(t / 600) % 2 === 0 ? "#ef4444" : "#7f1d1d";
      ctx.beginPath();
      ctx.arc(78, 1795, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#4ade80";
      ctx.font = FONT_BODY(30);
      ctx.fillText(`REC ${mm}:${ss}`, 106, 1778);
      ctx.textAlign = "right";
      ctx.fillStyle = "#166534";
      ctx.fillText("PRANK — simulasi hiburan, bukan serangan nyata", W - 60, 1778);
      ctx.textAlign = "left";

      // kartu akhir: pesan besar bergaya glitch
      if (t > durasiKetik + 250) {
        const muncul = Math.min(1, (t - durasiKetik - 250) / 420);
        ctx.fillStyle = `rgba(0,4,1,${0.82 * muncul})`;
        ctx.fillRect(0, 0, W, H);
        const jit = Math.sin(t / 60) * 3 * (1 - Math.min(1, (t - durasiKetik) / 3000));
        const cx = W / 2 + jit;
        const cy = H / 2;
        const bw = 820, bh = 420;
        ctx.save();
        ctx.globalAlpha = muncul;
        ctx.strokeStyle = "#4ade80";
        ctx.lineWidth = 4;
        roundRectPath(ctx, cx - bw / 2, cy - bh / 2, bw, bh, 30);
        ctx.stroke();
        ctx.strokeStyle = "rgba(74,222,128,0.4)";
        ctx.lineWidth = 2;
        roundRectPath(ctx, cx - bw / 2 - 16, cy - bh / 2 - 16, bw + 32, bh + 32, 36);
        ctx.stroke();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.font = FONT_BOLD(104);
        ctx.fillStyle = "#86efac";
        ctx.shadowColor = "#22c55e";
        ctx.shadowBlur = 36;
        const pesan = (pesanAkhir || "AKSES DIBERIKAN").toUpperCase();
        // pecah baris bila panjang
        const maxPesan = 11;
        const potong: string[] = [];
        for (let i = 0; i < pesan.length; i += maxPesan) potong.push(pesan.slice(i, i + maxPesan));
        potong.slice(0, 3).forEach((p, i) => ctx.fillText(p, cx, cy - 60 + i * 110));
        ctx.shadowBlur = 0;
        ctx.font = FONT_BODY(34);
        ctx.fillStyle = "#4ade80";
        ctx.fillText(`root@${(namaTarget || "target").toLowerCase()} — koneksi ditutup`, cx, cy + bh / 2 - 90);
        ctx.font = FONT_BODY(26);
        ctx.fillStyle = "#166534";
        ctx.fillText("— prank buatan FanzzTools Studio —", cx, cy + bh / 2 - 40);
        ctx.restore();
      }
    },
    [LAYOUT, barisCache, namaTarget, pesanAkhir],
  );

  /* ---------- pratinjau hidup: animasi berulang ---------- */
  useEffect(() => {
    mulaiRef.current = performance.now();
    let raf = 0;
    const loop = () => {
      const t = (performance.now() - mulaiRef.current) % Math.max(2600, durasiTotal);
      render(t);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [render, durasiTotal]);

  const unduhPng = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // bingkai final: kartu akhir tampil penuh
    render(durasiTotal - 400);
    downloadCanvas(canvas, "fanzz-hacker-prank.png");
    pushHistory("studio", { id: `hackerprank-${Date.now()}`, title: "Hacker Prank video generator", subtitle: `target: ${namaTarget}` });
    toast({ title: "Gambar terminal hacker terunduh", description: "PNG 1080 x 1920 — bingkai AKSES DIBERIKAN." });
  };

  const unduhVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas || merekam) return;
    if (!dukunganVideo) {
      toast({ title: "Perekaman video tidak didukung", description: "Peramban ini belum mendukung perekaman kanvas — unduh versi PNG.", variant: "destructive" });
      return;
    }
    setMerekam(true);
    try {
      const blob = await recordCanvas(canvas, durasiTotal, (t) => render(t));
      downloadBlob(blob, "fanzz-hacker-prank.webm");
      pushHistory("studio", { id: `hackerprank-${Date.now()}`, title: "Hacker Prank video generator", subtitle: `video ${Math.round(durasiTotal / 1000)} dtk — target: ${namaTarget}` });
      toast({ title: "Video prank terunduh!", description: `WebM ${Math.round(durasiTotal / 1000)} detik — murni animasi, tanpa eksekusi command nyata.` });
    } catch {
      toast({ title: "Gagal merekam video", variant: "destructive" });
    } finally {
      setMerekam(false);
    }
  };

  const estimasiDetik = Math.round(durasiTotal / 1000);

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div className="mb-1.5 flex items-center gap-2 text-xs font-bold">
            <User className="h-3.5 w-3.5 text-emerald-400" /> Nama target (prank)
          </div>
          <Input value={namaTarget} onChange={(e) => setNamaTarget(e.target.value)} maxLength={24} placeholder="nama temanmu" className="border-[var(--surface-line)] bg-background text-sm" />
          <p className="mt-1 text-[10px] text-muted-foreground">Ditampilkan di HUD & kartu akhir. Tulis {`{TARGET}`} di skrip untuk menyisipkan otomatis.</p>
        </div>
        <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div className="mb-1.5 flex items-center gap-2 text-xs font-bold">
            <Sparkles className="h-3.5 w-3.5 text-emerald-400" /> Pesan akhir
          </div>
          <Input value={pesanAkhir} onChange={(e) => setPesanAkhir(e.target.value)} maxLength={40} placeholder="AKSES DIBERIKAN" className="border-[var(--surface-line)] bg-background text-sm" />
          <p className="mt-1 text-[10px] text-muted-foreground">Kartu raksasa yang muncul setelah "proses hack" selesai.</p>
        </div>
      </div>

      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="mb-1.5 flex items-center gap-2 text-xs font-bold">
          <Binary className="h-3.5 w-3.5 text-emerald-400" /> Skrip terminal (satu baris = satu aksi)
        </div>
        <Textarea
          value={skrip}
          onChange={(e) => setSkrip(e.target.value)}
          placeholder="root@fanzz:~# ..."
          className="min-h-[170px] resize-none border-[var(--surface-line)] bg-background font-mono text-xs leading-relaxed"
          maxLength={3000}
        />
        <p className="mt-1 text-[10px] text-muted-foreground">
          Awali [+] hijau, [*] biru, [-]/[!] merah, perintah root@… hijau limau. Baris [####] otomatis jadi progress bar yang mengisi saat mengetik.
        </p>
      </div>

      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="mb-1 flex items-center justify-between text-xs font-bold">
          <span>Kecepatan ketik</span>
          <span className="text-muted-foreground">{kecepatan.toFixed(1)}x • video ±{estimasiDetik} dtk</span>
        </div>
        <input type="range" min={0.5} max={3} step={0.1} value={kecepatan} onChange={(e) => setKecepatan(Number(e.target.value))} className="w-full" />
      </div>

      {/* pratinjau animasi langsung */}
      {skrip.trim() ? (
        <div className="mx-auto w-full max-w-[340px]">
          <canvas ref={canvasRef} className="block h-auto w-full rounded-2xl border border-emerald-500/25 shadow-2xl shadow-emerald-500/10" />
          <p className="mt-1.5 text-center text-[10px] text-muted-foreground">Pratinjau animasi berjalan langsung — video direkam dengan durasi yang sama.</p>
        </div>
      ) : (
        <EmptyState icon={<Binary className="h-10 w-10" />} title="Skrip masih kosong" desc="Tulis beberapa baris untuk melihat terminal hacker palsunya." />
      )}

      <div className="flex flex-wrap gap-2">
        <Button onClick={unduhPng} disabled={!skrip.trim()} className="h-11 flex-1 bg-gradient-to-r from-emerald-500 to-green-600 font-bold text-black">
          <Download className="mr-2 h-4 w-4" /> Unduh PNG (bingkai akhir)
        </Button>
        {dukunganVideo && (
          <Button onClick={unduhVideo} disabled={!skrip.trim() || merekam} variant="outline" className="h-11 border-[var(--surface-line)] font-bold">
            {merekam ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Film className="mr-2 h-4 w-4" />}
            {merekam ? `Merekam ${estimasiDetik} dtk…` : "Unduh Video Prank"}
          </Button>
        )}
      </div>

      <p className="text-center text-[10px] leading-relaxed text-muted-foreground">
        🎭 Hiburan semata — terminal ini PURA-PURA. Tidak ada command sungguhan yang dijalankan, tidak ada koneksi ke perangkat mana pun.
      </p>
    </div>
  );
}
