"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, TextInput, DownloadButton } from "./iqc-shared";
import { ensureFonts, downloadCanvas, paintGradient, WALLPAPERS, fitFontLines, drawLinesCentered, hexToRgb } from "./lib";

/** Wallpaper Generator (IQC) — gradien siap pakai + teks nama/tanda tangan. */

export default function WallpaperTool() {
  const [preset, setPreset] = useState(0);
  const [c1, setC1] = useState("#ef4444");
  const [c2, setC2] = useState("#131318");
  const [angle, setAngle] = useState(150);
  const [teks, setTeks] = useState("Fanzz");
  const [posisi, setPosisi] = useState<"tengah" | "bawah" | "atas">("tengah");
  const [ukuran, setUkuran] = useState(1080);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const W = 1080;
    const H = ukuran === 1080 ? 1920 : 1080; // ponsel / desktop
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    await ensureFonts(["inter", "playfair"]);
    paintGradient(ctx, W, H, c1, c2, angle);
    // kilau lembut
    const g = ctx.createRadialGradient(W / 2, H * (posisi === "atas" ? 0.25 : 0.75), 60, W / 2, H / 2, H * 0.75);
    g.addColorStop(0, "rgba(255,255,255,0.14)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    // bintik bokeh
    let seed = 777;
    const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    for (let i = 0; i < 26; i++) {
      const x = rnd() * W;
      const y = rnd() * H;
      const r = 8 + rnd() * 46;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(255,255,255,${0.03 + rnd() * 0.07})`;
      ctx.fill();
    }
    // teks
    if (teks.trim()) {
      const { size, lines } = fitFontLines(ctx, teks.slice(0, 60), W * 0.84, H * 0.5, (s) => `800 ${s}px Inter`, 190, 40, 1.14);
      const cy = posisi === "tengah" ? H / 2 : posisi === "bawah" ? H * 0.82 : H * 0.18;
      const [r, gg, b] = hexToRgb(c2);
      const terang = (r + gg + b) / 3 > 150;
      ctx.shadowColor = "rgba(0,0,0,0.35)";
      ctx.shadowBlur = 24;
      ctx.shadowOffsetY = 6;
      ctx.fillStyle = terang ? "rgba(20,20,30,0.85)" : "rgba(255,255,255,0.94)";
      drawLinesCentered(ctx, lines, W / 2, cy, size, 1.14);
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
      ctx.shadowOffsetY = 0;
    }
    // tanda air kecil
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.font = "500 22px 'Archivo Narrow'";
    ctx.textAlign = "center";
    ctx.fillText("Testing Generator • By : FanzzTools™", W / 2, H - 40);
    ctx.textAlign = "left";
  }, [c1, c2, angle, teks, posisi, ukuran]);

  useEffect(() => {
    render();
  }, [render]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <ToolCard title="Wallpaper Generator" hint="Gradien estetik siap jadi wallpaper HP atau desktop.">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {WALLPAPERS.map((w, i) => (
            <button
              key={w.name}
              onClick={() => {
                setPreset(i);
                setC1(w.c1);
                setC2(w.c2);
                setAngle(w.angle);
              }}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                preset === i && c1 === w.c1 ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              <span className="h-3 w-3 rounded-full" style={{ background: `linear-gradient(135deg, ${w.c1}, ${w.c2})` }} />
              {w.name}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <label className="flex flex-1 items-center gap-2 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs">
            <input type="color" value={c1} onChange={(e) => setC1(e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" />
            <span className="font-mono text-[10px] text-muted-foreground">{c1}</span>
          </label>
          <label className="flex flex-1 items-center gap-2 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs">
            <input type="color" value={c2} onChange={(e) => setC2(e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" />
            <span className="font-mono text-[10px] text-muted-foreground">{c2}</span>
          </label>
        </div>
        <Label>Arah gradien: {angle}°</Label>
        <input type="range" min={0} max={360} value={angle} onChange={(e) => setAngle(Number(e.target.value))} className="w-full" />
        <Label>Teks (opsional)</Label>
        <TextInput value={teks} onChange={setTeks} maxLength={60} placeholder="Nama / kata motivate" />
        <Label>Posisi teks</Label>
        <div className="flex gap-1.5">
          {(["atas", "tengah", "bawah"] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPosisi(p)}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold capitalize transition ${
                posisi === p ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              {p}
            </button>
          ))}
        </div>
        <Label>Ukuran</Label>
        <div className="flex gap-1.5">
          {[
            [1080, "Ponsel 9:16"],
            [1920, "Desktop 16:9"],
          ].map(([v, l]) => (
            <button
              key={v}
              onClick={() => setUkuran(v as number)}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                ukuran === v ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              {l}
            </button>
          ))}
        </div>
        <DownloadButton onClick={() => downloadCanvas(canvasRef.current!, `fanzz-wallpaper-${ukuran}.png`)} />
      </ToolCard>

      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className="max-h-[520px] w-auto max-w-full rounded-xl shadow-2xl ring-1 ring-border/40" />
      </div>
    </div>
  );
}
