"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ensureFonts, downloadCanvas, wrapLines,
} from "@/components/tools/image-studio/lib";
import { PenLine, Download, CalendarDays } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * Nulis — menulis teks dengan font tulisan tangan di atas kertas buku tulis
 * bergaris biru + margin merah, lengkap dengan nama & kelas seperti PR sekolah.
 */

const W = 1240;
const H = 1754; // A4 150dpi
const MARGIN_X = 118;
const ATAS = 210;
const SPASI = 58; // jarak antar garis biru

const HARI_ID = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const BULAN_ID = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

interface OpsiNulis {
  nama: string;
  kelas: string;
  hari: string;
  tanggal: string;
  isi: string;
  tinta: "biru" | "hitam";
}

function gambarNulis(canvas: HTMLCanvasElement, o: OpsiNulis) {
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  // kertas
  ctx.fillStyle = "#fdfdf7";
  ctx.fillRect(0, 0, W, H);

  // garis biru horizontal
  ctx.strokeStyle = "#a8c8e8";
  ctx.lineWidth = 2;
  for (let y = ATAS; y <= H - 60; y += SPASI) {
    ctx.beginPath();
    ctx.moveTo(40, y);
    ctx.lineTo(W - 40, y);
    ctx.stroke();
  }

  // margin merah vertikal
  ctx.strokeStyle = "#e89a9a";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(MARGIN_X, 30);
  ctx.lineTo(MARGIN_X, H - 30);
  ctx.stroke();

  const tinta = o.tinta === "biru" ? "#1a3f9e" : "#26262a";
  const tintaRedup = o.tinta === "biru" ? "rgba(26,63,158,0.85)" : "rgba(38,38,42,0.85)";

  // kepala: nama (baris 1) & kelas (baris 2) di kiri, hari/tanggal di kanan atas
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "#333";
  ctx.font = "600 34px Inter, -apple-system, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("Nama:", 160, 118);
  ctx.fillText("Kelas:", 160, 176);
  ctx.fillStyle = tintaRedup;
  ctx.font = "600 42px Caveat, cursive";
  ctx.fillText(o.nama || "……………………", 286, 118);
  ctx.fillText(o.kelas || "………", 286, 176);

  // hari & tanggal kanan atas
  ctx.textAlign = "right";
  ctx.fillStyle = "#333";
  ctx.font = "600 34px Inter, -apple-system, sans-serif";
  ctx.fillText("Hari/Tanggal:", W - 480, 118);
  ctx.fillStyle = tintaRedup;
  ctx.font = "600 42px Caveat, cursive";
  const tgl = `${o.hari}, ${o.tanggal}`.trim().replace(/^[,\s]+/, "");
  ctx.fillText(tgl || "……………", W - 60, 118);

  // isi tulisan tangan — duduk tepat DI ATAS garis biru
  const ukuran = 46;
  ctx.font = `600 ${ukuran}px Caveat, cursive`;
  const lebarTulis = W - MARGIN_X - 90;
  const baris = wrapLines(ctx, o.isi.trim(), lebarTulis);

  // mulai dari baris ke-3 kertas, dua baris pertama dipakai kepala
  let indexBaris = 3;
  ctx.fillStyle = tinta;
  ctx.textAlign = "left";
  for (const b of baris) {
    if (indexBaris * SPASI + ATAS > H - 90) break; // muat satu halaman
    ctx.fillText(b, MARGIN_X + 34, ATAS + indexBaris * SPASI - 12);
    indexBaris++;
  }
}

export default function NulisTool() {
  const [nama, setNama] = useState("");
  const [kelas, setKelas] = useState("");
  const [hari, setHari] = useState(() => HARI_ID[new Date().getDay()]);
  const [tanggal, setTanggal] = useState(() => {
    const d = new Date();
    return `${d.getDate()} ${BULAN_ID[d.getMonth()]} ${d.getFullYear()}`;
  });
  const [isi, setIsi] = useState(
    "Baiklah, hari ini aku berjanji akan mengerjakan semua tugas tepat waktu dan tidak menunda-nunda lagi.",
  );
  const [tinta, setTinta] = useState<"biru" | "hitam">("biru");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    void ensureFonts(["caveat", "inter"]);
  }, []);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    gambarNulis(canvas, { nama, kelas, hari, tanggal, isi, tinta });
  }, [nama, kelas, hari, tanggal, isi, tinta]);

  useEffect(() => {
    render();
  }, [render]);

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    downloadCanvas(canvas, "fanzz-nulis.png");
    pushHistory("studio", {
      id: `nulis-${Date.now()}`,
      title: "Kertas nulis",
      subtitle: `${nama.trim() || "tanpa nama"} • ${isi.trim().slice(0, 40)}`,
    });
    toast({ title: "Kertas nulis terunduh", description: "1240 x 1754 piksel (A4 150 dpi)." });
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Nama</p>
          <Input value={nama} onChange={(e) => setNama(e.target.value)} maxLength={30} className="h-9 text-xs" placeholder="nama lengkap" />
        </div>
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Kelas</p>
          <Input value={kelas} onChange={(e) => setKelas(e.target.value)} maxLength={12} className="h-9 text-xs" placeholder="IX-A" />
        </div>
        <div>
          <p className="mb-1 flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
            <CalendarDays className="h-3 w-3" /> Hari
          </p>
          <Input value={hari} onChange={(e) => setHari(e.target.value)} maxLength={10} className="h-9 text-xs" />
        </div>
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Tanggal</p>
          <Input value={tanggal} onChange={(e) => setTanggal(e.target.value)} maxLength={30} className="h-9 text-xs" />
        </div>
      </div>

      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <p className="mb-1 flex items-center gap-1.5 text-xs font-bold">
          <PenLine className="h-3.5 w-3.5 text-sky-400" />
          Isi tulisan
        </p>
        <Textarea
          value={isi}
          onChange={(e) => setIsi(e.target.value)}
          className="min-h-[140px] resize-none border-[var(--surface-line)] bg-background text-sm"
          maxLength={900}
          placeholder="Tulis apa pun — surat, janji, catatan..."
        />
        <p className="mt-1 text-[10px] text-muted-foreground">
          Maksimal satu halaman A4 ({isi.length}/900 karakter). Tulisan duduk tepat di atas garis buku.
        </p>
      </div>

      <div>
        <p className="mb-1.5 text-xs font-bold text-muted-foreground">Warna tinta</p>
        <div className="grid grid-cols-2 gap-2">
          {([
            { id: "biru", label: "Pulpen Biru" },
            { id: "hitam", label: "Pulpen Hitam" },
          ] as const).map((t) => (
            <button
              key={t.id}
              onClick={() => setTinta(t.id)}
              className={`rounded-xl px-3 py-2 text-xs font-bold transition ${
                tinta === t.id
                  ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                  : "bg-secondary hover:bg-secondary/70"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[360px]">
        <canvas ref={canvasRef} className="block h-auto w-full rounded-2xl border border-[var(--surface-line)] bg-white shadow-xl" />
      </motion.div>

      <Button onClick={unduh} className="h-11 w-full bg-gradient-to-r from-sky-500 to-blue-600 font-bold">
        <Download className="mr-2 h-4 w-4" />
        Unduh Kertas Nulis
      </Button>
    </div>
  );
}
