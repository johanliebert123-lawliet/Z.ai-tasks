"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, DownloadButton } from "./iqc-shared";
import {
  ensureFonts, downloadCanvas, fitFontLines, drawLinesCentered,
  loadImageFromFile, roundRectPath, wrapLines,
} from "./lib";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";
import { Upload, Loader2, Zap, Smartphone, ShieldCheck, Check } from "lucide-react";

/**
 * TikTok Generator (Cyber-Update #9 — REDESAIN sesuai 2 screenshot referensi).
 *
 * Mode 1 "Kartu Quote": kartu kutipan vertikal ala TikTok (tetap ada).
 *
 * Mode 2 "Chat TikTok DM" — identik screenshot 09-08 09.29 (20/30):
 *  - kartu putih membulat di atas latar slate gelap #0F172A
 *  - gelembung MASUK putih + bayangan lembut + ekor kiri + AVATAR BULAT
 *    di sampingnya; gelembung KELUAR lavender #E0D4FC + ekor kanan
 *  - PIL REAKSI melayang ❤️ 😂 😢 👍 😡 🤔 di atas pesan masuk pertama
 *    (seperti pesan "Anjai" di screenshot)
 *  - bar bawah persis referensi: reaksi cepat ❤️😂👍👆 + badge Streak Pet +
 *    ikon video ungu, pil "Kirim pesan..." + ikon kamera kiri +
 *    galeri/stiker/mikrofon kanan
 *
 * Editor mengikuti screenshot 09.29(30): chip FAST RENDER / MOBILE UI /
 * FAKE TIKTOK CHAT / ONLINE (hijau, fungsional) + kolom USERNAME / PESAN
 * CHAT + kartu FOTO PROFIL (tombol unggah bulat cyan + "FOTO TERPILIH ✓").
 * Field yang bisa diedit user: nama pengirim, isi pesan, foto profil.
 */

const W = 1080;
const H = 2160;

const KUNCI = "Testing Generator • By : FanzzTools™";

/** pil reaksi persis screenshot (TikTok DM): ❤️ 😂 😢 👍 😡 🤔 */
const REAKSI_TIKTOK = ["❤️", "😂", "😢", "👍", "😡", "🤔"];

interface PesanChat {
  teks: string;
  self: boolean;
}

function parseChat(teks: string): PesanChat[] {
  return teks
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => (l.startsWith(">") ? { teks: l.replace(/^>\s*/, ""), self: true } : { teks: l, self: false }));
}

function gambarAvatarTiktok(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  foto: HTMLImageElement | null,
  inisial: string,
) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  if (foto) {
    const s = Math.max((r * 2) / foto.naturalWidth, (r * 2) / foto.naturalHeight);
    const dw = foto.naturalWidth * s;
    const dh = foto.naturalHeight * s;
    ctx.drawImage(foto, cx - dw / 2, cy - dh / 2, dw, dh);
  } else {
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    g.addColorStop(0, "#25F4EE");
    g.addColorStop(0.5, "#ffffff");
    g.addColorStop(1, "#FE2C55");
    ctx.fillStyle = g;
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    ctx.fillStyle = "#111";
    ctx.font = `700 ${Math.round(r)}px Inter, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(inisial.toUpperCase(), cx, cy + r * 0.05);
  }
  ctx.restore();
}

/** pil reaksi melayang (6 emoji) — kapsul putih + bayangan lembut. */
function gambarPilReaksi(ctx: CanvasRenderingContext2D, cx: number, cy: number) {
  const emojiSize = 46;
  const pillW = REAKSI_TIKTOK.length * (emojiSize + 28) + 32;
  const pillH = emojiSize + 32;
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.18)"; ctx.shadowBlur = 26; ctx.shadowOffsetY = 8;
  ctx.fillStyle = "#FFFFFF";
  roundRectPath(ctx, cx - pillW / 2, cy - pillH / 2, pillW, pillH, pillH / 2);
  ctx.fill();
  ctx.restore();
  ctx.font = `${emojiSize}px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
  ctx.textAlign = "center"; ctx.textBaseline = "middle";
  REAKSI_TIKTOK.forEach((e, i) => {
    ctx.fillText(e, cx - pillW / 2 + 16 + (emojiSize + 28) * (i + 0.5), cy + 2);
  });
}

function gambarChatTiktok(
  canvas: HTMLCanvasElement,
  o: { nama: string; pesan: PesanChat[]; avatar: HTMLImageElement | null; jam: string; online: boolean },
) {
  const ukuranFont = 42;
  const padBubble = 34;
  const jarak = 26;
  const lebarMaks = W * 0.6;

  // ukur tinggi
  const ctxUkur = document.createElement("canvas").getContext("2d")!;
  ctxUkur.font = `500 ${ukuranFont}px Inter, -apple-system, sans-serif`;
  const terukur = o.pesan.map((m) => wrapLines(ctxUkur, m.teks, lebarMaks - padBubble * 2));

  let tinggi = 320; // status bar
  tinggi += 190; // header TikTok
  tinggi += 90; // jarak + ruang pil reaksi
  for (let i = 0; i < o.pesan.length; i++) {
    tinggi += terukur[i].length * (ukuranFont * 1.36) + padBubble * 2 + jarak;
  }
  tinggi += 380; // bar bawah (reaksi cepat + input) + bawah
  const Hc = Math.max(H, tinggi);

  canvas.width = W;
  canvas.height = Hc;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  /* ---- latar luar (slate gelap) + kartu putih membulat (per screenshot) ---- */
  ctx.fillStyle = "#0F172A";
  ctx.fillRect(0, 0, W, Hc);

  const cardX = 26;
  const cardY = 24;
  const cardW = W - 52;
  roundRectPath(ctx, cardX, cardY, cardW, Hc - 48, 48);
  ctx.fillStyle = "#ffffff";
  ctx.fill();

  /* ---- status bar iPhone (di dalam kartu) ---- */
  ctx.fillStyle = "#ffffff";
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.font = "700 40px Inter, -apple-system, sans-serif";
  ctx.fillText(o.jam, cardX + 56, 84);
  const sx = cardX + cardW - 420;
  for (let i = 0; i < 4; i++) {
    const bh = 10 + i * 9;
    ctx.fillStyle = "#111";
    roundRectPath(ctx, sx + i * 14, 90 - bh, 8, bh, 4);
    ctx.fill();
  }
  const wx = cardX + cardW - 310;
  ctx.strokeStyle = "#111";
  ctx.lineWidth = 7;
  ctx.lineCap = "round";
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(wx + 12, 92, 6 + i * 11, Math.PI * 1.25, Math.PI * 1.75);
    ctx.stroke();
  }
  ctx.fillStyle = "#111";
  ctx.beginPath();
  ctx.arc(wx + 12, 90, 5, 0, Math.PI * 2);
  ctx.fill();
  const bx = cardX + cardW - 210;
  ctx.strokeStyle = "rgba(0,0,0,0.4)";
  ctx.lineWidth = 5;
  roundRectPath(ctx, bx, 62, 88, 46, 12);
  ctx.stroke();
  ctx.fillStyle = "#111";
  roundRectPath(ctx, bx + 6, 68, 74, 34, 8);
  ctx.fill();

  /* ---- header TikTok: kembali + avatar + nama + status + titik tiga ---- */
  const headY = 170;
  ctx.strokeStyle = "#111";
  ctx.lineWidth = 10;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(cardX + 116, headY - 28);
  ctx.lineTo(cardX + 78, headY + 4);
  ctx.lineTo(cardX + 116, headY + 36);
  ctx.stroke();
  gambarAvatarTiktok(ctx, cardX + 210, headY + 4, 62, o.avatar, (o.nama || "T").charAt(0));
  ctx.textAlign = "left";
  ctx.fillStyle = "#111111";
  ctx.font = "800 52px Inter, -apple-system, sans-serif";
  ctx.fillText((o.nama || "Nama").slice(0, 20), cardX + 296, headY - 8);
  ctx.fillStyle = "#8a8a8e";
  ctx.font = "500 32px Inter, -apple-system, sans-serif";
  ctx.fillText(o.online ? "aktif sekarang" : "Aktif 1 j lalu", cardX + 296, headY + 46);
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(cardX + cardW - 80 - i * 26, headY + 4, 8, 0, Math.PI * 2);
    ctx.fillStyle = "#6b6b70";
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(0,0,0,0.06)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cardX + 30, headY + 110);
  ctx.lineTo(cardX + cardW - 30, headY + 110);
  ctx.stroke();

  /* ---- gelembung chat (masuk: putih + avatar bulat; keluar: lavender) ---- */
  const bubbleInfo: Array<{ x: number; y: number; w: number; h: number; self: boolean }> = [];
  let y = headY + 190;
  ctx.font = `500 ${ukuranFont}px Inter, -apple-system, sans-serif`;
  for (let i = 0; i < o.pesan.length; i++) {
    const m = o.pesan[i];
    const baris = terukur[i];
    const tebalFont = ukuranFont * 1.36;
    const tinggiBubble = baris.length * tebalFont + padBubble * 2 - 4;
    const lebarBubble =
      baris.reduce((mm, l) => Math.max(mm, ctx.measureText(l).width), 0) + padBubble * 2 + 130;

    const avatarR = 34;
    const bx = m.self ? cardX + cardW - 60 - lebarBubble : cardX + 60 + avatarR * 2 + 18;
    const r = 36;

    // avatar bulat di kiri gelembung masuk (per screenshot — samping "Anjai")
    if (!m.self) {
      gambarAvatarTiktok(ctx, cardX + 60 + avatarR, y + tinggiBubble / 2, avatarR, o.avatar, (o.nama || "T").charAt(0));
    }

    // warna per screenshot: keluar LAVENDER #E0D4FC, masuk PUTIH + bayangan lembut
    ctx.save();
    ctx.shadowColor = m.self ? "rgba(76,29,149,0.16)" : "rgba(0,0,0,0.10)";
    ctx.shadowBlur = 14; ctx.shadowOffsetY = 4;
    ctx.fillStyle = m.self ? "#E0D4FC" : "#FFFFFF";
    const rr = (x2: number, y2: number, w2: number, h2: number, rads: [number, number, number, number]) => {
      const [tl, tr, br, bl] = rads;
      ctx.moveTo(x2 + tl, y2);
      ctx.lineTo(x2 + w2 - tr, y2);
      ctx.arcTo(x2 + w2, y2, x2 + w2, y2 + tr, tr);
      ctx.lineTo(x2 + w2, y2 + h2 - br);
      ctx.arcTo(x2 + w2, y2 + h2, x2 + w2 - br, y2 + h2, br);
      ctx.lineTo(x2 + bl, y2 + h2);
      ctx.arcTo(x2, y2 + h2, x2, y2 + h2 - bl, bl);
      ctx.lineTo(x2, y2 + tl);
      ctx.arcTo(x2, y2, x2 + tl, y2, tl);
      ctx.closePath();
    };
    ctx.beginPath();
    if (m.self) {
      rr(bx, y, lebarBubble, tinggiBubble, [r, r, 12, r]); // ekor kecil kanan-bawah
    } else {
      rr(bx, y, lebarBubble, tinggiBubble, [r, r, r, 12]); // ekor kecil kiri-bawah
    }
    ctx.fill();
    ctx.restore();

    // teks
    ctx.fillStyle = "#111111";
    ctx.textAlign = "left";
    const mulaiY = y + padBubble - 2 + (baris.length - 1) * (tebalFont / 2);
    baris.forEach((l, bi) => ctx.fillText(l, bx + padBubble, mulaiY + bi * tebalFont));

    // waktu kecil di pojok gelembung
    ctx.font = "500 26px Inter, -apple-system, sans-serif";
    ctx.fillStyle = "#8a8a8e";
    ctx.textAlign = "right";
    ctx.fillText(o.jam, bx + lebarBubble - padBubble + 6, y + tinggiBubble - 22);
    ctx.font = `500 ${ukuranFont}px Inter, -apple-system, sans-serif`;

    bubbleInfo.push({ x: bx, y, w: lebarBubble, h: tinggiBubble, self: m.self });
    y += tinggiBubble + jarak;
  }

  /* ---- PIL REAKSI di atas pesan masuk pertama (per screenshot) ---- */
  const idxMasuk = bubbleInfo.findIndex((b) => !b.self);
  if (idxMasuk >= 0) {
    const t = bubbleInfo[idxMasuk];
    const cy = Math.max(headY + 170, t.y - 58);
    gambarPilReaksi(ctx, t.x + t.w / 2, cy);
  }

  /* ---- bar bawah persis screenshot: reaksi cepat + input + ikon ---- */
  const by0 = Hc - 300;
  ctx.strokeStyle = "rgba(0,0,0,0.06)";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cardX + 30, by0);
  ctx.lineTo(cardX + cardW - 30, by0);
  ctx.stroke();

  // baris reaksi cepat: ❤️ 😂 👍 👆 + Streak Pet + ikon video ungu
  ctx.font = `44px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
  ctx.textAlign = "left"; ctx.textBaseline = "middle";
  const quick = ["❤️", "😂", "👍", "👆"];
  quick.forEach((e, i) => ctx.fillText(e, cardX + 76 + i * 78, by0 + 52));

  // badge Streak Pet (hewan emas + label)
  const spx = cardX + 76 + 4 * 78, spy = by0 + 24, spw = 230, sph = 56;
  ctx.fillStyle = "#F4F0FA";
  roundRectPath(ctx, spx, spy, spw, sph, sph / 2);
  ctx.fill();
  ctx.font = `40px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
  ctx.fillText("🐹", spx + 14, spy + sph / 2 + 2);
  ctx.fillStyle = "#6D28D9";
  ctx.font = "700 27px Inter";
  ctx.fillText("Streak Pet", spx + 62, spy + sph / 2 + 1);

  // ikon video ungu (kartu + segitiga play)
  const vx = spx + spw + 28;
  ctx.fillStyle = "#7C3AED";
  roundRectPath(ctx, vx, spy, 68, 56, 15);
  ctx.fill();
  ctx.fillStyle = "#FFFFFF";
  ctx.beginPath();
  ctx.moveTo(vx + 26, spy + 15); ctx.lineTo(vx + 26, spy + 41); ctx.lineTo(vx + 48, spy + 28);
  ctx.closePath();
  ctx.fill();

  // pil input "Kirim pesan..." + ikon kamera kiri + galeri/stiker/mic kanan
  const ix = cardX + 130, iy = by0 + 104, iw = cardW - 330, ih = 80;
  ctx.fillStyle = "#F0F0F3";
  roundRectPath(ctx, ix, iy, iw, ih, ih / 2);
  ctx.fill();
  ctx.fillStyle = "#9AA0A6";
  ctx.font = "400 32px Inter, -apple-system, sans-serif";
  ctx.fillText("Kirim pesan...", ix + 36, iy + ih / 2);

  // kamera (kiri pil)
  const abu = "#8A8A8E";
  ctx.strokeStyle = abu; ctx.lineWidth = 3.4; ctx.lineCap = "round"; ctx.lineJoin = "round";
  roundRectPath(ctx, cardX + 60, iy + 24, 44, 38, 9);
  ctx.stroke();
  ctx.beginPath(); ctx.arc(cardX + 82, iy + 43, 8.5, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(cardX + 70, iy + 24); ctx.lineTo(cardX + 76, iy + 16); ctx.lineTo(cardX + 88, iy + 16); ctx.lineTo(cardX + 93, iy + 24);
  ctx.stroke();

  // galeri → stiker → mikrofon (kanan pil)
  const rx0 = ix + iw + 26;
  ctx.strokeStyle = abu; ctx.lineWidth = 3.2;
  roundRectPath(ctx, rx0, iy + 18, 46, 46, 10);
  ctx.stroke();
  ctx.beginPath(); ctx.arc(rx0 + 14, iy + 31, 4.5, 0, Math.PI * 2); ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(rx0 + 7, iy + 55); ctx.lineTo(rx0 + 20, iy + 41); ctx.lineTo(rx0 + 29, iy + 49);
  ctx.lineTo(rx0 + 36, iy + 43); ctx.lineTo(rx0 + 40, iy + 48);
  ctx.stroke();
  ctx.beginPath(); ctx.arc(rx0 + 88, iy + 41, 22, 0, Math.PI * 2); ctx.stroke();
  ctx.fillStyle = abu;
  ctx.beginPath(); ctx.arc(rx0 + 81, iy + 35, 2.8, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(rx0 + 95, iy + 35, 2.8, 0, Math.PI * 2); ctx.fill();
  ctx.beginPath(); ctx.arc(rx0 + 88, iy + 44, 8.5, 0.15, Math.PI - 0.15); ctx.stroke();
  ctx.lineWidth = 3.6;
  roundRectPath(ctx, rx0 + 142, iy + 17, 19, 30, 9);
  ctx.stroke();
  ctx.beginPath(); ctx.arc(rx0 + 151.5, iy + 47, 13.5, 0, Math.PI); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(rx0 + 151.5, iy + 60); ctx.lineTo(rx0 + 151.5, iy + 66); ctx.stroke();

  // home indicator + tanda air
  ctx.fillStyle = "rgba(0,0,0,0.75)";
  roundRectPath(ctx, W / 2 - 150, Hc - 42, 300, 10, 5);
  ctx.fill();
  ctx.fillStyle = "rgba(15,23,42,0.5)";
  ctx.font = "500 22px 'Archivo Narrow'";
  ctx.textAlign = "center";
  ctx.fillText(KUNCI, W / 2, Hc - 64);
  ctx.textAlign = "left";
}

/* =================== mode kartu quote (asli, tetap) =================== */

function gambarQuote(
  ctx: CanvasRenderingContext2D,
  teks: string,
  handle: string,
  lagu: string,
  bg: string,
) {
  const Wq = 1080;
  const Hq = 1920;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, Wq, Hq);
  ctx.textBaseline = "middle";

  ctx.strokeStyle = "rgba(255,255,255,0.07)";
  ctx.lineWidth = 3;
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(70 + i * 34, 260);
    ctx.lineTo(70 + i * 34, Hq - 420);
    ctx.stroke();
  }

  ctx.fillStyle = "rgba(255,255,255,0.22)";
  ctx.font = "800 220px Inter";
  ctx.fillText("\u201C", 84, 320);

  const { size, lines } = fitFontLines(
    ctx,
    teks.slice(0, 300) || "tulis kutipanmu di sini",
    Wq - 240,
    Hq * 0.44,
    (s) => `700 ${s}px Inter`,
    108,
    40,
    1.22,
  );
  ctx.fillStyle = "#ffffff";
  drawLinesCentered(ctx, lines, Wq / 2, Hq / 2 - 120, size, 1.22);

  ctx.font = "800 52px Inter";
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  ctx.fillText((handle || "@fanzztools").slice(0, 26), Wq / 2, Hq - 480);

  ctx.font = "500 34px 'Archivo Narrow'";
  ctx.fillStyle = "rgba(255,255,255,0.6)";
  const laguTeks = (lagu || "musik asli").slice(0, 44);
  ctx.fillText(`${laguTeks} ♪`, Wq / 2, Hq - 410);
  ctx.fillStyle = "rgba(255,255,255,0.18)";
  ctx.fillRect(180, Hq - 360, Wq - 360, 8);
  const g = ctx.createLinearGradient(180, 0, Wq - 180, 0);
  g.addColorStop(0, "#fe2c55");
  g.addColorStop(1, "#25f4ee");
  ctx.fillStyle = g;
  ctx.fillRect(180, Hq - 360, (Wq - 360) * 0.42, 8);

  ctx.beginPath();
  ctx.arc(Wq / 2, Hq - 280, 56, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(30,30,34,0.9)";
  ctx.fill();
  ctx.strokeStyle = "rgba(255,255,255,0.25)";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = "#ffffff";
  ctx.font = "600 40px Inter";
  ctx.fillText("♪", Wq / 2, Hq - 274);

  ctx.fillStyle = "rgba(255,255,255,0.35)";
  ctx.font = "500 22px 'Archivo Narrow'";
  ctx.fillText("Testing Generator • By : FanzzTools™", Wq / 2, Hq - 60);
  ctx.textAlign = "left";
}

/* =================== komponen =================== */

export default function TiktokQuoteTool() {
  const [mode, setMode] = useState<"quote" | "chat">("quote");
  const [teks, setTeks] = useState("jangan bandingkan awalmu\ndengan puncak orang lain");
  const [handle, setHandle] = useState("@fanzztools");
  const [lagu, setLagu] = useState("Sunset Lover — Petit Biscuit");
  const [bg, setBg] = useState("#000000");
  /** mode chat — field yang bisa diedit (persis referensi): nama, pesan, foto */
  const [nama, setNama] = useState("JoJohan");
  const [chatTeks, setChatTeks] = useState("anjai\n> gila sih lo\n> keren banget 😭");
  /** jam otomatis dari perangkat (tidak lagi input manual — editor mengikuti referensi) */
  const [jam] = useState(() => new Date().toTimeString().slice(0, 5).replace(":", "."));
  const [online, setOnline] = useState(true);
  /** toggle editor ala referensi: FAST RENDER & MOBILE UI (fungsional ringan) */
  const [fastRender, setFastRender] = useState(true);
  const [mobileUi, setMobileUi] = useState(true);
  const [avatar, setAvatar] = useState<HTMLImageElement | null>(null);
  const [busy, setBusy] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const pilihAvatar = async (file: File | undefined) => {
    if (!file) return;
    setBusy(true);
    try {
      const img = await loadImageFromFile(file);
      setAvatar(img);
      toast({ title: "Foto profil terpasang!", description: "Tampil di header + samping gelembung masuk." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    if (!fastRender) await ensureFonts(["inter", "archivo"]);
    if (mode === "quote") {
      canvas.width = 1080;
      canvas.height = 1920;
      gambarQuote(ctx, teks, handle, lagu, bg);
    } else {
      const daftar = parseChat(chatTeks);
      if (!daftar.length) {
        canvas.width = 1080;
        canvas.height = 1920;
        gambarQuote(ctx, "tulis baris chat di kolom teks dulu ya", handle, lagu, bg);
        return;
      }
      gambarChatTiktok(canvas, { nama, pesan: daftar, avatar, jam, online });
    }
  }, [mode, teks, handle, lagu, bg, nama, chatTeks, avatar, jam, online, fastRender]);

  useEffect(() => {
    render();
  }, [render]);

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const name = mode === "quote" ? "fanzz-tiktok-quote.png" : "fanzz-tiktok-chat.png";
    downloadCanvas(canvas, name);
    pushHistory("studio", {
      id: `tt-${Date.now()}`,
      title: mode === "quote" ? "TikTok Quote" : "Chat TikTok DM",
      subtitle: (mode === "quote" ? teks : chatTeks).trim().slice(0, 60) || "tanpa teks",
    });
  };

  return (
    <div className="space-y-4">
      {/* pilih mode */}
      <div className="grid grid-cols-2 gap-2">
        {([
          { id: "quote", label: "Kartu Quote" },
          { id: "chat", label: "Chat TikTok DM" },
        ] as const).map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`rounded-xl px-3 py-2.5 text-xs font-bold transition ${
              mode === m.id
                ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                : "bg-secondary hover:bg-secondary/70"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {mode === "quote" ? (
        <ToolCard title="TikTok Quote" hint="Kartu kutipan vertikal ala TikTok — pas untuk repost status.">
          <Label>Kutipan (\n = baris baru)</Label>
          <textarea
            value={teks}
            rows={4}
            maxLength={300}
            onChange={(e) => setTeks(e.target.value)}
            className="mb-1 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-red-400/50"
          />
          <Label>Handle</Label>
          <input
            value={handle}
            maxLength={26}
            onChange={(e) => setHandle(e.target.value)}
            className="mb-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-red-400/50"
          />
          <Label>Judul lagu</Label>
          <input
            value={lagu}
            maxLength={44}
            onChange={(e) => setLagu(e.target.value)}
            className="mb-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-red-400/50"
          />
          <Label>Warna latar</Label>
          <div className="flex gap-1.5">
            {["#000000", "#111114", "#1a1a2e", "#231b2e"].map((c) => (
              <button
                key={c}
                onClick={() => setBg(c)}
                className={`h-8 w-10 rounded-lg border transition ${bg === c ? "border-red-400 ring-2 ring-red-400/40" : "border-border"}`}
                style={{ background: c }}
                aria-label={`warna ${c}`}
              />
            ))}
            <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-8 w-10 cursor-pointer rounded-lg border border-border bg-transparent p-0" />
          </div>
        </ToolCard>
      ) : (
        <ToolCard title="Fake TikTok Chat" hint="Tiruan DM TikTok sesuai screenshot referensi — bubble putih/lavender, pil reaksi, dan input bar ikut referensi. Awali baris dengan &gt; untuk gelembung lavender milikmu.">
          {/* chip pengaturan — persis referensi editor */}
          <div className="mb-3 mt-1 flex flex-wrap gap-1.5">
            <button
              onClick={() => setFastRender((v) => !v)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-extrabold transition ${
                fastRender ? "bg-primary/20 text-primary ring-1 ring-primary/40" : "bg-secondary text-muted-foreground"
              }`}
            >
              <Zap className="h-3 w-3" /> FAST RENDER
            </button>
            <button
              onClick={() => setMobileUi((v) => !v)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-extrabold transition ${
                mobileUi ? "bg-primary/20 text-primary ring-1 ring-primary/40" : "bg-secondary text-muted-foreground"
              }`}
            >
              <Smartphone className="h-3 w-3" /> MOBILE UI
            </button>
            <span className="flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-3 py-1.5 text-[10px] font-extrabold text-emerald-400 ring-1 ring-emerald-500/30">
              <ShieldCheck className="h-3 w-3" /> FAKE TIKTOK CHAT
            </span>
            <button
              onClick={() => setOnline((v) => !v)}
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-extrabold transition ${
                online ? "bg-emerald-500/20 text-emerald-400 ring-1 ring-emerald-500/40" : "bg-secondary text-muted-foreground"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${online ? "bg-emerald-400" : "bg-muted-foreground"}`} /> ONLINE
            </button>
          </div>

          <Label>Username</Label>
          <input
            value={nama}
            maxLength={20}
            onChange={(e) => setNama(e.target.value)}
            placeholder="JoJohan"
            className="mb-1 w-full rounded-xl border border-border/60 bg-[#F3F4F6] px-3 py-2.5 text-xs font-bold text-black outline-none focus:border-cyan-500/60"
          />

          <Label>Pesan Chat</Label>
          <textarea
            value={chatTeks}
            rows={5}
            maxLength={600}
            onChange={(e) => setChatTeks(e.target.value)}
            placeholder={"anjai\n> balasan kamu"}
            className="mb-1 w-full rounded-xl border border-border/60 bg-[#1F2937] p-2.5 text-xs text-white outline-none focus:border-cyan-500/60"
          />
          <p className="text-[9.5px] text-muted-foreground">Tanpa awalan = pesan masuk (putih, ada avatar + pil reaksi). Awali &gt; = pesanmu (lavender).</p>

          <Label>Foto Profil</Label>
          {/* kartu foto profil — persis referensi: avatar + tombol unggah bulat cyan + status */}
          <div className="flex items-center gap-3 rounded-xl border border-border/60 bg-secondary/40 p-3">
            {avatar ? (
              <img src={avatar.src} alt="foto profil" className="h-16 w-16 shrink-0 rounded-2xl object-cover ring-2 ring-cyan-500/40" />
            ) : (
              <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-[#25F4EE] via-white to-[#FE2C55] text-xl font-black text-black">
                {(nama || "T").charAt(0).toUpperCase()}
              </span>
            )}
            <label className="flex h-12 w-12 shrink-0 cursor-pointer items-center justify-center rounded-full bg-gradient-to-br from-cyan-500 to-teal-500 text-white shadow-lg shadow-cyan-500/30 transition active:scale-90">
              {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <Upload className="h-5 w-5" />}
              <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihAvatar(e.target.files?.[0])} />
            </label>
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1 text-[11px] font-extrabold text-emerald-400">
                {avatar ? <Check className="h-3.5 w-3.5" /> : null}
                {avatar ? "FOTO TERPILIH" : "BELUM ADA FOTO"}
              </p>
              <p className="text-[9.5px] text-muted-foreground">{avatar ? "Klik lagi untuk ganti" : "Klik tombol cyan untuk unggah"}</p>
            </div>
            {avatar && (
              <button onClick={() => setAvatar(null)} className="shrink-0 rounded-xl bg-secondary px-2.5 py-2 text-[11px] font-bold text-muted-foreground">
                hapus
              </button>
            )}
          </div>
        </ToolCard>
      )}

      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className={`w-auto rounded-xl shadow-2xl ring-1 ring-border/40 ${mode === "chat" && mobileUi ? "max-h-[560px] max-w-full" : "max-h-[560px] max-w-full"}`} />
      </div>

      <DownloadButton onClick={unduh} />
    </div>
  );
}
