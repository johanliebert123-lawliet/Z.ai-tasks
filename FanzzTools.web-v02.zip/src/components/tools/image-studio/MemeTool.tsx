"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { EmptyState } from "@/components/tools/shared";
import {
  ensureFonts, loadImageFromFile, downloadCanvas, fitFontLines,
} from "@/components/tools/image-studio/lib";
import { Upload, Download, ImagePlus, Type, Trash2 } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * Generator meme klasik: teks tebal ber-outline hitam di atas & bawah gambar.
 * Plus mode "Meme Teks" (tanpa gambar) dengan latar warna.
 */

interface OpsiMeme {
  atas: string;
  bawah: string;
  kapital: boolean;
  font: "anton" | "bebas";
  warnaTeks: string;
  warnaGaris: string;
  tebalOutline: number; // 0.05 - 0.14 relatif ukuran font
  ukuranRelatif: number; // 0.08 - 0.16 relatif lebar
}

function namaFont(f: "anton" | "bebas") {
  return f === "anton" ? "Anton, Impact, sans-serif" : "'Bebas Neue', Anton, Impact, sans-serif";
}

function gambarMemeGambar(
  canvas: HTMLCanvasElement,
  img: HTMLImageElement,
  o: OpsiMeme,
) {
  const maksLebar = 1440;
  const skala = Math.min(1, maksLebar / img.naturalWidth);
  const w = Math.round(img.naturalWidth * skala);
  const h = Math.round(img.naturalHeight * skala);
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.drawImage(img, 0, 0, w, h);

  const teksAtas = o.kapital ? o.atas.toUpperCase() : o.atas;
  const teksBawah = o.kapital ? o.bawah.toUpperCase() : o.bawah;

  const gambarTeks = (teks: string, posisi: "atas" | "bawah") => {
    if (!teks.trim()) return;
    const maxW = w * 0.94;
    const ukuranAwal = Math.round(w * o.ukuranRelatif);
    const { size, lines } = fitFontLines(
      ctx,
      teks,
      maxW,
      h * 0.42,
      (s) => `400 ${s}px ${namaFont(o.font)}`,
      ukuranAwal,
      18,
      1.08,
    );
    const lh = size * 1.08;
    ctx.font = `400 ${size}px ${namaFont(o.font)}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    ctx.strokeStyle = o.warnaGaris;
    ctx.lineWidth = Math.max(2, size * o.tebalOutline);
    const mulaiY =
      posisi === "atas"
        ? h * 0.055 + lh / 2
        : h - h * 0.055 - lines.length * lh + lh / 2;
    lines.forEach((l, i) => {
      const y = mulaiY + i * lh;
      ctx.strokeText(l, w / 2, y);
      ctx.fillStyle = o.warnaTeks;
      ctx.fillText(l, w / 2, y);
    });
  };

  gambarTeks(teksAtas, "atas");
  gambarTeks(teksBawah, "bawah");
}

function gambarMemeTeks(
  canvas: HTMLCanvasElement,
  teks: string,
  o: OpsiMeme,
  bg: string,
  preset: "persegi" | "potret" | "lebar",
) {
  const dim =
    preset === "persegi" ? [1080, 1080] : preset === "potret" ? [1080, 1350] : [1200, 675];
  const [w, h] = dim;
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  const isi = (o.kapital ? teks.toUpperCase() : teks).trim() || "TULIS SESUATU";
  const { lines, size } = fitFontLines(
    ctx,
    isi,
    w * 0.86,
    h * 0.7,
    (s) => `400 ${s}px ${namaFont(o.font)}`,
    Math.round(w * 0.12),
    20,
    1.1,
  );
  const lh = size * 1.1;
  ctx.font = `400 ${size}px ${namaFont(o.font)}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.lineJoin = "round";
  ctx.strokeStyle = o.warnaGaris;
  ctx.lineWidth = Math.max(2, size * o.tebalOutline);
  const mulaiY = h / 2 - ((lines.length - 1) * lh) / 2;
  lines.forEach((l, i) => {
    ctx.strokeText(l, w / 2, mulaiY + i * lh);
    ctx.fillStyle = o.warnaTeks;
    ctx.fillText(l, w / 2, mulaiY + i * lh);
  });
}

export default function MemeTool() {
  const [mode, setMode] = useState<"gambar" | "teks">("gambar");
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [atas, setAtas] = useState("");
  const [bawah, setBawah] = useState("");
  const [teks, setTeks] = useState("ketika kode berjalan sempurna di komputer orang lain");
  const [kapital, setKapital] = useState(true);
  const [font, setFont] = useState<"anton" | "bebas">("anton");
  const [warnaTeks, setWarnaTeks] = useState("#FFFFFF");
  const [warnaGaris, setWarnaGaris] = useState("#000000");
  const [tebalOutline, setTebalOutline] = useState(0.08);
  const [ukuranRelatif, setUkuranRelatif] = useState(0.11);
  const [bgTeks, setBgTeks] = useState("#1A1A2E");
  const [presetTeks, setPresetTeks] = useState<"persegi" | "potret" | "lebar">("persegi");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    void ensureFonts(["anton", "bebas"]);
  }, []);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const opsi: OpsiMeme = { atas, bawah, kapital, font, warnaTeks, warnaGaris, tebalOutline, ukuranRelatif };
    if (mode === "gambar") {
      if (img) gambarMemeGambar(canvas, img, opsi);
      else {
        canvas.width = 1080;
        canvas.height = 720;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;
        ctx.fillStyle = "#15151f";
        ctx.fillRect(0, 0, 1080, 720);
        ctx.fillStyle = "rgba(255,255,255,0.35)";
        ctx.font = "600 34px Inter, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("Unggah gambar untuk mulai membuat meme", 540, 360);
      }
    } else {
      gambarMemeTeks(canvas, teks, opsi, bgTeks, presetTeks);
    }
     
  }, [mode, img, atas, bawah, teks, kapital, font, warnaTeks, warnaGaris, tebalOutline, ukuranRelatif, bgTeks, presetTeks]);

  useEffect(() => {
    render();
  }, [render]);

  const pilihGambar = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Berkas bukan gambar", variant: "destructive" });
      return;
    }
    try {
      const gambar = await loadImageFromFile(file);
      setImg(gambar);
      setMode("gambar");
    } catch {
      toast({ title: "Gagal memuat gambar", variant: "destructive" });
    }
  };

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas || (mode === "gambar" && !img)) return;
    downloadCanvas(canvas, "fanzz-meme.png");
    pushHistory("studio", {
      id: `meme-${Date.now()}`,
      title: "Meme diunduh",
      subtitle: (mode === "gambar" ? [atas, bawah].filter(Boolean).join(" / ") : teks).slice(0, 60) || "meme",
    });
    toast({ title: "Meme terunduh", description: `${canvas.width} x ${canvas.height} piksel.` });
  };

  return (
    <div className="space-y-4">
      {/* mode */}
      <div className="grid grid-cols-2 gap-2">
        {([
          { id: "gambar", label: "Meme Gambar" },
          { id: "teks", label: "Meme Teks Saja" },
        ] as const).map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`rounded-xl px-3 py-2.5 text-xs font-bold transition ${
              mode === m.id
                ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                : "bg-secondary hover:bg-secondary/70"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* unggah */}
      {mode === "gambar" && (
        <div className="flex gap-2">
          <label className="flex flex-1 cursor-pointer items-center gap-3 rounded-xl bg-gradient-to-r from-red-500/15 to-red-700/15 p-3 ring-1 ring-red-400/20 transition hover:from-red-500/25 hover:to-red-700/25">
            <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihGambar(e.target.files?.[0])} />
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-md">
              <Upload className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-bold">{img ? "Ganti Gambar" : "Unggah Gambar"}</p>
              <p className="text-[11px] text-muted-foreground">Template apa pun jadi meme</p>
            </div>
          </label>
          {img && (
            <Button variant="outline" size="icon" className="h-auto w-12 border-[var(--surface-line)]" onClick={() => setImg(null)} aria-label="Buang gambar">
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      )}

      {/* teks */}
      {mode === "gambar" ? (
        <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">Teks Atas</p>
            <Input value={atas} onChange={(e) => setAtas(e.target.value)} maxLength={80} className="h-9 text-xs" placeholder="ketika..." />
          </div>
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">Teks Bawah</p>
            <Input value={bawah} onChange={(e) => setBawah(e.target.value)} maxLength={80} className="h-9 text-xs" placeholder="...dan kemudian" />
          </div>
        </div>
      ) : (
        <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">Teks Meme</p>
            <Input value={teks} onChange={(e) => setTeks(e.target.value)} maxLength={140} className="h-9 text-xs" />
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold">Ukuran kanvas</p>
            <Select value={presetTeks} onValueChange={(v) => setPresetTeks(v as typeof presetTeks)}>
              <SelectTrigger className="h-9 w-40 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="persegi">Persegi 1:1</SelectItem>
                <SelectItem value="potret">Potret 4:5</SelectItem>
                <SelectItem value="lebar">Lebar 16:9</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <label className="flex items-center gap-2 text-xs font-bold">
            Warna latar
            <input
              type="color"
              value={bgTeks}
              onChange={(e) => setBgTeks(e.target.value)}
              className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
            />
          </label>
        </div>
      )}

      {/* gaya */}
      <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Type className="h-3.5 w-3.5 text-red-400" />
            <p className="text-xs font-bold">Font</p>
          </div>
          <Select value={font} onValueChange={(v) => setFont(v as "anton" | "bebas")}>
            <SelectTrigger className="h-9 w-36 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="anton">Anton (klasik)</SelectItem>
              <SelectItem value="bebas">Bebas Neue</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-xs font-bold">HURUF KAPITAL</p>
          <Switch checked={kapital} onCheckedChange={setKapital} />
        </div>
        <div className="flex items-center gap-4">
          <label className="flex items-center gap-2 text-xs font-bold">
            Teks
            <input
              type="color"
              value={warnaTeks}
              onChange={(e) => setWarnaTeks(e.target.value)}
              className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
            />
          </label>
          <label className="flex items-center gap-2 text-xs font-bold">
            Garis tepi
            <input
              type="color"
              value={warnaGaris}
              onChange={(e) => setWarnaGaris(e.target.value)}
              className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
            />
          </label>
        </div>
        <div>
          <div className="mb-1.5 flex justify-between text-[10px] font-bold text-muted-foreground">
            <span>Tebal garis tepi</span>
            <span className="tabular-nums text-red-400">{tebalOutline.toFixed(2)}</span>
          </div>
          <Slider min={0.03} max={0.14} step={0.005} value={[tebalOutline]} onValueChange={(v) => setTebalOutline(v[0])} />
        </div>
        {mode === "gambar" && (
          <div>
            <div className="mb-1.5 flex justify-between text-[10px] font-bold text-muted-foreground">
              <span>Ukuran teks</span>
              <span className="tabular-nums text-red-400">{Math.round(ukuranRelatif * 100)}%</span>
            </div>
            <Slider min={0.07} max={0.16} step={0.005} value={[ukuranRelatif]} onValueChange={(v) => setUkuranRelatif(v[0])} />
          </div>
        )}
      </div>

      {/* pratinjau */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[440px]">
        <canvas ref={canvasRef} className="block h-auto w-full rounded-2xl border border-[var(--surface-line)] shadow-xl" />
      </motion.div>

      {mode === "gambar" && !img && (
        <EmptyState icon={<ImagePlus className="h-10 w-10" />} title="Belum ada gambar" desc="Unggah gambar untuk membuat meme dengan teks klasik atas-bawah." />
      )}

      <Button
        onClick={unduh}
        disabled={mode === "gambar" && !img}
        className="h-11 w-full bg-gradient-to-r from-red-500 to-red-700 font-bold"
      >
        <Download className="mr-2 h-4 w-4" />
        Unduh Meme
      </Button>
    </div>
  );
}
