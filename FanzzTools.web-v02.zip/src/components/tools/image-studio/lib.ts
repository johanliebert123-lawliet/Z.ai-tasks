"use client";

/**
 * Studio Gambar — pustaka utilitas kanvas bersama.
 * Semua generator berjalan 100% di sisi klien (foto tidak pernah diunggah ke server),
 * sehingga cepat, privat, dan tidak bergantung pada API eksternal.
 */

// ---------------------------------------------------------------- FONT GOOGLE

const FONT_DEFS: Record<string, { css: string; load: string[] }> = {
  anton: { css: "Anton", load: ["400 32px Anton"] },
  archivo: {
    css: "Archivo+Narrow:ital,wght@0,500;0,600;0,700",
    load: ["700 32px 'Archivo Narrow'", "500 32px 'Archivo Narrow'"],
  },
  bebas: { css: "Bebas+Neue", load: ["400 32px 'Bebas Neue'"] },
  caveat: {
    css: "Caveat:wght@500;600;700",
    load: ["600 32px Caveat", "700 32px Caveat", "500 32px Caveat"],
  },
  inter: {
    css: "Inter:wght@300;400;500;600;700;800",
    load: ["400 32px Inter", "500 32px Inter", "600 32px Inter", "700 32px Inter", "300 32px Inter", "800 32px Inter"],
  },
  playfair: {
    css: "Playfair+Display:ital,wght@0,600;0,700;1,600",
    load: ["700 32px 'Playfair Display'", "600 32px 'Playfair Display'", "italic 600 32px 'Playfair Display'"],
  },
};

const injected = new Set<string>();

/** Memuat font Google (sekali per keluarga) lalu menunggu hingga siap dipakai kanvas. */
export async function ensureFonts(keys: string[]): Promise<void> {
  if (typeof document === "undefined") return;
  const baru = keys.filter((k) => FONT_DEFS[k] && !injected.has(k));
  if (baru.length) {
    const href = `https://fonts.googleapis.com/css2?${baru.map((k) => `family=${FONT_DEFS[k].css}`).join("&")}&display=swap`;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = href;
    document.head.appendChild(link);
    baru.forEach((k) => injected.add(k));
  }
  await Promise.all(
    keys.flatMap((k) => FONT_DEFS[k]?.load ?? []).map((spec) =>
      Promise.race([
        document.fonts.load(spec).catch(() => {}),
        new Promise((r) => setTimeout(r, 2500)),
      ]),
    ),
  );
}

// ---------------------------------------------------------------- KANVAS DASAR

export function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

/** Patah baris otomatis (word-wrap); kata super panjang dipotong per karakter. Menghormati \n. */
export function wrapLines(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  const out: string[] = [];
  for (const paragraf of text.split("\n")) {
    const kata = paragraf.split(/\s+/).filter(Boolean);
    if (!kata.length) {
      out.push("");
      continue;
    }
    let baris = "";
    for (const k of kata) {
      const coba = baris ? `${baris} ${k}` : k;
      if (ctx.measureText(coba).width <= maxWidth || !baris) {
        if (ctx.measureText(coba).width > maxWidth && !baris) {
          // satu kata melebihi lebar — potong per karakter
          let potong = "";
          for (const ch of k) {
            if (ctx.measureText(potong + ch).width > maxWidth && potong) break;
            potong += ch;
          }
          out.push(potong);
          baris = "";
          continue;
        }
        baris = coba;
      } else {
        out.push(baris);
        baris = k;
      }
    }
    if (baris) out.push(baris);
  }
  return out;
}

/**
 * Kecilkan ukuran font sampai seluruh teks muat dalam kotak.
 * fontFn mengembalikan string ctx.font untuk ukuran tertentu.
 */
export function fitFontLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  maxHeight: number,
  fontFn: (size: number) => string,
  startSize: number,
  minSize = 10,
  lineHeightRatio = 1.2,
): { size: number; lines: string[] } {
  let size = startSize;
  let lines: string[] = [];
  while (size >= minSize) {
    ctx.font = fontFn(size);
    lines = wrapLines(ctx, text, maxWidth);
    const tinggi = lines.length * size * lineHeightRatio;
    const terlebar = lines.reduce((m, l) => Math.max(m, ctx.measureText(l).width), 0);
    if (tinggi <= maxHeight && terlebar <= maxWidth) break;
    size = Math.max(minSize, size - Math.max(1, Math.round(size * 0.06)));
  }
  ctx.font = fontFn(size);
  lines = wrapLines(ctx, text, maxWidth);
  return { size, lines };
}

/** Menggambar baris teks rata-tengah sebagai satu blok (posisi tengah blok di cy). */
export function drawLinesCentered(
  ctx: CanvasRenderingContext2D,
  lines: string[],
  cx: number,
  cy: number,
  size: number,
  lineHeightRatio = 1.2,
) {
  const lh = size * lineHeightRatio;
  const startY = cy - ((lines.length - 1) * lh) / 2;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  lines.forEach((l, i) => ctx.fillText(l, cx, startY + i * lh));
}

/** Menggambar gambar dengan mode cover (isi penuh, potong kelebihan) + zoom & offset. */
export function drawCover(
  ctx: CanvasRenderingContext2D,
  img: CanvasImageSource,
  iw: number,
  ih: number,
  x: number,
  y: number,
  w: number,
  h: number,
  zoom = 1,
  offX = 0.5,
  offY = 0.5,
) {
  const skala = Math.max(w / iw, h / ih) * zoom;
  const dw = iw * skala;
  const dh = ih * skala;
  const dx = x + (w - dw) * offX;
  const dy = y + (h - dh) * offY;
  ctx.drawImage(img, dx, dy, dw, dh);
}

// ---------------------------------------------------------------- UNDUH & FILE

export function downloadCanvas(canvas: HTMLCanvasElement, filename: string) {
  canvas.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 800);
  }, "image/png");
}

export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Gambar gagal dimuat"));
    };
    img.src = url;
  });
}

// ---------------------------------------------------------------- WARNA & GRADIEN

export function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "").trim();
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const n = parseInt(full.slice(0, 6) || "000000", 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHex(r: number, g: number, b: number): string {
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0");
  return `#${c(r)}${c(g)}${c(b)}`;
}

/** Gradien linear dua warna dengan sudut. */
export function paintGradient(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  c1: string,
  c2: string,
  angleDeg = 135,
) {
  const rad = (angleDeg * Math.PI) / 180;
  const cx = w / 2;
  const cy = h / 2;
  const len = Math.abs(w * Math.cos(rad)) + Math.abs(h * Math.sin(rad));
  const g = ctx.createLinearGradient(
    cx - (Math.cos(rad) * len) / 2,
    cy - (Math.sin(rad) * len) / 2,
    cx + (Math.cos(rad) * len) / 2,
    cy + (Math.sin(rad) * len) / 2,
  );
  g.addColorStop(0, c1);
  g.addColorStop(1, c2);
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

export const WALLPAPERS: Array<{ name: string; c1: string; c2: string; angle: number }> = [
  { name: "Senja", c1: "#ff9a6b", c2: "#7b2d8f", angle: 160 },
  { name: "Samudra", c1: "#2193b0", c2: "#0c1b3a", angle: 160 },
  { name: "Hutan", c1: "#134e35", c2: "#0a1f18", angle: 140 },
  { name: "Malam", c1: "#232526", c2: "#000000", angle: 150 },
  { name: "Permen", c1: "#ff9ec4", c2: "#5f6fff", angle: 130 },
  { name: "Ember", c1: "#f83600", c2: "#fee140", angle: 120 },
  { name: "Ungu Fanzz", c1: "#ef4444", c2: "#131318", angle: 150 },
  { name: "Monokrom", c1: "#e0e0e0", c2: "#3a3a3a", angle: 140 },
];

export const STORY_GRADIENTS: Array<{ name: string; c1: string; c2: string; angle: number }> = [
  { name: "Senja", c1: "#ff7e5f", c2: "#7b2d8f", angle: 160 },
  { name: "Lembayung", c1: "#8e2de2", c2: "#4a00e0", angle: 150 },
  { name: "Samudra", c1: "#2193b0", c2: "#11235a", angle: 160 },
  { name: "Hutan", c1: "#0f9b8e", c2: "#0b3d2e", angle: 140 },
  { name: "Bara", c1: "#c31432", c2: "#240b36", angle: 150 },
  { name: "Permen", c1: "#ee9ca7", c2: "#5f6fff", angle: 130 },
  { name: "Pasar Malam", c1: "#fc466b", c2: "#3f5efb", angle: 140 },
  { name: "Pekat", c1: "#141414", c2: "#000000", angle: 150 },
  { name: "Karamel", c1: "#f7971e", c2: "#8e3a10", angle: 130 },
  { name: "Mint Es", c1: "#a8ff78", c2: "#0f5132", angle: 140 },
];

// ---------------------------------------------------------------- REKAM VIDEO KANVAS

/** Mengecek apakah perekaman kanvas (canvas.captureStream + MediaRecorder) didukung. */
export function canRecordCanvas(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof HTMLCanvasElement !== "undefined" &&
    typeof HTMLCanvasElement.prototype.captureStream === "function" &&
    typeof window.MediaRecorder !== "undefined" &&
    (() => {
      try {
        return MediaRecorder.isTypeSupported("video/webm;codecs=vp9") || MediaRecorder.isTypeSupported("video/webm");
      } catch {
        return false;
      }
    })()
  );
}

export interface RecordOptions {
  fps?: number;
  mimeType?: string;
}

/**
 * Merekam animasi kanvas menjadi berkas .webm.
 * `drawFrame(t)` dipanggil berulang (t dalam milidetik) hingga durasi selesai.
 * Mengembalikan Blob video.
 */
export async function recordCanvas(
  canvas: HTMLCanvasElement,
  durationMs: number,
  drawFrame: (t: number) => void,
  opts: RecordOptions = {},
): Promise<Blob> {
  const fps = opts.fps ?? 25;
  const mime = opts.mimeType ?? (MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" : "video/webm");
  const stream = canvas.captureStream(fps);
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4_000_000 });
  const potongan: Blob[] = [];
  rec.ondataavailable = (e) => e.data.size > 0 && potongan.push(e.data);
  const selesai = new Promise<Blob>((resolve) => {
    rec.onstop = () => resolve(new Blob(potongan, { type: mime }));
  });
  rec.start();
  const mulai = performance.now();
  // render awal supaya frame pertama tidak kosong
  drawFrame(0);
  await new Promise<void>((resolve) => {
    const loop = () => {
      const t = performance.now() - mulai;
      drawFrame(Math.min(t, durationMs));
      if (t < durationMs) requestAnimationFrame(loop);
      else resolve();
    };
    requestAnimationFrame(loop);
  });
  // jeda kecil agar frame terakhir ikut terekam
  await new Promise((r) => setTimeout(r, 350));
  rec.stop();
  stream.getTracks().forEach((t) => t.stop());
  return selesai;
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 800);
}
