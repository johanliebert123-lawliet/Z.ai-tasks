"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ensureFonts, downloadCanvas, paintGradient, fitFontLines, drawLinesCentered, STORY_GRADIENTS,
} from "@/components/tools/image-studio/lib";
import { Quote, Download, AtSign, Sparkles } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * ISC — Story Card: kartu kutipan vertikal 1080x1920 bergaya cerita IG/WA.
 * Latar gradien pilihan, teks tengah otomatis menyesuaikan ukuran, handle & kaki kartu opsional.
 */

const W = 1080;
const H = 1920;

export default function StoryCardTool() {
  const [teks, setTeks] = useState(
    "hari yang berat tetap layak diakhiri dengan senyum kecil dan secangkir teh hangat",
  );
  const [handle, setHandle] = useState("");
  const [kaki, setKaki] = useState("");
  const [gradienIdx, setGradienIdx] = useState(0);
  const [kustom, setKustom] = useState<{ c1: string; c2: string } | null>(null);
  const [fontTebal, setFontTebal] = useState(true);
  const [kapitalAwal, setKapitalAwal] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    void ensureFonts(["inter"]);
  }, []);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const g = kustom ?? { c1: STORY_GRADIENTS[gradienIdx].c1, c2: STORY_GRADIENTS[gradienIdx].c2, angle: STORY_GRADIENTS[gradienIdx].angle };
    paintGradient(ctx, W, H, g.c1, g.c2, g.angle);
    // lapisan gelap halus agar teks putih selalu terbaca
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(0, 0, W, H);

    const bobot = fontTebal ? 800 : 500;
    const isi = kapitalAwal ? teks.toUpperCase() : teks;

    // handle atas (opsional)
    if (handle.trim()) {
      ctx.font = "600 44px Inter, -apple-system, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.92)";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const rapi = handle.trim().startsWith("@") ? handle.trim() : `@${handle.trim()}`;
      ctx.fillText(rapi, W / 2, 210);
    }

    // teks utama — mengecil otomatis sampai muat
    const { lines, size } = fitFontLines(
      ctx,
      isi.trim() || "tulis kutipan Anda",
      W * 0.8,
      H * 0.52,
      (s) => `${bobot} ${s}px Inter, -apple-system, sans-serif`,
      110,
      34,
      1.3,
    );
    ctx.fillStyle = "#ffffff";
    ctx.shadowColor = "rgba(0,0,0,0.35)";
    ctx.shadowBlur = 28;
    ctx.shadowOffsetY = 8;
    drawLinesCentered(ctx, lines, W / 2, H / 2, size, 1.3);
    ctx.shadowColor = "transparent";
    ctx.shadowBlur = 0;
    ctx.shadowOffsetY = 0;

    // ornamen kutipan kecil di atas teks
    ctx.font = "700 90px Inter, -apple-system, sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.4)";
    ctx.textAlign = "center";
    ctx.fillText("\u201C", W / 2, H / 2 - Math.min(H * 0.3, lines.length * size * 0.75) - 40);

    // kaki kartu (opsional)
    if (kaki.trim()) {
      ctx.font = "500 38px Inter, -apple-system, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      ctx.textAlign = "center";
      ctx.fillText(kaki.trim(), W / 2, H - 150);
    }
  }, [teks, handle, kaki, gradienIdx, kustom, fontTebal, kapitalAwal]);

  useEffect(() => {
    render();
  }, [render]);

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    downloadCanvas(canvas, "fanzz-story-card.png");
    pushHistory("studio", {
      id: `story-${Date.now()}`,
      title: "Story card (ISC)",
      subtitle: teks.trim().slice(0, 60) || "tanpa teks",
    });
    toast({ title: "Story card terunduh", description: "1080 x 1920 piksel — pas untuk status WA atau cerita IG." });
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <p className="mb-1.5 flex items-center gap-1.5 text-xs font-bold">
          <Quote className="h-3.5 w-3.5 text-red-400" />
          Kutipan / teks utama
        </p>
        <Textarea
          value={teks}
          onChange={(e) => setTeks(e.target.value)}
          className="min-h-[110px] resize-none border-[var(--surface-line)] bg-background text-sm"
          maxLength={240}
          placeholder="Tulis kutipan, curhatan, atau pengumuman..."
        />
      </div>

      {/* gradien */}
      <div>
        <p className="mb-1.5 text-xs font-bold text-muted-foreground">Latar Gradien</p>
        <div className="grid grid-cols-5 gap-2">
          {STORY_GRADIENTS.map((s, i) => (
            <button
              key={s.name}
              onClick={() => {
                setGradienIdx(i);
                setKustom(null);
              }}
              title={s.name}
              className={`h-11 rounded-xl ring-1 transition ${
                !kustom && i === gradienIdx ? "ring-2 ring-red-400" : "ring-[var(--surface-line)] hover:opacity-80"
              }`}
              style={{ background: `linear-gradient(${s.angle}deg, ${s.c1}, ${s.c2})` }}
            />
          ))}
        </div>
        <div className="mt-2 flex items-center gap-4">
          <label className="flex items-center gap-2 text-xs font-bold">
            Kustom A
            <input
              type="color"
              value={kustom?.c1 ?? STORY_GRADIENTS[gradienIdx].c1}
              onChange={(e) => setKustom((k) => ({ c1: e.target.value, c2: k?.c2 ?? STORY_GRADIENTS[gradienIdx].c2 }))}
              className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
            />
          </label>
          <label className="flex items-center gap-2 text-xs font-bold">
            Kustom B
            <input
              type="color"
              value={kustom?.c2 ?? STORY_GRADIENTS[gradienIdx].c2}
              onChange={(e) => setKustom((k) => ({ c1: k?.c1 ?? STORY_GRADIENTS[gradienIdx].c1, c2: e.target.value }))}
              className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
            />
          </label>
          {kustom && (
            <button onClick={() => setKustom(null)} className="text-[10px] font-bold text-red-400 underline underline-offset-2">
              kembali ke preset
            </button>
          )}
        </div>
      </div>

      {/* pengaturan teks */}
      <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="flex items-center justify-between">
          <p className="text-xs font-bold">Teks tebal</p>
          <Switch checked={fontTebal} onCheckedChange={setFontTebal} />
        </div>
        <div className="flex items-center justify-between">
          <p className="text-xs font-bold">HURUF KAPITAL</p>
          <Switch checked={kapitalAwal} onCheckedChange={setKapitalAwal} />
        </div>
        <div>
          <p className="mb-1 flex items-center gap-1 text-[10px] font-bold text-muted-foreground">
            <AtSign className="h-3 w-3" /> Nama akun di atas (opsional)
          </p>
          <Input value={handle} onChange={(e) => setHandle(e.target.value)} maxLength={24} className="h-9 text-xs" placeholder="username" />
        </div>
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Teks kecil di bawah (opsional)</p>
          <Input value={kaki} onChange={(e) => setKaki(e.target.value)} maxLength={40} className="h-9 text-xs" placeholder="— FanzzTools, 2026" />
        </div>
      </div>

      {/* pratinjau */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[280px]">
        <canvas ref={canvasRef} className="block h-auto w-full rounded-3xl border border-[var(--surface-line)] shadow-2xl" />
      </motion.div>

      <Button onClick={unduh} className="h-11 w-full bg-gradient-to-r from-red-500 to-red-700 font-bold">
        <Download className="mr-2 h-4 w-4" />
        Unduh Story Card
      </Button>

      <p className="flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground">
        <Sparkles className="h-3 w-3 text-red-400" />
        Ukuran teks menyesuaikan panjang kutipan secara otomatis.
      </p>
    </div>
  );
}
