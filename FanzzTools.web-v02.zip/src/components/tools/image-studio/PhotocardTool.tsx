"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState } from "@/components/tools/shared";
import {
  ensureFonts, loadImageFromFile, downloadCanvas, drawCover, roundRectPath, wrapLines,
} from "@/components/tools/image-studio/lib";
import { Upload, Download, IdCard } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * Pembuat Photocard (PC) — kartu foto ala album/K-pop:
 * bingkai putih klasik / warna / gradien / holografik, nama + label seri, nomor seri,
 * plus MODE MEME PC: strip caption tebal di bawah foto.
 */

const W = 900;
const H = 1280;
const FOTO_W = 780;
const FOTO_H = 960;
const FOTO_X = (W - FOTO_W) / 2;
const FOTO_Y = 64;

type Gaya = "klasik" | "warna" | "gradien" | "holo";

interface OpsiPc {
  gaya: Gaya;
  warnaBingkai: string;
  warnaBingkai2: string;
  nama: string;
  label: string;
  nomorSeri: string;
  zoom: number;
  geserY: number;
  modeMeme: boolean;
  caption: string;
  fontNama: "playfair" | "inter";
}

function gambarPc(canvas: HTMLCanvasElement, img: HTMLImageElement, o: OpsiPc) {
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const areaBawah = o.modeMeme ? 300 : 176;

  // latar kartu
  if (o.gaya === "klasik") {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, W, H);
  } else if (o.gaya === "warna") {
    ctx.fillStyle = o.warnaBingkai;
    ctx.fillRect(0, 0, W, H);
  } else {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, o.warnaBingkai);
    g.addColorStop(1, o.warnaBingkai2);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  // foto (cover + zoom + geser vertikal)
  ctx.save();
  roundRectPath(ctx, FOTO_X, FOTO_Y, FOTO_W, H - FOTO_Y - areaBawah, 28);
  ctx.clip();
  drawCover(
    ctx,
    img,
    img.naturalWidth,
    img.naturalHeight,
    FOTO_X,
    FOTO_Y,
    FOTO_W,
    H - FOTO_Y - areaBawah,
    o.zoom,
    0.5,
    0.5 + o.geserY,
  );
  // efek holografik: sapuan pelangi diagonal
  if (o.gaya === "holo") {
    ctx.globalCompositeOperation = "overlay";
    ctx.globalAlpha = 0.55;
    const holo = ctx.createLinearGradient(FOTO_X, FOTO_Y, FOTO_X + FOTO_W, FOTO_Y + FOTO_H);
    ["#ff5f6d", "#ffc371", "#a8ff78", "#78ffd6", "#68d6ff", "#a68bff"].forEach((c, i, arr) => {
      holo.addColorStop(i / (arr.length - 1), c);
    });
    ctx.fillStyle = holo;
    ctx.fillRect(FOTO_X, FOTO_Y, FOTO_W, FOTO_H);
    // kilau miring tipis
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.moveTo(FOTO_X + 140, FOTO_Y);
    ctx.lineTo(FOTO_X + 320, FOTO_Y);
    ctx.lineTo(FOTO_X + 120, FOTO_Y + FOTO_H);
    ctx.lineTo(FOTO_X - 60, FOTO_Y + FOTO_H);
    ctx.closePath();
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }
  ctx.restore();

  // garis tepi foto halus
  ctx.strokeStyle = "rgba(0,0,0,0.10)";
  ctx.lineWidth = 2;
  roundRectPath(ctx, FOTO_X, FOTO_Y, FOTO_W, H - FOTO_Y - areaBawah, 28);
  ctx.stroke();

  if (o.modeMeme) {
    // strip caption meme
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, H - areaBawah + 14, W, areaBawah - 14);
    const isi = (o.caption || "TULIS CAPTION").toUpperCase();
    ctx.font = "400 96px Anton, Impact, sans-serif";
    const baris = wrapLines(ctx, isi, W - 120).slice(0, 2);
    const size = baris.length > 1 ? 78 : 92;
    ctx.font = `400 ${size}px Anton, Impact, sans-serif`;
    const barisFinal = wrapLines(ctx, isi, W - 120).slice(0, 2);
    ctx.fillStyle = "#111111";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const mulai = H - areaBawah + 14 + (areaBawah - 14) / 2 - ((barisFinal.length - 1) * size * 1.05) / 2;
    barisFinal.forEach((l, i) => ctx.fillText(l, W / 2, mulai + i * size * 1.05));
  } else {
    // area nama elegan
    const fontNama =
      o.fontNama === "playfair"
        ? `italic 700 64px 'Playfair Display', Georgia, serif`
        : `700 56px Inter, -apple-system, sans-serif`;
    const teksNama = o.nama.trim();
    if (teksNama) {
      ctx.font = fontNama;
      ctx.fillStyle = o.gaya === "klasik" ? "#111111" : "#ffffff";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(teksNama, W / 2, H - areaBawah / 2 - 6);
    }
    if (o.label.trim()) {
      ctx.font = "600 26px Inter, -apple-system, sans-serif";
      ctx.fillStyle = o.gaya === "klasik" ? "rgba(17,17,17,0.55)" : "rgba(255,255,255,0.75)";
      ctx.textAlign = "center";
      ctx.fillText(o.label.toUpperCase(), W / 2, H - areaBawah / 2 + 42);
    }
  }

  // nomor seri kecil pojok
  if (o.nomorSeri.trim()) {
    ctx.font = "600 22px Inter, -apple-system, sans-serif";
    ctx.fillStyle = o.gaya === "klasik" ? "rgba(17,17,17,0.45)" : "rgba(255,255,255,0.7)";
    ctx.textAlign = "right";
    ctx.fillText(o.nomorSeri, W - 40, H - 28);
  }
}

const GAYA_OPSI: Array<{ id: Gaya; label: string }> = [
  { id: "klasik", label: "Putih Klasik" },
  { id: "warna", label: "Warna Polos" },
  { id: "gradien", label: "Gradien" },
  { id: "holo", label: "Holografik" },
];

export default function PhotocardTool() {
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [gaya, setGaya] = useState<Gaya>("klasik");
  const [warnaBingkai, setWarnaBingkai] = useState("#f4b8d0");
  const [warnaBingkai2, setWarnaBingkai2] = useState("#7f5af0");
  const [nama, setNama] = useState("Lyra");
  const [label, setLabel] = useState("FANZZ SERIES");
  const [nomorSeri, setNomorSeri] = useState("No. 001/100");
  const [zoom, setZoom] = useState(1);
  const [geserY, setGeserY] = useState(0);
  const [modeMeme, setModeMeme] = useState(false);
  const [caption, setCaption] = useState("PC tentang aku tapi aku nggak punya");
  const [fontNama, setFontNama] = useState<"playfair" | "inter">("playfair");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    void ensureFonts(["playfair", "inter", "anton"]);
  }, []);

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !img) return;
    const opsi: OpsiPc = { gaya, warnaBingkai, warnaBingkai2, nama, label, nomorSeri, zoom, geserY, modeMeme, caption, fontNama };
    gambarPc(canvas, img, opsi);
  }, [img, gaya, warnaBingkai, warnaBingkai2, nama, label, nomorSeri, zoom, geserY, modeMeme, caption, fontNama]);

  useEffect(() => {
    render();
  }, [render]);

  const pilihFoto = async (file: File | undefined) => {
    if (!file) return;
    try {
      const gambar = await loadImageFromFile(file);
      setImg(gambar);
      toast({ title: "Foto dimuat", description: "Atur bingkai, nama, lalu unduh kartu foto Anda." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    }
  };

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas || !img) return;
    downloadCanvas(canvas, modeMeme ? "fanzz-meme-pc.png" : "fanzz-photocard.png");
    pushHistory("studio", {
      id: `pc-${Date.now()}`,
      title: modeMeme ? "Meme PC" : "Photocard",
      subtitle: (modeMeme ? caption : nama).trim().slice(0, 60) || "tanpa judul",
    });
    toast({ title: "Photocard terunduh", description: "900 x 1280 piksel — siap dikoleksi." });
  };

  return (
    <div className="space-y-4">
      {/* unggah */}
      <label className="flex cursor-pointer items-center gap-3 rounded-xl bg-gradient-to-r from-red-500/15 to-red-700/15 p-3 ring-1 ring-red-400/20 transition hover:from-red-500/25 hover:to-red-700/25">
        <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihFoto(e.target.files?.[0])} />
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-md">
          <Upload className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-bold">{img ? "Ganti Foto" : "Pilih Foto"}</p>
          <p className="text-[11px] text-muted-foreground">Foto ideal: potret vertikal</p>
        </div>
      </label>

      {!img ? (
        <EmptyState
          icon={<IdCard className="h-10 w-10" />}
          title="Belum ada foto"
          desc="Pilih foto untuk membuat photocard — bingkai klasik, gradien, hingga holografik."
        />
      ) : (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* mode */}
          <div className="grid grid-cols-2 gap-2">
            {([
              { id: false, label: "Photocard Klasik" },
              { id: true, label: "Meme PC" },
            ] as const).map((m) => (
              <button
                key={String(m.id)}
                onClick={() => setModeMeme(m.id)}
                className={`rounded-xl px-3 py-2.5 text-xs font-bold transition ${
                  modeMeme === m.id
                    ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                    : "bg-secondary hover:bg-secondary/70"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          {/* gaya bingkai */}
          <div>
            <p className="mb-1.5 text-xs font-bold text-muted-foreground">Bingkai</p>
            <div className="grid grid-cols-4 gap-2">
              {GAYA_OPSI.map((g) => (
                <button
                  key={g.id}
                  onClick={() => setGaya(g.id)}
                  className={`rounded-xl px-2 py-2 text-[10px] font-bold transition ${
                    gaya === g.id
                      ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                      : "bg-secondary hover:bg-secondary/70"
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          {(gaya === "warna" || gaya === "gradien" || gaya === "holo") && (
            <div className="flex items-center gap-4 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
              <label className="flex items-center gap-2 text-xs font-bold">
                Warna 1
                <input
                  type="color"
                  value={warnaBingkai}
                  onChange={(e) => setWarnaBingkai(e.target.value)}
                  className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
                />
              </label>
              {gaya !== "warna" && (
                <label className="flex items-center gap-2 text-xs font-bold">
                  Warna 2
                  <input
                    type="color"
                    value={warnaBingkai2}
                    onChange={(e) => setWarnaBingkai2(e.target.value)}
                    className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
                  />
                </label>
              )}
            </div>
          )}

          {/* teks */}
          {modeMeme ? (
            <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
              <p className="mb-1 text-[10px] font-bold text-muted-foreground">Caption meme (kapital otomatis)</p>
              <Input value={caption} onChange={(e) => setCaption(e.target.value)} maxLength={60} className="h-9 text-xs" />
            </div>
          ) : (
            <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold">Font nama</p>
                <Select value={fontNama} onValueChange={(v) => setFontNama(v as "playfair" | "inter")}>
                  <SelectTrigger className="h-9 w-40 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="playfair">Playfair (elegan)</SelectItem>
                    <SelectItem value="inter">Inter (bersih)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <p className="mb-1 text-[10px] font-bold text-muted-foreground">Nama</p>
                <Input value={nama} onChange={(e) => setNama(e.target.value)} maxLength={24} className="h-9 text-xs" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <p className="mb-1 text-[10px] font-bold text-muted-foreground">Label seri</p>
                  <Input value={label} onChange={(e) => setLabel(e.target.value)} maxLength={20} className="h-9 text-xs" />
                </div>
                <div>
                  <p className="mb-1 text-[10px] font-bold text-muted-foreground">Nomor seri</p>
                  <Input value={nomorSeri} onChange={(e) => setNomorSeri(e.target.value)} maxLength={16} className="h-9 text-xs" />
                </div>
              </div>
            </div>
          )}

          {/* posisi foto */}
          <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
            <div>
              <div className="mb-1.5 flex justify-between text-[10px] font-bold text-muted-foreground">
                <span>Perbesar foto</span>
                <span className="tabular-nums text-red-400">{zoom.toFixed(2)}x</span>
              </div>
              <Slider min={1} max={2.2} step={0.05} value={[zoom]} onValueChange={(v) => setZoom(v[0])} />
            </div>
            <div>
              <div className="mb-1.5 flex justify-between text-[10px] font-bold text-muted-foreground">
                <span>Geser vertikal</span>
                <span className="tabular-nums text-red-400">{geserY.toFixed(2)}</span>
              </div>
              <Slider min={-0.4} max={0.4} step={0.02} value={[geserY]} onValueChange={(v) => setGeserY(v[0])} />
            </div>
          </div>

          {/* pratinjau */}
          <div className="mx-auto w-full max-w-[320px]">
            <canvas ref={canvasRef} className="block h-auto w-full rounded-2xl border border-[var(--surface-line)] shadow-xl" />
          </div>

          <Button onClick={unduh} className="h-11 w-full bg-gradient-to-r from-red-500 to-red-700 font-bold">
            <Download className="mr-2 h-4 w-4" />
            Unduh {modeMeme ? "Meme PC" : "Photocard"}
          </Button>
        </motion.div>
      )}
    </div>
  );
}
