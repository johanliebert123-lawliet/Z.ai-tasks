"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, TextInput, TextArea, DownloadButton, UploadPhoto } from "./iqc-shared";
import { ensureFonts, downloadCanvas, loadImageFromFile, roundRectPath } from "./lib";
import { useToast } from "@/hooks/use-toast";

/**
 * Chat Generator (IQC) — FanzzTools Cyber-Update (redesain final).
 * Hasil WA dirancang ULANG agar SAMA PERSIS dengan 2 screenshot referensi pemilik:
 *
 *  1. MODE "WhatsApp Terang" (screenshot 2026-09-08 09.29.20):
 *     - latar: obrolan latar TETAP yang di-BLUR asli (burem) + scrim tipis
 *     - pesan utama (bisa diubah) terlihat TAJAM di tengah, avatar bulat di kiri
 *     - pil reaksi ❤️😂😭👍😠😉 MELAYANG DI ATAS pesan — TIDAK menutupi chat
 *     - menu konteks di BAWAH pesan: Balas / Teruskan / Salin / Terjemahkan /
 *       Hapus untuk saya / Laporkan (ikon kiri)
 *     - bar bawah: reaksi cepat ❤️😂👍👆 + badge Streak Pet + ikon video ungu,
 *       pil input "Kirim pesan..." + ikon kamera kiri + galeri/stiker/mic kanan
 *
 *  2. MODE "WA iOS Gelap" (screenshot 2026-09-16):
 *     - latar chat gelap BLUR asli (burem) + scrim gelap
 *     - pesan utama TAJAM (bisa diubah: teks, nama, foto profil, waktu)
 *     - pil reaksi 👍❤️😂😮😢🙏 + tombol "+" DI ATAS pesan — TIDAK menutupi chat
 *     - menu iOS #2C2C2E DI BAWAH pesan: Beri Bintang / Balas / Teruskan /
 *       Salin / Ucapkan / Laporkan / Hapus (merah) — ikon di KANAN (gaya iOS)
 *
 *  3. MODE "TikTok Komentar" & 4. "iMessage" — perilaku lama dipertahankan.
 *
 * Untuk mode WA: hanya PESAN UTAMA yang bisa diubah (nama, foto profil, teks,
 * waktu, sisi kiri/kanan). Pesan latar + emoji reaksi TETAP (tidak bisa diubah)
 * persis seperti screenshot referensi. Hasil bisa diunduh PNG.
 */

type Mode = "wa-light" | "wa-ios" | "tiktok" | "iphone";

const MODES: Array<{ id: Mode; label: string }> = [
  { id: "wa-ios", label: "WA iOS Gelap" },
  { id: "wa-light", label: "WhatsApp Terang" },
  { id: "tiktok", label: "TikTok Komentar" },
  { id: "iphone", label: "iMessage" },
];

const KUNCI = "Testing Generator • By : FanzzTools™";

/** Set reaksi per mode — persis screenshot, TETAP (tidak diubah user). */
const REACTIONS: Record<Mode, string[]> = {
  "wa-light": ["❤️", "😂", "😭", "👍", "😠", "😉"],
  "wa-ios": ["👍", "❤️", "😂", "😮", "😢", "🙏"],
  tiktok: ["😍", "😂", "😆", "👍", "🤬", "😏"],
  iphone: ["❤️", "😂", "👍", "😮", "😢", "🙏"],
};

/** Item menu konteks per mode — persis screenshot, TETAP. */
const MENU_LIGHT: Array<{ label: string; red?: boolean }> = [
  { label: "Balas" },
  { label: "Teruskan" },
  { label: "Salin" },
  { label: "Terjemahkan" },
  { label: "Hapus untuk saya" },
  { label: "Laporkan", red: true },
];
const MENU_IOS: Array<{ label: string; red?: boolean }> = [
  { label: "Beri Bintang" },
  { label: "Balas" },
  { label: "Teruskan" },
  { label: "Salin" },
  { label: "Ucapkan" },
  { label: "Laporkan" },
  { label: "Hapus", red: true },
];
const MENU_TIKTOK: Array<{ label: string; red?: boolean }> = [
  { label: "Balas" },
  { label: "Salin teks" },
  { label: "Terjemahkan" },
  { label: "Laporkan komentar", red: true },
];

/** Obrolan latar TETAP untuk mode WA — sengaja generik, hanya tampil burem. */
const BG_CHAT: Array<{ me: boolean; text: string }> = [
  { me: false, text: "Gimana kabarnya?" },
  { me: true, text: "Baik banget nih" },
  { me: false, text: "Syukurlah 😊" },
  { me: false, text: "Udah makan?" },
  { me: true, text: "Belom, sibuk" },
  { me: false, text: "Yaudah, nanti aku telpon ya" },
  { me: true, text: "Oke siap" },
  { me: false, text: "Eh iya, aku liat story kamu" },
  { me: true, text: "Haha iya kemarin" },
  { me: false, text: "Keren sih tempatnya" },
  { me: true, text: "Makasih 😁" },
  { me: false, text: "Besok jadi?" },
  { me: true, text: "Jadi dong, jam 2 ya" },
  { me: false, text: "Siap, aku jemput" },
  { me: true, text: "Oke ditunggu" },
  { me: false, text: "Jangan lupa bawa nanti" },
  { me: true, text: "Siap boss" },
  { me: false, text: "Lagi dimana?" },
  { me: true, text: "Dirumah aja" },
  { me: false, text: "Mau mampir?" },
  { me: true, text: "Boleh, nanti sore" },
  { me: false, text: "Oke kabarin ya" },
];

interface Bubble {
  me: boolean;
  text: string;
  time: string;
}

function parseChat(raw: string, time: string): Bubble[] {
  return raw
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .slice(0, 40)
    .map((l) => ({
      me: l.startsWith(">"),
      text: (l.startsWith(">") ? l.slice(1) : l).trim().slice(0, 220),
      time,
    }));
}

function drawTicks(ctx: CanvasRenderingContext2D, x: number, y: number, blue: boolean) {
  ctx.strokeStyle = blue ? "#53bdeb" : "rgba(255,255,255,0.55)";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(x - 5, y + 3);
  ctx.lineTo(x - 2, y + 6);
  ctx.lineTo(x + 3, y - 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x, y + 3);
  ctx.lineTo(x + 3, y + 6);
  ctx.lineTo(x + 8, y - 2);
  ctx.stroke();
}

/* ================= IKON GARIS (menu konteks) ================= */
function icReply(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.09; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x + s * 0.85, y + s * 0.7); ctx.lineTo(x + s * 0.85, y + s * 0.3);
  ctx.quadraticCurveTo(x + s * 0.85, y - s * 0.05, x + s * 0.5, y - s * 0.05);
  ctx.lineTo(x + s * 0.15, y - s * 0.05); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x + s * 0.35, y - s * 0.3); ctx.lineTo(x + s * 0.15, y - s * 0.05);
  ctx.lineTo(x + s * 0.35, y + s * 0.2); ctx.stroke();
}
function icForward(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.save(); ctx.translate(x + s, y); ctx.scale(-1, 1);
  icReply(ctx, 0, 0, s, col); ctx.restore();
}
function icCopy(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.09;
  roundRectPath(ctx, x + s * 0.28, y - s * 0.42, s * 0.6, s * 0.6, s * 0.1); ctx.stroke();
  roundRectPath(ctx, x + s * 0.12, y - s * 0.18, s * 0.6, s * 0.6, s * 0.1); ctx.stroke();
}
function icTranslate(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.fillStyle = col;
  ctx.font = `700 ${s * 0.62}px Inter`; ctx.textAlign = "left"; ctx.textBaseline = "middle";
  ctx.fillText("A", x + s * 0.05, y);
  ctx.font = `600 ${s * 0.52}px Inter`;
  ctx.fillText("文", x + s * 0.5, y);
}
function icTrash(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.09; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x + s * 0.2, y - s * 0.2); ctx.lineTo(x + s * 0.8, y - s * 0.2); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x + s * 0.35, y - s * 0.2); ctx.lineTo(x + s * 0.35, y - s * 0.38);
  ctx.lineTo(x + s * 0.65, y - s * 0.38); ctx.lineTo(x + s * 0.65, y - s * 0.2); ctx.stroke();
  roundRectPath(ctx, x + s * 0.25, y - s * 0.2, s * 0.5, s * 0.62, s * 0.08); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x + s * 0.42, y - s * 0.02); ctx.lineTo(x + s * 0.42, y + s * 0.24);
  ctx.moveTo(x + s * 0.58, y - s * 0.02); ctx.lineTo(x + s * 0.58, y + s * 0.24); ctx.stroke();
}
function icFlag(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.1; ctx.lineCap = "round";
  ctx.beginPath(); ctx.moveTo(x + s * 0.25, y - s * 0.45); ctx.lineTo(x + s * 0.25, y + s * 0.45); ctx.stroke();
  ctx.fillStyle = col;
  ctx.beginPath();
  ctx.moveTo(x + s * 0.3, y - s * 0.42);
  ctx.lineTo(x + s * 0.82, y - s * 0.22);
  ctx.lineTo(x + s * 0.3, y - s * 0.02);
  ctx.closePath(); ctx.fill();
}
function icStar(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.09;
  ctx.beginPath();
  for (let i = 0; i < 5; i++) {
    const a1 = (Math.PI * 2 * i) / 5 - Math.PI / 2;
    const a2 = a1 + Math.PI / 5;
    const ox = x + s / 2 + Math.cos(a1) * s * 0.42;
    const oy = y + Math.cos(0) * 0 + Math.sin(a1) * s * 0.42;
    const ix = x + s / 2 + Math.cos(a2) * s * 0.18;
    const iy = y + Math.sin(a2) * s * 0.18;
    if (i === 0) ctx.moveTo(ox, oy); else ctx.lineTo(ox, oy);
    ctx.lineTo(ix, iy);
  }
  ctx.closePath(); ctx.stroke();
}
function icSpeak(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) {
  ctx.strokeStyle = col; ctx.lineWidth = s * 0.09;
  roundRectPath(ctx, x + s * 0.1, y - s * 0.4, s * 0.8, s * 0.55, s * 0.16); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(x + s * 0.35, y + s * 0.15); ctx.lineTo(x + s * 0.35, y + s * 0.42);
  ctx.lineTo(x + s * 0.58, y + s * 0.15); ctx.stroke();
}
function iconFor(label: string): (c: CanvasRenderingContext2D, x: number, y: number, s: number, col: string) => void {
  if (label === "Balas") return icReply;
  if (label === "Teruskan") return icForward;
  if (label.startsWith("Salin")) return icCopy;
  if (label.startsWith("Terjemah")) return icTranslate;
  if (label.startsWith("Hapus")) return icTrash;
  if (label.startsWith("Laporkan")) return icFlag;
  if (label.startsWith("Beri Bintang")) return icStar;
  if (label.startsWith("Ucapkan")) return icSpeak;
  return icReply;
}

export default function ChatFakeTool() {
  const [mode, setMode] = useState<Mode>("wa-ios");
  const [name, setName] = useState("JoJohan");
  const [status, setStatus] = useState("online");
  /** pesan utama (WA) — satu-satunya teks obrolan yang bisa diubah */
  const [mainMsg, setMainMsg] = useState("Join Saluran Mod di Bio");
  /** sisi pesan utama WA: false = kiri (dari kontak), true = kanan (dari Anda) */
  const [mainMe, setMainMe] = useState(false);
  /** obrolan multi-pesan (mode tiktok/iphone — perilaku lama) */
  const [chatRaw, setChatRaw] = useState(
    "> Anjai\napaan sih\n> besok gw ada ide konten gila bgt\nmaksudnya?\n> ntar aja deh, masih rahasia 🤫\nyaudah kalau gitu\n> siap! ke FanzzTools aja",
  );
  const [time, setTime] = useState("11.26");
  const [targetIdx, setTargetIdx] = useState(0);
  const [photo, setPhoto] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const bubbles = parseChat(chatRaw, time);
  const target = Math.min(Math.max(targetIdx, 0), Math.max(0, bubbles.length - 1));
  const isWaMode = mode === "wa-light" || mode === "wa-ios";

  const onFile = async (f: File | null) => {
    if (!f) return setPhoto(null);
    try {
      const img = await loadImageFromFile(f);
      setPhoto(img);
    } catch {
      toast({ title: "Gambar gagal dimuat", variant: "destructive" });
    }
  };

  /** ---- pil reaksi (6 emoji + tombol "+") — melayang DI ATAS pesan, tidak menutupi chat ---- */
  const drawReactionPill = (ctx: CanvasRenderingContext2D, cx: number, cy: number, emojis: string[], bg: string, border: string, dark: boolean, scale = 1) => {
    const emojiSize = 44 * scale;
    const cell = emojiSize + 26 * scale;
    const plusW = 42 * scale;
    const pillW = emojis.length * cell + plusW + 30 * scale;
    const pillH = emojiSize + 30 * scale;
    const x0 = cx - pillW / 2;
    const y0 = cy - pillH / 2;
    ctx.save();
    ctx.shadowColor = dark ? "rgba(0,0,0,0.45)" : "rgba(0,0,0,0.22)";
    ctx.shadowBlur = 26; ctx.shadowOffsetY = 8;
    ctx.fillStyle = bg;
    roundRectPath(ctx, x0, y0, pillW, pillH, pillH / 2);
    ctx.fill();
    ctx.restore();
    if (border) {
      ctx.strokeStyle = border; ctx.lineWidth = 1.5;
      roundRectPath(ctx, x0, y0, pillW, pillH, pillH / 2);
      ctx.stroke();
    }
    ctx.font = `${emojiSize}px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    emojis.forEach((e, i) => {
      ctx.fillText(e, x0 + 15 * scale + cell * (i + 0.5), cy + 2);
    });
    // tombol "+" kecil di ujung kanan pil (per screenshot iOS)
    const px = x0 + 15 * scale + cell * emojis.length + plusW / 2 - 6 * scale;
    ctx.save();
    ctx.strokeStyle = dark ? "rgba(255,255,255,0.55)" : "rgba(60,60,67,0.6)";
    ctx.lineWidth = 2.6 * scale; ctx.lineCap = "round";
    const pr = 13 * scale;
    ctx.beginPath(); ctx.moveTo(px - pr, cy); ctx.lineTo(px + pr, cy);
    ctx.moveTo(px, cy - pr); ctx.lineTo(px, cy + pr); ctx.stroke();
    ctx.restore();
  };

  /** ---- menu konteks gaya TERANG (ikon KIRI) — diposisikan DI BAWAH pesan ---- */
  const drawLightMenu = (ctx: CanvasRenderingContext2D, x: number, y: number, items: Array<{ label: string; red?: boolean }>) => {
    const w = 560, rowH = 88, h = items.length * rowH + 24;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.28)"; ctx.shadowBlur = 44; ctx.shadowOffsetY = 14;
    ctx.fillStyle = "#FFFFFF";
    roundRectPath(ctx, x, y, w, h, 26); ctx.fill();
    ctx.restore();
    items.forEach((it, i) => {
      const ry = y + 12 + i * rowH;
      if (i > 0) {
        ctx.strokeStyle = "rgba(0,0,0,0.08)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x + 26, ry); ctx.lineTo(x + w - 26, ry); ctx.stroke();
      }
      const col = it.red ? "#EA0029" : "#111111";
      iconFor(it.label)(ctx, x + 34, ry + rowH / 2 - 8, 46, col);
      ctx.fillStyle = col;
      ctx.font = "500 31px Inter";
      ctx.textAlign = "left"; ctx.textBaseline = "middle";
      ctx.fillText(it.label, x + 108, ry + rowH / 2);
    });
    return h;
  };

  /** ---- menu konteks gaya iOS GELAP (ikon KANAN) — diposisikan DI BAWAH pesan ---- */
  const drawIosItemsMenu = (ctx: CanvasRenderingContext2D, x: number, y: number, items: Array<{ label: string; red?: boolean }>) => {
    const w = 620, rowH = 92, h = items.length * rowH + 24;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.45)"; ctx.shadowBlur = 46; ctx.shadowOffsetY = 16;
    ctx.fillStyle = "#2C2C2E";
    roundRectPath(ctx, x, y, w, h, 34); ctx.fill();
    ctx.restore();
    items.forEach((it, i) => {
      const ry = y + 12 + i * rowH;
      if (i > 0) {
        ctx.strokeStyle = "#48484A"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x + 24, ry); ctx.lineTo(x + w - 24, ry); ctx.stroke();
      }
      const col = it.red ? "#FF453A" : "#FFFFFF";
      ctx.fillStyle = col;
      ctx.font = "400 33px Inter";
      ctx.textAlign = "left"; ctx.textBaseline = "middle";
      ctx.fillText(it.label, x + 30, ry + rowH / 2);
      iconFor(it.label)(ctx, x + w - 96, ry + rowH / 2 - 8, 46, col);
    });
    return h;
  };

  /** avatar bulat + placeholder orang */
  function drawAvatar(ctx: CanvasRenderingContext2D, x: number, y: number, s: number, radius: number, img: HTMLImageElement | null, phBg: string, phFg: string) {
    ctx.save();
    roundRectPath(ctx, x, y, s, s, radius); ctx.clip();
    if (img) ctx.drawImage(img, x, y, s, s);
    else {
      ctx.fillStyle = phBg; ctx.fillRect(x, y, s, s);
      ctx.fillStyle = phFg;
      ctx.beginPath(); ctx.arc(x + s / 2, y + s * 0.4, s * 0.2, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.arc(x + s / 2, y + s * 0.95, s * 0.32, Math.PI, 0); ctx.fill();
    }
    ctx.restore();
  }
  function drawDots(ctx: CanvasRenderingContext2D, cx: number, cy: number, col: string) {
    ctx.fillStyle = col;
    for (let i = -1; i <= 1; i++) {
      ctx.beginPath(); ctx.arc(cx + i * 12, cy, 5.5, 0, Math.PI * 2); ctx.fill();
    }
  }

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const W = 1080;
    await ensureFonts(["inter", "archivo"]);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const measureCtx = document.createElement("canvas").getContext("2d")!;

    const bodyFont = "400 30px Inter";
    const lineH = 42;
    const bubblePad = 24;

    const wrap = (text: string, font: string, maxW: number): string[] => {
      measureCtx.font = font;
      const out: string[] = [];
      for (const par of text.split("\n")) {
        const kata = par.split(/\s+/);
        let baris = "";
        for (const k of kata) {
          const coba = baris ? `${baris} ${k}` : k;
          if (measureCtx.measureText(coba).width > maxW && baris) { out.push(baris); baris = k; }
          else baris = coba;
        }
        out.push(baris);
      }
      return out.filter((l, i) => !(l === "" && i === out.length - 1));
    };

    /* ================================================================
     * MODE WA — TAMPILAN "SCREENSHOT LONG-PRESS" (canvas tinggi tetap)
     * Urutan vertikal persis screenshot referensi:
     *   status bar → header → (latar burem) → PIL REAKSI → PESAN UTAMA
     *   (tajam) → MENU KONTEKS → bar bawah
     * ================================================================ */
    if (isWaMode) {
      const dark = mode === "wa-ios";
      const H = 2280;
      canvas.width = W;
      canvas.height = H;
      ctx.textBaseline = "middle";

      const headerH = 168;
      const statusBarH = 96;
      const bottomH = dark ? 170 : 260;

      /* ---------- latar dasar ---------- */
      if (dark) {
        ctx.fillStyle = "#0B141A"; ctx.fillRect(0, 0, W, H);
      } else {
        ctx.fillStyle = "#F9FAFB"; ctx.fillRect(0, 0, W, H);
      }

      /* ---------- obrolan latar TETAP + BLUR ASLI (burem) ---------- */
      const bgW = 700;
      const bgFont = "400 30px Inter";
      const bgLineH = 40;
      const bgPad = 20;
      ctx.save();
      // blur kanvas asli — kalau browser tidak dukung ctx.filter, tetap digambar
      // dengan transparansi lebih tinggi agar kesan "burem" tetap ada
      const supportsFilter = typeof (ctx as CanvasRenderingContext2D & { filter?: string }).filter === "string";
      if (supportsFilter) (ctx as CanvasRenderingContext2D & { filter: string }).filter = "blur(13px)";
      else ctx.globalAlpha = 0.4;

      let by = statusBarH + headerH + 30;
      for (const m of BG_CHAT) {
        if (by > H - bottomH - 80) break;
        const lines = wrap(m.text, bgFont, bgW - bgPad * 2);
        const bh = lines.length * bgLineH + bgPad * 2 - 4 + 22;
        const bw = Math.min(bgW, Math.max(90, Math.max(...lines.map((l) => measureCtx.measureText(l).width)) + bgPad * 2 + 24));
        const bx = m.me ? W - 40 - bw : dark ? 40 : 104;
        if (dark) {
          ctx.fillStyle = m.me ? "#005C4B" : "#202C33";
        } else {
          ctx.fillStyle = m.me ? "#E0D4FC" : "#FFFFFF";
        }
        roundRectPath(ctx, bx, by, bw, bh, 16); ctx.fill();
        ctx.fillStyle = dark ? "#E9EDEF" : "#111111";
        ctx.font = bgFont; ctx.textAlign = "left";
        lines.forEach((l, i) => ctx.fillText(l, bx + bgPad, by + bgPad + 8 + i * bgLineH));
        by += bh + 18;
      }
      if (supportsFilter) (ctx as CanvasRenderingContext2D & { filter: string }).filter = "none";
      else ctx.globalAlpha = 1;
      ctx.restore();

      /* ---------- scrim gelap/terang di atas latar burem ---------- */
      if (dark) {
        ctx.fillStyle = "rgba(5,8,10,0.55)"; ctx.fillRect(0, 0, W, H);
      } else {
        ctx.fillStyle = "rgba(245,246,248,0.42)"; ctx.fillRect(0, 0, W, H);
      }

      /* ---------- status bar (persis screenshot: jam kiri, baterai kanan) ---------- */
      ctx.textBaseline = "middle";
      if (dark) {
        ctx.fillStyle = "#FFFFFF"; ctx.font = "700 34px Inter"; ctx.textAlign = "left";
        ctx.fillText(time.replace(/\./g, ":"), 56, statusBarH / 2);
        ctx.textAlign = "center";
        ctx.fillText("INDOSAT OOREDOO LTE", W / 2, statusBarH / 2);
      } else {
        ctx.fillStyle = "#111111"; ctx.font = "700 34px Inter"; ctx.textAlign = "left";
        ctx.fillText(time.replace(/\./g, ":"), 56, statusBarH / 2);
        ctx.textAlign = "center";
        ctx.fillText("4G+", W / 2 - 40, statusBarH / 2);
      }
      // baterai di kanan
      const batPct = 88;
      const bx0 = W - 150, by0 = statusBarH / 2 - 16, bw0 = 74, bh0 = 32;
      ctx.strokeStyle = dark ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.4)";
      ctx.lineWidth = 2.4;
      roundRectPath(ctx, bx0, by0, bw0, bh0, 8); ctx.stroke();
      ctx.fillStyle = "#35C759";
      roundRectPath(ctx, bx0 + 4, by0 + 4, (bw0 - 8) * (batPct / 100), bh0 - 8, 4); ctx.fill();
      ctx.fillStyle = dark ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.4)";
      roundRectPath(ctx, bx0 + bw0 + 3, by0 + 10, 6, 12, 2); ctx.fill();
      ctx.fillStyle = dark ? "#FFFFFF" : "#111111"; ctx.font = "600 26px Inter"; ctx.textAlign = "right";
      ctx.fillText(String(batPct), bx0 - 12, statusBarH / 2);

      /* ---------- header ---------- */
      const hy = statusBarH;
      if (dark) {
        ctx.fillStyle = "#1F2C34"; ctx.fillRect(0, hy, W, headerH);
      } else {
        ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, hy, W, headerH);
        ctx.strokeStyle = "rgba(0,0,0,0.08)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, hy + headerH - 2); ctx.lineTo(W, hy + headerH - 2); ctx.stroke();
      }
      // panah kembali
      ctx.strokeStyle = dark ? "#E9EDEF" : "#333333"; ctx.lineWidth = 5; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(58, hy + 84); ctx.lineTo(32, hy + 84);
      ctx.moveTo(50, hy + 72); ctx.lineTo(32, hy + 84); ctx.lineTo(50, hy + 96); ctx.stroke();
      // avatar + nama + status
      drawAvatar(ctx, 78, hy + 42, 86, 22, photo, dark ? "#6A7F8C" : "#6A7F8C", dark ? "#0B141A" : "#F2F5F7");
      ctx.fillStyle = dark ? "#E9EDEF" : "#111111"; ctx.font = "600 40px Inter"; ctx.textAlign = "left";
      ctx.fillText((name || "Kontak").slice(0, 24), 192, hy + 70);
      ctx.fillStyle = "#66BC77"; ctx.font = "400 27px Inter";
      ctx.fillText((status || "online").slice(0, 24), 192, hy + 118);
      // ikon video + telepon (kanan)
      const iconCol = dark ? "#AEBAC1" : "#566A74";
      ctx.strokeStyle = iconCol; ctx.lineWidth = 4.4; ctx.lineCap = "round"; ctx.lineJoin = "round";
      const vy0 = hy + 60;
      roundRectPath(ctx, W - 190, vy0, 62, 44, 12); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(W - 128, vy0 + 12); ctx.lineTo(W - 106, vy0 + 8);
      ctx.lineTo(W - 106, vy0 + 36); ctx.lineTo(W - 128, vy0 + 32); ctx.closePath(); ctx.stroke();
      // telepon (lingkaran + gagang)
      ctx.beginPath(); ctx.arc(W - 78, vy0 + 22, 22, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(W - 86, vy0 + 12); ctx.quadraticCurveTo(W - 72, vy0 + 8, W - 70, vy0 + 22);
      ctx.stroke();

      /* ---------- PESAN UTAMA (tajam, bisa diubah) ---------- */
      const mainText = (mainMsg || "...").slice(0, 300);
      const mainLines = wrap(mainText, bodyFont, 620);
      const mainH = mainLines.length * lineH + bubblePad * 2 - 6 + 26;
      const mainW = Math.min(740, Math.max(120, Math.max(...mainLines.map((l) => measureCtx.measureText(l).width)) + bubblePad * 2 + (mainMe ? 70 : 20)));
      // posisi vertikal: sisakan ruang pil di atas + menu di bawah (tengah layar)
      const pillH = 78;
      const menuH = dark ? MENU_IOS.length * 92 + 24 : MENU_LIGHT.length * 88 + 24;
      const contentTop = hy + headerH + 60;
      const contentBottom = H - bottomH - 50;
      const room = contentBottom - contentTop;
      let msgY = contentTop + Math.max(60, (room - (pillH + mainH + menuH + 40)) / 2);
      const msgX = mainMe ? W - 40 - mainW : dark ? 40 : 104;

      // pil reaksi DI ATAS pesan (melayang, tidak menutupi teks)
      const pillCx = mainMe ? msgX + mainW / 2 : msgX + mainW / 2;
      const pillCy = msgY - 14 - pillH / 2;
      drawReactionPill(
        ctx, pillCx, pillCy, REACTIONS[mode],
        dark ? "#3A3A3C" : "#FFFFFF",
        dark ? "rgba(255,255,255,0.14)" : "rgba(0,0,0,0.06)",
        dark,
      );

      // gelembung pesan utama — digambar TAJAM (di atas scrim)
      if (dark) {
        ctx.fillStyle = mainMe ? "#005C4B" : "#2C2C2E";
        ctx.save();
        ctx.shadowColor = "rgba(0,0,0,0.35)"; ctx.shadowBlur = 30; ctx.shadowOffsetY = 8;
        roundRectPath(ctx, msgX, msgY, mainW, mainH, 18); ctx.fill();
        ctx.restore();
        // ekor gelembung
        ctx.beginPath();
        if (mainMe) { ctx.moveTo(msgX + mainW, msgY + 26); ctx.lineTo(msgX + mainW + 14, msgY + 34); ctx.lineTo(msgX + mainW, msgY + 44); ctx.fill(); }
        else { ctx.moveTo(msgX, msgY + 26); ctx.lineTo(msgX - 14, msgY + 34); ctx.lineTo(msgX, msgY + 44); ctx.fill(); }
      } else {
        ctx.fillStyle = mainMe ? "#E0D4FC" : "#FFFFFF";
        ctx.save();
        ctx.shadowColor = "rgba(0,0,0,0.16)"; ctx.shadowBlur = 26; ctx.shadowOffsetY = 6;
        roundRectPath(ctx, msgX, msgY, mainW, mainH, 18); ctx.fill();
        ctx.restore();
        ctx.beginPath();
        if (mainMe) { ctx.moveTo(msgX + mainW, msgY + 26); ctx.lineTo(msgX + mainW + 13, msgY + 34); ctx.lineTo(msgX + mainW, msgY + 44); ctx.fill(); }
        else { ctx.moveTo(msgX, msgY + 26); ctx.lineTo(msgX - 13, msgY + 34); ctx.lineTo(msgX, msgY + 44); ctx.fill(); }
      }
      // avatar bulat di kiri gelembung masuk (mode terang, per screenshot)
      if (!dark && !mainMe) {
        const ar = 30, ax = 50, ay = msgY + mainH / 2;
        ctx.save();
        ctx.beginPath(); ctx.arc(ax, ay, ar, 0, Math.PI * 2); ctx.clip();
        if (photo) {
          const s = Math.max((ar * 2) / photo.naturalWidth, (ar * 2) / photo.naturalHeight);
          ctx.drawImage(photo, ax - (photo.naturalWidth * s) / 2, ay - (photo.naturalHeight * s) / 2, photo.naturalWidth * s, photo.naturalHeight * s);
        } else {
          ctx.fillStyle = "#C5D0D6"; ctx.fillRect(ax - ar, ay - ar, ar * 2, ar * 2);
          ctx.fillStyle = "#7A8B94";
          ctx.beginPath(); ctx.arc(ax, ay - 6, 10, 0, Math.PI * 2); ctx.fill();
          ctx.beginPath(); ctx.arc(ax, ay + 16, 16, Math.PI, 0); ctx.fill();
        }
        ctx.restore();
      }
      // teks pesan utama + waktu
      ctx.fillStyle = dark ? (mainMe ? "#FFFFFF" : "#FFFFFF") : "#111111";
      ctx.font = bodyFont; ctx.textAlign = "left";
      mainLines.forEach((l, i) => ctx.fillText(l, msgX + bubblePad, msgY + bubblePad + 8 + i * lineH));
      const ty = msgY + mainH - 16;
      ctx.font = "400 22px Inter";
      const tw = ctx.measureText(time).width;
      if (mainMe) {
        const tx = msgX + mainW - 30;
        drawTicks(ctx, tx - 26, ty, dark);
        ctx.fillStyle = dark ? "rgba(255,255,255,0.5)" : "rgba(0,0,0,0.4)";
        ctx.fillText(time, tx - 12, ty);
      } else {
        ctx.fillStyle = dark ? "rgba(255,255,255,0.45)" : "rgba(0,0,0,0.35)";
        ctx.fillText(time, msgX + mainW - tw - 18, ty);
      }

      /* ---------- MENU KONTEKS DI BAWAH pesan (tidak menutupi bubble) ---------- */
      const menuY = msgY + mainH + 22;
      if (dark) {
        drawIosItemsMenu(ctx, Math.min(Math.max(40, msgX), W - 660), menuY, MENU_IOS);
      } else {
        drawLightMenu(ctx, Math.min(msgX + 30, W - 600), menuY, MENU_LIGHT);
      }

      /* ---------- bar bawah ---------- */
      const byWa = H - bottomH;
      if (dark) {
        ctx.fillStyle = "#1F2C34"; ctx.fillRect(0, byWa, W, bottomH - 40);
        const ix = 40, iy = byWa + 40, iw = W - 220, ih = 76;
        ctx.fillStyle = "#2A3942";
        roundRectPath(ctx, ix, iy, iw, ih, ih / 2); ctx.fill();
        ctx.fillStyle = "#8696A0"; ctx.font = "400 30px Inter"; ctx.textAlign = "left";
        ctx.fillText("Ketik pesan", ix + 30, iy + ih / 2);
        ctx.fillStyle = "#00A884";
        ctx.beginPath(); ctx.arc(W - 100, iy + ih / 2, 44, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = "#FFFFFF"; ctx.font = `38px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`; ctx.textAlign = "center";
        ctx.fillText("🎤", W - 100, iy + ih / 2 + 2);
      } else {
        ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, byWa, W, bottomH - 40);
        ctx.strokeStyle = "rgba(0,0,0,0.07)"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, byWa); ctx.lineTo(W, byWa); ctx.stroke();

        // baris reaksi cepat
        ctx.font = `40px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
        ctx.textAlign = "left"; ctx.textBaseline = "middle";
        const quick = ["❤️", "😂", "👍", "👆"];
        quick.forEach((e, i) => ctx.fillText(e, 48 + i * 72, byWa + 44));

        // badge "Streak Pet" — hewan emas + label (per screenshot)
        const spx = 48 + 4 * 72, spy = byWa + 20, spw = 216, sph = 52;
        ctx.fillStyle = "#F4F0FA";
        roundRectPath(ctx, spx, spy, spw, sph, sph / 2); ctx.fill();
        ctx.font = `36px "Apple Color Emoji","Noto Color Emoji","Segoe UI Emoji",sans-serif`;
        ctx.fillText("🐹", spx + 12, spy + sph / 2 + 2);
        ctx.fillStyle = "#6D28D9"; ctx.font = "700 26px Inter";
        ctx.fillText("Streak Pet", spx + 58, spy + sph / 2 + 1);

        // ikon video ungu
        const vx = spx + spw + 26, vy = byWa + 20;
        ctx.fillStyle = "#7C3AED";
        roundRectPath(ctx, vx, vy, 66, 52, 14); ctx.fill();
        ctx.fillStyle = "#FFFFFF";
        ctx.beginPath();
        ctx.moveTo(vx + 25, vy + 14); ctx.lineTo(vx + 25, vy + 38); ctx.lineTo(vx + 46, vy + 26);
        ctx.closePath(); ctx.fill();

        // pil input "Kirim pesan..."
        const ix = 100, iy = byWa + 86, iw = W - 300, ih = 76;
        ctx.fillStyle = "#F0F0F3";
        roundRectPath(ctx, ix, iy, iw, ih, ih / 2); ctx.fill();
        ctx.fillStyle = "#9AA0A6"; ctx.font = "400 30px Inter"; ctx.textAlign = "left";
        ctx.fillText("Kirim pesan...", ix + 34, iy + ih / 2);

        // ikon KAMERA di kiri pil
        ctx.strokeStyle = "#8A8A8E"; ctx.lineWidth = 3.2; ctx.lineCap = "round"; ctx.lineJoin = "round";
        roundRectPath(ctx, 32, iy + 22, 42, 36, 9); ctx.stroke();
        ctx.beginPath(); ctx.arc(53, iy + 40, 8, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(42, iy + 22); ctx.lineTo(48, iy + 15); ctx.lineTo(60, iy + 15); ctx.lineTo(65, iy + 22); ctx.stroke();

        // tiga ikon KANAN pil: galeri → stiker → mikrofon
        const rx0 = ix + iw + 24;
        const abu = "#8A8A8E";
        ctx.strokeStyle = abu; ctx.lineWidth = 3;
        roundRectPath(ctx, rx0, iy + 17, 44, 44, 10); ctx.stroke();
        ctx.beginPath(); ctx.arc(rx0 + 13, iy + 29, 4.5, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(rx0 + 6, iy + 53); ctx.lineTo(rx0 + 19, iy + 39); ctx.lineTo(rx0 + 28, iy + 47);
        ctx.lineTo(rx0 + 35, iy + 41); ctx.lineTo(rx0 + 39, iy + 46); ctx.stroke();
        ctx.beginPath(); ctx.arc(rx0 + 84, iy + 39, 21, 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = abu;
        ctx.beginPath(); ctx.arc(rx0 + 77, iy + 33, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(rx0 + 91, iy + 33, 2.6, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(rx0 + 84, iy + 42, 8, 0.15, Math.PI - 0.15); ctx.stroke();
        ctx.lineWidth = 3.4;
        roundRectPath(ctx, rx0 + 136, iy + 16, 18, 28, 9); ctx.stroke();
        ctx.beginPath(); ctx.arc(rx0 + 145, iy + 44, 13, 0, Math.PI); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(rx0 + 145, iy + 57); ctx.lineTo(rx0 + 145, iy + 63); ctx.stroke();
      }

      /* ---------- tanda air ---------- */
      ctx.fillStyle = dark ? "rgba(255,255,255,0.34)" : "rgba(0,0,0,0.35)";
      ctx.font = "500 22px 'Archivo Narrow'";
      ctx.textAlign = "center";
      ctx.fillText(KUNCI, W / 2, H - 26);
      ctx.textAlign = "left";
      return;
    }

    /* ================================================================
     * MODE TIKTOK / IPHONE — perilaku lama (tidak diubah)
     * ================================================================ */
    const maxTextW = 600;
    const menuPad = 46;

    const headerH = mode === "iphone" ? 150 : 168;
    const bottomH = mode === "iphone" ? 120 : 232;
    let totalH = headerH + 40;
    const laid = bubbles.map((b, i) => {
      const lines = wrap(b.text, bodyFont, maxTextW);
      const h = lines.length * lineH + bubblePad * 2 - 6 + (mode !== "tiktok" ? 26 : 0) + (mode === "tiktok" ? 20 : 0);
      const isTarget = i === target && mode !== "iphone";
      totalH += h + 20 + (isTarget ? 640 : 0);
      return { ...b, lines, h, isTarget };
    });
    totalH += bottomH + 90;
    canvas.width = W;
    canvas.height = Math.max(1400, totalH);
    const H = canvas.height;
    ctx.textBaseline = "middle";

    const isTikTok = mode === "tiktok";

    /* ---------- latar kontainer ---------- */
    if (isTikTok) {
      ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, 0, W, H);
    } else {
      ctx.fillStyle = "#000000"; ctx.fillRect(0, 0, W, H);
    }

    /* ---------- wallpaper chat ---------- */
    if (isTikTok) {
      ctx.fillStyle = "#F6F6F8"; ctx.fillRect(0, headerH, W, H - headerH - bottomH);
    }

    /* ---------- header ---------- */
    if (isTikTok) {
      ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, 0, W, headerH);
      ctx.strokeStyle = "rgba(0,0,0,0.07)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, headerH - 2); ctx.lineTo(W, headerH - 2); ctx.stroke();
      drawAvatar(ctx, 76, 33, 86, 43, photo, "#2F2F2F", "#111");
      ctx.fillStyle = "#111111"; ctx.font = "700 40px Inter"; ctx.textAlign = "left";
      ctx.fillText((name || "Kreator").slice(0, 20), 190, 62);
      ctx.fillStyle = "#7C7C7C"; ctx.font = "400 26px Inter";
      ctx.fillText("Komentar • 1,2 rb", 190, 108);
      drawDots(ctx, W - 70, 75, "#666666");
    } else {
      ctx.fillStyle = "rgba(20,20,22,0.96)"; ctx.fillRect(0, 0, W, headerH);
      ctx.fillStyle = "#0a84ff"; ctx.font = "600 38px Inter"; ctx.textAlign = "left";
      ctx.fillText("‹", 48, 85);
      drawAvatar(ctx, 110, 43, 84, 42, photo, "#3A3A3C", "#8E8E93");
      ctx.fillStyle = "#ffffff"; ctx.font = "600 34px Inter"; ctx.textAlign = "center";
      ctx.fillText((name || "Kontak").slice(0, 22), W / 2 + 40, 70);
      ctx.fillStyle = "#8e8e93"; ctx.font = "400 24px Inter";
      ctx.fillText("terlihat baru saja", W / 2 + 40, 108);
    }

    /* ---------- video blur (TikTok) ---------- */
    if (isTikTok) {
      const vy = headerH + 16, vh = 250;
      ctx.save();
      roundRectPath(ctx, 30, vy, W - 60, vh, 28); ctx.clip();
      const g = ctx.createLinearGradient(30, vy, W - 30, vy + vh);
      g.addColorStop(0, "#7C3AED"); g.addColorStop(0.5, "#4F46E5"); g.addColorStop(1, "#DB2777");
      ctx.fillStyle = g; ctx.fillRect(30, vy, W - 60, vh);
      ctx.fillStyle = "rgba(255,255,255,0.14)";
      for (let i = 0; i < 26; i++) {
        const x = 40 + ((i * 613) % (W - 80));
        const y = vy + 10 + ((i * 337) % (vh - 20));
        roundRectPath(ctx, x, y, 90 + (i % 4) * 46, 42, 18); ctx.fill();
      }
      ctx.fillStyle = "rgba(255,255,255,0.85)"; ctx.font = "700 40px Inter"; ctx.textAlign = "center";
      ctx.fillText("Video kreator (blur)", W / 2, vy + vh / 2);
      ctx.restore();
      drawReactionPill(ctx, W / 2, vy + vh + 8, REACTIONS.tiktok, "#FFFFFF", "rgba(0,0,0,0.06)", false, 0.85);
    }

    /* ---------- gelembung ---------- */
    ctx.textAlign = "left";
    let y = headerH + (isTikTok ? 300 : 40);
    const bubbleRects: Array<{ x: number; y: number; w: number; h: number; me: boolean; b: (typeof laid)[number] }> = [];
    for (const b of laid) {
      measureCtx.font = bodyFont;
      const bw = Math.min(
        720,
        Math.max(
          96,
          Math.max(...b.lines.map((l) => measureCtx.measureText(l).width)) + bubblePad * 2 + (b.me && !isTikTok && mode !== "iphone" ? 70 : 20),
        ),
      );
      const bx = b.me ? W - 40 - bw : isTikTok ? 40 : 40;
      bubbleRects.push({ x: bx, y, w: bw, h: b.h, me: b.me, b });
      y += b.h + 20 + (b.isTarget ? 640 : 0);
    }

    const drawBubble = (r: (typeof bubbleRects)[number]) => {
      const { x, y: by, w, h, me } = r;
      if (isTikTok) {
        ctx.fillStyle = me ? "#F0F0F3" : "#FFFFFF";
        ctx.save(); ctx.shadowColor = "rgba(0,0,0,0.08)"; ctx.shadowBlur = 10; ctx.shadowOffsetY = 2;
        roundRectPath(ctx, x, by, w, h, 18); ctx.fill(); ctx.restore();
      } else {
        if (me) {
          const g = ctx.createLinearGradient(x, by, x + w, by);
          g.addColorStop(0, "#0a84ff"); g.addColorStop(1, "#0a6ee8");
          ctx.fillStyle = g;
        } else ctx.fillStyle = "#26262a";
        roundRectPath(ctx, x, by, w, h, 20); ctx.fill();
      }
      const c2 = ctx;
      ctx.fillStyle = isTikTok ? "#111111" : "#ffffff";
      ctx.font = bodyFont;
      r.b.lines.forEach((l, i) => c2.fillText(l, r.x + bubblePad, r.y + bubblePad + 8 + i * lineH));
      const ty = by + h - 16;
      ctx.font = "400 22px Inter";
      const tw = ctx.measureText(r.b.time).width;
      if (isTikTok) {
        ctx.fillStyle = "rgba(0,0,0,0.35)";
        ctx.fillText(r.b.time, x + w - tw - 18, ty);
      } else {
        ctx.fillStyle = "rgba(255,255,255,0.45)";
        ctx.fillText(r.b.time, x + w - tw - 18, ty);
      }
    };

    for (const r of bubbleRects) drawBubble(r);

    /* ---------- MENU KONTEKS pada komentar target (TikTok) ---------- */
    if (isTikTok) {
      const tr = bubbleRects[target];
      if (tr) {
        ctx.fillStyle = "rgba(20,20,20,0.12)";
        ctx.fillRect(0, headerH, W, H - headerH - bottomH);
        drawBubble(tr);
        drawReactionPill(ctx, tr.x + tr.w / 2, tr.y - 52, REACTIONS.tiktok, "#FFFFFF", "rgba(0,0,0,0.06)", false, 0.8);
        drawLightMenu(ctx, Math.min(tr.x + 26, W - 620), tr.y + tr.h + 14, MENU_TIKTOK);
      }
    }

    /* ---------- bar bawah ---------- */
    const by0 = H - bottomH;
    if (isTikTok) {
      ctx.fillStyle = "#FFFFFF"; ctx.fillRect(0, by0, W, bottomH - 40);
      ctx.strokeStyle = "rgba(0,0,0,0.08)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, by0); ctx.lineTo(W, by0); ctx.stroke();
      const ix = 40, iy = by0 + 40, iw = W - 200, ih = 74;
      ctx.fillStyle = "#F1F1F4";
      roundRectPath(ctx, ix, iy, iw, ih, ih / 2); ctx.fill();
      ctx.fillStyle = "#9C9C9C"; ctx.font = "400 30px Inter"; ctx.textAlign = "left";
      ctx.fillText("Tambahkan komentar...", ix + 30, iy + ih / 2);
      ctx.fillStyle = "#FE2C55";
      ctx.beginPath(); ctx.arc(W - 96, iy + ih / 2, 40, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#FFFFFF"; ctx.font = "700 34px Inter"; ctx.textAlign = "center";
      ctx.fillText("✚", W - 96, iy + ih / 2 + 2);
    } else {
      ctx.fillStyle = "#1C1C1E"; ctx.fillRect(0, by0, W, bottomH - 40);
      const ix = 40, iy = by0 + 26, iw = W - 200, ih = 74;
      ctx.fillStyle = "#2C2C2E";
      roundRectPath(ctx, ix, iy, iw, ih, ih / 2); ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.5)"; ctx.font = "400 30px Inter"; ctx.textAlign = "left";
      ctx.fillText("Ketik pesan", ix + 30, iy + ih / 2);
      ctx.fillStyle = "#0a84ff";
      ctx.beginPath(); ctx.arc(W - 90, iy + ih / 2, 42, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#FFFFFF"; ctx.font = "400 34px Inter"; ctx.textAlign = "center";
      ctx.fillText("➤", W - 90, iy + ih / 2);
    }

    /* ---------- tanda air ---------- */
    ctx.fillStyle = isTikTok ? "rgba(0,0,0,0.35)" : "rgba(255,255,255,0.34)";
    ctx.font = "500 22px 'Archivo Narrow'";
    ctx.textAlign = "center";
    ctx.fillText(KUNCI, W / 2, H - 26);
    ctx.textAlign = "left";
  }, [mode, name, status, chatRaw, time, targetIdx, photo, mainMsg, mainMe, isWaMode]);

  useEffect(() => {
    render();
  }, [render]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <ToolCard
        title="Generator Obrolan Palsu"
        hint={
          isWaMode
            ? "Mode WA: latar burem otomatis; hanya pesan utama, nama, foto profil & waktu yang bisa diubah. Pil reaksi selalu DI ATAS pesan dan menu konteks DI BAWAH — persis screenshot referensi."
            : "Awali baris dengan '>' untuk pesan Anda (kanan); tanpa '>' untuk balasan (kiri)."
        }
      >
        <div className="mb-3 flex flex-wrap gap-1.5">
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                mode === m.id ? "bg-gradient-to-r from-red-500 to-cyan-500 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        <Label>Nama kontak</Label>
        <TextInput value={name} onChange={setName} maxLength={24} />
        {mode !== "iphone" && (
          <>
            <Label>Status (online / terakhir dilihat...)</Label>
            <TextInput value={status} onChange={setStatus} maxLength={24} />
          </>
        )}

        {isWaMode ? (
          <>
            {/* MODE WA: hanya pesan utama yang bisa diubah */}
            <Label>Pesan utama (chat yang ditampilkan)</Label>
            <TextArea value={mainMsg} onChange={setMainMsg} rows={3} maxLength={300} />
            <Label>Sisi pesan utama</Label>
            <div className="mb-3 flex gap-1.5">
              <button
                onClick={() => setMainMe(false)}
                className={`flex-1 rounded-xl py-2 text-[11px] font-bold transition ${!mainMe ? "bg-gradient-to-r from-red-500 to-cyan-500 text-white" : "bg-secondary/60 text-muted-foreground"}`}
              >
                Kiri (dari kontak)
              </button>
              <button
                onClick={() => setMainMe(true)}
                className={`flex-1 rounded-xl py-2 text-[11px] font-bold transition ${mainMe ? "bg-gradient-to-r from-red-500 to-cyan-500 text-white" : "bg-secondary/60 text-muted-foreground"}`}
              >
                Kanan (dari Anda)
              </button>
            </div>
          </>
        ) : (
          <>
            <Label>Isi obrolan — tiap baris 1 pesan</Label>
            <TextArea value={chatRaw} onChange={setChatRaw} rows={8} maxLength={2200} />
            {mode === "tiktok" && bubbles.length > 0 && (
              <>
                <Label>Komentar yang diberi menu (tekan-lama)</Label>
                <select
                  value={target}
                  onChange={(e) => setTargetIdx(Number(e.target.value))}
                  className="w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs font-bold outline-none"
                >
                  {bubbles.map((b, i) => (
                    <option key={i} value={i}>
                      {i + 1}. {b.me ? "(Anda) " : ""}
                      {b.text.slice(0, 32)}
                    </option>
                  ))}
                </select>
              </>
            )}
          </>
        )}

        <Label>Waktu pesan</Label>
        <TextInput value={time} onChange={setTime} maxLength={10} />
        <UploadPhoto onFile={onFile} hint="Foto profil (opsional)" />

        <DownloadButton onClick={() => downloadCanvas(canvasRef.current!, `fanzz-chat-${mode}.png`)} />
      </ToolCard>

      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className="max-h-[640px] w-auto max-w-full rounded-2xl shadow-2xl ring-1 ring-border/40" />
      </div>
    </div>
  );
}
