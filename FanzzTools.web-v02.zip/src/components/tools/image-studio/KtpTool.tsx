"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, TextInput, DownloadButton, UploadPhoto } from "./iqc-shared";
import { ensureFonts, downloadCanvas, loadImageFromFile } from "./lib";
import { useToast } from "@/hooks/use-toast";

/**
 * KTP Generator (IQC) — kartu identitas DUMMY untuk keperluan kreator/game/
 * mocking UI. TIDAK untuk penipuan: watermark besar "DUMMY FanzzTools V2"
 * diagonal dicetak permanen di hasil akhir + cap merah kecil sudut kanan bawah.
 */

export default function KtpTool() {
  const [provinsi, setProvinsi] = useState("JAWA TENGAH");
  const [kabupaten, setKabupaten] = useState("KABUPATEN KENDAL");
  const [nik, setNik] = useState("3325010101970001");
  const [nama, setNama] = useState("FANZZ FENDI PRATAMA");
  const [ttl, setTtl] = useState("KENDAL, 01-01-1997");
  const [jk, setJk] = useState("LK");
  const [gol, setGol] = useState("O");
  const [alamat, setAlamat] = useState("JL. MERDEKA NO. 10");
  const [rtrw, setRtrw] = useState("005/002");
  const [kel, setKel] = useState("SUKOMULYO");
  const [kec, setKec] = useState("KALIWUNGU");
  const [agama, setAgama] = useState("ISLAM");
  const [status, setStatus] = useState("BELUM KAWIN");
  const [pekerjaan, setPekerjaan] = useState("PEGAWAI SWASTA");
  const [wn, setWn] = useState("WNI");
  const [berlaku, setBerlaku] = useState("SEUMUR HIDUP");
  const [photo, setPhoto] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const onFile = async (f: File | null) => {
    if (!f) return setPhoto(null);
    try {
      setPhoto(await loadImageFromFile(f));
    } catch {
      toast({ title: "Gambar gagal dimuat", variant: "destructive" });
    }
  };

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    // rasio KTP asli 85mm × 53mm ≈ 1.585
    const W = 1010;
    const H = 638;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    await ensureFonts(["inter", "archivo"]);

    /* ---------- dasar kartu ---------- */
    // latar biru muda khas + tekstur gelombang samar
    ctx.fillStyle = "#dfeaf4";
    ctx.fillRect(0, 0, W, H);
    ctx.strokeStyle = "rgba(15,76,129,0.06)";
    ctx.lineWidth = 3;
    for (let i = 0; i < 8; i++) {
      ctx.beginPath();
      ctx.moveTo(0, 90 + i * 70);
      for (let x = 0; x <= W; x += 40) {
        ctx.lineTo(x, 90 + i * 70 + Math.sin(x / 90) * 16);
      }
      ctx.stroke();
    }
    // bingkai biru
    ctx.strokeStyle = "#0f4c81";
    ctx.lineWidth = 6;
    ctx.strokeRect(6, 6, W - 12, H - 12);
    ctx.strokeStyle = "rgba(15,76,129,0.35)";
    ctx.lineWidth = 2;
    ctx.strokeRect(16, 16, W - 32, H - 32);

    ctx.textBaseline = "middle";
    ctx.textAlign = "center";

    /* ---------- kepala kartu ---------- */
    ctx.fillStyle = "#0f4c81";
    ctx.font = "700 34px 'Archivo Narrow'";
    ctx.fillText(`PROVINSI ${provinsi || "_______"}`.toUpperCase().slice(0, 34), W / 2, 62);
    ctx.font = "700 30px 'Archivo Narrow'";
    ctx.fillText((kabupaten || "_______").toUpperCase().slice(0, 34), W / 2, 104);
    ctx.font = "800 40px Inter";
    ctx.fillText("KARTU TANDA PENDUDUK", W / 2, 152);
    // garis ganda
    ctx.fillStyle = "#0f4c81";
    ctx.fillRect(120, 178, W - 240, 3);
    ctx.fillRect(120, 186, W - 240, 1.5);

    /* ---------- NIK ---------- */
    ctx.textAlign = "left";
    ctx.font = "800 52px Inter";
    ctx.fillStyle = "#0f4c81";
    const nikTeks = (nik || "3xxxxxxxxxxxxxxx").replace(/\D/g, "").slice(0, 16).padEnd(16, "0");
    ctx.fillText(`NIK : ${nikTeks}`, 60, 232);

    /* ---------- foto 3×4 (kiri) ---------- */
    const pw = 150;
    const ph = 200;
    const px = 60;
    const py = 272;
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(px - 4, py - 4, pw + 8, ph + 8);
    ctx.strokeStyle = "#0f4c81";
    ctx.lineWidth = 2;
    ctx.strokeRect(px - 4, py - 4, pw + 8, ph + 8);
    if (photo) {
      // rasio cover 3:4
      const skala = Math.max(pw / photo.width, ph / photo.height);
      const dw = photo.width * skala;
      const dh = photo.height * skala;
      ctx.drawImage(photo, px + (pw - dw) / 2, py + (ph - dh) / 2, dw, dh);
      // lapisan pudar khas foto KTP
      ctx.fillStyle = "rgba(70,110,160,0.10)";
      ctx.fillRect(px, py, pw, ph);
    } else {
      ctx.fillStyle = "#c3d3e3";
      ctx.fillRect(px, py, pw, ph);
      ctx.fillStyle = "#8fa8c0";
      ctx.beginPath();
      ctx.arc(px + pw / 2, py + 74, 34, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(px + pw / 2, py + 158, 52, Math.PI, 0);
      ctx.fill();
      ctx.fillStyle = "#5a7898";
      ctx.font = "600 15px Inter";
      ctx.textAlign = "center";
      ctx.fillText("unggah foto", px + pw / 2, py + ph - 14);
      ctx.textAlign = "left";
    }

    // tanda tangan dekoratif di bawah foto
    ctx.strokeStyle = "rgba(20,20,90,0.65)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(px + 16, py + ph + 42);
    ctx.bezierCurveTo(px + 40, py + ph + 12, px + 58, py + ph + 60, px + 84, py + ph + 30);
    ctx.bezierCurveTo(px + 100, py + ph + 14, px + 116, py + ph + 40, px + 138, py + ph + 36);
    ctx.stroke();
    ctx.strokeStyle = "rgba(0,0,0,0.25)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(px, py + ph + 74);
    ctx.lineTo(px + pw, py + ph + 74);
    ctx.stroke();

    /* ---------- kolom data (kanan) ---------- */
    const fx = 250;
    const labelW = 215;
    let fy = 272;
    const baris = (
      [
        ["Nama", (nama || "_______").toUpperCase().slice(0, 32)],
        ["Tempat/Tgl Lahir", (ttl || "_______").slice(0, 32)],
        ["Jenis Kelamin", `${(jk || "LK").slice(0, 14)}   Gol. Darah : ${(gol || "-").slice(0, 4)}`],
        ["Alamat", (alamat || "_______").slice(0, 32)],
        ["RT/RW", (rtrw || "___/___").slice(0, 12)],
        ["Kel/Desa", (kel || "_______").slice(0, 26)],
        ["Kecamatan", (kec || "_______").slice(0, 26)],
        ["Agama", (agama || "_______").slice(0, 20)],
        ["Status Perkawinan", (status || "_______").slice(0, 20)],
        ["Pekerjaan", (pekerjaan || "_______").slice(0, 30)],
        ["Kewarganegaraan", (wn || "WNI").slice(0, 12)],
        ["Berlaku Hingga", (berlaku || "_______").slice(0, 24)],
      ] as Array<[string, string]>
    );
    ctx.font = "400 24px Inter";
    for (const [label, nilai] of baris) {
      ctx.fillStyle = "#333a45";
      ctx.textAlign = "left";
      ctx.fillText(`: ${nilai}`, fx + labelW, fy);
      fy += 30;
    }
    // label digambar terpisah supaya tidak bergeser
    fy = 272;
    ctx.font = "700 24px Inter";
    ctx.fillStyle = "#222831";
    for (const [label] of baris) {
      ctx.fillText(label, fx, fy);
      fy += 30;
    }

    /* ---------- kode batang dekoratif ---------- */
    let seed = parseInt(nikTeks.slice(0, 8) || "12345678", 10) || 12345678;
    const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
    const bx0 = W - 190;
    const by0 = 556;
    ctx.fillStyle = "#222831";
    for (let x = 0; x < 120; x += 4) {
      const lebar = 1 + Math.floor(rnd() * 3);
      ctx.fillRect(bx0 + x, by0, lebar, 40);
    }
    ctx.font = "500 14px 'Archivo Narrow'";
    ctx.fillText(nikTeks.slice(0, 13), bx0 + 58, by0 + 52);

    /* ---------- cap merah kecil sudut kanan bawah ---------- */
    ctx.textAlign = "right";
    ctx.fillStyle = "rgba(200,20,20,0.85)";
    ctx.font = "700 15px 'Archivo Narrow'";
    ctx.fillText("dummy ktp, this not real!", W - 30, H - 30);
    ctx.textAlign = "left";

    /* ---------- WATERMARK BESAR DIAGONAL (kiri-bawah → kanan-atas) ---------- */
    ctx.save();
    ctx.translate(W / 2, H / 2);
    ctx.rotate(-Math.atan2(H - 60, W - 60)); // arah dari kiri-bawah ke kanan-atas
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    // ganda: outline tebal + isi semi-transparan supaya sulit dihapus
    const wmText = "DUMMY  FanzzTools V2";
    ctx.font = `900 ${Math.floor(W / 9.2)}px Inter`;
    ctx.lineWidth = 14;
    ctx.strokeStyle = "rgba(210,0,0,0.42)";
    ctx.strokeText(wmText, 0, 0);
    ctx.fillStyle = "rgba(210,0,0,0.30)";
    ctx.fillText(wmText, 0, 0);
    // salinan kedua lebih tipis di atasnya (menyilang)
    ctx.rotate(Math.PI / 24);
    ctx.font = `900 ${Math.floor(W / 14)}px Inter`;
    ctx.lineWidth = 8;
    ctx.strokeStyle = "rgba(210,0,0,0.28)";
    ctx.strokeText(wmText, 0, -86);
    ctx.fillStyle = "rgba(210,0,0,0.18)";
    ctx.fillText(wmText, 0, -86);
    ctx.restore();
  }, [provinsi, kabupaten, nik, nama, ttl, jk, gol, alamat, rtrw, kel, kec, agama, status, pekerjaan, wn, berlaku, photo]);

  useEffect(() => {
    render();
  }, [render]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <ToolCard
        title="KTP Dummy Generator"
        hint="Kartu identitas palsu untuk keperluan kreator/mock UI. Watermark DUMMY dicetak permanen di hasil — tidak untuk penipuan."
      >
        <Label>Provinsi</Label>
        <TextInput value={provinsi} onChange={setProvinsi} maxLength={30} />
        <Label>Kabupaten / Kota</Label>
        <TextInput value={kabupaten} onChange={setKabupaten} maxLength={30} />
        <Label>NIK (16 digit, bebas)</Label>
        <TextInput value={nik} onChange={(v) => setNik(v.replace(/\D/g, "").slice(0, 16))} maxLength={16} />
        <Label>Nama Lengkap</Label>
        <TextInput value={nama} onChange={setNama} maxLength={32} />
        <Label>Tempat / Tanggal Lahir</Label>
        <TextInput value={ttl} onChange={setTtl} maxLength={32} />
        <div className="flex gap-2">
          <div className="flex-1">
            <Label>Jenis Kelamin</Label>
            <TextInput value={jk} onChange={setJk} maxLength={14} />
          </div>
          <div className="w-24">
            <Label>Gol. Darah</Label>
            <TextInput value={gol} onChange={setGol} maxLength={4} />
          </div>
        </div>
        <Label>Alamat</Label>
        <TextInput value={alamat} onChange={setAlamat} maxLength={32} />
        <div className="flex gap-2">
          <div className="w-32">
            <Label>RT/RW</Label>
            <TextInput value={rtrw} onChange={setRtrw} maxLength={10} />
          </div>
          <div className="flex-1">
            <Label>Kel/Desa</Label>
            <TextInput value={kel} onChange={setKel} maxLength={26} />
          </div>
        </div>
        <Label>Kecamatan</Label>
        <TextInput value={kec} onChange={setKec} maxLength={26} />
        <Label>Agama</Label>
        <TextInput value={agama} onChange={setAgama} maxLength={20} />
        <Label>Status Perkawinan</Label>
        <TextInput value={status} onChange={setStatus} maxLength={20} />
        <Label>Pekerjaan</Label>
        <TextInput value={pekerjaan} onChange={setPekerjaan} maxLength={30} />
        <div className="flex gap-2">
          <div className="w-28">
            <Label>Kewarga-</Label>
            <TextInput value={wn} onChange={setWn} maxLength={12} />
          </div>
          <div className="flex-1">
            <Label>Berlaku Hingga</Label>
            <TextInput value={berlaku} onChange={setBerlaku} maxLength={24} />
          </div>
        </div>
        <UploadPhoto onFile={onFile} hint="Foto 3×4 (opsional)" />

        <DownloadButton onClick={() => downloadCanvas(canvasRef.current!, "fanzz-ktp-dummy.png")} label="Unduh KTP Dummy" />
      </ToolCard>

      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className="w-full max-w-[620px] rounded-xl shadow-2xl ring-1 ring-border/40" />
      </div>
    </div>
  );
}
