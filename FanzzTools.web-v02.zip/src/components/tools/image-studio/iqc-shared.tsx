"use client";

import { ReactNode } from "react";
import { Download } from "lucide-react";

/** Komponen antarmuka bersama untuk generator IQC (Studio Gambar V2.11). */

export function ToolCard({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="glass rounded-2xl p-4">
      <h3 className="mb-1 text-sm font-extrabold">{title}</h3>
      {hint && <p className="mb-3 text-[10px] leading-snug text-muted-foreground">{hint}</p>}
      <div className="space-y-0">{children}</div>
    </div>
  );
}

export function Label({ children }: { children: ReactNode }) {
  return <p className="mb-1.5 mt-3 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">{children}</p>;
}

export function TextInput({
  value,
  onChange,
  placeholder,
  maxLength = 120,
  type = "text",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  maxLength?: number;
  type?: string;
}) {
  return (
    <input
      type={type}
      value={value}
      placeholder={placeholder}
      maxLength={maxLength}
      onChange={(e) => onChange(e.target.value)}
      className="mb-1 w-full rounded-xl border border-border/60 bg-secondary/50 px-3 py-2.5 text-xs outline-none focus:border-red-400/50"
    />
  );
}

export function TextArea({
  value,
  onChange,
  rows = 3,
  maxLength = 400,
  mono,
}: {
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  maxLength?: number;
  mono?: boolean;
}) {
  return (
    <textarea
      value={value}
      rows={rows}
      maxLength={maxLength}
      onChange={(e) => onChange(e.target.value)}
      className={`mb-1 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-red-400/50 ${mono ? "font-mono" : ""}`}
    />
  );
}

export function ColorInput({ value, onChange, label }: { value: string; onChange: (v: string) => void; label?: string }) {
  return (
    <label className="flex items-center gap-2 rounded-xl border border-border/60 bg-secondary/50 px-3 py-2 text-xs">
      <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="h-7 w-9 cursor-pointer rounded border-0 bg-transparent p-0" />
      <span className="font-mono text-[10px] text-muted-foreground">{label || value}</span>
    </label>
  );
}

export function DownloadButton({ onClick, label = "Unduh PNG" }: { onClick: () => void; label?: string }) {
  return (
    <button
      onClick={onClick}
      className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-red-500 to-red-700 px-4 py-3 text-xs font-extrabold text-white shadow-lg shadow-red-500/20 transition-transform active:scale-95"
    >
      <Download className="h-4 w-4" /> {label}
    </button>
  );
}

export function UploadPhoto({
  onFile,
  hint = "Opsional — diproses di perangkat Anda",
}: {
  onFile: (f: File | null) => void;
  hint?: string;
}) {
  return (
    <label className="mt-3 flex cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-border/70 bg-secondary/30 px-3 py-3 text-[11px] font-bold text-muted-foreground transition hover:border-red-400/50 hover:text-foreground">
      <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current">
        <path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z" />
      </svg>
      Unggah foto
      <input
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => onFile(e.target.files?.[0] || null)}
      />
      <span className="sr-only">{hint}</span>
    </label>
  );
}
