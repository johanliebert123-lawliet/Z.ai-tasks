"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { EmptyState } from "@/components/tools/shared";
import {
  ensureFonts, loadImageFromFile, downloadCanvas, drawCover,
} from "@/components/tools/image-studio/lib";
import { Upload, Download, Image as ImageIcon, Loader2, Sparkles } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

type WarnaMode = "bw" | "gray" | "color";
type LatarMode = "white" | "black" | "transparent";

interface SpiralParams {
  turns: number;
  lwScale: number;
  gamma: number;
  arms: number;
  mode: WarnaMode;
  bg: LatarMode;
}

const PARAMS_DEFAULT: SpiralParams = {
  turns: 40,
  lwScale: 1,
  gamma: 1,
  arms: 1,
  mode: "bw",
  bg: "white",
};

/**
 * Merender foto menjadi seni garis spiral (archimedean spiral).
 * Tebal garis mengikuti kecerahan foto: area gelap = garis tebal, terang = garis tipis,
 * sehingga hasil selalu MENYESUAIKAN DIRI dengan foto yang dipilih.
 * Berjalan bertahap (async) agar antarmuka tidak macet pada resolusi besar.
 */
async function renderSpiral(
  canvas: HTMLCanvasElement,
  img: HTMLImageElement,
  p: SpiralParams,
  onProgress?: (frac: number) => void,
): Promise<void> {
  const size = canvas.width;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  // latar
  ctx.clearRect(0, 0, size, size);
  if (p.bg !== "transparent") {
    ctx.fillStyle = p.bg === "white" ? "#ffffff" : "#000000";
    ctx.fillRect(0, 0, size, size);
  }

  // sumber sampel piksel (di-kecilkan ke ukuran kanvas, cover-crop)
  const smp = document.createElement("canvas");
  smp.width = size;
  smp.height = size;
  const sctx = smp.getContext("2d", { willReadFrequently: true });
  if (!sctx) return;
  drawCover(sctx, img, img.naturalWidth || img.width, img.naturalHeight || img.height, 0, 0, size, size);
  const data = sctx.getImageData(0, 0, size, size).data;
  const sample = (x: number, y: number) => {
    const xi = Math.max(0, Math.min(size - 1, x | 0));
    const yi = Math.max(0, Math.min(size - 1, y | 0));
    const i = (yi * size + xi) * 4;
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const l = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    return { r, g, b, l };
  };

  const cx = size / 2;
  const cy = size / 2;
  const maxR = size * 0.492;
  const ringGap = (2 * maxR) / p.turns; // jarak radial antar cincin spiral
  const thetaMax = p.turns * 2 * Math.PI;
  const inverted = p.bg === "black"; // pada latar hitam: kecerahan yang menentukan ketebalan
  const baseStep = Math.max(1.4, size / 640);

  ctx.lineCap = "round";
  ctx.lineJoin = "round";

  // pengelompokan segmen dengan kuantisasi tebal (0.25px) & warna (4bit/kanal)
  // supaya jumlah panggilan stroke() jauh berkurang
  let currentKey = -1;
  let pathOpen = false;
  const flush = () => {
    if (pathOpen) {
      ctx.stroke();
      pathOpen = false;
    }
  };

  let segCount = 0;
  const tick = () => new Promise<void>((r) => setTimeout(r, 0));

  for (let arm = 0; arm < p.arms; arm++) {
    const phase = (arm / p.arms) * 2 * Math.PI;
    let theta = phase + (2 * Math.PI * 1.2) / ringGap; // mulai setelah pusat nyaris nol
    let px = 0;
    let py = 0;
    let first = true;

    while (true) {
      const r = (ringGap * (theta - phase)) / (2 * Math.PI);
      if (r > maxR) break;
      const x = cx + r * Math.cos(theta);
      const y = cy + r * Math.sin(theta);

      if (!first) {
        const s = sample((px + x) / 2, (py + y) / 2);
        const lNorm = inverted ? s.l : 1 - s.l;
        const tebal = Math.max(0.55, ringGap * p.lwScale * Math.pow(lNorm, p.gamma));

        // warna garis menurut mode
        let colorKey: number;
        let color: string;
        if (p.mode === "bw") {
          color = inverted ? "#ffffff" : "#000000";
          colorKey = 0;
        } else if (p.mode === "gray") {
          const v = Math.round(s.l * 31);
          colorKey = v;
          const c = inverted ? Math.round(90 + (s.l * 165)) : Math.round(255 - v * 8.2);
          color = `rgb(${c},${c},${c})`;
        } else {
          const qr = s.r >> 4;
          const qg = s.g >> 4;
          const qb = s.b >> 4;
          colorKey = 1 + qr * 256 + qg * 16 + qb;
          color = `rgb(${qr * 17},${qg * 17},${qb * 17})`;
        }

        const qt = Math.round(tebal * 4);
        const key = qt * 1000000 + colorKey;
        if (key !== currentKey) {
          flush();
          currentKey = key;
          ctx.strokeStyle = color;
          ctx.lineWidth = qt / 4;
          ctx.beginPath();
          pathOpen = true;
        }
        ctx.moveTo(px, py);
        ctx.lineTo(x, y);

        segCount++;
        if (segCount % 5000 === 0) {
          flush();
          await tick();
          onProgress?.((arm + (theta - phase) / thetaMax) / p.arms);
        }
      }

      px = x;
      py = y;
      first = false;

      // langkah adaptif: halus di pusat yang melengkung rapat, hemat di tepi
      const step = Math.max(baseStep, Math.min(ringGap * 0.13, Math.max(r, 2) * 0.14));
      theta += Math.min(0.3, step / Math.max(r, 2));
    }
    flush();
    onProgress?.((arm + 1) / p.arms);
  }
  onProgress?.(1);
}

const PREVIEW_SIZE = 560;

export default function SpiralTool() {
  const [img, setImg] = useState<HTMLImageElement | null>(null);
  const [namaFile, setNamaFile] = useState("");
  const [params, setParams] = useState<SpiralParams>(PARAMS_DEFAULT);
  const [resolusi, setResolusi] = useState("2048");
  const [merender, setMerender] = useState(false);
  const [progres, setProgres] = useState(0);
  const [menyiapkan, setMenyiapkan] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  // muat font sekali (tidak dipakai untuk menggambar, tapi menyiapkan konteks) + render awal
  useEffect(() => {
    void ensureFonts(["inter"]);
  }, []);

  const gambarPreview = useCallback(
    (source: HTMLImageElement | null, p: SpiralParams) => {
      const canvas = canvasRef.current;
      if (!canvas || !source) return;
      canvas.width = PREVIEW_SIZE;
      canvas.height = PREVIEW_SIZE;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      if (p.bg !== "transparent") {
        ctx.fillStyle = p.bg === "white" ? "#ffffff" : "#000000";
        ctx.fillRect(0, 0, PREVIEW_SIZE, PREVIEW_SIZE);
      } else {
        ctx.clearRect(0, 0, PREVIEW_SIZE, PREVIEW_SIZE);
      }
      setMerender(true);
      setProgres(0);
      void renderSpiral(canvas, source, p, (f) => setProgres(f)).finally(() => setMerender(false));
    },
    [],
  );

  // render ulang tiap parameter / gambar berubah
  useEffect(() => {
    gambarPreview(img, params);
  }, [img, params, gambarPreview]);

  const pilihFoto = async (file: File | undefined) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast({ title: "Berkas bukan gambar", description: "Silakan pilih berkas JPG, PNG, atau WebP.", variant: "destructive" });
      return;
    }
    try {
      const gambar = await loadImageFromFile(file);
      setImg(gambar);
      setNamaFile(file.name);
      toast({ title: "Foto dimuat", description: "Spiral menyesuaikan diri otomatis dengan foto Anda." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    }
  };

  const unduh = async () => {
    if (!img) return;
    setMenyiapkan(true);
    try {
      const ukuran = Number(resolusi);
      const kanvas = document.createElement("canvas");
      kanvas.width = ukuran;
      kanvas.height = ukuran;
      await renderSpiral(kanvas, img, params);
      downloadCanvas(kanvas, `fanzz-spiral-${ukuran}px.png`);
      pushHistory("studio", {
        id: `spiral-${Date.now()}`,
        title: "Spiral PFP diunduh",
        subtitle: `${ukuran}px • ${params.turns} putaran • ${
          params.mode === "bw" ? "hitam-putih" : params.mode === "gray" ? "abu-abu" : "warna asli"
        }`,
      });
      toast({ title: "Gambar spiral terunduh", description: `Resolusi ${ukuran} x ${ukuran} piksel — siap dipakai sebagai foto profil.` });
    } catch {
      toast({ title: "Gagal menyiapkan gambar", variant: "destructive" });
    } finally {
      setMenyiapkan(false);
    }
  };

  const ubah = <K extends keyof SpiralParams>(k: K, v: SpiralParams[K]) =>
    setParams((p) => ({ ...p, [k]: v }));

  return (
    <div className="space-y-4">
      {/* unggah foto */}
      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <label className="flex cursor-pointer items-center gap-3 rounded-xl bg-gradient-to-r from-red-500/15 to-red-700/15 p-3 ring-1 ring-red-400/20 transition hover:from-red-500/25 hover:to-red-700/25">
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => pilihFoto(e.target.files?.[0])}
          />
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-white shadow-md">
            <Upload className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">{img ? "Ganti Foto" : "Pilih Foto"}</p>
            <p className="truncate text-[11px] text-muted-foreground">
              {namaFile || "JPG / PNG / WebP — diproses sepenuhnya di perangkat Anda"}
            </p>
          </div>
        </label>
      </div>

      {!img ? (
        <EmptyState
          icon={<ImageIcon className="h-10 w-10" />}
          title="Belum ada foto"
          desc="Pilih foto terlebih dahulu — wajah atau objek dengan latar kontras menghasilkan spiral terbaik."
        />
      ) : (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          {/* pratinjau */}
          <div className="relative mx-auto w-full max-w-[420px]">
            <div className="checker overflow-hidden rounded-2xl border border-[var(--surface-line)] shadow-xl">
              <canvas ref={canvasRef} className="block h-auto w-full" />
            </div>
            {merender && (
              <div className="absolute inset-x-0 bottom-0 rounded-b-2xl bg-black/70 p-2 backdrop-blur-sm">
                <div className="flex items-center gap-2 text-[10px] font-bold text-white">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span className="tabular-nums">Merender {Math.round(progres * 100)}%</span>
                  <div className="ml-auto h-1 w-24 overflow-hidden rounded-full bg-white/20">
                    <div className="h-full rounded-full bg-red-400 transition-all" style={{ width: `${progres * 100}%` }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* mode warna */}
          <div>
            <p className="mb-1.5 text-xs font-bold text-muted-foreground">Mode Warna</p>
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: "bw", label: "Hitam-Putih" },
                { id: "gray", label: "Abu-Abu" },
                { id: "color", label: "Warna Asli" },
              ] as const).map((m) => (
                <button
                  key={m.id}
                  onClick={() => ubah("mode", m.id)}
                  className={`rounded-xl px-3 py-2 text-xs font-bold transition ${
                    params.mode === m.id
                      ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                      : "bg-secondary hover:bg-secondary/70"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* latar */}
          <div>
            <p className="mb-1.5 text-xs font-bold text-muted-foreground">Latar</p>
            <div className="grid grid-cols-3 gap-2">
              {([
                { id: "white", label: "Putih" },
                { id: "black", label: "Hitam" },
                { id: "transparent", label: "Transparan" },
              ] as const).map((m) => (
                <button
                  key={m.id}
                  onClick={() => ubah("bg", m.id)}
                  className={`rounded-xl px-3 py-2 text-xs font-bold transition ${
                    params.bg === m.id
                      ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                      : "bg-secondary hover:bg-secondary/70"
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* kerapatan & tebal */}
          <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
            <div>
              <div className="mb-1.5 flex items-baseline justify-between">
                <p className="text-xs font-bold">Kerapatan Garis Spiral</p>
                <span className="text-[10px] font-bold tabular-nums text-red-400">
                  {params.turns} putaran {params.turns >= 60 ? "(rapat)" : params.turns <= 24 ? "(longgar)" : "(sedang)"}
                </span>
              </div>
              <Slider
                min={12}
                max={90}
                step={1}
                value={[params.turns]}
                onValueChange={(v) => ubah("turns", v[0])}
              />
              <p className="mt-1 text-[10px] text-muted-foreground">Sedikit garis = garis besar berani; banyak garis = detail halus.</p>
            </div>
            <div>
              <div className="mb-1.5 flex items-baseline justify-between">
                <p className="text-xs font-bold">Ketebalan Garis</p>
                <span className="text-[10px] font-bold tabular-nums text-red-400">{params.lwScale.toFixed(2)}x</span>
              </div>
              <Slider
                min={0.4}
                max={1.6}
                step={0.05}
                value={[params.lwScale]}
                onValueChange={(v) => ubah("lwScale", v[0])}
              />
            </div>
            <div>
              <div className="mb-1.5 flex items-baseline justify-between">
                <p className="text-xs font-bold">Kontras Gelap-Terang</p>
                <span className="text-[10px] font-bold tabular-nums text-red-400">{params.gamma.toFixed(2)}</span>
              </div>
              <Slider
                min={0.5}
                max={2.5}
                step={0.05}
                value={[params.gamma]}
                onValueChange={(v) => ubah("gamma", v[0])}
              />
            </div>
            <div className="flex items-center justify-between gap-3">
              <p className="text-xs font-bold">Jalur Spiral</p>
              <Select value={String(params.arms)} onValueChange={(v) => ubah("arms", Number(v))}>
                <SelectTrigger className="h-9 w-36 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 garis</SelectItem>
                  <SelectItem value="2">2 garis sejajar</SelectItem>
                  <SelectItem value="3">3 garis sejajar</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* unduh */}
          <div className="flex flex-wrap items-center gap-2">
            <Select value={resolusi} onValueChange={setResolusi}>
              <SelectTrigger className="h-11 w-32 text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1024">1024 px</SelectItem>
                <SelectItem value="2048">2048 px</SelectItem>
              </SelectContent>
            </Select>
            <Button
              onClick={unduh}
              disabled={menyiapkan}
              className="h-11 flex-1 bg-gradient-to-r from-red-500 to-red-700 font-bold"
            >
              {menyiapkan ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Download className="mr-2 h-4 w-4" />}
              {menyiapkan ? "Menyiapkan..." : "Unduh PNG"}
            </Button>
          </div>

          <p className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <Sparkles className="h-3 w-3 text-red-400" />
            Foto diproses sepenuhnya di perangkat Anda — tidak ada data yang diunggah ke server.
          </p>
        </motion.div>
      )}
    </div>
  );
}
