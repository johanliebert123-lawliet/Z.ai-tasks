"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, TextInput, TextArea, DownloadButton, UploadPhoto } from "./iqc-shared";
import { ensureFonts, downloadCanvas, loadImageFromFile, roundRectPath, drawCover } from "./lib";
import { useToast } from "@/hooks/use-toast";

/** Notifikasi Generator (IQC) — banner notifikasi WhatsApp / iPhone / Android, teks bisa diubah. */

type Mode = "wa" | "iphone" | "android";

const MODES: Array<{ id: Mode; label: string }> = [
  { id: "wa", label: "WhatsApp" },
  { id: "iphone", label: "iPhone" },
  { id: "android", label: "Android" },
];

export default function NotifTool() {
  const [mode, setMode] = useState<Mode>("wa");
  const [app, setApp] = useState("WhatsApp");
  const [judul, setJudul] = useState("Circle Luca");
  const [pesan, setPesan] = useState("bro, udah coba Studio Gambar di FanzzTools?");
  const [waktu, setWaktu] = useState("sekarang");
  const [photo, setPhoto] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const onFile = async (f: File | null) => {
    if (!f) return setPhoto(null);
    try {
      setPhoto(await loadImageFromFile(f));
    } catch {
      toast({ title: "Gambar gagal dimuat", variant: "destructive" });
    }
  };

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const W = 1170;
    const H = 900;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    await ensureFonts(["inter", "archivo"]);

    /* wallpaper latar gradien gelap (meniru layar kunci) */
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, "#1c1440");
    g.addColorStop(0.55, "#31135c");
    g.addColorStop(1, "#0d0722");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    // jam besar layar kunci
    ctx.fillStyle = "rgba(255,255,255,0.92)";
    ctx.font = "200 92px Inter";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("21:47", W / 2, 190);
    ctx.font = "500 30px Inter";
    ctx.fillStyle = "rgba(255,255,255,0.6)";
    ctx.fillText("Kamis, 17 September", W / 2, 258);
    ctx.textAlign = "left";

    /* banner notifikasi */
    const bx = 36;
    const bw = W - 72;
    const bh = 190;
    const by = 340;

    if (mode === "iphone") {
      // iOS: kartu kaca transparan blur-ish
      ctx.fillStyle = "rgba(60,60,68,0.55)";
      roundRectPath(ctx, bx, by, bw, bh, 42);
      ctx.fill();
    } else {
      ctx.fillStyle = mode === "wa" ? "#1f2c34" : "#202124";
      roundRectPath(ctx, bx, by, bw, bh, 36);
      ctx.fill();
      ctx.strokeStyle = "rgba(255,255,255,0.08)";
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    /* ikon aplikasi / foto */
    const isz = 100;
    const ix = bx + 34;
    const iy = by + (bh - isz) / 2;
    if (photo) {
      ctx.save();
      roundRectPath(ctx, ix, iy, isz, isz, mode === "iphone" ? 22 : 50);
      ctx.clip();
      drawCover(ctx, photo, photo.width, photo.height, ix, iy, isz, isz);
      ctx.restore();
    } else if (mode === "wa") {
      ctx.fillStyle = "#25d366";
      ctx.beginPath();
      ctx.arc(ix + isz / 2, iy + isz / 2, isz / 2, 0, Math.PI * 2);
      ctx.fill();
      // telepon WA sederhana
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(ix + isz / 2, iy + isz / 2, 30, -0.4, 2.2);
      ctx.arc(ix + isz / 2 - 12, iy + isz / 2 + 4, 12, 2.2, 4.6);
      ctx.fill();
    } else if (mode === "android") {
      ctx.fillStyle = "#3ddc84";
      roundRectPath(ctx, ix, iy, isz, isz, 26);
      ctx.fill();
      ctx.fillStyle = "#202124";
      ctx.font = "800 54px Inter";
      ctx.textAlign = "center";
      ctx.fillText("A", ix + isz / 2, iy + isz / 2 + 4);
      ctx.textAlign = "left";
    } else {
      ctx.fillStyle = "rgba(255,255,255,0.25)";
      roundRectPath(ctx, ix, iy, isz, isz, 22);
      ctx.fill();
    }

    /* teks banner */
    const tx = ix + isz + 34;
    ctx.textBaseline = "middle";
    // baris atas: nama app kecil + waktu kanan
    ctx.font = "600 26px 'Archivo Narrow'";
    ctx.fillStyle = "rgba(255,255,255,0.55)";
    ctx.fillText((app || "Aplikasi").slice(0, 20).toUpperCase(), tx, by + 42);
    ctx.textAlign = "right";
    ctx.fillText((waktu || "sekarang").slice(0, 14), bx + bw - 34, by + 42);
    ctx.textAlign = "left";
    // judul
    ctx.font = "700 36px Inter";
    ctx.fillStyle = "#ffffff";
    ctx.fillText((judul || "Judul").slice(0, 34), tx, by + 92);
    // pesan (wrap 2 baris)
    ctx.font = "400 30px Inter";
    ctx.fillStyle = "rgba(255,255,255,0.78)";
    const maxW = bw - (tx - bx) - 70;
    let baris = "";
    let py2 = by + 140;
    const kata = (pesan || "pesan").split(/\s+/);
    const lines: string[] = [];
    for (const k of kata) {
      const c = baris ? `${baris} ${k}` : k;
      if (ctx.measureText(c).width > maxW) {
        lines.push(baris);
        baris = k;
        if (lines.length === 2) break;
      } else baris = c;
    }
    if (lines.length < 2 && baris) lines.push(baris);
    lines.slice(0, 2).forEach((l, i) => ctx.fillText(l, tx, py2 + i * 38));

    /* tanda air */
    ctx.textAlign = "center";
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.font = "500 22px 'Archivo Narrow'";
    ctx.fillText("Testing Generator • By : FanzzTools™", W / 2, H - 44);
    ctx.textAlign = "left";
  }, [mode, app, judul, pesan, waktu, photo]);

  useEffect(() => {
    render();
  }, [render]);

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      <ToolCard title="Notifikasi Generator" hint="Banner notifikasi di layar kunci — gaya WA / iPhone / Android.">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => {
                setMode(m.id);
                if (m.id === "wa") setApp("WhatsApp");
                if (m.id === "iphone") setApp("Pesan");
                if (m.id === "android") setApp("Aplikasi");
              }}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                mode === m.id ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>
        <Label>Nama aplikasi</Label>
        <TextInput value={app} onChange={setApp} maxLength={20} />
        <Label>Judul (nama pengirim)</Label>
        <TextInput value={judul} onChange={setJudul} maxLength={34} />
        <Label>Isi pesan</Label>
        <TextArea value={pesan} onChange={setPesan} rows={3} maxLength={160} />
        <Label>Waktu</Label>
        <TextInput value={waktu} onChange={setWaktu} maxLength={14} />
        <UploadPhoto onFile={onFile} hint="Ikon foto profil (opsional)" />
        <DownloadButton onClick={() => downloadCanvas(canvasRef.current!, `fanzz-notif-${mode}.png`)} />
      </ToolCard>

      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className="max-h-[520px] w-auto max-w-full rounded-xl shadow-2xl ring-1 ring-border/40" />
      </div>
    </div>
  );
}
