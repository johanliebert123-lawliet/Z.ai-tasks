"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Upload, Download, Loader2 } from "lucide-react";
import {
  ensureFonts, loadImageFromFile, downloadCanvas, paintGradient, drawCover,
  roundRectPath, wrapLines, WALLPAPERS,
} from "@/components/tools/image-studio/lib";
import { useToast } from "@/hooks/use-toast";
import { pushHistory } from "@/lib/history";

/**
 * IQC — iPhone Quote Card (V2 Modern-UpdSec — UPGRADE BESAR).
 *
 * Mode "Layar Kunci": kartu pesan kaca embun di layar kunci iPhone (tetap).
 *
 * Mode "Obrolan WA" (UPGRADED): dulu gaya iMessage — sekarang TIRUAN
 * WHATSAPP iOS DARK MODE persis seperti tangkapan layar asli:
 *  - header: panah kembali, AVATAR KONTAK (bisa di-upload foto sendiri),
 *    nama tebal + status "online", ikon video & telepon
 *  - gelembung: masuk #202C33 (kiri, ekor), keluar #005C4B (kanan, ekor)
 *  - waktu di dalam gelembung + centang biru ganda (dibaca) untuk keluar
 *  - chip tanggal "HARI INI", input bar bawah dengan mikrofon
 *  - wallpaper chat opsional (foto sendiri) atau warna WA
 *
 * Semua digambar lokal di kanvas — tanpa API eksternal.
 */

const W = 1170;
const H = 2532;

const HARI_ID = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const BULAN_ID = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

function tanggalIndonesia(d = new Date()) {
  return `${HARI_ID[d.getDay()]}, ${d.getDate()} ${BULAN_ID[d.getMonth()]}`;
}

// ---------------------------------------------------------------- elemen UI iOS

function gambarStatusBar(
  ctx: CanvasRenderingContext2D,
  carrier: string,
  jam: string,
  baterai: number,
  sinyal: number,
  lebar: number,
) {
  ctx.save();
  ctx.fillStyle = "#ffffff";
  ctx.textBaseline = "middle";

  // operator + jam kecil (kiri)
  ctx.textAlign = "left";
  ctx.font = "600 44px Inter, -apple-system, sans-serif";
  ctx.fillText(carrier.toUpperCase(), 72, 92);
  const wCarrier = ctx.measureText(carrier.toUpperCase()).width;
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.fillText(jam, 72 + wCarrier + 34, 92);

  // sinyal (4 batang)
  const sx = lebar - 470;
  for (let i = 0; i < 4; i++) {
    const bh = 12 + i * 11;
    ctx.fillStyle = i < sinyal ? "#ffffff" : "rgba(255,255,255,0.35)";
    roundRectPath(ctx, sx + i * 17, 100 - bh, 10, bh, 5);
    ctx.fill();
  }

  // wifi (tiga busur + titik)
  const wx = lebar - 355;
  ctx.strokeStyle = "#ffffff";
  ctx.lineCap = "round";
  for (let i = 0; i < 3; i++) {
    ctx.lineWidth = 9;
    ctx.beginPath();
    ctx.arc(wx + 16, 104, 8 + i * 13, Math.PI * 1.25, Math.PI * 1.75);
    ctx.stroke();
  }
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(wx + 16, 100, 6, 0, Math.PI * 2);
  ctx.fill();

  // baterai
  const bx = lebar - 240;
  ctx.lineWidth = 6;
  ctx.strokeStyle = "rgba(255,255,255,0.55)";
  roundRectPath(ctx, bx, 68, 100, 52, 14);
  ctx.stroke();
  roundRectPath(ctx, bx + 106, 84, 10, 20, 4);
  ctx.fillStyle = "rgba(255,255,255,0.55)";
  ctx.fill();
  const level = Math.max(0, Math.min(100, baterai)) / 100;
  ctx.fillStyle = level > 0.2 ? "#ffffff" : "#FF453A";
  roundRectPath(ctx, bx + 7, 75, Math.max(8, 86 * level), 38, 8);
  ctx.fill();

  // persentase
  ctx.textAlign = "right";
  ctx.fillStyle = "#ffffff";
  ctx.font = "600 40px Inter, -apple-system, sans-serif";
  ctx.fillText(`${baterai}%`, bx - 18, 94);

  // pulau dinamis
  ctx.fillStyle = "#000000";
  roundRectPath(ctx, lebar / 2 - 190, 28, 380, 118, 59);
  ctx.fill();
  ctx.restore();
}

function gambarIndikatorRumah(ctx: CanvasRenderingContext2D, tinggi: number) {
  ctx.fillStyle = "rgba(255,255,255,0.92)";
  roundRectPath(ctx, W / 2 - 210, tinggi - 46, 420, 12, 6);
  ctx.fill();
}

/** Avatar bulat — foto upload atau lingkaran bernama awal. */
function gambarAvatar(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  foto: HTMLImageElement | null,
  inisial: string,
) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  if (foto) {
    drawCover(ctx, foto, foto.naturalWidth, foto.naturalHeight, cx - r, cy - r, r * 2, r * 2, 1);
  } else {
    const g = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    g.addColorStop(0, "#6A7175");
    g.addColorStop(1, "#3B4A50");
    ctx.fillStyle = g;
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2);
    ctx.fillStyle = "#E9EDEF";
    ctx.font = `700 ${Math.round(r * 1.05)}px Inter, -apple-system, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(inisial.toUpperCase(), cx, cy + r * 0.05);
  }
  ctx.restore();
}

// ---------------------------------------------------------------- mode layar kunci

interface OpsiKunci {
  carrier: string;
  jam: string;
  baterai: number;
  sinyal: number;
  pengirim: string;
  pesan: string;
  wallpaper: { c1: string; c2: string; angle: number };
  foto: HTMLImageElement | null;
}

function gambarKunci(canvas: HTMLCanvasElement, o: OpsiKunci) {
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  // latar
  if (o.foto) {
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    drawCover(ctx, o.foto, o.foto.naturalWidth, o.foto.naturalHeight, 0, 0, W, H, 1.05);
    ctx.fillStyle = "rgba(0,0,0,0.18)";
    ctx.fillRect(0, 0, W, H);
  } else {
    paintGradient(ctx, W, H, o.wallpaper.c1, o.wallpaper.c2, o.wallpaper.angle);
  }

  gambarStatusBar(ctx, o.carrier, o.jam, o.baterai, o.sinyal, W);

  // tanggal + jam besar
  ctx.textAlign = "center";
  ctx.fillStyle = "#ffffff";
  ctx.font = "500 52px Inter, -apple-system, sans-serif";
  ctx.fillText(tanggalIndonesia(), W / 2, 430);
  ctx.font = "600 248px Inter, -apple-system, sans-serif";
  ctx.fillText(o.jam, W / 2, 650);

  // kartu pesan kaca embun
  const padX = 64;
  const padY = 62;
  ctx.font = "400 48px Inter, -apple-system, sans-serif";
  const barisPesan = wrapLines(ctx, o.pesan, W - padX * 2 - 140);
  const tinggiKartu = padY * 2 + (o.pengirim ? 96 : 0) + barisPesan.length * 62 + 40;

  const kartuY = 980;
  const kartuH = Math.min(tinggiKartu, H - kartuY - 200);

  ctx.save();
  roundRectPath(ctx, padX, kartuY, W - padX * 2, kartuH, 72);
  ctx.clip();
  // latar kaca: salin wallpaper lalu blur
  if (typeof ctx.filter === "string") ctx.filter = "blur(34px) saturate(1.5)";
  if (o.foto) drawCover(ctx, o.foto, o.foto.naturalWidth, o.foto.naturalHeight, 0, 0, W, H, 1.05);
  else paintGradient(ctx, W, H, o.wallpaper.c1, o.wallpaper.c2, o.wallpaper.angle);
  ctx.filter = "none";
  ctx.fillStyle = "rgba(255,255,255,0.16)";
  ctx.fillRect(padX, kartuY, W - padX * 2, kartuH);
  ctx.restore();

  ctx.strokeStyle = "rgba(255,255,255,0.28)";
  ctx.lineWidth = 3;
  roundRectPath(ctx, padX, kartuY, W - padX * 2, kartuH, 72);
  ctx.stroke();

  // isi kartu
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(255,255,255,0.85)";
  let yy = kartuY + padY;
  if (o.pengirim) {
    ctx.font = "600 46px Inter, -apple-system, sans-serif";
    ctx.fillText(o.pengirim, W / 2, yy + 16);
    yy += 96;
  }
  ctx.fillStyle = "#ffffff";
  ctx.font = "400 48px Inter, -apple-system, sans-serif";
  const mulaiY = yy + (barisPesan.length - 1) * 31;
  barisPesan.forEach((l, i) => ctx.fillText(l, W / 2, mulaiY + i * 62));

  gambarIndikatorRumah(ctx, H);
}

// ---------------------------------------------------------------- mode obrolan WA (UPGRADED)

interface PesanObrolan {
  teks: string;
  self: boolean;
}

interface OpsiObrolan {
  carrier: string;
  jam: string;
  baterai: number;
  sinyal: number;
  kontak: string;
  pesan: PesanObrolan[];
  tampilkanWaktu: boolean;
  dibaca: boolean;
  online: boolean;
  /** foto profil kontak (upload) */
  avatar: HTMLImageElement | null;
  /** wallpaper chat (upload) — null = warna default WA */
  wallpaper: HTMLImageElement | null;
}

/** Gelembung WA dengan EKOR khas (bezier). */
function gambarBubbleWA(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  self: boolean,
) {
  const r = 34; // radius sudut
  const tail = 30;
  ctx.beginPath();
  if (self) {
    // kanan: sudut kiri-atas & kiri-bawah membulat penuh, pojok kanan-bawah ekor
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    // ekor kanan-bawah
    ctx.lineTo(x + w - 14, y + h);
    ctx.quadraticCurveTo(x + w + tail - 6, y + h + 6, x + w + tail, y + h + tail + 4);
    ctx.quadraticCurveTo(x + w + tail - 20, y + h + 2, x + w - tail - 8, y + h - 4);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r);
    ctx.arcTo(x, y, x + r, y, r);
  } else {
    // kiri: ekor kiri-atas
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y, x + w, y + r, r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x, y + h, x, y + h - r, r);
    ctx.lineTo(x, y + r);
    // ekor kiri-atas
    ctx.quadraticCurveTo(x - 2, y + 6, x - tail, y - tail - 2);
    ctx.quadraticCurveTo(x - tail + 16, y + 4, x + r - 6, y + 2);
    ctx.arcTo(x, y, x + r, y, r);
  }
  ctx.closePath();
}

/** Centang ganda biru (dibaca) — path manual. */
function gambarCentangGanda(ctx: CanvasRenderingContext2D, x: number, y: number, warna: string) {
  ctx.save();
  ctx.strokeStyle = warna;
  ctx.lineWidth = 7;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  // centang 1
  ctx.beginPath();
  ctx.moveTo(x, y);
  ctx.lineTo(x + 14, y + 14);
  ctx.lineTo(x + 34, y - 12);
  ctx.stroke();
  // centang 2 (sedikit geser kanan)
  ctx.beginPath();
  ctx.moveTo(x + 22, y);
  ctx.lineTo(x + 36, y + 14);
  ctx.lineTo(x + 56, y - 12);
  ctx.stroke();
  ctx.restore();
}

function gambarObrolan(canvas: HTMLCanvasElement, o: OpsiObrolan) {
  const ukuranFont = 46;
  const padBubble = 36;
  const jarak = 26;
  const lebarMaks = W * 0.66;

  // ukur tinggi total (kanvas memanjang)
  const ctxUkur = document.createElement("canvas").getContext("2d")!;
  ctxUkur.font = `400 ${ukuranFont}px Inter, -apple-system, sans-serif`;
  const terukur = o.pesan.map((m) => wrapLines(ctxUkur, m.teks, lebarMaks - padBubble * 2 - 60));

  let tinggi = 1560; // status bar + header WA + chip tanggal + jarak
  for (let i = 0; i < o.pesan.length; i++) {
    tinggi += terukur[i].length * (ukuranFont * 1.34) + padBubble * 2 + jarak;
  }
  tinggi += 340; // input bar + ruang bawah
  const Hc = Math.max(H, tinggi);

  canvas.width = W;
  canvas.height = Hc;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  /* ---- latar chat WA dark ---- */
  ctx.fillStyle = "#0B141A"; // warna chat WA dark
  ctx.fillRect(0, 0, W, Hc);
  if (o.wallpaper) {
    drawCover(ctx, o.wallpaper, o.wallpaper.naturalWidth, o.wallpaper.naturalHeight, 0, 0, W, Hc, 1.02);
    ctx.fillStyle = "rgba(11,20,26,0.45)";
    ctx.fillRect(0, 0, W, Hc);
  }

  gambarStatusBar(ctx, o.carrier, o.jam, o.baterai, o.sinyal, W);

  /* ---- header WA ---- */
  const headerY = 200;
  const headerH = 190;
  ctx.fillStyle = "#202C33"; // header WA dark
  ctx.fillRect(0, headerY, W, headerH);
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(0, headerY + headerH);
  ctx.lineTo(W, headerY + headerH);
  ctx.stroke();

  // panah kembali <
  ctx.strokeStyle = "#E9EDEF";
  ctx.lineWidth = 11;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(128, headerY + headerH / 2 - 34);
  ctx.lineTo(84, headerY + headerH / 2);
  ctx.lineTo(128, headerY + headerH / 2 + 34);
  ctx.stroke();

  // avatar kontak (bisa foto)
  const avR = 72;
  gambarAvatar(ctx, 230, headerY + headerH / 2, avR, o.avatar, (o.kontak || "?").charAt(0));

  // nama + status online
  ctx.textAlign = "left";
  ctx.fillStyle = "#E9EDEF";
  ctx.font = "700 52px Inter, -apple-system, sans-serif";
  ctx.fillText((o.kontak || "Kontak").slice(0, 22), 340, headerY + headerH / 2 - 24);
  ctx.fillStyle = o.online ? "#25D366" : "#8696A0";
  ctx.font = "400 36px Inter, -apple-system, sans-serif";
  ctx.fillText(o.online ? "online" : "terakhir dilihat hari ini pukul " + o.jam, 340, headerY + headerH / 2 + 38);

  // ikon video + telepon (kanan)
  const ikonWarna = "#AEBAC1";
  // kamera video
  const vx = W - 300;
  ctx.fillStyle = ikonWarna;
  roundRectPath(ctx, vx, headerY + headerH / 2 - 30, 56, 40, 10);
  ctx.fill();
  ctx.beginPath();
  ctx.moveTo(vx + 56, headerY + headerH / 2 - 20);
  ctx.lineTo(vx + 78, headerY + headerH / 2 - 32);
  ctx.lineTo(vx + 78, headerY + headerH / 2 + 12);
  ctx.lineTo(vx + 56, headerY + headerH / 2);
  ctx.closePath();
  ctx.fill();
  // telepon
  const px = W - 150;
  ctx.save();
  ctx.translate(px, headerY + headerH / 2);
  ctx.rotate(0.6);
  roundRectPath(ctx, -14, -34, 28, 68, 12);
  ctx.fill();
  ctx.restore();

  /* ---- chip tanggal "HARI INI" ---- */
  const chipY = headerY + headerH + 70;
  ctx.textAlign = "center";
  ctx.font = "600 32px Inter, -apple-system, sans-serif";
  const chipTeks = tanggalIndonesia(new Date()).toUpperCase();
  const chipW = ctx.measureText(chipTeks).width + 76;
  ctx.fillStyle = "#182229";
  roundRectPath(ctx, W / 2 - chipW / 2, chipY, chipW, 64, 16);
  ctx.fill();
  ctx.fillStyle = "#8696A0";
  ctx.fillText(chipTeks, W / 2, chipY + 42);

  /* ---- gelembung chat ---- */
  let y = chipY + 140;
  ctx.font = `400 ${ukuranFont}px Inter, -apple-system, sans-serif`;
  ctx.textBaseline = "middle";

  for (let i = 0; i < o.pesan.length; i++) {
    const m = o.pesan[i];
    const baris = terukur[i];
    const tebalFont = ukuranFont * 1.34;
    const tinggiBubble = baris.length * tebalFont + padBubble * 2 - 6;
    const lebarBubble =
      baris.reduce((mm, l) => Math.max(mm, ctx.measureText(l).width), 0) + padBubble * 2 + (o.tampilkanWaktu ? 190 : 60);

    const bx = m.self ? W - 96 - lebarBubble : 96;

    ctx.fillStyle = m.self ? "#005C4B" : "#202C33"; // warna gelembung WA asli
    gambarBubbleWA(ctx, bx, y, lebarBubble, tinggiBubble, m.self);
    ctx.fill();

    // teks
    ctx.fillStyle = "#E9EDEF";
    ctx.textAlign = "left";
    const mulaiY = y + padBubble - 3 + (baris.length - 1) * (tebalFont / 2);
    baris.forEach((l, bi) => ctx.fillText(l, bx + padBubble, mulaiY + bi * tebalFont));

    // waktu + centang di pojok dalam gelembung
    if (o.tampilkanWaktu) {
      ctx.font = "400 28px Inter, -apple-system, sans-serif";
      ctx.fillStyle = "rgba(233,237,239,0.6)";
      ctx.textAlign = "right";
      const wx = bx + lebarBubble - padBubble + 8;
      const wy = y + tinggiBubble - 26;
      ctx.fillText(o.jam, wx, wy);
      if (m.self) {
        // centang ganda biru bila dibaca, abu bila terkirim
        gambarCentangGanda(ctx, wx - 78, wy - 2, o.dibaca ? "#53BDEB" : "rgba(233,237,239,0.6)");
      }
      ctx.font = `400 ${ukuranFont}px Inter, -apple-system, sans-serif`;
    }

    y += tinggiBubble + jarak;
  }

  /* ---- input bar bawah (tiruan WA) ---- */
  const inputY = Hc - 290;
  ctx.fillStyle = "#202C33";
  roundRectPath(ctx, 70, inputY, W - 320, 130, 65);
  ctx.fill();
  // placeholder
  ctx.textAlign = "left";
  ctx.fillStyle = "rgba(134,150,160,0.9)";
  ctx.font = "400 42px Inter, -apple-system, sans-serif";
  ctx.fillText("Ketik pesan", 140, inputY + 67);
  // ikon plus (lampiran) di kiri input
  ctx.strokeStyle = "#8696A0";
  ctx.lineWidth = 9;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(120, inputY + 45);
  ctx.lineTo(120, inputY + 90);
  ctx.moveTo(97, inputY + 67);
  ctx.lineTo(143, inputY + 67);
  ctx.stroke();
  // ikon kamera di kanan input
  ctx.fillStyle = "#8696A0";
  roundRectPath(ctx, W - 480, inputY + 38, 54, 42, 10);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(W - 453, inputY + 59, 10, 0, Math.PI * 2);
  ctx.fillStyle = "#202C33";
  ctx.fill();
  // tombol mikrofon hijau
  const mcx = W - 160;
  const mcy = inputY + 65;
  ctx.fillStyle = "#005C4B";
  ctx.beginPath();
  ctx.arc(mcx, mcy, 62, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#E9EDEF";
  roundRectPath(ctx, mcx - 13, mcy - 34, 26, 48, 13);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(mcx, mcy + 6, 13, 0, Math.PI);
  ctx.fill();
  roundRectPath(ctx, mcx - 13, mcy + 6, 26, 20, 6);
  ctx.fill();

  gambarIndikatorRumah(ctx, Hc);
}

// ---------------------------------------------------------------- komponen

function parseObrolan(teks: string): PesanObrolan[] {
  return teks
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => (l.startsWith(">") ? { teks: l.replace(/^>\s*/, ""), self: true } : { teks: l, self: false }));
}

export default function IphoneQuoteTool() {
  const [mode, setMode] = useState<"kunci" | "obrolan">("kunci");
  const [carrier, setCarrier] = useState("Telkomsel");
  const [jam, setJam] = useState(() =>
    new Date().toTimeString().slice(0, 5),
  );
  const [baterai, setBaterai] = useState(88);
  const [sinyal, setSinyal] = useState(4);
  const [pengirim, setPengirim] = useState("");
  const [pesan, setPesan] = useState("kalau nggak sekarang, kapan lagi?");
  const [kontak, setKontak] = useState("Seseorang");
  const [tampilkanWaktu, setTampilkanWaktu] = useState(true);
  const [dibaca, setDibaca] = useState(true);
  const [online, setOnline] = useState(true);
  const [wallIdx, setWallIdx] = useState(0);
  const [foto, setFoto] = useState<HTMLImageElement | null>(null);
  /** V2 UpdSec: foto profil kontak (chat WA) + wallpaper chat */
  const [avatar, setAvatar] = useState<HTMLImageElement | null>(null);
  const [chatWall, setChatWall] = useState<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    void ensureFonts(["inter"]);
  }, []);

  const wallpaper = WALLPAPERS[wallIdx] ?? WALLPAPERS[0];

  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (mode === "kunci") {
      gambarKunci(canvas, {
        carrier,
        jam,
        baterai,
        sinyal,
        pengirim: pengirim.trim(),
        pesan: pesan.trim() || "tuliskan pesan Anda di sini",
        wallpaper,
        foto,
      });
    } else {
      const daftar = parseObrolan(pesan);
      if (!daftar.length) {
        gambarKunci(canvas, {
          carrier, jam, baterai, sinyal, pengirim: "", pesan: "tulis baris pesan di kolom teks",
          wallpaper, foto,
        });
        return;
      }
      gambarObrolan(canvas, {
        carrier,
        jam,
        baterai,
        sinyal,
        kontak: kontak.trim() || "Seseorang",
        pesan: daftar,
        tampilkanWaktu,
        dibaca,
        online,
        avatar,
        wallpaper: chatWall,
      });
    }
  }, [mode, carrier, jam, baterai, sinyal, pengirim, pesan, kontak, tampilkanWaktu, dibaca, online, wallpaper, foto, avatar, chatWall]);

  useEffect(() => {
    render();
  }, [render]);

  const pilihFoto = async (file: File | undefined) => {
    if (!file) return;
    try {
      const img = await loadImageFromFile(file);
      setFoto(img);
      toast({ title: "Wallpaper foto terpasang", description: "Foto diproses di perangkat Anda saja." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    }
  };

  const pilihAvatar = async (file: File | undefined) => {
    if (!file) return;
    try {
      const img = await loadImageFromFile(file);
      setAvatar(img);
      toast({ title: "Foto profil kontak terpasang", description: "Tampil di header chat." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    }
  };

  const pilihChatWall = async (file: File | undefined) => {
    if (!file) return;
    try {
      const img = await loadImageFromFile(file);
      setChatWall(img);
      toast({ title: "Wallpaper chat terpasang", description: "Latar belakang obrolan WA." });
    } catch {
      toast({ title: "Gagal memuat foto", variant: "destructive" });
    }
  };

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    downloadCanvas(canvas, mode === "kunci" ? "fanzz-iphone-quote.png" : "fanzz-wa-chat-iphone.png");
    pushHistory("studio", {
      id: `iqc-${Date.now()}`,
      title: mode === "kunci" ? "iPhone Quote (IQC)" : "Chat WA iPhone",
      subtitle: pesan.trim().slice(0, 60) || "tanpa teks",
    });
    toast({
      title: "Tangkapan layar terunduh",
      description: `${canvas.width} x ${canvas.height} piksel — siap dipakai.`,
    });
  };

  return (
    <div className="space-y-4">
      {/* mode */}
      <div className="grid grid-cols-2 gap-2">
        {([
          { id: "kunci", label: "Layar Kunci (IQC)" },
          { id: "obrolan", label: "Chat WA iPhone" },
        ] as const).map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id)}
            className={`rounded-xl px-3 py-2.5 text-xs font-bold transition ${
              mode === m.id
                ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-md"
                : "bg-secondary hover:bg-secondary/70"
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* status bar */}
      <div className="grid grid-cols-2 gap-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Operator</p>
          <Input value={carrier} onChange={(e) => setCarrier(e.target.value)} maxLength={18} className="h-9 text-xs" />
        </div>
        <div>
          <p className="mb-1 text-[10px] font-bold text-muted-foreground">Jam (HH:MM)</p>
          <Input value={jam} onChange={(e) => setJam(e.target.value)} maxLength={5} className="h-9 text-xs" placeholder="14:30" />
        </div>
        <div>
          <p className="mb-1 flex justify-between text-[10px] font-bold text-muted-foreground">
            Baterai <span className="tabular-nums text-red-400">{baterai}%</span>
          </p>
          <Slider min={1} max={100} step={1} value={[baterai]} onValueChange={(v) => setBaterai(v[0])} />
        </div>
        <div>
          <p className="mb-1 flex justify-between text-[10px] font-bold text-muted-foreground">
            Sinyal <span className="tabular-nums text-red-400">{sinyal}/4</span>
          </p>
          <Slider min={0} max={4} step={1} value={[sinyal]} onValueChange={(v) => setSinyal(v[0])} />
        </div>
      </div>

      {/* wallpaper layar kunci */}
      {mode === "kunci" ? (
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <p className="text-xs font-bold text-muted-foreground">Wallpaper</p>
            <label className="flex cursor-pointer items-center gap-1.5 text-[10px] font-bold text-red-400">
              <Upload className="h-3 w-3" />
              pakai foto sendiri
              <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihFoto(e.target.files?.[0])} />
            </label>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {WALLPAPERS.map((w, i) => (
              <button
                key={w.name}
                onClick={() => {
                  setWallIdx(i);
                  setFoto(null);
                }}
                title={w.name}
                className={`h-10 rounded-xl ring-1 transition ${
                  !foto && i === wallIdx ? "ring-2 ring-red-400" : "ring-[var(--surface-line)] hover:opacity-80"
                }`}
                style={{ background: `linear-gradient(${w.angle}deg, ${w.c1}, ${w.c2})` }}
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <p className="mb-1 text-[10px] font-bold text-muted-foreground">Nama kontak</p>
              <Input value={kontak} onChange={(e) => setKontak(e.target.value)} maxLength={22} className="h-9 text-xs" />
            </div>
            <div>
              <p className="mb-1 text-[10px] font-bold text-muted-foreground">Foto profil kontak</p>
              <div className="flex items-center gap-2">
                <label className="flex cursor-pointer items-center gap-1.5 rounded-xl bg-red-500/15 px-3 py-2 text-[10px] font-bold text-red-300 transition-colors hover:bg-red-500/25">
                  <Upload className="h-3 w-3" />
                  {avatar ? "ganti foto" : "upload foto"}
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihAvatar(e.target.files?.[0])} />
                </label>
                {avatar && (
                  <button onClick={() => setAvatar(null)} className="rounded-xl bg-secondary px-2.5 py-2 text-[10px] font-bold text-muted-foreground">
                    hapus
                  </button>
                )}
              </div>
            </div>
          </div>
          <div className="flex items-center justify-between gap-3">
            <label className="flex cursor-pointer items-center gap-1.5 text-[10px] font-bold text-red-400">
              <Upload className="h-3 w-3" />
              wallpaper chat (opsional)
              <input type="file" accept="image/*" className="hidden" onChange={(e) => pilihChatWall(e.target.files?.[0])} />
            </label>
            {chatWall && (
              <button onClick={() => setChatWall(null)} className="rounded-xl bg-secondary px-2.5 py-1.5 text-[10px] font-bold text-muted-foreground">
                hapus wallpaper
              </button>
            )}
          </div>
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">
              Baris pesan — awali dengan tanda &quot;&gt;&quot; untuk gelembung hijau milik Anda
            </p>
            <Textarea
              value={pesan}
              onChange={(e) => setPesan(e.target.value)}
              className="min-h-[130px] resize-none border-[var(--surface-line)] bg-background text-sm"
              maxLength={600}
              placeholder={"gimana kabarmu?\n> alhamdulillah baik, kamu?\ngitu aja kok susah"}
            />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <div className="flex items-center gap-2">
              <Switch checked={tampilkanWaktu} onCheckedChange={setTampilkanWaktu} />
              <span className="text-[10px] font-bold">Waktu</span>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={dibaca} onCheckedChange={setDibaca} />
              <span className="text-[10px] font-bold">Centang biru</span>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={online} onCheckedChange={setOnline} />
              <span className="text-[10px] font-bold">Online</span>
            </div>
          </div>
        </div>
      )}

      {/* konten layar kunci */}
      {mode === "kunci" && (
        <div className="space-y-3 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">Nama pengirim (opsional)</p>
            <Input
              value={pengirim}
              onChange={(e) => setPengirim(e.target.value)}
              maxLength={30}
              className="h-9 text-xs"
              placeholder="kosongkan bila tanpa nama"
            />
          </div>
          <div>
            <p className="mb-1 text-[10px] font-bold text-muted-foreground">Isi pesan</p>
            <Textarea
              value={pesan}
              onChange={(e) => setPesan(e.target.value)}
              className="min-h-[90px] resize-none border-[var(--surface-line)] bg-background text-sm"
              maxLength={300}
              placeholder="Tulis kutipan atau pesan..."
            />
          </div>
        </div>
      )}

      {/* pratinjau */}
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[300px]">
        <canvas
          ref={canvasRef}
          className="block h-auto w-full rounded-[36px] border-4 border-black/80 bg-black shadow-2xl ring-1 ring-white/10"
        />
      </motion.div>

      <Button onClick={unduh} className="h-11 w-full bg-gradient-to-r from-red-500 to-red-700 font-bold">
        <Download className="mr-2 h-4 w-4" />
        Unduh Tangkapan Layar
      </Button>
    </div>
  );
}
