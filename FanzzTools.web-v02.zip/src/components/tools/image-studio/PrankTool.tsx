"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ToolCard, Label, TextInput, DownloadButton } from "./iqc-shared";
import { ensureFonts, downloadCanvas } from "./lib";

/**
 * Prank Generator (IQC) — Error PC & layar virus palsu dengan teks yang bisa diubah.
 * 100% client-side. Untuk prank bersahabat — bukan alat menipu.
 */

type Mode = "bsod" | "dialog" | "virus" | "terminal";

const MODES: Array<{ id: Mode; label: string; judul: string }> = [
  { id: "bsod", label: "Error PC", judul: "Layar Biru Windows (BSOD)" },
  { id: "dialog", label: "Dialog", judul: "Dialog Error Klasik" },
  { id: "virus", label: "Virus", judul: "Peringatan Virus" },
  { id: "terminal", label: "Terminal", judul: "Terminal Hacker" },
];

export default function PrankTool() {
  const [mode, setMode] = useState<Mode>("bsod");
  const [bsodText, setBsodText] = useState(
    "PC Anda mengalami masalah dan perlu dimulai ulang. Kami hanya mengumpulkan beberapa info kesalahan, lalu akan memulai ulang untuk Anda.",
  );
  const [bsodPercent, setBsodPercent] = useState(45);
  const [bsodCode, setBsodCode] = useState("FANZZ_TOOLS_PRANK");

  const [dlgTitle, setDlgTitle] = useState("Sistem Error");
  const [dlgMsg, setDlgMsg] = useState("Operasi gagal dikarenakan file sistem sudah terkunci.\nKode: 0xFANZZ2026");
  const [dlgButtons, setDlgButtons] = useState("OK   |   Batal");

  const [virusTitle, setVirusTitle] = useState("!! VIRUS TERDETEKSI !!");
  const [virusMsg, setVirusMsg] = useState("69 TROJAN ditemukan di komputer Anda!\nMenghapus file pribadi Anda...");
  const [virusProgress, setVirusProgress] = useState(87);

  const [terminalLines, setTerminalLines] = useState(
    "> mengakses C:\\Users\\Rahasia\\Documents...\n> mengunduh 47 file pribadi [██████████] 100%\n> mengirim data ke server tak dikenal 192.168.66.6\n> AKSES DIBERIKAN. terlambat untuk membatalkan.",
  );

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const render = useCallback(async () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const W = 1920;
    const H = 1080;
    canvas.width = W;
    canvas.height = H;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    await ensureFonts(["inter", "archivo"]);

    ctx.textBaseline = "middle";
    ctx.textAlign = "left";

    if (mode === "bsod") {
      // latar biru Windows 10/11
      ctx.fillStyle = "#0078d7";
      ctx.fillRect(0, 0, W, H);
      // wajah sedih
      ctx.fillStyle = "#ffffff";
      ctx.font = "400 190px Inter";
      ctx.fillText(":( ", 150, 230);
      // teks utama (wrap)
      ctx.font = "400 44px Inter";
      const words = bsodText.split(/\s+/);
      const maxW = W - 300;
      let lines: string[] = [];
      let baris = "";
      for (const w of words) {
        const coba = baris ? `${baris} ${w}` : w;
        if (ctx.measureText(coba).width > maxW) {
          lines.push(baris);
          baris = w;
        } else baris = coba;
      }
      if (baris) lines.push(baris);
      lines = lines.slice(0, 4);
      lines.forEach((l, i) => ctx.fillText(l, 150, 400 + i * 64));
      // persentase
      const pct = Math.max(0, Math.min(100, Math.round(bsodPercent)));
      ctx.font = "400 44px Inter";
      ctx.fillText(`${pct}% lengkap`, 150, 400 + lines.length * 64 + 40);
      // kode + QR dekoratif
      ctx.font = "400 30px Inter";
      const stopY = 400 + lines.length * 64 + 140;
      ctx.fillText(`Untuk informasi selengkapnya tentang masalah ini dan kemungkinan perbaikan, kunjungi`, 150, stopY);
      ctx.fillText(`https://www.windows.com/stopcode`, 150, stopY + 42);
      ctx.fillText(`Jika Anda menghubungi personel dukungan, beri tahu mereka info ini:`, 150, stopY + 110);
      ctx.fillText(`Kode berhenti: ${bsodCode || "FANZZ_TOOLS_PRANK"}`, 150, stopY + 152);
      // blok "QR" dekoratif (pola acak deterministik)
      const qs = 14;
      const qx = W - 340;
      const qy = stopY + 40;
      let seed = 1234567;
      const rnd = () => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff);
      for (let y = 0; y < 12; y++) {
        for (let x = 0; x < 12; x++) {
          if (rnd() > 0.5) {
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(qx + x * qs, qy + y * qs, qs - 2, qs - 2);
          }
        }
      }
      ctx.fillStyle = "#0078d7";
      for (const [cx, cy] of [[0, 0], [11, 0], [0, 11]] as Array<[number, number]>) {
        ctx.fillRect(qx + cx * qs, qy + cy * qs, qs, qs);
      }
    } else if (mode === "dialog") {
      // latar desktop hijau-xp klasik
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, "#3a7d5d");
      g.addColorStop(1, "#1e4f38");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      // kotak dialog
      const dw = 900;
      const dh = 420;
      const dx = (W - dw) / 2;
      const dy = (H - dh) / 2;
      ctx.fillStyle = "#d4d0c8";
      ctx.fillRect(dx, dy, dw, dh);
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 3;
      ctx.strokeRect(dx + 1.5, dy + 1.5, dw - 3, dy + 3);
      // baris judul biru gradien khas XP
      const tg = ctx.createLinearGradient(dx, dy, dx, dy + 44);
      tg.addColorStop(0, "#0058e6");
      tg.addColorStop(1, "#3a93ff");
      ctx.fillStyle = tg;
      ctx.fillRect(dx + 4, dy + 4, dw - 8, 44);
      ctx.fillStyle = "#ffffff";
      ctx.font = "700 28px Inter";
      ctx.fillText(dlgTitle || "Error", dx + 18, dy + 27);
      // tombol X
      ctx.fillStyle = "#d4d0c8";
      ctx.fillRect(dx + dw - 44, dy + 8, 32, 34);
      ctx.fillStyle = "#000000";
      ctx.font = "700 26px Inter";
      ctx.textAlign = "center";
      ctx.fillText("×", dx + dw - 28, dy + 26);
      ctx.textAlign = "left";
      // ikon X merah bundar
      const ix = dx + 60;
      const iy = dy + 140;
      ctx.beginPath();
      ctx.arc(ix, iy, 34, 0, Math.PI * 2);
      ctx.fillStyle = "#d81f1f";
      ctx.fill();
      ctx.strokeStyle = "#8b0000";
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.moveTo(ix - 15, iy - 15);
      ctx.lineTo(ix + 15, iy + 15);
      ctx.moveTo(ix + 15, iy - 15);
      ctx.lineTo(ix - 15, iy + 15);
      ctx.stroke();
      // pesan (wrap, dukung \n)
      ctx.fillStyle = "#000000";
      ctx.font = "400 30px Inter";
      const maxW = dw - 200;
      let ly = dy + 110;
      for (const par of (dlgMsg || "Pesan").split("\n").slice(0, 6)) {
        let baris2 = "";
        for (const w of par.split(/\s+/)) {
          const coba = baris2 ? `${baris2} ${w}` : w;
          if (ctx.measureText(coba).width > maxW) {
            ctx.fillText(baris2, dx + 130, ly);
            ly += 44;
            baris2 = w;
          } else baris2 = coba;
        }
        if (baris2) {
          ctx.fillText(baris2, dx + 130, ly);
          ly += 44;
        }
      }
      // tombol
      const btns = (dlgButtons || "OK").split("|").map((b) => b.trim()).filter(Boolean).slice(0, 3);
      const bw = 130;
      const totalW = btns.length * bw + (btns.length - 1) * 40;
      let bx = dx + (dw - totalW) / 2;
      const by = dy + dh - 90;
      for (const b of btns) {
        ctx.fillStyle = "#e8e6e0";
        ctx.fillRect(bx, by, bw, 52);
        ctx.strokeStyle = "#808080";
        ctx.lineWidth = 2;
        ctx.strokeRect(bx, by, bw, 52);
        ctx.fillStyle = "#000000";
        ctx.font = "400 26px Inter";
        ctx.textAlign = "center";
        ctx.fillText(b.slice(0, 14), bx + bw / 2, by + 27);
        ctx.textAlign = "left";
        bx += bw + 40;
      }
    } else if (mode === "virus") {
      // layar merah gelap
      ctx.fillStyle = "#1a0000";
      ctx.fillRect(0, 0, W, H);
      const g = ctx.createRadialGradient(W / 2, H / 2, 100, W / 2, H / 2, W);
      g.addColorStop(0, "rgba(255,0,0,0.28)");
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, W, H);
      // segitiga peringatan besar
      ctx.beginPath();
      ctx.moveTo(W / 2, 180);
      ctx.lineTo(W / 2 + 180, 500);
      ctx.lineTo(W / 2 - 180, 500);
      ctx.closePath();
      ctx.fillStyle = "#f5c518";
      ctx.fill();
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 14;
      ctx.stroke();
      ctx.fillStyle = "#000000";
      ctx.font = "800 200px Inter";
      ctx.textAlign = "center";
      ctx.fillText("!", W / 2, 420);
      // judul
      ctx.fillStyle = "#ff2b2b";
      ctx.font = "800 92px Inter";
      ctx.fillText((virusTitle || "!! VIRUS !!").slice(0, 40), W / 2, 610);
      // pesan
      ctx.fillStyle = "#ffdddd";
      ctx.font = "600 44px Inter";
      let vy = 700;
      for (const par of (virusMsg || "pesan").split("\n").slice(0, 3)) {
        ctx.fillText(par.slice(0, 60), W / 2, vy);
        vy += 60;
      }
      // progress bar
      const pw = 1100;
      const px = (W - pw) / 2;
      const py = 850;
      ctx.fillStyle = "#3a0000";
      ctx.fillRect(px, py, pw, 54);
      const pct = Math.max(0, Math.min(100, virusProgress));
      const pg = ctx.createLinearGradient(px, 0, px + pw, 0);
      pg.addColorStop(0, "#ff2b2b");
      pg.addColorStop(1, "#ff6b6b");
      ctx.fillStyle = pg;
      ctx.fillRect(px, py, (pw * pct) / 100, 54);
      ctx.strokeStyle = "#ff5555";
      ctx.lineWidth = 3;
      ctx.strokeRect(px, py, pw, 54);
      ctx.fillStyle = "#ffffff";
      ctx.font = "700 30px Inter";
      ctx.fillText(`${pct}%`, W / 2, py + 27);
      ctx.fillStyle = "#ff8888";
      ctx.font = "400 28px 'Archivo Narrow'";
      ctx.fillText("SYSTEM32 — jangan matikan komputer Anda", W / 2, py + 120);
      ctx.textAlign = "left";
    } else {
      // terminal hijau
      ctx.fillStyle = "#0c0c0c";
      ctx.fillRect(0, 0, W, H);
      // bayangan CRT samar
      const scan = ctx.createLinearGradient(0, 0, 0, H);
      scan.addColorStop(0, "rgba(0,255,0,0.03)");
      scan.addColorStop(0.5, "rgba(0,0,0,0.0)");
      scan.addColorStop(1, "rgba(0,255,0,0.04)");
      ctx.fillStyle = scan;
      ctx.fillRect(0, 0, W, H);
      // header
      ctx.fillStyle = "#00ff41";
      ctx.font = "600 30px 'Archivo Narrow'";
      ctx.fillText("C:\\WINDOWS\\system32> fanzz.exe --mode=hacker", 60, 60);
      // garis pemisah
      ctx.fillRect(60, 85, W - 120, 2);
      // baris terminal
      ctx.font = "500 32px 'Archivo Narrow'";
      let ty = 140;
      const lines = terminalLines.split("\n").slice(0, 18);
      for (const l of lines) {
        const isAlert = /AKSES DIBERIKAN|terlambat|VIRUS|gagal/i.test(l);
        ctx.fillStyle = isAlert ? "#ff3333" : "#00ff41";
        ctx.fillText(l.slice(0, 90), 60, ty);
        ty += 48;
      }
      // kursor berkedip statis
      ctx.fillStyle = "#00ff41";
      ctx.fillRect(60, ty, 20, 34);
      // kaki
      ctx.fillStyle = "#007700";
      ctx.font = "500 24px 'Archivo Narrow'";
      ctx.fillText(`root@fanzz:~$ ${lines.length} baris dieksekusi`, 60, H - 50);
    }
  }, [mode, bsodText, bsodPercent, bsodCode, dlgTitle, dlgMsg, dlgButtons, virusTitle, virusMsg, virusProgress, terminalLines]);

  useEffect(() => {
    render();
  }, [render]);

  const aktif = MODES.find((m) => m.id === mode)!;

  return (
    <div className="grid gap-5 lg:grid-cols-[320px_1fr]">
      {/* kontrol */}
      <ToolCard title={aktif.judul} hint="Prank bersahabat — hasil berupa gambar statis.">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                mode === m.id ? "bg-gradient-to-r from-red-500 to-red-700 text-white" : "bg-secondary text-muted-foreground"
              }`}
            >
              {m.label}
            </button>
          ))}
        </div>

        {mode === "bsod" && (
          <>
            <Label>Teks utama</Label>
            <textarea
              value={bsodText}
              onChange={(e) => setBsodText(e.target.value.slice(0, 240))}
              rows={3}
              className="mb-3 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-red-400/50"
            />
            <Label>Persentase: {bsodPercent}%</Label>
            <input type="range" min={0} max={100} value={bsodPercent} onChange={(e) => setBsodPercent(Number(e.target.value))} className="mb-3 w-full" />
            <Label>Kode berhenti</Label>
            <TextInput value={bsodCode} onChange={setBsodCode} />
          </>
        )}
        {mode === "dialog" && (
          <>
            <Label>Judul dialog</Label>
            <TextInput value={dlgTitle} onChange={setDlgTitle} />
            <Label>Pesan (\n = baris baru)</Label>
            <textarea
              value={dlgMsg}
              onChange={(e) => setDlgMsg(e.target.value.slice(0, 300))}
              rows={3}
              className="mb-3 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-red-400/50"
            />
            <Label>Tombol (pisahkan dengan |)</Label>
            <TextInput value={dlgButtons} onChange={setDlgButtons} />
          </>
        )}
        {mode === "virus" && (
          <>
            <Label>Judul</Label>
            <TextInput value={virusTitle} onChange={setVirusTitle} />
            <Label>Pesan (\n = baris baru)</Label>
            <textarea
              value={virusMsg}
              onChange={(e) => setVirusMsg(e.target.value.slice(0, 200))}
              rows={3}
              className="mb-3 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 text-xs outline-none focus:border-red-400/50"
            />
            <Label>Progres: {virusProgress}%</Label>
            <input type="range" min={0} max={100} value={virusProgress} onChange={(e) => setVirusProgress(Number(e.target.value))} className="w-full" />
          </>
        )}
        {mode === "terminal" && (
          <>
            <Label>Baris terminal (\n = baris baru)</Label>
            <textarea
              value={terminalLines}
              onChange={(e) => setTerminalLines(e.target.value.slice(0, 1200))}
              rows={8}
              className="mb-3 w-full rounded-xl border border-border/60 bg-secondary/50 p-2.5 font-mono text-xs outline-none focus:border-red-400/50"
            />
          </>
        )}

        <DownloadButton onClick={() => downloadCanvas(canvasRef.current!, `fanzz-prank-${mode}.png`)} />
      </ToolCard>

      {/* pratinjau */}
      <div className="flex items-start justify-center">
        <canvas ref={canvasRef} className="max-h-[520px] w-auto max-w-full rounded-xl shadow-2xl ring-1 ring-border/40" />
      </div>
    </div>
  );
}
