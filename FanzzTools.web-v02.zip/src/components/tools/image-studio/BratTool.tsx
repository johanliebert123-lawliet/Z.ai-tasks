"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/tools/shared";
import {
  ensureFonts, downloadCanvas, recordCanvas, downloadBlob, canRecordCanvas,
} from "@/components/tools/image-studio/lib";
import { Download, Film, Type, Loader2 } from "lucide-react";
import { pushHistory } from "@/lib/history";
import { useToast } from "@/hooks/use-toast";

/**
 * Generator "brat" — teks huruf kecil di atas latar hijau kapur khas sampul album brat.
 * Digambar sepenuhnya di kanvas (tanpa API luar) + varian warna + video animasi ketik.
 */

const UKURAN = 1080;

interface PresetWarna {
  nama: string;
  bg: string;
  teks: string;
}

const PRESET: PresetWarna[] = [
  { nama: "Hijau Brat", bg: "#8ACE00", teks: "#111111" },
  { nama: "Hitam Remix", bg: "#333333", teks: "#8ACE00" },
  { nama: "Putih", bg: "#F2F2F2", teks: "#111111" },
  { nama: "Merah Muda", bg: "#FFA3C7", teks: "#111111" },
  { nama: "Biru", bg: "#6C94FF", teks: "#111111" },
  { nama: "Pekat", bg: "#0A0A0A", teks: "#F5F5F5" },
];

/** Konfigurasi tata letak brat — spasi & kecepatan bisa diatur (V2.11 #22). */
function gambarBrat(
  ctx: CanvasRenderingContext2D,
  teks: string,
  bg: string,
  warnaTeks: string,
  porsiTeks = 1,
  spasi = 1, // 0.6 rapat … 2 le Longgar
) {
  const w = UKURAN;
  const h = UKURAN;
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);

  const bersih = (teks || "brat").toLowerCase();
  // V2.11 (#22) + V2 UpdSec FIX: spasi antar kata digandakan sesuai pengaturan.
  // BUG LAMA: fungsi bungkus() memecah teks dengan /\s+/ lalu menggabung ulang
  // dengan SATU spasi — jadi pengaturan spasi tidak pernah berpengaruh.
  // FIX: simpan panjang separator, lalu pakai separator itu saat menggabung baris.
  const sep = " ".repeat(Math.max(1, Math.round(spasi * 2) - 1));
  const kataKata = bersih.split(/\s+/).filter(Boolean);
  const fontFn = (size: number) => `700 ${size}px 'Archivo Narrow', 'Arial Narrow', Arial, sans-serif`;

  // ukuran huruf khas brat: sekitar 9-10% tinggi kanvas untuk satu baris
  const ukuranAwal = Math.round(h * 0.095);
  ctx.font = fontFn(ukuranAwal);
  try {
    (ctx as CanvasRenderingContext2D & { letterSpacing: string }).letterSpacing = "-0.015em";
  } catch {
    /* peramban tanpa dukungan letterSpacing — abaikan */
  }

  // bungkus teks manual (per kata) agar lebar maksimal 86% — spasi dijaga utuh
  const maxW = w * 0.86;
  const bungkus = (size: number): string[] => {
    ctx.font = fontFn(size);
    const baris: string[] = [];
    let cur = "";
    for (const kata of kataKata) {
      const coba = cur ? cur + sep + kata : kata;
      if (ctx.measureText(coba).width <= maxW) cur = coba;
      else {
        if (cur) baris.push(cur);
        cur = kata;
      }
    }
    if (cur) baris.push(cur);
    return baris;
  };

  let size = ukuranAwal;
  let baris = bungkus(size);
  // kecilkan bila melebihi 6 baris
  while (baris.length > 6 && size > 24) {
    size = Math.round(size * 0.88);
    baris = bungkus(size);
  }

  const lh = size * 1.12;
  const total = baris.length * lh;
  const startY = h / 2 - total / 2 + lh / 2;

  ctx.fillStyle = warnaTeks;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // animasi ketik: porsiTeks 0..1 memotong jumlah karakter yang tampil
  const panjangTotal = baris.reduce((n, l) => n + l.length + sep.length, 0);
  if (porsiTeks >= 1) {
    baris.forEach((l, i) => ctx.fillText(l, w / 2, startY + i * lh));
  } else {
    const sisa = Math.max(0, Math.round(porsiTeks * panjangTotal));
    let terpakai = 0;
    baris.forEach((l, i) => {
      const ruang = sisa - terpakai;
      if (ruang > 0) ctx.fillText(l.slice(0, ruang), w / 2, startY + i * lh);
      terpakai += l.length + sep.length;
    });
  }
}

export default function BratTool() {
  const [teks, setTeks] = useState("brat");
  const [presetIdx, setPresetIdx] = useState(0);
  const [bgKustom, setBgKustom] = useState<string | null>(null);
  const [teksKustom, setTeksKustom] = useState<string | null>(null);
  const [merekam, setMerekam] = useState(false);
  /** V2.11 (#22): spasi antar kata (0.6–2) & kecepatan mengetik untuk video */
  const [spasi, setSpasi] = useState(1);
  const [kecepatan, setKecepatan] = useState(1); // 0.5 lambat … 3 kilat
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const dukunganVideo = canRecordCanvas();

  useEffect(() => {
    void ensureFonts(["archivo"]);
  }, []);

  const bg = bgKustom ?? PRESET[presetIdx].bg;
  const warnaTeks = teksKustom ?? PRESET[presetIdx].teks;

  const render = useCallback(
    (porsi = 1) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      canvas.width = UKURAN;
      canvas.height = UKURAN;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      gambarBrat(ctx, teks, bg, warnaTeks, porsi, spasi);
    },
    [teks, bg, warnaTeks, spasi],
  );

  useEffect(() => {
    render(1);
  }, [render]);

  const unduh = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    downloadCanvas(canvas, "fanzz-brat.png");
    pushHistory("studio", {
      id: `brat-${Date.now()}`,
      title: "Brat generator",
      subtitle: teks.trim().slice(0, 60) || "brat",
    });
    toast({ title: "Gambar brat terunduh", description: "Format PNG 1080 x 1080 — siap diposting." });
  };

  const unduhVideo = async () => {
    const canvas = canvasRef.current;
    if (!canvas || merekam) return;
    if (!dukunganVideo) {
      toast({
        title: "Perekaman video tidak didukung",
        description: "Peramban ini belum mendukung perekaman kanvas. Silakan unduh versi PNG.",
        variant: "destructive",
      });
      return;
    }
    setMerekam(true);
    try {
      const jumlah = Math.max(1, teks.length);
      // V2.11: kecepatan mengetik bisa diatur (0.5 lambat … 3 kilat)
      const durasiKetik = Math.min(9000, Math.max(600, (900 + jumlah * 70) / kecepatan));
      const durasiTahan = 900;
      const blob = await recordCanvas(canvas, durasiKetik + durasiTahan, (t) => {
        const porsi = Math.min(1, t / durasiKetik);
        gambarBrat(canvas.getContext("2d")!, teks, bg, warnaTeks, porsi, spasi);
      });
      downloadBlob(blob, "fanzz-brat.webm");
      render(1);
      toast({ title: "Video brat terunduh", description: `Format WebM — kecepatan ketik ${kecepatan}x, spasi ${spasi}x.` });
    } catch {
      toast({ title: "Gagal merekam video", variant: "destructive" });
    } finally {
      setMerekam(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="mb-1.5 flex items-center gap-2 text-xs font-bold">
          <Type className="h-3.5 w-3.5 text-lime-400" />
          Teks (otomatis huruf kecil)
        </div>
        <Textarea
          value={teks}
          onChange={(e) => setTeks(e.target.value)}
          placeholder="tulis apa pun — contoh: aku capek banget hari ini"
          className="min-h-[76px] resize-none border-[var(--surface-line)] bg-background text-sm"
          maxLength={220}
        />
        <p className="mt-1 text-[10px] text-muted-foreground">{teks.length}/220 karakter — panjang otomatis dibungkus rapi.</p>
      </div>

      {/* preset warna */}
      <div>
        <p className="mb-1.5 text-xs font-bold text-muted-foreground">Warna</p>
        <div className="grid grid-cols-3 gap-2">
          {PRESET.map((p, i) => {
            const aktif = !bgKustom && !teksKustom && i === presetIdx;
            return (
              <button
                key={p.nama}
                onClick={() => {
                  setPresetIdx(i);
                  setBgKustom(null);
                  setTeksKustom(null);
                }}
                className={`overflow-hidden rounded-xl ring-1 transition ${
                  aktif ? "ring-2 ring-red-400" : "ring-[var(--surface-line)] hover:opacity-90"
                }`}
              >
                <div className="flex h-12 items-center justify-center" style={{ background: p.bg }}>
                  <span className="text-sm font-extrabold" style={{ color: p.teks }}>
                    brat
                  </span>
                </div>
                <p className="bg-secondary py-1 text-center text-[9px] font-bold">{p.nama}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* kustom warna + spasi + kecepatan */}
      <div className="flex items-center gap-4 rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <label className="flex items-center gap-2 text-xs font-bold">
          Latar
          <input
            type="color"
            value={bg}
            onChange={(e) => setBgKustom(e.target.value)}
            className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
          />
        </label>
        <label className="flex items-center gap-2 text-xs font-bold">
          Teks
          <input
            type="color"
            value={warnaTeks}
            onChange={(e) => setTeksKustom(e.target.value)}
            className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--surface-line)] bg-transparent p-0.5"
          />
        </label>
        {(bgKustom || teksKustom) && (
          <button
            onClick={() => {
              setBgKustom(null);
              setTeksKustom(null);
            }}
            className="ml-auto text-[10px] font-bold text-red-400 underline underline-offset-2"
          >
            kembali ke preset
          </button>
        )}
      </div>

      {/* V2.11 (#22): spasi antar kata */}
      <div className="rounded-2xl border border-[var(--surface-line)] bg-secondary/40 p-4">
        <div className="mb-1 flex items-center justify-between text-xs font-bold">
          <span>Spasi antar kata</span>
          <span className="text-muted-foreground">{spasi.toFixed(1)}x {spasi >= 1.7 ? "(panjang khas brat)" : spasi <= 0.8 ? "(rapat)" : ""}</span>
        </div>
        <input
          type="range"
          min={0.6}
          max={2}
          step={0.1}
          value={spasi}
          onChange={(e) => setSpasi(Number(e.target.value))}
          className="w-full"
        />
        <div className="mb-1 mt-3 flex items-center justify-between text-xs font-bold">
          <span>Kecepatan ketik video</span>
          <span className="text-muted-foreground">{kecepatan.toFixed(1)}x</span>
        </div>
        <input
          type="range"
          min={0.5}
          max={3}
          step={0.1}
          value={kecepatan}
          onChange={(e) => setKecepatan(Number(e.target.value))}
          className="w-full"
        />
      </div>

      {/* pratinjau */}
      {teks.trim() ? (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[380px]">
          <canvas
            ref={canvasRef}
            className="block h-auto w-full rounded-2xl border border-[var(--surface-line)] shadow-xl"
          />
        </motion.div>
      ) : (
        <EmptyState icon={<Type className="h-10 w-10" />} title="Teks masih kosong" desc="Tulis sesuatu untuk melihat pratinjau." />
      )}

      <div className="flex flex-wrap gap-2">
        <Button
          onClick={unduh}
          disabled={!teks.trim()}
          className="h-11 flex-1 bg-gradient-to-r from-lime-500 to-emerald-600 font-bold text-black"
        >
          <Download className="mr-2 h-4 w-4" />
          Unduh PNG
        </Button>
        {dukunganVideo && (
          <Button
            onClick={unduhVideo}
            disabled={!teks.trim() || merekam}
            variant="outline"
            className="h-11 border-[var(--surface-line)] font-bold"
          >
            {merekam ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Film className="mr-2 h-4 w-4" />}
            {merekam ? "Merekam..." : "Video Mengetik"}
          </Button>
        )}
      </div>
    </div>
  );
}
