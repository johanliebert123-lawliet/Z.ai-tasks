"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useApp, getSettings, saveSettings, type ViewId } from "@/lib/app-store";
import HomeView from "@/components/tools/HomeView";
import FilmView from "@/components/tools/FilmView";
import AnimeView from "@/components/tools/AnimeView";
import AiChatView from "@/components/tools/AiChatView";
import MusicView from "@/components/tools/MusicView";
import DownloaderView from "@/components/tools/DownloaderView";
import EmailView from "@/components/tools/EmailView";
import AmView from "@/components/tools/AmView";
import OsintView from "@/components/tools/OsintView";
import ApkBuilderView from "@/components/tools/ApkBuilderView";
import ChatView from "@/components/tools/ChatView";
import NewsView from "@/components/tools/NewsView";
import WikiView from "@/components/tools/WikiView";
import BooksView from "@/components/tools/BooksView";
import ProfileView from "@/components/tools/ProfileView";
import NekopoiView from "@/components/tools/NekopoiView";
import ManhwaView from "@/components/tools/ManhwaView";
import ComicView from "@/components/tools/ComicView";
import DonghuaView from "@/components/tools/DonghuaView";
import AiImageView from "@/components/tools/AiImageView";
import ReactWaView from "@/components/tools/ReactWaView";
import CapcutView from "@/components/tools/CapcutView";
import DracinView from "@/components/tools/DracinView";
import GachaNokosView from "@/components/tools/GachaNokosView";
import HistoryView from "@/components/tools/HistoryView";
import LyricsToolView from "@/components/tools/LyricsToolView";
import ProfanityView from "@/components/tools/ProfanityView";
import UsernameCheckView from "@/components/tools/UsernameCheckView";
import ImageStudioView from "@/components/tools/ImageStudioView";
import HdImageView from "@/components/tools/HdImageView";
import QrStudioView from "@/components/tools/QrStudioView";
import CalculatorView from "@/components/tools/CalculatorView";
import IqTestView from "@/components/tools/IqTestView";
import MiniPlayer from "@/components/MiniPlayer";
import CrowAnimation from "@/components/CrowAnimation";
import SecurityGuard from "@/components/SecurityGuard";
import LiveClock from "@/components/LiveClock";
import { FanzzLogo } from "@/components/tools/shared";
/* V2 Modern-UpdSec — views baru */
import AllToolsView from "@/components/tools/AllToolsView";
import SourceCodeView from "@/components/tools/SourceCodeView";
import SecurityScanView from "@/components/tools/SecurityScanView";
import MinecraftView from "@/components/tools/MinecraftView";
import IbadahView from "@/components/tools/IbadahView";
import QuranView from "@/components/tools/QuranView";
import DebateView from "@/components/tools/DebateView";
import FanzzStoryView from "@/components/tools/FanzzStoryView";
/* V2.12 Security-Updt — Parent Monitor */
import ParentMonitorView from "@/components/tools/ParentMonitorView";
/* V2.13 zuperupdt — tools baru */
import CuacaView from "@/components/tools/CuacaView";
import WifiView from "@/components/tools/WifiView";
import RodaNamaView from "@/components/tools/RodaNamaView";
import AsciiView from "@/components/tools/AsciiView";
/* FanzSec-Update — FanzzSecurity Security Center + FanzSec.Ai */
import FanzzSecurityView from "@/components/security/FanzzSecurityView";
import FanzSecAiView from "@/components/security/FanzSecAiView";
import { FanzSecBubble } from "@/components/security/security-icons";
import {
  Home, Clapperboard, Tv, Bot, Music4, Grid3X3, Download, MailPlus, Zap, User,
  Sun, Moon, Fingerprint, Package, MessageCircle, Newspaper, BookOpen, Library,
  Flame, BookOpen as BookIcon, Swords, ImageIcon, Heart, Scissors, Tv2, Dices,
  History as HistoryIcon, Music2, ShieldAlert, AtSign, Droplets, Book, Palette,
  Sparkles, QrCode, Calculator, Brain, Code2, ShieldCheck, Blocks, Moon as MoonIbadah,
  BookOpen as BookQuran, Clock3, Gamepad2, Swords as SwordsDebat,
  ShieldCheck as ShieldPm, Baby, CloudSun, Wifi as WifiIcon, Terminal, Type as TypeIcon,
} from "lucide-react";

function useChatUnreadHeartbeat(active: boolean) {
  useEffect(() => {
    if (!active) return;
    let stop = false;
    const tick = () => {
      fetch("/api/social/conversations")
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (!stop && d?.ok) useApp.setState({ chatUnread: Number(d.unread) || 0 });
        })
        .catch(() => {});
    };
    tick();
    const t = setInterval(tick, 30000);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, [active]);
}

/** Avatar sendiri (V2 UpdSec) — dipakai sidebar & header; diperbarui lewat event. */
function useMyAvatar() {
  const [avatar, setAvatar] = useState<string | null>(null);
  useEffect(() => {
    const muat = () => {
      fetch("/api/social/profile")
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => setAvatar(d?.ok ? d.profile?.avatar || null : null))
        .catch(() => {});
    };
    muat();
    const ev = () => muat();
    window.addEventListener("fanzz-avatar-updated", ev);
    return () => window.removeEventListener("fanzz-avatar-updated", ev);
  }, []);
  return avatar;
}

const PRIMARY_TABS: Array<{ view: ViewId; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { view: "home", label: "Beranda", icon: Home },
  { view: "film", label: "Film", icon: Clapperboard },
  { view: "ai", label: "AI", icon: Bot },
  { view: "music", label: "Musik", icon: Music4 },
  // V2 UpdSec: halaman baru "The All-Tools" menggantikan tombol "Lainnya"
  // (daftar lengkap + pencarian kini jadi halaman penuh — semua tools tetap terjangkau)
  { view: "alltools", label: "All-Tools", icon: Grid3X3 },
];

const ALL_TOOLS: Array<{ view: ViewId; label: string; icon: React.ComponentType<{ className?: string }>; desc: string; badge?: string }> = [
  // FanzSec-Update — Security Center & AI Security Assistant
  { view: "security", label: "FanzzSecurity", icon: ShieldCheck, desc: "Security Center: pindai file, web, metadata, hash/IOC, device advisor", badge: "BARU" },
  { view: "fanzsec", label: "FanzSec.Ai", icon: ShieldAlert, desc: "AI Security Assistant — white-hat, analisis file 49 MB", badge: "BARU" },
  // V2.13 zuperupdt — tools baru paling atas
  { view: "cuaca", label: "Cuaca Live", icon: CloudSun, desc: "GPS real-time, animasi kondisi, prakiraan besok", badge: "BARU" },
  { view: "wifi", label: "Check WiFi Sekitar", icon: WifiIcon, desc: "Region, IP, DNS, QR WiFi & audit password", badge: "BARU" },
  { view: "roda", label: "Roda Nama", icon: Dices, desc: "56 nama, multi-pemenang, ranking & animasi warna", badge: "BARU" },
  { view: "ascii", label: "ASCII Art", icon: TypeIcon, desc: "Multi-varian + logo Kali dragon — tanpa API key", badge: "BARU" },
  // V2.12 Security-Updt — Parent Monitor / Family Cyber Safety (aktif, bukan coming-soon)
  { view: "pm", label: "Parent Monitor", icon: ShieldPm, desc: "Family Cyber Safety — pantau HP anak legal & transparan", badge: "BARU" },
  { view: "studio", label: "Studio Gambar", icon: Palette, desc: "13 generator: spiral, brat, IQC, chat palsu, KTP dummy, wallpaper…", badge: "BARU" },
  { view: "hdimage", label: "Image HD", icon: Sparkles, desc: "HD-kan foto sampai 8K, rasio blur, gabung foto" },
  { view: "qr", label: "QR Studio", icon: QrCode, desc: "Buat QR bergaya + pindai/analisis QR" },
  { view: "kalkulator", label: "Kalkulator", icon: Calculator, desc: "Matematika lengkap + rumus fisika" },
  { view: "iqtest", label: "Tes IQ", icon: Brain, desc: "75 soal berbobot, hasil jujur + kartu PNG" },
  // V2 Modern-UpdSec — tools baru di daftar sidebar
  { view: "story", label: "FanzzStory", icon: Clock3, desc: "Status 22 jam: teks/foto+musik/video, like, komentar", badge: "BARU" },
  { view: "ibadah", label: "Ruang Ibadah", icon: MoonIbadah, desc: "Jadwal sholat, kiblat, bacaan, semua agama", badge: "BARU" },
  { view: "quran", label: "Qur'an Digital", icon: BookQuran, desc: "114 surah, 21 imam, tafsir & terjemahan", badge: "BARU" },
  { view: "debat", label: "Debat Filosofis AI", icon: SwordsDebat, desc: "Test psikologi + 8 level + skor & unduh", badge: "BARU" },
  { view: "sourcecode", label: "Ambil Source Code", icon: Code2, desc: "HTML/CSS/JS web lain — legal & rapi", badge: "BARU" },
  { view: "secscan", label: "Cek Keamanan Web", icon: ShieldCheck, desc: "18+ pemeriksaan, skor A+ s/d F", badge: "BARU" },
  { view: "minecraft", label: "Download Minecraft", icon: Gamepad2, desc: "APK, mods, maps, shaders, versi lengkap", badge: "BARU" },
  { view: "chat", label: "Chat Sosial", icon: MessageCircle, desc: "Chat realtime, grup, follow" },
  { view: "anime", label: "Nonton Anime", icon: Tv, desc: "Sub indo, player native bebas iklan" },
  { view: "dracin", label: "Nonton Dracin", icon: Tv2, desc: "Drama Asia sub Indonesia" },
  { view: "manhwa", label: "Baca Manhwa", icon: BookIcon, desc: "Komik full color + search" },
  { view: "komik", label: "Baca Komik", icon: Book, desc: "Manhwa • Manhua • Comic" },
  { view: "donghua", label: "Nonton Donghua", icon: Swords, desc: "Anime China sub indo" },
  { view: "gacha", label: "Gacha Nokos", icon: Dices, desc: "Nomor OTP WhatsApp + negara" },
  { view: "lyrics", label: "Lyrics Music Python", icon: Music2, desc: "Lirik lagu full + tersinkron" },
  { view: "usercheck", label: "Cek Profil Username", icon: AtSign, desc: "Ada di dalam tools OSINT" },
  { view: "profanity", label: "Deteksi Kata Sensitif", icon: ShieldAlert, desc: "Multi-bahasa + tingkat kasar" },
  { view: "history", label: "Riwayat", icon: HistoryIcon, desc: "Riwayat per tools, rapi terpisah" },
  { view: "aiimage", label: "AI Image Gen", icon: ImageIcon, desc: "Bikin gambar dari teks" },
  { view: "reactwa", label: "React Saluran WA", icon: Heart, desc: "React emoji ke saluran WA" },
  { view: "capcut", label: "CapCut Pro Gen", icon: Scissors, desc: "Akun aktif + Pro trial 7 hari" },
  { view: "nekopoi", label: "Nekopoi 21+", icon: Flame, desc: "Konten dewasa (verifikasi usia)", badge: "21+" },
  { view: "news", label: "Berita + BMKG", icon: Newspaper, desc: "Update tiap menit + info gempa" },
  { view: "books", label: "Baca Buku/PDF", icon: Library, desc: "Pustaka arsip + PDF lokal" },
  { view: "wiki", label: "Pencarian Wiki", icon: BookOpen, desc: "Indonesia & English — tinggal pilih" },
  { view: "film", label: "Nonton Film", icon: Clapperboard, desc: "MovieZone + LK21 + 30 server" },
  { view: "ai", label: "AI Chat", icon: Bot, desc: "Multi-model + riwayat + tugas latar" },
  { view: "music", label: "Musik", icon: Music4, desc: "Cari, populer, preview, download" },
  { view: "downloader", label: "Downloader", icon: Download, desc: "All-in-one 20+ platform + preview" },
  { view: "email", label: "Email Trial", icon: MailPlus, desc: "Email sementara + OTP" },
  { view: "am", label: "AM Active", icon: Zap, desc: "Premium Alight Motion", badge: "PRO" },
  { view: "osint", label: "OSINT", icon: Fingerprint, desc: "NIK & massal, email, WA, IP, domain, WHOIS, username" },
  { view: "apk", label: "APK Builder", icon: Package, desc: "HTML/ZIP atau link jadi app Android" },
  { view: "alltools", label: "The All-Tools", icon: Grid3X3, desc: "Semua tools + pencarian + coming soon" },
  { view: "profile", label: "Profil", icon: User, desc: "Akun, foto profil & pengaturan" },
];

export default function AppShell() {
  const { view, setView, user, chatUnread } = useApp();
  /** tema aktif: dark (default) / light / blood (Dark Charcoal-Blood) */
  const [theme, setTheme] = useState<"dark" | "light" | "blood">("dark");
  /** animasi gagak sedang berjalan (saat masuk tema blood) */
  const [crows, setCrows] = useState(false);
  const myAvatar = useMyAvatar();

  // heartbeat badge chat belum dibaca (jalan tiap 30 detik)
  useChatUnreadHeartbeat(true);

  const applyThemeClass = (t: "dark" | "light" | "blood") => {
    document.documentElement.classList.toggle("light", t === "light");
    document.documentElement.classList.toggle("blood", t === "blood");
  };

  // init tema dari pengaturan tersimpan (default: gelap) — lewat microtask biar gak cascading render
  useEffect(() => {
    queueMicrotask(() => {
      const t = getSettings().theme || "dark";
      setTheme(t);
      applyThemeClass(t);
    });

  }, []);

  /** Siklus tema: dark → light → blood (dengan gagak) → dark. */
  const cycleTheme = () => {
    const order: Array<"dark" | "light" | "blood"> = ["dark", "light", "blood"];
    const next = order[(order.indexOf(theme) + 1) % order.length];
    setTheme(next);
    saveSettings({ theme: next });
    applyThemeClass(next);
    if (next === "blood") setCrows(true);
  };

  // scroll ke atas tiap ganti view
  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [view]);

  const viewTitles: Record<ViewId, string> = {
    home: "Beranda", film: "Nonton Film", anime: "Nonton Anime", ai: "AI Chat",
    music: "Musik", downloader: "Downloader", email: "Email Trial", am: "AM Active",
    osint: "OSINT", apk: "APK Builder", chat: "Chat Sosial", news: "Berita Terkini",
    wiki: "Pencarian Wiki", books: "Baca Buku & PDF", profile: "Profil",
    nekopoi: "Nekopoi 21+", manhwa: "Baca Manhwa", komik: "Baca Komik", donghua: "Nonton Donghua",
    aiimage: "AI Image Gen", reactwa: "React Saluran WA", capcut: "CapCut Pro Gen",
    dracin: "Nonton Dracin", gacha: "Gacha Nokos", history: "Riwayat",
    lyrics: "Lyrics Music Python", profanity: "Deteksi Kata Sensitif", usercheck: "Cek Profil Username",
    studio: "Studio Gambar",
    hdimage: "Image HD", qr: "QR Studio", kalkulator: "Kalkulator", iqtest: "Tes IQ",
    // V2 Modern-UpdSec
    alltools: "The All-Tools", sourcecode: "Ambil Source Code Web", secscan: "Cek Keamanan Website",
    minecraft: "Download Minecraft", ibadah: "Ruang Ibadah", quran: "Qur'an Digital",
    debat: "Debat Filosofis AI", story: "FanzzStory",
    // V2.12 Security-Updt
    pm: "Parent Monitor — Family Cyber Safety",
    // V2.13 zuperupdt
    cuaca: "Cuaca Live",
    wifi: "Check WiFi Sekitar",
    roda: "Roda Nama",
    ascii: "ASCII Art",
    // FanzSec-Update
    security: "FanzzSecurity — Security Center",
    fanzsec: "FanzSec.Ai — AI Security Assistant",
  };

  return (
    <div className="flex min-h-dvh">
      {/* sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-[var(--surface-line)] bg-[var(--surface-side)] backdrop-blur-xl md:flex">
        <div className="flex items-center gap-2.5 px-5 py-5">
          <FanzzLogo className="h-9 w-9 drop-shadow-lg" />
          <div>
            <p className="text-sm font-extrabold leading-none">
              <span className="gradient-text">FanzzTools</span>
              <span className="ml-1 text-[10px] font-bold text-red-400">V2</span>
            </p>
            <p className="mt-0.5 text-[9px] text-muted-foreground">All-in-One Tools</p>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {ALL_TOOLS.map((t) => (
            <button
              key={t.view}
              onClick={() => setView(t.view)}
              data-nav-ai={t.view === "ai" ? "1" : undefined}
              className={`relative flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-left transition-colors ${
                view === t.view ? "text-white" : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
              }`}
            >
              {view === t.view && (
                <motion.span layoutId="side-pill" className="absolute inset-0 rounded-xl bg-gradient-to-r from-red-500/80 to-red-700/80" transition={{ type: "spring", stiffness: 350, damping: 30 }} />
              )}
              <t.icon className="relative z-10 h-4.5 w-4.5 shrink-0" />
              <div className="relative z-10 min-w-0 flex-1">
                <p className="flex items-center gap-1.5 truncate text-xs font-bold">
                  {t.label}
                  {t.badge && <span className="rounded-full bg-amber-500/20 px-1.5 py-px text-[8px] font-extrabold text-amber-300">{t.badge}</span>}
                </p>
              </div>
            </button>
          ))}
        </nav>

        <div className="space-y-2 border-t border-[var(--surface-line)] p-3">
          {/* jam real-time pengguna (V2 UpdSec) */}
          <LiveClock />
          {/* siklus tema: gelap → terang → charcoal-blood (gagak) */}
          <button
            onClick={cycleTheme}
            className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left transition-colors hover:bg-secondary/70"
          >
            <span
              className={`flex h-8 w-8 items-center justify-center rounded-lg text-white transition-colors ${
                theme === "light"
                  ? "bg-gradient-to-br from-amber-400 to-orange-500"
                  : theme === "blood"
                    ? "bg-gradient-to-br from-red-800 to-red-950"
                    : "bg-gradient-to-br from-blue-600 to-blue-900"
              }`}
            >
              {theme === "light" ? <Sun className="h-4 w-4" /> : theme === "blood" ? <Droplets className="h-4 w-4 text-red-300" /> : <Moon className="h-4 w-4" />}
            </span>
            <div className="min-w-0">
              <p className="text-xs font-bold">
                {theme === "light" ? "Mode Terang" : theme === "blood" ? "Charcoal-Blood" : "Mode Gelap"}
              </p>
              <p className="text-[10px] text-muted-foreground">Ketuk untuk ganti tema</p>
            </div>
          </button>
          <button onClick={() => setView("profile")} className="flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-left transition-colors hover:bg-secondary/70">
            {myAvatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={myAvatar} alt="foto profil" className="h-8 w-8 rounded-lg object-cover" />
            ) : (
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-red-500 to-red-700 text-xs font-extrabold text-white">
                {(user?.username || "L").charAt(0).toUpperCase()}
              </span>
            )}
            <div className="min-w-0">
              <p className="truncate text-xs font-bold">{user?.username}</p>
              <p className="truncate text-[10px] text-muted-foreground">{user?.email}</p>
            </div>
          </button>
        </div>
      </aside>

      {/* konten utama */}
      <main className="min-w-0 flex-1 md:pl-60">
        {/* header atas mobile */}
        <header className="sticky top-0 z-20 flex items-center gap-3 bg-[var(--surface-header)] px-4 py-3 pt-safe backdrop-blur-xl md:hidden">
          <FanzzLogo className="h-8 w-8 drop-shadow-lg" />
          <div className="min-w-0 flex-1">
            <p className="flex items-center gap-1 text-sm font-extrabold">
              <span className="gradient-text">FanzzTools</span>
              <span className="text-[10px] font-bold text-red-400">V2</span>
            </p>
            <p className="truncate text-[9px] font-bold text-muted-foreground">{viewTitles[view]}</p>
          </div>
          {/* jam real-time pengguna (V2 UpdSec) */}
          <LiveClock compact />
          <button
            onClick={cycleTheme}
            aria-label="Ganti tema (gelap / terang / charcoal-blood)"
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-colors ${
              theme === "light"
                ? "bg-gradient-to-br from-amber-400 to-orange-500"
                : theme === "blood"
                  ? "bg-gradient-to-br from-red-800 to-red-950"
                  : "glass"
            } text-white`}
          >
            {theme === "light" ? <Sun className="h-4 w-4" /> : theme === "blood" ? <Droplets className="h-4 w-4 text-red-300" /> : <Moon className="h-4 w-4" />}
          </button>
          <button
            onClick={() => setView("profile")}
            className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-gradient-to-br from-red-500 to-red-700 text-xs font-extrabold text-white"
            aria-label="Profil"
          >
            {myAvatar ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={myAvatar} alt="foto profil" className="h-full w-full object-cover" />
            ) : (
              (user?.username || "L").charAt(0).toUpperCase()
            )}
          </button>
        </header>

        <div className="mx-auto max-w-3xl px-4 pb-36 pt-4 md:px-8 md:pb-28">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
            >
              {view === "home" && <HomeView />}
              {view === "film" && <FilmView />}
              {view === "anime" && <AnimeView />}
              {view === "ai" && <AiChatView />}
              {view === "music" && <MusicView />}
              {view === "downloader" && <DownloaderView />}
              {view === "email" && <EmailView />}
              {view === "am" && <AmView />}
              {view === "osint" && <OsintView />}
              {view === "apk" && <ApkBuilderView />}
              {view === "chat" && <ChatView />}
              {view === "news" && <NewsView />}
              {view === "wiki" && <WikiView />}
              {view === "books" && <BooksView />}
              {view === "profile" && <ProfileView />}
              {view === "nekopoi" && <NekopoiView />}
              {view === "manhwa" && <ManhwaView />}
              {view === "komik" && <ComicView />}
              {view === "donghua" && <DonghuaView />}
              {view === "aiimage" && <AiImageView />}
              {view === "reactwa" && <ReactWaView />}
              {view === "capcut" && <CapcutView />}
              {view === "dracin" && <DracinView />}
              {view === "gacha" && <GachaNokosView />}
              {view === "history" && <HistoryView />}
              {view === "lyrics" && <LyricsToolView />}
              {view === "profanity" && <ProfanityView />}
              {view === "usercheck" && <UsernameCheckView />}
              {view === "studio" && <ImageStudioView />}
              {view === "hdimage" && <HdImageView />}
              {view === "qr" && <QrStudioView />}
              {view === "kalkulator" && <CalculatorView />}
              {view === "iqtest" && <IqTestView />}
              {/* V2 Modern-UpdSec — views baru */}
              {view === "alltools" && <AllToolsView />}
              {view === "sourcecode" && <SourceCodeView />}
              {view === "secscan" && <SecurityScanView />}
              {view === "minecraft" && <MinecraftView />}
              {view === "ibadah" && <IbadahView />}
              {view === "quran" && <QuranView />}
              {view === "debat" && <DebateView />}
              {view === "story" && <FanzzStoryView />}
              {/* V2.12 Security-Updt — Parent Monitor */}
              {view === "pm" && <ParentMonitorView />}
              {/* V2.13 zuperupdt — tools baru */}
              {view === "cuaca" && <CuacaView />}
              {view === "wifi" && <WifiView />}
              {view === "roda" && <RodaNamaView />}
              {view === "ascii" && <AsciiView />}
              {/* FanzSec-Update — FanzzSecurity + FanzSec.Ai */}
              {view === "security" && <FanzzSecurityView />}
              {view === "fanzsec" && <FanzSecAiView />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* bubble melayang FanzSec.Ai — kanan bawah (FanzSec-Update) */}
      {view !== "fanzsec" && view !== "security" && (
        <motion.button
          initial={{ opacity: 0, scale: 0.6, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          whileHover={{ scale: 1.07 }}
          whileTap={{ scale: 0.93 }}
          transition={{ type: "spring", stiffness: 320, damping: 22, delay: 0.6 }}
          onClick={() => setView("fanzsec")}
          aria-label="Buka FanzSec.Ai — AI Security Assistant"
          className="fixed bottom-24 right-4 z-30 flex h-13 w-13 items-center justify-center rounded-full md:bottom-6 md:right-6 md:h-14 md:w-14"
        >
          <span className="absolute inset-0 rounded-full bg-cyan-500/20 blur-lg" />
          <FanzSecBubble className="relative h-12 w-12 drop-shadow-[0_0_10px_rgba(34,211,238,0.45)] md:h-13 md:w-13" />
        </motion.button>
      )}

      <MiniPlayer />

      {/* V2-new (#9): pengaman klien — anti view-source + tanda tangan console */}
      <SecurityGuard />

      {/* animasi gagak saat beralih ke tema Dark Charcoal-Blood */}
      {crows && <CrowAnimation onDone={() => setCrows(false)} />}

      {/* bottom nav mobile */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-[var(--surface-line)] bg-[var(--surface-nav)] pb-safe backdrop-blur-xl md:hidden">
        <div className="grid grid-cols-5">
          {PRIMARY_TABS.map((t) => (
            <button
              key={t.view}
              onClick={() => setView(t.view)}
              data-nav-ai={t.view === "ai" ? "1" : undefined}
              className="relative flex flex-col items-center gap-0.5 py-2.5"
            >
              {view === t.view && (
                <motion.span layoutId="nav-dot" className="absolute top-0 h-0.5 w-8 rounded-full bg-gradient-to-r from-red-500 to-blue-600" />
              )}
              <t.icon className={`h-5 w-5 transition-colors ${view === t.view ? "text-red-400" : "text-muted-foreground"}`} />
              <span className={`text-[9px] font-bold transition-colors ${view === t.view ? "text-red-400" : "text-muted-foreground"}`}>
                {t.label}
              </span>
              {/* badge chat belum dibaca — ikut tombol All-Tools (chat ada di dalamnya) */}
              {t.view === "alltools" && chatUnread > 0 && view !== "chat" && (
                <span className="absolute right-3 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 text-[8px] font-extrabold text-white ring-2 ring-[var(--surface-nav)]">
                  {chatUnread > 9 ? "9+" : chatUnread}
                </span>
              )}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
