# APK Builder — Mode PARENT MONITOR

> Cara membuat companion Family Cyber Safety langsung dari web, tanpa
> Android Studio. V2.12 Security-Updt.

---

## Kapan pakai mode ini?

Mode **Parent Monitor** di APK Builder membuat **companion HP anak** —
aplikasi kecil untuk pairing + pelaporan status perangkat yang transparan.
Pakai ini kalau Anda ingin cara tercepat (±2 menit) tanpa compile apa pun.

Kalau Anda butuh **statistik pemakaian aplikasi penuh**
(UsageStatsManager), build companion **native Kotlin** — lihat
`ANDROID-SETUP.md`.

Mode lama APK Builder (**File HTML/ZIP** dan **Dari Link/URL**) tidak
berubah sama sekali — mode Parent Monitor hanyalah pilihan ketiga.

---

## Langkah

1. **Buka lewat dashboard Parent Monitor** (disarankan):
   Parent Monitor → perangkat anak → **Buat APK Companion**.
   APK Builder akan terbuka otomatis di mode Parent Monitor dengan profil
   anak sudah terisi.

   *(Bisa juga dibuka langsung: APK Builder → tombol **Parent Monitor**.)*

2. **Atur aplikasi**:
   - **Nama aplikasi** — tampil di launcher HP anak.
     ⛔ DILARANG menyamarkan sebagai aplikasi sistem ("Android System",
     "Google Play Services", dll) — tombol build menolak nama-nama itu.
   - **Icon** — wajib (jpg/png, di-resize otomatis).
   - **Fitur monitoring** — centang/hapus: Status perangkat (ON),
     Statistik pemakaian, Lokasi (OFF), Media (OFF).

3. **Generate Companion APK** — proses ±10–30 detik di browser Anda
   (file tidak diunggah ke mana pun; ditandatangani di perangkat Anda).

4. **Hasil** menampilkan:
   - Ukuran file + **nama package** (`com.fanzz.familysafety.…`) + versi
   - **SHA-256** untuk memverifikasi file APK tidak berubah
   - **Kode pairing + QR otomatis** (kalau dibuka dari dashboard) —
     berlaku 10 menit

5. **Install di HP anak**: kirim file APK → buka → izinkan "install dari
   sumber tidak dikenal" → Install.

6. **Hubungkan**: buka companion → *Mulai Hubungkan* → ketik kode
   `PM-XXXX-XXXX` (atau pindai QR) → baca layar konfirmasi → **Saya Setuju**.

---

## Apa yang dilakukan companion ini?

| Layar | Isi |
|---|---|
| Sambutan | Penjelasan transparan + daftar fitur yang akan aktif |
| Hubungkan | Input kode `PM-XXXX-XXXX` + pemindai QR (bila kamera tersedia) |
| Konfirmasi | Keluarga/anak/perangkat/fitur — anak menekan **Saya Setuju** |
| Status | Fitur aktif, baterai, jaringan, sinkron terakhir + tombol Sinkron / Kirim Lokasi (opsional) / Bagikan Foto (opsional) / **Putuskan Koneksi** |
| Privasi | Daftar lengkap apa yang dikirim & yang tidak pernah dilakukan |

Companion **hanya aktif saat dibuka** (heartbeat tiap 60 detik selama
aplikasi terbuka) — bukan pelacak latar belakang. Sinkron latar belakang
terjadwal ada di companion native.

## Catatan teknis

- Companion web tidak bisa mengakses `UsageStatsManager` (batasan Android
  untuk semua aplikasi web) — itu sebabnya statistik pemakaian penuh butuh
  companion native (`android-companion/`).
- Kamera QR memakai `BarcodeDetector` bawaan Android Chrome/WebView.
  Kalau tidak tersedia/diizinkan, kode manual tetap berfungsi — hasilnya
  sama persis.
- Template APK + sertifikat penanda tangan diambil dari `/apk/` milik
  server Anda sendiri (sama seperti mode File/Link).
