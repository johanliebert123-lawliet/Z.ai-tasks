# FanzzTools V2 — All-in-One Tools Website

> **V2.13 zuperupdt** — lihat `ZUPERUPDT-REPORT.md` untuk daftar perbaikan & tools baru (Cuaca Live, Check WiFi, Roda Nama, ASCII Art, Tutorial Termux, Parent Monitor 2-fase consent, Qur'an multi-sumber anti-terpotong, Downloader multi-resolusi 4K).

Website all-in-one tools: **nonton film** (MovieZone server utama + LK21 Stream Premium + subtitle semua bahasa + CC AI), **nonton anime sub indo** (pemutar NATIVE bebas iklan — bisa diskip/diputar ulang), **nonton donghua**, **nonton Dracin** (katalog TMDB + 20+ server embed), **baca manhwa**, **baca komik** (Manhwa + Manhua + Comic via ComicVerse), **Nekopoi 21+** (pemutar native + auto pindah server saat mirror terproteksi), **Gacha Nokos** (nomor mengikuti rencana penomoran negara + pilih negara), **Lyrics Music Python** (lirik lagu lengkap), **Cek Profil Username** (di dalam OSINT), **Deteksi Kata Sensitif** (multi-bahasa + leet + hate speech), **AI chat multi-model dengan RIWAYAT + INGATAN + TUGAS LATAR BELAKANG**, **AI image generator**, **react saluran WhatsApp**, **CapCut Pro generator**, **musik** (Sedang Populer, semua lagu bisa diputar tanpa delay, lirik tebal real-time + teka-lirik, mini player popup biasa + mode bubble), **all-in-one downloader** (YouTube via InnerTube + preview semua), **chat sosial + grup**, **berita + Info BMKG real-time**, **baca buku/PDF** (+ seksi sedang populer), **wiki dua bahasa**, **email trial**, **AM Active**, **OSINT** (NIK + NIK Massal + Email Checker + WA Info/Unban + IP + domain + WHOIS + Cek Username), **APK Builder** (+ mode Parent Monitor), **Riwayat per-tools**, **Studio Gambar** (13 generator), **Image HD** (upscale 8K + rasio blur + gabung foto), **QR Studio** (generator bergaya + pemindai), **Kalkulator** (matematika + fisika), **Tes IQ** (75 soal, hasil jujur), dan **Parent Monitor / Family Cyber Safety** (pengawasan anak yang legal, transparan, anti-salah-pakai — maks usia anak 35 tahun).

Dibangun dengan **Next.js 16 + TypeScript + Tailwind CSS 4 + shadcn/ui** — terstruktur, rapi, aman, dan siap deploy di **Vercel**.

---

## Ringkasan Perubahan pada Versi 2.12.0 (Security-Updt)

**7 perbaikan bug + aktivasi modul Parent Monitor** — tanpa menulis ulang sistem yang sudah berjalan, tanpa mengubah lapisan keamanan yang sudah ketat.

### Perbaikan bug:
1. **Audio Qur'an (#1)** — dulu gagal untuk SEMUA imam ("imam lagi bermasalah"): view memanggil CDN luar langsung dengan `crossOrigin` sehingga kena CORS/blokir jaringan. Sekarang audio di-stream lewat `/api/quran/audio` (same-origin) dengan rantai sumber cadangan otomatis: cdn.islamic.network → everyayah.com → cdn.equran.id. Mode full-surah pun kini lewat proxy dengan allowlist host.
2. **Downloader (#2)** — preview video gagal & unduhan YouTube ter-redirect ke halaman FanzzTools sendiri. Akar masalah: URL InnerTube yang SUDAH berupa proxy relatif dibungkus proxy dua kali (→ 400 "Tautan file tidak valid"), lalu fallback unduhan membuka URL relatif sebagai navigasi (→ halaman sendiri). Sekarang URL proxy dipakai apa adanya dan unduh langsung hanya untuk URL absolut.
3. **Foto profil & story hilang (#3)** — social-store & story-store 100% in-memory (cold-start = hilang). Ditemukan JUGA bug serius di persist.ts: semua file JSON ter-stringify GANDA sehingga pm.json tidak pernah benar-benar pulih. Keduanya diperbaiki: profil, story, chat, grup, dan data Parent Monitor kini bertahan restart (data/social.json, data/story.json, data/pm.json).
4. **Status foto + musik (#4)** — tipe story baru **Foto + Musik**: foto tampil TETAP 14 detik, musik latar opsional dipotong 14 detik.
5. **Video story layar hitam (#5)** — data video tidak pernah sampai pemutar (respons `/api/story/view` diabaikan). Sekarang data video/foto/musik dimuat saat story dibuka + indikator memuat.
6. **Parent Monitor belum aktif (#6)** — dashboard & API-nya sudah ada tapi tidak terdaftar di navigasi; fitur pilihan orang tua pada QR di-hardcode sehingga lokasi/media tidak pernah aktif. Kini: tampil di sidebar/beranda/All-Tools (kartu lama "Ransomware 30+" yang menyesatkan DIHAPUS), QR membawa fitur pilihan orang tua, ada `/api/pm/health`, APK Builder punya mode **Parent Monitor** (companion web), dan sumber companion **native Kotlin** tersedia di `android-companion/`.
7. **Kompas kiblat (#7)** — dulu hanya mendengarkan `deviceorientation` (alpha RELATIF — bukan utara sejati di Android) tanpa kompensasi rotasi layar. Sekarang: `deviceorientationabsolute` + fallback iOS (`webkitCompassHeading`) + kompensasi sudut layar + smoothing + label status sensor jujur (absolut/relatif/tidak didukung).

### Modul baru: Parent Monitor / Family Cyber Safety
Pengawasan orang tua yang **legal & transparan** (bukan spyware): pernyataan wali resmi, batas usia anak 35 tahun (server-side), pairing QR HMAC sekali-pakai 10 menit dengan konfirmasi eksplisit anak, token perangkat tersimpan sebagai hash, isolasi household total, audit log, Privacy Center, retensi otomatis. **Tanpa** keylogger/intercep OTP/baca chat/rekam diam-diam/stealth mode. Dokumentasi: `PARENT-MONITOR.md`, `QR-ENROLLMENT.md`, `APK-BUILDER-PARENT-MONITOR.md`, `ANDROID-SETUP.md`, `SECURITY.md`, `PRIVACY.md`, `TROUBLESHOOTING.md`, `VERCEL-DEPLOYMENT.md`.

### Catatan jujur build:
31 pengujian API end-to-end Parent Monitor + story foto/musik + persistensi **PASS** di environment build (lihat `FINAL-REPORT.md`). Companion **native Kotlin** (android-companion/) TIDAK dikompilasi di environment ini (tanpa Android SDK) — ditandai **NOT RUN** dan harus dibangun orang tua via Android Studio.

---

## Ringkasan Perubahan pada Versi 2.11.0

Perbaikan bug nyata + 8 kelompok fitur baru — tanpa mengubah sistem yang sudah berfungsi (perintah #17 dihormati).

### Perbaikan bug yang dilaporkan:
1. **Musik (#1/#11/#33) — semua lagu bisa diputar & anti-delay**: penyedia audio kini berbalapan PARALEL (InnerTube 3 klien + **savetube 3 CDN** (teknik NanzMusify — terbukti bekerja bahkan dari IP yang diblokir Google) + faa + puruboy), dedupe permintaan in-flight per lagu, cache per-videoId dengan TTL per sumber, parameter `fresh=1`, dan auto-retry pemutar saat URL audio kedaluwarsa. Seksi Sedang Populer tetap jalan.
2. **Dracin (#6/#34) — dibangun ulang dari nol**: dracinema.com memblokir permanen semua IP datacenter (termasuk Vercel). Dracin kini memakai katalog **TMDB** (Drama China/Korea/Semua Asia, filter live-action, genre, season/episode) + pemutaran lewat **20+ server embed milik sendiri** (jalur yang sama dengan Nonton Film — VidLink/VidSrc/MovieZone/LK21 + subjudul).
3. **Nekopoi Playmogo (#5b)**: Playmogo 1/2 terproteksi Cloudflare di sisi server — sistem kini otomatis beralih ke mirror lain yang bisa dibaca (Streampoi/streamruby native), tampilan mirror diurutkan, dan bila semua terkunci, pemutar embed + pesan jujur.
4. **NOKOS (#26)**: panjang nomor diperbaiki mengikuti rencana penomoran negara (Indonesia 13 digit, Filipina 13, Vietnam 12) — tidak lagi "kurang 1 digit".
5. **Buku (#34)**: seksi **Sedang Populer** — tren mingguan Open Library → fallback arsip terbanyak diunduh → fallback daftar kurasi (selalu tampil).

### Fitur baru:
6. **IQC lengkap (#22)** — Studio Gambar kini 13 generator: + **Prank** (BSOD/Error PC, dialog klasik, peringatan virus, terminal hacker — teks bisa diubah), **Chat Palsu** (WhatsApp/TikTok DM/iMessage — nama, foto profil, isi chat bisa diubah), **KTP Dummy** (semua kolom bisa diubah + foto, watermark merah diagonal "DUMMY FanzzTools V2" permanen + cap kecil sudut), **Wallpaper**, **TikTok Quote**, **Notifikasi** (banner layar kunci WA/iPhone/Android); **Brat** kini punya kontrol spasi antar kata + kecepatan ketik video. Semua keluaran quote/chat tercantumkan teks "Testing Generator • By : FanzzTools™".
7. **Image HD (#23)** — upscale bertahap sampai 8K + penajaman unsharp (jujur: penajaman piksel, bukan AI generatif), konversi rasio dengan sisi blur (9:16 ↔ 16:9 dll, kekuatan blur bisa diatur), gabung 2-4 foto (3 tata letak), pembanding sebelum/sesudah digeser, ekspor PNG/JPG/WebP.
8. **QR Studio (#35)** — generator QR dengan bentuk modul **kotak/bulat/titik/HATI**, sudut mata, warna kustom, logo tengah (ECC level H), ukuran 512-2048px, mode isi Teks/URL/WiFi/Kontak; **pemindai** QR dari gambar (jsQR) + analisis isi (URL/WiFi/kontak/lokasi/teks + salin/buka tautan).
9. **Email Checker (#25)** — format, MX domain (DNS nyata), domain sekali-pakai, profil Gravatar, reputasi bila tersedia, verdict + tips pemulihan. Jujur soal yang tidak mungkin dicek alat publik (daftar registrasi, kata sandi bocor per-email, tanggal buat akun, nomor WA terkait) + tautan resmi HIBP.
10. **WA Info + Unban (#27/#28)** — validitas nomor (rencana penomoran 40+ negara), negara, indikasi operator (ID), tautan wa.me; jujur bahwa nama/foto profil/tanggal buat tidak bisa ditarik alat publik. **Composer surat banding** (jenis blokir + penyebab + kronologi) yang tersalin siap kirim ke jalur resmi WhatsApp.
11. **Kalkulator (#29)** — mode Matematika (parser recursive-descent aman TANPA eval: + − × ÷ ^ % !, fungsi sqrt/sin/cos/tan/log/ln/abs, konstanta π/e/phi, riwayat) + mode Fisika (12 rumus Mekanika/Listrik/Materi/Kalor/Gelombang dengan **solver dua arah** — isi yang diketahui, kosongkan satu yang dicari).
12. **Tes IQ (#30)** — 75 soal asli berbobot 3 tingkat (deret angka, analogi, logika, aritmetika, deret huruf, beda-satu); pilih 20/40/60/75 soal; timer 30 detik/soal; **hasil jujur** (tidak disembunyikan walau rendah, skor rendah tetap ditampilkan apa adanya); rincian per kategori; kartu hasil PNG 1080×1440 berbingkai + disclaimer bukan diagnosis resmi.
13. **Lirik Tebal real-time (#31)** — baris lirik aktif TEBAL + tersorot mengikuti posisi lagu (lirik tersinkron LRCLIB), gulir otomatis; mode **Teka-Lirik** (tebak baris aktif dengan clue 3 tingkat — huruf awal → sebagian kata → baris penuh — **berbatas 5 clue per lagu**).
14. **NIK Massal (#16 versi legal)** — tempel banyak NIK (maks 100) → tabel valid/salah + wilayah + tanggal lahir hasil pembacaan struktur angka + penanda anomali (tanggal tidak mungkin, panjang salah, nomor urut 0000) + salin CSV untuk Sheets/Excel.
15. **Footer beranda (#24)** — tujuan web, hak cipta, dan himbauan "Gunakan dengan bijak!" di bawah beranda (tipis, tidak menghalangi).

### Catatan etis (tetap):
Permintaan **RAT** (pengendali HP jarak jauh) dan **lookup data pribadi dari NIK via data bocor** TIDAK diimplementasikan — itu malware/doxxing dengan risiko pidana (UU PDP 27/2022 & UU ITE) bagi siapa pun yang memakainya, termasuk pribadi. Cek NIK tetap **dekoder struktural murni** (38 provinsi / 514 kab-kota / 7.285 kecamatan Kemendagri) + kini validasi massal. Semua tools ditulis "gunakan dengan bijak".

---

## Ringkasan Perubahan pada Versi V2-new (2.9.0)

Pembaruan terarah dari V0.01 — tidak ada sistem dibangun ulang; yang berfungsi tetap utuh, masalah yang dilaporkan diperbaiki satu per satu.

1. **Musik — semua lagu bisa diputar & instan (#1, #11)** — audio kini diambil langsung dari server YouTube (rantai InnerTube WEB_REMIX → ANDROID → IOS) lalu diputar lewat proxy streaming (Range/206); tidak lagi bergantung pada konverter pihak ketiga yang lambat & rate-limited. Fallback faa/puruboy tetap ada.
2. **Musik — seksi "Sedang Populer" (#1)** — daftar lagu tren tampil otomatis saat membuka halaman musik (multi-kueri tren, rotasi harian).
3. **Mini player (#18)** — default popup BIASA (lengkap); tombol KOTAK di sisi kiri-atas mengubahnya jadi gelembung bulat yang bisa digeser (musik tetap berjalan).
4. **Anime (#5)** — pencarian kini punya fallback database Jikan/MyAnimeList (klik kartu = cari versi sub indo otomatis); mirror dapat dikonversi ke PEMUTAR NATIVE (tanda NATIVE — bebas iklan, diskip, layar penuh + kunci landscape) via /api/anime/resolve + /api/stream/proxy; tombol Muat ulang melewati cache; pemutar embed utama (embedUrl) yang sebelumnya tidak pernah dirender kini dipakai sebagai cadangan.
5. **Nekopoi (#5b)** — semua server (Playmogo 1/2, Streampoi, M3U8, MP4) di-resolve ke pemutar native (bebas iklan, bisa diskip/diputar ulang); bila server diblokir sumber, pemutar embed cadangan otomatis dipakai + pesan jujur.
6. **Donghua (#2)** — akar bug ditemukan: pencarian `?s=` sumber tidak berfungsi secara server-side dan seluruh kartu situs adalah halaman watch. Pencarian kini memakai katalog lokal (±96 judul, cache 1 jam); kartu langsung membuka episode; pemutar memakai URL geo.dailymotion ASLI + tombol "Ganti Pemutar" cadangan.
7. **Dracin (#6)** — request dua putaran (Node fetch + cURL, masing-masing diulang) + parameter refresh + pesan error jujur; bila sumber memblokir IP server, pengguna diberi tahu apa adanya.
8. **Wikipedia (#3)** — API diambil dengan tiga strategi berurutan (fetch biasa → HTTP/2 ala browser → cURL) + pengulangan; klien memakai timeout & tombol "Berhenti memuat" supaya tidak ngestuck saat membaca artikel lengkap.
9. **Beranda (#4)** — SEMUA tools tampil di beranda; sheet "Lainnya" kini dapat DIGULIR (perbaikan ngefreeze) dengan tinggi maksimum 80dvh.
10. **Komik BARU (#20)** — view "Baca Komik" dengan tab Semua/Manhwa/Manhua/Comic dari ComicVerse (Bacakomik): pencarian, detail, daftar chapter, reader vertikal + navigasi chapter.
11. **Cek Username (#7, #14)** — pindah ke dalam tools OSINT (tab "Cek Username"); variasi username kini beragam & dirotasi per nama (tidak lagi pola berulang seperti .14 terus), dan hanya yang benar-benar DITEMUKAN yang ditampilkan.
12. **Deteksi kata sensitif (#8)** — normalisasi LEET (4nj1ng, k0nt0l), pengulangan huruf (anjiiing), pemisah (a-n-j-i-n-g), penyamaran (b*tch), plus kamus HATE SPEECH (nazi, hitler, KKK, slur rasial, dll) — terverifikasi: "nazi" kini terdeteksi level 3.
13. **Gacha Nokos (#15)** — nomor mengikuti RENCANA PENOMORAN negara (awalan ponsel valid, mis. Indonesia 62-8xx) sehingga tidak lagi ditolak WhatsApp dengan "nomor tidak sesuai negara"; pemilih negara; tombol salin nomor polos (E.164 tanpa format).
14. **Animasi gagak + tema blood (#13)** — gerombolan lebih besar (28 ekor + gagak alfa raksasa), durasi lebih panjang, vignette merah darah berdenyut, tema blood lebih gelap dengan vignette menetap.
15. **AI Chat (#21)** — RIWAYAT percakapan (tersimpan, bisa dibuka & dilanjutkan), INGATAN jangka panjang (hal yang selalu diingat AI di semua sesi), dan TUGAS LATAR BELAKANG (toggle "Latar" — pindah menu sesuka hati, AI tetap mengerjakan; hasil masuk Riwayat + notifikasi).
16. **Downloader YouTube (#12)** — penyedia InnerTube dijalankan pertama (stabil, tanpa "failed to fetch"); URL terikat IP dikirim via proxy unduh; preview video/audio/gambar tetap untuk semua platform.
17. **Keamanan (#9)** — security headers ketat (anti-clickjacking, nosniff, HSTS, Permissions-Policy), X-Copyright di level HTTP, poweredByHeader & source map produksi dimatikan, API noindex + no-store, menu klik-kanan dinonaktifkan di produksi + tanda tangan kepemilikan di console.
18. **Cap anti-klaim (#10)** — badge "By : Fanzz-Dev. ©FanzzProject 2026-10-12" + peringatan tidak boleh mengklaim, kecil tapi terbaca di pojok kanan bawah BERANDA saja; konstanta dibekukan + verifikasi integritas berkala (dipasang ulang bila dihapus dari DOM).

---

## Ringkasan Perubahan pada Versi V0.01

Versi ini merupakan pembarahan terarah dari FanzzTools V2a (2.7.0) — tidak ada fitur yang dibangun ulang, semua yang berfungsi tetap dipertahankan, perbaikan dan penambahan bersifat menambal masalah yang dilaporkan.

1. **Perbaikan downloader YouTube ("error http")** — format CDN langsung (tidak terikat IP server) ditambahkan sebagai pilihan unduh yang selalu tersedia; bila proxy ditolak sumber, unduhan otomatis beralih ke mode langsung.
2. **Server LK21 Stream Premium ditambahkan di pemutar film** (5 server: VIP/Fast/HD/Pro/Ultra) — MovieZone tetap sumber utama di urutan pertama.
3. **Subtitle semua bahasa** — pilihan subtitle kini mendukung 30+ bahasa (Indonesia, English, Jepang, Korea, Arab, Spanyol, dll) di server VidLink/LK21 VIP; CC AI menerjemahkan otomatis bila subtitle bahasa yang dipilih belum tersedia (default Bahasa Indonesia, aktif otomatis).
4. **Gacha Nokos** — gacha nomor virtual untuk OTP WhatsApp lengkap dengan deteksi negara asal, jenis WhatsApp (Business / App biasa), rarity, dan kode OTP berbatas waktu.
5. **Riwayat per-tools** — setiap tools (film, anime, manhwa, donghua, dracin, nekopoi, buku, musik, downloader, lirik, nokos) punya riwayatnya sendiri yang rapi dan bisa dikelola.
6. **Tema Dark Charcoal-Blood** — tema ketiga selain gelap & terang; saat beralih ke tema ini kawanan gagak abu-hitam bermata merah menyala (gaya Sharingan) terbang menyilang dari tiga arah dengan animasi halus dan efek lensing pada mata.
7. **Nonton Dracin** — drama Asia sub Indonesia dari dracinema.com (porting SC DracinTeros), langsung di FanzzTools dengan pemutar video in-app + pilih kualitas; dibangun sebagai route Next.js sehingga otomatis mendukung deploy Vercel.
8. **Nekopoi 21+ diperbarui** — sumber utama kini dixzz-neko-api (daftar rapi, mirror bernama, tautan unduh per kualitas); scraper lama tetap dipakai sebagai cadangan.
9. **Lyrics Music Python** — pencarian lirik lagu lengkap sesuai nada & panjang lagu (lirik polos + lirik tersinkron per waktu).
10. **Cek Profil Username** — masukkan username (tanpa @), sistem memeriksa real-time di 12 platform (TikTok, Instagram, YouTube, Twitter/X, GitHub, Reddit, Telegram, dll) + variasi username populer.
11. **Deteksi Kata Sensitif** — periksa teks multi-bahasa (Indonesia, Inggris US/UK, Jerman, Jepang, Sunda, Jawa) dengan tingkat keparahan dan versi tersensor otomatis.
12. **Info BMKG real-time** — gempa signifikan terbaru, gempa dirasakan, gempa terkini, dan potensi peringatan tsunami (kartu di halaman Berita, auto-refresh).
13. **Perbaikan delay musik** — putar ulang lagu jadi instan (cache server + cache perangkat, penyedia dijalankan paralel dengan fallback cURL).
14. **Mini player bubble** — popup musik kini bisa dikecilkan jadi bulatan kecil yang dapat digeser tanpa menghentikan musik; ketuk untuk memperbesar kembali, tombol X untuk menutup sekaligus membatalkan lagu.
15. **ID pengguna FanzzTools (LT-XXXXXX)** — ditampilkan di profil, bisa dicari di chat, admin grup dapat menambah anggota langsung via ID/username, jumlah followers & profil lengkap pengguna lain dapat dilihat real-time.
16. **APK Builder diperbaiki + mode link** — akar masalah "APK langsung tertutup" ditemukan dan diperbaiki (activity kini menunjuk ke kelas asli di dex secara absolut); tersedia dua pilihan sumber: file HTML/ZIP atau tautan/URL.
17. **Wikipedia dua bahasa** — pilih Wikipedia Indonesia atau English langsung dari halaman pencarian.
18. **Anime, donghua, manhwa, buku, nekopoi** — diverifikasi ulang dan diperbaiki (sumber anime bintangapi sehat: 3 grup resolusi × mirror; manhwa MangaDex; donghua topdonghua; buku fallback Internet Archive).

---

## Cara Deploy ke Vercel (2 Menit)

### Cara 1: Lewat GitHub (Direkomendasikan)
1. Extract ZIP ini, unggah seluruh isinya ke repo GitHub baru (private juga bisa).
2. Buka [vercel.com](https://vercel.com) → **Add New → Project**.
3. Import repo tersebut → Vercel otomatis mendeteksi Next.js.
4. Klik **Deploy** — selesai. Tidak perlu pengaturan tambahan apa pun.

### Cara 2: Vercel CLI
```bash
npm i -g vercel
cd fanzztools-v2-v001
vercel --prod
```

### Env Variables (Opsional)
Semua fitur langsung berjalan tanpa pengaturan apa pun. Namun **sangat disarankan** mengatur `APP_SECRET` agar cookie session Anda unik:

| Variable | Wajib? | Keterangan |
|----------|--------|------------|
| `APP_SECRET` | Disarankan | Secret untuk signing cookie session. Ganti dengan string acak yang panjang. |
| `AM_API_BASE` | Tidak | Default `https://am.yappi.my.id`. Bila domain AM berubah, perbarui nilai ini. |
| `TMDB_API_KEY` | Tidak | Default sudah terpasang. |

Caranya: Vercel → Project → Settings → Environment Variables.

---

## Fitur Lengkap

### Nonton Film
- **MovieZone = server utama** (pilihan bawaan, urutan pertama) + **LK21 Stream Premium** (VIP/Fast/HD/Pro/Ultra) + 15 server embed lain — total 23+ server.
- **Subtitle semua bahasa (30+)** — aktif otomatis Bahasa Indonesia, tinggal pilih dari daftar; CC AI menerjemahkan otomatis bila belum tersedia.
- **Anti-iklan otomatis** via iframe sandbox ketat + toggle Mode Kompatibel.
- Series lengkap dengan pemilih season & episode + tombol Landscape.
- Riwayat menonton otomatis (muncul di Beranda + tab Riwayat).

### Nonton Anime
- Sedang tayang, jadwal per hari, anime tamat, pencarian + detail lengkap.
- Nonton langsung: pilih resolusi (360p-1080p) & mirror (filedon, vidhide, mega, dll) + tautan unduh episode.
- Chat sambil menonton.

### Nonton Dracin (BARU)
- Drama Asia sub Indonesia dari dracinema.com: beranda, genre, pencarian, detail, daftar episode.
- Pemutar video in-app dengan pilih kualitas + navigasi episode + buka di pemutar luar.
- Dub Indonesia mengikuti trek audio yang disediakan sumber.

### Nonton Donghua
- Hot/Populer, Baru diperbarui, Sedang Tayang, Akan Tayang, Tamat + pencarian; player dailymotion.

### Baca Manhwa
- Katalog populer + pencarian dua sumber (MangaDex + sumber lama), reader in-app, chapter resmi bertanda.

### Nekopoi 21+
- Sumber utama dixzz-neo-api (terbaru + pencarian + detail + mirror bernama + tautan unduh per kualitas + m3u8), cadangan scraper langsung.
- Gerbang verifikasi usia 21+, sandbox anti-popup, tombol Layar Penuh & Ganti Mirror.

### Gacha Nokos (BARU)
- Gacha nomor virtual dengan rarity (Umum/Langka/Epik/Legendaris) + animasi mengocok.
- Deteksi negara asal (prefix asli 40+ negara) + jenis WhatsApp (Business / App biasa).
- Kode OTP 6 digit berlaku 5 menit + limit harian + riwayat nomor tersimpan.

### Lyrics Music Python (BARU)
- Cari lagu → lirik lengkap (lirik polos + lirik tersinkron per waktu/nada), salin lirik sekali klik.

### Cek Profil Username (BARU)
- Periksa username di 12 platform secara real-time + variasi username populer (@billy123, @billy.id, dll) lengkap dengan status per platform.

### Deteksi Kata Sensitif (BARU)
- Deteksi kata kasar/sensitif: Indonesia, Inggris (US/UK), Jerman, Jepang, Sunda, Jawa.
- Tingkat keparahan (agak kasar / kasar / sangat kasar), statistik per bahasa, versi tersensor otomatis.

### Riwayat (BARU)
- Riwayat terpisah per tools (film, anime, manhwa, donghua, dracin, nekopoi, buku, musik, downloader, lirik, nokos) — lihat, buka tools, hapus per entri/tab, atau bersihkan semua.

### Berita + Info BMKG (BARU)
- Berita update tiap menit sesuai lokasi + Cek Fakta.
- Kartu Info BMKG: gempa signifikan terbaru (magnitudo, kedalaman, peta shakemap), gempa dirasakan, gempa terkini, potensi tsunami — auto-refresh 2 menit.

### Pencarian Wiki
- Wikipedia **Indonesia** dan **English** — tinggal pilih bahasanya, artikel dibaca langsung in-app.

### Baca Buku/PDF
- Pustaka jutaan buku (Internet Archive) + PDF lokal + pencarian otomatis versi terbaca.

### AI Chat & AI Image Gen
- 5 model AI bisa dipilih + analisis gambar + baca file + mode Web; image generator dengan fallback otomatis.

### React Saluran WA & CapCut Pro Gen
- React emoji ke pesan saluran WA (deteksi pemeliharaan jujur + alternatif ReaksiKu); generator akun CapCut Pro trial 7 hari.

### Musik
- Cari, preview (proxy anti-CORS), unduh MP3, lirik, favorit.
- **Mini player bubble** yang bisa digeser tanpa menghentikan musik — ketuk untuk memperbesar, X untuk menutup & membatalkan.
- Putar ulang instan (cache).

### All-in-One Downloader
- 20+ platform, rantai penyedia berlapis (varhad → faa CDN langsung → tikwm → faa), preview + progress bar.
- YouTube: 14+ format termasuk format CDN langsung yang selalu bisa diunduh; TikTok tetap stabil.

### Chat Sosial + Grup
- Chat realtime (teks/gambar/VN), cari pengguna via **ID FanzzTools (LT-XXXXXX)** atau username/negara.
- Grup: admin dapat menambahkan anggota via ID/username, promote/demote, kick; lihat followers & profil lengkap pengguna lain real-time.

### Email Trial, AM Active, OSINT + WHOIS, APK Builder, Profil
- Email sementara + OTP otomatis; AM Active premium; OSINT (NIK/IP/nomor/domain/WHOIS); **APK Builder dari file HTML/ZIP atau dari link/URL** (activity diperbaiki — tidak lagi langsung tertutup); profil dengan ID pengguna.

### Tema
- Tiga tema: **Gelap** (default), **Terang**, dan **Dark Charcoal-Blood** (dengan animasi kawanan gagak bermata merah menyala saat diaktifkan).

---

## Sistem Login (Aman & Tanpa Ribet)
- Login/sign up wajib; password di-hash bcrypt; session di cookie httpOnly yang di-sign JWT (30 hari).
- Rate limiting per IP di semua endpoint sensitif; validasi input ketat + proteksi SSRF di API downloader.
- Tanpa database eksternal — akun dapat dipulihkan otomatis dari vault lokal bila server cold-start.

## Struktur Proyek
```
src/
├── app/
│   ├── page.tsx               # App shell (loading → auth → tools)
│   ├── layout.tsx             # Root layout + font
│   ├── globals.css            # Tema (gelap/terang/charcoal-blood + animasi gagak)
│   └── api/                   # 28+ API routes (auth, movies, anime, manhwa,
│                               #   nekopoi, dracin, download, subtitle, bmkg,
│                               #   lyrics-tool, username-check, social, ai, ...)
├── components/
│   ├── LoadingScreen.tsx      # Loading animasi awal
│   ├── AuthGate.tsx           # Login / Sign up
│   ├── AppShell.tsx           # Navigasi + tema 3-mode + registrasi semua tools
│   ├── MiniPlayer.tsx         # Musik mini player bubble (draggable)
│   ├── CrowAnimation.tsx      # Animasi gagak tema Charcoal-Blood
│   └── tools/                 # 27 view tools (Film, Anime, Dracin, Gacha Nokos,
│                               #   Lyrics, UsernameCheck, Profanity, Riwayat, BMKG, ...)
└── lib/
    ├── session.ts             # JWT session (jose)
    ├── store.ts               # User registry + rate limiter
    ├── social-store.ts        # Profil + chat + grup + fanzzId
    ├── history.ts             # Riwayat per-tools (localStorage)
    ├── nokos.ts               # Gacha Nokos (negara, WA type, OTP)
    ├── profanity.ts           # Kamus kata sensitif multi-bahasa
    ├── apk-builder.ts         # APK builder (manifest fix + mode URL)
    ├── constants.ts           # Embed servers (MovieZone/LK21/Fanzz) & config
    └── ...
```

## Development Lokal
```bash
npm install
npm run dev
# buka http://localhost:3000
```

---

Dibuat dengan sepenuh hati — FanzzTools V2 v0.01
