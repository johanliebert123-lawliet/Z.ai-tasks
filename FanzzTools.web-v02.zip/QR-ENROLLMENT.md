# QR Enrollment — Cara Kerja Pairing Parent Monitor

> Dokumen teknis (pemula-friendly) tentang sistem pairing satu-kali-pakai
> FanzzTools V2.12 Security-Updt.

---

## Format QR

```
FANZZ-PM1|<enrollmentId>|<kode>|<kedaluwarsa-ms>|<HMAC-SHA256>
```

- `kode` = `PM-XXXX-XXXX` (huruf/angka tanpa karakter ambigu — bisa diketik
  manual di companion kalau QR tidak bisa dipindai)
- `kedaluwarsa` = 10 menit sejak dibuat
- `HMAC` = tanda tangan berbasis `APP_SECRET` server — QR palsu langsung
  ditolak dengan pesan "Tanda tangan QR tidak valid"

**QR tidak berisi rahasia permanen apa pun** — tidak ada password, tidak ada
token jangka panjang. Kalau QR ini bocor ke orang asing sekalipun, yang bisa
dilakukan hanyalah *menghubungkan perangkat ke profil anak Anda* — dan itu
tetap butuh anak menekan **Saya Setuju** di layar HP.

## Siklus hidup (state machine)

```
WAITING ──(QR dipindai)──▶ SCANNED ──(anak konfirmasi)──▶ CONNECTED
   │                          │
   │(10 menit lewat)          │(gagal/invalid)
   ▼                          ▼
EXPIRED                    FAILED
   
WAITING ──(orang tua batalkan)──▶ CANCELLED
```

Status perangkat di dashboard: `MENUNGGU ENROLLMENT` → `TERHUBUNG` /
`DIJEDA` / `DICABUT` / `OFFLINE`.

## Token perangkat

Saat anak menekan **Saya Setuju**:

1. Server membuat **token acak 32-byte** (sekali lihat).
2. Yang disimpan di server: **SHA-256 hash** token — bukan tokennya.
3. Companion menyimpan token asli di HP (SharedPreferences / localStorage).
4. Setiap panggilan API companion menyertakan `Authorization: Bearer <token>`.

Akibatnya:
- Database/server **tidak pernah menyimpan token plaintext** → kalau file
  data bocor, token tetap tidak bisa dipakai.
- Token **per perangkat** (bukan global) → dicabut/diputus hanya mempengaruhi
  satu HP.
- Orang tua bisa **Revoke** perangkat dari dashboard; anak bisa **Putuskan
  Koneksi** dari companion — dua arah, sama kuat.

## Keamanan tambahan

| Proteksi | Nilai |
|---|---|
| Rate-limit pembuatan QR | 20/menit per IP (butuh sesi login) |
| Rate-limit konsumsi pairing | 15/menit per IP |
| Kedaluwarsa QR | 10 menit |
| Pemakaian ulang | Ditolak ("Kode sudah dipakai") |
| Tanpa konfirmasi anak | Ditolak (`confirm: true` wajib) |
| Fitur pilihan orang tua | Ikut tercatat di QR (usage/status ON; location/media harus sengaja dinyalakan) |

## Endpoint API terkait

| Endpoint | Sisi | Fungsi |
|---|---|---|
| `POST /api/pm/enrollment` (action: generate/cancel) | orang tua | buat / batalkan QR |
| `GET /api/pm/enrollment?id=` | orang tua | polling status pairing |
| `POST /api/pm/device/enroll` | anak | konsumsi QR/kode → token |
| `POST /api/pm/device/heartbeat` | anak | baterai/jaringan/izin + sinkron fitur |
| `POST /api/pm/device/usage` | anak | upsert statistik agregat |
| `POST /api/pm/device/location` | anak | kirim posisi (fitur ON) |
| `POST /api/pm/device/media` | anak | kirim media pilihan |
| `POST /api/pm/device/disconnect` | anak | putus koneksi sendiri |
| `GET /api/pm/health` | publik | status layanan + kebijakan |
