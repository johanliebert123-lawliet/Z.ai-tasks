# Parent Monitor / Family Cyber Safety — Panduan Lengkap

> **FanzzTools V2.12 Security-Updt** — fitur pengawasan orang tua yang **legal,
> transparan, dan anti-salah-pakai**. Bukan spyware: tidak ada keylogger,
> tidak membaca chat, tidak merekam diam-diam, tidak ada mode siluman.

---

## Ini apa? (untuk pemula)

Parent Monitor membantu **orang tua/wali memantau perangkat anak sendiri**
agar anak terlindung dari risiko digital — sesuai kewajiban pengawasan anak
dalam **UU ITE** dan **UU PDP** (perlindungan data pribadi).

Orang tua melihat dari **web FanzzTools V2** (menu *Parent Monitor*):

- **Statistik pemakaian aplikasi** (durasi agregat per aplikasi per hari)
- **Status perangkat** — baterai, jenis jaringan, waktu sinkron terakhir
- **Lokasi** (opsional — hanya jika diaktifkan DAN anak mengirimkannya)
- **Media** (opsional — hanya foto yang anak pilih sendiri)
- **Alerts & audit log** (aktivitas pengawasan tercatat)

Anak memasang aplikasi kecil bernama **companion** di HP-nya. Companion
**selalu menampilkan** fitur apa saja yang aktif dan punya tombol
**Putuskan Koneksi** yang bisa dipakai kapan saja.

---

## Syarat pemakaian (dipaksa oleh sistem)

| Syarat | Penegakan |
|---|---|
| Konfirmasi **pernyataan wali resmi** sebelum pakai | Onboarding 1x — tanpa ini semua fitur terkunci |
| **Usia anak maksimal 35 tahun** saat profil dibuat | Server menolak tahun lahir yang menghasilkan usia > 35 |
| Anak **dewasa (18+)** → hanya dengan persetujuan tertulisnya | Peringatan wajib tampil; perlindungan UU PDP tetap berlaku |
| Pairing **diketahui anak** | Companion menampilkan layar konfirmasi "Saya Setuju" — tidak ada koneksi diam-diam |
| Hanya **perangkat milik keluarga sendiri** | Isolasi household total — akun lain tidak bisa melihat data keluarga lain |

---

## Cara pakai (5 langkah)

1. **Buka** FanzzTools V2 → sidebar/beranda → **Parent Monitor**.
2. **Onboarding**: baca pernyataan wali, centang, isi tahun lahir Anda →
   *Simpan Pernyataan*.
3. **Tambah profil anak** (nama panggilan + tahun lahir; tahun lahir opsional
   tapi tanpa itu validasi usia 35 tahun tidak jalan).
4. **Hubungkan HP anak** — dua cara:
   - **Cara A — buat APK companion**: tekan *Buat APK Companion* → Anda
     diarahkan ke APK Builder mode *Parent Monitor* → atur nama & icon →
     *Generate* → download APK → install di HP anak → buka → masukkan
     **kode pairing** (tampil setelah APK jadi, atau QR di dashboard).
   - **Cara B — pakai companion yang sudah terinstall**: tekan
     *QR / Kode Pairing* di dashboard → tunjukkan QR ke HP anak / dikirim
     kodenya (`PM-XXXX-XXXX`) → anak mengetiknya di companion.
5. **Pantau dari dashboard**: tab *Keluarga* (profil), *Perangkat* (status,
   baterai, izin), *Aktivitas* (grafik pemakaian per hari/7 hari/30 hari),
   *Privasi* (hapus data kapan saja).

Kode pairing **berlaku 10 menit** dan **sekali pakai**. Kalau kedaluwarsa,
tekan *Muat Ulang QR*.

---

## Data apa yang dikirim & berapa lama disimpan?

| Data | Default | Retensi |
|---|---|---|
| Statistik pemakaian aplikasi (agregat) | ON | 90 hari |
| Status perangkat (baterai/jaringan) | ON | ikut perangkat |
| Lokasi GPS | **OFF** | 30 hari |
| Media (foto pilihan anak) | **OFF** | thumbnail 30 hari, metadata 90 hari |

Semua bisa **dihapus total** kapan saja lewat tab *Privasi → Hapus SEMUA*.

## Yang TIDAK akan pernah dilakukan sistem ini

- ❌ Keylogger / merekam ketikan
- ❌ Membaca isi chat, pesan, email, atau OTP
- ❌ Merekam layar / kamera / mikrofon diam-diam
- ❌ Mengambil seluruh galeri tanpa anak memilih
- ❌ Menyembunyikan diri / mengganti icon diam-diam / mode siluman
- ❌ Menjalankan perintah jarak jauh / shell
- ❌ Melewati izin Android apa pun

---

## Dua jenis companion

| | Companion Web (APK Builder) | Companion Native (Kotlin) |
|---|---|---|
| Cara dapat | Build langsung di web, tanpa komputer khusus | Compile sendiri dari folder `android-companion/` (Android Studio) |
| Pairing kode/QR | ✅ | ✅ (kamera asli) |
| Status perangkat + baterai | ✅ | ✅ |
| Statistik pemakaian aplikasi | ⚠️ terbatas (tanpa akses UsageStatsManager) | ✅ penuh (UsageStatsManager agregat) |
| Sinkron latar belakang | hanya saat app dibuka (60 detik sekali) | ✅ WorkManager tiap ≥15 menit |
| Lokasi & media pilihan | ✅ | ✅ |
| Putuskan koneksi oleh anak | ✅ | ✅ |

Detail teknis: `QR-ENROLLMENT.md`, `APK-BUILDER-PARENT-MONITOR.md`,
`ANDROID-SETUP.md`.

## Kalau ada masalah

Lihat `TROUBLESHOOTING.md` (kompas kiblat, audio Qur'an, downloader,
story, pairing, dll).
