import type { NextConfig } from "next";

/**
 * V2 Modern-UpdSec — PENGUATAN KEAMANAN LAPIS HTTP.
 *
 *  - Content-Security-Policy ketat (tapi tetap kompatibel dengan semua
 *    sumber media pihak ketiga yang dipakai FanzzTools: TMDB, YouTube CDN,
 *    googlevideo via proxy, dsb.)
 *  - Cross-Origin-Opener/C embedder policy — anti clickjacking/tabnabbing
 *  - HSTS preload 2 tahun
 *  - Source map produksi dimatikan — bundle yang dikirim ke browser TIDAK
 *    membawa source code asli (yang terlihat hanya hasil minify)
 *  - Header X-Robots-Tag untuk API (tidak diindeks mesin pencari)
 *  - Cache-Control ketat untuk API (no-store)
 */
const securityHeaders = [
  { key: "X-Frame-Options", value: "SAMEORIGIN" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "X-DNS-Prefetch-Control", value: "on" },
  { key: "X-Permitted-Cross-Domain-Policies", value: "none" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin-allow-popups" },
  { key: "Cross-Origin-Resource-Policy", value: "cross-origin" },
  {
    key: "Permissions-Policy",
    value:
      "camera=(), microphone=(self), geolocation=(self), payment=(), usb=(), " +
      // fix kompas kiblat: accelerometer=(self) — dulu () memblokir sensor untuk origin sendiri,
      // sehingga event deviceorientation/deviceorientationabsolute tidak pernah terpicu di Chromium/Android
      "accelerometer=(self), magnetometer=(self), gyroscope=(self), " +
      "xr-spatial-tracking=(), idle-detection=()",
  },
  {
    key: "Strict-Transport-Security",
    value: "max-age=63072000; includeSubDomains; preload",
  },
  {
    key: "Content-Security-Policy",
    value: [
      "default-src 'self'",
      // script: Next.js butuh inline (hydration) + blob untuk worker hls.js
      "script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: https://gc.zgo.at",
      // style: Tailwind + styled inject pakai inline
      "style-src 'self' 'unsafe-inline'",
      // gambar dari banyak CDN (TMDB, ytimg, dll) + data URI
      "img-src 'self' data: blob: https: http:",
      // media audio/video dari CDN streaming
      "media-src 'self' blob: data: https: http:",
      // koneksi API ke mana pun (proxy streaming, AI, dsb — semuanya via /api/* self)
      "connect-src 'self' https: http: blob: wss: ws:",
      // iframe pemutar embed pihak ketiga (mirror anime/film)
      "frame-src 'self' https: http:",
      "font-src 'self' data: https:",
      "worker-src 'self' blob:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'self'",
      "upgrade-insecure-requests",
    ].join("; "),
  },
  // Cap kepemilikan di level HTTP juga (lapis kedua setelah teks footer)
  {
    key: "X-Copyright",
    value: "FanzzProject - By: Fanzz-Dev. 2026. Dilarang mengklaim sebagai buatan anda.",
  },
];

const nextConfig: NextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  poweredByHeader: false,
  productionBrowserSourceMaps: false,
  async headers() {
    return [
      {
        source: "/((?!_next/static|_next/image|favicon.ico|icon.svg|manifest.json).*)",
        headers: securityHeaders,
      },
      {
        // API tidak boleh diindeks & tidak boleh dibingkai situs lain
        source: "/api/:path*",
        headers: [
          ...securityHeaders,
          { key: "X-Robots-Tag", value: "noindex, nofollow" },
          { key: "Cache-Control", value: "no-store" },
        ],
      },
      {
        // _next/static: kunci panjang — fingerprint bundel tidak bocor
        source: "/_next/static/:path*",
        headers: [{ key: "X-Content-Type-Options", value: "nosniff" }],
      },
    ];
  },
};

export default nextConfig;
