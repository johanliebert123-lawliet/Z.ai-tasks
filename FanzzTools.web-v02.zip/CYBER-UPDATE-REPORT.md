# FanzzTools V2 — CYBER-UPDATE REPORT

Rilis: **FanzzTools.V2.Cyber-Update.zip** (nama paket kerja: `FanzzTools.V2-zuperupdt` lanjutan).
Semua perubahan dibatasi strictly pada 10 poin yang diminta — panel OSINT, file
"wormgpt", tema/UI di luar yang disebut, dan struktur auth/session/security-headers
TIDAK disentuh (satu-satunya pengecualian sesuai arahan: 1 baris Permissions-Policy).

---

## P1 — Foto profil & Story hilang di halaman Profil (tapi ada di header)

**Apa yang diubah** — `src/components/tools/ProfileView.tsx`:
- Dihapus fungsi `muatProfil()` yang tidak pernah dipanggil (dead code).
- `useEffect` pengambil ID publik kini mengisi `fanzzId` **dan** `setAvatar(d.profile?.avatar || null)`
  dari SATU response `/api/social/profile` (tidak ada fetch kedua untuk data yang sama).

**Cara verifikasi manual:**
1. Login → upload foto profil → toast "Foto profil diperbarui".
2. Buka tab profil baru / refresh keras (Ctrl+Shift+R) → foto TETAP tampil di kartu Profil
   DAN di header/sidebar (keduanya kini membaca sumber yang sama).
3. Hapus foto → kedua tempat ikut kosong.

*(teruji live: GET /api/social/profile mengembalikan `fanzzId` + `avatar` bersamaan; upload → persist → GET mengembalikan avatar)*

---

## P2 — Roda Nama: teks berdempetan

**Apa yang diubah** — `src/components/tools/RodaNamaView.tsx`:
- `fontSize` diskrit 3 tingkat → fungsi KONTINU: `Math.max(7, Math.min(13, 130 / n))`.
- Setiap `<text>` kini memakai `textLength` + `lengthAdjust="spacingAndGlyphs"`
  yang dihitung dari chord-width sektor di radius label:
  `chord = 2 * rr * sin(π/n) * 0.85` (rr = r * 0.62).
  Teks hanya DIKOMPRES bila lebar alami (estimasi 0.62em/karakter) melebihi chord —
  tidak pernah direnggangkan, tidak pernah meluber ke sektor tetangga.

**Cara verifikasi manual:** isi roda dengan 3, 10, 20, 30, 50 nama (sertakan nama ±12 karakter,
mis. "Cakrawala") → tidak ada label yang bertabrakan di semua jumlah; putar roda → label ikut rotasi.

*(terverifikasi geometris oleh script `scripts/verify_roda_geometri.js` — 10/10 kasus PASS:
textLength ≤ chord dan tinggi font ≤ jarak busur antar-sektor)*

---

## P3 — Kompas Kiblat mati total meski GPS aktif

**Apa yang diubah** — `next.config.ts` (HANYA baris ini):
- `Permissions-Policy`: `accelerometer=()` → `accelerometer=(self)`
  (kini setara `magnetometer=(self)` dan `gyroscope=(self)`).

**Cara verifikasi manual (HP fisik Android/Chromium):** buka Ruang Ibadah → tab kiblat →
tekan "Aktifkan Kompas + GPS" → putar HP → jarum bergerak real-time. (Sebelum fix, event
`deviceorientation`/`deviceorientationabsolute` tidak pernah terpicu karena sensor diblokir
untuk semua origin termasuk situs sendiri.) Periksa juga di DevTools → Network → dokumen utama →
response header `Permissions-Policy` kini berisi `accelerometer=(self)`.

---

## P4 — Downloader: YouTube 1 resolusi & Instagram gagal

**Apa yang diubah** — `src/app/api/download/route.ts`:
1. `viaInnerTube()` kini membaca `adaptiveFormats` (filter `mimeType` mengandung `video/mp4`,
   diurutkan resolusi tertinggi dulu, maks 8 entri) — 1080p/1440p/2160p yang dulu tak pernah
   muncul sekarang tampil dengan label jujur:
   **"MP4 {res} • video saja — tanpa audio (unduh audio terpisah)"**.
   (Mux server-side ffmpeg sengaja TIDAK dipakai agar aman di deployment tanpa ffmpeg.)
2. Deteksi `isInstagram = /instagram\.com/i.test(url)` ditambahkan. Untuk Instagram, wave-1
   kini memprioritaskan endpoint IG EKSPLISIT `api-faa.my.id/faa/igdl` (terverifikasi hidup,
   mengembalikan array URL) sebelum sxtream AIO; wave-2 fallback varhad AIO.
3. Timeout wave-1 diturunkan: `WAVE1_TIMEOUT = 10000ms` (sxtream) dan 12000ms (igdl &
   InnerTube) — provider lambat gagal cepat, tidak menahan hasil paralel.

**Cara verifikasi manual:**
- YouTube: paste link video → daftar format memuat 360p s.d. 2160p (23 format saat diuji);
  entri 1080p+ berlabel "video saja — tanpa audio".
- Instagram: paste link reel publik → muncul "Video Instagram" yang bisa diunduh (diuji ±6 dtk).
- Kecepatan: total waktu respons ≈ provider tercepat (bukan penjumlahan).

*(teruji live: IG ok/source=faa; YouTube ok 23 format 360p–2160p; parser InnerTube
diverifikasi script `verify_innertube_parser.js` — 7/7 PASS)*

---

## P5 — FanzzStory: musik library tidak bisa dipreview / gagal dipakai

**Apa yang diubah** — `src/components/tools/FanzzStoryView.tsx`:
1. Setiap baris hasil pencarian musik kini punya tombol **preview play/pause**
   (memutar lewat `/api/music/ytmp3?id=...` + satu elemen `<audio>` tersembunyi; auto-segarkan
   sekali via `?fresh=1` bila URL kedaluwarsa). Preview berhenti otomatis saat modal ditutup
   atau lagu dipakai.
2. `pakaiMusikLibrary()` kini SETARA jalur upload manual: audio diambil penuh lewat proxy
   same-origin (bebas CORS) → MIME disadap dari byte header (`sniffAudioMime`) →
   `potongMusik14Detik()` → disimpan sebagai **data URL 14 detik yang mandiri**
   (tidak kedaluwarsa, tidak ditolak story-store). Fallback: data URL utuh bila decode gagal
   (pemutar tetap memotong 14 dtk saat diputar).

**Cara verifikasi manual:** buat story foto → Library → cari lagu → tekan ▶ (terdengar) →
tutup → buka lagi → pilih lagu (proses memotong ±2–5 dtk) → kirim story → putar: musiknya
tepat 14 detik, dan tidak mati walau link YouTube asli kedaluwarsa.

---

## P6 — TermuxView: AI pendamping khusus coding/Termux

**Apa yang ditambah:**
- `TermuxAICompanion` di `src/components/tools/TermuxView.tsx`: tombol bulat mengambang
  (pojok kanan-bawah, hanya ada di halaman Termux) → panel chat PARSIAL
  (`≤380px × ≤64dvh`, tidak menutup tools) dengan riwayat, indikator analisis, dan input bar.
- Infra memakai AI yang sudah ada: `POST /api/ai/chat` dengan **mode baru `termux`**
  (`src/app/api/ai/chat/route.ts`) — system prompt membatasi jawaban HANYA untuk:
  (1) debug error Termux, (2) instal/menjalankan library & tools, (3) penjelasan output error.
  Topik lain ditolak sopan 1–2 kalimat.

**Cara verifikasi manual:** buka Tutorial Termux → tekan bubble hijau → tanya
"pip install einsteinpy error: gcc failed — gimana fixnya?" → jawaban relevan;
tanya "resep ayam geprek" → ditolak sopan dan diarahkan balik ke topik Termux.

---

## P7 — TermuxView: tutorial & pilihan library

**Apa yang diubah/tambah** (`TermuxView.tsx`):
- Label diperbaiki: "Kali Linux" → **KALI NETHUNTER (Rootless)**, dengan langkah instalasi
  resmi kali.org (`install-nethunter-termux` dari GitLab Kali + `nethunter kex`).
  `proot-distro` tetap tersedia sebagai "alternatif ringan".
- 4 kategori library populer baru (semua instruksi terdokumentasi publik, nama paket
  diverifikasi terhadap repo resmi Termux aarch64):
  - **Sains**: `pkg install python python-numpy matplotlib` + venv di Kali + EinsteinPy + scipy/pandas/sympy/jupyter.
  - **Web scraping**: `pip install requests beautifulsoup4` (+ contoh siap-jalan), `pkg install nodejs` + `npm i cheerio`.
  - **Dev tools**: git, neovim (`:Tutor`), nodejs, openssh (+ kunci GitHub), php, ruby.
  - **NetHunter/pentest**: NetHunter rootless, nmap, kali-tools-top10.
- Tab menjadi 7 bagian; subjudul & riwayat diperbarui.

**Cara verifikasi manual:** buka Tutorial Termux → scroll tab → pilih "Web Scraping" →
salin contoh → jalankan di Termux → 10 judul HN tercetak.

---

## P8 — Tools baru: Generator video "hacker prank"

**Apa yang ditambah:**
- `src/components/tools/image-studio/HackerTerminalTool.tsx` + tab **Hacker Prank** di
  ImageStudioView (tepat di sebelah TikTok Quote — Studio Gambar kini 14 generator).
- Terminal PALSU 1080×1920 murni animasi canvas: baris kode bergaya hacker mengetik +
  scroll ala terminal, hujan matrix deterministik di latar, scanline CRT, progress bar
  `[####……]`, HUD target, kartu akhir glitch "AKSES DIBERIKAN".
- Input: nama target (`{TARGET}`), skrip (prefix `[+]`/`[*]`/`[-]` mewarnai baris),
  pesan akhir, kecepatan (0.5–3×). Output: **PNG** (bingkai akhir) + **video WebM**
  (`recordCanvas` — infra studio yang sama dengan BratTool).
- TANPA eksekusi command sungguhan, tanpa koneksi jaringan; watermark
  "PRANK — simulasi hiburan, bukan serangan nyata" tercantum di status bar.

**Cara verifikasi manual:** Studio Gambar → Hacker Prank → lihat pratinjau animasi berjalan
→ "Unduh Video Prank" → hasil WebM ±durasi tertera.

---

## P9 — ChatFakeTool & TiktokQuoteTool: redesain sesuai 3 screenshot

**Apa yang diubah** (semua warna/emoji/layout disalin dari screenshot referensi):
- `ChatFakeTool.tsx` mode **WhatsApp Terang**: reaksi pil ❤️ 😂 😢 👍 😡 🤔; bubble masuk
  PUTIH + bayangan + ekor kiri + **avatar bulat** di sampingnya; bubble keluar LAVENDER
  `#E0D4FC` + ekor kanan (arah ekor lama yang terbalik diperbaiki); latar `#F9FAFB`;
  bar bawah baru: reaksi cepat ❤️😂👍👆 + badge **Streak Pet** + ikon video ungu, pil
  "Kirim pesan..." + ikon kamera kiri + galeri/stiker/mikrofon kanan (mic hijau & klip kertas dihapus).
  Menu konteks tetap persis: Balas / Teruskan / Salin / Terjemahkan / Hapus untuk saya / Laporkan (merah).
  Mode WA iOS Gelap / TikTok Komentar / iMessage tidak berubah (sudah sesuai screenshot 09-16).
- `TiktokQuoteTool.tsx` mode **Chat TikTok DM**: kartu putih membulat di latar `#0F172A`;
  bubble masuk putih + avatar bulat, keluar lavender; **pil reaksi ❤️😂😢👍😡🤔 melayang
  di atas pesan masuk pertama**; input bar persis referensi (reaksi cepat + Streak Pet +
  video ungu + kamera + galeri/stiker/mic — tombol kirim merah dihapus).
  Editor mengikuti screenshot nexus: chip FAST RENDER / MOBILE UI / FAKE TIKTOK CHAT /
  **ONLINE** (fungsional), kolom **USERNAME** (input terang) / **PESAN CHAT** (textarea gelap),
  kartu **FOTO PROFIL** (tombol unggah bulat cyan + "FOTO TERPILIH ✓ / klik lagi untuk ganti").
  Jam otomatis dari perangkat (bukan input manual). Mode Kartu Quote tetap.

**Cara verifikasi manual:** Studio Gambar → Chat → mode WhatsApp Terang (bandingkan dengan
screenshot 09.29.20: bubble, pil reaksi, menu, bar bawah) → TikTok Quote → Chat TikTok DM
(bandingkan dengan screenshot 09.29.30: editor + pratinjau). Field yang bisa diedit:
nama pengirim, isi pesan, foto profil.

---

## P10 — ParentMonitor + android-companion: consent + notifikasi persisten + reliability

**Apa yang diubah:**

*Server* — `src/lib/pm-store.ts` + `src/app/api/pm/device/enroll`:
- **Guard consent baru (CONSENT_NOT_SHOWN)**: `consent:true` kini HANYA diterima bila
  fase 1b (`action:"shown"` — layar disclosure terbuka) sudah dilakukan. Enrollment tanpa
  persetujuan ditolak keras; token tetap tidak pernah terbit sebelum anak menyetujui.
- **Jendela "online" 35 menit** (dulu 10 menit — LEBIH PENDEK dari interval heartbeat
  WorkManager 15 menit; itulah akar status offline palsu). Berlaku di `connectedCount`,
  alert offline, dan `publicDevice.online`.

*Companion (Kotlin native)* — `android-companion/`:
- **Layar disclosure eksplisit** sebelum tombol setuju: APA yang dipantau, OLEH SIAPA,
  KENAPA & BERAPA LAMA (retensi), yang TIDAK pernah dilakukan + checkbox
  "Saya sudah membaca & mengerti" — tombol "Saya Setuju & Hubungkan" baru aktif setelah
  dicentang DAN server mengonfirmasi layar terbuka.
- **Ikon monitoring PERSISTEN**: `MonitoringService.kt` (foreground service tipe
  `dataSync`, notifikasi `setOngoing(true)` — tidak bisa di-swipe diam-diam,
  `START_STICKY`, `stopWithTask=false`) + `BootReceiver.kt` (hidup lagi setelah reboot)
  + izin `POST_NOTIFICATIONS` / `FOREGROUND_SERVICE_DATA_SYNC` / `RECEIVE_BOOT_COMPLETED`.
- **Reliability**: `onResume` → heartbeat langsung tiap aplikasi dibuka;
  SyncWorker menjaga service tetap hidup & menangani token dicabut (berhenti total +
  matikan ikon); dashboard orang tua auto-refresh tiap 60 dtk. Versi 2.14.0.

**Cara verifikasi manual:**
1. Deploy → Parent Monitor → buat pairing → di HP anak: scan → layar Persetujuan Monitoring
   muncul → tombol setuju MATI sampai checkbox dicentang.
2. Coba kirim `consent:true` tanpa membuka layar (mis. curl) → ditolak `CONSENT_NOT_SHOWN`.
3. Setelah setuju → ikon "Monitoring keluarga aktif" muncul di status bar dan tidak bisa
   di-swipe; matikan HP-nyalakan → ikon kembali; swipe aplikasi dari recent → ikon tetap ada.
4. Dashboard: device "online" stabil selama ≤35 menit sejak heartbeat terakhir (bukan flip-flop);
   "Sinkron terakhir" ter-update tiap 15 menit & tiap kali aplikasi anak dibuka.

*(teruji live end-to-end: fase-1 pending → consent tanpa shown DITOLAK → shown → connected
+ token → heartbeat ok → overview online: true, battery 77, charging true)*

---

## Pemeriksaan kualitas (ringkas)

| Pemeriksaan | Hasil |
|---|---|
| `bun run lint` (file yang diubah vs baseline asli) | 9 error / 13 warning — **IDENTIK dengan baseline** (semua error lama bawaan file asli; 0 error baru) |
| `tsc --noEmit` | 44 error = **identik baseline** (0 error tipe baru; `ignoreBuildErrors` memang aktif sejak awal) |
| `bun run build` (Next.js 16.3.5, +`APP_SECRET` uji) | **SUCCES** — compiled + 94/94 halaman |
| Verifikasi geometri roda (P2) | 10/10 PASS |
| Verifikasi parser InnerTube (P4) | 7/7 PASS |
| Smoke test runtime (P1, P4 IG/YT, P10 consent/heartbeat) | SEMUA PASS |

> Catatan build: `APP_SECRET` wajib di production (fail-fast bawaan, tidak diubah).
> Generate: `openssl rand -hex 32` — lihat `.env.example`.
