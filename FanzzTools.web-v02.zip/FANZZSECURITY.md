# FANZZSECURITY — Security Center

**FanzzSecurity** adalah pusat keamanan FanzzTools V2 (menu utama:
*FanzzSecurity* — badge BARU). Desain: grid heksagonal gelap dengan aksen
cyan/blue — nuansa "cyber defense", bukan template dashboard generik.
Musik ambient whitehat opsional (tombol kanan-atas, mulai hanya setelah
interaksi pengguna — kepatuhan autoplay browser).

## 12 Alat Keamanan

| # | Alat | Jenis | Lokasi |
|---|------|-------|--------|
| 1 | Pindai File | heuristik statis lokal (hash, magic-byte, zip-slip, APK) | langsung di panel |
| 2 | Pindai Web / URL | 18+ pemeriksaan header/TLS pasif + skor + grade | lewat Cek Keamanan Website |
| 3 | Email & Breach | email sementara + OTP; status breach: butuh API key (jujur) | lewat Email Trial |
| 4 | NIK Validator | validasi format + wilayah (bukan database rahasia) | lewat OSINT |
| 5 | WHOIS / DNS / Domain | RDAP real-time, A/MX/TXT/NS, DMARC, SPF | lewat OSINT |
| 6 | IP Intelligence | ASN, ISP, negara, kota aproksimasi (ipwho.is) | lewat OSINT |
| 7 | Phone Intelligence | validasi nomor + operator (bukan GPS) | lewat OSINT |
| 8 | Metadata Gambar | EXIF: kamera, tanggal, GPS bila ada | langsung di panel |
| 9 | Analisis APK | struktur manifest, DEX, tanda tangan, native lib | Pindai File dengan file .apk |
| 10 | HTTP Security / TLS | header, sertifikat, kebijakan cookie | lewat Cek Keamanan Website |
| 11 | Device Security Advisor | hardening Android/iOS/Windows/macOS/Linux | langsung di panel |
| 12 | Hash / IOC Analyzer | hash file, JWT decode, Base64, ekstraksi IOC | langsung di panel |

Tiga tab panel: **Ringkasan** (postur keamanan + status), **Security
Tools** (grid 12 alat), **Status Keamanan** (indikator TLS sesi, sesi
login, kesehatan fitur).

## Kejujuran hasil (aturan mutlak)

- Tanpa engine reputasi (VirusTotal dsb.) hasil file TIDAK pernah
  "SAFE/MALICIOUS" — hanya `CLEAN_HEURISTIC` / `SUSPICIOUS` /
  `HEURISTIC_ONLY` / `UNSCANNABLE`.
- Breach email ditandai "memerlukan API key yang belum dikonfigurasi"
  bila belum ada kunci.
- Tangkapan layar situs butuh `SCREENSHOTONE_ACCESS_KEY`; tanpa kunci →
  pesan konfigurasi (lihat SCREENSHOTONE-SETUP.md).

Detail mesin: `SECURITY-SCANNER.md`. Daftar sumber API: `API-SOURCES.md`.

## Musuh yang DITES tidak dilakukan

Tidak ada keylogger, tidak ada intersep SMS/OTP, tidak ada akses galeri
tersembunyi, tidak ada mode stealth. FanzzSecurity adalah alat
pembelaan (white-hat), bukan senjata serangan — konsisten dengan
spesifikasi pemilik: *SECURITY MUST NEVER BE TRADED FOR CONVENIENCE*.
