# PRIVACY.md — Privasi Data Parent Monitor

> Ringkasan ramah-pemula. Versi lengkap teknis: `SECURITY.md`.

## Siapa yang datanya diproses?

1. **Orang tua/wali** (pemilik akun FanzzTools) — data akun & aktivitas
   pengawasan (audit log).
2. **Anak di bawah pengawasan** — data dari perangkat yang **diketahui dan
   disetujuinya** (layar "Saya Setuju" saat pairing).

## Data anak yang diproses

| Data | Kapan dikumpulkan | Retensi | Default |
|---|---|---|---|
| Statistik pemakaian aplikasi (nama paket, durasi agregat, jumlah buka) | Sinkron terjadwal (native, ≥15 mnt) | 90 hari | ON (web: terbatas) |
| Status perangkat (baterai, jenis jaringan, model, versi) | Heartbeat | ikut umur perangkat | ON |
| Lokasi GPS | **Hanya** saat fitur ON dan anak menekan tombol kirim | 30 hari | **OFF** |
| Thumbnail foto pilihan | **Hanya** saat fitur ON dan anak memilih foto | 30 hari | **OFF** |

## Hak anak (by design, tidak bisa dimatikan orang tua)

- Melihat **fitur apa saja yang aktif** — selalu tampil di companion.
- **Putuskan koneksi** dari companion — kapan saja, tanpa izin orang tua.
- Mencabut izin Usage Access / lokasi / kamera dari Settings Android —
  companion berhenti mengirim data terkait (tidak ada bypass).

## Hak orang tua

- Menghapus data per kategori atau **SEMUA** data keluarga (Privacy Center).
- Mencabut perangkat (revoke) — token mati seketika.

## Yang tidak pernah dikumpulkan

Ketikan (keylogger), isi chat/pesan/OTP, isi email, rekaman layar/kamera/
mikrofon, seluruh isi galeri, riwayat panggilan/SMS/kontak.

## Dasar pemrosesan

Pengawasan wali sah atas anak (perlindungan anak — UU ITE & UU PDP),
dengan batas usia profil anak **maksimal 35 tahun** dan peringatan
persetujuan tertulis untuk anak 18+.

## Hilangkan semua data

Dashboard Parent Monitor → tab **Privasi** → *Hapus SEMUA data monitoring*.
Data perangkat terhapus permanen dari penyimpanan server (tidak ada backup
terpisah pada arsitektur file-JSON ini).
