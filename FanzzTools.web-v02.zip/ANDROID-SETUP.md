# ANDROID-SETUP — Companion Native (Kotlin)

> Panduan build aplikasi companion **native** untuk Parent Monitor.
> Pilihan ini memberi **statistik pemakaian aplikasi agregat** via
> UsageStatsManager — yang tidak bisa dilakukan companion web.

---

## Dua pilihan companion

| | Web (APK Builder) | Native (proyek ini) |
|---|---|---|
| Butuh Android Studio? | ❌ | ✅ |
| Waktu | ±2 menit | ±10 menit (sekali setup) |
| Statistik pemakaian penuh | ⚠️ terbatas | ✅ |
| Sinkron otomatis | hanya saat dibuka | ✅ tiap ≥15 menit (WorkManager) |

Proyek sumber ada di folder **`android-companion/`** di root repo.

## Cara build

1. Install **Android Studio** (versi Koala 2024.1.1 atau lebih baru).
2. **File → Open** → pilih folder `android-companion`.
3. Tunggu **Gradle sync** selesai (butuh internet, ±5 menit pertama kali).
4. Buka `MainActivity.kt` → ubah baris:
   ```kotlin
   const val DEFAULT_SERVER = "https://fanzztools.example.com"
   ```
   menjadi URL deployment FanzzTools Anda.
5. **Build → Generate Signed Bundle / APK → APK** → buat keystore sendiri
   (simpan baik-baik; keystore berbeda = aplikasi tidak bisa di-update
   tanpa uninstall).
6. Transfer APK ke HP anak (WA/kabel/drive) → install → buka.

## Setelah install di HP anak

1. **Mulai Hubungkan** → pindai QR dari dashboard (kamera) atau ketik
   `PM-XXXX-XXXX`.
2. Baca layar konfirmasi → **Saya Setuju & Hubungkan**.
3. Companion meminta **Usage Access** (izin khusus Android):
   Settings → Special app access → Usage access → aktifkan *Family Safety*.
   - Izin ini bisa anak **cabut kapan saja** dari Settings yang sama —
     companion berhenti mengirim statistik begitu izin dicabut (tidak ada
     bypass).
4. Selesai — data mulai muncul di dashboard dalam ±15 menit.

## Yang dilakukan companion native di latar belakang

- **WorkManager** menjadwalkan sinkronisasi **minimum 15 menit sekali**
  (batas keras Android — tidak ada mode "real-time").
- Setiap sinkron mengirim: heartbeat (baterai/jaringan/izin) + **statistik
  agregat** (total durasi + aplikasi per hari) dari UsageStatsManager.
- Gagal kirim → retry **exponential backoff** (30 detik → maks 5 jam),
  hanya saat ada koneksi.

## Yang TIDAK diminta/dilakukan

- ❌ Izin SMS / kontak / log panggilan / mikrofon / galeri penuh
- ❌ Membaca isi notifikasi atau teks apa pun
- ❌ Merekam layar / lokasi diam-diam (lokasi hanya saat tombol ditekan)
- ❌ Icon tersembunyi / uninstall-protection / anti-Play-Protecct

## Masalah umum

| Gejala | Sebab | Solusi |
|---|---|---|
| Gradle sync gagal | versi AGP/JDK lama | pakai Android Studio terbaru + JDK 17 |
| `DEFAULT_SERVER` salah → "Server tidak terjangkau" | URL belum diganti | ubah lalu rebuild |
| Statistik kosong | Usage Access belum aktif | Settings → Usage access → aktifkan |
| "QR bukan QR FanzzTools" | memindai QR lain | scan QR dari dashboard Parent Monitor |
