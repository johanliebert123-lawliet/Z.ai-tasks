# FanzzTools V2 — Modern-UpdSec

Dokumen upgrade keamanan + fitur versi **Modern-UpdSec** (hasil akhir: `FanzzTools.V2.Modern-UpdSec.zip`).

---

## ⚠️ WAJIB DIBACA DULU — 1 LANGKAH SEBELUM DEPLOY

### Celah #1 yang SUDAH diperbaiki: default secret JWT
Versi lama diam-diam memakai secret hardcoded kalau `APP_SECRET` tidak di-set — siapa pun yang pernah melihat source bisa memalsukan sesi user mana pun.

**Sekarang:** production TANPA `APP_SECRET` = **deploy gagal cepat** (fail-fast), bukan diam-diam memakai secret bocor.

**Yang harus kamu lakukan SEKALI di Vercel:**
1. Jalankan di komputer: `openssl rand -hex 32`
2. Vercel → Project FanzzTools → **Settings → Environment Variables**
3. Tambah: Name = `APP_SECRET`, Value = hasil openssl (64 karakter), Environment = Production + Preview + Development
4. **Redeploy.**

Tanpa langkah ini deploy akan error dengan pesan `[FanzzTools] APP_SECRET WAJIB di-set di production!` — itu SENGAJA, demi keamanan.

---

## 🔐 Ringkasan Penguatan Keamanan

| # | Perbaikan | Detail |
|---|-----------|--------|
| 1 | **JWT secret fail-fast** | Default secret DIHAPUS. Dev = secret acak per-proses; production tanpa env = gagal build. Claim JWT ditambah `aud` + `alg` dikunci HS256. |
| 2 | **Password min 8 karakter** | Dari 6 → 8 (register + login + hint UI). |
| 3 | **bcrypt 12 rounds** | Dari 10 → 12 (≈100x lebih lambat di-brute-force). Kompatibel dengan hash lama $10$. |
| 4 | **Anti brute-force berlapis** | Rate-limit login diperketat 15→12/5menit per IP + **8/15menit per email** (akun dikunci sementara). Pesan error generik (tidak membocorkan email terdaftar). |
| 5 | **SSRF guard LENGKAP** | Semua proxy/scraper kini blokir: 172.16.0.0/12, 100.64.0.0/10 (CGNAT), 169.254.0.0/16, multicast, TEST-NET, IPv6 ULA/link-local, IP bentuk desimal/heksa. **Redirect diikuti manual + host di-revalidasi tiap lompatan** (anti DNS-rebinding). |
| 6 | **CSP + header ketat** | Content-Security-Policy, COOP, CORP, Permissions-Policy diperluas, X-Permitted-Cross-Domain-Policies, HSTS preload — di `next.config.ts` + `vercel.json` (lapis ganda). |
| 7 | **Rate-limit memory hygiene** | Sweeper periodik + hard cap 50.000 key — Map tidak bisa lagi dibengkakkan untuk DoS memori. |
| 8 | **SecurityGuard klien diperkuat** | Blokir F12 / Ctrl+Shift+I/J/C / Ctrl+U / Ctrl+S / Ctrl+P di production, anti-drag gambar/media, anti-select elemen struktural (escape hatch `data-fanzz-selectable="1"` untuk area teks yang memang perlu disalin), deteksi DevTools + watermark anti-klaim berkala. |
| 9 | **Source map tetap mati** | `productionBrowserSourceMaps: false` — yang terkirim hanya bundle minified. |
| 10 | **Validasi input lebih ketat** | URL dengan kredensial embed ditolak; panjang token/cookie dibatasi. |

**Catatan jujur (tetap berlaku):** tidak ada web yang 100% anti-inspect — HTML/CSS/JS pada akhirnya harus dikirim ke browser. Yang dilindungi penuh adalah logika sensitif & kunci (tetap di server, di belakang sesi login + rate-limit). Lapisan klien di sini menaikkan hambatan, bukan mustahilkan.

## 🛠️ Perbaikan Bug

| Bug | Akar masalah | Fix |
|-----|--------------|-----|
| **Brat: atur jarak spasi tidak berfungsi** | Fungsi bungkus teks memecah dengan `/\s+/` lalu menggabung ulang dengan SATU spasi — spasi ganda hancur sejak awal | Separator disimpan sebagai variabel & dipakai saat menggabung baris |
| **Anime: pindah server tidak bisa dipencet** | Fetch resolve tanpa timeout bisa menggantung; dua resolve berlomba saling menimpa | AbortController 25 detik + token anti-race + indikator loading di tombol |
| **Musik: delay banget / gagal memuat** | savetube cascade 3 CDN × 9 detik = 27 detik; cache client TTL 24 jam untuk URL presigned 90 menit | 3 CDN savetube sekarang PARALEL; cache client TTL per-sumber (googlevideo 5 jam / CDN 70 menit) |
| **©FanzzTools bubble/pop-up menghalangi** | Cap copyright dirender fixed floating | Menjadi teks statis di paling bawah footer beranda |

## ✨ Fitur & Tools Baru

1. **The All-Tools** — halaman ke-5 (nav bawah) berisi SEMUA tools + **pencarian** + 6 kartu Coming Soon (Generator Prompt AI, URL to ZIP, Jailbreak Prompt AI, Ransomware 30+ pantau anak, Stream Live & Playlist Olahraga, Check WiFi Sekitar).
2. **Ambil Source Code Web** — ambil HTML/CSS/JS halaman publik (legal, seperti Ctrl+U): ringkasan struktur, inline style/script, daftar aset, unduh 1 file HTML.
3. **Cek Keamanan Website** — 18+ pemeriksaan pasif (HTTPS/HSTS, CSP, cookie flags, clickjacking, mixed content, CORS reflektif, banner versi, security.txt…), skor 0-100 grade A+–F + rekomendasi per temuan.
4. **Download Minecraft** — scrape MCPELife: 8 kategori, pencarian, arsip versi, server Bedrock, panduan, resolve link unduhan langsung (proxy sesi login).
5. **Ruang Ibadah** — jadwal sholat Kemenag per kota/GPS, **kompas kiblat real-time**, hitung mundur sholat berikutnya, rakaat wajib + 14 sunnah, saran surah, **bacaan sholat lengkap Arab/Latin/Arti (bisa disalin)**, + ibadah semua agama (Protestan+aliran, Katolik+ritus, Ortodoks+aliran, Hindu, Buddha, Konghucu, dll) dengan doa harian & tombol Tanya AI.
6. **Qur'an Digital** — 114 surah (Arab Utsmani, latin, terjemahan Kemenag, **tafsir**), **21 imam** audio per-ayat + 5 qari full-surah, putar berurutan, skip ayat, waktu berjalan, semua bisa disalin.
7. **Debat Filosofis AI** — untuk ateis/agnostik/siapa pun: **test psikologi 5 soal wajib** (profil ditampilkan), **8 level** (Awam→SuperHard), timer durasi, **juri AI** menentukan pemenang + skor + pihak unggul/melemah, **unduh hasil PNG/JPG/PDF dengan border**.
8. **FanzzStory** — status ala WA: **teks (10 gradasi) atau video+caption**, aktif **22 jam** lalu hilang otomatis, **maks 5 per user**, global (semua user lihat), **like + komentar** (tombol komentar kecil di pojok kanan atas), pemilik bisa lihat **siapa saja penonton**, progres bar per story.
9. **Foto profil user** — upload avatar (dikompres 256px di client), tampil di chat, story, sidebar & header.
10. **Jam real-time** detik berjalan di header mobile & sidebar desktop.
11. **iPhone WA Chat Generator (UPGRADE)** — kini persis WhatsApp iOS dark: header avatar **(bisa upload foto)** + nama + online, gelembung #202C33/#005C4B berekor, waktu + **centang biru ganda**, chip tanggal, input bar + tombol mic, wallpaper chat opsional.
12. **TikTok Chat Generator (UPGRADE)** — mode Chat DM TikTok: kartu putih, header **foto profil (bisa upload)** + nama tebal + menu titik tiga, gelembung abu/lavender, status bar iPhone, input bar TikTok.
13. **Hapus**: fitur unban WA (sesuai permintaan), disclaimer-disclaimer teks.

## 🚀 Deploy

```bash
# 1. Set APP_SECRET di Vercel (WAJIB — lihat atas)
# 2. Deploy biasa
```

Environment variables:
| Nama | Wajib | Keterangan |
|------|-------|------------|
| `APP_SECRET` | ✅ PRODUCTION | `openssl rand -hex 32` |
| `BCRYPT_ROUNDS` | ⬜ | default 12 (10–14) |
