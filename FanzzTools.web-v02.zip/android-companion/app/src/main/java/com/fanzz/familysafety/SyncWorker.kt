package com.fanzz.familysafety

import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.BatteryManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Pekerja sinkronisasi latar belakang (WorkManager).
 *
 * KEJUJURAN DESAIN (spesifikasi §44):
 *  - Periode MINIMAL 15 menit (batas WorkManager) — TIDAK ada pelacakan real-time.
 *  - Data yang dikirim: statistik pemakaian AGREGAT per aplikasi
 *    (total durasi + jumlah buka) dari UsageStatsManager — bukan isi aktivitas,
 *    bukan notifikasi, bukan teks apa pun.
 *  - Retry: exponential backoff (30 dtk → 5 jam) dengan constraint jaringan.
 *  - Kalau izin PACKAGE_USAGE_STATS dicabut anak lewat Settings, worker
 *    melaporkan "permission revoked" dan TIDAK mengirim apa pun.
 */
object UsageCollector {

    fun hasUsagePermission(ctx: Context): Boolean {
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val stats = usm.queryAndAggregateUsageEvents(now - 60_000, now)
        // kalau permission tidak ada, queryAndAggregateUsageEvents mengembalikan
        // hasil kosong/stale — verifikasi tambahan lewat AppOps di bawah
        return checkAppOps(ctx) && stats != null
    }

    private fun checkAppOps(ctx: Context): Boolean {
        return try {
            val pm = ctx.packageManager
            val info = pm.getApplicationInfo(ctx.packageName, 0)
            val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
            val mode = appOps.checkOpNoThrow(
                android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                info.uid,
                ctx.packageName
            )
            mode == android.app.AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    /** Statistik agregat HARI INI per paket — durasi total & jumlah event foreground. */
    fun todayEntries(ctx: Context): JSONArray {
        if (!checkAppOps(ctx)) return JSONArray() // izin dicabut → jangan kirim apa pun

        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        val now = System.currentTimeMillis()

        val stats = usm.queryAndAggregateUsageStats(start, now)
        val out = JSONArray()
        for ((pkg, s) in stats) {
            val ms = s.totalTimeInForeground
            if (ms < 30_000) continue // < 30 dtk dihitung noise
            val app = try {
                ctx.packageManager.getApplicationLabel(
                    ctx.packageManager.getApplicationInfo(pkg, 0)
                ).toString()
            } catch (_: Exception) {
                pkg
            }
            out.put(
                JSONObject()
                    .put("pkg", pkg)
                    .put("app", app)
                    .put("usageMs", ms)
                    .put("launches", 0) // jumlah buka tidak diekspos UsageStats agregat
            )
        }
        return out
    }

    fun todayDate(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Calendar.getInstance().time)

    /** Status baterai untuk heartbeat. */
    fun battery(ctx: Context): Pair<Int, Boolean>? {
        return try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val charging = bm.isCharging
            if (level >= 0) level to charging else null
        } catch (_: Exception) {
            null
        }
    }

    /** Label jaringan kasar (tanpa izin READ_PHONE_STATE). */
    fun networkLabel(ctx: Context): String {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "offline"
            when {
                !caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) -> "offline"
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_CELLULAR) -> "seluler"
                else -> "lainnya"
            }
        } catch (_: Exception) {
            "tidak diketahui"
        }
    }

    /** Status izin untuk heartbeat (transparan ke orang tua). */
    fun permissionsJson(ctx: Context): JSONObject {
        return JSONObject()
            .put("usage", if (checkAppOps(ctx)) "granted" else "revoked")
            .put("location", "runtime")
            .put("media", "photo-picker")
            .put("notifications", "n/a")
    }
}

/**
 * Worker sinkronisasi terjadwal — dipasang dari MainActivity saat pairing.
 * PeriodicWorkRequest MINIMAL 15 menit (kebijakan WorkManager & spesifikasi).
 */
class SyncWorker(ctx: Context, params: androidx.work.WorkerParameters) :
    androidx.work.CoroutineWorker(ctx, params) {

    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        if (!PmStore.isPaired(applicationContext)) {
            return androidx.work.ListenableWorker.Result.success() // sudah diputus — berhenti rapi
        }
        return try {
            val ctx = applicationContext
            // Cyber-Update #10b: pastikan ikon monitoring persisten tetap hidup
            // (aman dipanggil dari worker — dibungkus try-catch di dalam)
            MonitoringService.ensureRunning(ctx)
            val bat = UsageCollector.battery(ctx)
            val hb = PmApi.heartbeat(
                ctx,
                bat?.first,
                bat?.second,
                UsageCollector.networkLabel(ctx),
                UsageCollector.permissionsJson(ctx)
            )
            if (hb.optBoolean("ok")) {
                hb.optJSONObject("features")?.let { PmStore.updateFeatures(ctx, it) }
                // kirim usage hanya bila fitur aktif & izin masih diberikan
                val feats = PmStore.features(ctx)
                if (feats.optBoolean("usage")) {
                    val entries = UsageCollector.todayEntries(ctx)
                    if (entries.length() > 0) {
                        PmApi.usage(ctx, UsageCollector.todayDate(), entries)
                    }
                }
                androidx.work.ListenableWorker.Result.success()
            } else {
                // Cyber-Update #10c: token dicabut di sisi server → berhenti total
                // (matikan ikon monitoring + hapus pairing) supaya dashboard
                // ortu dan HP anak selalu konsisten
                if (hb.optString("error", "").contains("dicabut", true)) {
                    MonitoringService.stop(ctx)
                    PmStore.clear(ctx)
                    androidx.work.ListenableWorker.Result.success()
                } else {
                    androidx.work.ListenableWorker.Result.retry()
                }
            }
        } catch (_: Exception) {
            androidx.work.ListenableWorker.Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "fanzz_pm_sync"

        /** Pasang jadwal: tiap 15 menit (batas minimal WorkManager), backoff
         *  eksponensial, butuh jaringan. Cyber-Update #10c: hasil sinkron
         *  dipakai server dengan jendela "online" 35 menit — perangkat sehat
         *  tidak lagi tampak offline bolak-balik. */
        fun schedule(ctx: Context) {
            val req = androidx.work.PeriodicWorkRequestBuilder<SyncWorker>(15, java.util.concurrent.TimeUnit.MINUTES)
                .setConstraints(
                    androidx.work.Constraints.Builder()
                        .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                        .build()
                )
                .setBackoffCriteria(
                    androidx.work.BackoffPolicy.EXPONENTIAL,
                    30, java.util.concurrent.TimeUnit.SECONDS
                )
                .build()
            androidx.work.WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork(WORK_NAME, androidx.work.ExistingPeriodicWorkPolicy.UPDATE, req)
        }

        fun cancel(ctx: Context) {
            androidx.work.WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NAME)
        }
    }
}
