package com.fanzz.familysafety

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import kotlin.concurrent.thread

/**
 * Companion Parent Monitor — layar utama (transparan by design).
 *
 * Alur (Cyber-Update #10): Sambutan → Hubungkan (kode/QR) → DISCLOSURE
 * EKSPLISIT (apa yang dipantau, oleh siapa, kenapa) → centang "saya sudah
 * mengerti" → baru tombol "Saya Setuju & Hubungkan" aktif → Status.
 * Setelah disetujui: ikon monitoring PERSISTEN menyala (foreground service)
 * dan TIDAK bisa di-dismiss diam-diam — hanya mati saat koneksi diputus.
 * Layar Status SELALU menampilkan fitur monitoring aktif + tombol Putuskan.
 * Tidak ada layar tersembunyi / mode siluman.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(40))
        }
        scroll.addView(root, ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        setContentView(scroll)

        if (PmStore.isPaired(this)) showStatus() else showWelcome()
    }

    /** Cyber-Update #10c: tiap kali aplikasi dibuka → pastikan ikon monitoring
     *  tetap hidup + kirim heartbeat langsung (last-seen di dashboard orang
     *  tua akurat, bukan menunggu siklus 15 menit berikutnya). */
    override fun onResume() {
        super.onResume()
        if (PmStore.isPaired(this) && statusPill != null) {
            MonitoringService.ensureRunning(this)
            syncNow()
        }
    }

    /* ================= LAYAR SAMBUTAN ================= */

    private fun showWelcome() {
        root.removeAllViews()
        title2("Family Safety")
        para("Aplikasi keamanan keluarga — menghubungkan perangkat ini dengan akun orang tua/wali " +
            "supaya mereka bisa membantu menjaga keamanan digital kamu.")
        pill(listOf("TRANSPARAN", "BISA DIPUTUS KAPAN SAAT", "TANPA KEYLOGGER", "TANPA BACA CHAT"))
        cardTitle("Yang dilaporkan aplikasi ini")
        para("- Status perangkat: baterai, jaringan, waktu sinkron\n" +
            "- Statistik pemakaian aplikasi (agregat, native)\n" +
            "- Lokasi GPS — hanya jika fitur aktif DAN kamu menekan tombol kirim\n" +
            "- Foto — hanya yang kamu pilih sendiri")
        bigButton("Mulai Hubungkan") { showConnect() }
        ghostButton("Privasi & Izin") { showAbout(fromStatus = false) }
    }

    /* ================= LAYAR HUBUNGKAN ================= */

    private fun showConnect() {
        root.removeAllViews()
        title2("Hubungkan ke keluarga")
        para("Minta orang tua membuka FanzzTools V2 → Parent Monitor, lalu tekan " +
            "QR / Kode Pairing. Kode berlaku 10 menit dan hanya sekali pakai.")

        cardTitle("Masukkan kode pairing")
        val input = EditText(this).apply {
            hint = "PM-XXXX-XXXX atau tempel FANZZ-PM1|…"
            filters = arrayOf(android.text.InputFilter.AllCaps())
            gravity = Gravity.CENTER
        }
        root.addView(input, lp())
        bigButton("Hubungkan dengan Kode") {
            val code = input.text.toString().trim().uppercase()
            // zuperupdt #7: teks QR penuh (FANZZ-PM1|...) hasil salin-tempel
            // dari pemindai QR luar diparse LANGSUNG — tidak dianggap "acak".
            if (code.startsWith("FANZZ-PM1|")) {
                pair(code, null)
            } else if (!Regex("^PM-[A-Z0-9]{4}-[A-Z0-9]{4}$").matches(code)) {
                toast("Format kode: PM-XXXX-XXXX — atau tempel teks QR FANZZ-PM1|…")
            } else {
                pair(null, code)
            }
        }

        cardTitle("atau pindai QR")
        bigButton("Pindai QR dengan Kamera") {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) {
                startActivityForResult(Intent(this, QrScanActivity::class.java), REQ_QR)
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQ_CAM)
            }
        }
        ghostButton("Kembali") { showWelcome() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CAM && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startActivityForResult(Intent(this, QrScanActivity::class.java), REQ_QR)
        } else if (requestCode == REQ_CAM) {
            toast("Izin kamera ditolak — pakai kode manual (hasilnya sama).")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_QR && resultCode == RESULT_OK) {
            val payload = data?.getStringExtra("payload")
            if (!payload.isNullOrEmpty()) {
                if (!payload.startsWith("FANZZ-PM1|")) {
                    toast("QR bukan QR pairing FanzzTools Parent Monitor.")
                } else {
                    pair(payload, null)
                }
            }
        }
    }

    /* ================= PAIRING 2-FASE + KONFIRMASI (zuperupdt #7 + Cyber-Update #10) ================= */

    private var pending: JSONObject? = null // hasil fase 1: deviceId + consentTicket (TANPA token)
    private var shownAck = false            // fase 1b "shown" berhasil → server mengizinkan consent

    private fun pair(qrPayload: String?, code: String?) {
        toast("Menghubungi server…")
        val model = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        thread {
            val serverUrl = PmStore.serverUrl(this).ifEmpty { DEFAULT_SERVER }
            // FASE 1: scan saja — perangkat PENDING_CONSENT, tanpa token
            val d = PmApi.enrollPhase1(serverUrl, qrPayload, code, model, Build.VERSION.RELEASE ?: "")
            runOnUiThread {
                if (d.optBoolean("ok")) {
                    pending = d
                    shownAck = false
                    showConfirm(d)
                    // FASE 1b: tandai layar persetujuan terbuka (dashboard ortu
                    // melihat CONSENT_REQUIRED secara live; server MEWAJIBKAN
                    // ini sebelum menerima consent=true)
                    val dd = d
                    thread {
                        val m = PmApi.markConsentShown(serverUrl, dd.optString("deviceId"), dd.optString("consentTicket"))
                        if (m.optBoolean("ok")) shownAck = true
                    }
                } else {
                    // galat terstruktur: pesan manusia + kode mesin
                    val code = d.optString("error", "")
                    val msg = d.optString("message", d.optString("error", ""))
                    toast(if (code.isNotEmpty()) "$msg [$code]" else (msg.ifEmpty { "Pairing gagal — kode mungkin salah/kedaluwarsa." }))
                }
            }
        }
    }

    /** Cyber-Update #10a: DISCLOSURE EKSPLISIT sebelum tombol setuju bisa
     *  ditekan — apa yang dipantau, oleh siapa, kenapa, berapa lama, dan
     *  yang TIDAK pernah dilakukan. Tombol "Saya Setuju" baru AKTIF setelah
     *  anak mencentang "saya sudah membaca & mengerti". */
    private fun showConfirm(d: JSONObject) {
        root.removeAllViews()
        title2("Persetujuan Monitoring")
        para("Perangkat ini BELUM terhubung. Hubungan baru terjadi setelah kamu membaca penjelasan di bawah, mencentang persetujuan, lalu menekan \u201cSaya Setuju & Hubungkan\u201d.")

        val feats = d.optJSONObject("features") ?: JSONObject()

        cardTitle("APA yang akan dipantau")
        para("- Status perangkat: baterai, jaringan, waktu sinkron terakhir\n" +
            "- Statistik pemakaian aplikasi (total durasi & jumlah buka saja)" +
            (if (feats.optBoolean("usage")) " — AKTIF" else " — NONAKTIF") + "\n" +
            "- Lokasi GPS" + (if (feats.optBoolean("location")) " — AKTIF" else " — hanya saat kamu menekan tombol kirim") + "\n" +
            "- Foto" + (if (feats.optBoolean("media")) " — AKTIF" else " — hanya yang kamu pilih sendiri"))

        cardTitle("OLEH SIAPA")
        kv("Keluarga", d.optString("householdName", "-"))
        kv("Profil anak", d.optString("childNickname", "-"))
        kv("Perangkat", d.optString("deviceLabel", "-"))

        cardTitle("KENAPA & BERAPA LAMA")
        para("Tujuannya membantu orang tua/wali menjaga keamanan digitalmu — " +
            "bukan mengintip isi percakapan. Data disimpan terbatas: statistik pemakaian 90 hari, " +
            "lokasi 30 hari, media 30–90 hari. Kamu bisa memutus koneksi kapan saja dari aplikasi ini.")

        cardTitle("Yang TIDAK pernah dilakukan")
        para("- Membaca isi chat / pesan apa pun\n" +
            "- Mencatat ketikan (keylogger) atau OTP\n" +
            "- Merekam layar / kamera / mikrofon\n" +
            "- Menyembunyikan diri — ikon monitoring TETAP tampil di status bar selama terhubung")

        // checkbox persetujuan — tombol setuju baru aktif setelah dicentang
        val check = CheckBox(this).apply {
            text = "Saya sudah membaca & mengerti penjelasan di atas"
            textSize = 13f
            setTextColor(0xFFE8ECF8.toInt())
        }
        root.addView(check, lp())

        val agreeBtn = Button(this).apply {
            text = "Saya Setuju & Hubungkan"
            textSize = 14f
            isAllCaps = false
            background.setTint(0xFF6366F1.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            isEnabled = false
            alpha = 0.4f
            setOnClickListener {
                if (!check.isChecked) return@setOnClickListener
                doAgree()
            }
        }
        root.addView(agreeBtn, lp())
        check.setOnCheckedChangeListener { _, checked ->
            agreeBtn.isEnabled = checked
            agreeBtn.alpha = if (checked) 1f else 0.4f
        }

        dangerButton("Batalkan (kode jadi tidak berlaku)") {
            val dd = pending
            pending = null
            if (dd != null) {
                thread {
                    val serverUrl = PmStore.serverUrl(this).ifEmpty { DEFAULT_SERVER }
                    // FASE 2: consent=false → REJECTED, kode mati
                    PmApi.enrollPhase2(serverUrl, dd.optString("deviceId"), dd.optString("consentTicket"), false)
                }
            }
            showConnect()
        }
    }

    private fun doAgree() {
        val dd = pending ?: return
        toast("Mengirim persetujuan…")
        thread {
            val serverUrl = PmStore.serverUrl(this).ifEmpty { DEFAULT_SERVER }
            // server menolak consent bila layar disclosure belum ditandai
            // terbuka (CONSENT_NOT_SHOWN) — pastikan fase 1b sukses dulu
            if (!shownAck) {
                val m = PmApi.markConsentShown(serverUrl, dd.optString("deviceId"), dd.optString("consentTicket"))
                shownAck = m.optBoolean("ok")
            }
            if (!shownAck) {
                runOnUiThread {
                    toast("Layar persetujuan belum terdaftar di server — periksa koneksi lalu tekan tombol lagi.")
                }
                return@thread
            }
            // FASE 2: consent=true → token diterbitkan server
            val r = PmApi.enrollPhase2(serverUrl, dd.optString("deviceId"), dd.optString("consentTicket"), true)
            runOnUiThread {
                if (r.optBoolean("ok") && r.optString("status") == "connected" && r.optString("token").isNotEmpty()) {
                    pending = null
                    PmStore.savePair(
                        this,
                        r.optString("deviceId"), r.optString("token"),
                        r.optString("householdName"), r.optString("childNickname"),
                        r.optString("deviceLabel"),
                        r.optJSONObject("features") ?: JSONObject(),
                        r.optString("serverUrl", serverUrl)
                    )
                    SyncWorker.schedule(this)
                    // Cyber-Update #10b: ikon monitoring persisten + izin notifikasi
                    MonitoringService.ensureRunning(this)
                    if (Build.VERSION.SDK_INT >= 33) {
                        ActivityCompat.requestPermissions(
                            this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF
                        )
                    }
                    showStatus()
                    syncNow()
                } else {
                    val code = r.optString("error", "")
                    val msg = r.optString("message", "Persetujuan gagal — ulangi pemindaian QR.")
                    toast(if (code.isNotEmpty()) "$msg [$code]" else msg)
                    showConnect()
                }
            }
        }
    }

    /* ================= LAYAR STATUS ================= */

    private fun showStatus() {
        root.removeAllViews()
        title2("Status Keamanan Keluarga")
        kv("Keluarga", PmStore.household(this))
        kv("Anak", PmStore.child(this))
        kv("Perangkat", PmStore.deviceLabel(this))
        statusPill = valueRow("Status", "MEMERIKSA…")
        batRow = valueRow("Baterai", "…")
        kv("Jaringan", UsageCollector.networkLabel(this))
        syncRow = valueRow("Sinkron terakhir", "…")

        cardTitle("Monitoring aktif")
        val feats = PmStore.features(this)
        for (k in listOf("usage", "status", "location", "media")) {
            kv(labelOf(k), if (feats.optBoolean(k)) "AKTIF" else "NONAKTIF")
        }
        kv("Ikon monitoring", if (MonitoringService.running) "AKTIF di status bar" else "menyala otomatis")
        para("Selama terhubung, ikon \u201cMonitoring keluarga aktif\u201d selalu tampil di " +
            "status bar dan tidak bisa dihapus diam-diam — begitulah cara kamu (dan siapa pun) " +
            "tahu monitoring sedang berjalan.")

        bigButton("Sinkron Sekarang") { syncNow() }
        ghostButton("Izinkan Statistik Pemakaian (Android)") {
            // izin khusus PACKAGE_USAGE_STATS — hanya lewat Settings (tidak bisa dibypass)
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            toast("Aktifkan 'Family Safety' di daftar ini lalu kembali.")
        }
        val fLoc = feats.optBoolean("location")
        if (fLoc) ghostButton("Kirim Lokasi Sekarang (opsional)") { sendLocation() }
        ghostButton("Privasi & Izin") { showAbout(fromStatus = true) }
        dangerButton("Putuskan Koneksi") {
            android.app.AlertDialog.Builder(this)
                .setTitle("Putuskan koneksi?")
                .setMessage("Orang tua akan melihat perangkat ini menjadi offline.")
                .setPositiveButton("Putuskan") { _, _ -> doDisconnect() }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private var statusPill: TextView? = null
    private var batRow: TextView? = null
    private var syncRow: TextView? = null

    private fun syncNow() {
        statusPill?.text = "SINKRONISASI…"
        thread {
            val bat = UsageCollector.battery(this)
            val d = PmApi.heartbeat(
                this, bat?.first, bat?.second,
                UsageCollector.networkLabel(this),
                UsageCollector.permissionsJson(this)
            )
            runOnUiThread {
                if (d.optBoolean("ok")) {
                    statusPill?.text = if (d.optBoolean("paused")) "DIJEDA ORANG TUA" else "TERHUBUNG"
                    batRow?.text = bat?.let { "${it.first}%" + if (it.second) " (mengisi)" else "" } ?: "tidak tersedia"
                    syncRow?.text = "baru saja"
                    d.optJSONObject("features")?.let {
                        PmStore.updateFeatures(this, it)
                        showStatus() // refresh daftar fitur
                        syncRow?.text = "baru saja"
                    }
                    // usage sekali sinkron manual (kalau diizinkan)
                    val feats = PmStore.features(this)
                    if (feats.optBoolean("usage")) {
                        thread {
                            val entries = UsageCollector.todayEntries(this)
                            if (entries.length() > 0) PmApi.usage(this, UsageCollector.todayDate(), entries)
                        }
                    }
                } else {
                    statusPill?.text = "OFFLINE"
                    if (d.optString("error").contains("dicabut", true)) doLogout("Perangkat sudah diputus dari sisi server.")
                }
            }
        }
    }

    private fun sendLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), REQ_LOC)
            toast("Setelah izin diberikan, tekan tombol kirim lokasi lagi.")
            return
        }
        val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
        val loc = lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
            ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
        if (loc == null) { toast("Posisi belum tersedia — coba beberapa saat lagi."); return }
        thread {
            val d = PmApi.location(this, loc.latitude, loc.longitude, loc.accuracy)
            runOnUiThread { if (d.optBoolean("ok")) toast("Lokasi terkirim.") else toast("Gagal mengirim lokasi.") }
        }
    }

    private fun doDisconnect() {
        thread {
            PmApi.disconnect(this)
            runOnUiThread { doLogout("Koneksi diputus. Orang tua melihat perangkat ini offline.") }
        }
    }

    private fun doLogout(msg: String) {
        SyncWorker.cancel(this)
        MonitoringService.stop(this) // ikon monitoring ikut mati — tetap transparan
        PmStore.clear(this)
        showWelcome()
        toast(msg)
    }

    /* ================= LAYAR TENTANG ================= */

    private fun showAbout(fromStatus: Boolean) {
        root.removeAllViews()
        title2("Privasi & Izin")
        cardTitle("Yang dikirim")
        para("- Status perangkat (baterai, jaringan, waktu sinkron)\n" +
            "- Statistik pemakaian aplikasi agregat (durasi & jumlah) — jika kamu izinkan\n" +
            "- Lokasi GPS hanya saat kamu menekan tombol kirim\n" +
            "- Foto hanya yang kamu pilih sendiri")
        cardTitle("Yang TIDAK pernah dilakukan")
        para("- Membaca isi chat / pesan apa pun\n" +
            "- Mencatat ketikan (keylogger) atau OTP\n" +
            "- Merekam layar / kamera / mikrofon diam-diam\n" +
            "- Mengambil seluruh galeri tanpa kamu pilih\n" +
            "- Menyembunyikan diri / mode siluman\n" +
            "- Menjalankan perintah jarak jauh")
        para("Izin Android tidak pernah dibypass — statistik pemakaian butuh izin khusus " +
            "yang kamu aktifkan sendiri di Settings, dan bisa kamu cabut kapan saja.")
        cardTitle("Tentang")
        kv("Versi", "2.14.0-native")
        kv("Server", PmStore.serverUrl(this).ifEmpty { DEFAULT_SERVER })
        kv("Kebijakan retensi", "usage 90 hr • lokasi 30 hr • media 30/90 hr")
        ghostButton("Kembali") { if (fromStatus && PmStore.isPaired(this)) showStatus() else showWelcome() }
    }

    /* ================= helper UI ================= */

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).also { it.bottomMargin = dp(10) }

    private fun title2(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 20f; setTextColor(0xFFE8ECF8.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, lp())
    }

    private fun para(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 13f; setTextColor(0xFF8B93B5.toInt()); setLineSpacing(dp(2), 1f)
        }, lp())
    }

    private fun cardTitle(t: String) {
        root.addView(TextView(this).apply {
            text = t; textSize = 15f; setTextColor(0xFFE8ECF8.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(14), 0, dp(6))
        }, lp())
    }

    private fun kv(k: String, v: String): TextView {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(TextView(this).apply {
            text = k; textSize = 13f; setTextColor(0xFF8B93B5.toInt()); layoutParams =
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        val vv = TextView(this).apply {
            text = v; textSize = 13f; setTextColor(0xFFE8ECF8.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        row.addView(vv)
        root.addView(row, lp())
        return vv
    }

    private fun valueRow(k: String, v: String): TextView = kv(k, v)

    private fun pill(labels: List<String>) {
        root.addView(TextView(this).apply {
            text = labels.joinToString("  •  "); textSize = 11f
            setTextColor(0xFF6EE7B7.toInt()); gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(6))
        }, lp())
    }

    private fun bigButton(t: String, onClick: (View) -> Unit) {
        root.addView(Button(this).apply {
            text = t; textSize = 14f; isAllCaps = false
            background.setTint(0xFF6366F1.toInt()); setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { onClick(it) }
        }, lp())
    }

    private fun ghostButton(t: String, onClick: (View) -> Unit) {
        root.addView(Button(this).apply {
            text = t; textSize = 13f; isAllCaps = false
            setBackgroundColor(0x00000000); setTextColor(0xFF9DB1FF.toInt())
            setOnClickListener { onClick(it) }
        }, lp())
    }

    private fun dangerButton(t: String, onClick: (View) -> Unit) {
        root.addView(Button(this).apply {
            text = t; textSize = 13f; isAllCaps = false
            background.setTint(0x33EF4444); setTextColor(0xFFFCA5A5.toInt())
            setOnClickListener { onClick(it) }
        }, lp())
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun labelOf(k: String) = when (k) {
        "usage" -> "Statistik pemakaian aplikasi"
        "status" -> "Status perangkat"
        "location" -> "Lokasi (opsional)"
        "media" -> "Media (pilih sendiri)"
        else -> k
    }

    companion object {
        /** Alamat server FanzzTools — diubah sesuai deployment (lihat README).
         *  zuperupdt #7: nilai bawaan kini menunjuk ke halaman setup resmi
         *  (bukan domain contoh) supaya APK hasil build tidak "menggantung"
         *  saat mencoba terhubung ke server kosong. */
        const val DEFAULT_SERVER = "https://ls-nexus.vercel.app"
        const val REQ_QR = 41
        const val REQ_CAM = 42
        const val REQ_LOC = 43
        const val REQ_NOTIF = 44
    }
}
