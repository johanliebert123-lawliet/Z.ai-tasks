package com.fanzz.familysafety

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.util.UUID

/**
 * Penyimpanan lokal companion (SharedPreferences).
 * Token perangkat disimpan PLAINTEXT hanya di HP anak (server menyimpan HASH) —
 * tidak pernah ditulis ke log, tidak dibagikan ke aplikasi lain.
 */
object PmStore {
    private const val PREFS = "fanzz_pm"
    private const val K_DEVICE_ID = "deviceId"
    private const val K_TOKEN = "token"
    private const val K_HOUSEHOLD = "householdName"
    private const val K_CHILD = "childNickname"
    private const val K_DEVICE_LABEL = "deviceLabel"
    private const val K_FEATURES = "features"
    private const val K_SERVER = "serverUrl"

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isPaired(ctx: Context): Boolean = prefs(ctx).getString(K_TOKEN, null) != null

    fun savePair(
        ctx: Context,
        deviceId: String,
        token: String,
        householdName: String,
        childNickname: String,
        deviceLabel: String,
        features: JSONObject,
        serverUrl: String
    ) {
        prefs(ctx).edit()
            .putString(K_DEVICE_ID, deviceId)
            .putString(K_TOKEN, token)
            .putString(K_HOUSEHOLD, householdName)
            .putString(K_CHILD, childNickname)
            .putString(K_DEVICE_LABEL, deviceLabel)
            .putString(K_FEATURES, features.toString())
            .putString(K_SERVER, serverUrl)
            .apply()
    }

    fun token(ctx: Context): String? = prefs(ctx).getString(K_TOKEN, null)
    fun deviceId(ctx: Context): String? = prefs(ctx).getString(K_DEVICE_ID, null)
    fun serverUrl(ctx: Context): String = prefs(ctx).getString(K_SERVER, "") ?: ""
    fun household(ctx: Context): String = prefs(ctx).getString(K_HOUSEHOLD, "-") ?: "-"
    fun child(ctx: Context): String = prefs(ctx).getString(K_CHILD, "-") ?: "-"
    fun deviceLabel(ctx: Context): String = prefs(ctx).getString(K_DEVICE_LABEL, "-") ?: "-"

    fun features(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString(K_FEATURES, "{}") ?: "{}")
    } catch (_: Exception) {
        JSONObject()
    }

    fun updateFeatures(ctx: Context, f: JSONObject) {
        prefs(ctx).edit().putString(K_FEATURES, f.toString()).apply()
    }

    /** Instalasi ID stabil — dipakai untuk idempotensi upsert usage. */
    fun installId(ctx: Context): String {
        val p = prefs(ctx)
        var id = p.getString("installId", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            p.edit().putString("installId", id).apply()
        }
        return id
    }

    fun clear(ctx: Context) {
        prefs(ctx).edit().clear().apply()
    }
}
