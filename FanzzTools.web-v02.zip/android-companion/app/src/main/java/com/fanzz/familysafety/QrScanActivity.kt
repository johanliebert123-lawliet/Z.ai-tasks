package com.fanzz.familysafety

import android.content.Intent
import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import java.util.concurrent.Executors

/**
 * Pemindai QR pairing — kamera belakang + dekoder ZXing murni.
 * Hanya membaca QR dengan awalan FANZZ-PM1| (kode pairing bertanda tangan);
 * kamera mati total begitu QR valid ketemu (tidak ada preview menggantung).
 */
class QrScanActivity : AppCompatActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private var found = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()

        val previewView = PreviewView(this)
        setContentView(FrameLayout(this).apply { addView(previewView) })

        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor, ::analyze)

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun analyze(proxy: ImageProxy) {
        if (found) { proxy.close(); return }
        val raw = try {
            val img = proxy.image ?: return proxy.close()
            val bmp = proxy.toBitmap()
            val w = bmp.width; val h = bmp.height
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            val source = RGBLuminanceSource(w, h, pixels)
            QRCodeReader().decode(
                BinaryBitmap(HybridBinarizer(source)),
                mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE))
            )
        } catch (_: Exception) {
            null
        }
        val text = raw?.text
        proxy.close()
        if (text != null && text.startsWith("FANZZ-PM1|")) {
            found = true
            runOnUiThread {
                // PERBAIKAN zuperupdt #7 ("QR dipindai tidak merespons"):
                // dulu setResult memakai `intent` PELUNCUR (intent.putExtra) —
                // di banyak versi Android payload tidak pernah sampai ke
                // MainActivity (hasil kembali kosong). Intent BARU wajib.
                setResult(RESULT_OK, Intent().putExtra("payload", text))
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}
