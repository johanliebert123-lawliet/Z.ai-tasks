package com.fanzz.familysafety

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Klien API Parent Monitor (server FanzzTools V2).
 * Semua panggilan memakai token Bearer perangkat; server menyimpan hash-nya.
 * Rate limit server juga berlaku — companion tidak pernah spam.
 */
object PmApi {

    private fun http(ctx: Context, path: String, method: String, body: JSONObject?): JSONObject {
        val base = PmStore.serverUrl(ctx).trimEnd('/')
        val conn = URL(base + path).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("User-Agent", "FanzzFamilySafety/2.12 (Android ${Build.VERSION.RELEASE})")
        PmStore.token(ctx)?.let { conn.setRequestProperty("Authorization", "Bearer $it") }
        if (body != null) {
            conn.doOutput = true
            val out: OutputStream = conn.outputStream
            out.write(body.toString().toByteArray(Charsets.UTF_8))
            out.close()
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Exception) { JSONObject().put("ok", false) }
    }

    fun health(ctx: Context, serverUrl: String): JSONObject =
        httpBase(serverUrl, "/api/pm/health")

    private fun httpBase(serverUrl: String, path: String): JSONObject {
        val conn = URL(serverUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 15000
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Exception) { JSONObject().put("ok", false) }
    }

    /** FASE 1 (zuperupdt #7): scan QR / input kode.
     *  TANPA confirm — perangkat dibuat PENDING_CONSENT, TIDAK ada token.
     *  Respons: { deviceId, consentTicket, householdName, childNickname,
     *             deviceLabel, features, consentRequired } atau galat
     *  terstruktur { ok:false, error:"PAIRING_EXPIRED", message:"..." }. */
    fun enrollPhase1(
        serverUrl: String,
        qrPayload: String?,
        code: String?,
        model: String,
        androidVersion: String
    ): JSONObject {
        val conn = URL(serverUrl.trimEnd('/') + "/api/pm/device/enroll").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json")
        val body = JSONObject()
            .put("model", model)
            .put("androidVersion", androidVersion)
            .put("appVersion", "2.14.0-native")
        if (qrPayload != null) body.put("qrPayload", qrPayload)
        if (code != null) body.put("code", code)
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code2 = conn.responseCode
        val stream = if (code2 in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Exception) { JSONObject().put("ok", false) }
    }

    /** FASE 1b: layar persetujuan terbuka → status CONSENT_REQUIRED di dashboard. */
    fun markConsentShown(serverUrl: String, deviceId: String, consentTicket: String): JSONObject =
        postEnroll(serverUrl, JSONObject()
            .put("deviceId", deviceId)
            .put("consentTicket", consentTicket)
            .put("action", "shown"))

    /** FASE 2: jawaban anak. consent=true → token diterbitkan;
     *  consent=false → REJECTED (kode mati). */
    fun enrollPhase2(serverUrl: String, deviceId: String, consentTicket: String, consent: Boolean): JSONObject =
        postEnroll(serverUrl, JSONObject()
            .put("deviceId", deviceId)
            .put("consentTicket", consentTicket)
            .put("consent", consent))

    private fun postEnroll(serverUrl: String, body: JSONObject): JSONObject {
        val conn = URL(serverUrl.trimEnd('/') + "/api/pm/device/enroll").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/json")
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code2 = conn.responseCode
        val stream = if (code2 in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        return try { JSONObject(text) } catch (_: Exception) { JSONObject().put("ok", false) }
    }

    fun heartbeat(ctx: Context, battery: Int?, charging: Boolean?, network: String, permissions: JSONObject): JSONObject {
        val body = JSONObject()
            .put("battery", battery ?: JSONObject.NULL)
            .put("charging", charging ?: JSONObject.NULL)
            .put("network", network)
            .put("permissions", permissions)
            .put("appVersion", "2.14.0-native")
        return http(ctx, "/api/pm/device/heartbeat", "POST", body)
    }

    /** Upsert usage agregat (idempotent — server simpan nilai maksimum). */
    fun usage(ctx: Context, date: String, entries: JSONArray): JSONObject {
        val body = JSONObject().put("date", date).put("entries", entries)
        return http(ctx, "/api/pm/device/usage", "POST", body)
    }

    fun location(ctx: Context, lat: Double, lon: Double, accuracy: Float): JSONObject {
        val body = JSONObject().put("lat", lat).put("lon", lon).put("accuracy", accuracy.toInt())
        return http(ctx, "/api/pm/device/location", "POST", body)
    }

    fun media(ctx: Context, kind: String, size: Long, thumbB64: String?): JSONObject {
        val items = JSONArray().put(JSONObject().put("kind", kind).put("size", size).put("thumb", thumbB64 ?: JSONObject.NULL))
        return http(ctx, "/api/pm/device/media", "POST", JSONObject().put("items", items))
    }

    fun disconnect(ctx: Context): JSONObject =
        http(ctx, "/api/pm/device/disconnect", "POST", JSONObject())
}
