package com.fanzz.familysafety

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Cyber-Update #10b: layanan foreground dengan IKON NOTIFIKASI PERSISTEN.
 *
 * Prinsip transparansi (spesifikasi Family Safety):
 *  - Selama monitoring aktif, ada penanda TETAP di status bar HP anak —
 *    notifikasi "ongoing" TIDAK BISA di-swipe/dismis diam-diam.
 *  - Notifikasi hanya hilang saat koneksi diputus (anak menekan Putuskan /
 *    orang tua mencabut perangkat) — bukan karena disembunyikan.
 *  - HANYA penanda status — tidak membaca apa pun, tidak menyembunyikan diri.
 *
 * Teknis: foreground service tipe dataSync (Android 14+), START_STICKY agar
 * dihidupkan ulang sistem bila terbunuh, stopWithTask=false agar tetap jalan
 * saat aplikasi di-swipe dari recent apps.
 */
class MonitoringService : Service() {

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val household = PmStore.household(this)
        val child = PmStore.child(this)

        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif: Notification = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Monitoring keluarga aktif")
            .setContentText("Family Safety terhubung dengan $household ($child). Ketuk untuk melihat status atau memutus koneksi.")
            .setStyle(
                Notification.BigTextStyle()
                    .bigText("Family Safety terhubung dengan $household ($child).\n\n" +
                        "Yang dilaporkan: status perangkat & statistik pemakaian agregat.\n" +
                        "Ketuk untuk melihat status atau memutus koneksi kapan saja.")
            )
            .setOngoing(true) // tidak bisa di-dismiss diam-diam
            .setOnlyAlertOnce(true)
            .setContentIntent(pi)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, notif)
        }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID,
                "Status monitoring keluarga",
                NotificationManager.IMPORTANCE_LOW // senyap: tanpa suara/getar
            ).apply {
                description = "Penanda permanen bahwa monitoring keluarga aktif di perangkat ini. Tidak bisa dihapus selama terhubung."
                setShowBadge(false)
            }
        )
    }

    companion object {
        const val CHANNEL_ID = "fanzz_pm_monitoring"
        const val NOTIF_ID = 4210

        @Volatile
        @JvmStatic
        var running: Boolean = false

        /** Hidupkan layar ikon persisten (aman dipanggil saat app di foreground). */
        fun ensureRunning(ctx: Context) {
            if (running) return
            try {
                ctx.startForegroundService(Intent(ctx, MonitoringService::class.java))
            } catch (_: Exception) {
                // Beberapa konteks (background terbatas Android 12+) menolak —
                // SyncWorker/BootReceiver akan mencoba lagi di kesempatan lain.
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, MonitoringService::class.java))
            } catch (_: Exception) {
                /* diam */
            }
        }
    }
}
