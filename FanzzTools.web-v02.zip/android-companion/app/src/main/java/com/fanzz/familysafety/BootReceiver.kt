package com.fanzz.familysafety

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Cyber-Update #10b: setelah HP menyala ulang (BOOT_COMPLETED), kalau
 * perangkat masih terhubung & disetujui, ikon monitoring persisten
 * dihidupkan kembali — penanda transparansi tidak boleh hilang diam-diam
 * hanya karena reboot.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && PmStore.isPaired(context)) {
            MonitoringService.ensureRunning(context)
        }
    }
}
