plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fanzz.familysafety"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.fanzz.familysafety"
        minSdk = 26          // Android 8.0+
        targetSdk = 34
        versionCode = 21400
        versionName = "2.14.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.camera:camera-view:1.3.4")
    // dekoder QR — pustaka murni, tanpa izin tambahan
    implementation("com.google.zxing:core:3.5.3")
    implementation("org.json:json:20240303") // sudah bundel di Android; dideklarasikan eksplisit
}
