// Parent Monitor — Native Android Companion (Kotlin)
// =====================================================
// FanzzTools V2 • Family Cyber Safety — V2.12 Security-Updt
//
// PROYEK INI ADALAH SUMBER ASLI companion NATIVE (bukan WebView).
// Fitur:
//  - Pairing lewat QR (kamera) atau kode manual PM-XXXX-XXXX
//  - Konfirmasi eksplisit pengguna perangkat SEBELUM terhubung
//  - Layar "Family Safety Status" transparan (fitur aktif selalu tampil)
//  - Statistik pemakaian aplikasi agregat via UsageStatsManager
//    (butuh izin khusus PACKAGE_USAGE_STATS — dibuka lewat Settings)
//  - Sinkronisasi latar belakang via WorkManager (periode MINIMAL 15 menit,
//    retry exponential backoff, constraint jaringan)
//  - Lokasi opsional (hanya saat fitur aktif DAN tombol ditekan)
//  - Tombol Putuskan Koneksi untuk anak — transparan, bisa kapan saja
//  - TANPA keylogger / intersep OTP / baca chat / rekam diam-diam /
//    scraping galeri / shell jarak jauh / stealth mode
//
// STATUS BUILD (kejujuran build — spesifikasi §46):
//  NOT RUN — proyek ini BELUM dikompilasi & diuji di environment pengiriman
//  (tidak ada Android SDK/Gradle di server web). Orang tua meng-compile
//  sendiri di Android Studio. Semua API yang dipanggil kompatibel dengan
//  API level 26+ (Android 8.0).

pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "FanzzFamilySafety"
include(":app")
