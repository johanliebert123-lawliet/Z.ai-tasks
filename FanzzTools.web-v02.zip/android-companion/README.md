# Fanzz Family Safety — Companion Native Android (Kotlin)

Companion **native** (bukan WebView) untuk fitur **Parent Monitor / Family Cyber
Safety** FanzzTools V2. Dibuat untuk orang tua yang ingin statistik pemakaian
aplikasi **agregat** (UsageStatsManager) — sesuatu yang tidak bisa diambil
companion berbasis web.

> **STATUS BUILD (kejujuran build — §46 spesifikasi):**
> **NOT RUN** — proyek ini BELUM dikompilasi dan BELUM diuji di environment
> pengiriman (server web tidak punya Android SDK/Gradle). Kode ditulis agar
> kompatibel AGP 8.5 / Kotlin 1.9 / API 26+, tapi hasil kompilasinya harus
> diverifikasi orang tua sendiri di Android Studio.

## Cara build (orang tua, ±10 menit)

1. Install **Android Studio** (Koala atau lebih baru) + SDK 34.
2. Buka folder `android-companion` → tunggu Gradle sync.
3. Ubah `DEFAULT_SERVER` di `MainActivity.kt` menjadi URL deployment FanzzTools
   kamu (mis. `https://fanzztools-kamu.vercel.app`).
4. `Build → Generate Signed Bundle / APK → APK` (buat keystore sendiri).
5. Transfer APK ke HP anak → install (izinkan "sumber tidak dikenal").

Alternatif tanpa kompilasi: **APK Builder → mode Parent Monitor** di web
FanzzTools (companion berbasis web: pairing kode/QR, status transparan, lokasi
opsional, media pilihan — TANPA statistik UsageStatsManager).

## Alur pemakaian (Cyber-Update #10)

1. Orang tua: web → **Parent Monitor** → buat profil anak (maks usia 35) →
   buat perangkat → **QR / Kode Pairing** (berlaku 10 menit, sekali pakai).
2. HP anak: buka Family Safety → **Mulai Hubungkan** → scan QR atau ketik
   `PM-XXXX-XXXX`.
3. Layar **DISCLOSURE EKSPLISIT** muncul di HP anak — apa yang dipantau, oleh
   siapa, kenapa, retensi data — lalu anak mencentang **"Saya sudah membaca &
   mengerti"**; baru tombol **Saya Setuju & Hubungkan** aktif (tidak ada
   pairing diam-diam). Server MEWAJIBKAN layar ini terbuka (error
   `CONSENT_NOT_SHOWN` bila fase "shown" dilewati) sebelum consent diterima.
4. Setelah disetujui: **ikon monitoring persisten** menyala di status bar
   (foreground service `MonitoringService`, ongoing — tidak bisa di-swipe
   diam-diam, otomatis hidup lagi setelah reboot lewat `BootReceiver`).
5. Aktifkan izin **Usage Access** saat diminta (Settings → Special access →
   Usage access → Family Safety). Bisa dicabut anak kapan saja.
6. Dashboard orang tua menerima heartbeat tiap ±15 menit (WorkManager) +
   langsung tiap kali aplikasi dibuka anak; jendela "online" server 35 menit
   supaya perangkat sehat tidak tampak offline bolak-balik.

## Desain privasi (bukan spyware)

| Ada | Tidak ada (dilarang §36) |
|---|---|
| Statistik pemakaian agregat (durasi/jumlah buka per aplikasi) | keylogger / isi ketikan |
| Status baterai, jaringan, waktu sinkron | intersep OTP/password/chat |
| Lokasi opsional — hanya saat anak menekan tombol | pelacakan lokasi diam-diam |
| Media pilihan anak (Photo Picker) | scraping galeri penuh |
| Layar status transparan + tombol Putuskan | stealth mode / icon tersembunyi |
| Sinkron terjadwal ≥ 15 menit | remote shell / perintah jarak jauh |

Retensi data di server: usage 90 hari • lokasi 30 hari • thumbnail 30 hari •
metadata media 90 hari. Semua bisa dihapus lewat **Privacy Center** di
dashboard orang tua.

## File penting

- `MainActivity.kt` — layar: sambutan, hubungkan, konfirmasi, status, privasi.
- `QrScanActivity.kt` — kamera belakang + ZXing (hanya QR `FANZZ-PM1|…`).
- `PmApi.kt` — klien API `/api/pm/device/*` (Bearer token per perangkat).
- `PmStore.kt` — token & konfigurasi lokal (SharedPreferences).
- `SyncWorker.kt` — WorkManager ≥15 menit + UsageStatsManager agregat.
