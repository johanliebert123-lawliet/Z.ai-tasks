#!/usr/bin/env node
/* E2E test: /api/react-wa — verifikasi perbaikan bug "Parameter url wajib diisi".
 * Alur: register → session → POST /api/react-wa {action:"react", url, reactions}.
 * Verifikasi:
 *   1. Tanpa url → 400 validasi lokal (bukan 400 upstream "Parameter url wajib diisi")
 *   2. URL bukan whatsapp.com → 400 lokal
 *   3. URL valid → request TERKIRIM ke upstream dengan param url + emoji lengkap
 *      (200 masuk antrean / 429 jeda / 502 upstream) — YANG PENTING: error 400
 *      "Parameter url wajib diisi" TIDAK muncul lagi karena url terkirim.
 *   4. Respons 429 → field retry + waitSec terisi (UI bisa auto-wait).
 */
const BASE = process.env.PM_TEST_BASE || "http://127.0.0.1:3111";
let cookie = "";
let passed = 0, failed = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { passed++; console.log(`PASS  ${name}`); }
  else { failed++; console.log(`FAIL  ${name} ${extra}`); }
};

async function j(path, opts = {}) {
  const r = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(cookie ? { cookie } : {}), ...(opts.headers || {}) },
  });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) cookie = sc.map((c) => c.split(";")[0]).join("; ");
  let d = null;
  try { d = await r.json(); } catch {}
  return { status: r.status, d };
}

(async () => {
  const email = `rwa${Date.now()}@fanzz.test`;
  let r = await j("/api/auth/register", { method: "POST", body: JSON.stringify({ email, username: "rwatester", password: "Test12345!" }) });
  ok("register", r.d?.ok === true);
  r = await j("/api/auth/session");
  ok("session aktif", r.d?.ok === true);

  // 1) tanpa url → validasi lokal
  r = await j("/api/react-wa", { method: "POST", body: JSON.stringify({ action: "react", url: "", reactions: ["🔥"] }) });
  ok("tanpa url → ditolak validasi lokal (bukan error upstream)", r.status === 400 && (r.d?.error || "").includes("Tautan") || (r.d?.error || "").includes("tidak valid"));

  // 2) url bukan whatsapp → ditolak
  r = await j("/api/react-wa", { method: "POST", body: JSON.stringify({ action: "react", url: "https://example.com/post/1", reactions: ["🔥"] }) });
  ok("url non-whatsapp → ditolak", r.status === 400);

  // 3) URL channel WA valid → upstream menerima (terkirim dengan param url)
  //    Contoh pesan saluran publik dari laporan pemilik.
  const target = "https://whatsapp.com/channel/0029VbD89iz3bbV3E3Q0C841/968";
  r = await j("/api/react-wa", { method: "POST", body: JSON.stringify({ action: "react", url: target, reactions: ["🔥", "❤️"] }) });
  const errStr = String(r.d?.error || "");
  if (r.d?.ok === true) {
    ok("react dengan url → MASUK ANTREAN (status 200 upstream)", true, JSON.stringify(r.d));
    ok("respons taskStatus terisi", typeof r.d?.taskStatus === "string" && r.d.taskStatus.length > 0);
  } else if (r.status === 429) {
    ok("react → 429 rate-limit upstream (url SAMPAI, hanya antrean)", r.d?.retry === true && Number(r.d?.waitSec) > 0, JSON.stringify(r.d));
  } else {
    // BUG LAMA: 400 "Parameter url wajib diisi" — kalau masih muncul, fix gagal
    ok(`react → terkirim tapi upstream jawab ${r.status} (bukan bug url)`, !errStr.includes("url wajib diisi"), JSON.stringify(r.d));
  }

  // 4) tanpa reactions → 400 lokal
  r = await j("/api/react-wa", { method: "POST", body: JSON.stringify({ action: "react", url: target, reactions: [] }) });
  ok("tanpa emoji → ditolak", r.status === 400);

  console.log(`\n=== HASIL: ${passed} PASS / ${failed} FAIL ===`);
  process.exit(failed ? 1 : 0);
})();
