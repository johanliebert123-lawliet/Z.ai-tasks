#!/usr/bin/env node
/* End-to-end test Parent Monitor — alur 2-FASE + mesin status (zuperupdt #7).
 *
 * TEST A — QR generate (CREATED): format FANZZ-PM1|id|code|exp|sig, TTL 10 mnt, fitur ortu ikut
 * TEST B — QR rusak / tanda tangan palsu → galat terstruktur INVALID_QR / QR_SIGNATURE_INVALID
 * TEST C — FASE 1 (scan): perangkat PENDING_CONSENT, TANPA token, consentTicket terbit
 * TEST D — FASE 2 consent:false → REJECTED (kode mati, tidak ada token, ortu diberi tahu)
 * TEST E — FASE 2 tiket salah → CONSENT_INVALID; tiket benar + status habis → DEVICE_NOT_PENDING
 * TEST F — FASE 2 consent:true → CONNECTED + token; heartbeat/usage/location/media jalan
 * TEST G — replay: QR terpakai ulang → PAIRING_USED; scan ulang saat PENDING → tiket baru (anti-macet)
 * TEST H — QR kedaluwarsa (exp lampau, tanda tangan valid) → PAIRING_EXPIRED
 * TEST I — ortu cancel → REVOKED → rescan PAIRING_CANCELLED; anak disconnect → token mati
 *
 * + integrasi lama: attestation, batas usia, isolasi household, story foto+musik, privacy purge.
 *
 * Jalankan: node scripts/test-pm-e2e.mjs  (server harus aktif di BASE,
 *  dijalankan dengan APP_SECRET=test-secret-0123456789abcdef0123456789 supaya
 *  TEST H bisa menempa QR kedaluwarsa bertanda tangan valid).
 */
const BASE = process.env.PM_TEST_BASE || "http://localhost:3111";
const APP_SECRET = process.env.PM_TEST_SECRET || "test-secret-0123456789abcdef0123456789";
let cookie = "";
let passed = 0, failed = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { passed++; console.log(`PASS  ${name}`); }
  else { failed++; console.log(`FAIL  ${name} ${extra}`); }
};

async function j(path, opts = {}) {
  const r = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(cookie ? { cookie } : {}), ...(opts.headers || {}) },
  });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) cookie = sc.map((c) => c.split(";")[0]).join("; ");
  let d = null;
  try { d = await r.json(); } catch {}
  return { status: r.status, d };
}

import crypto from "crypto";
/** Tempa payload QR bertanda tangan valid (algoritma sama dengan pm-store). */
function forgeQr(id, code, exp) {
  const sig = crypto.createHmac("sha256", `${APP_SECRET}#fanzz-pm-v1`).update(`FANZZ-PM1|${id}|${code}|${exp}`).digest("base64url");
  return `FANZZ-PM1|${id}|${code}|${exp}|${sig}`;
}

(async () => {
  // ---------- health ----------
  let r = await j("/api/pm/health");
  ok("health: ok + policy usia 35", r.d?.ok === true && r.d?.policy?.childMaxAge === 35);

  // ---------- auth ----------
  const email = `pmtest${Date.now()}@fanzz.test`;
  r = await j("/api/auth/register", { method: "POST", body: JSON.stringify({ email, username: "pmtester", password: "Test12345!" }) });
  ok("register", r.d?.ok === true, JSON.stringify(r.d));
  r = await j("/api/auth/session");
  ok("session cookie aktif", r.d?.ok === true);

  // ---------- PM overview (auto household) ----------
  r = await j("/api/pm/overview");
  ok("overview: household dibuat, belum attested", r.d?.ok === true && r.d?.household?.attested === false);

  r = await j("/api/pm/children", { method: "POST", body: JSON.stringify({ nickname: "Anak1", birthYear: 2015 }) });
  ok("children: ditolak sebelum attestation", r.status === 400 || r.d?.ok === false);

  r = await j("/api/pm/attest", { method: "POST", body: JSON.stringify({ confirm: true, parentBirthYear: 1990 }) });
  ok("attest: pernyataan wali tersimpan", r.d?.ok === true);

  r = await j("/api/pm/children", { method: "POST", body: JSON.stringify({ nickname: "Kakak", birthYear: 1988 }) });
  ok("children: usia 37 (1988) DITOLAK", r.d?.ok === false, JSON.stringify(r.d));
  r = await j("/api/pm/children", { method: "POST", body: JSON.stringify({ nickname: "Adik", birthYear: 2015 }) });
  ok("children: usia 11 diterima", r.d?.ok === true, JSON.stringify(r.d));
  const childId = r.d?.child?.id;

  /* ================= TEST A — QR generate (CREATED) ================= */
  r = await j("/api/pm/enrollment", { method: "POST", body: JSON.stringify({ action: "generate", childId, deviceLabel: "HP Adik", features: { usage: true, status: true, location: true, media: true } }) });
  const qrA = r.d?.enrollment?.qrPayload || "";
  const partsA = qrA.split("|");
  ok("A1 generate: QR FANZZ-PM1 5 segmen", r.d?.ok === true && partsA.length === 5 && partsA[0] === "FANZZ-PM1", JSON.stringify(r.d?.enrollment));
  ok("A2 generate: TTL ±10 menit", r.d?.enrollment?.expiresAt > Date.now() + 9 * 60_000 && r.d?.enrollment?.expiresAt <= Date.now() + 11 * 60_000);
  r = await j(`/api/pm/enrollment?id=${r.d?.enrollment?.id}`);
  ok("A3 status awal: CREATED (menunggu pemindaian)", r.d?.ok === true && r.d?.status === "created", JSON.stringify(r.d));

  /* ================= TEST B — QR rusak / palsu ================= */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: "https://bukan-qr-fanzz.com/apa-aja" }) });
  ok("B1 QR non-PM1 → INVALID_QR (terstruktur)", r.d?.ok === false && r.d?.error === "INVALID_QR" && !!r.d?.message, JSON.stringify(r.d));
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: `FANZZ-PM1|${partsA[1]}|${partsA[2]}|${partsA[3]}|sig-palsu-dan-salah` }) });
  ok("B2 tanda tangan palsu → QR_SIGNATURE_INVALID", r.d?.ok === false && r.d?.error === "QR_SIGNATURE_INVALID", JSON.stringify(r.d));
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ code: "PM-XXXX-XXXX" }) });
  ok("B3 kode tak dikenal → PAIRING_NOT_FOUND", r.d?.ok === false && r.d?.error === "PAIRING_NOT_FOUND", JSON.stringify(r.d));

  /* ================= TEST C — FASE 1: scan → PENDING (tanpa token) ================= */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrA, model: "Pixel 8", androidVersion: "14", appVersion: "2.13.0-native" }) });
  ok("C1 fase-1 scan: ok + consentRequired", r.d?.ok === true && r.d?.consentRequired === true, JSON.stringify(r.d));
  ok("C2 fase-1: TANPA token (consent dulu!)", !r.d?.token, JSON.stringify(r.d));
  ok("C3 fase-1: consentTicket + deviceId terbit", typeof r.d?.consentTicket === "string" && r.d.consentTicket.length >= 20 && typeof r.d?.deviceId === "string");
  ok("C4 fase-1: status pending + fitur ortu terbawa", r.d?.status === "pending" && r.d?.features?.location === true && r.d?.features?.media === true, JSON.stringify(r.d));
  const devA = r.d?.deviceId, ticketA = r.d?.consentTicket, enrollIdA = partsA[1];

  // dashboard harus melihat PENDING (belum connected!)
  r = await j(`/api/pm/enrollment?id=${enrollIdA}`);
  ok("C5 dashboard: status PENDING (perangkat belum terhubung)", r.d?.ok === true && r.d?.status === "pending", JSON.stringify(r.d));
  r = await j("/api/pm/overview");
  ok("C6 overview: perangkat pending_consent (bukan connected)", r.d?.devices?.some?.((d) => d.id === devA && d.status === "pending_consent"), JSON.stringify(r.d?.devices?.map?.((d) => [d.id, d.status])));

  // heartbeat TANPA token ditolak — perangkat belum berhak
  r = await j("/api/pm/device/heartbeat", { method: "POST", headers: { Authorization: `Bearer ${ticketA}` }, body: "{}" });
  ok("C7 tiket persetujuan ≠ token: heartbeat ditolak 401", r.status === 401);

  // FASE 1b: mark shown → CONSENT_REQUIRED di dashboard
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devA, consentTicket: ticketA, action: "shown" }) });
  ok("C8 action shown → CONSENT_REQUIRED", r.d?.ok === true && r.d?.status === "consent_required", JSON.stringify(r.d));

  /* ================= TEST G (bagian 1) — scan ulang saat PENDING = anti-macet ================= */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrA, model: "Pixel 8" }) });
  ok("G1 scan ulang saat PENDING: TIDAK error \"sudah dipakai\" (anti-macet)", r.d?.ok === true, JSON.stringify(r.d));
  ok("G2 scan ulang: tiket BARU diterbitkan", r.d?.ok === true && r.d?.consentTicket && r.d.consentTicket !== ticketA);
  const ticketA2 = r.d?.consentTicket;

  /* ================= TEST E — tiket salah / status salah ================= */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devA, consentTicket: "tiket-salah-total-0000000000", consent: true }) });
  ok("E1 tiket salah → CONSENT_INVALID", r.d?.ok === false && r.d?.error === "CONSENT_INVALID", JSON.stringify(r.d));
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: "dv-tidak-ada", consentTicket: ticketA2, consent: true }) });
  ok("E2 deviceId tak dikenal → PAIRING_NOT_FOUND", r.d?.ok === false && r.d?.error === "PAIRING_NOT_FOUND", JSON.stringify(r.d));

  /* ================= TEST D — consent FALSE → REJECTED ================= */
  // pakai tiket kedua (G2) untuk menolak
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devA, consentTicket: ticketA2, consent: false }) });
  ok("D1 consent:false → status rejected", r.d?.ok === true && r.d?.status === "rejected", JSON.stringify(r.d));
  ok("D2 consent:false → TANPA token", !r.d?.token);
  r = await j(`/api/pm/enrollment?id=${enrollIdA}`);
  ok("D3 dashboard: enrollment REJECTED", r.d?.status === "rejected", JSON.stringify(r.d));
  r = await j("/api/pm/overview");
  ok("D4 overview: perangkat rejected + ortu diberi tahu (alert)", r.d?.devices?.some?.((d) => d.id === devA && d.status === "rejected") && (r.d?.alerts || []).some?.((a) => a.type === "device_rejected"), JSON.stringify(r.d?.alerts?.map?.((a) => a.type)));
  // kode mati setelah ditolak
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrA }) });
  ok("D5 kode mati setelah ditolak → PAIRING_REJECTED", r.d?.ok === false && r.d?.error === "PAIRING_REJECTED", JSON.stringify(r.d));
  // tiket hangus — pakai tiket lama lagi → CONSENT_INVALID (bukan connected)
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devA, consentTicket: ticketA, consent: true }) });
  ok("D6 tiket lama ditolak setelah REJECTED", r.d?.ok === false, JSON.stringify(r.d));

  /* ================= TEST F — consent TRUE → CONNECTED + token ================= */
  r = await j("/api/pm/enrollment", { method: "POST", body: JSON.stringify({ action: "generate", childId, deviceLabel: "HP Adik 2", features: { usage: true, status: true, location: true, media: true } }) });
  const qrF = r.d?.enrollment?.qrPayload || "";
  const enrollIdF = qrF.split("|")[1];
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrF, model: "Pixel 8", androidVersion: "14", appVersion: "2.13.0-native" }) });
  const devF = r.d?.deviceId, ticketF = r.d?.consentTicket;
  ok("F1 fase-1 kedua: pending + tiket", r.d?.ok === true && r.d?.status === "pending" && !!ticketF);
  /* FASE 1b wajib (guard Cyber-Update #10a): layar disclosure harus terbuka
     sebelum consent:true diterima — klien nakal tidak bisa melompat ke consent. */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devF, consentTicket: ticketF, action: "shown" }) });
  ok("F1b action shown → CONSENT_REQUIRED", r.d?.ok === true && r.d?.status === "consent_required", JSON.stringify(r.d));
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devF, consentTicket: ticketF, consent: true }) });
  ok("F2 consent:true → CONNECTED", r.d?.ok === true && r.d?.status === "connected", JSON.stringify(r.d));
  ok("F3 consent:true → token diterbitkan (satu kali lihat)", typeof r.d?.token === "string" && r.d.token.length >= 20);
  const token = r.d?.token;
  ok("F4 fitur ortu diterapkan (location/media ON)", r.d?.features?.location === true && r.d?.features?.media === true, JSON.stringify(r.d?.features));
  r = await j(`/api/pm/enrollment?id=${enrollIdF}`);
  ok("F5 dashboard: enrollment CONNECTED", r.d?.status === "connected");

  // device APIs kini berfungsi dengan token
  const auth = { Authorization: `Bearer ${token}` };
  r = await j("/api/pm/device/heartbeat", { method: "POST", headers: auth, body: JSON.stringify({ battery: 87, charging: false, network: "wifi", permissions: { usage: "granted" } }) });
  ok("F6 heartbeat: diterima dengan token", r.d?.ok === true, JSON.stringify(r.d));
  r = await j("/api/pm/device/usage", { method: "POST", headers: auth, body: JSON.stringify({ date: new Date().toISOString().slice(0, 10), entries: [{ pkg: "com.youtube.app", app: "YouTube", usageMs: 3600000, launches: 12 }] }) });
  ok("F7 usage: upsert diterima", r.d?.ok === true);
  r = await j("/api/pm/usage?childId=" + childId + "&days=1");
  const yt = (r.d?.topApps || []).find((a) => a.pkg === "com.youtube.app");
  ok("F8 usage report: agregat muncul di dashboard", !!yt && yt.usageMs === 3600000, JSON.stringify(r.d?.topApps));
  r = await j("/api/pm/device/location", { method: "POST", headers: auth, body: JSON.stringify({ lat: -6.2, lon: 106.816, accuracy: 25 }) });
  ok("F9 location: diterima", r.d?.ok === true);
  const thumb = "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABBQJ//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwF//8QAFBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwF//9k=";
  r = await j("/api/pm/device/media", { method: "POST", headers: auth, body: JSON.stringify({ items: [{ kind: "photo", size: 1024, thumb }] }) });
  ok("F10 media: thumbnail pilihan diterima", r.d?.ok === true);
  r = await j("/api/pm/device/heartbeat", { method: "POST", headers: { Authorization: "Bearer faketoken123" }, body: "{}" });
  ok("F11 token palsu ditolak 401", r.status === 401);

  /* ================= TEST G (bagian 2) — replay setelah CONNECTED ================= */
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrF }) });
  ok("G3 QR terpakai ulang → PAIRING_USED", r.d?.ok === false && r.d?.error === "PAIRING_USED", JSON.stringify(r.d));
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ deviceId: devF, consentTicket: ticketF, consent: true }) });
  ok("G4 consent ulang setelah connected → ditolak (tiket sekali pakai: CONSENT_INVALID / DEVICE_NOT_PENDING)", r.d?.ok === false && (r.d?.error === "DEVICE_NOT_PENDING" || r.d?.error === "CONSENT_INVALID"), JSON.stringify(r.d));

  /* ================= TEST H — QR kedaluwarsa (tanda tangan VALID, exp lampau) ================= */
  const expLampau = Date.now() - 60_000;
  const qrH = forgeQr("en-forge-test-0001", "PM-AAAA-BBBB", expLampau);
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrH }) });
  ok("H1 QR exp lampau (sig valid) → PAIRING_EXPIRED", r.d?.ok === false && r.d?.error === "PAIRING_EXPIRED", JSON.stringify(r.d));
  // tanda tangan valid + exp depan → kode tidak ditemukan (id tak ada) → NOT_FOUND, bukan expired
  const qrH2 = forgeQr("en-tak-ada-99999", "PM-CCCC-DDDD", Date.now() + 600_000);
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrH2 }) });
  ok("H2 QR valid tapi enrollment tak ada → PAIRING_NOT_FOUND", r.d?.ok === false && r.d?.error === "PAIRING_NOT_FOUND", JSON.stringify(r.d));

  /* ================= TEST I — cancel ortu + disconnect anak ================= */
  r = await j("/api/pm/enrollment", { method: "POST", body: JSON.stringify({ action: "generate", childId, deviceLabel: "HP Adik 3" }) });
  const qrI = r.d?.enrollment?.qrPayload || "";
  const enrollIdI = qrI.split("|")[1];
  // anak scan dulu (pending)
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrI }) });
  ok("I1 scan (QR ketiga): pending", r.d?.ok === true && r.d?.status === "pending");
  const devI = r.d?.deviceId;
  // ortu membatalkan saat menunggu consent
  r = await j("/api/pm/enrollment", { method: "POST", body: JSON.stringify({ action: "cancel", enrollmentId: enrollIdI }) });
  ok("I2 ortu cancel saat pending: ok", r.d?.ok === true);
  r = await j(`/api/pm/enrollment?id=${enrollIdI}`);
  ok("I3 dashboard: enrollment REVOKED", r.d?.status === "revoked", JSON.stringify(r.d));
  r = await j("/api/pm/overview");
  ok("I4 overview: perangkat pending ikut dicabut (revoked)", r.d?.devices?.some?.((d) => d.id === devI && d.status === "revoked"));
  // scan ulang setelah cancel → PAIRING_CANCELLED
  r = await j("/api/pm/device/enroll", { method: "POST", body: JSON.stringify({ qrPayload: qrI }) });
  ok("I5 scan ulang setelah cancel → PAIRING_CANCELLED", r.d?.ok === false && r.d?.error === "PAIRING_CANCELLED", JSON.stringify(r.d));

  // anak disconnect dari perangkat F
  r = await j("/api/pm/device/disconnect", { method: "POST", headers: auth, body: "{}" });
  ok("I6 anak bisa putus sendiri", r.d?.ok === true);
  r = await j("/api/pm/device/heartbeat", { method: "POST", headers: auth, body: "{}" });
  ok("I7 token mati setelah diputus (401)", r.status === 401);
  r = await j("/api/pm/overview");
  ok("I8 overview: perangkat F revoked", r.d?.devices?.some?.((d) => d.id === devF && d.status === "revoked"));

  // ---------- household isolation ----------
  const savedCookie = cookie;
  const email2 = `pmtest2${Date.now()}@fanzz.test`;
  await j("/api/auth/register", { method: "POST", body: JSON.stringify({ email: email2, username: "intruder", password: "Test12345!" }) });
  r = await j("/api/pm/overview");
  ok("isolasi: user lain tidak melihat anak/device user pertama", (r.d?.children || []).length === 0 && (r.d?.devices || []).length === 0);
  r = await j("/api/pm/usage?childId=" + childId + "&days=1");
  ok("isolasi: usage anak user lain tidak terbaca", r.status === 404 || r.status === 400 || r.d?.ok === false || (r.d?.topApps || []).length === 0);
  cookie = savedCookie;

  // ---------- story: foto + musik (proxy library juga valid) ----------
  r = await j("/api/story/create", { method: "POST", body: JSON.stringify({ type: "photo", text: "caption foto", bg: 2, data: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", music: "data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjY4MC4xLjMAAAA" }) });
  ok("story create: foto+musik diterima (14 dtk)", r.d?.ok === true, JSON.stringify(r.d));
  const storyId = r.d?.story?.id;
  r = await j("/api/story/list");
  const st = (r.d?.groups || []).flatMap((g) => g.stories).find((s) => s.id === storyId);
  ok("story list: tipe photo + photoDuration 14000 + hasMusic, TANPA data (hemat bw)", st?.type === "photo" && st?.photoDuration === 14000 && st?.hasMusic === true && st?.data === undefined);
  r = await j("/api/story/view", { method: "POST", body: JSON.stringify({ id: storyId }) });
  ok("story view: data foto + musik disertakan saat ditonton", r.d?.story?.data?.startsWith("data:image/") === true && r.d?.story?.music?.startsWith("data:audio/") === true);
  r = await j("/api/story/create", { method: "POST", body: JSON.stringify({ type: "photo", data: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==", music: "/api/stream/proxy?url=https%3A%2F%2Fcdn.contoh.com%2Flagu.mp3", musicVideo: "dQw4w9WgXcQ" }) });
  ok("story create: musik dari library situs (path proxy) + videoId valid", r.d?.ok === true, JSON.stringify(r.d));

  // ---------- privacy purge ----------
  r = await j("/api/pm/privacy", { method: "POST", body: JSON.stringify({ what: "all" }) });
  ok("privacy: purge SEMUA data keluarga", r.d?.ok === true, JSON.stringify(r.d));

  console.log(`\n=== HASIL: ${passed} PASS / ${failed} FAIL ===`);
  process.exit(failed > 0 ? 1 : 0);
})().catch((e) => { console.error("FATAL", e); process.exit(2); });
