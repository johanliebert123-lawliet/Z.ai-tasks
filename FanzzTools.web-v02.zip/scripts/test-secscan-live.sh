#!/usr/bin/env bash
# Uji live /api/security/scan (pasif, contoh example.com) — verifikasi
# pemindai 18+ bekerja end-to-end dengan sesi.
set -u
cd /home/z/my-project/work/fanzztools
rm -rf /tmp/fanzz-scan-data
export APP_SECRET="test-secret-0123456789abcdef0123456789"
export FANZZ_DATA_DIR=/tmp/fanzz-scan-data
bun run start -p 3112 > /tmp/fanzz-scan.log 2>&1 &
SRV=$!
sleep 10

curl -s -c /tmp/scan-cookies.txt -X POST http://127.0.0.1:3112/api/auth/register -H "Content-Type: application/json" -d "{\"email\":\"scan$RANDOM@fanzz.test\",\"username\":\"scantester\",\"password\":\"Test12345!\"}" > /dev/null

echo "=== scan example.com (harus ok:true + skor + findings) ==="
curl -s -b /tmp/scan-cookies.txt "http://127.0.0.1:3112/api/security/scan?url=example.com" | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'))
print('target:', d.get('target'))
print('score:', d.get('score'), 'grade:', d.get('grade'))
print('httpStatus:', d.get('httpStatus'))
print('findings:', d.get('summary'))
print('sample:', [f['name'] for f in (d.get('findings') or [])][:5])
"
echo "=== scan host internal → ditolak 400 ==="
curl -s -b /tmp/scan-cookies.txt "http://127.0.0.1:3112/api/security/scan?url=http://10.0.0.1/" | head -c 120; echo ""
echo "=== tanpa sesi → 401 ==="
curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:3112/api/security/scan?url=example.com"

kill $SRV 2>/dev/null
pkill -f next-server 2>/dev/null
echo "DONE"
