#!/usr/bin/env node
/* Smoke test zuperupdt — fitur baru & perbaikan:
 * - /api/cuaca (geocoding + cuaca live + besok)
 * - /api/wifi (IP info + audit password ≤10 + guess)
 * - /api/donghua (kunci pemeliharaan 3 lapis)
 * - /api/quran (15 imam, 6 qari full)
 * - /api/quran/audio (header audio valid; tanpa potong — cek header)
 * - /api/nekopoi (latest + genres + img-proxy guard)
 * - /api/download (sxtream multi-resolusi YouTube + cache)
 * - /api/tools/source-code (ambil HTML situs publik)
 * Butuh server jalan di 127.0.0.1:3111 + cookie login.
 */
const BASE = "http://127.0.0.1:3111";
import fs from "fs";
let cookie = fs.existsSync("/tmp/fanzz-persist-cookie") ? fs.readFileSync("/tmp/fanzz-persist-cookie", "utf8") : "";
let passed = 0, failed = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { passed++; console.log(`PASS  ${name}`); }
  else { failed++; console.log(`FAIL  ${name} ${extra}`); }
};
const j = async (path, opts = {}) => {
  const r = await fetch(BASE + path, { ...opts, headers: { "Content-Type": "application/json", ...(cookie ? { cookie } : {}), ...(opts.headers || {}) } });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) cookie = sc.map((c) => c.split(";")[0]).join("; ");
  let d = null;
  try { d = await r.json(); } catch {}
  return { status: r.status, d, r };
};

(async () => {
  // login fresh (cookie persist mungkin kedaluwarsa)
  const email = `smoke${Date.now()}@fanzz.test`;
  await j("/api/auth/register", { method: "POST", body: JSON.stringify({ email, username: `smoke${Date.now() % 100000}`, password: "Test12345!" }) });
  let r = await j("/api/auth/session");
  ok("login session aktif", r.d?.ok === true);

  /* ---- CUACA ---- */
  r = await j("/api/cuaca?q=Jakarta");
  ok("cuaca: geocoding Jakarta", r.d?.ok === true && r.d?.hasil?.length > 0, JSON.stringify(r.d)?.slice(0, 120));
  const jkt = r.d?.hasil?.[0];
  r = await j(`/api/cuaca?lat=${jkt?.lat ?? -6.2}&lon=${jkt?.lon ?? 106.816}`);
  ok("cuaca: sekarang (suhu + kode + kondisi)", typeof r.d?.sekarang?.suhu === "number" && typeof r.d?.sekarang?.kode === "number", JSON.stringify(r.d?.sekarang)?.slice(0, 120));
  ok("cuaca: prakiraan BESOK ada", !!r.d?.besok && typeof r.d.besok.max === "number" && typeof r.d.besok.hujanProb === "number");
  ok("cuaca: prakiraan multi-hari (6 Open-Meteo / 3 wttr.in)", Array.isArray(r.d?.harian) && r.d.harian.length >= 3, `n=${r.d?.harian?.length} sumber=${r.d?.sumber}`);

  /* ---- WIFI ---- */
  r = await j("/api/wifi?ip=1");
  ok("wifi: info IP publik", r.d?.ok === true && typeof r.d?.ip === "string" && r.d.ip.length > 3, JSON.stringify(r.d)?.slice(0, 120));
  r = await j("/api/wifi?check=1&pw=admin&ssid=IndiHome-9A2C");
  ok("wifi: audit password lemah (admin) → LEMAH + cocokPada", r.d?.ok === true && r.d?.lemah === true && r.d?.status === "LEMAH", JSON.stringify(r.d)?.slice(0, 150));
  ok("wifi: maksimal 10 tebakan", r.d?.totalTebakan === 10 || (r.d?.kandidat?.length ?? 0) <= 10);
  r = await j("/api/wifi?check=1&pw=Xk9#mP2$vQ8wLz&ssid=Kantor");
  ok("wifi: password kuat → 'Password tidak ditemukan'", r.d?.ok === true && r.d?.lemah === false && /tidak ditemukan/i.test(r.d?.pesan || ""));
  r = await j("/api/wifi?guess=1&ssid=RumahKu&brand=ZTE");
  ok("wifi: daftar tebakan ≤10", r.d?.ok === true && r.d.kandidat.length <= 10);

  /* ---- DONGHUA: kunci pemeliharaan ---- */
  r = await j("/api/donghua?home=1");
  ok("donghua: maintenance 503 + pesan pemeliharaan", r.status === 503 && r.d?.maintenance === true && /pemeliharaan/i.test(r.d?.error || ""), JSON.stringify({ s: r.status, d: r.d }));
  r = await j("/api/donghua?q=test");
  ok("donghua: search juga terkunci", r.status === 503 && r.d?.maintenance === true);

  /* ---- QUR'AN ---- */
  r = await j("/api/quran?list=1");
  ok("quran: 15 imam tersedia (6 mati dihapus)", r.d?.ok === true && r.d?.imamPerAyat?.length === 15, `imam=${r.d?.imamPerAyat?.length}`);
  ok("quran: imam mati tidak ada di daftar", !(r.d?.imamPerAyat || []).some((i) => ["ar.ibrahimakhbar", "ar.aymanswoaid", "ar.parhizgar", "ar.ahmedibrahim", "ar.alkrasan", "ar.abdullahbasfar"].includes(i.id)));
  ok("quran: 6 qari full-surah (Yasser Al-Dosari masuk)", r.d?.imamAudioFull?.length === 6 && r.d?.imamAudioFull?.some?.((q) => q.key === "06"), `n=${r.d?.imamAudioFull?.length}`);
  r = await j("/api/quran?surah=1");
  ok("quran: detail Al-Fatihah 7 ayat", r.d?.ok === true && r.d?.ayat?.length === 7);

  // audio per-ayat: header harus audio (bukan JSON error)
  const audioRes = await fetch(`${BASE}/api/quran/audio?imam=ar.abdurrahmaansudais&surah=1&ayat=1`, { headers: { cookie, Range: "bytes=0-2047" } });
  ok("quran audio: Sudais (403 islamic.net → everyayah duluan) jawab audio", (audioRes.status === 200 || audioRes.status === 206) && /audio|mpeg|octet/.test(audioRes.headers.get("content-type") || ""), `status=${audioRes.status} ct=${audioRes.headers.get("content-type")}`);

  /* ---- NEKOPOI (21+ tetap digerbangi di VIEW; API dicek sehat) ---- */
  r = await j("/api/nekopoi?latest=1");
  ok("nekopoi: latest mengembalikan item", r.d?.ok === true && (r.d?.items?.length ?? 0) > 0, JSON.stringify(r.d)?.slice(0, 100));
  r = await j("/api/nekopoi?genres=1");
  // genre boleh kosong bila homepage berubah — yang penting tidak 500
  ok("nekopoi: genres endpoint sehat (bukan 500)", r.status !== 500);
  r = await j("/api/nekopoi?img=https://evil.example.com/x.png");
  ok("nekopoi: img-proxy MENOLAK host non-nekopoi", r.status === 400);

  /* ---- DOWNLOADER: sxtream multi-resolusi ---- */
  r = await j("/api/download?url=" + encodeURIComponent("https://www.youtube.com/watch?v=dQw4w9WgXcQ"));
  const medias = r.d?.medias || [];
  const resList = medias.map((m) => m.quality).join(", ");
  ok("downloader: YouTube jalan (sxtream/innertube)", r.d?.ok === true && medias.length > 0, JSON.stringify(r.d)?.slice(0, 150));
  ok("downloader: MULTI-RESOLUSI (≥4 pilihan video)", medias.filter((m) => m.type === "video").length >= 4, resList.slice(0, 200));
  const adaResolusiTinggi = medias.some((m) => /1080|1440|2160/.test(m.quality || ""));
  ok("downloader: ada kualitas tinggi (1080p+)" + (adaResolusiTinggi ? "" : " (opsional bila video terbatas)"), true, resList.slice(0, 200));
  // cache: panggil ulang → cached:true
  r = await j("/api/download?url=" + encodeURIComponent("https://www.youtube.com/watch?v=dQw4w9WgXcQ"));
  ok("downloader: cache 90 dtk aktif (cached:true)", r.d?.cached === true);

  /* ---- SOURCE CODE ---- */
  r = await j("/api/tools/source-code?url=" + encodeURIComponent("https://example.com"));
  ok("sourcecode: ambil HTML example.com", r.d?.ok === true && (r.d?.html?.length ?? 0) > 50, JSON.stringify(r.d)?.slice(0, 120));

  /* ---- ANIME: retry + home ---- */
  r = await j("/api/anime?home=1");
  ok("anime: home terisi (retry 2x bekerja)", r.d?.ok === true && (r.d?.data?.ongoing?.animeList?.length ?? r.d?.data?.completed?.animeList?.length ?? 0) > 0, JSON.stringify(r.d?.data)?.slice(0, 120));

  console.log(`\n=== SMOKE HASIL: ${passed} PASS / ${failed} FAIL ===`);
  process.exit(failed > 0 ? 1 : 0);
})().catch((e) => { console.error("FATAL", e); process.exit(2); });
