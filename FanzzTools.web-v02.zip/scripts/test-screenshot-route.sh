#!/usr/bin/env bash
# Uji jalur galat /api/security/screenshot (tanpa kunci ScreenshotOne):
# 401 tanpa sesi, 501 jujur saat tak dikonfigurasi, 400 host internal, 429 rate-limit.
set -u
cd /home/z/my-project/work/fanzztools
rm -rf /tmp/fanzz-shot-data
export APP_SECRET="test-secret-0123456789abcdef0123456789"
export FANZZ_DATA_DIR=/tmp/fanzz-shot-data
bun run start -p 3112 > /tmp/fanzz-shot.log 2>&1 &
SRV=$!
sleep 10

echo "=== 1. tanpa sesi → 401"
curl -s -o /dev/null -w "%{http_code}\n" "http://127.0.0.1:3112/api/security/screenshot?url=https://example.com"

echo "=== 2. sesi valid, tanpa key → 501 jujur"
curl -s -c /tmp/shot-cookies.txt -X POST http://127.0.0.1:3112/api/auth/register -H "Content-Type: application/json" -d "{\"email\":\"shot$RANDOM@fanzz.test\",\"username\":\"shottester\",\"password\":\"Test12345!\"}" > /dev/null
curl -s -b /tmp/shot-cookies.txt "http://127.0.0.1:3112/api/security/screenshot?url=https://example.com" | head -c 300; echo ""

echo "=== 3. host internal → 400 (anti-SSRF)"
curl -s -b /tmp/shot-cookies.txt "http://127.0.0.1:3112/api/security/screenshot?url=http://192.168.1.1/" | head -c 150; echo ""

echo "=== 4. rate limit (6/menit) → 429 di pemanggilan ke-7"
for i in 1 2 3 4 5 6 7; do
  curl -s -o /dev/null -w "%{http_code} " -b /tmp/shot-cookies.txt "http://127.0.0.1:3112/api/security/screenshot?url=https://example-$RANDOM.com"
done
echo ""

kill $SRV 2>/dev/null
pkill -f next-server 2>/dev/null
echo "DONE"
