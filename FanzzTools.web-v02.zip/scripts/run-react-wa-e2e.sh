#!/usr/bin/env bash
# Jalankan server produksi + test react-wa e2e dalam SATU sesi.
set -u
cd /home/z/my-project/work/fanzztools
rm -rf /tmp/fanzz-test-data
export APP_SECRET="test-secret-0123456789abcdef0123456789"
export FANZZ_DATA_DIR=/tmp/fanzz-test-data
export NODE_ENV=production

APP_SECRET="$APP_SECRET" FANZZ_DATA_DIR="$FANZZ_DATA_DIR" bun run start -p 3111 > /tmp/fanzz-server.log 2>&1 &
SRV=$!
sleep 12

node scripts/test-react-wa.mjs
TESTEXIT=$?

kill $SRV 2>/dev/null
pkill -f next-server 2>/dev/null
sleep 1
echo "SERVER-LOG:"; tail -5 /tmp/fanzz-server.log
exit $TESTEXIT
