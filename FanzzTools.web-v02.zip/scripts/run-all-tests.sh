#!/usr/bin/env bash
# zuperupdt — test runner lengkap (3 kedalaman sesuai permintaan #14):
#   SUITE 1: PM e2e A–I (62 tes — mesin status 2-fase consent)
#   SUITE 2: persistensi (seed → restart server → verify)
#   SUITE 3: smoke fitur baru (cuaca/wifi/donghua/quran/nekopoi/downloader/sourcecode/anime)
# Server uji: build produksi + APP_SECRET uji + data dir bersih.
set -u
cd /home/z/my-project/work/fanzztools
PORT=3111
BASE="http://127.0.0.1:$PORT"
export APP_SECRET="test-secret-0123456789abcdef0123456789"
export FANZZ_DATA_DIR=/tmp/fanzz-test-data
export PM_TEST_BASE="$BASE"
export PM_TEST_SECRET="$APP_SECRET"

echo "== build produksi =="
APP_SECRET="$APP_SECRET" bun run build > /tmp/zuper-build.log 2>&1 || { echo "BUILD FAIL"; tail -20 /tmp/zuper-build.log; exit 1; }
echo "build: OK"

start_server() { APP_SECRET="$APP_SECRET" FANZZ_DATA_DIR="$FANZZ_DATA_DIR" PORT=$PORT bun run start -p $PORT > /tmp/zuper-server.log 2>&1 & sleep 8; }
stop_server() { pkill -f "next start" 2>/dev/null; pkill -f "next-server" 2>/dev/null; sleep 2; }

echo "== SUITE 1: PM e2e A–I =="
rm -rf "$FANZZ_DATA_DIR"; rm -f /tmp/fanzz-persist-cookie
start_server
node scripts/test-pm-e2e.mjs; S1=$?
stop_server

echo "== SUITE 2: persistensi (restart server) =="
rm -rf "$FANZZ_DATA_DIR"; rm -f /tmp/fanzz-persist-cookie
start_server
node scripts/test-persist.mjs seed > /dev/null 2>&1 || { echo "seed FAIL"; stop_server; exit 1; }
sleep 5   # tunggu debounce tulis file (2,5 dtk)
stop_server
start_server
node scripts/test-persist.mjs verify; S2=$?
# server tetap jalan untuk suite 3 (data tidak perlu bersih)

echo "== SUITE 3: smoke fitur baru =="
node scripts/test-zuperupdt-smoke.mjs; S3=$?
stop_server

echo ""
echo "===================================="
echo "SUITE 1 (PM A–I)   : exit $S1"
echo "SUITE 2 (persist)  : exit $S2"
echo "SUITE 3 (smoke)    : exit $S3"
[ $S1 -eq 0 ] && [ $S2 -eq 0 ] && [ $S3 -eq 0 ] && echo "SEMUA SUITE: PASS ✓" || echo "ADA SUITE GAGAL ✗"
exit $(( S1 + S2 + S3 ))
