#!/usr/bin/env node
/* Uji persistensi (Bug #3): avatar + story + profil harus bertahan restart server.
 * Fase seed: daftar + set avatar + buat story → simpan cookie ke /tmp/fanzz-persist-cookie.
 * Fase verify (setelah server direstart dgn APP_SECRET sama): pakai cookie tersimpan. */
const BASE = "http://127.0.0.1:3111";
import fs from "fs";
let cookie = fs.existsSync("/tmp/fanzz-persist-cookie") ? fs.readFileSync("/tmp/fanzz-persist-cookie", "utf8") : "";
const j = async (path, opts = {}) => {
  const r = await fetch(BASE + path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(cookie ? { cookie } : {}), ...(opts.headers || {}) },
  });
  const sc = r.headers.getSetCookie ? r.headers.getSetCookie() : [];
  if (sc.length) cookie = sc.map((c) => c.split(";")[0]).join("; ");
  let d = null;
  try { d = await r.json(); } catch {}
  return { status: r.status, d };
};

const PHASE = process.argv[2] || "seed";
(async () => {
  if (PHASE === "seed") {
    const email = `persist${Date.now()}@fanzz.test`;
    let r = await j("/api/auth/register", { method: "POST", body: JSON.stringify({ email, username: "persistuser", password: "Test12345!" }) });
    if (!r.d?.ok) { console.error("register gagal", r.d); process.exit(1); }
    fs.writeFileSync("/tmp/fanzz-persist-cookie", cookie);
    // set avatar (data URL kecil)
    const avatar = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==";
    r = await j("/api/social/profile", { method: "POST", body: JSON.stringify({ avatar, bio: "bio persist test" }) });
    console.log("avatar set:", r.d?.ok === true || JSON.stringify(r.d));
    // buat story foto+musik
    r = await j("/api/story/create", { method: "POST", body: JSON.stringify({
      type: "photo", text: "story persist", bg: 1,
      data: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
      music: "data:audio/mpeg;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjY4MC4xLjMAAAA",
    })});
    console.log("story created:", r.d?.ok === true || JSON.stringify(r.d));
    console.log("SEED-OK");
  } else {
    // verify setelah restart — login ulang (session cookie lama masih ada di process ini)
    let r = await j("/api/story/list");
    const mine = (r.d?.groups || []).find((g) => g.isMe);
    const stories = mine?.stories || [];
    console.log("story bertahan:", stories.length === 1 && stories[0]?.type === "photo" && stories[0]?.hasMusic === true ? "PASS" : `FAIL ${JSON.stringify(stories).slice(0, 200)}`);
    r = await j("/api/social/profile");
    const avatarOk = r.d?.profile?.avatar?.startsWith("data:image/png") === true;
    const bioOk = r.d?.profile?.bio === "bio persist test";
    console.log("avatar bertahan:", avatarOk ? "PASS" : "FAIL " + JSON.stringify(r.d?.profile).slice(0, 120));
    console.log("bio bertahan:", bioOk ? "PASS" : "FAIL");
  }
})().catch((e) => { console.error("FATAL", e); process.exit(2); });
