#!/usr/bin/env bash
# Audit keamanan non-regresi — FanzzTools V2 (FanzSec-Update).
# Cek statis: secrets di client, NEXT_PUBLIC secret, auth di route sensitif,
# rate-limit, fail-closed PM, isPrivateHost SSRF, file sensitif di public/.
set -u
cd /home/z/my-project/work/fanzztools
P=0; F=0
cek() { # nama, perintah bash (string) — exit 0 = PASS
  if bash -c "$2" >/dev/null 2>&1; then echo "PASS  $1"; P=$((P+1)); else echo "FAIL  $1"; F=$((F+1)); fi
}

echo "== 1. Secrets tidak boleh ter-bundle ke client =="
cek "tidak ada NEXT_PUBLIC_ yang mengandung SECRET/KEY/TOKEN" '
  ! grep -rE "NEXT_PUBLIC_[A-Z_]*(SECRET|KEY|TOKEN|PASSWORD)" src/ --include="*.ts" --include="*.tsx" | grep -v "CONVEX_URL" | grep -q .'
cek "APP_SECRET hanya di server (tidak ada di components/)" '
  ! grep -rn "APP_SECRET" src/components/ | grep -q .'
cek "API key react WA tidak hardcoded di client components" '
  ! grep -rn "HAFIZ-XD" src/components/ | grep -q .'
cek "kunci screenshotone tidak ada di client" '
  ! grep -rn "SCREENSHOTONE" src/components/ | grep -v "SETUP.md" | grep -v "Tangkapan" | grep -qE "ACCESS_KEY|SECRET_KEY"'

echo "== 2. Route sensitif wajib auth =="
for r in pm/overview pm/children pm/enrollment pm/privacy security/scan security/screenshot react-wa story/list social/profile ai/chat; do
  cek "/api/$r memanggil requireSession/auth" "grep -qE 'requireSession|authDevice|unauthorizedResponse' src/app/api/$r/route.ts"
done

echo "== 3. Rate limit aktif di route upstream =="
for r in security/scan security/screenshot react-wa; do
  cek "/api/$r rate-limited" "grep -q 'rateLimit' src/app/api/$r/route.ts"
done

echo "== 4. Anti-SSRF pada fitur terima-URL =="
for r in security/scan security/screenshot tools/source-code; do
  cek "/api/$r memvalidasi isPrivateHost" "grep -q 'isPrivateHost' src/app/api/$r/route.ts"
done

echo "== 5. Fail-closed PM saat DB gagal =="
cek "pg-bridge: kegagalan DB terlihat (lastError, bukan sukses senyap)" '
  grep -q "lastError" src/lib/pg-bridge.ts'
cek "health route membocorkan status DB" '
  grep -qE "databaseReady|pgStatus" src/app/api/pm/health/route.ts'
cek "route PM sensitif fail-closed 503 saat DB mati" '
  grep -rn "DATABASE_UNAVAILABLE" src/app/api/pm/ | grep -q .'

echo "== 6. File sensitif TIDAK ada di public/ =="
for f in template.apk; do :; done
cek "public/ bebas .env / key / pem" '
  ! ls public/ public/apk 2>/dev/null | grep -qE "\.env|\.pem|\.key|secret"'
cek "apk template boleh (aset publik builder, bukan kunci)" '
  test -f public/apk/template.apk'

echo "== 7. Upload/arsip aman (anti zip-slip) =="
cek "security-scan menolak path ../ dalam arsip" '
  grep -qE "\.\./|zip-slip|zipSlip" src/lib/security-scan.ts'
cek "upload FanzSec.Ai dibatasi 49MB" '
  grep -q "49 \* 1024 \* 1024" src/components/security/FanzSecAiView.tsx'

echo "== 8. Branding konsisten (tidak ada bocoran Lyzs user-facing) =="
cek "src/ bebas Lyzs user-facing (string/JSX — komentar migrasi & kunci lama dikecualikan)" '
  ! grep -rn "Lyzs\|LYZS" src/ --include="*.ts" --include="*.tsx" | grep -v "lyzs_" | grep -vE "^\s*[0-9]+:\s*(/\*|\*|//)" | grep -v "Migrasi data lokal lama" | grep -q .'
cek "android-companion pakai package com.fanzz" '
  grep -q "com.fanzz.familysafety" android-companion/app/build.gradle.kts'
cek "QR prefix FANZZ-PM1 sinkron server & companion" '
  grep -q "FANZZ-PM1" src/lib/pm-store.ts && grep -rq "FANZZ-PM1" android-companion/app/src/main/java/'

echo "== 9. Session/cookie =="
cek "session.ts: APP_SECRET wajib di produksi (throw)" '
  grep -q "production" src/lib/session.ts'
cek "cookie httpOnly + sameSite" '
  grep -qE "httpOnly|sameSite" src/lib/session.ts'

echo ""
echo "=== AUDIT KEAMANAN: $P PASS / $F FAIL ==="
exit $F
