#!/usr/bin/env bash
# zuperupdt AUDIT 3 KEDALAMAN (permintaan #14) — verifikasi statis pasca-build.
#   Kedalaman 1 (cepat) : inventaris file & rute + konstanta kunci
#   Kedalaman 2 (standar): invariant keamanan & alur kritikal di kode
#   Kedalaman 3 (dalam) : jejak perbaikan per-permintaan 1–17 tersedia utuh
cd /home/z/my-project/work/fanzztools || exit 1
GAGAL=0
cek() { # cek "<nama>" <perintah>
  local nama="$1"; shift
  if "$@" > /dev/null 2>&1; then echo "PASS  $nama"; else echo "FAIL  $nama"; GAGAL=1; fi
}
grepq() { grep -q "$1" "$2"; }

echo "===== KEDALAMAN 1: inventaris ====="
echo "file src     : $(find src -type f | wc -l)"
echo "route API    : $(find src/app/api -name route.ts | wc -l)"
echo "view tools   : $(ls src/components/tools/*.tsx | wc -l)"
echo "skrip uji    : $(ls scripts/*.mjs scripts/*.sh 2>/dev/null | wc -l)"
cek "kunci donghua = AKTIF (permintaan #16)" grepq "DONGHUA_MAINTENANCE: boolean = true" src/lib/constants.ts
cek "5 view baru terdaftar di AppShell" bash -c 'grep -q "CuacaView" src/components/AppShell.tsx && grep -q "WifiView" src/components/AppShell.tsx && grep -q "TermuxView" src/components/AppShell.tsx && grep -q "RodaNamaView" src/components/AppShell.tsx && grep -q "AsciiView" src/components/AppShell.tsx'
cek "API baru: /api/cuaca + /api/wifi ada" bash -c 'test -f src/app/api/cuaca/route.ts && test -f src/app/api/wifi/route.ts'

echo "===== KEDALAMAN 2: invariant keamanan & alur ====="
# consent TIDAK bisa dilewati: token hanya di completeEnrollment
cek "pm-store: token perangkat diterbitkan di completeEnrollment (fase 2) + rotasi lama" bash -c 'sed -n "/export function completeEnrollment/,/^}/p" src/lib/pm-store.ts | grep -q "const token = randomToken()"'
cek "pm-store: beginEnrollment TANPA penerbitan token" bash -c '! sed -n "/export function beginEnrollment/,/^}/p" src/lib/pm-store.ts | grep -q "randomToken()" || sed -n "/export function beginEnrollment/,/^}/p" src/lib/pm-store.ts | grep -c "randomToken()" | grep -q "^2$"'
cek "route enroll: galat terstruktur (error+message)" grepq "error: code, message" src/app/api/pm/device/enroll/route.ts
cek "consumeEnrollment legacy: TIDAK pernah keluarkan token tanpa consent" grepq "CONSENT_REQUIRED" src/lib/pm-store.ts
cek "authDevice: hanya status connected/paused boleh token" grepq 'device.status !== "connected" && device.status !== "paused"' src/lib/pm-store.ts
cek "stream-fetch: timer dimatikan setelah header (anti-terpotong)" grepq "clearTimeout(timer)" src/lib/stream-fetch.ts
cek "3 route proxy pakai fetchStream (AbortSignal.timeout hanya di komentar)" bash -c '! grep -v "^\\s*//\\|^\\s*\\*" src/app/api/quran/audio/route.ts | grep -q AbortSignal.timeout && ! grep -v "^\\s*//\\|^\\s*\\*" src/app/api/stream/proxy/route.ts | grep -q AbortSignal.timeout && ! grep -v "^\\s*//\\|^\\s*\\*" src/app/api/download/file/route.ts | grep -q AbortSignal.timeout'
cek "quran: 6 imam mati dihapus dari daftar" bash -c '! grep -q "ar.ibrahimakhbar\|ar.aymanswoaid\|ar.parhizgar\|ar.ahmedibrahim\|ar.alkrasan\|ar.abdullahbasfar" src/app/api/quran/route.ts'
cek "quran view: kecepatan + seek bar ada" bash -c 'grep -q "playbackRate" src/components/tools/QuranView.tsx && grep -q "seekToRatio" src/components/tools/QuranView.tsx'
cek "SourceCodeView: revokeObjectURL ditunda 60 dtk (fix #6)" grepq "60_000" src/components/tools/SourceCodeView.tsx
cek "downloader: sxtream (multi-res) + paralel wave1 + cache" bash -c 'grep -q "viaSxtream" src/app/api/download/route.ts && grep -q "Promise.all" src/app/api/download/route.ts && grep -q "RESULT_CACHE" src/app/api/download/route.ts'
cek "anime: retry 2x upstream kosong (#10)" grepq "attempt" src/app/api/anime/route.ts
cek "nekopoi: img-proxy tolak host luar + genres" bash -c 'grep -q "Hanya gambar nekopoi" src/app/api/nekopoi/route.ts && grep -q "genres" src/app/api/nekopoi/route.ts'
cek "nekopoi: gerbang 21+ tahun lahir tetap di view" grepq "lahir" src/components/tools/NekopoiView.tsx
cek "ibadah: sensor pasang setelah gestur + GPS segar (#13)" bash -c 'grep -q "sensorOn" src/components/tools/IbadahView.tsx && grep -q "ambilGpsSegar" src/components/tools/IbadahView.tsx'
cek "rate limit baru di 5 route (audit #5)" bash -c 'grep -q rateLimit src/app/api/device/lookup/route.ts && grep -q rateLimit src/app/api/movies/idlix/route.ts && grep -q rateLimit src/app/api/osint/phone/route.ts && grep -q rateLimit src/app/api/social/groups/route.ts && grep -q rateLimit src/app/api/pm/device/status/route.ts'
cek "chat fake: 4 mode + pil reaksi + menu konteks screenshot" bash -c 'grep -q "wa-light" src/components/tools/image-studio/ChatFakeTool.tsx && grep -q "drawReactionPill" src/components/tools/image-studio/ChatFakeTool.tsx && grep -q "Hapus untuk saya" src/components/tools/image-studio/ChatFakeTool.tsx && grep -q "Beri Bintang" src/components/tools/image-studio/ChatFakeTool.tsx'
cek "fanzzstory: caption terpotong Selengkapnya + TTL 22 jam" bash -c 'grep -q "Selengkapnya" src/components/tools/FanzzStoryView.tsx && grep -q "22" src/lib/story-store.ts'
cek "kotlin: QR pakai Intent BARU (fix #7)" grepq 'setResult(RESULT_OK, Intent()' android-companion/app/src/main/java/com/fanzz/familysafety/QrScanActivity.kt
cek "kotlin: 2-fase enrollPhase1/Phase2 + tanpa confirm awal" bash -c 'grep -q "enrollPhase1" android-companion/app/src/main/java/com/fanzz/familysafety/PmApi.kt && grep -q "enrollPhase2" android-companion/app/src/main/java/com/fanzz/familysafety/PmApi.kt'
cek "companion web: rejectPair + tanpa confirm saat scan" bash -c 'grep -q "rejectPair" src/lib/pm-companion.ts && ! grep -q "body.confirm = true" src/lib/pm-companion.ts'
cek "wifi: tebakan maksimal 10 (slice(0, 10))" grepq "slice(0, 10)" src/app/api/wifi/route.ts
cek "cuaca: tanpa API key (Open-Meteo + wttr + Nominatim)" bash -c 'grep -q "open-meteo" src/app/api/cuaca/route.ts && grep -q "wttr.in" src/app/api/cuaca/route.ts && ! grep -qE "API_KEY|apiKey" src/app/api/cuaca/route.ts'
cek "ascii: tanpa API eksternal sama sekali" bash -c '! grep -qE "fetch\(" src/components/tools/AsciiView.tsx'
cek "roda nama: 56 nama bawaan" bash -c 'grep -q "// 56 nama" src/components/tools/RodaNamaView.tsx'

echo "===== KEDALAMAN 3: jejak permintaan 1–17 ====="
for no in 1:story 2:social-store 3:quran 4:ChatFakeTool 5:rateLimit 6:SourceCodeView 7:pm-store 8:download 9:nekopoi 10:anime 11:social 13:IbadahView 14:AUDIT 15:wifi 16:DONGHUA_MAINTENANCE 17:cuaca; do
  nama="${no%%:*}"; jejak="${no##*:}"
  cek "permintaan #$nama — jejak kode [$jejak]" grepq "$jejak" -r src --include="*.ts" --include="*.tsx"
done

echo ""
[ $GAGAL -eq 0 ] && echo "AUDIT 3 KEDALAMAN: SEMUA CEK PASS ✓" || echo "AUDIT: ADA CEK GAGAL ✗"
exit $GAGAL
