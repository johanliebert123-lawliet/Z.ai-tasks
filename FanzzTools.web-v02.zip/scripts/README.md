# Skrip Uji (V2.12 Security-Updt)

Jalankan saat server berjalan (default port 3111 — sesuaikan `BASE`):
- `node scripts/test-pm-e2e.mjs` — 31 pengujian end-to-end Parent Monitor + story foto/musik.
- `node scripts/test-persist.mjs seed` lalu restart server dengan APP_SECRET sama, lalu `node scripts/test-persist.mjs verify`.
