# VERCEL-DEPLOYMENT.md — Deploy FanzzTools V2.12 Security-Updt

> Panduan deploy pemula (Vercel) + catatan self-host.

## Deploy ke Vercel (±5 menit)

1. **Push/zip** kode ini ke repositori Git Anda (GitHub/GitLab).
2. [vercel.com](https://vercel.com) → **Add New → Project** → import repo.
3. Framework otomatis terdeteksi **Next.js** — biarkan semua default.
4. **Environment Variables** (Settings → Environment Variables):

   | Name | Value | Environment |
   |---|---|---|
   | `APP_SECRET` | hasil `openssl rand -hex 32` | Production + Preview + Development |

   ⚠️ Tanpa ini deploy **gagal cepat** dengan pesan
   `[FanzzTools] APP_SECRET WAJIB di-set di production!` — itu disengaja
   demi keamanan sesi & QR Parent Monitor.

5. **Deploy** → selesai. `vercel.json` sudah mengatur header keamanan +
   region `sin1` (terdekat pengguna Indonesia).

## Setelah deploy: checklist Parent Monitor

- [ ] Buka `https://domain-anda/api/pm/health` → harus `{"ok":true,...}`
- [ ] Login → sidebar ada **Parent Monitor** (badge BARU)
- [ ] Onboarding pernyataan wali → buat profil anak (usia ≤ 35)
- [ ] QR pairing muncul + countdown 10 menit
- [ ] (Opsional) Build companion APK via APK Builder mode Parent Monitor
- [ ] (Opsional data penuh) Build companion native: `android-companion/`
  → ganti `DEFAULT_SERVER` ke domain Anda → Android Studio

## ⚠️ Batas penting Vercel (baca sebelum pilih hosting)

Vercel/serverless **tidak punya disk persisten antar instance**:

- Profil, story, chat, dan data Parent Monitor disimpan di folder `data/`
  → bertahan **selama instance warm** saja (menit–jam tanpa trafik).
- Setelah instance tidur/di-scale, data memulai dari nol.

**Rekomendasi** (urutan):
1. **VPS/self-host** (Railway/Render/VPS apa pun, `bun run build && bun run start`)
   → `data/` benar-benar persisten. Set `FANZZ_DATA_DIR` ke disk persisten.
2. Vercel untuk demo/uji coba (fitur lain 100% jalan; data sosial bersifat
   sementara).

## Self-host singkat

```bash
bun install            # atau npm install
cp .env.example .env.local   # edit APP_SECRET!
bun run build
bun run start          # default port 3000
```

Reverse proxy HTTPS (wajib untuk sensor kompas kiblat & kamera QR):
contoh Caddyfile sudah disertakan (`Caddyfile`).

## Yang TIDAK perlu di-set

- Tidak ada env khusus Parent Monitor — `APP_SECRET` yang sama menandatangani
  QR pairing (HMAC) dan sesi.
- Jangan taruh rahasia dengan prefix `NEXT_PUBLIC_` (ikut terkirim ke browser).
