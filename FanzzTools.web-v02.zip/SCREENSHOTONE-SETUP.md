# ScreenshotOne — Setup Tangkapan Layar Situs (FanzzSecurity)

Fitur **"Tangkapan Layar Situs"** pada alat *Cek Keamanan Website*
(FanzzSecurity → Pindai Web / URL) memakai layanan
[ScreenshotOne](https://screenshotone.com) untuk memfoto tampilan situs
target sebagai **bukti visual** saat pemindaian.

Tanpa kunci, fitur ini **tidak aktif** — tombol tetap terlihat, tetapi
menjawab `SCREENSHOT_NOT_CONFIGURED` secara jujur. Tidak ada gambar
palsu/placeholder yang dipalsukan sebagai hasil sukses.

## Kenapa lewat proxy server?

Permintaan TIDAK dikirim langsung dari browser ke ScreenshotOne, melainkan
lewat route server FanzzTools: `/api/security/screenshot`. Alasannya:

1. **Kunci tidak bocor** — `ACCESS_KEY`/`SECRET_KEY` hanya hidup di server.
   Browser hanya memanggil route milik kita sendiri.
2. **Anti-SSRF** — host internal/lokal/private (127.0.0.1, 10.x, 192.168.x,
   metadata cloud, dll.) DITOLAK sebelum sampai ke upstream. Permintaan hanya
   boleh memfoto host publik.
3. **Rate limit** — maksimum 6 tangkapan/menit per IP + wajib sesi login.
   Mencegah pemborosan kuota akun ScreenshotOne oleh pengguna lain.
4. **Kualitas terkunci** — viewport 1280×800, JPG kualitas 80, cache aktif.
   Hasil konsisten dan hemat kuota.

## Cara menyetel (Vercel Dashboard — tanpa terminal)

1. Daftar / login di **https://screenshotone.com** (ada paket gratis).
2. Buka **Dashboard → Access keys** → salin *Access key*.
   *(Opsional: buat juga *Secret key* untuk permintaan bertanda tangan —
   tanpa itu, mode access-key saja sudah cukup.)*
3. Buka **Vercel Dashboard** → project FanzzTools → **Settings →
   Environment Variables**.
4. Tambah:
   | Name | Value |
   |------|-------|
   | `SCREENSHOTONE_ACCESS_KEY` | (access key dari langkah 2) |
   | `SCREENSHOTONE_SECRET_KEY` | (secret key, opsional) |
5. Klik **Save**, lalu **Deployments → … → Redeploy** agar variabel terbaca.
6. Buka FanzzTools → FanzzSecurity → Pindai Web / URL → pindai sebuah
   situs → tekan **"Tangkapan Layar Situs"**. Gambar muncul + tombol
   **Unduh JPG**.

## Format respons route

| Kondisi | Respons |
|---|---|
| Sukses | `200` + bytes gambar (`Content-Type: image/jpeg`) |
| Belum dikonfigurasi | `501` JSON `{error:"SCREENSHOT_NOT_CONFIGURED", message}` |
| Host ditolak (internal) | `400` `Host internal/lokal tidak diizinkan` |
| Terlalu sering | `429` (rate limit 6/menit/IP) |
| Upstream gagal/timeout | `502` + keterangan apa adanya |

## Kejujuran hasil

Gambar yang ditampilkan adalah **byte-for-byte hasil ScreenshotOne** untuk
URL tersebut — tidak dimanipulasi, tidak digambar ulang. Bila ScreenshotOne
gagal (situs menolak dirender, timeout, kuota habis), UI menampilkan pesan
gagal apa adanya dan **tidak** mengklaim screenshot berhasil.
