# API-SOURCES — Sumber Layanan Eksternal FanzzTools V2

Dokumen ini mencatat SEMUA upstream/layanan eksternal yang dipanggil
FanzzTools, bagaimana dipanggil, kunci yang dibutuhkan, dan statusnya.
Prinsip: **proxy server-side** — browser hanya memanggil route milik
FanzzTools sendiri (`/api/...`); tidak ada kunci rahasia yang ikut
ter-bundle ke client.

## Ringkasan per kategori

| Kategori | Sumber | Kunci | Jalur |
|---|---|---|---|
| React Saluran WA | api.jerexd.my.id | `JEREXD_APIKEY` (default terpasang, server-side) | `/api/react-wa` |
| Tangkapan layar | api.screenshotone.com | `SCREENSHOTONE_ACCESS_KEY` (+ opsional SECRET) | `/api/security/screenshot` |
| Metadata film/anime | api.themoviedb.org | `TMDB_API_KEY` (default publik terpasang) | `/api/movies/*`, `/api/anime` |
| Musik | music.youtube.com (internal API), api-faa.my.id | — | `/api/music/*` |
| Downloader | api.sxtream.my.id, api-faa.my.id | — | `/api/download` |
| Cuaca/BMKG | api.open-meteo.com, data.bmkg.go.id | — | `/api/cuaca`, `/api/bmkg` |
| Ibadah | api.aladhan.com, equran.id, cdn.equran.id, everyayah.com, cdn.islamic.network | — | `/api/ibadah/*`, `/api/quran/*` |
| Buku | openlibrary.org, archive.org, books.google.com | — | `/api/books` |
| Berita + fact-check | news.google.com (RSS), feeds.bbci.co.uk | — | `/api/news`, `/api/news/factcheck` |
| Anime/Manga | api.jikan.moe, api.mangadex.org, bintangapi.my.id | — | `/api/anime`, `/api/donghua`, `/api/manhwa` |
| Email sementara | temp-mail.io (internal API) | — | `/api/email/*` |
| AI (chat/gambar/search/vision) | z-ai SDK (server-side) | kunci di server | `/api/ai/*` |
| OSINT domain | rdap.org, rdap.verisign.com, data.iana.org | — | `/api/osint/domain`, `/api/osint/whois` |
| OSINT IP | ipwho.is | — | `/api/osint/ip` |
| OSINT email | emailrep.io, gravatar.com | — | `/api/osint/email` |
| OSINT WA | wa.me (pemetaan publik) | — | `/api/osint/wa` |
| Sumber lain | github.com users, deepai.org | — | `/api/username-check`, `/api/ai/image` |

## Detail penting per layanan

### React Saluran WA (reactCh)
- Upstream: `GET https://api.jerexd.my.id/api/whatsapp/reactch?apikey=…&url=<pesan>&emoji=<e1,e2>`
- Dipanggil dari `/api/react-wa` (POST, proxy server-side, rate-limit 30/menit/IP).
- Kontrak diverifikasi langsung: 200 = masuk antrean, 429 = jeda ±15 detik
  per postingan sama, 400 = `url` wajib.
- **Perbaikan bug v01**: dulu parameter `url` tidak terkirim (root cause
  error 400 "Parameter url wajib diisi"). Sekarang wajib dikirim + divalidasi
  (`^https?://` + mengandung `whatsapp.com`), kombinasi maks 2 emoji.
- Rotasi kunci: ganti env `JEREXD_APIKEY` tanpa ubah kode.

### ScreenshotOne
- Upstream: `GET https://api.screenshotone.com/take?access_key=…&url=…`
- Dipanggil dari `/api/security/screenshot` (GET, proxy, anti-SSRF
  `isPrivateHost`, rate-limit 6/menit/IP, wajib sesi login).
- Tanpa kunci → 501 jujur `SCREENSHOT_NOT_CONFIGURED`. Detail: `SCREENSHOTONE-SETUP.md`.

### OSINT (WHOIS/RDAP/IP/email)
- WHOIS modern via RDAP (rdap.org + registry spesifik) — publik, tanpa kunci.
- IP intel via ipwho.is — publik. Bukan pelacak GPS; hanya ASN/ISP/negara.
- Email rep via emailrep.io — skoring publik. Breach penuh (haveibeenpwned)
  memerlukan API key berbayar → ditandai jujur di UI sebagai belum tersedia.
- NIK: validasi FORMAT + wilayah (regex + tabel wilayah) — bukan database
  rahasa pemerintah. Tidak pernah diklaim bisa membaca data pribadi.

### Layanan tanpa kunci (publik)
Open-Meteo, BMKG, Jikan, MangaDex, OpenLibrary, Archive.org, Google News RSS,
BBC RSS, equran.id, aladhan, everyayah — semua endpoint publik gratis.
Dipanggil server-side dengan timeout + rate-limit FanzzTools sendiri agar
 tidak menyalahgunakan kuota upstream.

### AI
Model AI dipanggil via SDK server-side (`src/lib/ai.ts`) — kunci model
tidak pernah masuk client bundle. FanzSec.Ai memakai jalur yang sama dengan
sistem-prompt white-hat (lihat FANZSEC-AI.md).

## Etika & batas scraping
- Downloader hanya memproses tautan milik pengguna sendiri; tidak ada
  scraping massal otomatis.
- Semua route upstream memiliki `AbortSignal.timeout` — permintaan macet
  dibatalkan, tidak menggantung.
- Rate limit per-IP diterapkan di SEMUA route yang memanggil upstream
  (lihat `src/lib/store.ts` → `rateLimit`).
- Host internal/private ditolak (`src/lib/validate.ts` → `isPrivateHost`)
  untuk semua fitur yang menerima URL dari pengguna (anti-SSRF).
