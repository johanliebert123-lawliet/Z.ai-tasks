# SECURITY.md — Model Keamanan FanzzTools V2 (Security-Updt)

> Dokumen ini merangkum arsitektur keamanan yang **sudah ada** (tidak
> diubah oleh Security-Updt — diperkuat, bukan diganti) + tambahan untuk
> Parent Monitor.

## Yang TIDAK berubah (warisan Modern-UpdSec — tetap ketat)

1. **APP_SECRET fail-fast** — production tanpa `APP_SECRET` gagal build.
   Secret yang sama menandatangani sesi JWT **dan** QR Parent Monitor.
2. **Sesi HTTP-only** — cookie `httpOnly` + `Secure` + `SameSite` —
   JavaScript klien tidak bisa mencuri sesi.
3. **Rate limiting** di semua endpoint sensitif (login, register, unduhan,
   story, PM, dll) + sweeper anti-bengkak memori.
4. **SSRF guard** — proxy/downloader menolak IP privat, CGNAT, link-local,
   IPv6 ULA; redirect diikuti manual dengan revalidasi host.
5. **Validasi input ketat** — zod/manual di setiap route; URL berkredensial
   ditolak; panjang payload dibatasi.
6. **Header keamanan** — CSP, COOP, CORP, HSTS preload, Permissions-Policy
   (di `next.config.ts` + `vercel.json`).
7. **Password bcrypt 12 rounds** + minimal 8 karakter + anti brute-force
   per-IP dan per-email.
8. **Source map mati** di production.

## Tambahan khusus Parent Monitor (V2.12)

| Kontrol | Implementasi |
|---|---|
| Token perangkat hash-only | Server simpan SHA-256; plaintext hanya sekali di response enroll |
| QR ber-HMAC + TTL 10 menit + sekali pakai | `FANZZ-PM1\|id\|code\|exp\|sig` — palsu/kedaluwarsa/replay ditolak |
| Konfirmasi anak wajib | `/api/pm/device/enroll` menolak tanpa `confirm: true` |
| Pernyataan wali (attestation) gate | Semua operasi PM anak/perangkat butuh attestation tersimpan |
| Batas usia anak 35 tahun | Validasi server-side saat create/update profil anak |
| Isolasi household | Setiap query memfilter `householdId` milik sesi — parent A tidak bisa baca parent B (diuji) |
| Audit log | Semua aksi orang tua (QR, revoke, purge, dll) tercatat per household |
| Rate-limit device API | heartbeat 120/mnt, usage 60/mnt, location 60/mnt, media 30/mnt per IP |
| Retensi otomatis | usage 90 hr, lokasi 30 hr, thumbnail 30 hr, metadata media 90 hr |
| No-spyware by design | Tidak ada endpoint untuk konten chat/OTP/ketikan/layar/audio — fiturnya memang tidak ada |

## Batas yang jujur harus diketahui

- **Vercel/serverless**: filesystem tidak persisten antar instance —
  data social/story/PM bertahan selama instance warm + hanya benar-benar
  persisten di self-host/VPS (folder `data/`). Ini batas platform, bukan
  celah keamanan.
- **Companion web** tidak bisa mengakses UsageStatsManager — keterbatasan
  platform Android untuk semua aplikasi berbasis web, bukan pilihan desain.
- Keamanan klien (anti-devtools dll) menaikkan hambatan, bukan
  membuat-inspeksi-mustahil — logika sensitif tetap 100% di server.
