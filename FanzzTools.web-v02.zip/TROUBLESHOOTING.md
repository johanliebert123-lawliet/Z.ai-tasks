# TROUBLESHOOTING — FanzzTools V2.12 Security-Updt

Kumpulan masalah → solusi, termasuk **7 perbaikan** di versi ini.

---

## 🆕 Perbaikan V2.12 (ringkas)

| # | Masalah lama | Penyebab | Sekarang |
|---|---|---|---|
| 1 | Audio Qur'an gagal semua imam ("imam lagi bermasalah") | View memanggil CDN luar langsung + `crossOrigin` → kena CORS/blokir jaringan | Audio di-stream via `/api/quran/audio` (same-origin) + rantai sumber cadangan: islamic.network → everyayah → equran.id |
| 2 | Downloader: preview mati; YT malah ke-redirect ke halaman FanzzTools sendiri | URL InnerTube sudah proxy relatif lalu dibungkus DUA KALI → 400 "Tautan tidak valid"; fallback anchor membuka URL relatif = halaman sendiri | Proxy URL dipakai apa adanya (tanpa double-wrap); unduh langsung hanya untuk URL absolut |
| 3 | Foto profil & story hilang setelah balik | social-store & story-store 100% in-memory; + bug file JSON ter-stringify ganda sehingga pm.json juga tak pernah pulih | Kedua store kini persisten (data/social.json, data/story.json) + bug stringify ganda diperbaiki |
| 4 | Status belum support foto + musik | Tipe story cuma teks/video | Mode **Foto + Musik**: foto tampil **14 detik tetap**, musik **dipotong 14 detik** |
| 5 | Video story layar hitam | `src` video tidak pernah diisi (data tidak ikut list; respons `/api/story/view` diabaikan) | Data video/foto/musik dimuat saat ditonton + indikator memuat |
| 6 | Fitur pengawasan anak belum aktif | View Parent Monitor tidak terdaftar di navigasi; fitur QR di-hardcode | Dashboard aktif di sidebar/beranda/All-Tools + QR membawa pilihan fitur orang tua |
| 7 | Kompas kiblat tidak bergerak/salah arah | Hanya `deviceorientation` (alpha relatif) tanpa kompensasi layar | `deviceorientationabsolute` + fallback iOS + kompensasi rotasi layar + smoothing + label status sensor |

---

## Detail solusi per fitur

### Audio Qur'an
- Tidak perlu setting apa pun — proxy otomatis. Kalau satu imam masih gagal:
  sistem otomatis pindah sumber; kalau tetap gagal, **ganti imam** (dropdown)
  atau coba mode **Full Surah**.
- Pastikan masih login (rate-limit 90 request/menit per IP).

### Downloader
- Preview: tekan tombol **putar bulat ungu** → video diputar lewat proxy
  server (bebas CORS/Referer block). Bisa di-seek.
- Kalau muncul "Beralih ke unduh langsung" → normal: CDN sumber menolak
  proxy, browser ambil langsung dari CDN (file tetap tersimpan).
- Link harus `http://`/`https://` publik; link privat/dibatasi memang gagal.

### Story (foto+musik/video)
- Foto: PNG/JPG/WebP maks ±7 MB. Musik: MP3/M4A/OGG/WAV maks ±6 MB.
- **Durasi foto selalu 14 detik** — musik dipotong di 14 detik otomatis;
  kalau musiknya lebih pendek, lagu berhenti natural.
- Maksimal 5 status aktif per user; masa hidup 22 jam.

### Kiblat (Ruang Ibadah)
- Tekan **Aktifkan kompas** lalu angkat HP (layar ke atas).
- Label status: **kompas absolut** = akurat ke utara sejati.
  **kompas relatif** = kalibrasi dengan pola angka-8 beberapa kali.
  Tidak muncul sensor = browser perangkat itu tidak mengirim data kompas —
  pakai angka derajat kiblat yang tertera (tetap valid untuk patokan).
- iOS: akan muncul permintaan izin Motion & Orientation — izinkan.

### Parent Monitor
- **"Ditolak sebelum attestation"** → selesaikan onboarding dulu.
- **"Batas usia profil anak adalah 35 tahun"** → sistem menolak tahun lahir
  yang menghasilkan usia >35 (anti salah-pakai). Tidak bisa di-bypass.
- **QR kedaluwarsa** → tekan Muat Ulang QR (10 menit masa berlaku).
- **"Kode sudah dipakai"** → QR sekali pakai; buat QR baru.
- **Companion "Server tidak terjangkau"** → cek internet HP anak; cek
  `GET /api/pm/health` dari browser HP (harus `{"ok":true,...}`).
- **Statistik pemakaian kosong** → companion web memang tidak bisa akses
  UsageStatsManager; pakai companion native (`ANDROID-SETUP.md`), atau
  aktifkan Usage Access di HP anak (native).
- **Data hilang di Vercel** → serverless filesystem tidak persisten antar
  instance; gunakan self-host/VPS untuk data yang benar-benar menetap
  (folder `data/`), atau terima data warm-instance-only.

### Deployment
- Production **wajib** `APP_SECRET` (lihat `.env.example` / `VERCEL-DEPLOYMENT.md`).
- Build gagal `[FanzzTools] APP_SECRET WAJIB di-set` → itu SENGAJA (fail-fast).
