# SECURITY-SCANNER — Mesin Pemindai FanzzSecurity

Dokumen teknis + batas kejujuran mesin pemindai FanzzTools. Berlaku untuk
**Pindai File** (klien), **Cek Keamanan Website** (server), dan alat bantu
hash/IOC (klien). Prinsip utama spesifikasi pemilik: **hasil pemindaian
TIDAK BOLEH DIPALSUKAN** — tanpa engine, statusnya UNSCANNABLE /
HEURISTIC_ONLY, bukan "SAFE".

## 1. Pindai File (klien — `src/lib/security-scan.ts`)

Analisis **statis heuristik**, 100% di browser (file tidak diunggah ke
server, tidak dijalankan):

1. **Hash SHA-256** via WebCrypto — identitas file.
2. **Deteksi MIME nyata** dari magic-byte (tabel 20+ tanda: JPEG, PNG, ZIP,
   PDF, ELF, MZ/EXE, DEX Android, Matroska, dll).
3. **Ekstensi menyamar** — mismatch ekstensi vs MIME asli (mis. `.jpg`
   yang isinya EXE) = sinyal bahaya kuat.
4. **Inspeksi arsip anti zip-slip** — daftar entry ZIP, tandai path
   `../`/absolut, file ganda, ukuran dekompresi ekstrem (zip bomb heuristik).
5. **Struktur APK** — `AndroidManifest.xml`, `classes.dex`, native lib,
   META-INF; tandai APK tanpa manifest / dex tersembunyi.
6. **String mencurigakan** (frasa umum payload) — bobot kecil, heuristik.

**Status hasil (jujur):**
- `CLEAN_HEURISTIC` — tidak ada sinyal buruk *dari pemeriksaan yang ada*
  (BUKAN jaminan bebas virus).
- `SUSPICIOUS` — ada sinyal kuat (ekstensi menyamar, zip-slip, entry ganda).
- `HEURISTIC_ONLY` — data tidak cukup untuk menyimpulkan.
- `UNSCANNABLE` — file terenkripsi/rusak/tidak terbaca — TIDAK pernah
  dipalsukan jadi "SAFE".

Tidak ada verdict "MALICIOUS"/"virus detected" — itu butuh reputasi hash
mesin AV (VirusTotal dsb.) yang belum dikonfigurasi. UI menyatakannya.

## 2. Cek Keamanan Website (server — `/api/security/scan`)

Pemindaian **pasif** 18+ pemeriksaan — hanya membaca respons HTTP publik,
nol eksploitasi:

HTTPS/redirect, HSTS (max-age + includeSubDomains + preload),
X-Frame-Options/CSP frame-ancestors, nosniff, Referrer-Policy, kualitas
CSP (unsafe-inline/eval), Permissions-Policy, cookie flags
(HttpOnly/Secure/SameSite), banner versi server, mixed content, CORS
reflektif, form action http, COOP/CORP/COEP, security.txt, robots/sitemap,
generator meta, Cache-Control dinamis.

Skor 0–100 berbobot + grade A+…F + saran perbaikan per temuan.
Proteksi: wajib sesi login, rate-limit 8/menit/IP, **anti-SSRF**
(`isPrivateHost` menolak 127.0.0.1, 10.x, 192.168.x, 172.16–31.x,
169.254.169.254, localhost, .internal, dsb.), redirect diikuti maks 5 hop
dengan validasi ulang setiap hop.

Tambahan v01: **tangkapan layar bukti visual** via ScreenshotOne
(`/api/security/screenshot`) — proxy server-side, tanpa kunci → 501 jujur
(lihat SCREENSHOTONE-SETUP.md).

## 3. Hash / IOC Analyzer (klien)

Utilitas white-hat lokal: hash file (SHA-256/1, MD5), decode JWT (header +
payload, tanpa verifikasi tanda tangan — dinyatakan demikian), decode
Base64, ekstraksi IOC (IPv4, domain, URL) dari teks. Tidak menghubungi
server threat-intelligence apa pun → tidak ada "reputation" palsu.

## 4. Metadata Gambar (klien)

Parser EXIF ringan: kamera, tanggal, GPS bila tertanam. File tanpa EXIF →
"tidak ada metadata" (jujur), bukan dikira-kira.

## 5. Batasan yang diakui

- Heuristik statis ≠ antivirus. Sinyal bersifat indikatif.
- Engine reputasi hash (VirusTotal/Intezer) belum diintegrasikan — status
  breach-scan email pun sama (butuh kunci). Semua kekurangan ditampilkan
  apa adanya di UI, bukan disembunyikan.
- Pemindaian tidak pernah mengeksekusi file target — aman untuk file
  berbahaya sekalipun.
